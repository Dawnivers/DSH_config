# 换机复刻 DSH：把「懂你的那个它」搬过去

> 一句话：**模型是装出来的，记忆是拷过来的。**
> DSH 里"和你做过很多项目、记得你的风格"这件事，落在 C 盘用户目录的三样东西里 ——
> `~/.mnemon`（记忆本体）、`~/.dsh/profiles` 与 `~/.dsh/skills`（插件、技能与配置）、以及**项目代码本身所在的绝对路径**。
> 会话历史（`~/.dsh/sessions`）**不在其中**：它是提炼记忆的原料，不是资产，备份包默认不带（见下方表格）。
> 把上面三样原样搬到新机，它就还是那个它；漏掉任何一个，新机会变成一个礼貌的陌生人。

---

## 0. 这套工具

| 文件 | 作用 |
| --- | --- |
| `export-dsh.ps1` | 在**旧机**上跑，产出一个迁移包（本机实测：1174 文件 / 38 MB，压缩后 11 MiB —— 不含会话与缓存） |
| `restore-dsh.ps1` | 在**新机**上跑，把包里的数据归位（只搬文件，不装插件） |
| `distill-dsh.mjs` | 周备份**之前**跑：把最近 7 天的会话榨成一份摘要，供提炼进 `MEMORY.md` |
| 本文 | 手工步骤与验收清单 |

### 每周的固定动作：先提炼，再备份

会话不随包走（它是 zstd 压过、再压不动的 80 MB 原料）。所以在备份之前，先把本周对话里**还值得留的东西**落进长期记忆，否则电脑一坏就永久丢了：

```powershell
node .\distill-dsh.mjs --days 7        # 产出 D:\dsh-migration\distill\distill-<日期>.md
node .\distill-dsh.mjs --list          # 只看这周有哪些会话，不导出内容
```

摘要里每个会话给的是：工作目录、轮次、用了哪些工具、以及**你本人说过的每一句话**（子代理会话和一两句的碎片会跳过）。
读一遍，把「半年后还有用的」挑出来写进 `MEMORY.md`：规则、偏好、踩过的坑、定下来的决策；
一次性的过程（装了什么、跑了哪条命令）不要写。

`publish-dsh.ps1` 会在打包前检查最近一次摘要是几天前的，超过 7 天就警告——它不阻止备份，只是提醒你漏了这一步。

```powershell
# 旧机打包（默认落 D:\dsh-migration\dsh-<时间戳>，不含 node_modules / 缓存 / 登录态）
pwsh -File .\export-dsh.ps1
pwsh -File .\export-dsh.ps1 -SkipAttachments      # 不要历史图片时，省掉 180 MB
pwsh -File .\export-dsh.ps1 -KeepSessions         # 反悔了，把会话也带上（包会回到 90+ MB）

# 新机先看清单，再归位
pwsh -File .\restore-dsh.ps1 -Kit 'D:\dsh-migration\dsh-20261018-1014' -WhatIfOnly
pwsh -File .\restore-dsh.ps1 -Kit 'D:\dsh-migration\dsh-20261018-1014' -Force
```

| 路径 | 内容 | 搬不搬 |
| --- | --- | --- |
| `~/.mnemon/runtime/` | `memories.json` + `MEMORY.md` + `USER.md` = **记忆本体** | ✅ 必须 |
| `~/.dsh/sessions/` | 每个会话一份 `.zstd` jsonl（本机 228 个 / 81 MB）。**已是 zstd，压不动** | ❌ 默认不导出（`-KeepSessions` 可带） |
| `~/.dsh/storages/session_projcache/` | 会话的投影缓存（本机 37 MB），会话在时 DSH 自动重建 | ❌ 默认不导出 |
| `~/.dsh/attachments/` | 会话里的图片、附件（本机 180 MB） | ❌ 默认跳过（publish 会加 `-SkipAttachments`） |
| `~/.dsh/storages/` | workspace 注册表、cost-meter 账本 | ✅ 必须 |
| `~/.dsh/skills/` | 装到 home 的技能包（`ppt-master`、`archify` 默认排除，见包内 `EXCLUDED.md`） | ✅ 必须 |
| `~/.dsh/task-board/` | 任务板账本 | ✅ 建议 |
| `~/.dsh/.credentials.yaml` | API 密钥（**明文，仅靠文件 ACL 保护**） | ✅ 建议 |
| `~/.dsh/profiles/*/{package.json,pnpm-lock.yaml,cordis.patch.yml}` | 插件清单与插件配置 | ✅ 必须 |
| `~/.dsh/profiles/*/node_modules/` | 装出来的依赖 | ❌ 重装（且会踩 pnpm store 的坑） |
| `~/.dsh/cache`、`browser-sessions` | 缓存、浏览器登录态 | ❌ 与本机绑定，拷了也没用 |
| `~/AppData/Roaming/DSH Desktop/*` | Electron 窗口位置、主题缓存 | ❌ 可丢，重开一次就有 |

---

## 1. 新机：先装，再喂

1. 装**同版本**的 DSH Desktop（本机是 `2.0.17`，安装包 `D:\DSH\DSH-Desktop-2.0.17-x64-Setup.exe`）。
   装到 D 盘 —— 这是你的硬规则，也顺手避开 C 盘空间。
2. 启动一次、登录 DeepSeek 账号、**然后退出**。这一步只是让 DSH 生成 `~/.dsh` 和 profile 骨架。
3. 确认 `DSH_HOME` 没被改过（默认 `%USERPROFILE%\.dsh`）。如果你以前设过环境变量，新机要设成一样。

> 不要在新机上先聊一堆项目再恢复 —— 恢复会覆盖同名文件，你的新对话和新记忆会打架。要么先恢复再开工，要么恢复前把新机 `~/.dsh` 备份走。

## 2. 迁移包归位

```powershell
cd D:\path\to\dsh-migration
pwsh -File .\restore-dsh.ps1 -Kit 'D:\dsh-migration\dsh-20261018-1014' -WhatIfOnly
pwsh -File .\restore-dsh.ps1 -Kit 'D:\dsh-migration\dsh-20261018-1014' -Force
```

跑完检查三行（脚本会打印）：`runtime\MEMORY.md OK` / `runtime\USER.md OK` / `runtime\memories.json OK`。
**这三行是"它还记得你"的全部依据**，缺任何一行都别往下走。

- `-RestorePluginSources`：把包里的自研插件源码放回 manifest 记录的原路径（已存在则跳过，不覆盖）。
- 目标目录已有历史会话时不加 `-Force` 会直接拒绝 —— 这是保护，不是故障。

## 3. 项目代码：路径必须一模一样

`manifest.json` 里 `workspaces` 是旧机的 workspace 注册表。本机现有 4 个：

| workspace | 会话数 |
| --- | --- |
| `D:\Users\林先语\Documents\deepseek-harness\default-workspace` | 32 |
| `D:\WebGIS\web三维开发\智慧地铁项目` | 5 |
| `F:\AE 开发\实验三` | 2 |
| `F:\遥感数字图像处理` | 3 |

**为什么路径不能变**：会话目录名是按工作区绝对路径编码的（`--D-WebGIS-web~4E09~7EF4...--`），
workspace 注册表、cost-meter 账本、插件 link 目标里存的也全是绝对路径。
用户名或盘符一变，DSH 会把同一份代码当成另一个工作区 —— 历史会话挂不上、新会话落到新目录。

保路径的三个办法，按优先级：
1. 新机沿用同一个 Windows 用户名（`林先语`）和同样的盘符 —— 最省事；
2. 用 `subst` 把老盘符映射回去（`subst F: D:\old-F`），代码放新位置但路径不变；
3. 改 `manifest.json` 里的路径 → 不推荐，sessions 目录名也要跟着改。

代码本身用 git / 网盘 / 移动硬盘搬都行，**但落到磁盘上的位置必须是上表那几个路径**。

## 4. 重装插件（唯一不能靠拷的一步）

`node_modules` 故意没打包：一来体积大，二来跨机的 pnpm store 不可能对得上。

```powershell
$env:PNPM_STORE_DIR = 'D:\.pnpm-store'        # 你的规则：一切落 D 盘，别写进 C 盘
cd $env:DSH_HOME\profiles\desktop
pnpm install
```

- 9 个市场插件（`dsh-cost-meter`、`dsh-context`、`dsh-mnemon`、`@linxin666/dsh-web-all` …）从 lockfile 重装，版本会被钉住；
- 8 个 `link:` 自研插件（agnes-core/image/video、mcp-anysearch、bridge-browser、archify、context7、academic-research-skills）必须先有源码目录再 install，否则 link 断链、插件全灭；
- **踩过的坑**：DSH 自带 pnpm 与项目里 pnpm 的 store 版本不一致时会判定 node_modules 需重建；
  绝不要为了绕提示去设 `CI=true` 或 `confirm-modules-purge=false`（会真删重装）。真遇到就把 `verifyDepsBeforeRun: false` 写进 `pnpm-workspace.yaml`。
- 最保险的对照物：旧机 `profiles\desktop\package.json` 的 `dependencies` 列表 —— 新机装完逐个核一遍，少一个就是一个功能消失。

## 5. 改掉机器相关的绝对路径

`profiles\desktop\cordis.patch.yml` 里有两处写死了旧机路径，新机必须改成新机实际路径：

```yaml
pwshPath: 'C:\Users\林先语\AppData\Local\Microsoft\WindowsApps\pwsh.exe'
command:  'C:\Users\林先语\.local\bin\windows-mcp.exe'
```

顺带核一下别的写死的路径：`bridge-browser` 的 Chrome 路径、`modlens`、Blender / mocap 相关脚本（`D:\mocap\retarget_aist.py`、`D:\Blender\assets\trainAndChisa.blend`）—— 这些是项目资产，随项目一起搬，路径变了两边都要改。

## 6. 验收清单（一条条打勾）

- [ ] 新开一个会话，它主动提到你的 D 盘安装规则 / 成本纪律 —— 说明 `USER.md` + `MEMORY.md` 活了
- [ ] 记忆能召回：问「上次那个 X 最后怎么解决的」，它答得出 —— **靠的是 MEMORY.md，不是会话记录**
- [ ] 会话列表是空的 —— 这是预期，会话不回迁（包袱默认不带）
- [ ] `cost-meter` 账本没清零（`~/.dsh/storages/cost-meter/ledger.json` 有历史日期）
- [ ] 任务板卡片都在
- [ ] 插件齐全：浏览器桥、Agnes 出图/出视频、anysearch、context7、archify、成本计
- [ ] MCP 工具能起来（`windows`、`anysearch`）
- [ ] 技能列表和旧机一致（`~/.dsh/skills` + 插件自带技能）
- [ ] 宠物/皮肤还在（`~/.dsh/pet.json`、`skin-center-active.json`）
- [ ] 一个真实项目跑起来：`Translation` 前后端能起、`/realtime` 轨迹能跑

## 7. 以后别再手工搬

- 每周收工跑一次 `export-dsh.ps1`，`D:\dsh-migration` 只留最近 2～3 个包（一个 ≈ 290 MB）；
- 包本身是普通文件树，可以直接丢网盘/移动硬盘；`manifest.json` 里记了机器名、DSH 版本、workspace 清单和 link 插件原路径，换机时省掉所有回忆；
- 如果只想搬"记忆"、不想搬历史：Mnemon 自带 Pack 导出/导入的概念（`full` / `runtime` / `documents` / `memory-spaces` 四种粒度）。设置页里有对应入口就用它，没有就直接整目录拷 `~/.mnemon` —— 那本来就是记忆的本体；
- 换机前先在旧机上跑一次 `-WhatIfOnly`，它会把你「以为搬了其实没搬」的东西（比如 F 盘的两个 workspace）直接列出来。

## 8. 已挂上自动化：每周推 GitHub

`publish-dsh.ps1` 把上面第 0～2 步接成一条流水线，由任务板卡片「DSH 配置周备份：打包并推送 GitHub」
（cron `0 22 * * 0`，每周日 22:00）驱动：

1. `export-dsh.ps1 -ExcludeSecrets -SkipAttachments` 生成迁移包（**排除** `.credentials.yaml` / `.env`，因为目标仓库是 public）；
2. `tar -a` 压成 `dsh-YYYYMMDD.zip`（约 69 MB，卡在 GitHub 单文件 100 MB 上限以内）；
3. 重建一个单提交历史，保留最近 2 份包 + `LATEST.json` + `README.md`；
4. `git push --force` 到 `Dawnivers/DSH_config` 的 `main`（单提交 = 仓库体积恒定，不会一周涨 70 MB）；
5. 本地留 `publish-state.json` 作为证据（`result=pushed`、`sizeMB`、`sha256`、耗时）。

手工跑法：

```powershell
pwsh -File .\publish-dsh.ps1 -DryRun    # 只打包+组装，不推
pwsh -File .\publish-dsh.ps1            # 真推
```

- **凭据**：`%USERPROFILE%\.dsh-config-publish\token`，一行 Fine-grained PAT（Contents: Read and write，仅限该仓库）。文件所在目录 ACL 已限制为仅当前用户可读；脚本只读取，从不回显。
- **网络**：GitHub 直连会 `Connection was reset`，脚本自动探测本机代理端口（7897/7890/10809…）并给 git 配上 `http.proxy`。
- **两个硬闸**：包里出现 `.credentials.yaml`/`.env` 直接拒绝发布；zip ≥ 100 MiB 拒绝推送（GitHub 单文件硬顶，到 95 MiB 起报剩余量）。
- **密钥体检（`scan-secrets.py`）**：对话里贴过的密钥会原样进 transcript；带 `-KeepSessions` 时会一并进包。
  所以推送前会扫描包内所有文本文件（以及存在时的 `.zstd` 会话），
  对每个候选 token 做存活检测（GitHub 打 `/user`）。只要有**还活着**的密钥就中止发布；已撤销的死串只警告。
- **包内脱敏（`redact-secrets.py`）**：体检之前先把包里所有 `github_pat_*`/`ghp_*`/`sk-*`/`AIza*` 替换成 `<REDACTED>`
  （文本文件就地改；`.zstd` 会话多帧解压→替换→重压）。**只改包里的副本，本机 `~/.dsh` 一个字节不动** —— 所以恢复后需要重新填 API Key。
  2026-10-18 实测：8 个文件、90 处命中，处理后体检 0 命中。
- 这就是为什么**永远不要把 PAT 贴进对话**，也**不要把 API Key 写进插件的 `cordis.patch.yml`**：两者都会进入 transcript，进而进入备份与仓库。
  密钥应该放环境变量（如 `AGNES_API_KEY`、`DEEPSEEK_API_KEY`），代码里只留 `!!js process.env.XXX`。
- **注意**：远程包不含附件（180 MB）也不含 API 密钥 —— 真正的完整备份仍要以本地 `D:\dsh-migration\dsh-<时间戳>\` 为准。
