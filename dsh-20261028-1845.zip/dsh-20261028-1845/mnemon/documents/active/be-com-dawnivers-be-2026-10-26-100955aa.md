---
id: "100955aa-9fe1-4aca-a47b-5251d6d88287"
title: "BE 包名定稿 com.dawnivers.be：重命名决策、三处错位修复与「编译绿/启动绿」首里程碑（2026-10-26 实测）"
description: "openlayers服务平台开发 的 BE 子工程从 com.example.api 定稿为 com.dawnivers.be 的完整记录：改名理由与唯一免费窗口、pom 坐标改动、目录/包名/主类三处错位的编译错误与修复、application.properties 内容与密码不入库策略、首个 git 提交范围、启动成功≠数据源可用的实测证据、下一步 HelloController→ping-db 顺序。"
status: "active"
created_at: "2026-10-26T05:48:54.360Z"
updated_at: "2026-10-26T05:48:54.360Z"
content_hash: "3737de5105aedc6c1a3ff9483764d86478f6eeb5c6dfc6ecb474203f378288fb"
source_paths:
  - "BE/pom.xml"
  - "BE/.gitignore"
  - "BE/src/main/java/com/dawnivers/be/BeApplication.java"
  - "BE/src/main/resources/application.properties"
  - "FE/src/main.js"
session_ids:
  - "34b14f41-c6a6-465b-b16d-a31e589a1e66"
memory_body_ids:
  []
---

# BE 包名定稿 `com.dawnivers.be` 与首个可启动里程碑（2026-10-26 实测）

工作目录 `D:\WebGIS\web二维开发\openlayers服务平台开发`，子工程 `BE\`（独立 git 仓库）。Maven `D:\maven\bin\mvn.cmd`，本地仓库 `D:\m2repo`，JDK 17，Spring Boot 3.5.16。
本文是该轮的**状态交接**：把「脚手架 → 可编译 → 可启动」这一段收口。前置知识见 [BE(api) Spring Boot 3.5.16 后端脚手架](7eab7ab9-b0b8-4f01-a2a7-09444c6ffdea)（Maven 目录契约、Initializr 版本现实）与 [Spring Boot 入口类与首次启动验收](753c5a7a-347a-4270-ab07-3c64460c8fcf)（入口类职责、日志判读、按端口杀进程）。**注意：那两篇里写的 `com.example.api` / `artifactId=api` 是改名前的状态，以本文为准。**

## 1. 命名定稿（唯一一次「免费改名窗口」）

改名时的工程里**还没有任何 `.java` 文件**，只有 pom + 空目录，所以成本仅「移 3 个文件夹 + 改 pom 两行」。一旦有多个 java 文件，成本膨胀为每个文件的 `package` 声明 + 全部 `import` + 目录搬迁 + git 历史路径。这就是「唯一免费窗口」的实际含义。

| 项 | 改前 | 定稿 | 理由 |
|---|---|---|---|
| `groupId` | `com.example` | `com.dawnivers` | `example.com` 是 RFC 2606 保留给文档示例的域名，全世界模板都用 `com.example`，简历/仓库里一眼看出「模板没改」 |
| `artifactId` | `api` | `be` | 目录本来叫 `BE`，两个名字指同一物迟早出错 |
| 包名 | `com.example.api` | `com.dawnivers.be` | 跟随上两项；Initializr 规则即 `package = groupId + "." + artifactId` |
| 主类 | `ApiApplication` | `BeApplication` | 跟随 artifactId；文件必须同名 |

补充事实：`com.dawnivers` 无需真持有该域名——Java 包名只要求反向域名**格式**，不校验所有权。包名硬规则：全小写、段内无中划线/空格、不以数字开头、不用 Java 关键字、不以 `java`/`javax` 开头、正式项目不用 `example`/`demo`/`test`。

## 2. 定稿后的实际结构（检查证据，非预估）

```
BE\
├── .gitignore            57 B / 5 行：target/  *.iml  .idea/  application-local.properties  *.log
├── pom.xml               1575 B
└── src\main\
    ├── java\com\dawnivers\be\
    │   ├── BeApplication.java    753 B
    │   └── controller\           （空目录；git 不跟踪空目录）
    └── resources\                （补齐后放 application.properties）
```

pom 关键坐标：parent 3.5.16、`groupId=com.dawnivers`、`artifactId=be`、`version=0.0.1-SNAPSHOT`、`java.version=17`；依赖 `spring-boot-starter-web` + `spring-boot-starter-jdbc` + `postgresql`；插件 `spring-boot-maven-plugin`。

## 3. 三处错位与编译失败（真实报错 → 修法）

改名时最典型的半途状态：目录改了、类名改了、`package` 没改。`mvn compile` 输出（控制台 GBK 乱码，实义如下）：

```
[ERROR] ApiApplication.java:[8,8] 类 BeApplication 是公共的, 应在名为 BeApplication.java 的文件中声明
[INFO] BUILD FAILURE
```

| # | 错位 | 症状 | 修法 |
|---|---|---|---|
| 1 | 文件名 `ApiApplication.java` ↔ `public class BeApplication` | 上述编译错误，`mvn compile` 直接 FAILURE | 文件重命名或类名改回，二者取一；定稿选重命名 |
| 2 | `package com.example.be;` ↔ 目录 `com/dawnivers/be` | 单文件时可能蒙过，一旦有第二个类 `import` 立刻「程序包不存在」 | 改为 `package com.dawnivers.be;` |
| 3 | `src/main/resources` 为空 | 启动即 `Failed to configure a DataSource: 'url' attribute is not specified` | 先补 `application.properties` 再启动 |

修复后验收命令与结果：`mvn -B compile` → `Compiling 1 source file with javac [debug parameters release 17]` + `BUILD SUCCESS`（首次真正编译通过）。

**诊断工具**（一条命令查全部「声明 vs 目录」是否对齐，比逐个文件看快）：

```powershell
cd D:\WebGIS\web二维开发\openlayers服务平台开发\BE
Get-ChildItem src\main\java -Recurse -Filter *.java | ForEach-Object {
  $pkg = (Select-String -Path $_.FullName -Pattern '^package (.+);' | Select-Object -First 1).Matches.Groups[1].Value
  $rel = $_.DirectoryName.Replace((Resolve-Path src\main\java).Path + '\','').Replace('\','.')
  "{0}  声明={1}  目录={2}  {3}" -f $_.Name, $pkg, $rel, $(if ($pkg -eq $rel) {'OK'} else {'MISMATCH'})
}
```

另外两条清洁建议：删掉主类文件里注释掉的旧模板（留着会被 IDE 全局替换带偏）；`.gitignore` 可补 `.vscode/` 与 `*.class`。

## 4. `application.properties`（`src\main\resources\`）

```properties
server.port=8094
spring.datasource.url=jdbc:postgresql://localhost:5432/Spatial
spring.datasource.username=postgres
spring.datasource.password=<从 etl\.env 的 PGPASSWORD 取，不写进本文>
spring.datasource.driver-class-name=org.postgresql.Driver
```

| 段 | 写错的症状 |
|---|---|
| `server.port=8094` | 默认 8080，**会与 GeoServer 撞端口**，起不来 |
| `url/username/password` | 启动能过，第一次查库才报 `password authentication failed` |
| `driver-class-name` | 一般可省（Boot 自己推断），写上是为了报错更指向明确 |

**properties 格式的阴坑**：值里的 `#` 会被当成注释开头而截断，`\` 是转义符。该密码已实测为 6 位纯字母数字、不含 `#` `=` `:` `\` 空格 `!` `"` `'` `$`、无非 ASCII 字符，故可直接粘贴。

**密码不入库**：`.gitignore` 已含 `application-local.properties`。策略是本次**先不提交 `src/main/resources`**；等 `/api/ping-db` 通了，把密码挪到 `application-local.properties`（本地覆盖），仓库里的 `application.properties` 留占位符。

## 5. 第一次提交的范围（刻意排除 resources）

```powershell
git add pom.xml .gitignore src/main/java
git commit -m "00 后端工程初始化（Spring Boot 3.5.16 / 8094 / 包 com.dawnivers.be）"
```

理由：这是第一个「能编译能启动」的里程碑，不该等几十个文件改完再回头想提交什么；而带上明文密码的 properties 必须留到第 4 节的收拾步骤之后。此前 `git status` 全是 `??`、`git log` 报 `master does not have any commits yet`。

## 6. 启动验收与一个必须记住的反直觉

期望日志（顺序固定）：`Tomcat initialized with port 8094 (http)` → `Tomcat started on port 8094 (http) with context path '/'` → `Started BeApplication in ~1.2 seconds`。
另开窗口验证：`Get-NetTCPConnection -LocalPort 8094 -State Listen`；`curl.exe -i http://localhost:8094/` 返回 404 + Whitelabel Error Page **是正常的**——Tomcat 活着，只是还没有任何路由。

> **启动成功 ≠ 数据源配对了。** 实测：故意写错密码启动，照样 `Started ... in 1.248 seconds`，因为 HikariCP 懒连接，第一次真正查库才建池。所以验证数据源必须靠 `/api/ping-db`，不能看启动日志。

## 7. 下一步顺序（为什么 hello 在 ping-db 之前）

`HelloController`（`/api/hello`，与数据库无关）→ 拿到 Web 层基准 → 再做 `/api/ping-db`。这样一旦出事，能立刻区分「Web 层问题」与「数据层问题」，而不是两个变量一起动。
