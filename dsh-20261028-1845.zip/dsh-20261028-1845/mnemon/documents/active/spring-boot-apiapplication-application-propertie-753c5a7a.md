---
id: "753c5a7a-347a-4270-ab07-3c64460c8fcf"
title: "Spring Boot 入口类与首次启动验收：ApiApplication + application.properties 顺序、日志判读与端口清理（实测）"
description: "openlayers服务平台开发 BE 子工程写 ApiApplication 前的顺序纠正与启动验收手册：starter-jdbc 导致必须先写数据源配置、入口类四段职责与删除反证、与 FE main.js 的角色对照、入口类复用边界、编译/启动/另开窗口验证/按端口杀残留进程的完整命令、启动日志五行判读表、六类失败对照。"
status: "active"
created_at: "2026-10-26T05:22:04.390Z"
updated_at: "2026-10-26T05:22:04.390Z"
content_hash: "2e5db640f4b3afd483ccf9b26c30701ac17b431b8fd923d93f10e199ca333c6e"
source_paths:
  - "BE/src/main/java/com/example/api/ApiApplication.java"
  - "BE/src/main/resources/application.properties"
  - "BE/pom.xml"
  - "FE/src/main.js"
session_ids:
  - "119514f1-c675-47fb-8776-3baf2edd70d5"
memory_body_ids:
  []
---

# Spring Boot 首次启动验收（BE`ApiApplication` 阶段，2026-10-26 实测）

适用：`D:\WebGIS\web二维开发\openlayers服务平台开发\BE`，pom 已含 `spring-boot-starter-web` / `-jdbc` / `postgresql`，parent 3.5.16，JDK 17，Maven 在 `D:\maven\bin\mvn.cmd`，本地仓库 `D:\m2repo`（走 aliyun-public 镜像）。
本文接续 `7eab7ab9-b0b8-4f01-a2a7-09444c6ffdea`（Maven 目录契约与 Initializr 版本现实），从「开始写 `ApiApplication.java`」往下走。

## 1. 结论先行：顺序必须改成「主类 → 配置 → 启动」

原先设想的「先空跑起来再加数据库」在本 pom 下**必然失败**。用同款 pom + 4 行主类 + 不放 `application.properties` 实跑，10.6 s 后 `BUILD FAILURE`：

```
Failed to configure a DataSource: 'url' attribute is not specified and no embedded datasource could be configured.
Reason: Failed to determine a suitable driver class
```

原因：`spring-boot-starter-jdbc` 一发现「classpath 有 JDBC、却没有 URL」就拒绝启动。
误导点：报错关键词是 `DataSource`，人容易去查 PostgreSQL 而真因只是缺配置文件。

## 2. 入口类：四段各自的职责（删除反证法）

```java
package com.example.api;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiApplication {
    public static void main(String[] args) {
        SpringApplication.run(ApiApplication.class, args);
    }
}
```

| 元素 | 职责 | 删/改错的症状 |
|---|---|---|
| `package` | 与 `com\example\api\` 目录一一对应；同时是 `@ComponentScan` 起点 | 编译报「类 X 是公共的, 应在名为 X.java 的文件中声明」或「程序包不存在」；包名改错则服务能起但接口全 404 |
| `@SpringBootApplication` | `@Configuration` + `@EnableAutoConfiguration` + `@ComponentScan` 合成 | 能编译能进 `run()`，但无 Tomcat，进程自行退出 |
| `main` | 唯一入口 | `mvn spring-boot:run` 报 `No main manifest` |
| `run(X.class, args)` | 建 IoC 容器 + 起内嵌 Tomcat；`args` 可临时覆盖配置（如 `--server.port=`） | — |

- 两个 import 来自传递依赖：`SpringApplication` 在 `spring-boot-3.5.16.jar`，`SpringBootApplication` 在 `spring-boot-autoconfigure-3.5.16.jar`；pom 里只写 starter，不写类名。30 秒自查：`mvn -B dependency:tree` + `jar tf <jar> | Select-String 类名`，或 IDE 中 Ctrl+单击跳进 jar。
- 主类必须放在 `controller` 的**上一层**（`com.example.api`），不是放进 `controller` 包里。

## 3. 与前端入口是同一角色

`FE/src/main.js`（14 行）与 `ApiApplication.java` 结构同构：声明根（`App.vue` ↔ 注解所在类）、交给框架（`createApp(App)` ↔ `SpringApplication.run(...)`）、装配（`app.use(...)` ↔ 自动装配）、接管运行环境（`mount('#app')` ↔ 起 Tomcat 绑端口）、全局配置（`import './style.css'` ↔ `application.properties`）。两边都是「一行一个动作、零业务逻辑」。

`run(ApiApplication.class, args)` 看着像「调用自己」，实为把**类的元信息**交给框架反射读取（注解、包位置、`@Bean`），故必须传 `Class` 而非实例；`main` 为 static，启动时还没有对象。等价于前端把根组件本身交给 `createApp`。

## 4. 复用边界（这是用户当时的疑问点）

- **同项目**：只能一个。出现两个带 `@SpringBootApplication` 的类时，`mvn package` 报 `Unable to find a single main class from the following candidates [...]` —— 看到这句话就是有两个入口类。
- **跨项目**：复用的是「形状」，只改三处：包名、类名（文件名同步）、`run(...)` 里的类引用。这就是生成器产出的该文件永远一样的原因——它没有设计空间。
- **硬规矩**：业务代码（`@Bean`、`CommandLineRunner`、初始化 SQL）不进主类；要加 Bean 就建 `config` 包，主类保持 4 行。
- 何时才需要第二个入口：多模块/微服务各自可独立启动，或同一代码要跑「Web 服务」与「批量导入」两种形态。本项目单体 + 独立 FE，全生命周期只需这一个。

## 5. 启动前必须写的配置

`BE/src/main/resources/application.properties`：

```properties
server.port=8094
spring.datasource.url=jdbc:postgresql://localhost:5432/Spatial
spring.datasource.username=postgres
spring.datasource.password=<从 etl/.env 的 PGPASSWORD 取，不写进文档与 git>
spring.datasource.driver-class-name=org.postgresql.Driver
```

**反直觉实测**：把密码故意写成错误值时仍然启动成功（`Tomcat started on port 18094` / `Started ApiApplication in 1.248 seconds`）。HikariCP 懒建池，首次真正取连接才连库。故「启动成功 ≠ 数据库配对了」，只能靠后续 `/api/ping-db` 查 `select count(*) from admin_area`（期望 13）验证。

## 6. 验收流程（每步命令）

```powershell
cd D:\WebGIS\web二维开发\openlayers服务平台开发\BE
& 'D:\maven\bin\mvn.cmd' -B compile                                   # 应出现 Compiling 1 source file
Test-Path target\classes\com\example\api\ApiApplication.class          # True
& 'D:\maven\bin\mvn.cmd' -B spring-boot:run                            # 前台阻塞，首次会下插件依赖
```

另开一个 PowerShell 窗口（原窗口已被占住）：

```powershell
Get-NetTCPConnection -LocalPort 8094 -State Listen
curl.exe -i http://localhost:8094/          # 404 + Whitelabel 页是正常结果：Tomcat 活着、暂无路由
```

`curl.exe` 必须带 `.exe`（PowerShell 的 `curl` 是 `Invoke-WebRequest` 别名）。

停止后**必须确认端口释放**：

```powershell
Get-NetTCPConnection -LocalPort 8094 -State Listen -ErrorAction SilentlyContinue
Get-NetTCPConnection -LocalPort 8094 -State Listen | ForEach-Object { Stop-Process -Id $_.OwningProcess -Force }
```

实测踩过：杀掉 maven 进程后子 java 仍占端口，必须**按端口找使用者**再杀，不能只按进程名。

## 7. 启动日志五行判读

| 日志 | 证明 | 缺失说明 |
|---|---|---|
| `Starting ApiApplication using Java 17.x with PID` | 主类找到、JVM 版本对 | 主类位置/包名错 |
| `No active profile set, falling back to default` | 未配 profile | 正常，忽略 |
| `Tomcat initialized with port 8094 (http)` | `server.port` 生效 | properties 未被加载（文件名/位置错） |
| `Tomcat started on port 8094` | 端口真正绑定 | 端口被占会看到 `Port ... was already in use` |
| `Started ApiApplication in X seconds` | **启动完成（唯一成功标志）** | 中途抛异常，看末尾堆栈 |

## 8. 失败对照

| 报错 | 真因 | 修法 |
|---|---|---|
| `Failed to configure a DataSource: 'url' attribute is not specified` | 有 starter-jdbc 但无数据源配置 | 先写 `application.properties` |
| `Port 8094 was already in use` | 上次的 java 未退 | 按端口杀（见 §6） |
| `Could not find or load main class com.example.api.ApiApplication` | 文件不在 `src\main\java\com\example\api\` | 挪文件 |
| `程序包 org.springframework.boot 不存在` | 依赖未下全 | `mvn -B dependency:resolve` |
| `类 ApiApplication 是公共的, 应在名为 ApiApplication.java 的文件中声明` | 文件名与类名不一致 | 改文件名 |
| 服务正常启动但全部接口 404 | controller 在扫描起点之外 | 移到 `com.example.api` 子包内 |

## 9. 完成判据

- `mvn -B compile` 出现 `Compiling 1 source file` 且 `BUILD SUCCESS`；
- `target\classes\com\example\api\ApiApplication.class` 存在；
- 日志同时有 `Tomcat started on port 8094` 与 `Started ApiApplication in ...`；
- Ctrl+C 后 `Get-NetTCPConnection -LocalPort 8094 -State Listen` 为空。

## 10. 后续与关联

下一步是 `HelloController`（`@RestController` + `@RequestMapping("/api")` + `@GetMapping("/hello")`，`curl.exe http://localhost:8094/api/hello` 验证），再 `/api/ping-db`，最后 `/api/build` 返回 `FeatureCollection`、13 个 features。约定：从此不再给成品代码，只讲注解分工与验收方式。

- 脚手架与 Maven 目录契约、Initializr 只发 4.x 的版本冲突：`7eab7ab9-b0b8-4f01-a2a7-09444c6ffdea`
- 阿里云镜像与 `D:\m2repo` 预热证据（989 文件/21.5 MB → 本次 resolve 后 1728 文件/62.0 MB）：`e1de590d-c337-454d-adf1-9639c5044380`
- 项目总体设计、三服务边界与数据模型：`266aea70-7a25-4d94-8359-39555b8b651f`
