---
id: "b023afe4-1280-4350-ac26-b45bfed9813a"
title: "会话剪枝工具 prune-sessions.mjs 与 40 MB 未提炼悬空区（2026-10-28 演练实测）"
description: "提炼完成后自动清理会话的落地设计与证据：DSH 会话目录/投影缓存的两层映射、prune-sessions.mjs 的四条剪枝判据与回收站式删除（manifest+sha256）、演练结果 53 个会话 40.16 MB、当前会话被\"摘要后改动\"精确挡住的验证，以及 232 个会话中 178 个（40.6 MB）从未进过摘要的缺口与\"先补提炼再剪\"的顺序建议。"
status: "active"
created_at: "2026-10-28T09:40:47.054Z"
updated_at: "2026-10-28T09:40:47.054Z"
content_hash: "4e35bde7bb414dde50b81303f0161fbfdbdb94a489231cbe8cffffad4a04a8c4"
source_paths:
  - "dsh-migration/prune-sessions.mjs"
  - "dsh-migration/distill-dsh.mjs"
  - "dsh-migration/publish-dsh.ps1"
session_ids:
  - "a6611f1c-e423-49aa-ab90-7e97346ae331"
memory_body_ids:
  []
---

# 会话剪枝：把"提炼完的原料"安全搬走的工具与实测

日期：2026-10-28（Windows，DSH Desktop，工作区 `D:\Users\林先语\Documents\deepseek-harness\default-workspace`）
起因：用户问「你能将提炼完成的会话自动删除吗」——即把 distill 流水线闭环到清理环节。

关联文档（本文只写**新增的剪枝环节**，不复述它们已有内容）：
- `5be07c0a-bdbc-4239-ac2e-60ebdd629807` — `distill-dsh.mjs` 会话提炼流水线（多帧 zstd、来源过滤、54 个真对话、摘要 140 KB 硬顶）
- `4f697022-3973-415e-83e6-61435101a435` — 备份包瘦身（默认不导 sessions，97.07 → 10.94 MiB）
- `40db82e5-4bab-4e2a-9a6d-6b98e729b8f5` — 方案 C 实测：sessions 81 MiB 压缩率 100%

## 0. 前提：删会话前先确认不会留悬空索引

动手前查过 DSH 自己的索引文件：

| 路径 | 内容 |
|---|---|
| `~/.dsh/dsh-session-archive/archive-ledger.json` | `{"version":1,"entries":{}}` — 空 |
| `~/.dsh/dsh-session-archive/state.json` | 只有 `nextCheckAt`，无会话清单 |
| 是否 sqlite 索引 | 无 |

结论：没有集中式会话表需要同步维护，剪掉目录本身即可，不会留下悬空索引。

## 1. 会话在磁盘上的两层结构（剪枝的落点）

```
~/.dsh/sessions/<编码后的工作区名>/<session-id>/session.v4.jsonl.zstd
~/.dsh/storages/session_projcache/sessions/<session-id>.json
```

- `<编码后的工作区名>` 形如 `--D-WebGIS-web~4E09~7EF4~5F00~53D1-~6672...--`：非 ASCII 被转成 `~XXXX` 十六进制，看起来像乱码，属正常。
- **映射关系实测**：projcache 文件名 = 会话目录名原样（**不剥离 `session-` 前缀**）。按"剥前缀"假设只有 3/5 命中；按原名匹配 **232/232 全命中**。这是剪枝必须同时删两处、且不会误删的依据。
- 只有 `archive-ledger.json` / `state.json` 的 `dsh-session-archive` 与 `session_projcache` 根目录文件都不参与，实际有效数据是 232 个会话目录 ↔ 232 个 projcache 文件。

## 2. `dsh-migration/prune-sessions.mjs`

**默认演练，不加 `--apply` 一个文件都不动。** 真跑也是搬进回收站（保留 `manifest.json`，含每个会话的 sha256、原路径、最后写入时间），恢复 = 把目录搬回去；真删要另跑 `--purge --older-than 30`。

四条判据，缺一不可：

| 条件 | 作用 |
|---|---|
| 会话出现在指定 `distill-*.md` 摘要里 | 只处理**真的提炼过**的，不按时间一刀切 |
| 最后写入**早于摘要生成时间** | 摘要之后又动过 ⇒ 内容未进摘要，不能剪 |
| 早于 `--days` 天（默认 0，不过滤） | 可选保险 |
| 最近 30 分钟未动 | 防止把正在用的会话搬走 |

## 3. 演练结果（2026-10-28 17:25 的摘要，`distill-20261028.md` 覆盖 54 会话）

- 可搬 **53 个 / 40.16 MB**（摘要覆盖 54，减掉 1 个摘要后被改动的）。
- 跳过统计：`摘要未覆盖 178、摘要后被改动 1、未满 0 天 0、最近动过 0`。
- **当前会话被精确挡住**：`session-b77290e1-…` 最后写入 17:39 > 摘要生成 17:25，命中"摘要后被改动"。这条验证了判据二不是摆设。

## 4. 真正的发现：40 MB 从未进过摘要的悬空区

| | 会话数 | 体积 |
|---|---|---|
| 全部 | 232 | **82.1 MB** |
| 摘要覆盖过 | 54 | 41.5 MB |
| **摘要没覆盖** | **178** | **40.6 MB** |

未覆盖的**不全是子代理碎片**，里面躺着流程建立之前的真会话：

```
4.09 MB  2026-10-17  session-2594f463…
2.86 MB  2026-10-15  session-1aa4de98…
2.69 MB  2026-10-20  session-36cf3f5f…
1.83 MB  2026-10-06  session-69715489…
1.50 MB  2026-10-21  session-3666cfa3…
```

尴尬之处：这批会话**既不进备份包（sessions 已排除），也不在任何摘要里**——哪天清理就是没榨过直接扔掉的原料。

## 5. 由此定下的顺序：先补提炼，再剪

1. **历史补提炼**：对老会话按时间窗口多跑几次 `distill-dsh.mjs`（一次 7 天，避开 140 KB 摘要硬顶截断）→ 人读 → 确认 → 写进 MEMORY.md。
2. **然后一起剪**：补完的摘要覆盖全部 232 个会话后，`prune-sessions.mjs --apply` 一次搬走约 82 MB。

直接剪掉那 40 MB 等于判定「10-06 到 10-21 那段没价值」——不可接受，早期阶段踩的坑大概率在里面。

## 6. 自动化的两个接法（待用户选）

- **A. 推送成功后自动搬**：`publish-dsh.ps1` 加 `-PruneSessions`，每周日备份成功后自动搬走"摘要覆盖且摘要后未改动"的会话。有 30 天回收站兜底。
- **B. 只搬 7 天以前**：更保守，`--days 7`，保证最近一周对话永远在本地。

倾向 **A + `--days 3`**：既有回收站兜底，又不会搬走这两天手头正在翻的会话。

**当前状态：工具已写好并只做过演练；未执行任何删除，`-PruneSessions` 开关未挂上，等用户在前述三个选项（补提炼 / 直接剪 / 挂开关）中拍板。**

## 7. 源码路径

- `dsh-migration/prune-sessions.mjs`（新建，约 5 KB，Node 24，无依赖）
- `dsh-migration/distill-dsh.mjs`（产出摘要，剪枝的输入）
- `dsh-migration/publish-dsh.ps1`（备份 & 未来的 `-PruneSessions` 挂点）
- 摘要与回收站：`D:\dsh-migration\distill\distill-*.md`
