---
id: "fcf2dd32-10e1-4183-a8b3-334b4ee039bd"
title: "MyBatis 映射到 record DTO 时 List 字段的 TypeHandler 方案：PoiDto argument type mismatch 排查实录"
description: "MyBatis 把 jsonb_path_query_array(...)::text 的 JSON 文本当 String 传给 record 构造器导致 PoiDto argument type mismatch 的根因、StringListTypeHandler+resultMap 修法与验证清单。"
status: "active"
created_at: "2026-10-28T01:26:17.850Z"
updated_at: "2026-10-28T01:26:17.850Z"
content_hash: "a19d63fa134473b5eed39b78f284b883b1f0aee46de8dbab096377d482adc115"
source_paths:
  - "BE/src/main/java/com/dawnivers/be/config/StringListTypeHandler.java"
  - "BE/src/main/resources/mapper/PoiMapper.xml"
  - "BE/src/main/java/com/dawnivers/be/dto/PoiDto.java"
  - "BE/src/main/java/com/dawnivers/be/service/PoiService.java"
  - "BE/src/main/java/com/dawnivers/be/controller/PoiController.java"
session_ids:
  - "5141c1cf-3dbf-429c-980c-933f9bcb1a08"
memory_body_ids:
  []
---

# MyBatis 映射到 record DTO 时 List 字段的 TypeHandler 方案

来源：D 阶段 `/api/poi/{gid}` 接口联调，`com.dawnivers.be.dto.PoiDto` 为 `record`，
`photos` 字段声明 `List<String>`，SQL 用 PostgreSQL jsonb 函数直接返文本。

## 1. 症状与定位

前端/curl 只看到：

```
{"timestamp":"...","status":500,"error":"Internal Server Error","path":"/api/poi/1"}
```

**HTTP 响应体是外层，真因只在服务端日志里。** 关键行：

```
Error instantiating class com.dawnivers.be.dto.PoiDto with invalid types
  (long,String,...,double,double,List,boolean)
or values (1,B001B0IZT0,解放公园,park,110101,解放大道1861号,027-82421760,
           114.292598,30.610841,
           ["http://store.is.autonavi.com/showpic/...", "http://...", "http://..."],
           false)
Cause: java.lang.IllegalArgumentException: argument type mismatch
```

诊断方法：**把 invalid types 列表与 values 列表按位对齐**——

| 位 | 声明类型 | MyBatis 实际给的值 |
|---|---|---|
| 10 | `List` | `["http://...","http://..."]` ← 整段文本，即一个 `String` |
| 11 | `boolean` | `false` |

第 10 位送进去的是 `String`，构造器要求 `List<String>`，反射调用即
`argument type mismatch`。

## 2. 根因

SQL 中：

```sql
jsonb_path_query_array(raw, '$.photos[*].url')::text AS photos
```

`::text` 让它**变成一段 JSON 文本**。MyBatis 的自动映射（`resultType` + record 的
`DefaultObjectFactory`/`applyConstructorAutomapping`）只会按 JDBC 类型给出 `String`，
不会解析 JSON。**MyBatis 没有内置 String→List 的转换，必须显式 TypeHandler。**

同一根因的另一种说法：`Cannot convert String to List` / `argument type mismatch` ——
都是"列给的是字符串、构造器要的是 List"。

## 3. 采用方案（A）：自定义 TypeHandler + resultMap

**DTO 对外契约不变**（前端始终拿到 `photos: ["url1","url2"]`），且该 handler 可复用于
后续所有 jsonb→List 字段（如 `biz_ext`、D16 其他字段）。

新建 `BE/src/main/java/com/dawnivers/be/config/StringListTypeHandler.java`：

```java
package com.dawnivers.be.config;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.ibatis.type.BaseTypeHandler;
import org.apache.ibatis.type.JdbcType;

import java.sql.*;
import java.util.List;

public class StringListTypeHandler extends BaseTypeHandler<List<String>> {

    private static final ObjectMapper MAPPER = new ObjectMapper();

    @Override
    public void setNonNullParameter(PreparedStatement ps, int i, List<String> p, JdbcType t) {
        throw new UnsupportedOperationException("仅用于读取");
    }

    @Override
    public List<String> getNullableResult(ResultSet rs, String columnName) throws SQLException {
        return parse(rs.getString(columnName));
    }

    @Override
    public List<String> getNullableResult(ResultSet rs, int columnIndex) throws SQLException {
        return parse(rs.getString(columnIndex));
    }

    @Override
    public List<String> getNullableResult(CallableStatement cs, int columnIndex) throws SQLException {
        return parse(cs.getString(columnIndex));
    }

    private List<String> parse(String json) throws SQLException {
        if (json == null || json.isBlank()) return List.of();
        try {
            return MAPPER.readValue(json, new TypeReference<List<String>>() {});
        } catch (Exception e) {
            throw new SQLException("photos 解析失败: " + json, e);
        }
    }
}
```

**XML 必须从 `resultType` 改为 `resultMap`**——`resultType` 无法表达"这一列用自定义
handler"。record 目标需用 `<constructor>`，且 `<arg>` 顺序必须与 record 组件顺序一致：

```xml
<resultMap id="PoiDtoMap" type="com.dawnivers.be.dto.PoiDto">
    <constructor>
        <idArg column="gid"  javaType="long"/>
        <arg column="amap_id"  javaType="java.lang.String"/>
        <arg column="name"     javaType="java.lang.String"/>
        <arg column="category" javaType="java.lang.String"/>
        <arg column="typecode" javaType="java.lang.String"/>
        <arg column="address"  javaType="java.lang.String"/>
        <arg column="tel"      javaType="java.lang.String"/>
        <arg column="lon"      javaType="double"/>
        <arg column="lat"      javaType="double"/>
        <arg column="photos"   javaType="java.util.List"
             typeHandler="com.dawnivers.be.config.StringListTypeHandler"/>
        <arg column="detail_fetched" javaType="boolean"/>
    </constructor>
</resultMap>

<select id="selectByGid" resultMap="PoiDtoMap">
    select gid, amap_id, name, category, typecode, address, tel,
           ST_X(geom) as lon, ST_Y(geom) as lat,
           jsonb_path_query_array(raw, '$.photos[*].url')::text as photos,
           detail_fetched_at is not null as detail_fetched
      from poi
     where gid = #{gid}
</select>
```

## 4. 被否决的替代方案

- **B：DTO 用 `String photosJson`，Service 内转换**——要么对外契约退化成字符串，
  要么得建 `PoiRow`（Mapper 用）+ `PoiDto`（对外用）两个类，多一层机械转换。不如 A 干净。
- **C：`resultType="map"` 再手工组装**——绕远，失去 record 的类型安全。

## 5. 验证清单（改完重启后）

服务端口 8094，profile `local`，无 devtools，改代码必须手动重启。

```powershell
$env:PYTHONIOENCODING='utf-8'
curl.exe -s http://localhost:8094/api/poi/1  | python -c "import sys,json;d=json.load(sys.stdin);print(d['name'],d['photos'])"
curl.exe -s http://localhost:8094/api/poi/39 | python -c "import sys,json;d=json.load(sys.stdin);print(d['name'],d['photos'])"   # 期望 []
curl.exe -s -o NUL -w "404test -> [HTTP %{http_code}]`n" http://localhost:8094/api/poi/999999999
curl.exe -s -o NUL -w "400test -> [HTTP %{http_code}]`n" http://localhost:8094/api/poi/abc
curl.exe -s -o NUL -w "areas -> [HTTP %{http_code}] %{size_download} bytes`n" http://localhost:8094/api/areas
```

已实测通过的部分（与本次 bug 无关，说明 Controller/Service 层逻辑正确）：
`/api/poi/999999999` → 404（`ResponseStatusException` 生效）；
`/api/poi/abc` → 400（Spring 类型转换拦截）。
注意 500 时响应体没有 `photos` 键，验收脚本取 `d['photos']` 会 KeyError —— 那是错误
响应，不是接口 bug。

## 6. 操作顺序与踩坑

1. 新建 `config/StringListTypeHandler.java`；
2. 改 `PoiMapper.xml`：`resultType` → `resultMap`；
3. `mvn -B -q clean compile`（必须 `clean`，增量编译会说谎）；
4. 停旧实例：`Get-NetTCPConnection -LocalPort 8094 -State Listen` 取 `OwningProcess`
   后 `Stop-Process -Force`，确认端口释放再起——否则 `Port 8094 was already in use`；
5. `mvn -q spring-boot:run` 重启后跑上面五条验证。

## 参考

- 相关文档：`30e3d3c7-0ab7-43c6-a88a-c9592c046c68`（Controller 层约定，record 作为固定结构
  响应 DTO 的判据）、`6b85ed40-4278-4e1f-b061-02a6fc74fc95`（其中"geometry 进 MyBatis 先
  `ST_AsGeoJSON` 返 String，别一上来写 TypeHandler"的经验边界——照片这类简单数组字段用
  TypeHandler 更合适）、`d7826a4a-c9bb-4fbe-bccc-7cacfd399421`（poi 表结构与字段缺失率）。
- 源文件：`BE/src/main/java/com/dawnivers/be/dto/PoiDto.java`、
  `BE/src/main/resources/mapper/PoiMapper.xml`、
  `BE/src/main/java/com/dawnivers/be/service/PoiService.java`、
  `BE/src/main/java/com/dawnivers/be/controller/PoiController.java`。
