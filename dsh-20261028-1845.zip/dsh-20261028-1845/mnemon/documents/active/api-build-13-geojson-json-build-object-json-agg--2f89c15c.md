---
id: "2f89c15c-dc27-4607-a604-e2eb083af4cd"
title: "/api/build 返回 13 区 GeoJSON 的实现规格与验收基线：json_build_object + json_agg + ST_AsGeoJSON::json、ObjectMapper 构造器注入、85 432 字节对照式验证（实测）"
description: "openlayers服务平台开发 BE 子工程的 /api/build 落地手册：已定稿并实测的 GeoJSON 聚合 SQL（三个不可改细节）、Jackson ObjectMapper 字段+构造器注入要点与漏参报错、四层响应验证阶梯（状态码/体积 85432 bytes/结构 13 个 dict/服务端日志）、String 与 JsonNode 两条路线的契约强度更正、失败现象-真因表、验收后期望数据与前端代理下一步。"
status: "active"
created_at: "2026-10-26T10:44:14.847Z"
updated_at: "2026-10-26T10:44:14.847Z"
content_hash: "b4d88e2d45205d15ab7663e08e18dd19a032ddf54c76b4b4b5b0249e69640223"
source_paths:
  - "BE/src/main/java/com/dawnivers/be/controller/AreaController.java"
  - "BE/src/main/resources/application.properties"
  - "FE/vite.config.js"
session_ids:
  - "a8d5bcaa-d861-479d-9a01-9d33334d2322"
memory_body_ids:
  []
---

# /api/build 返回 13 区 GeoJSON：实现规格与验收基线

工作区 `D:\WebGIS\web二维开发\openlayers服务平台开发`，BE 子工程 = `BE`，Spring Boot 3.5.16 / JDK 17 / Maven `D:\maven\bin\mvn.cmd` / 端口 8094；同机 GeoServer 8080、前端 Vite 5173。
接续既有三篇：`7e152f0a-53ee-4111-b95c-9e790c4ebac2`（进程 CreationDate 对比源码 LastWriteTime 的 404 差量诊断、端口三层阶梯）、`753c5a7a-347a-4270-ab07-3c64460c8fcf`（入口类与首次启动验收）、`30e3d3c7-0ab7-43c6-a88a-c9592c046c68`（Controller 层约定、四种返回类型判据、String 走 `StringHttpMessageConverter` 的陷阱）。
本篇只补前三篇没有的：**`/api/build` 这个接口的 SQL 契约、Jackson `readTree` 接线方式、以及可用于回归比对的实测基线数字**。

## 1. 数据端先跑通：SQL 与实测基线

用 psql 直出，**实测**（不是推测）：

```
输出大小: 85,432 字节 (83.4 KB)
type = FeatureCollection | features = 13
properties keys = ['adcode', 'name', 'level', 'center']
first = 青山区 420107 district
center = [114.3915169, 30.6364754]
geometry = MultiPolygon  (对象，不是字符串)
```

定稿 SQL：

```sql
SELECT json_build_object(
  'type','FeatureCollection',
  'features', json_agg(f)
)
FROM (
  SELECT json_build_object(
    'type','Feature',
    'properties', json_build_object('adcode',adcode,'name',name,'level',level,'center',center),
    'geometry', ST_AsGeoJSON(geom)::json
  ) AS f
  FROM admin_area
) t
```

三个不可改的细节，改一个就坏：

| 细节 | 改错的后果 |
|---|---|
| `ST_AsGeoJSON(geom)::json` 的 `::json` | geometry 变成**字符串**，前端 `new GeoJSON().readFeatures()` 直接崩 |
| `json_agg(f)` 聚合 | 变成 13 行、每行一个 Feature，外层没有 FeatureCollection |
| 子查询别名 `AS f` / `) t` | 语法错误 |

`float8[]` 形态的 `center` 被 `json_build_object` 自然转成数组，无需额外处理。
PSQL 控制台把中文区名显示成乱码属 PowerShell GBK 控制台现象，数据本身是 UTF-8，JDBC → Java → HTTP 链路不会乱码（断言方式见 §3 第 3 层）。

## 2. Java 侧接线：四处改动，第三处最容易漏

`BE\src\main\java\com\dawnivers\be\controller\AreaController.java` 现有形态（仅 `/ping-db`，返回 `Long`，实测 200 / `13`）：

```java
@RestController
@RequestMapping("/api")
public class AreaController {
    private final JdbcTemplate jdbcTemplate;
    public AreaController(JdbcTemplate jdbcTemplate) { this.jdbcTemplate = jdbcTemplate; }
    @GetMapping("/ping-db")
    public Long pingDb() {
        return jdbcTemplate.queryForObject("select count(*) from admin_area", Long.class);
    }
}
```

加 `/api/build` 要动的四处：

1. import `com.fasterxml.jackson.databind.JsonNode`、`com.fasterxml.jackson.databind.ObjectMapper`；
2. 字段 `private final ObjectMapper objectMapper;`；
3. **构造器追加参数并赋值**：`AreaController(JdbcTemplate jdbcTemplate, ObjectMapper objectMapper)`。Spring 按类型各找一个 Bean——`JdbcTemplate` 由 starter-jdbc 提供、`ObjectMapper` 由 `JacksonAutoConfiguration` 提供（starter-web → starter-json），两个都在，创建成功。漏赋值/漏参数的典型报错：`Parameter 0 of constructor in ...AreaController required a bean of type ... that could not be found`；
4. 方法：`@GetMapping("/build") public JsonNode build()`，体内两行——`String json = jdbcTemplate.queryForObject(BUILD_SQL, String.class); return objectMapper.readTree(json);`。

SQL 常量用 JDK 17 文本块 `private static final String BUILD_SQL = """...""";`（`static` 类级共享、`final` 不可变；文本块缩进自动剥离）。

`readTree(String)` 声明 `throws JsonProcessingException`（受检）：今日做法是**方法上 `throws`**，让异常交给 Spring 变成 500 并留完整堆栈；D8 做统一错误处理时再改为业务异常。**禁止 `catch (Exception e) {}` 空吞**——"SQL 返回坏 JSON"会退化成前端拿 null，排查成本翻倍。

## 3. 四层验证阶梯（`/api/build` 必须全做）

| 层 | 命令 | 期望 |
|---|---|---|
| ① 状态码 | `curl.exe -s -i http://localhost:8094/api/build --max-time 30` | `HTTP/1.1 200` |
| ② 体积 | `curl.exe -s -o "$env:TEMP\build.json" -w "[HTTP %{http_code}] %{size_download} bytes %{time_total}s" ...` | **85432 bytes**，与 psql 直出一致 ⇒ 中间没被二次编码 |
| ③ 结构/类型 | `python -c "import json;d=json.load(open(r'$env:TEMP\build.json',encoding='utf-8'));f=d['features'][0];print(d['type'],len(d['features']),type(f['geometry']).__name__,f['properties']['name'])"` | `FeatureCollection 13 dict 青山区` |
| ④ 服务端日志 | mvn 窗口 | 首次请求出现 `Initializing Spring DispatcherServlet`；DB 首查出现 `HikariPool-1 - Starting... / Start completed.` |

- 第 3 层那个 `dict` 是关键：`str` 说明 SQL 漏了 `::json`；数量校验浏览器做不了，必须回命令行。
- 状态码判读（与 404 篇一致并扩展）：`200` 进到方法；`404` + Spring 四字段 JSON = 无匹配 handler（路径错 / 没重启 / 未扫到类）；`500` = 方法内抛异常，看日志 `Caused by`；`curl: (7)` = 端口没服务。
- 字节类问题的排查技巧：用 `-o` 存文件再用 python 读，别用 `-s` 直接看控制台（否则会把"控制台编码"误判成"服务端乱码"）。

## 4. 重启纪律（本篇新增的机制解释）

`mvn spring-boot:run` 不是直接跑程序，而是 **fork 第二个 java 进程**；Windows 上 Ctrl+C 发给前台进程组，mvn 退出但子 java 常成为孤儿。本项目已两次实测（13:51、15:46 各一个），其中 15:46 那个在源码 16:26 修改后仍在 8094 上服务，于是 `/api/ping-db` 一直是 404。

**判据永远是"端口上还有没有人"，不是"我按过 Ctrl+C 了"：**

```powershell
# 查：谁占 8094、多老
$c = Get-NetTCPConnection -LocalPort 8094 -State Listen -ErrorAction SilentlyContinue | Select-Object -First 1
if ($c) { Get-CimInstance Win32_Process -Filter "ProcessId=$($c.OwningProcess)" | Select-Object ProcessId,Name,CreationDate }
(Get-Item src\main\java\com\dawnivers\be\controller\AreaController.java).LastWriteTime

# 杀：确认输出必须是 "8094 -> 0"
if ($c) { Stop-Process -Id $c.OwningProcess -Force }
Start-Sleep -Seconds 2
"8094 -> " + (Get-NetTCPConnection -LocalPort 8094 -State Listen -ErrorAction SilentlyContinue | Measure-Object).Count
```

端口没空就起，报的是 `Web server failed to start. Port 8094 was already in use.`，极易被误读成代码问题。

重启范围对照：`.java` / `application.properties` / `pom.xml`（后者还要 `Java: Reload Projects`）要重启 BE；前端 `.vue/.css/.js` 走 Vite HMR 不用；GeoServer SLD 不用重启但要在 GeoServer 里 reload。只重启要改的那个服务——BE 8094 重启不影响 8080 与 5173。

本次实测重启后的正常启动日志：`Tomcat started on port 8094 (http)`、`Started BeApplication in 1.171 seconds`；首查日志 `HikariPool-1 - Added connection org.postgresql.jdbc.PgConnection@...` / `Start completed`。

## 5. 一处已更正的旧说法（避免按错误理由选方案）

早前说过"返回 `String` 一定会被序列化两次、变成 `\"{...}\"`"——**不准确**：

- 方法**直接**返回 `String` ⇒ 走 `StringHttpMessageConverter`，body 是原样文本（`Content-Type: text/plain`），不加引号；
- 真正发生转义的是把 JSON 字符串塞进 `Map`/POJO 再返回（`Map.of("data", jsonString)`）。

两条路都能出正确 JSON，差别在契约强度：

| 方案 | 好处 | 坏处 |
|---|---|---|
| `JsonNode` + `readTree` | 类型即契约；解析即校验（坏 JSON 当场 `JsonParseException`）；后续可改字段 | 多一个 `ObjectMapper` 依赖 |
| `String` + `produces="application/json"` | 少一次解析 | 忘写 `produces` 就变 `text/plain`；坏 JSON 原样流到前端才炸 |

本项目选定 `JsonNode`，因为后续 `nearby` 要真去加字段/改结构。

## 6. 失败现象 → 真因对照

| 现象 | 真因 | 修法 |
|---|---|---|
| 启动失败 `required a bean of type 'ObjectMapper'` | 构造器加参但字段未声明/未赋值，或 import 错包 | 用 `com.fasterxml.jackson.databind.ObjectMapper` |
| `200` 但体积约翻倍（≈170 KB） | 返回值被多包一层 / 未用 `readTree` | 方法签名确认是 `JsonNode` |
| `FeatureCollection 13 str` | SQL 漏 `::json` | 改 SQL |
| `500` + `JsonParseException` | SQL 返回的不是合法 JSON（复制进了 psql 边框等） | 把 SQL 原样回 psql 单测 |
| `500` + `No serializer` / `UnsupportedOperationException` | 返回了 geometry 相关 Java 对象 | 仍走 SQL 出 GeoJSON |
| body 中文变 `????` | 客户端控制台编码 | `-o` 存文件后 python 读 |
| `404` | 没重启 / 路径拼错 | 比进程 `CreationDate` 与源码 `LastWriteTime` |

## 7. 通过之后的下一步（D5 收尾）

1. `FE\vite.config.js` 的 `server.proxy` 加 `/api → http://localhost:8094`（**不要 rewrite**）；
2. 起前端（`pnpm dev` 或 `node node_modules/vite/bin/vite.js`），注意本项目前端端口是 **5173**；
3. `curl.exe -s http://localhost:5173/api/build | python -c "import sys,json; print(len(json.load(sys.stdin)['features']))"` ⇒ `13`；
4. 提交（`git status` 先确认没把带密码的 `application.properties` 带进去）：`git add pom.xml .gitignore src .vscode`，commit message 形如 `02 /api/build 返回13区GeoJSON（JdbcTemplate + Jackson）`。

分层分工原则（本篇与后续 nearby / 格网共用）：**PostgreSQL 负责把 geometry 变成 GeoJSON（`ST_AsGeoJSON`），Jackson 只负责 Java ↔ JSON 文本传输，每一层只做自己懂的事**——距离计算放 PostGIS、聚合放 SQL，不要下放到 Java 或前端。
