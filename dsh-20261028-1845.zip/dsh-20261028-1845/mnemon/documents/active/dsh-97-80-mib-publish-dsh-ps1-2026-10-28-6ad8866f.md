---
id: "6ad8866f-0f40-4601-91e9-d31b793a186e"
title: "DSH 周备份体积上限核查：97.80 MiB 实测余量与 publish-dsh.ps1 闸门缺陷（2026-10-28）"
description: "回答\"单次推送有大小限制吗\"的完整核查：GitHub 两级限制（单次 push 2 GiB、单文件 100 MiB）与其余各道尺寸线、本机备份包实测 97.07→97.80 MiB 的余量、对上一条 99.5 MB 估算的撤回与原因、10-18 那次失败实为 HTTP 408 链路问题、体积真正大头（ppt-master / archify）、以及 publish-dsh.ps1 现有 ≥95 MB 只告警导致超限仍会照推的闸门缺陷与补丁方案。"
status: "active"
created_at: "2026-10-28T08:22:12.651Z"
updated_at: "2026-10-28T08:22:12.651Z"
content_hash: "3e38374ff1eb0327a042d287b6df63a663234ffb798419c03a0cb7477c8672f6"
source_paths:
  - "dsh-migration/publish-dsh.ps1"
  - "dsh-migration/export-dsh.ps1"
session_ids:
  - "91f1b914-6413-4352-9513-03691194a111"
memory_body_ids:
  []
---

# DSH 周备份体积上限核查（2026-10-28）

承接两份既有文档：`284e4a5f-9725-4a26-bd8c-7ad334658199`（周备份 → GitHub 的单提交 force push 发布链路）与 `2d0583cd-e504-420a-af51-d210a6aa571e`（design-md 技能落地，其 §6 首次提出「备份包逼近 100 MB 上限」的担忧）。本文只记录**体积上限这一次的实测核查**，并**撤回其中 §6 的一个错误估算**，同时指出 `publish-dsh.ps1` 现存的一个闸门缺陷。

## 1. GitHub 的尺寸限制是分层的，别混成一件事

| 限制 | 数值 | 触发表现 |
|---|---|---|
| 单次推送（push） | **2 GiB** | `remote: fatal: pack exceeds maximum allowed size` 或 `fatal: the remote end hung up unexpectedly` |
| 单个文件（git 跟踪） | **100 MiB 硬拦截**；50 MiB 起 git 仅警告、仍能推成功 | 推送被拒 |
| 网页上传单文件 | 25 MiB | 浏览器里添加文件时 |
| 仓库总体积 | 建议 < 1 GB，强烈建议 < 5 GB | 影响 clone 速度与基础设施健康；过大会收到 GitHub Support 邮件 |
| Release 附件 | 单文件受所在套餐的 LFS 上限，总量与带宽不限 | 适合分发大二进制 |

结论：**「单次推送」确实有上限，是 2 GiB**；但对本机链路这个数字从未被触及——推的是 ~97 MiB 的单个 zip，真正起作用的是**单文件 100 MiB**那条线。

来源：<https://docs.github.com/en/repositories/working-with-files/managing-large-files/about-large-files-on-github> · <https://docs.github.com/en/get-started/using-git/troubleshooting-the-2-gb-push-limit>（2 GiB 的规避手法是分批推 commit，或删 `.git` 重建历史分批追加）

## 2. 实测余量

```
当前包          101,788,821 B = 97.07 MiB
GitHub 硬顶     104,857,600 B = 100 MiB
剩余                             2.93 MiB
```

## 3. 撤回上一条估算（重要）

`2d0583cd` 的 §6 写「加 design-md 后约 99.5 MB，很可能被拒推」，并提出三个候选方向（备份排除 design-md / 瘦身语料 / 改走 Release）。**该估算错误**：把未压缩体积当成了包内增量。

实测 deflate：

```
design-md 原始   2,527,675 B  (2.41 MiB)
design-md 压缩     761,859 B  (0.73 MiB)   压缩率 30.1 %
加进去后        102,550,680 B  (97.80 MiB)  ← 距硬顶仍有 2.20 MiB
```

纯文本（`DESIGN.md`）压缩率约 30%，所以**不需要为它做备份排除，照常装即可**。§6 中基于该错数的三条方向在当时都不必启用。

## 4. 10-18 那次 72 MB 推失败不是被限额拒

报的是 `HTTP 408` / `send-pack: unexpected disconnect`，体积**远低于** 100 MiB 与 2 GiB 任何一条。定性为**链路问题**（代理、超时、大包传输不稳定），处理方式是重试或按既有做法 `commit --amend` 后重推，与包体积无关。不要把它当成「撞上限」的先例去缩包。

## 5. 真正会撞线的情形与真正的大头

- 带 `-IncludeAttachments`（+180 MB 附件）→ 必然越过单文件线，`publish-dsh.ps1` 已为此 `throw`。
- 按每周约 +24 MB 的增速，再涨约两周即逼近 100 MiB。
- 体积大头不是文本类技能，而是 **`ppt-master` 39.88 MB** 与 **`archify` 4.71 MB**；若含二进制素材，压缩率会远低于文本，是最该先看的瘦身对象。

## 6. `publish-dsh.ps1` 的闸门缺陷与补丁

现状（`dsh-migration/publish-dsh.ps1` L151–156）逻辑是：

- `$zipMB -ge 95` 且**带** `-IncludeAttachments` → `throw`；
- `$zipMB -ge 95` 但**不带**附件 → 只 `Write-Warn`。

后果：**普通周备份即使到了 100.5 MiB，脚本也会照推**，然后被 GitHub 拒，报一个与体积关系不明的错。应在本地就拦住：

```powershell
# 替换 publish-dsh.ps1 现 151-156 段
$zipBytes  = $zipInfo.Length
$hardLimit = 104857600          # GitHub 单文件 100 MiB
if ($zipBytes -ge $hardLimit) {
  throw "zip 已达 $([math]::Round($zipBytes/1MB,2)) MiB，超过 GitHub 单文件 100 MiB 硬顶，推送必被拒。请缩包或改用 release。"
}
if ($zipBytes -ge 95MB) {
  Write-Warn ("zip {0} MiB，距 100 MiB 硬顶只剩 {1} MiB" -f `
    [math]::Round($zipBytes/1MB,2), [math]::Round(($hardLimit-$zipBytes)/1MB,2))
}
```

保留 95 MiB 的**告警**（提示逼近），把 100 MiB 变成**硬中止**。

退路：2 GiB 的 push 额度允许**把包拆成两个各自 < 100 MiB 的 zip** 一次推上去——合法且可行，作为最后手段而非首选。

**状态**：补丁未落地——核查末尾向用户询问「要我把那段闸门改进 `publish-dsh.ps1` 吗？」，当轮未获答复。

## 7. 源文件

- `dsh-migration/publish-dsh.ps1`（L142–156 压缩与体积闸；L105–140 为密钥硬闸与脱敏）
- `dsh-migration/export-dsh.ps1`（包内容与排除项）
