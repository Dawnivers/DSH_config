---
id: "0a010014-88e2-4b6c-a7c5-7a8e5ce68004"
title: "design-md（awesome-design-md）接入 DSH 的可行性调研与三方案建议"
description: "对比 awesome-design-md（84 份 DESIGN.md 语料，零适配）与 rea（MCP server，自带 DSH 适配）两个仓库；核实 DSH 技能发现根与 cordis.patch.yml 挂 MCP 的既有做法；给出 A 零改动 / B 包成 DSH skill（推荐）/ C MCP 化三方案。截至 2026-10-28 仅调研，用户未确认动手。"
status: "active"
created_at: "2026-10-28T07:14:29.872Z"
updated_at: "2026-10-28T07:14:29.872Z"
content_hash: "76c1290860229c377c9bcfd4834e166b711a2bee0ec06ef86b6cacc46bfac451"
source_paths:
  []
session_ids:
  - "dfd7deed-4117-4f07-8aa1-c857a4811495"
memory_body_ids:
  []
---

# design-md 接入 DSH 的可行性调研

日期：2026-10-28。状态：**仅调研与建议，未创建 skill、未改 profile、未安装任何东西**。用户当时的问题是「能不能适配/魔改这两个仓库」，尚未答复是否动手。

## 0. 一句话结论

要「魔改」的第一个仓库（awesome-design-md）**根本没有适配层，也不需要适配**——它是纯 Markdown 语料，任何能读文件的 agent 都能用；真正缺的不是能力，而是**触发条件**（agent 凭什么知道该读哪一份、按哪套规范落地）。而以为帮不上忙的第二个仓库（rea）反而自带 DSH 适配，可作为「给 DSH 做适配」的参考实现。

## 1. 两个仓库不是一类

| | awesome-design-md | rea |
|---|---|---|
| 实质 | 84 个站点的 DESIGN.md 语料（169 个 .md，约 2.39 MB，MIT） | MCP server（172 个工具）+ 打包 skill + `setup` 安装器 |
| 可执行代码 | 无（除 `.github` 工作流） | TypeScript 工程 |
| 用法 | `npx getdesign@latest add vercel` → 往项目根写一个 md | `npx rea-agents setup` → 往各 agent 写配置 |

## 2. awesome-design-md 的事实核查

- 目录只有 `design-md/<站点>/DESIGN.md` + README，**没有配套基础设施**，因此「适配清单」不存在，看不到 DSH 不等于被排除。
- README 声称每个站点附 `preview.html` / `preview-dark.html`，**实际仓库里一个 HTML 都没有**，169 个文件全是 `.md`；预览只在 getdesign.md 网站。
- 单份文件规模参考：`design-md/vercel/DESIGN.md` 约 41 KB。
- DESIGN.md 是结构化文档：YAML frontmatter 直接给 token（如 `colors.primary: "#171717"`、`hairline`、`canvas-soft`），正文固定分节 `Overview / Colors / Typography / Layout / Elevation & Depth / Shapes / Components / Do's and Don'ts`。读这份文件比读截图更可靠。

## 3. rea 的 DSH 适配（可作为参考实现）

- `docs/installation.md` 的支持清单里明写 `DeepSeek Harness | dsh`（要求 rea-agents ≥ 6.5.0）。
- `docs/client-configuration.md` 的接入方式是往 `$DSH_HOME/cordis.patch.yml` 追加 `insert` 条目，`name: "@deepseek-ai/dsh-mcp-client"`、`transport: stdio`、`command: <node 绝对路径>`、`args: [".../scripts/rea.mjs", "mcp"]`，工具名随后变成 `mcp__rea__<tool>`。
- **本机已有同款先例**：`~/.dsh/profiles/desktop/cordis.patch.yml` 第 65–79 行就是用 `insert` + `@deepseek-ai/dsh-mcp-client` 挂 windows-mcp。所以这是既有通道，不是新能力。
- 差异点：`rea setup --client dsh` 写的是 **home 级** `~/.dsh/cordis.patch.yml`（本机当时不存在），而 windows-mcp 在 **profile 级** `~/.dsh/profiles/desktop/`；两者都生效，home 级对所有 profile 生效。
- 未核实：rea 的 DSH 支持仅据其文档，**未实际安装验证**。

## 4. DSH 技能发现根（已在 `dsh-skill-filesystem/lib/index.js` 核实）

`SkillProvider.roots(cwd)` 的实际顺序：

1. 项目级 `<projectRoot>/.dsh/skills`（source `project-dsh`）
2. 项目级 `<projectRoot>/.agents/skills`（`project-agents`）
3. 自定义 `customSkillDirs`（`custom`）
4. 用户级 `<dshHome>/skills`（`user-dsh`，skipSystem）
5. 用户级 `<agentsHome>/skills`，`agentsHome` = `config.agentsHome ?? process.env.DSH_AGENTS_HOME ?? ~/.agents`（`user-agents`）
6. bundled 目录（`bundled`，trustedHost）

含义：写到 `~/.dsh/skills/` 或 `~/.agents/skills/` 都会被自动看见；模块内有针对 `SKILL.md` 的 chokidar watcher（`observeHostMutation` / 失效重扫），**改完即时生效，不必重启**。

## 5. 三个方案（成本差一个数量级）

- **A｜零改动**：`npx getdesign add <站点>` 把 DESIGN.md 扔进项目根，用户一句话「用这份 DESIGN.md」。要固化就加一条运行时记忆（涉及 UI 时先找项目根 DESIGN.md）。约 5 分钟。
- **B｜包成 DSH skill（推荐）**：`~/.dsh/skills/design-md/SKILL.md` 写清路由（用户要某品牌视觉 → 读 `design-md/<站点>/DESIGN.md` → 按 8/9 节规范落地），`references/` 放全量或按需 `curl` 拉取。建议**先做骨架 + 索引**（84 个站点名 + 一句话风格描述），正文按需拉，避免一上来把 2.4 MB 塞进技能目录。
- **C｜MCP 化**：写个取 DESIGN.md 的 MCP。收益最低——纯文本不需要工具，skill 里一行 `curl` 就够，反而多一次往返。

## 6. 待办 / 未验证

- 用户尚未确认执行 B（或只要 A 的记忆）。
- B 若执行：需决定 84 份是全量落地还是索引 + 按需拉取；索引需要从各 DESIGN.md 的 frontmatter `description` 抽取。
- rea 的 `cordis.patch.yml` 片段未在本机实测；home 级 vs profile 级的选择需按「是否想对所有 profile 生效」定。

## 7. 关联

- MCP 桥接的接线字段与 token 税另见 `4b7d494f-5c4b-4c71-8ea5-80f19359a2cb`（DSH 代码索引/上下文方案选型）。
- 另一份 MCP 选型调研：`8ba56185-2c41-4c6d-8b5a-903a6ba284ea`（Windows-MCP），其中也记录了 cordis.patch.yml 热生效这一约束。
