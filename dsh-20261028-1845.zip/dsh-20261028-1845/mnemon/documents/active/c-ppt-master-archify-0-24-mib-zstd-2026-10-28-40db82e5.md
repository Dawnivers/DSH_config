---
id: "40db82e5-4bab-4e2a-9a6d-6b98e729b8f5"
title: "备份包瘦身实测（方案 C）：排除 ppt-master/archify 只省 0.24 MiB，真凶是 zstd 会话（2026-10-28）"
description: "记录 export-dsh.ps1 加 -ExcludeSkills 的落地改法与实跑数据：排除 44.59 MiB 技能后 zip 仅从 97.07 降到 96.83 MiB，原因是 home/sessions 81 MiB 全是 session.v4.jsonl.zstd、压缩率 100% 且占整包 83%；同时推翻“换 7z/LZMA2 可再省 20-30%”的假设，给出 B（GitHub Release）/A（拆包）/C'（缩备份范围）三条后续路线与推荐排序。"
status: "active"
created_at: "2026-10-28T09:05:02.004Z"
updated_at: "2026-10-28T09:05:02.004Z"
content_hash: "380da51c5c9d53084b34f2032426100d21ddfaf76a5401e77956c73245423c9e"
source_paths:
  - "dsh-migration/export-dsh.ps1"
  - "dsh-migration/publish-dsh.ps1"
session_ids:
  - "5216da29-a778-4d6b-a350-c56893883d42"
memory_body_ids:
  []
---

# 备份包瘦身实测：方案 C 落地与 zstd 根因（2026-10-28）

承接 `6ad8866f-0f40-4601-91e9-d31b793a186e`（体积上限核查，预测「再约两周撞 100 MiB」）与 `284e4a5f-9725-4a26-bd8c-7ad334658199`（publish 链路）。本文只记**这次真正落地的改动与实跑结论**，并更正该核查里一条错误假设。

## 1. 改动：`export-dsh.ps1` 三处（方案 C）

`dsh-migration/export-dsh.ps1`：

1. **参数**：新增 `[string[]]$ExcludeSkills = @('ppt-master','archify')` 与 `[switch]$KeepAllSkills`；后者为真时把列表清空（一键退回全量导出）。
2. **排除方式**：robocopy 的 `/XD` 只吃绝对路径，所以在复制 `home\skills` 前把每个技能展开成 `Join-Path $src $s` 追加进 `$exDirs`；不存在则跳过，不报错。被排除项同时收集进 `$excludedSkillsReport`（名字 / 文件数 / MB）。
3. **记账**：`manifest.json` 增加 `excludedSkills` 字段；包根生成 `EXCLUDED_SKILLS.md`，内容由脚本从各技能 `SKILL.md` 的 metadata 里抓：版本号 + `official_repository` 或 `based_on`。

`publish-dsh.ps1` **不必改**——它调 export 时没显式传该参数，默认值自动生效。

**可复原性前置核查**（排除前做的，理由：删了就变永久丢失）：
- `ppt-master` v6.7.2，`official_repository: https://github.com/hugohe3/ppt-master`，MIT，13149 文件 / 39.88 MB（大头是 `templates` 24.45 MB + `scripts` 12.14 MB），无 `node_modules`、无 `package.json`。
- `archify` v2.14，`based_on: Cocoon-AI/architecture-diagram-generator (MIT, v1.0)`，62 文件 / 4.71 MB。
- `~/.dsh/skills-manager/state.json`(4.4 KB) 存安装清单，可用于重装留痕。

## 2. 实测：净省 0.24 MiB

真跑一次导出（`D:\dsh-test\dsh-20261028-1702`，1629 文件 / 155.92 MB）再压 zip：

| 项 | 10-25 包 | 10-28 实测 | 变化 |
|---|---|---|---|
| home/sessions | 59.61 | 81.00 | **+21.39** |
| home/skills | 49.01 | 9.21 | **−39.80** |
| home/storages | 27.35 | 37.77 | **+10.42** |
| plugin-sources | 22.28 | 22.28 | 0 |
| 原始合计 | 163.74 | 155.92 | −7.82 |
| **zip** | **97.07 MiB** | **96.83 MiB** | **−0.24 MiB** |

排除确实生效（39.80 MiB 出去了），但三天里 sessions +21.39、storages +10.42 把收益吃光。旧包 10-25 里确实含 ppt-master（13323 条目）与 archify（156 条目），所以不是「原本就没装」。

**结论：没有 C，本周的包会是 ~111 MiB 直接被拒——C 只救了这一周。**

## 3. 根因：sessions 是 zstd，压不动

各子树单独 deflate 实测：

| 子树 | 原始 | 压缩后 | 压缩率 |
|---|---|---|---|
| **home/sessions** | 81.00 | 80.76 | **100%** |
| home/storages | 37.77 | 5.21 | 14% |
| home/skills | 9.21 | 3.23 | 35% |
| plugin-sources | 22.28 | 3.97 | 18% |

`home/sessions` 下 227 个文件**全是 `session.v4.jsonl.zstd`**——DSH 已用 zstd 压过，外层 zip 无收益。它占整包 83%，一个字节都压不下去。

**被推翻的假设**：先前想「换 7z/LZMA2 能再省 20-30%」——对这块完全无效（且本机未装 7z/zstd/xz CLI，无法实测）。另外验证过「sessions 大文件里塞了内联图片」也不成立：前 8 大文件合计 18.0 MB，内联图片块 0 个。

## 4. 后续三条路线

| 方案 | 效果 | 代价 |
|---|---|---|
| **B. 走 GitHub Release** | 彻底脱离 100 MiB（release 单件上限 2 GiB），仓库只留 `LATEST.json` + README | `git push` 换成 Release API 上传；周更会堆 release，需定期删旧 asset |
| **A. 拆包** | 拆成两个各 <100 MiB 的文件，一次 push 合法 | 清理逻辑、`LATEST.json`、还原流程、restore 里「找包」等都假设「只有一个文件」，需一并改 |
| **C'. 缩备份范围** | 只备份最近 N 天会话，老会话不进包 | 主动放弃历史；`~/.dsh/dsh-session-archive` 已有归档目录，可能有现成机制可借 |

**推荐排序已从「C 就够」改为：B 为主、A 为过渡，C 保留**（它确实把 44.59 MiB 低价值数据请出包，且留下 `EXCLUDED_SKILLS.md` 重装清单）。

**当前状态**：已把三条路线与推荐抛给用户，**等其选 B 还是 A**。若选 B，下一步是把 `publish-dsh.ps1` 推送段换成 Release API（保留 zip、删旧 asset、SHA-256 校验），仓库侧只留指向最新 release 的 `LATEST.json`。

## 5. 源文件

- `dsh-migration/export-dsh.ps1`（L67–78 home 目录与 robocopy 排除、L188–202 manifest、L204–208 自带说明书）
- `dsh-migration/publish-dsh.ps1`（L84–101 调 export 与找包）
- 临时产物已清理：`D:\dsh-test`、`D:\tmp-taste2`、`D:\tmp-rb2`、`D:\tmp-three`
