---
id: "3a43c83f-513f-447d-aa7e-dda5eb8beb07"
title: "定时任务卡 prompt 冻结后的补丁方式：tag.promptPrefix 注入（DSH 配置周备份卡 2026-10-28 实例）"
description: "DSH 任务看板上已执行过的卡 title/description/prompt 会被冻结、task_board_update 改不动；本周备份卡（ead69e05）靠新增带 promptPrefix 的标签把「zip 约 11 MB 属正常 + 三项新验收」注入到每次执行，保住 2 次执行历史。含卡的实际状态、cron/下次运行、三个可选方案对比与仍旧的 description 文案。"
status: "active"
created_at: "2026-10-28T10:00:36.392Z"
updated_at: "2026-10-28T10:00:36.392Z"
content_hash: "162da3758fe0db75db377dd875f76bc61f8efe431d9dc2322ebef756ee12086e"
source_paths:
  - "dsh-migration/publish-dsh.ps1"
  - "dsh-migration/prune-sessions.mjs"
  - "dsh-migration/distill-dsh.mjs"
session_ids:
  - "e57231b4-40ab-49e7-a987-01ec68e4d7d2"
memory_body_ids:
  []
---

# 定时任务卡 prompt 冻结后的补丁方式（2026-10-28）

场景：`publish-dsh.ps1` 内部被加了「提炼本周会话 + 剪枝」两步，但看板上那张周备份卡的既有 prompt 还写着「zip 约 69 MB」，验收清单里也没有 distill/ 与 session-trash/。卡已经在跑，怎么让它在不丢历史的前提下知道新流程。

闭环流水线本身（distill → prune → export → 脱敏/体检 → 推）见 `ee27edfa`；本文只记**任务看板侧**的结论。

## 1. 卡的实际状态（2026-10-28 查得）

| 项 | 值 |
|---|---|
| 卡 id | `ead69e05-d364-4703-bce7-90dda8467e4e` |
| 标题 | DSH 配置周备份：打包并推送 GitHub |
| status / 标签 | `todo` / 备份 |
| schedule | `0 22 * * 0`，Asia/Shanghai |
| 上次触发 | 2026-10-25 22:00（succeeded） |
| 下次触发 | 2026-11-01 22:00 |
| executionCount | 2 |

看板侧 `armedSchedules: 1` —— 全板只有这一张卡挂着定时器。卡的 prompt 第 2 步就是 `pwsh -NoProfile -File .\publish-dsh.ps1`，所以脚本内部新增的步骤**自动被覆盖**，不需要新建卡、不需要改调度。这是「编排放在脚本里而不是放在卡 prompt 里」的直接收益。

## 2. 约束：执行过的卡，title / description / prompt 冻结

`executionCount >= 1` 之后，看板不再接受 `task_board_update` 修改这三个字段（改标签不受限）。因此：

- 旧的「69 MB」「约 68 MB」文案改不掉；
- 新验收项无法追加进 prompt；
- 想改只能换渠道，不能硬改。

## 3. 采用方案：带 promptPrefix 的标签

标签对象支持 `{ name, promptPrefix }`，每次执行时把 `promptPrefix` 文本前置注入到任务 prompt 之前——等于给冻结的 prompt 打了个运行时补丁，且标签本身随时可改。

本次实际加上的第二个标签（`tags` 变成长度 2）：

```json
{ "name": "含提炼与剪枝",
  "promptPrefix": "注意：2026-10-28 起 publish-dsh.ps1 内部已增加「提炼本周会话 + 剪枝」，zip 约 11 MB 属正常（不再是 69 MB）。结论里额外确认：包内 distill/ 有摘要、session-trash/ 有本轮搬走的会话、publish-state.json 的 sizeMB 与远端一致。" }
```

写入后 `updatedAt` 刷新，cron、`nextRunAt`、`executionCount=2` 均未变——即补丁不触碰调度与历史。

## 4. 三个方案的取舍（备查）

| 方案 | 效果 | 代价 |
|---|---|---|
| **A. 标签 + promptPrefix**（已采用） | 执行时注入说明，行为正确 | 无；标签可改 |
| B. 新建卡替代 + 归档旧卡 | description 干净 | 丢执行历史，需重挂调度 |
| C. 不动 | 行为正确，文案过时 | 看板上一直显示错数 |

选 A 的理由：卡的价值在 prompt 与调度，description 只是给人看的说明；用一处可改的标签换掉重挂调度的风险不划算。

## 5. 遗留（非阻塞）

- 看板上点开这张卡，**description 仍写「zip ≈68 MB」**（冻结）。只在执行时被 promptPrefix 纠正，界面文案依旧旧。日后嫌碍眼再走方案 B。
- 11-01 那次是第一次真正搬会话：74 个会话当前卡在「摘要已沉淀 ≥12 小时」门槛上，届时会被搬进 `D:\dsh-migration\session-trash\`（30 天后才可 `--purge`）。
- 待用户决定：是否在非周日手动跑一次含 `--apply` 的真实闭环，把风险提前暴露。

## 6. 源文件

- `dsh-migration/publish-dsh.ps1` — 闭环编排主体（卡 prompt 实际调用的就是它）
- `dsh-migration/distill-dsh.mjs`、`dsh-migration/prune-sessions.mjs` — 被编排的两步
- 相关文档：`ee27edfa`（闭环定稿）、`5be07c0a`（distill 原理）、`b023afe4`（prune 判据）
