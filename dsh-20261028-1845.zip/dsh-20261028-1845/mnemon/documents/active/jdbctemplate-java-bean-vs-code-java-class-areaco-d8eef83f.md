---
id: "d8eef83f-289b-463a-a53a-4319d6398187"
title: "JdbcTemplate 接入与 Java 红线归因：构造器注入的 Bean 装配链、VS Code Java 环境对齐、漏写 class 类声明诊断（AreaController /ping-db 实测）"
description: "openlayers服务平台开发 BE 子工程接入 spring-jdbc 的落地参照：AreaController 六段结构、DataSource→JdbcTemplate→Controller 自动装配链与 Bean 缺失报错归因、.vscode/settings.json 四条 Java/Maven 环境对齐（JDK D:\\java、settings.xml、mvn.cmd）、「IDE 红 vs mvn compile 红」判据表、缺 class 声明导致 6 处级联错误的定位法、/api/ping-db 验收与失败关键词对照。"
status: "active"
created_at: "2026-10-26T08:31:22.781Z"
updated_at: "2026-10-26T08:31:22.781Z"
content_hash: "78edf72fe728e91b915cc0e35b6ceddbb7bbc16dcf22ec81effe7286760c57d0"
source_paths:
  - "BE/src/main/java/com/dawnivers/be/controller/AreaController.java"
  - "BE/.vscode/settings.json"
  - "BE/src/main/resources/application.properties"
  - "BE/pom.xml"
session_ids:
  - "42261b1e-4a3b-4aa3-9992-8b96dec03eeb"
memory_body_ids:
  []
---

# JdbcTemplate 接入与 Java 红线归因（2026-10-26 实测）

工作目录 `D:\WebGIS\web二维开发\openlayers服务平台开发`，子工程 `BE\`（Spring Boot 3.5.16 + Java 17）。本文记录**数据访问层第一次接进 Web 层**这一跳：`AreaController` 的骨架、Bean 从哪里来、编辑器红线怎么归因。
上层脚手架与目录契约见 [BE(api) Spring Boot 3.5.16 后端脚手架](7eab7ab9-b0b8-4f01-a2a7-09444c6ffdea)；入口类与端口/启动验收见 [Spring Boot 入口类与首次启动验收](753c5a7a-347a-4270-ab07-3c64460c8fcf)；controller 通用约定与返回类型判据见 [Controller 层约定与返回类型选择](30e3d3c7-0ab7-43c6-a88a-c9592c046c68)。本文只补这三篇未覆盖的部分。

## 1. 三个 Controller 的分工（验证顺序即它们的存在理由）

| 文件 | 路径 | 验证什么 |
|---|---|---|
| `BeApplication.java` | — | 唯一有 `main` 的入口，启动容器 + 内嵌 Tomcat |
| `HelloController.java` | `/api/hello` | 不碰数据库，证明 **Web 层通了** |
| `AreaController.java` | `/api/ping-db` | 碰数据库，证明 **数据层也通了** |

`AreaController` 自己没有 `main`，单独跑不起来；它生效完全依赖 `@SpringBootApplication` 里 `@ComponentScan` 从 `com.dawnivers.be` 开始向下扫到 `controller` 子包。**这条链断了就是 404 且启动日志无任何报错**（本项目已踩过一次）——这是排查 404 时第一个该怀疑的，而不是路由写错。

## 2. AreaController 的六段结构

```java
package com.dawnivers.be.controller;                 // ① 包：必须等于目录路径
import org.springframework.jdbc.core.JdbcTemplate;   // ② import：只起短名，不装依赖
import org.springframework.web.bind.annotation.*;     //    GetMapping / RestController / RequestMapping

@RestController          // ③ 组合注解 = @Controller + @ResponseBody
@RequestMapping("/api")  //    类级前缀
public class AreaController {                    // ★ 类型声明，字段/方法唯一能放的容器

    private final JdbcTemplate jdbcTemplate;     // ④ 依赖，final

    public AreaController(JdbcTemplate jdbcTemplate) {   // ⑤ 构造器注入入口
        this.jdbcTemplate = jdbcTemplate;
    }

    @GetMapping("/ping-db")                      // ⑥ 最终 URL = /api + /ping-db
    public Long pingDb() {
        return jdbcTemplate.queryForObject("select count(*) from admin_area", Long.class);
    }
}
```

要点（与 Controller 那篇不重复的部分）：

- **`final` 字段 + 單构造器 = 不需要 `@Autowired`**（Spring 4.3+ 单构造器自动按参数类型注入）。`final` 的价值是「构造不完整就编译不过」，依赖缺失暴露在启动期而非运行期空指针。
- **构造器只在启动时执行一次**，之后 `AreaController` 是单例，所有请求共用——所以类里不能放可变成员变量。
- **`Long` 而非 `Integer`**：PG 的 `count(*)` 是 `bigint`。`Integer.class` 也能过（框架内部做数值转换），但那是宽容不是真实类型。
- **`queryForObject(sql, Class)` 要求恰好一行一列**，0 行或多行抛异常；`count(*)` 天生一行，所以安全。
- 直接 `return Long` → 响应体是裸数字 `13`；不要再包 `{"count":13}`。

## 3. Bean 从哪来：自动装配链（`required a bean of type 'JdbcTemplate'` 的唯一正解）

```
application.properties 的 spring.datasource.*（url/username/password/driver-class-name）
      ↓ 被 DataSourceAutoConfiguration 读取
DataSource（HikariCP 连接池）                 ← Boot 自动装配的 Bean ①
      ↓ JdbcTemplateAutoConfiguration 拿到它
JdbcTemplate                                  ← Boot 自动装配的 Bean ②
      ↓ 构造器按参数类型匹配
AreaController                                ← Spring 创建的 Bean ③
```

- 整条链的地基是 pom 里的 `spring-boot-starter-jdbc`（传递引入 `spring-jdbc-6.2.19.jar`）。**这也是为什么不需要去中央仓库找 `JdbcTemplate`**——它不是一个要单独引入的库。
- 报错 `Parameter 0 of constructor in ... required a bean of type 'org.springframework.jdbc.core.JdbcTemplate' that could not be found` = 断在 ① 或 ②：要么缺 starter，要么 `spring.datasource` 四个键没配齐。
- **启动成功 ≠ 数据库配通了**：Hikari 懒建池，密码写错也能看到 `Started BeApplication`。第一次真取连接才认证，所以必须靠 `/api/ping-db` 打一枪。

## 4. VS Code Java 环境对齐（`.vscode/settings.json`）

四条都是「不让扩展去猜」：

```json
{
  // ① 语言服务器自己跑在哪个 JVM 上。不配它会下载一个 JRE 塞进 C 盘
  "java.jdt.ls.java.home": "D:\\java",
  // ② 项目编译/索引用的 JDK，必须和 pom 的 java.version=17 对上
  "java.configuration.runtimes": [
    { "name": "JavaSE-17", "path": "D:\\java", "default": true }
  ],
  // ③ 用配了阿里云镜像的那份 settings.xml，而不是内置干净配置
  "java.configuration.maven.globalSettings": "D:\\maven\\conf\\settings.xml",
  // ④ 明确 mvn 在哪
  "maven.executable.path": "D:\\maven\\bin\\mvn.cmd"
}
```

配套事实：JDK 在 `D:\java`、Maven 在 `D:\maven`（本地仓库 `D:\m2repo`，见脚手架那篇）、`settings.json` 里只有绝对路径无任何私密内容，所以**可以提交 git**。扩展侧 26 个里该有的都在（`vscjava.vscode-java-pack`、`redhat.java` 语言服务器本体、java-debug/dependency/test、maven、gradle），**红线不需要重装扩展**。

## 5. 红线归因：永远以 `mvn compile` 为终审

| 现象 | 结论 | 动作 |
|---|---|---|
| IDE 红 + `mvn compile` 也报错，位置一致 | **代码真错** | 改代码 |
| IDE 红 + `mvn compile` 通过 | 编辑器索引问题 | `Ctrl+Shift+P` → `Java: Reload Projects` |
| IDE 全绿 + `mvn compile` 报错 | 极罕见（编码/生成源码） | 以 `mvn` 为准 |

判据理由：`mvn compile` 与 `mvn spring-boot:run`、与将来 CI 用的是同一套编译器，IDE 只是提前显影。

### 5.1 实测：漏写 `public class AreaController {` 会红一整片

写了注解、字段、构造器、方法，却没写类声明与收尾 `}`，编译输出：

```
AreaController.java:[11,15] 需要 class、interface、enum 或 record
AreaController.java:[13,8]  需要 class、interface、enum 或 record
AreaController.java:[15,1]  需要 class、interface、enum 或 record
AreaController.java:[17,8]  需要 class、interface、enum 或 record
AreaController.java:[18,85] 需要<标识符>
AreaController.java:[19,1]  需要 class、interface、enum 或 record
6 errors   BUILD FAILURE
```

- **根因**：Java 文件顶层只允许 `package` / `import` / 类型声明（class/interface/enum/record）。字段、构造器、方法**只能在大括号里**。编译器顺着注解往下找「要修饰的 class」，找到的却是 `private final`，于是报「我需要 class」。
- **为什么红线从第 11 行才开始**：`package`、`import` 本就是合法顶层语句，所以前 6 行不红。
- **只读第一条错误**：第 18 行第 85 列的「需要<标识符>」是解析乱掉后的级联产物；一个真错派生多条，追后面的浪费时间。
- 缩进不影响编译，但成员统一缩进 4 空格能让「漏了 class 那行」一眼可见——这次就是顶格写法让人更难发现。

## 6. 验收与失败关键词对照

```powershell
cd D:\WebGIS\web二维开发\openlayers服务平台开发\BE
& 'D:\maven\bin\mvn.cmd' -B -q compile        # 静默即成功
# 彻底停旧实例（按端口杀，不能按进程名）：杀 maven 后子 java 仍可能占端口
$c = Get-NetTCPConnection -LocalPort 8094 -State Listen -ErrorAction SilentlyContinue | Select-Object -First 1
if ($c) { Stop-Process -Id $c.OwningProcess -Force }; Start-Sleep -Seconds 2
& 'D:\maven\bin\mvn.cmd' -q spring-boot:run
# 另开窗口
curl.exe -s -w "`n耗时 %{time_total}s`n" http://localhost:8094/api/ping-db --max-time 40   # 期望 13
```

| 报错关键词 | 真因 | 修法 |
|---|---|---|
| 编译期 `找不到符号: 类 JdbcTemplate` | import 拼错 / 扩展没索引到依赖 | 查依赖树；`Java: Reload Projects` |
| `required a bean of type 'JdbcTemplate'` | 缺 starter-jdbc 或数据源没配 | 见 §3 |
| `password authentication failed for user "postgres"` | 密码错 | 从 `etl/.env` 的 `PGPASSWORD` 重抄 |
| `FATAL: database "Spatial" does not exist` | 库名错 | 库就叫 `Spatial` |
| `Connection to localhost:5432 refused` | PG 服务没起 | `Get-Service postgresql-x64-18` → `Start-Service` |
| 卡 30s 后 `Connection is not available, request timed out after 30000ms` | 认证/端口/防火墙连不上 | 用 psql 手连对照（`D:\PostgreSQL18.4\data\18\bin\psql.exe`） |
| `relation "admin_area" does not exist` | 连上了但库/搜索路径不对 | psql 里 `\dt` 看表在不在 `public` |
| `HTTP 404` + Spring 错误体 | 路径错 / 没重启 / 类没扫到 | 比对进程启动时间与文件修改时间 |

判读口径：「第一次 0.8s、第二次 0.05s」是懒建池的正常表现，不是性能问题；日志里 `HikariPool-1 - Start completed` 与 curl 返回 `13` 是同一事实的两种证据。当前库中 `admin_area` 13 行、`poi` 16016 行，可用来反证「真在读库」。

## 7. 有意的简化（技术债，记着别忘）

- **SQL 直接写在 controller 里**：正规分层是 controller 收参数 / service 管业务 / repository 管 SQL。后续 `D6` 要把这条 SQL 搬进 `AreaRepository`。
- **`/ping-db` 是开发者探针不是产品功能**：上线前该删或迁到 `/actuator/health`。留着的好处是任何接口报错时先打它，`13` 即说明数据库侧无恙。

## 8. 追加 `/api/build` 的顺序（先 psql 后 Java）

不能省「先在 psql 里把 SQL 跑通」这一步。SQL 用 `json_build_object` + `json_agg` 拼 `FeatureCollection`，`geometry` 走 `ST_AsGeoJSON(geom)::json`；Java 侧 `queryForObject(sql, String.class)` → `objectMapper.readTree(json)` → 返回 `JsonNode`（若返回 `String` 会被再序列化一次，前端拿到双重转义字符串——详见 Controller 那篇的返回类型对照）。
