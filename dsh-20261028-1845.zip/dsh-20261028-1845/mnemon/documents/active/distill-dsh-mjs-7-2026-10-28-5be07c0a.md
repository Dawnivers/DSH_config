---
id: "5be07c0a-bdbc-4239-ac2e-60ebdd629807"
title: "会话提炼流水线 distill-dsh.mjs：备份前把最近 7 天会话榨成摘要（2026-10-28 实测）"
description: "把「周备份不再带会话」的代价补上的完整落地：distill-dsh.mjs 如何分帧解压 session.v4.jsonl.zstd、怎么只提取真人原话（跳过子代理 delegationDepth>0 与碎片会话）、54/185 的过滤效果、publish-dsh.ps1 里摘要年龄警告的三个分支实测，以及 Node zlib 多帧 zstd 只返回首帧这个坑。"
status: "active"
created_at: "2026-10-28T09:27:24.066Z"
updated_at: "2026-10-28T09:27:24.066Z"
content_hash: "267942fa11863142c906618d2088eb9de06c4779b2eb329cf3c3853af6c939dc"
source_paths:
  - "dsh-migration/distill-dsh.mjs"
  - "dsh-migration/publish-dsh.ps1"
  - "dsh-migration/export-dsh.ps1"
  - "dsh-migration/RESTORE.md"
session_ids:
  - "33555a67-ad81-40d9-97e6-8ae94098d75b"
memory_body_ids:
  []
---

# 会话提炼流水线：备份丢会话前，先把原料榨一遍

日期：2026-10-28（Windows，DSH Desktop，用户 `林先语`）

承接文档（本文只写**新增的提炼链路**，不重复它们已有内容）：
- `4f697022-3973-415e-83e6-61435101a435` — 迁移包瘦身落地（97.07 → 10.94 MiB，默认不导 sessions）
- `40db82e5-4bab-4e2a-9a6d-6b98e729b8f5` — 方案 C 实测与 zstd 压缩率 100% 的根因
- `6afd90bd-37d7-4f8c-bbf9-0c641ffc0bf2` — scan-secrets 活体检疫闸（会话曾把活 PAT 带进包）

## 0. 为什么需要这一步

瘦身方案的直接后果是：**会话不进包 ⇒ 电脑坏了会话永久消失**。用户的判断是「会话只是原料，提炼出的长期记忆才是核心」——但原料没了就没法再提炼，所以提炼动作必须在会话消失之前完成。

由此定下的流程：**每周备份前先跑一次提炼 → 读摘要 → 把规则/偏好/坑/决策写进 MEMORY.md → 再推备份**。备份丢掉的只是已经榨干过的对话。

## 1. 坑：Node 的 zstd 解不了多帧

会话文件 `~/.dsh/sessions/<workspace>/<session-id>/session.v4.jsonl.zstd` 是**多帧拼接**（每追加一次内容就压一帧）。

| 尝试 | 结果 |
|---|---|
| `zlib.zstdDecompressSync(buf)` | 只返回**第一帧**——正好是 200 多字节的登录头。看起来"成功"，实际内容全丢 |
| `zlib.createZstdDecompress()` 流式 | 返回 **0 字节** |
| 按 magic `0x28 0xB5 0x2F 0xFD` 逐帧切开再分别解压拼接 | ✅ 正确 |

实测：一个 4.09 MB 文件切出 **1561 帧**，解出 14.9 MB 文本 / 2627 行。这个坑极容易误判——首帧解压"成功"且能产出合法 JSON，只看返回值不会怀疑。

## 2. 会话记录的内部结构（提炼的取料依据）

首条 `session` 记录带元数据：`type, version, id, createdAt, cwd, isSeeded, delegationDepth, agentPreset`。

真实会话（14.9 MB 样本）的类型分布：

| 类型 | 条数 |
|---|---|
| `tool/result` | 402 |
| `tool/call` | 389 |
| `session-log-deepseek/delivery-accepted` | 366 |
| `step/start` | 363 |
| `assistant/message` | 363 |
| `step/end` | 363 |
| `user/message` | 103 |
| `agent/inbox/spliced` | 92 |
| `turn/start` / `turn/end` | 38 / 38 |

- `user/message` 结构：`{type, seq, time, data:{content[], source:{kind,rpcId,clientTimeZone}, role, id}, surfaceOp}`。
- **`data.source.kind` 是区分真人与系统注入的关键**——只保留真人来源，工具回显、系统注入、`agent/inbox/spliced` 一律过滤。
- `delegationDepth > 0` = 子代理会话。

## 3. `distill-dsh.mjs`（7.4 KB，Node 24，无依赖）

```powershell
node .\distill-dsh.mjs --days 7     # 产出 D:\dsh-migration\distill\distill-20261028.md
node .\distill-dsh.mjs --list       # 只列这周有哪些会话，不导出内容
```

每个会话输出：工作目录、轮次、真人消息数、会话 id、用过的工具及次数、**本人说过的每一句话**（原话照录，不做总结不做判断——脚本只取料，判断留给人）。

过滤规则（第一版直接跑 185 个会话、输出过大，才加的）：

| 过滤 | 数量 |
|---|---|
| 7 天内会话文件总数 | 185 |
| 跳过子代理会话（`delegationDepth > 0`） | 117 |
| 跳过碎片会话（真人消息 < 2 句） | 8 |
| **留下真对话** | **54** → 96.7 KB 摘要 |

摘要有 140 KB 硬顶，避免一次塞爆上下文。

## 4. 接进备份流程（警告而非阻断）

`publish-dsh.ps1` 打包前检查最近一次 `distill-*.md` 的年龄，三个分支都实测过：

| 情况 | 行为 |
|---|---|
| 摘要是今天生成 | 不警告 ✅ |
| 没有 distill 目录 | ⚠️「本周还没做会话提炼（最近一次：从未跑过）」 |
| 摘要已 9 天前 | ⚠️「本周还没做会话提炼（最近一次：9 天前）」 |

设计取舍：**只警告不阻止**。备份不该卡在一个需要人判断的步骤上。

`RESTORE.md` 同步新增「每周的固定动作：先提炼，再备份」一节，含三条命令与提炼标准——*半年后还有用吗？是规则/偏好/坑/决策，还是一次性的过程？*

**摘要文件不在备份包里**：`D:\dsh-migration\distill\` 不属于 publish 打包的 pack 目录，所以摘要里的对话原文不会被推上 GitHub（这点在会话 transcript 曾有泄密史的背景下很重要，见 `6afd90bd`）。

## 5. 收尾状态

- 三个 PS 脚本语法全过；`distill-dsh.mjs` 实跑成功；探针文件（`D:\tmp-probe*.cjs`、`tmp-session-probe.jsonl`）已清理。
- 首份摘要已生成：`D:\dsh-migration\distill\distill-20261028.md`（96.7 KB）。
- **未完成**：第一次真正的提炼（从摘要里挑候选写进 MEMORY.md）尚未执行；提议的做法是让子代理读摘要、按「规则/偏好/坑/决策」四类挑候选并带出处，再由用户逐条确认，以免把 30k token 塞进主上下文。

## 6. 源文件

- `dsh-migration/distill-dsh.mjs` — 提炼脚本主体
- `dsh-migration/publish-dsh.ps1` — 打包前摘要年龄警告
- `dsh-migration/RESTORE.md` — 「先提炼，再备份」章节
- `dsh-migration/export-dsh.ps1` — 上游导出（提供 sessions 排除与 `-KeepSessions` 反悔开关）
