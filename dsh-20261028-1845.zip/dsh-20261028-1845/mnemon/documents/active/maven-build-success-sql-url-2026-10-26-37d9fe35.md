---
id: "37d9fe35-39c9-4384-baeb-38b4397ffed5"
title: "构建可信度排障：Maven 增量编译的假 BUILD SUCCESS、文本块 SQL 的编译期盲区、文档↔URL 契约漂移（2026-10-26 实测）"
description: "openlayers服务平台开发 BE 子工程的「验证本身不可信」类故障判据：.class 与 .java 同秒导致 Maven 跳过编译并输出假 BUILD SUCCESS 的识别与 clean 兜底、文本块内 SQL 手误（ELECT/SELECT）编译期零告警只能靠逐字节与 psql 对照、javac 中文报错不可搜时切英文、PowerShell/Python 控制台 GBK 造成的乱码假象、/api/build 与 /api/buildAreas 的文档-代码契约漂移处置原则。"
status: "active"
created_at: "2026-10-26T11:05:14.960Z"
updated_at: "2026-10-26T11:05:14.960Z"
content_hash: "47b6effd79a5149e090a27142bc87ce6de5f45c0d2b82081379c26503e9532be"
source_paths:
  - "BE/src/main/java/com/dawnivers/be/controller/AreaController.java"
session_ids:
  - "d59dfec9-e596-4bbf-96e8-2fc40174d5ac"
memory_body_ids:
  []
---

# 构建可信度排障：三类「验证结果本身在骗你」的情况（2026-10-26 实测）

工作目录 `D:\WebGIS\web二维开发\openlayers服务平台开发`，子工程 `BE\`（Spring Boot 3.5.16 + Java 17 + PostgreSQL/PostGIS + Maven 3.9 `D:\maven\bin\mvn.cmd`）。

本文不重复接口实现细节：`/api/build` 的 SQL 形态、ObjectMapper 构造器注入、`readTree(String)` 受检异常处理、85432 字节验收阶梯见 [/api/build 返回 13 区 GeoJSON 的实现规格与验收基线](2f89c15c-dc27-4607-a604-e2eb083af4cd)；IDE 红线与 mvn 结论冲突的判据表见 [JdbcTemplate 接入与 Java 红线归因](d8eef83f-289b-463a-a53a-4319d6398187)。本文只补这三篇都没覆盖的一层：**当「构建成功」「接口 200」「控制台乱码」这类结论本身不可信时，怎么证伪。**

## 1. 假 BUILD SUCCESS：Maven 增量判断 + 编辑器顺手编译

### 现象

`AreaController` 源码里 `readTree(String)` 抛出的受检异常 `JsonProcessingException` 没有 `throws` 也没 `try/catch`，代码客观上是坏的；但执行：

```powershell
& 'D:\maven\bin\mvn.cmd' -B compile
# [INFO] BUILD SUCCESS
```

### 真因（有两条证据才成立，只看到一条容易误判）

1. **Maven 编译插件做时间戳增量判断**：`.class` 不比 `.java` 旧，就直接跳过整个编译，日志出现 `Nothing to compile - all classes are up to date.`。
2. **VS Code 的 Java 扩展在保存时已经编译过一次**，产出的 `AreaController.class` 时间戳是 `2026/10/26 18:49:32`，与源码改动的**同一秒**——于是 Maven 认定「已经编好了」。

删掉 class 强制重编后立刻暴露真实状态：

```powershell
Remove-Item target\classes\com\dawnivers\be\controller\AreaController.class
& 'D:\maven\bin\mvn.cmd' -B compile
# [INFO] Recompiling the module because of changed source code.
# [INFO] Compiling 3 source files with javac [debug parameters release 17] to target\classes
# [ERROR] AreaController.java:[49,37] 未报告的异常错误 com.fasterxml.jackson.core.JsonProcessingException;
```

### 判据与兜底

| 日志里出现 | 含义 | 该做什么 |
|---|---|---|
| `Nothing to compile - all classes are up to date.` | **这次没有编译你的改动**，其后的 `BUILD SUCCESS` 不可信 | 改 `clean compile` |
| `Recompiling the module because of changed source code.` + `Compiling N source files` | 真的编译了 | 可以相信结论 |

```powershell
# 日常快速验证
& 'D:\maven\bin\mvn.cmd' -B -q compile
# 怀疑「明明没改对却成功」、或编辑器红线与 mvn 结论冲突、或要交付/提交前
& 'D:\maven\bin\mvn.cmd' -B clean compile     # clean 删 target，强制全量
```

`clean compile` 的成本只有几秒，比「被假成功骗着去起服务、再花十分钟查 500」便宜一个数量级。**结论：只要验证结论要用来下判断（而不是只做语法检查），就用 `clean compile`。**

## 2. 文本块里的 SQL：编译期绝对盲区

### 现象

SQL 写在 JDK 17 文本块 `private static final String BUILD_SQL = """ ... """;` 中，第 18 行首单词是 `ELECT json_build_object(`，少了 `S`。编译全绿、启动正常、请求返回 500，数据库报 `ERROR: syntax error at or near "ELECT"`。

### 逐字节取证法（肉眼不可靠时用）

```powershell
$c = Get-Content $path -Encoding UTF8
$c[17]                                    # 第 18 行
[byte[]][char[]]$c[17]                    # 32,32,32,32,69,76,69,67,84,32,... ← 69=E 76=L 69=E 67=C 84=T
Select-String -Path $path -Pattern 'SELECT'
```

字节序列 `69 76 69 67 84` = `ELECT`，一眼定案；同时 `Select-String -Pattern 'SELECT'` 命中不到第 18 行，两条证据互相印证。

### 为什么编译器帮不了你

文本块内容对 javac 而言只是**普通字符串字面量**，没有 SQL 语法、没有关键字高亮、没有拼写检查。**SQL 正确性 100% 推迟到运行期**，且报错点在数据库侧（`BadSqlGrammarException` → 500），不在 Java 侧。

### 规则

- **SQL 先在 `psql` 里跑通，再整段复制粘贴进 Java，不手敲。** 关键字一个字母都不能丢。
- 文本块一旦被「手改缩进/手重敲」，就当新 SQL 重新在 psql 里验一遍。
- 已知文本块隐患清单（本次顺带发现，均不阻断但建议顺手改）：注解与 `public class` 之间空行、`BUILD_SQL =` 行尾多余空格、SQL 缩进不齐、构造器参数逗号后缺空格、方法体缩进不齐。

## 3. 报错语言影响可搜索性

中文 javac 输出 `未报告的异常错误 …` 直接搜索几乎命中不到有效资料；同类问题的英文原文 `unreported exception …; must be caught or declared to be thrown` 一搜即得。

```powershell
$env:JAVA_TOOL_OPTIONS='-Duser.language=en -Duser.country=US'
```

**判断规则：中文报错搜不到时，第一反应是切英文输出，而不是换关键词。**

## 4. 控制台编码造成的两类假象（数据其实是好的）

| 场景 | 假象 | 正确判据 |
|---|---|---|
| PowerShell / Python 打印接口 JSON 里的中文 | 区名显示为 `��ɽ��` | 控制台 GBK 显示问题，非数据问题；设 `$env:PYTHONIOENCODING='utf-8'` 后正常显示 `青山区` |
| `psql` 查询输出中文 | 同样是乱码 | 设 `$env:PGCLIENTENCODING='UTF8'`；或改用接口/文件落盘再读 |

**验证链路的可信判据是「字节与结构」，不是「控制台看起来像什么」**：本次三路交叉验证结果一致——接口 `[HTTP 200] 85166 bytes application/json 0.010059s`、`keys=['type','features']`、`geometry` 反序列化为 `dict`（MultiPolygon）、前五个区名 `['青山区','新洲区','江岸区','江汉区','硚口区']`。

### 与既有基线的数值差异说明

既有文档记的 `85432 bytes` 是 psql 直出对照值；本次 HTTP 实测 `85166 bytes`。两者相差约 0.3%，源于 psql 文本输出与 HTTP 序列化的细微差别（如空白/转义策略），**不是错误信号**。验收时按「同一数量级 + 结构断言通过」判断，别把字节数当精确指纹；真正要盯的是 `geometry` 是否为 `dict`（`str` 才说明 `::json` 丢了）。

## 5. 文档↔实现契约漂移：`/api/build` vs `/api/buildAreas`

`roadmap.md` 约定 `/api/build`，实现里写成了 `@GetMapping("/buildAreas")`；同时方法名仍是 `build`。三方（文档 / URL / 方法名）已经不一致。

处置原则：**契约先定，代码跟随**——保留 `/api/build`，改代码与方法名（`buildAreas` 或保留 `build`，但 URL 必须回对齐文档）。理由是 D6 起前端会照文档写 `fetch('/api/build')`，让代码迁就一次改名，远比让前端和后续所有文档返工便宜。任何一端改动都必须**同步三处**：`roadmap.md`、`@GetMapping` 值、前端 `fetch` 路径与 `vite.config.js` 代理。

同类风险：D8 出现 `/api/poi/{gid}` 这类带参接口时，SQL 必须用 `?` 占位 + 参数数组（`queryForObject(SQL, Long.class, gid)`），**禁止字符串拼 SQL**（SQL 注入入口）。当前 `BUILD_SQL` 无参数，暂时安全。

## 6. 运维侧小坑

- **端口 8094 已被占用**时二次启动的报错是 `Web server failed to start. Port 8094 was already in use.` + `BUILD FAILURE`。这不是代码问题；直接用**已在跑的实例**验证即可（本次即如此），要重启先按端口查 PID 再 `Stop-Process`：

```powershell
$c = Get-NetTCPConnection -LocalPort 8094 -State Listen -ErrorAction SilentlyContinue | Select-Object -First 1
if ($c) { Stop-Process -Id $c.OwningProcess -Force }
```

- 区分「SQL 错」还是「Java 错」的最高效手段：**同一段 SQL 先在 psql 跑一遍**。psql 报语法错 → SQL 问题；psql 通而接口 500 → Java/序列化问题。
