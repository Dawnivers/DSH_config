---
id: "d7826a4a-c9bb-4fbe-bccc-7cacfd399421"
title: "D7 POI 数据勘察与 nearby 空间查询 SQL 实测（武汉 poi 表、16 项字段、无 GiST 索引）"
description: "武汉 GIS 项目 D7：poi 表结构与缺失率实测、D8 接口契约的 bigint/detail_fetched 修正、ST_DWithin(nearby) 计数与最近 N 的 SQL 拆解（::geography 决定米）、索引现状（geom 无 GiST）与不稳定 ORDER BY 问题。"
status: "active"
created_at: "2026-10-27T08:24:57.284Z"
updated_at: "2026-10-27T08:24:57.284Z"
content_hash: "90692af3828fe10a8857ba7a6db76ea8d1d4847911dc1a533b4bc470ddf96dab"
source_paths:
  - "BE/src/main/java/com/dawnivers/be/BeApplication.java"
  - "BE/src/main/resources/application.properties"
  - "FE/docs/roadmap.md"
session_ids:
  - "544d3f24-5202-4b5f-abe5-08df0c3f96d4"
memory_body_ids:
  []
---

# D7：POI 数据勘察 + nearby 空间查询 SQL 拆解

承接 `6b85ed40-4278-4e1f-b061-02a6fc74fc95`（D5 三层边界：PostGIS 算、Java 定形状、controller 管门）、`a20938c7-4625-4107-9544-f9b0633eb334`（geography vs 3857 报数口径）、`266aea70-7a25-4d94-8359-39555b8b651f`（项目总设计，含 ST_DWithin 单位坑）。

## 1. D6 重构验收结论（已通过）

- `mvn -B clean compile` → COMPILE OK；`spring-boot:run` 起服务后三个端点全 200：`/api/hello` 88B、`/api/ping-db` 内容 `13`、`/api/areas` 85166B。
- `/api/areas` SHA256 与早晨旧 JdbcTemplate 实现基线**逐字节一致**：`96F25F6965130C4FA476CBFCD3EC82D9BD8D02BF0B06E3F4D5B75F15BC8BB107`。证明拆分四层并改由 MyBatis Mapper+XML 接管后输出不变。
- git 历史干净：`cc368bd 00 后端工程初始化` / `5053741 01 拆分四层` / `7e52035 02 补 README 与 MyBatis 映射配置`。
- 教训复用：`AreaMapper..xml`（多一个点）曾导致绑定风险；判活要 `clean`，增量编译会说谎；杀实例后日志 `exit code: -1` 属外部终止而非崩溃。

## 2. poi 表结构实测（16 列）

`gid bigint`（契约写 int，实际 bigint，Java 用 `long`）、`amap_id text`、`name text`、`category text`、`typecode text`、`address text`、`adcode text`、`tel text`、`lon/lat numeric`（与 geom 重复存）、`geom geometry(4326)`、`raw jsonb`（高德原始）、`detail jsonb`、`detail_fetched_at timestamptz`、`source text`、`fetched_at timestamptz`。

分类分布与契约 `school|hospital|mall|park` 完全一致：hospital 5347 / mall 4858 / school 4648 / park 1163，合计 **16016**。

缺失率（决定 DTO 空值策略）：
- `tel` 缺 7242（45%）→ 契约的 `tel: null` 降级是必须的；
- `address` 缺 100（0.6%）→ 同样走 null；
- `detail` 缺 16016（**100%**）→ `/api/poi/{gid}` 的 `detail_fetched` 当前恒为 false，契约需注明，或先跑一次详情抓取；
- `adcode` 无缺失，13 个 distinct 值，与 `admin_area` 全部对得上（JOIN 写作 `p.adcode = a.adcode::text`）。

13 区 POI 数：洪山 1940 / 武昌 1681 / 江夏 1634 / 江岸 1382 / 黄陂 1352 / 蔡甸 1336 / 汉阳 1244 / 东西湖 1213 / 硚口 1178 / 新洲 1170 / 江汉 1104 / 青山 582 / 汉南 200。

## 3. nearby 查询实测（测试点 114.36,30.54，半径 800 m）

结果：school 109 / mall 10 / park 3 / hospital 2 = 124 个；最近 5 条为武大校内建筑（53/62/62/67/77 m），距离严格递增，说明单位确实是米、`round()` 生效。武大片区学校占 88% 符合地物特征——**结果合理即等价于"三个要素全对"**。

`ST_DWithin` 三要素：
1. `ST_MakePoint(lon, lat)` —— **经度在前**（与 GeoJSON 一致，与 `ST_X/ST_Y` 命名顺序相反），写反不报错、结果为空（点到南极附近）。
2. `ST_SetSRID(..., 4326)` —— 不声明会报 `Operation on mixed SRID geometries`。
3. `::geography` —— **决定单位是米还是度**。漏掉时 `800` 表示 800 度，全库命中返回 16016 条且不报错。等价写法 `ST_Transform(...,3857)` 更快但武汉纬度有 ~0.85 尺度误差；本项目小半径 + 可读性优先，用 `::geography`。

筛选/精算分工：`WHERE` 用 `ST_DWithin`（返回布尔，计算量小）粗筛，`SELECT` 里才用 `ST_Distance` 算精确米数；否则每行都要算精距。`ORDER BY` 可引用 SELECT 别名（PG 特性，标准 SQL 不允许）。

## 4. 发现的三个待办（D8 前）

1. **geom 上没有 GiST 索引**：`pg_indexes` 只有 `poi_pkey1(gid)`、`poi_amap_id_key(amap_id)`、`idx_poi_category`、`idx_poi_adcode` 四个 btree。当前 16016 行是 Seq Scan + 逐行算距，能跑但会随数据量/并发变慢。补 `CREATE INDEX idx_poi_geom ON poi USING GIST (geom); ANALYZE poi;` 后 `EXPLAIN ANALYZE` 应从 Seq Scan 变 Bitmap Heap Scan。**这是本项目第一次真正依赖空间索引的场景。**
2. **`ORDER BY distance_m LIMIT 5` 结果不稳定**：第 5、6 名距离相同（62 m 出现两次）时 PG 任选其一，会让 D10–D11 的断言偶发失败（flaky test）。修法：`ORDER BY distance_m, gid`。
3. **边界点未验证**：汉南区约 (114.05, 30.31) 800 m 内可能 0 条。`/api/poi/nearby` 必须返回 `{"count":0,"by_category":{全0}}` 而不是 500。

另：`round(ST_Distance(...))` 返回 `double precision`（值恰为整数）；需整数可 `::int`。

## 5. 契约修正建议（roadmap.md §5）

| 契约原文 | 实际 | 建议 |
|---|---|---|
| `"gid": 10231` | bigint | 标注 bigint / Java `long` |
| `address` 示例为完整地址 | 100 条 null | 保持 null 降级，不改 |
| `detail_fetched: false` | 100% 未抓详情，恒 false | 注明"当前恒为 false"或补详情抓取 |

## 6. D8 迁移到 Java 的形态

Mapper 方法签名用 `@Param("lon") double lon, @Param("lat") double lat, @Param("radius") double`，XML 用 `#{}` 预编译占位（安全），**不用 `${}`**；`LIMIT #{limit}` 在 PG JDBC 下可用。DTO 先用 `record PoiDto(...)` + 手写 `RowMapper`（或开 `map-underscore-to-camel-case` 试自动映射），目标是先验证 record+RowMapper+Jackson 全链路，接口留到 D8。

## 7. 未决

- 是否要把 gid bigint / detail_fetched 恒 false 两条改动直接写进 `FE/docs/roadmap.md` §5，待用户确认。
- GiST 索引是否由代理代建（属数据库变更），待用户选择。
- BE 的 README 仍需补"clone 后复制 `application-local.properties.example` 并填密码"这一必读步骤。
