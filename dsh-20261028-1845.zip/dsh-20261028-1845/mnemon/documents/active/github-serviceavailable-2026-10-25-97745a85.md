---
id: "97745a85-22a8-4580-b9fc-4a9a9595df48"
title: "GitHub 提交「未关联账号」的诊断与修复（ServiceAvailable 仓库）+ 推送前三道检查（2026-10-25）"
description: "FE 仓库首次推送到 GitHub 后的体检记录：提交作者用的是 Gitee noreply 邮箱导致 GitHub 显示「未关联账号」、贡献图不亮；给出只改 --local 配置 + rebase --root --exec --author 保留原时间 + force-with-lease 的修复步骤（截至记录时尚未执行），以及推送前「.env 忽略 / 暂存区扫密钥 / 代理 7897 可用」三道检查与各目录该不该建独立仓库的结论。"
status: "active"
created_at: "2026-10-25T14:34:07.786Z"
updated_at: "2026-10-25T14:34:07.786Z"
content_hash: "e00434995d0838d9e05517e53678f4ec77af5ff93e2a9f1cd2fae58011150b9b"
source_paths:
  - "FE/.gitignore"
  - "FE/.env.example"
  - "FE/docs/roadmap.md"
session_ids:
  - "a0ac1b4a-1bd3-412a-b103-53ae75976028"
memory_body_ids:
  []
---

# GitHub 提交未关联账号：诊断与修复

## 1. 背景与仓库状态

FE（Vue 3 + OpenLayers）首次把当日成果推到 GitHub：

- 远端：`https://github.com/Dawnivers/ServiceAvailable.git`，**public**，默认分支 `main`，GitHub 侧显示 25 KB
- 提交历史 3 条：`5aa3832 00项目初始化` → `2acf369 00_1项目初始化` → `86a20c1 feat: 图层控制面板与 POI 图层接入（Pinia store + ImageWMS）`
- 最新提交 11 个文件、+635/−19（`LayerPanel.vue` 289 行、`docs/roadmap.md` 228 行、两张设计稿 PNG、`.gitignore` 加 `*.err`、删模板残留 `stores/counter.js`）
- 本地 `.git` 约 1.4 MB，跟踪文件 22 个

同日产出内容的 as-built 记录见 `05d1317d-4e21-4582-8c4a-80cab1cc825b`（前端结构）与 `8328e42a-03f8-4b41-b3a7-de40645db95d`（POI/GeoServer 实证），本文只记仓库与推送这一层。

## 2. 体检结论：仓库是干净的，问题只在作者归属

用户凭直觉说"提交得有点问题"，实测逐项核对：

| 检查 | 结果 |
|---|---|
| 工作区 | 干净，`## main...origin/main` 无未提交/未推送 |
| 误提交（`node_modules` / `dist` / `.env` / 日志） | ✅ 无 |
| 全仓库密钥扫描（跟踪文件） | ✅ 无真实 key |
| `.env.example` | 只有「你的天地图key」占位符（长度 8、非 32 位 hex）→ 先前一次 `tk=` 命中是**假阳性** |
| 提交作者 | ❌ 三条全部 `author=(未关联账号)` |

作者一行：

```
dawnivers <16738257+dawnivers@user.noreply.gitee.com>
```

GitHub 按邮箱匹配账号，这个 Gitee noreply 邮箱它不认识，于是**没有头像、点作者名进不去 profile、贡献图不亮**；对外看像"别人的仓库"。

**排错方法论**：`git log --format='%h %an <%ae>'` 只能看到"本地认为的作者"；"是否关联到 GitHub 账号"必须靠远端/API 侧判断——查仓库最近提交的作者归属，才看到 `(未关联账号)`。本地一切正常 ≠ 远端归属正确。

## 3. 修复方案（截至记录时尚未执行，等用户确认）

GitHub 数字 ID 由公开 API 查得 `304228860`（login `Dawnivers`），对应 noreply 邮箱 `304228860+Dawnivers@users.noreply.github.com`。

```powershell
cd D:\WebGIS\web二维开发\openlayers服务平台开发\FE

# 关键：用 --local，别用 --global，否则会把 Gitee 项目的作者一起改掉
git config --local user.name  "Dawnivers"
git config --local user.email "304228860+Dawnivers@users.noreply.github.com"

# 改写历史里所有提交的作者；--author 而非 --reset-author，原提交时间保持不变
git rebase -r --root --exec 'git commit --amend --no-edit --author="Dawnivers <304228860+Dawnivers@users.noreply.github.com>"'

git log --format='%h  %an <%ae>  %ad  %s' --date=short   # 校验三条都是新邮箱
git push --force-with-lease origin main                  # 比 --force 安全：远端被他人动过会拒绝
```

风险判断：首次改写本仓库历史，但只有 3 个提交、无协作者、`--force-with-lease` 兜底。验证方式是改完**用 API 复查作者是否变为 `Dawnivers`**，而不是只看本地 `git log`。

## 4. 推送前三道检查（固定成本约 5 秒，建议成为习惯）

| 检查 | 命令/判据 | 本次结果 |
|---|---|---|
| 敏感文件是否被忽略 | `git check-ignore -v .env` | `.gitignore:17:.env` ✅ |
| 暂存内容里有没有 key | 对 `git diff --cached` 扫 `sk-` / `ghp_` / `github_pat_` / 天地图 tk / 16 进制长串 | ✅ 零命中 |
| 代理是否可用 | `127.0.0.1:7897` 监听 + `git config` 的 `http.https://github.com.proxy` | ✅（此前一次 `Connection was reset` 就是代理没开） |

另：`.dev.log` / `.dev.err` 是 dev server 启动时用 `Start-Process -RedirectStandardOutput/-RedirectStandardError` 重定向出的控制台日志（`.dev.err` 空 = 没报过错）。`.gitignore` 里 `*.log` 已覆盖前者，补 `*.err` 覆盖后者；文件被 dev server 占用时 Windows 删不掉，**留着当日志但不进仓库**是更省事的选择。

## 5. 仓库格局（后续决定）

| 目录 | 处理 |
|---|---|
| `FE` | ✅ `ServiceAvailable`（已推） |
| `api`（Spring Boot） | 建议单独一个仓库，D5 建项目时一起 init |
| `etl` | 暂不推（高德采集逻辑）；`data/raw/` 与 `*.sql` 永不推 |
| `Project`（vanilla 对照版） | 不推，本地冻结 |
| `styles/`（SLD） | 属服务端配置，D20 一起整理进部署仓库更合理 |

遗留小瑕疵（不阻塞）：`README.md` 仍是 create-vue 模板文案；两个初始化提交语义重复，可 squash 但改写历史收益小。
