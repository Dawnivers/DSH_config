---
id: "30e3d3c7-0ab7-43c6-a88a-c9592c046c68"
title: "Spring Boot Controller 层约定与返回类型选择：HelloController 基准接口、请求九步链路、404/405/500 归因与 Map/POJO/record/JsonNode 判据（实测）"
description: "openlayers服务平台开发 BE 子工程 controller 层落地参照：包名改为 com.dawnivers.be 后的实测编译状态、curl 404 的 JSON 基线体（无模板引擎故非 Whitelabel HTML）、@RestController+@RequestMapping+@GetMapping 各自职责与写错后果、DispatcherServlet 九步链路与 404/405/500 卡点、Controller 单例导致的线程安全红线、四种返回类型对照表与「结构谁定的」口诀、String 返回 text/plain 陷阱、无 devtools 时必须手动重启、PowerShell 调用运算符 & 踩坑。"
status: "active"
created_at: "2026-10-26T07:16:47.876Z"
updated_at: "2026-10-26T07:16:47.876Z"
content_hash: "7e312000654c3b7dfc6d023f6d3a28f1c5b51bfbb15e3b13faece98f294fe0b9"
source_paths:
  - "BE/src/main/java/com/dawnivers/be/BeApplication.java"
  - "BE/src/main/java/com/dawnivers/be/controller/HelloController.java"
  - "BE/pom.xml"
session_ids:
  - "0f6ee982-78ad-41cc-b762-2dd6c33cad40"
memory_body_ids:
  []
---

# Controller 层约定与返回类型选择（实测）

属于 BE 子工程。目录契约见 [BE(api) Spring Boot 3.5.16 后端脚手架](7eab7ab9-b0b8-4f01-a2a7-09444c6ffdea)；入口类与首次启动见 [Spring Boot 入口类与首次启动验收](753c5a7a-347a-4270-ab07-3c64460c8fcf)；总选题见 [全链路 GIS 项目设计](266aea70-7a25-4d94-8359-39555b8b651f)。本文只记 controller 这一层。

## 1. 当前实测状态

包名已从生成器的 `com.example.be` 改为 **`com.dawnivers.be`**，目录同步为 `BE\src\main\java\com\dawnivers\be\`，入口类名 `BeApplication`（`ApiApplication` 只是设计稿里的叫法）。`mvn compile` 输出 `Compiling 1 source file with javac [debug parameters release 17]` → `BUILD SUCCESS`。

启动后按端口验证（8094 已确认无残留进程）：

```
Get-NetTCPConnection -LocalPort 8094 -State Listen
→ :: 8094 Listen OwningProcess 34708        （:: 是 IPv6 通配，Windows 同时接受 IPv4）

curl.exe -i http://localhost:8094/
→ HTTP/1.1 404 / Content-Type: application/json
  {"timestamp":"...","status":404,"error":"Not Found","path":"/"}
```

**基线要更正**：早先预期是 Whitelabel 白页 HTML，实际是 **JSON**。原因是 pom 只有 `starter-web`、没有模板引擎，`curl` 的 `Accept: */*` 被协商到 `BasicErrorController` 的 JSON 分支。这个 404 JSON 体是「服务活着、只是没这条路由」的标准基线，也是后续统一 `{code,message}` 错误约定的改造起点。

## 2. 三条命令层踩坑

| 现象 | 真因 | 写法 |
|---|---|---|
| `'D:\maven\bin\mvn.cmd' -B spring-boot:run` → `ParserError: 表达式或语句中存在意外的标记"-B"` | PowerShell 把带引号的路径当**字符串字面量**，不是命令 | 引号开头必须配调用运算符：`& 'D:\maven\bin\mvn.cmd' -B spring-boot:run` |
| — | `D:\maven\bin` 本已在 PATH，`Get-Command mvn` 能直接找到 | 日常直接 `mvn -B spring-boot:run`；全路径只在路径含空格或需指定版本时用 |
| `curl -i` 行为异常 | PowerShell 的 `curl` 是 `Invoke-WebRequest` 别名 | 必须写 `curl.exe` |

规律：**开头被引号包住的东西，前面必须有 `&`**；不加引号的路径 PowerShell 自会当命令。`&` 是「执行」，`.` 是「在当前作用域执行 .ps1」，别混用。

## 3. HelloController：最小基准接口

路径 `BE\src\main\java\com\dawnivers\be\controller\HelloController.java`：

```java
package com.dawnivers.be.controller;                     // ① 包 = 目录，且是 be 的子包

import java.time.LocalDateTime;                          // ② JDK 类在前
import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.web.bind.annotation.GetMapping;   // ③ 第三方在后
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController                                          // ④ Bean + 返回值直接序列化为 JSON
@RequestMapping("/api")                                  // ⑤ 类级前缀
public class HelloController {

    @GetMapping("/hello")                                // ⑥ GET /api/hello
    public Map<String, Object> hello() {
        Map<String, Object> body = new LinkedHashMap<>(); // ⑦ 局部变量，不是成员字段
        body.put("message", "BE is up");
        body.put("service", "be");
        body.put("port", 8094);
        body.put("time", LocalDateTime.now().toString());
        return body;
    }
}
```

- import 分两组是排版惯例（IDEA 默认行为），非语法要求。
- 用 `LinkedHashMap` 而非 `HashMap`：后者不保证键顺序，调试时字段顺序每次都可能变。
- **`/api` 前缀漏掉接口就变 `/hello`**——注意 FE 代理也走 `/api`，两者同名纯属巧合，是两个不同的东西。
- 验收：`curl.exe -i http://localhost:8094/api/hello` → `200` + `Content-Type: application/json` + 加了引号的 JSON 对象（引号即证明过了 Jackson）。

## 4. 请求的实际九步链路

```
① 客户端 GET /api/hello
② 内嵌 Tomcat 收下 → 交给 DispatcherServlet（唯一总调度）
③ 查路由表：/api/hello + GET 命中哪个方法
④ 反射调用该方法（Controller 是单例，不是每次 new）
⑤ 方法体执行 → return 一个 Map
⑥ 拿到返回值（此刻它还不是 HTTP 响应）
⑦ 选消息转换器：非 String → MappingJackson2HttpMessageConverter → JSON 字符串
⑧ 设状态码 200 + Content-Type
⑨ 写响应体 → Tomcat 发回
```

路由表在**启动时**由 `RequestMappingHandlerMapping` 扫描 controller 注释登记，不是每请求现算。

关键归因：**404 和 405 都卡在第 ③ 步，方法根本没执行**；只有 500 是进来了、抛在中间。所以见 404/405 时翻代码逻辑是浪费时间，只查四件事——URL 拼写、类级前缀、方法注解、包是否在 `be.controller` 下（不在就扫不到）。

| 状态码 | 卡点 | 代码执行了吗 | 查什么 |
|---|---|---|---|
| 404 | ③ 查表未命中 | 否 | 路径/前缀/包位置 |
| 405 | ③ 路径命中但动词不符 | 否 | 方法是否写成 `@PostMapping` |
| 500 | ⑤ 方法内抛异常 | 是 | `spring-boot:run` 窗口的堆栈，不是 curl |
| 200 | 一路到 ⑨ | 是 | — |

## 5. `@RequestMapping` 与 `@GetMapping`

`@GetMapping("/hello")` **完全等价于** `@RequestMapping(value="/hello", method=RequestMethod.GET)`。它不是新机制，是 Spring 4.3 起的**组合注解**：`@GetMapping` 自身带元注解 `@RequestMapping(method=GET)`，并用 `@AliasFor` 把 `value` 别名到 `@RequestMapping.path`；正因为动词已钉死，它**没有** `method` 属性，写 `@GetMapping(method=POST)` 直接编译报错。

| 场景 | 用哪个 |
|---|---|
| 方法级、单动词 | `@GetMapping`/`@PostMapping`（语义自明） |
| 类级公共前缀 | `@RequestMapping`（多动词共享前缀） |
| 同路径 GET+POST | `@RequestMapping(value, method={GET,POST})` |
| 需要 `produces`/`consumes`/`params` | 都行，写在实际使用的那个上 |

两条红线：

1. **不要写不带 `method` 的 `@RequestMapping` 去暴露接口**——method 为空表示全动词匹配，会收下 GET/POST/PUT/DELETE/PATCH；既让本该只读的接口能被 DELETE 打，又让 405 这个诊断信号彻底消失。
2. **类级不要限定动词**（`@RequestMapping(value="/api", method=GET)`）——会株连类内所有方法，里面再写 `@PostMapping` 无法路由。

若想显式声明响应格式，加 `produces = MediaType.APPLICATION_JSON_VALUE`：`Accept: text/html` 时会得到 **406**，而不是莫名其妙变 500。

## 6. 线程安全红线（Controller 是单例）

启动时只创建一个 Controller 实例，所有请求共用、方法被并发调用：

```java
private Map<String,Object> body = new HashMap<>();   // ❌ 两个请求互改同一个 Map
Map<String,Object> body = new LinkedHashMap<>();     // ✅ 一律局部变量
```

症状特征：偶尔串数据、压测才复现、本地测不出来。**Controller 里只放无状态的东西（注入的 Service/JdbcTemplate），请求相关数据全用局部变量。**

## 7. 四种返回类型：同一份 JSON，四副身子

同一份 POI 数据，四种写法产出的 JSON 完全一样，区别在「类型有多强」和「结构由谁决定」。

| | 类型安全 | 代码量 | 字段拼错 | 适合 |
|---|---|---|---|---|
| `Map<String,Object>` | 无 | 中 | 静默多/少字段 | 临时接口、动态键（如按分类聚合） |
| POJO | 强 | 大（字段+getter+setter，6 行/字段） | 编译报错 | 老项目、需 setter 的可变对象 |
| `record` | 强 | 极小（一行） | 编译报错 | **固定结构响应 DTO 首选**；不可变、天然线程安全；Jackson 2.12+ 原生支持，Boot 3.5 无需配置 |
| `JsonNode` | 无 | 极小 | 运行时才 `null` | GeoJSON、第三方透传、SQL 直出 |

- POJO 坑：Jackson 默认只认 `public` getter 或 `public` 字段，写了 `private` 字段却漏 getter，该字段在 JSON 里**静默消失**、不报错。
- `JsonNode` 用法：`objectMapper.readTree(jdbcTemplate.queryForObject(SQL, String.class))`，字段名/顺序/null 全保持 SQL 原样——但 `node.get("features")` 拼错只返回 `null`。
- **`String` 是陷阱不是第五种**：`@RestController` 返回 `String` 走 `StringHttpMessageConverter`，`Content-Type: text/plain`，`curl -i` 看着像对的但 `json.load` 直接挂。要 JSON 就返回对象，别返回手拼字符串。
- `ResponseEntity<T>` 是另一个维度——给任意返回类型套壳以控制状态码/响应头（`ResponseEntity.status(404).body(err)`），做 `{code,message}` 错误约定时才需要；现在直接返回对象就是默认 200。

**口诀：结构我自己定的 → `record`；结构别人定的（GeoJSON/SQL 直出）→ `JsonNode`；结构还没想清楚 → 先 `Map`，稳定后升级 `record`。**

本项目落地：

| 接口 | 返回类型 |
|---|---|
| `/api/hello` | `Map`（三四个字段，不值得建类） |
| `/api/ping-db` | `Integer`（单个数字，连 Map 都不必） |
| `/api/build` | `JsonNode`（GeoJSON 结构由规范定，写 DTO 自找麻烦） |
| `/api/poi/{gid}` | `record`（字段固定约 12 个，类型安全值钱） |
| `/api/poi/nearby` | `record` + 嵌套 record/List |

**一眼判断走了哪个转换器**：看 `curl -i` 的 `Content-Type`——`application/json` = Jackson（Map/POJO/record/JsonNode 都在此）；`text/plain` = 返回了裸 String（多半是坑）；`text/html` 或缺失 = 走了视图解析（注解误用 `@Controller`）。排查「前端 JSON.parse 报错」比看代码快。

## 8. 改代码不会自动生效

pom 里**没有 `spring-boot-devtools`**，所以改 `.java` 后必须：

```powershell
# 回正在跑 spring-boot:run 的窗口：Ctrl+C
Get-NetTCPConnection -LocalPort 8094 -State Listen -ErrorAction SilentlyContinue   # 应为空
mvn -B spring-boot:run
```

Ctrl+C 有时只杀 mvn、子 java 还活着，下次启动就会 `Port 8094 was already in use`，所以必须显式确认端口释放。热重启等加测试时再引入 devtools——初期手动重启反而让「哪次改动导致什么」的反馈粒度更清晰。
