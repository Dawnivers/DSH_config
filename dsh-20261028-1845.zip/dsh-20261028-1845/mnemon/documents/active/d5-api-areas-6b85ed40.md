---
id: "6b85ed40-4278-4e1f-b061-02a6fc74fc95"
title: "D5 后端落地实录：/api/areas 实现、三层职责边界与本地密码方案"
description: "武汉 GIS 项目 D5 阶段后端落地记录：AreaController 的 /api/areas（13 区 GeoJSON，实测 85166 字节）实现链路、PostGIS/Java/Controller/前端 的三层边界判据与反例、Spring profile 本地密码方案（不用 .env）、以及 ELECT 手误/增量编译说谎/孤儿 JVM 等实测坑。"
status: "active"
created_at: "2026-10-26T11:48:37.602Z"
updated_at: "2026-10-26T11:48:37.602Z"
content_hash: "1fe7e4b1fde0ab45ea833c3c560df00941776036c84d552dab7047732ebb9e1e"
source_paths:
  - "BE/src/main/java/com/dawnivers/be/controller/AreaController.java"
  - "BE/src/main/resources/application.properties"
  - "BE/.gitignore"
  - "FE/vite.config.js"
  - "FE/docs/roadmap.md"
session_ids:
  - "ccc858c2-2a10-428c-91d2-25d1453d699e"
memory_body_ids:
  []
---

# D5 后端落地实录：/api/areas 与三层边界

日期：2026-10-26。项目根 `D:\WebGIS\web二维开发\openlayers服务平台开发`（BE = Spring Boot 3.5.16 + JDK17 + PostGIS，FE = Vite + OpenLayers，GeoServer 8080）。
本记录承接设计文档 `266aea70-7a25-4d94-8359-39555b8b651f`（§8 只写了"应该长什么样"的包结构），补的是**实际建起来、跑通并量过的版本**。

## 1. 已落地的接口事实（以运行中的代码为准）

| 端点 | 实现 | 实测 |
|---|---|---|
| `GET /api/hello` | `HelloController` | Web 层通 |
| `GET /api/ping-db` | `AreaController` 内直接 `jdbcTemplate.queryForObject("select count(*) from admin_area", Long.class)` | `13` |
| `GET /api/areas` | `AreaController.areas()`，一次性把 13 区拼成 FeatureCollection | `[HTTP 200] 85166 bytes`，`FeatureCollection` / 13 features / MultiPolygon / 0.009s |

- 直连 8094 与走 Vite 5173 代理（`/api → http://localhost:8094`，**不加重写**）返回**字节数完全一致**，说明代理未改写内容。
- 响应结构：顶层 `keys = ['type','features']`；`properties = {adcode:int, name:str, level:'district', center:[lon,lat]}`；`geometry` 是 GeoJSON **对象**（SQL 里 `ST_AsGeoJSON(geom)::json`，漏了 `::json` 会退化成字符串）。
- 中文必须用 UTF-8 解码后验证（PowerShell 直接输出是乱码，`['青山区','新洲区','江岸区','江汉区','硚口区']` 才对）。

## 2. 命名：文档跟着代码走

用户先说"以后按 buildAreas 来"，但代码最终落的是：

```java
@GetMapping("/areas")                       // 第 42 行
public JsonNode areas() throws JsonProcessingException { ... }
```

结论：**以运行中的代码为准**，`FE/docs/roadmap.md:25` 从 `/api/build` → `/api/buildAreas` → 最终改成 `/api/areas`。`/areas` 是名词，符合 `GET` 语义，与 D8 的 `/api/poi/{gid}`、`/api/stats/coverage` 风格统一，不再改。
连带教训：`curl .../api/area` 少一个 `s` 就是 404 —— 这种 404 的响应体里带 `"path"`，逐字符对 `@GetMapping` 即可。

## 3. 三层边界（本轮讨论的最终定稿）

一句话记忆点：**PostGIS 算，Java 定形状，controller 管门，前端管画。**

| 边界 | 归谁 | 判据 |
|---|---|---|
| 算什么 | PostGIS：`ST_DWithin` / `ST_Distance` / `ST_AsGeoJSON` / `group by` / `order by … limit` | 能一条 SQL 算完的，绝不在 Java 里循环算 |
| 长什么样 | Java（DTO / `record`）：字段名、类型、空值策略、单位换算、缺键补零 | 对外承诺的字段集合只能由带类型的代码定义 |
| 怎么画 | 前端：分级配色、图例、热力图叠加、标签避让 | 渲染逻辑一律不进 BE |
| 参数校验与路由 | controller：`@RequestParam` 类型转换、值域校验（如 `0 < radius <= 5000`）、404/400 | controller 里不该有 SQL 与业务规则 |

改动落点对照：改半径/取最近 N 个 → SQL；改精度/加字段 → Java（+SQL 取列）；改颜色/分级 → 前端；geometry 变字符串 → SQL 漏 `::json`。

### 三个反例（各自的坏法）

1. **让 SQL `json_build_object` 把整个响应结构拼出来**：字段漏写静默通过、分类映射逻辑复制多份、无法单测、换库重写。
2. **把空间计算搬进 Java**（全表 16016 个点进内存手算 haversine）：丢 GiST 索引（PostGIS 只碰附近几十个）、跨纬度距离偏、最终会重写出 buffer/intersects/contains。
3. **controller 里直接写 SQL**（`/api/ping-db` 的现状）：今天只有一行没问题，是技术债；**抽出去的信号 = 同一查询出现第二处调用，或方法体超过 10 行**。

### 例外清单（别把边界做成教条）
- 小范围精算：SQL `ST_DWithin` 粗筛走索引 → Java 用 JTS 精算（复杂缓冲区/合并面）。
- 坐标转换：GCJ→WGS84 已在 ETL 入库前完成，BE 出库不再转换，避免层层转换。
- 几乎纯 CRUD：`select … where id = ?` 直接 DTO 直出，别套三件套。
- geometry 进 MyBatis：先用 `ST_AsGeoJSON(geom) AS geom_json` 返 String，别一上来写 TypeHandler。

## 4. 为什么不全让数据库吐 JSON 文本

Java 侧仍需要 `JsonNode`/DTO 这一层的理由：字段契约与类型安全（externally promised shape）、空值与缺键策略、可单测、可复用（导出 Excel、生成瓦片缓存时不用复制 SQL）。build/areas 这种"整块透传"保留 `JsonNode` 是合理的特例；业务接口用 `record` DTO。

## 5. 本地密码方案（不要用 .env）

关键事实：**Spring Boot 不读 `.env`**。`.env` 是 Vite / `python-dotenv` 的习惯（`FE/.env` 存天地图 tk，`etl/.env` 存 PGPASSWORD / AMAP_KEY）；JVM 的对应物是**属性源 + profile**。

采用的是 profile 方案：
1. `application.properties` 里删掉明文密码行，加 `spring.profiles.active=local`；
2. `src/main/resources/application-local.properties` 存真实密码（`.gitignore` 里已有 `application-local.properties`，当初留的口子正好用上）；
3. 提交 `application-local.properties.example`（`spring.datasource.password=CHANGE_ME`）当模板，README 写明"复制后填值"；
4. `git check-ignore -v src/main/resources/application-local.properties` 必须**有输出**（无输出 = 没被忽略）；
5. 启动日志出现 `The following 1 profile is active: "local"` 才算生效；`/api/ping-db` 出 `13` 才算密码读到了。

补充事实：
- 该 BE 仓库当时**零提交**（`fatal: … does not have any commits yet`），所以密码尚未进 git 历史——这是处理成本最低的时刻。
- `application-local.properties` 缺失时 Spring **不报错**，只是密码为空、首次查库认证失败（Hikari 懒启动）。
- 环境变量方案（`${PGPASSWORD}`，`psql` 也认这个名字）适合部署/临时用：变量缺失会启动失败并明确报 `Could not resolve placeholder`，比空密码静默连库好；**不要用 `setx`**（明文进注册表 HKCU\Environment 且新终端才生效）。
- 优先级：命令行参数 > 环境变量 > `application-{profile}.properties` > `application.properties`。两者可并存：`spring.datasource.password=${DB_PASSWORD:dummy}`。

## 6. D5 实测踩过的坑（都有真实证据）

1. **SQL 文本块手误编译期查不出**：第 18 行的 `ELECT json_build_object(` —— 少了 `S`，编译 BUILD SUCCESS 但运行报错。
2. **`mvn compile` 增量编译会说谎**：代码有编译错误时也报过 BUILD SUCCESS；判据要看是否 `Recompiling … because of changed source code` 与 `Compiling N source files`。
3. **改 Java 必须重启，Ctrl+C 常留孤儿 JVM**：多次 404 都是旧 JVM（旧类）在 8094 上；重启流程 = 查 `Get-NetTCPConnection -LocalPort 8094 -State Listen` → `Stop-Process -Id <pid> -Force` → 等 2s → `mvn -q spring-boot:run`。
4. **Jackson 的 `readTree(String)` 声明了受检异常** `JsonProcessingException`，必须在方法签名声明或用 try/catch——这是"受检异常"的实例，不是随便加的。
5. **Jackson 类型决定转换器**：返回 `JsonNode` → `application/json`；返回 `String` → `text/plain`（前端拿不到对象）。"交给 Jackson 有什么用"的答案就在这里：它按目标类型选 `HttpMessageConverter` 并做序列化，不需要自己拼 JSON 字符串。
6. **`@SpringBootApplication` 的组件扫描根决定会不会 404**：`HelloController` 一度因包位置在扫描根之外而 404。
7. 端口现状：8094（BE）/ 8080（GeoServer）/ 5173（Vite）三服务可同时存活。

## 7. D6 待办（不改对外行为）

1. 上 MyBatis（`mybatis-spring-boot-starter`），SQL 从 Java 常量搬进 `resources/mapper/*.xml` 或注解 Mapper；
2. 拆包：`controller`（只管 HTTP）/ `service`（编排 + 组装 DTO）/ `repository`（SQL + RowMapper）/ `dto`（`record`）；
3. **验收标准：三个接口 `curl` 返回逐字节不变**（`/api/areas` 仍是 85166 bytes、13 features）。行为不变 + 结构变好 = 重构成功；行为变了就是顺手改功能，必须单独提交。
4. `roadmap.md §5` 还缺 `/api/areas` 的契约条目（13 features / ≈85 KB / 字段说明），D12 前端消费时会用到。
