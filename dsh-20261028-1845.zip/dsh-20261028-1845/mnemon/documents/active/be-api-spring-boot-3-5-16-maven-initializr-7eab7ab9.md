---
id: "7eab7ab9-b0b8-4f01-a2a7-09444c6ffdea"
title: "BE(api) Spring Boot 3.5.16 后端脚手架：Maven 目录契约、Initializr 版本现实与踩坑"
description: "openlayers服务平台开发 的 BE 子工程（Spring Boot 3.5.16 + Maven）落地参照：Maven 标准目录逐项职责、与 Vite 的对照、start.spring.io 只发 4.x 导致的版本冲突与 starter 改名、Initializr 一行命令、git 不跟踪空目录、PowerShell 反引号续行踩坑与修复记录、验收命令。"
status: "active"
created_at: "2026-10-26T03:39:27.577Z"
updated_at: "2026-10-26T03:39:27.577Z"
content_hash: "3ae440806325c9851cee4a20b82b661763175cfa8064ef2ccba7a69dadee0173"
source_paths:
  - "BE/pom.xml"
  - "BE/.gitignore"
session_ids:
  - "a05b6b01-a1d6-4688-9f46-c38b328fa5b5"
memory_body_ids:
  []
---

# BE(api) 后端脚手架落地参照（2026-10-26）

工作目录 `D:\WebGIS\web二维开发\openlayers服务平台开发`，子工程 `BE\`（Maven `artifactId: api`，`0.0.1-SNAPSHOT`），Spring Boot **3.5.16** + Java 17 + PostgreSQL 驱动 `42.7.11`。
总项目选题、数据与里程碑见 [OpenLayers + GeoServer + Spring Boot 全链路 GIS 项目设计](266aea70-7a25-4d94-8359-39555b8b651f)；本文只记录 BE 侧的目录契约、脚手架工具与实测踩坑。

## 1. 当前实际结构（检查证据，非预估）

```
BE\
├── .git\                （独立仓库，父目录不是 git 仓库）
├── .gitignore           （57 B / 5 行：target/  *.iml  .idea/  application-local.properties  *.log）
├── pom.xml              （1574 B）
└── src\
    ├── main\
    │   ├── java\com\example\api\controller\
    │   └── resources\
```
Maven 环境：本地仓库 `<localRepository>D:\m2repo</localRepository>` 写在 `D:\maven\conf\settings.xml`（用户硬要求：依赖不放 C 盘），已 `dependency:resolve` 通过，postgresql 驱动从 aliyun-public 拉取成功；`mvn compile` 目前是 `No sources to compile`（还没有 `.java`）。

## 2. 这套布局是 Maven 约定，不是 Spring 发明的

`src/main/java`、`src/main/resources`、`src/test/java` 出自 [Maven Standard Directory Layout](https://maven.apache.org/guides/introduction/introduction-to-the-standard-directory-layout.html)，核心是**约定优于配置**：不用告诉构建工具代码在哪。Gradle 与 start.spring.io 生成器照抄同一套，所以任何 Java 教程/公司项目都是这几个名字。技术上可用 `pom.xml` 的 `<sourceDirectory>` 改，但改了整个生态都要跟着配，没人改。

| 位置 | 作用 | 关键规则 |
|---|---|---|
| `pom.xml` | 项目身份证 + 依赖 + 插件 | `groupId:artifactId:version` 三元组为全球唯一坐标 |
| `src/main/java` | 生产代码（90% 时间在这） | 目录路径必须与 `package` 完全一致；不一致能编译过但类加载失败 |
| `src/main/resources` | **直接进 classpath 根** | 所以 `application.properties` 必须在这一层，不能放 `resources/config/`；Mapper XML、SQL、静态资源也放这 |
| `src/test/java` | 与 main 同构的镜像树 | 单向可见：测试能见 main，main 见不到测试 |
| `target/` | `mvn clean` 即清空 | 绝不进 git |
| `src/main/resources/static`、`templates` | Boot 自己托管网页/模板用 | **本项目永不创建**：前端是独立 `FE` 工程，BE 只吐 JSON |
| `mvnw` / `mvnw.cmd` / `.mvn/` | Maven Wrapper | 别人 clone 后没装 Maven 也能构建；本机已有 Maven 3.9.9，D20 写 README 时再加 |

与 Vite 的直觉对照：`package.json`↔`pom.xml`、`public/`+`.env`↔`resources/`、`node_modules/`↔`D:\m2repo`（**全局共享、不在项目内，最大的体验差异**）、`dist/`↔`target/`、`pnpm dev`↔`mvn spring-boot:run`、`vite build`↔`mvn package`。差异：前端改依赖清单即装，Maven 要触发一次构建才下载；Maven 无 `pnpm-lock.yaml` 对应物，版本锁得更松。

## 3. 脚手架工具：start.spring.io 就是 Java 版 `pnpm create vite`

网页 <https://start.spring.io>；IDE 内置（IDEA / VS Code 的 Spring Initializr 扩展）；一行 curl 实测可用（0.9 s、14947 B）：

```powershell
curl.exe -s -o be.zip "https://start.spring.io/starter.zip?type=maven-project&language=java&bootVersion=4.1.2.RELEASE&javaVersion=17&groupId=com.example&artifactId=be&name=BeApplication&packageName=com.example.be&packaging=jar&dependencies=web,jdbc,postgresql"
```

生成的 13 个文件：`.gitattributes` `.gitignore` `HELP.md` `mvnw` `mvnw.cmd` `pom.xml` `.mvn\wrapper\maven-wrapper.properties` `src\main\java\com\example\be\BeApplication.java` `src\main\resources\application.properties` `src\test\java\com\example\be\BeApplicationTests.java`。
**目录布局与手写的 `com\example\api\` 完全一致**，差别只有 mvnw、`.gitattributes`（管换行符）、`src\test` 骨架，以及官方 `.gitignore` 有 33 行（按 STS / IntelliJ / NetBeans / VS Code 分块）。
另有 [Spring CLI](https://docs.spring.io/spring-cli/reference/index.html)（`boot new` / `boot add`，可把模板合进现有项目并自动改包名）与 `mvn archetype:generate`（上古、模板质量参差，官方不推荐）——当前都不必装。

## 4. 关键实测：Initializr 已不认 3.5.x（版本冲突的具体证据）

用 3.5.16 请求 starter.zip 直接被拒：

```json
{"status":400,"message":"Invalid Spring Boot version '3.5.16', Spring Boot compatibility range is >=4.0.0"}
```

metadata 当前只发 **4.0.9 / 4.1.2（默认）/ 4.2.0-RC1**（Java 可选 17/21/25/27；packaging jar|war）。结论：
- 手写 pom 的 **3.5.16 不受影响**，中央仓库依赖齐全（已 resolve 成功）。
- 但网上新教程/生成器给的都是 4.x，与 3.5 有实质差异——**抄代码时最容易中的坑**：

| 本项目（3.5，正确） | Boot 4.x 官方生成 |
|---|---|
| `spring-boot-starter-web` | `spring-boot-starter-webmvc`（**改名**） |
| `spring-boot-starter-test` | 拆成 `...-webmvc-test` / `...-jdbc-test` 等按技术栈分 |

即：看到 `spring-boot-starter-webmvc` 就是 4.x 写法，放进 3.5 的 pom 会解析失败。这是当时决定不跳 4.x 的具体依据之一。

## 5. 两个通用踩坑与教训

**① PowerShell 反引号续行极易断**：多行 `New-Item ... -Path` 后接反引号换行写 `src\main\...`，一旦续行符后多一个空格，`-Path` 就被吞进路径，实际建出名为 `-Pathsrc\main\java\com\example\api\controller,src\main\resources` 的 7 层空目录树，真正的 `src\main` 不存在，后面写 Java 找不到落点。教训：**PowerShell 里能不用续行符就不用**，改用数组：

```powershell
$dirs = @(
  'src\main\java\com\example\api\controller'
  'src\main\resources'
)
New-Item -ItemType Directory -Force -Path $dirs | Out-Null
Remove-Item -LiteralPath '.\-Pathsrc' -Recurse -Force   # 删除时用 -LiteralPath 防通配符解析
```

**② git 不记录空目录**：`git status` 只列 `?? .gitignore`、`?? pom.xml`，`src` 不出现不是丢了——空目录 git 一概不跟踪，`git add src` 在放进第一个 `.java` 之前无效。

## 6. 当前卡口与验收

下一步是写 `BE\src\main\java\com\example\api\ApiApplication.java`（`package com.example.api;`，Spring Boot 启动类）。验收标准必须从 `No sources to compile` 变成 **编译 1 个源文件**（不加 `-q` 时打印 `Compiling 1 source file to ...\target\classes`）：

```powershell
cd D:\WebGIS\web二维开发\openlayers服务平台开发\BE
& 'D:\maven\bin\mvn.cmd' -q compile
```

可选补强：`.gitignore` 增加 `.vscode/`、`*.ipr`（用户用 VS Code），不影响构建。
