#requires -Version 7
<#
.SYNOPSIS
  把 export-dsh.ps1 产出的迁移包装回一台新电脑。

.DESCRIPTION
  只做「文件归位」这一件事：记忆(mnemon) / skills / storages / task-board /
  .credentials.yaml / profile 元数据。会话(sessions)默认不在包里（导出时就不带），
  只有用 -KeepSessions 导出的包才有，归位时会一并处理。它不重装插件、不动项目代码——
  那两步在 RESTORE.md 里，必须手工（且要在 D 盘）。

.EXAMPLE
  # 先看一眼包里有什么，别写盘
  pwsh -File .\restore-dsh.ps1 -Kit 'D:\dsh-migration\dsh-20261018-1014' -WhatIfOnly

  # 真正归位（目标已有旧会话时需要 -Force）
  pwsh -File .\restore-dsh.ps1 -Kit 'D:\dsh-migration\dsh-20261018-1014' -Force
#>
[CmdletBinding()]
param(
  [Parameter(Mandatory)][string]$Kit,
  [string]$TargetDshHome = $(if ($env:DSH_HOME) { $env:DSH_HOME } else { Join-Path $env:USERPROFILE '.dsh' }),
  [string]$TargetMnemonHome = (Join-Path $env:USERPROFILE '.mnemon'),
  [switch]$RestorePluginSources,
  [switch]$Force,
  [switch]$WhatIfOnly
)

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'

function Invoke-Robocopy {
  param([string]$Source, [string]$Destination)
  $rcArgs = @($Source, $Destination, '/E', '/R:1', '/W:1', '/NFL', '/NDL', '/NJH', '/NJS', '/NP')
  $null = robocopy @rcArgs
  if ($LASTEXITCODE -gt 7) { throw "robocopy failed ($LASTEXITCODE): $Source -> $Destination" }
}

function Get-TreeStats {
  param([string]$Path)
  if (-not (Test-Path $Path)) { return [pscustomobject]@{ files = 0; mb = 0 } }
  $f = Get-ChildItem $Path -Recurse -File -Force -ErrorAction SilentlyContinue
  return [pscustomobject]@{ files = $f.Count; mb = [math]::Round((($f | Measure-Object Length -Sum).Sum / 1MB), 2) }
}

if (-not (Test-Path $Kit)) { throw "迁移包不存在：$Kit" }
$manifestPath = Join-Path $Kit 'manifest.json'
if (-not (Test-Path $manifestPath)) { throw "缺少 manifest.json，这不是本工具产出的包：$Kit" }
$m = Get-Content $manifestPath -Raw | ConvertFrom-Json

Write-Host "迁移包     : $Kit"
Write-Host "导出时间   : $($m.exportedAt)"
Write-Host "来源机器   : $($m.machine.name) / $($m.machine.user)"
Write-Host "来源 DSH   : $($m.dshVersion)"
Write-Host "目标 DSH   : $TargetDshHome"
Write-Host "目标记忆   : $TargetMnemonHome"
Write-Host ''

# 版本核对（只警告，不阻断）
$installed = $null
$appPkg = 'D:\DSH\dsh_data\DSH Desktop\resources\app\package.json'
if (Test-Path $appPkg) { try { $installed = (Get-Content $appPkg -Raw | ConvertFrom-Json).version } catch {} }
if ($installed -and $installed -ne $m.dshVersion) {
  Write-Host "!! 版本不一致：包来自 $($m.dshVersion)，本机装的是 $installed —— 建议先装成同版本再恢复" -ForegroundColor Yellow
}

# 目标已有历史会话时要求 -Force —— 但只有当包里真的带了会话才需要确认（默认包不带）
$kitSessions = Join-Path $Kit 'home\sessions'
$existingSessions = Get-ChildItem (Join-Path $TargetDshHome 'sessions') -Directory -ErrorAction SilentlyContinue
if ((Test-Path $kitSessions) -and $existingSessions -and -not $Force -and -not $WhatIfOnly) {
  throw "目标 $TargetDshHome\sessions 已有 $($existingSessions.Count) 个会话目录。确认要合并请加 -Force（会覆盖同名文件，但不删除多余文件）。"
}

if ($WhatIfOnly) {
  Write-Host '包内容：' -ForegroundColor Cyan
  foreach ($d in (Get-ChildItem $Kit -Directory)) {
    $s = Get-TreeStats $d.FullName
    Write-Host ("  {0,-16} {1,5} files {2,9:N2} MB" -f $d.Name, $s.files, $s.mb)
  }
  Write-Host ''
  Write-Host 'workspace 注册表（新机上这些路径必须原样存在，否则历史会话挂不回去）：' -ForegroundColor Cyan
  foreach ($w in $m.workspaces) { Write-Host ("  [{0}] {1}   ({2} 个会话)" -f $(if ($w.pathExists) { 'x' } else { ' ' }), $w.path, $w.sessionCount) }
  Write-Host ''
  Write-Host 'link: 自研插件（源码已打进包，需放回原路径后重新 link）：' -ForegroundColor Cyan
  foreach ($p in $m.profiles) { foreach ($l in $p.links) { Write-Host ("  [{0}] {1}" -f $p.profile, $l.target) } }
  Write-Host ''
  Write-Host '-WhatIfOnly 模式：什么都没写。' -ForegroundColor DarkGray
  return
}

# ---------------------------------------------------------------- 1. home 目录归位
Write-Host '归位 %DSH_HOME% …'
New-Item -ItemType Directory -Force -Path $TargetDshHome | Out-Null
foreach ($d in (Get-ChildItem (Join-Path $Kit 'home') -Directory)) {
  Invoke-Robocopy -Source $d.FullName -Destination (Join-Path $TargetDshHome $d.Name)
  $s = Get-TreeStats (Join-Path $TargetDshHome $d.Name)
  Write-Host ("  {0,-20} {1,5} files  {2,8:N2} MB" -f $d.Name, $s.files, $s.mb)
}
foreach ($f in (Get-ChildItem (Join-Path $Kit 'home') -File)) {
  Copy-Item $f.FullName (Join-Path $TargetDshHome $f.Name) -Force
  Write-Host "  $($f.Name)"
}

# ---------------------------------------------------------------- 2. 记忆归位
if (Test-Path (Join-Path $Kit 'mnemon')) {
  New-Item -ItemType Directory -Force -Path $TargetMnemonHome | Out-Null
  Invoke-Robocopy -Source (Join-Path $Kit 'mnemon') -Destination $TargetMnemonHome
  $s = Get-TreeStats $TargetMnemonHome
  Write-Host ("  记忆 ~/.mnemon        {0,5} files  {1,8:N2} MB" -f $s.files, $s.mb)
  foreach ($f in @('runtime\MEMORY.md', 'runtime\USER.md', 'runtime\memories.json')) {
    $ok = Test-Path (Join-Path $TargetMnemonHome $f)
    Write-Host ("    {0,-28} {1}" -f $f, $(if ($ok) { 'OK' } else { '缺失!' }))
  }
} else {
  Write-Host '!! 包里没有 mnemon 目录，新机不会继承记忆' -ForegroundColor Red
}

# ---------------------------------------------------------------- 3. profile 元数据
$stamp = Get-Date -Format 'yyyyMMdd-HHmm'
if (Test-Path (Join-Path $Kit 'profiles')) {
  foreach ($profDir in (Get-ChildItem (Join-Path $Kit 'profiles') -Directory)) {
    $dst = Join-Path $TargetDshHome "profiles\$($profDir.Name)"
    New-Item -ItemType Directory -Force -Path $dst | Out-Null
    foreach ($f in (Get-ChildItem $profDir.FullName -File)) {
      $target = Join-Path $dst $f.Name
      if (Test-Path $target) { Copy-Item $target "$target.bak-$stamp" -Force }
      Copy-Item $f.FullName $target -Force
    }
    Write-Host ("  profiles\{0} 元数据已就位" -f $profDir.Name)
  }
}

# ---------------------------------------------------------------- 4. 自研插件源码（可选）
if ($RestorePluginSources) {
  if (-not (Test-Path (Join-Path $Kit 'plugin-sources'))) { Write-Host '包里没有 plugin-sources，跳过' -ForegroundColor Yellow }
  else {
    Write-Host '还原自研插件源码到原路径…'
    foreach ($p in $m.profiles) {
      foreach ($l in $p.links) {
        $src = Join-Path $Kit "plugin-sources\$($l.slug)"
        if (-not (Test-Path $src)) { Write-Host "  缺失 $($l.slug)" -ForegroundColor Yellow; continue }
        if (Test-Path $l.target) {
          Write-Host "  已存在，跳过（不覆盖）：$($l.target)" -ForegroundColor DarkGray
          continue
        }
        New-Item -ItemType Directory -Force -Path $l.target | Out-Null
        Invoke-Robocopy -Source $src -Destination $l.target
        Write-Host "  $($l.target)"
      }
    }
  }
}

Write-Host ''
Write-Host '文件归位完成。剩下的必须手工做，见 RESTORE.md：' -ForegroundColor Green
Write-Host '  1) 用 manifest 里同样的路径放回项目代码'
Write-Host '  2) 在 profile 目录里 pnpm install（store 放 D 盘）重装插件'
Write-Host '  3) 改掉 cordis.patch.yml 里的 pwshPath / windows-mcp.exe 绝对路径'
Write-Host '  4) 启动 DSH，验证记忆、历史会话、插件'
