# 未随包导出的内容

## 会话

会话历史是提炼长期记忆的原料，不是资产。记忆本体在 `mnemon/` 里单独备份，所以这里不给会话。

- `home\sessions` — 82.64 MB / 235 个文件
- `home\dsh-session-archive` — 0 MB / 2 个文件

## 缓存

会话的投影缓存，会话在的时候 DSH 会自己重建，不必备份。

- `home\storages\session_projcache` — 37.86 MB / 235 个文件

## 技能

体积大、且能从上游重新安装，所以不随包走。

- **ppt-master** — 39.88 MB / 13149 个文件 — 官方仓库：https://github.com/hugohe3/ppt-master（v6.7.2）
- **archify** — 4.71 MB / 62 个文件 — 基于：Cocoon-AI/architecture-diagram-generator (MIT, v1.0)（v2.14）

## 换机后怎么办

1. 先跑 `restore-dsh.ps1` 把包内内容归位：记忆、技能、任务板、profile 配置。
2. 缺的技能按上面的来源装回 `%USERPROFILE%\.dsh\skills\`。
3. 会话不会回来，也不需要 —— 检索记忆用 Memory 工具，不必翻旧对话。

想换成旧行为：`-KeepSessions` 恢复会话、`-KeepAllSkills` 恢复技能（包会重新逼近 100 MiB 红线）。
