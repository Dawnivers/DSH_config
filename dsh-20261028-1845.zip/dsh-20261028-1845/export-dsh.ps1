#requires -Version 7
<#
.SYNOPSIS
  导出一份可搬到新电脑的 DSH「人格 + 项目历史」迁移包。

.DESCRIPTION
  收集构成「和你一起做过很多项目、懂你风格」的全部持久数据：
    - %USERPROFILE%\.mnemon        MEMORY.md / USER.md / memories.json —— 真正的「它记得你」
    - %DSH_HOME%\skills            装到 home 的技能包（体积大且可重装的默认排除）
    - %DSH_HOME%\task-board        任务板账本
    - %DSH_HOME%\storages          workspace 注册表、cost-meter 账本
    - %DSH_HOME%\.credentials.yaml API 密钥（明文，仅靠文件 ACL 保护，可直接搬）
    - 各 profile 的 package.json / lock / cordis.patch.yml（不含 node_modules，重装更快）
    - 所有 link: 插件的源码目录（自研插件，market 装不回来）

  默认不导出会话历史：sessions 是 .zstd 压缩过的，占包八成且再压不动，
  而它是提炼长期记忆的原料、不是资产；连带排除它的投影缓存 storages\session_projcache。
  用 -KeepSessions 可恢复旧行为。
  刻意不导出：attachments、node_modules、cache、browser-sessions（登录态与本机绑定）、日志、端口 shim。

.EXAMPLE
  pwsh -File .\export-dsh.ps1
  pwsh -File .\export-dsh.ps1 -SkipAttachments -OutRoot 'E:\dsh-migration'
  pwsh -File .\export-dsh.ps1 -KeepAllSkills      # 连 ppt-master / archify 一起导出（包会大 40+ MB）
#>
[CmdletBinding()]
param(
  [string]$OutRoot = 'D:\dsh-migration',
  [switch]$SkipAttachments,
  [switch]$ExcludeSecrets,
  # 不随包走的技能（默认排除体积大、能从上游重装的），用于把 zip 压在 GitHub 单文件 100 MiB 红线以下。
  [string[]]$ExcludeSkills = @('ppt-master', 'archify'),
  [switch]$KeepAllSkills,
  # 会话历史默认不导出：会话只是提炼长期记忆的原料，记忆本体（mnemon/）已单独备份。
  [switch]$KeepSessions
)
if ($KeepAllSkills) { $ExcludeSkills = @() }

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'

function Get-DshHome {
  if ($env:DSH_HOME) { return $env:DSH_HOME }
  return (Join-Path $env:USERPROFILE '.dsh')
}

function Invoke-Robocopy {
  param([string]$Source, [string]$Destination, [string[]]$ExcludeDirs = @())
  $rcArgs = @($Source, $Destination, '/E', '/R:1', '/W:1', '/NFL', '/NDL', '/NJH', '/NJS', '/NP')
  if ($ExcludeDirs.Count -gt 0) { $rcArgs += '/XD'; $rcArgs += $ExcludeDirs }
  $null = robocopy @rcArgs
  if ($LASTEXITCODE -gt 7) { throw "robocopy failed ($LASTEXITCODE): $Source -> $Destination" }
}

function Get-TreeStats {
  param([string]$Path)
  if (-not (Test-Path $Path)) { return [pscustomobject]@{ files = 0; mb = 0 } }
  $f = Get-ChildItem $Path -Recurse -File -Force -ErrorAction SilentlyContinue
  return [pscustomobject]@{ files = $f.Count; mb = [math]::Round((($f | Measure-Object Length -Sum).Sum / 1MB), 2) }
}

$dshHome = Get-DshHome
$mnemonHome = Join-Path $env:USERPROFILE '.mnemon'
$stamp = Get-Date -Format 'yyyyMMdd-HHmm'
$dest = Join-Path $OutRoot "dsh-$stamp"

Write-Host "DSH_HOME : $dshHome"
Write-Host "mnemon   : $mnemonHome"
Write-Host "导出到    : $dest"
Write-Host ''

New-Item -ItemType Directory -Force -Path $dest | Out-Null

# ---------------------------------------------------------------- 1. home 目录
# 会话历史默认不导出（-KeepSessions 可恢复）：会话是提炼长期记忆的原料，不是资产；
# 记忆本体在 mnemon/ 里另有备份。会话的投影缓存 storages\session_projcache 一并排除——
# 它只是会话的索引副本，会话不在时留着是死数据。
$sessionDirs = @('sessions', 'dsh-session-archive')

$homeDirs = @('skills', 'storages', 'task-board', 'pets', 'llm-deepseek',
  'agents-anywhere', 'dsh-usage')
if ($KeepSessions) { $homeDirs = $sessionDirs + $homeDirs }
if (-not $SkipAttachments) { $homeDirs += 'attachments' }

# 没进包的东西统一记账，最后写进 EXCLUDED.md 与 manifest.json
$excludedReport = @()

foreach ($d in $sessionDirs) {
  if ($KeepSessions) { continue }
  $p = Join-Path $dshHome $d
  if (-not (Test-Path $p)) { continue }
  $st = Get-TreeStats $p
  $excludedReport += [pscustomobject]@{ kind = '会话'; name = $d; files = $st.files; mb = [math]::Round($st.mb, 2) }
  Write-Host ("  home\{0,-22} (已排除, {1:N2} MB / {2} 文件)" -f $d, $st.mb, $st.files) -ForegroundColor Yellow
}

foreach ($d in $homeDirs) {
  $src = Join-Path $dshHome $d
  if (-not (Test-Path $src)) { Write-Host "skip (missing): $d" -ForegroundColor DarkGray; continue }

  $exDirs = @('cache', 'Cache')
  if ($d -eq 'skills' -and $ExcludeSkills.Count -gt 0) {
    foreach ($s in $ExcludeSkills) {
      $p = Join-Path $src $s
      if (-not (Test-Path $p)) { Write-Host "  home\skills\$s  (未安装，跳过排除)" -ForegroundColor DarkGray; continue }
      $st = Get-TreeStats $p
      $exDirs += $p
      $excludedReport += [pscustomobject]@{ kind = '技能'; name = $s; files = $st.files; mb = [math]::Round($st.mb, 2) }
      Write-Host ("  home\skills\{0}  (已排除, {1:N2} MB / {2} 文件)" -f $s, $st.mb, $st.files) -ForegroundColor Yellow
    }
  }

  if ($d -eq 'storages' -and -not $KeepSessions) {
    $cache = Join-Path $src 'session_projcache'
    if (Test-Path $cache) {
      $st = Get-TreeStats $cache
      $exDirs += $cache
      $excludedReport += [pscustomobject]@{ kind = '缓存'; name = 'storages\session_projcache'; files = $st.files; mb = [math]::Round($st.mb, 2) }
      Write-Host ("  home\storages\session_projcache  (已排除, {0:N2} MB / {1} 文件)" -f $st.mb, $st.files) -ForegroundColor Yellow
    }
  }

  Invoke-Robocopy -Source $src -Destination (Join-Path $dest "home\$d") -ExcludeDirs $exDirs
  $s = Get-TreeStats (Join-Path $dest "home\$d")
  Write-Host ("  home\{0,-20} {1,5} files  {2,8:N2} MB" -f $d, $s.files, $s.mb)
}
if ($SkipAttachments) { Write-Host '  home\attachments        已跳过（历史会话里的图片会显示不出来）' -ForegroundColor Yellow }

# ---------------------------------------------------------------- 2. home 文件
$homeFiles = @('.credentials.yaml', '.env', 'pet.json', 'skin-center-active.json', '.anonymous-user-id')
New-Item -ItemType Directory -Force -Path (Join-Path $dest 'home') | Out-Null
$withheld = @()
foreach ($f in $homeFiles) {
  $src = Join-Path $dshHome $f
  if (-not (Test-Path $src)) { continue }
  if ($ExcludeSecrets -and $f -in @('.credentials.yaml', '.env')) {
    $withheld += $f
    Write-Host "  home\$f  (含密钥，已排除)" -ForegroundColor Yellow
    continue
  }
  Copy-Item $src (Join-Path $dest "home\$f") -Force
  Write-Host "  home\$f"
}
if ($withheld.Count -gt 0) {
  @(
    '本迁移包刻意不含以下文件（含密钥，禁止外传）:'
    ''
    ($withheld | ForEach-Object { "- $_" })
    ''
    '换机时请从旧机单独复制，或用 GUI 重新录入 API Key。'
  ) | Set-Content (Join-Path $dest 'home\SECRETS_WITHHELD.txt') -Encoding utf8
}

# ---------------------------------------------------------------- 3. mnemon（记忆本体）
if (Test-Path $mnemonHome) {
  Invoke-Robocopy -Source $mnemonHome -Destination (Join-Path $dest 'mnemon') -ExcludeDirs @('cache', 'logs', 'Cache')
  $s = Get-TreeStats (Join-Path $dest 'mnemon')
  Write-Host ("  mnemon                  {0,5} files  {1,8:N2} MB" -f $s.files, $s.mb)
} else {
  Write-Host '  !! 没找到 ~/.mnemon —— 迁移包不含记忆，新机不会认识你' -ForegroundColor Red
}

# ---------------------------------------------------------------- 4. profile 配置
$profileMeta = @('package.json', 'pnpm-lock.yaml', 'pnpm-workspace.yaml', 'cordis.patch.yml', 'cordis.yml')
$linkSources = @{}
$profilesDir = Join-Path $dshHome 'profiles'
$profileReport = @()

if (Test-Path $profilesDir) {
  foreach ($prof in (Get-ChildItem $profilesDir -Directory | Where-Object { $_.Name -notlike '.*' })) {
    $dstProf = Join-Path $dest "profiles\$($prof.Name)"
    New-Item -ItemType Directory -Force -Path $dstProf | Out-Null
    foreach ($m in $profileMeta) {
      $src = Join-Path $prof.FullName $m
      if (Test-Path $src) { Copy-Item $src (Join-Path $dstProf $m) -Force }
    }
    $entry = [ordered]@{ profile = $prof.Name; plugins = @(); links = @() }
    $pkgPath = Join-Path $prof.FullName 'package.json'
    if (Test-Path $pkgPath) {
      $pkg = Get-Content $pkgPath -Raw | ConvertFrom-Json
      $deps = [ordered]@{}
      foreach ($set in @('dependencies', 'devDependencies')) {
        $node = $pkg.$set
        if ($null -ne $node) { foreach ($p in $node.PSObject.Properties) { $deps[$p.Name] = "$($p.Value)" } }
      }
      foreach ($name in $deps.Keys) {
        $spec = $deps[$name]
        if ($spec -like 'link:*') {
          $target = $spec.Substring(5).Replace('/', '\')
          $slug = ($name -replace '[@/]', '_') + '__' + (Split-Path $target -Leaf)
          $exists = Test-Path $target
          $entry.links += [ordered]@{ name = $name; target = $target; slug = $slug; exists = $exists }
          if ($exists) { $linkSources[$target] = $slug }
        } else {
          $entry.plugins += [ordered]@{ name = $name; spec = $spec }
        }
      }
    }
    $profileReport += [pscustomobject]$entry
    Write-Host ("  profiles\{0,-14} {1} 个市场插件, {2} 个 link 插件" -f $prof.Name, $entry.plugins.Count, $entry.links.Count)
  }
}

# ---------------------------------------------------------------- 5. link 插件源码
if ($linkSources.Count -gt 0) {
  Write-Host ''
  Write-Host '复制自研（link:）插件源码…'
  foreach ($target in $linkSources.Keys) {
    $slug = $linkSources[$target]
    $dst = Join-Path $dest "plugin-sources\$slug"
    Invoke-Robocopy -Source $target -Destination $dst -ExcludeDirs @('node_modules', '.git', 'dist\cache', '.turbo')
    $s = Get-TreeStats $dst
    Write-Host ("  {0,-52} {1,5} files {2,8:N2} MB" -f $slug, $s.files, $s.mb)
  }
}

# ---------------------------------------------------------------- 6. manifest
$wsList = @()
$wsFile = Join-Path $dshHome 'storages\workspace.json'
if (Test-Path $wsFile) {
  $wsJson = Get-Content $wsFile -Raw | ConvertFrom-Json
  foreach ($p in $wsJson.tables.workspaces.PSObject.Properties) {
    $wsList += [ordered]@{
      id            = $p.Name
      path          = $p.Value.path
      title         = $p.Value.title
      sessionCount  = @($p.Value.sessionIds).Count
      pathExists    = (Test-Path $p.Value.path)
    }
  }
}

$appVersion = 'unknown'
$appPkg = 'D:\DSH\dsh_data\DSH Desktop\resources\app\package.json'
if (Test-Path $appPkg) { try { $appVersion = (Get-Content $appPkg -Raw | ConvertFrom-Json).version } catch {} }

$manifest = [ordered]@{
  kind          = 'dsh-migration-kit'
  schemaVersion = 1
  exportedAt    = (Get-Date).ToString('o')
  machine       = [ordered]@{ name = $env:COMPUTERNAME; user = $env:USERNAME; userProfile = $env:USERPROFILE }
  dshHome       = $dshHome
  mnemonHome    = $mnemonHome
  dshVersion    = $appVersion
  includeAttachments = (-not $SkipAttachments)
  includeSessions = [bool]$KeepSessions
  excluded      = @($excludedReport)
  profiles      = $profileReport
  workspaces    = $wsList
  stats         = (Get-TreeStats $dest)
  restoreHint   = 'RESTORE.md（与本脚本同目录）'
}
$manifest | ConvertTo-Json -Depth 8 | Set-Content (Join-Path $dest 'manifest.json') -Encoding utf8

# 没进包的东西：留下名字、体积和重装线索，否则换机时只看到"少了点东西"却不知道为什么
if ($excludedReport.Count -gt 0) {
  $intro = @{
    '会话' = '会话历史是提炼长期记忆的原料，不是资产。记忆本体在 `mnemon/` 里单独备份，所以这里不给会话。'
    '缓存' = '会话的投影缓存，会话在的时候 DSH 会自己重建，不必备份。'
    '技能' = '体积大、且能从上游重新安装，所以不随包走。'
  }
  $lines = @('# 未随包导出的内容', '')
  foreach ($kind in @('会话', '缓存', '技能')) {
    $group = @($excludedReport | Where-Object { $_.kind -eq $kind })
    if ($group.Count -eq 0) { continue }
    $lines += "## $kind"
    $lines += ''
    $lines += $intro[$kind]
    $lines += ''
    foreach ($e in $group) {
      if ($kind -ne '技能') {
        $lines += "- ``home\$($e.name)`` — $([math]::Round($e.mb,2)) MB / $($e.files) 个文件"
        continue
      }
      $hint = '（SKILL.md 未标注来源，请从原安装处拷回）'
      $skillMd = Join-Path $dshHome "skills\$($e.name)\SKILL.md"
      if (Test-Path $skillMd) {
        $head = Get-Content $skillMd -TotalCount 30
        $repo = $head | Select-String -Pattern 'official_repository:\s*"?([^"\r\n]+)' | Select-Object -First 1
        $based = $head | Select-String -Pattern 'based_on:\s*"?([^"\r\n]+)' | Select-Object -First 1
        $ver = $head | Select-String -Pattern '^\s*version:\s*"?([^"\r\n]+)' | Select-Object -First 1
        if ($repo) { $hint = '官方仓库：' + $repo.Matches[0].Groups[1].Value.Trim() }
        elseif ($based) { $hint = '基于：' + $based.Matches[0].Groups[1].Value.Trim() }
        if ($ver) { $hint += '（v' + $ver.Matches[0].Groups[1].Value.Trim() + '）' }
      }
      $lines += "- **$($e.name)** — $([math]::Round($e.mb,2)) MB / $($e.files) 个文件 — $hint"
    }
    $lines += ''
  }
  $lines += @(
    '## 换机后怎么办'
    ''
    '1. 先跑 `restore-dsh.ps1` 把包内内容归位：记忆、技能、任务板、profile 配置。'
    '2. 缺的技能按上面的来源装回 `%USERPROFILE%\.dsh\skills\`。'
    '3. 会话不会回来，也不需要 —— 检索记忆用 Memory 工具，不必翻旧对话。'
    ''
    '想换成旧行为：`-KeepSessions` 恢复会话、`-KeepAllSkills` 恢复技能（包会重新逼近 100 MiB 红线）。'
  )
  $lines | Set-Content (Join-Path $dest 'EXCLUDED.md') -Encoding utf8
  Write-Host ("  已写入 EXCLUDED.md（{0} 项未导出）" -f $excludedReport.Count) -ForegroundColor Yellow
}

# ---------------------------------------------------------------- 7. 自带说明书与还原脚本
foreach ($c in @('RESTORE.md', 'restore-dsh.ps1', 'export-dsh.ps1')) {
  $src = Join-Path $PSScriptRoot $c
  if (Test-Path $src) { Copy-Item $src (Join-Path $dest $c) -Force }
}

$total = Get-TreeStats $dest
Write-Host ''
Write-Host ("完成：{0}  ({1} 个文件, {2:N2} MB)" -f $dest, $total.files, $total.mb) -ForegroundColor Green
Write-Host "把它连同 RESTORE.md 一起拷到移动硬盘 / 网盘即可。" -ForegroundColor Green
