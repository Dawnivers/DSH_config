"""new_model.py -- copy this to start a new model. Verifier-first template.

WHY THIS SHAPE
The verifier is written BEFORE the model, like a test. That is the whole method:
a defect you can only see is one you will reintroduce; a defect you can measure
stays fixed. Every axis below is computed from geometry -- no LLM judge appears
anywhere, because a vision model was measured reporting "uniform leaf size, no
droop" for geometry with 25.6x size variation and 81.4% of leaves drooping.

SESSION HANDLING (automatic)
On startup this detects whether a live Blender is reachable:
  * live + scene already holds someone's work  -> save it to a timestamped
    .blend FIRST, then start clean
  * live + empty or factory-default scene      -> start clean, nothing to save
  * live + MODE = "append"                     -> leave the scene alone and add
                                                  to it (for "add X to this
                                                  scene" tasks)
  * no live Blender                            -> the .py IS the deliverable
Both a .blend and a standalone .py are exported at the end. The .py matters
more: a .blend is an opaque binary, the script is diffable, parameterisable,
and reproduces the model from nothing.

RUN
    # headless, scoring only (no .blend, script is the deliverable):
    python3 new_model.py
    # if the build route needs Blender (curve bevel, cloth sim, particles):
    /Applications/Blender.app/Contents/MacOS/Blender -b -P new_model.py
    # or paste into a live Blender session driven over MCP
"""
import os
import sys

import numpy as np

TEMPLATE_DIR = os.path.dirname(os.path.abspath(__file__)) if globals().get("__file__") else os.getcwd()
SKILL_DIR = os.path.dirname(TEMPLATE_DIR)
CATEGORY_DIR = os.path.dirname(SKILL_DIR)
SKILL = os.path.join(SKILL_DIR, "scripts")
ENGINE = os.path.join(CATEGORY_DIR, "procedural-3d-modeling", "scripts")
SKILLS_HOME = os.environ.get("SKILLS_HOME", "")
SEARCH_PATHS = [SKILL, ENGINE]
if SKILLS_HOME:
    SEARCH_PATHS += [
        os.path.join(SKILLS_HOME, "verifier-first-3d-modeling", "scripts"),
        os.path.join(SKILLS_HOME, "procedural-3d-modeling", "scripts"),
        os.path.join(SKILLS_HOME, "creative", "verifier-first-3d-modeling", "scripts"),
        os.path.join(SKILLS_HOME, "creative", "procedural-3d-modeling", "scripts"),
    ]
for p in SEARCH_PATHS:
    if p not in sys.path:
        sys.path.insert(0, p)

import verify_model as vm
import silhouette as sil
import session as S

# Resolve our own source ONCE. Under MCP `__file__` does not exist -- the code
# is exec'd from a string -- so a bare __file__ raises NameError and, worse, a
# copy-the-source-file export silently yields a .blend with no .py beside it.
# SELF is None in that case, and the __main__ block below refuses to ship a
# half-set of artifacts rather than pretending it succeeded.
SELF = globals().get("__file__")
SELF = os.path.abspath(SELF) if SELF and os.path.exists(SELF) else None


# ============================================================== 1. TASK SPEC
# Fill this in FIRST. Declaring the gates forces you to decide what "correct"
# means before you can be tempted to accept whatever the build produces.

SPEC = {
    "name": "my_model",
    "cls": "DERIVED",            # DERIVED | MIXED | SPECIFIED

    # --- session policy. "auto" is the safe default: existing work is saved to
    # a timestamped .blend before the scene is cleared. Switch to "append" when
    # the task is "add X to this scene" rather than "model X" -- appending is
    # the one case where clearing would destroy the point of the task.
    "session_mode": "auto",      # auto | append | replace
    "out_dir": os.path.expanduser("~/blender_out"),

    # --- axis 1: topology. NO universal gate exists. A curve-bevelled tree is
    # 25718 correct shells; a heightfield is a correct open sheet.
    "expect_shells": 1,          # None to skip the component check
    "expect_genus": 0,           # a bore/handle/loop raises this; None to skip
    "require_closed": True,      # False for open surfaces

    # --- axis 2: physics
    "ground_z": 0.0,

    # --- axis 5: sampling discipline (SDF routes only)
    "min_voxels_per_feature": 4.0,

    # --- axis 6: the complexity parameter. If you cannot name one, the model is
    # SPECIFIED (hand-typed coordinates) and its detail will not scale.
    "scale_param": "n",
    "scale_values": (8, 12, 18, 27),
}


# ================================================================= 2. BUILD
# One function, parameterised by the complexity knob. Keep it deterministic:
# seed every RNG, because retry-until-lucky is a reward exploit.

def build(n=12, seed=0):
    """Return (verts, faces). Replace this body with the real model.

    Route order -- prefer the highest tier that can express the target:
      1. Blender native (curve bevel, geometry nodes, cloth/rigid-body solvers)
      2. Direct mesh construction (from_pydata) for cards and instances
      3. SDF field + mesher, ONLY when you need organic blending or CSG AND a
         guaranteed single closed solid
      4. Displacement/texture for microdetail
    """
    rng = np.random.default_rng(seed)

    # --- example: SDF route (delete if using another route) ---------------
    # A central mass with n bumps on it. Note this is genus 0: the bumps are
    # attached to a solid core. Arranging the same spheres in a RING instead
    # leaves a hole through the middle -- genus 1 -- which is exactly the kind
    # of thing the topology gate is there to catch.
    import sdf_core as sc
    f = sc.Field()
    f.add(sc.Sphere((0, 0, 0), 0.42))
    for k in range(int(n)):
        # golden-angle spiral: even coverage for any n, no stacking
        z = 1.0 - 2.0 * (k + 0.5) / n
        r = np.sqrt(max(0.0, 1.0 - z * z))
        a = np.pi * (3.0 - np.sqrt(5.0)) * k
        p = np.array([r * np.cos(a), r * np.sin(a), z]) * 0.46
        # Adjacent bulges joined by smooth_union. NOT a subtracted groove:
        # measured at 2.3 voxels/feature, a cut slot's p95 dihedral is 34.5
        # degrees against a blend's 8.5 -- same feature, same resolution.
        f.add(sc.Sphere(p, 0.15, smooth=0.10))
    verts, faces, _ = sc.build_mesh(f, res=140, newton=2, verbose=False)
    return verts, faces


def feature_sizes():
    """Smallest dimension of each authored feature, for the aliasing audit.
    Return () for non-SDF routes."""
    return (0.84, 0.30)          # core diameter, bump diameter


def voxel_size(res=140):
    """World size of one voxel, for the feature/voxel ratio."""
    import sdf_core as sc
    f = sc.Field()
    f.add(sc.Sphere((0, 0, 0), 0.42))
    f.add(sc.Sphere((0, 0, 0.46), 0.15, smooth=0.10))
    lo, hi = f.bounds(pad=0.06)
    return float((hi - lo).max() / res)


# ================================================================ 3. VERIFY

def verify(verbose=True):
    V, F = build()

    topo = vm.topology(V, F, SPEC["expect_shells"], SPEC["expect_genus"],
                       SPEC["require_closed"])
    phys = vm.physical_validity(V, F, ground_z=SPEC["ground_z"])

    feats = feature_sizes()
    detail = vm.detail_adequacy(feats, voxel_size()) if feats else None

    # Axis 6. NO output measure works for every route, so try all three and
    # report them. Measured failure modes:
    #   poly               cannot tell new detail from resampling (a resampled
    #                      figure scored 1.99, a real terrain 2.02)
    #   outline_complexity blind to interior relief; saturates and goes NEGATIVE
    #                      on self-occluding forms (a tree canopy: -0.92)
    #   surface_roughness  interior relief only; misses silhouette-only change
    # This template's own example is a case in point: blending n bumps into a
    # core SMOOTHS the outline (-0.08) while adding real surface relief (+0.42).
    measures = {
        "poly": vm.poly_measure,
        "outline": lambda vv, ff: sil.outline_complexity(vv, ff, res=192),
        "roughness": vm.surface_roughness,
    }
    sweeps = {k: vm.scaling_response(lambda v: build(n=v),
                                     SPEC["scale_values"], measure=m)
              for k, m in measures.items()}
    # score against the measure that actually sees this route's detail
    best = max(sweeps, key=lambda k: sweeps[k].get("slope") or -9e9)
    scal = sweeps[best]
    scal["measure"] = best

    gen = vm.generative_quality(len(F), SELF or __name__,
                                build=lambda: build(), scaling=scal)

    card = vm.score(
        V, F,
        source_path=SELF,
        voxel=voxel_size() if feats else None,
        feature_sizes=feats,
        expect_shells=SPEC["expect_shells"],
        expect_genus=SPEC["expect_genus"],
        ground_z=SPEC["ground_z"],
    )
    card["generative"] = gen
    card["scaling"] = scal

    if verbose:
        print(vm.format_card(card))
        print("\nscaling response by output measure (slope > 0 = rules add detail):")
        for k, s in sweeps.items():
            mark = "  <- scored" if k == best else ""
            print("   %-10s %+.3f  growth %.2fx%s"
                  % (k, s.get("slope") or 0.0, s.get("growth") or 0.0, mark))
        if (scal.get("slope") or 0) <= 0.05:
            print("   WARNING: no measure sees detail growing with '%s'."
                  % SPEC["scale_param"])
            print("   Either the parameter only resamples, or the model is")
            print("   SPECIFIED (hand-typed coordinates) and will not scale.")
        if not topo["gate"]:
            print("\nTOPOLOGY FAILED -- diagnose before touching anything else:")
            for s in vm.shell_report(V, F, top=5):
                print("   V=%-6d frac=%.4f lo=%s hi=%s"
                      % (s["verts"], s["frac"], s["lo"], s["hi"]))
        if not phys.get("gate"):
            print("\nPHYSICS FAILED: centre of mass %s is outside the footprint"
                  % phys.get("com"))
    return card, V, F


if __name__ == "__main__":
    # 1. probe the session and protect whatever is already there. This runs
    #    BEFORE the build, because the whole point is not to destroy work.
    prep = S.prepare_scene(mode=SPEC["session_mode"],
                           save_dir=SPEC["out_dir"],
                           label="preserved")

    # 2. score the model (pure geometry, no Blender needed)
    card, V, F = verify()
    card["session"] = {k: prep[k] for k in ("mode", "action", "preserved")}

    # 3. link into the live scene if there is one. In "append" mode this adds
    #    to the user's existing objects instead of replacing them.
    if S.has_workspace():
        import sdf_core as sc
        sc.to_blender(V, F, name=SPEC["name"])
        print("\n[session] linked '%s' into the scene" % SPEC["name"])

    # 4. always leave both artifacts behind: the .blend for a live scene, and
    #    the .py that regenerates it from nothing. With no workspace the script
    #    is the entire deliverable.
    if SELF is None:
        print("\n" + "=" * 68)
        print("CANNOT EXPORT THE SCRIPT: this code has no file on disk.")
        print("That is what happens when code is sent straight over MCP -- it")
        print("is exec'd from a string, so only the .blend can be saved and")
        print("there is nothing to reproduce the model with.")
        print()
        print("Fix: write the script FIRST, then run the file. Either")
        print("  session.write_then_run(code, '~/blender_out/thing.py')")
        print("or, from a shell:")
        print("  blender -b -P ~/blender_out/thing.py")
        print("=" * 68)
        out = S.finish(None, out_dir=SPEC["out_dir"], label=SPEC["name"],
                       scorecard=card, require_script=False)
    else:
        out = S.finish(SELF, out_dir=SPEC["out_dir"], label=SPEC["name"],
                       scorecard=card)

    print("\n=== deliverables ===")
    for k in ("blend", "script", "scorecard"):
        print("  %-10s %s" % (k, out[k] or "(none)"))
    if prep.get("preserved"):
        print("  %-10s %s" % ("preserved", prep["preserved"]))
