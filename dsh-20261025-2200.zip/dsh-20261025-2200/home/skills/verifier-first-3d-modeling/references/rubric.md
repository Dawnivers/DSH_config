# The Rubric

Every score must come from geometry, declared structure, source parameters, or
explicit reference constraints. Do not use an undifferentiated human or LLM
beauty score as geometric reward.

## Score composition

```text
semantic_gate = declared_structure_pass
hard_gates = semantic_gate * topology_gate * physical_gate
score = hard_gates * dense_axis_score
```

Semantic structure is declared per task. It names regions, relations, openings,
repetition and expected topology before construction. It is a precondition, not
an extra universal geometry metric.

Hard gates are multiplicative because an unusable structure should not recover
through material, polygon count or a good silhouette. Remaining axes use dense
partial credit so the trajectory shows which measurement improved.

## Semantic structure gate

Check the full model against its structure map:

| check | pass condition |
|---|---|
| declared regions | every required region exists and has measurable support |
| adjacency and contacts | every required relation is geometrically verified |
| openings and cavities | intended boundaries are real geometry, not shading or texture |
| repetition | instances follow declared count, spacing, orientation or distribution rules |
| continuity | each path, rim, transition and junction remains semantically readable |
| hierarchy | secondary and tertiary forms attach to the correct primary mass |

A closed, manifold mesh can still fail this gate if its semantic regions are
missing, its openings are painted, or its attachments are accidental.

## Topology gate

Topology is task-declared, not universal. A task must state the expected shell
count, openness and genus when those properties matter.

| check | pass condition |
|---|---|
| connected components | equals the task-declared expectation, or is intentionally unconstrained |
| non-manifold edges | zero unless explicitly allowed and justified |
| boundary edges | match declared openings or open-surface regions |
| watertightness | matches the task's solid/open-surface declaration |
| genus | equals the task-declared expectation when applicable |
| self-intersection | none when the task claims a valid solid or surface |
| mesh validity | finite vertices, valid indices, no forbidden duplicate/zero-area faces |

Never infer correctness from shell count alone. Measure the topology that the
structure map declares.

## Physical validity gate

Use only when the task declares physical constraints:

- support and contact relations are satisfied;
- centre of mass lies within the declared support region;
- no unintended floating components exist;
- ground contact and wall thickness meet the declared constraints;
- units and bounding dimensions are sane.

## Metric accuracy

Normalize before comparing so scores are scale-free. Give every landmark or
cross-section an explicit target and tolerance.

```text
error_i = abs(measured_i - target_i) / tolerance_i
axis_metric = mean(max(0, 1 - error_i))
```

Restrict measurements to semantic regions or spatial masks. Prefer stable
threshold crossings and fitted profiles over unqualified extrema, which often
select an unrelated local maximum.

## Silhouette fidelity

When reference silhouettes or target masks are declared:

1. render at least four orthographic views;
2. align with the declared coordinate/camera convention;
3. compute per-view IoU and symmetric outline Chamfer;
4. report mean and variance across views;
5. hold out at least one observation and report its score separately.

A model that matches one view and collapses in profile is overfit, not accurate.
Do not score silhouettes when the reference does not constrain the hidden form.

## Detail adequacy

For sampled routes, measure every required feature against the local sample or
edge scale:

```text
ratio_j = feature_size_j / local_sample_size
axis_detail = fraction of required features above the declared minimum
```

A feature below the sampling threshold must be re-expressed, enlarged or
sampled more finely. Surface detail cannot substitute for missing volume,
openings, edge thickness or semantic transitions.

Check positional, tangent and normal continuity around every high-value region.

## Generative quality

This axis prevents transcription and dead controls from being rewarded.

### Representation capacity

Name controls for silhouette, depth, cross-sections, junctions, openings and
local landmarks. Perturb each control and verify its intended spatial support:
the target region moves while unrelated regions remain stable.

### Scaling response

Sweep a model-level complexity parameter and measure the output property where
new structure should appear. Pure resampling, subdivision or added coordinates
without a live structural parameter do not count as generative quality.

### Determinism

The same source, parameters and seed must produce an identical result.

### Efficiency

Cap complexity and report quality per unit of geometry. Do not reward polygon
count by itself.

## Anti-gaming summary

| exploit | blocked by |
|---|---|
| retry until a metric passes | determinism |
| coordinate dumping | representation-capacity and scaling-response checks |
| dead parameters | parameter liveness and spatial-support checks |
| view overfitting | held-out observations |
| polygon inflation | complexity cap and efficiency reporting |
| painted openings or fake contacts | semantic structure plus topology |
| hidden stray components | full-mesh topology checks |
| beautiful but unusable output | multiplicative hard gates |

## Reporting

Emit one JSON scorecard per attempt with every sub-check, not only the total.
Record the first failed structural level, the measurement that exposed it, the
responsible representation or control, and the repair that changed the score.
Keep object-specific failures in the task trajectory. Promote a rule into the
reusable skill only after it transfers across tasks.
