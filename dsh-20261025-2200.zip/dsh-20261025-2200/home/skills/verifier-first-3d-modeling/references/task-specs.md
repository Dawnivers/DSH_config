# Task Specs for SFT / RL

A task is a triple: **prompt, verifier configuration, optional reference**. A
task without a verifier is unusable because the build has no actionable error
signal.

## Spec format

```python
TASK = {
  "id": "replace_me",
  "prompt": "Describe the target form and the required structural relations.",
  "cls": "DERIVED",                 # DERIVED | MIXED | SPECIFIED
  "route_hint": None,               # leave None when route choice is scored

  # ---- semantic structure: task precondition, declared before building
  "regions": ("region_a", "region_b"),
  "relations": (("region_a", "region_b", "adjacent"),),
  "openings": (),                    # named openings or cavities, if any
  "repetition": None,                # rule / count / spacing / None

  # ---- topology, declared per task; there is no universal shell gate
  "expect_shells": 1,
  "expect_genus": 0,
  "require_closed": True,

  # ---- assembly, for multi-region tasks
  "assembly": None,                  # or {"expect_connected": True, ...}

  # ---- physical validity, when applicable
  "ground_z": None,
  "require_com_over_support": False,
  "min_wall_thickness": None,

  # ---- metric accuracy: (target, tolerance) per declared landmark
  "landmarks": {
      "landmark_a": (0.0, 0.01),
      "landmark_b": (1.0, 0.02),
  },

  # ---- silhouette/reference scoring; always hold out an observation when used
  "reference": None,
  "holdout_views": (),

  # ---- detail adequacy, for sampled routes
  "min_samples_per_feature": 4.0,

  # ---- generative quality
  "scale_param": "complexity",
  "scale_values": (1, 2, 4),
  "scale_measure": "route_appropriate_measure",
  "declared_params": ("complexity",),

  "polycount_cap": 500_000,
  "timeout_s": 120,
}
```

The `regions`, `relations`, `openings` and `repetition` fields are not prose
ornaments. They define the semantic structure that must exist before surface
quality is scored. A dark material patch does not satisfy an opening; accidental
contact does not satisfy an adjacency relation.

Classify each region by information source. For **DERIVED** regions, expose the
causal rule and its parameters. For **MIXED** regions, generate the shared
structure and represent supplied constraints separately. For **SPECIFIED**
regions, use the supplied constraints through an adequate continuous
representation; do not score unsupported fidelity claims. This is a modeling
route decision, not a reason to skip the task.

For reference-based scoring, use calibrated observations or explicit geometric
constraints and hold out at least one observation. Score only what the reference
actually constrains; do not infer hidden structure from a single projection.

For multi-region tasks, `assembly` is a structural gate, not a screenshot note.
The contact graph must be declared and checked in the order
`orphan_parts -> aabb -> field`; if an earlier stage fails, later stages must be
reported as `status="skipped"` rather than silently treated as passing.

## Difficulty ladder

Order tiers by reasoning burden, not visual complexity:

| tier | task shape | primary capability |
|---|---|---|
| 1 | DERIVED, one region, manifold only | can it generate a deterministic form |
| 2 | DERIVED with declared topology | can it design connectivity deliberately |
| 3 | DERIVED with non-zero genus or openings | can it reason about cavities and handles |
| 4 | DERIVED with simulation or solver detail | can it route detail to a solver |
| 5 | sampled form with feature-size constraints | can it match representation to sampling rate |
| 6 | MIXED multi-region assembly | can it separate generated structure from supplied constraints |
| 7 | reference-constrained multi-view form | can it fit observed structure without view overfitting |

## Reward

```text
reward = semantic_gate * topology_gate * physical_gate * dense_axis_score
```

Hard gates are multiplicative. Remaining axes use dense partial credit so the
trajectory shows which relationship or measurement improved.

Shaping that matters:

- reward per landmark, relation and feature, not only per task;
- log every iteration's scorecard and the first failed structural level;
- reward the repair that changes the named measurement;
- cap polygons rather than rewarding polygon count;
- never use an undifferentiated LLM beauty score as geometric reward.

## Anti-gaming checklist

| exploit | check |
|---|---|
| retry until a seed passes | determinism: same seed gives identical output |
| hard-code coordinates without a model | scaling response and parameter liveness |
| dead parameters with plausible names | perturb each parameter and measure support |
| overfit scored views | held-out observation and overfit gap |
| subdivide to inflate score | polycount cap and score normalized by complexity |
| paint an opening or junction | semantic structure plus topology checks on full geometry |
| hide stray components | full-mesh component and non-manifold checks |

## Execution harness requirements

- Score headless. Geometry scoring must not depend on a GUI render state.
- Treat builder crashes and timeouts as explicit failed attempts and keep their
  trace in the trajectory.
- Pin and record random seeds, source hashes and parameter values.
- Emit one JSON scorecard per attempt with every sub-check, not only the total.
- Keep task-specific failures and repairs in the generated dataset trajectory;
  promote a rule into the reusable skill only after it transfers across tasks.
