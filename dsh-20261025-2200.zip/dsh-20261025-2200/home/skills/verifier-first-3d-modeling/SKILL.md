---
name: verifier-first-3d-modeling
description: "先定怎么验证、再选建模路线：可脚本化 3D 建模 + 指标验收。何时用：要建 3D 模型但不确定怎么算对。"
version: 1.0.0
author: Project Contributors
license: MIT
platforms: [linux, macos, windows]
metadata:
  tags: [3D, Blender, Procedural, Verification, Rubric, TrainingData]
  related_skills: [procedural-3d-modeling, test-driven-development, systematic-debugging]
---

# Verifier-First 3D Modeling

## When to use

Use when **choosing how** to build 3D geometry with a script, when judging
whether a build succeeded, or when authoring modeling tasks whose results must
be scored automatically (SFT/RL data, benchmarks, CI gates).

## Default quality and high-fidelity route

Unless the task explicitly requests low-poly, stylized, preview, real-time, or
resource-constrained output, treat **high precision as the default acceptance
level**. A recognizable blockout is evidence only that the category may be
present; it is not a finished model.

The quality contract is feature-based rather than polygon-based:

- every declared semantic region and junction is geometrically readable;
- primary silhouette and depth profile agree across the required views;
- secondary planes, transitions, openings, rims and edge thicknesses are present;
- local landmarks and intentional deviations survive neutral inspection;
- tertiary features are resolved at the scale of the chosen geometry or sampling;
- topology, metric, multi-view and parameter checks pass at final quality.

For a high-information constrained form, prefer this route:

```text
reference frame
→ semantic structure map
→ control cage / base topology
→ multi-view envelope fit
→ regional deformation
→ local constrained forms
→ multires or dense detail
→ neutral inspection and verification
```

Use a low-complexity control cage only as an editing coordinate system. The final
asset must be driven to the required resolution and detail level before scoring.
Do not let smooth shading, subdivision, dark materials, depth of field or a
large polygon count substitute for unresolved structure.

The representation decision is itself part of the task. If the first route cannot
move a required region independently without damaging adjacent regions, stop and
change route—typically to a control mesh, deformation cage, surface-constrained
mesh, or multires stack—rather than adding more disconnected primitives.

## The two modeling limits

**1. Representation capacity must match form information.**

A representation is suitable only when its parameters correspond to meaningful
changes in the target. Recursion, simulation and distributions efficiently
encode repeated or law-governed structure. A constrained surface, deformation
cage, cross-section stack or control mesh is better for dense continuous form.
Primitives are useful for primary masses, but become coordinate dumping when
used as independent patches for every local landmark.

Test representation capacity before building at full quality:

- Name the parameters that control silhouette, depth, cross-sections,
  junctions, negative spaces and local landmarks.
- Perturb each parameter and verify that the intended region moves while
  unrelated regions remain stable.
- Increase the model's structural complexity and confirm that new form appears,
  rather than merely resampling the same surface.
- If improving fidelity requires adding unrelated coordinates one by one, change
  the representation instead of continuing.

Resolution only samples the representation more finely. It cannot add a
missing structural degree of freedom.

**2. Only observable errors converge.**

A modeling loop needs more than a final projection. Inspect the object through
silhouettes, cross-sections, landmarks, normal fields, topology, component
relations and neutral multi-view renders. Each observation should answer one
specific question and identify the responsible structure when it fails.

Use visual review to discover an unmeasured defect class, then express the
confirmed defect as a structural constraint or measurement. Keep failed
attempts and repairs in the generated task trajectory; do not accumulate
object-specific failure stories in this reusable skill.

> Never optimize geometry against an undifferentiated beauty judgment. A useful
> signal says which structural level failed and what parameter or relation can
> change it.

## 装配验证：把多体拼接变成可问的问题

多体建模应先写声明式接触图，再构造网格。`procedural-3d-modeling` skill
中的 `scripts/assembly.py` 是唯一实现源；本 skill 通过
`bootstrap.add_sibling_skill("procedural-3d-modeling")` 以相对路径加载它，
不复制机器特定代码。

```python
import assembly as A
asm = A.Assembly()
asm.add("mass_a", mass_a_prims())
asm.add("mass_b", mass_b_prims(), parent="mass_a")
asm.require_contact("region_a", "region_b")

# 建网格前的廉价审计
thin = asm.audit_features(voxel=voxel, need=4.0)
report = asm.check(sc, samples=20000)
assert list(report["stages"]) == ["orphan_parts", "aabb", "field"]
```

三层验证必须按成本递增记录：孤立件 → AABB 预检 → 场接触测试。接触图还
必须只有一个连通分量；否则 `orphan_parts` 阶段失败，后两阶段返回
`status="skipped"`。AABB 只是必要条件，不是充分条件；两个包围盒相交
不代表两个结构真的接触。场探针使用固定 Halton 序列而不是不可复现的随机流。
焊接应使用 `A.weld(...)` 显式增加桥接体，并验证焊接前后的壳数、非流形边和
Euler 特征。薄连接审计要在昂贵构建前执行，且报告部件名与体素数。

装配关系属于结构约束：零件、接触关系、连接厚度和壳数都可写进 verifier。
不要用截图或 LLM judge 替代这些关系检查。


### Step 1 — classify where the information comes from

| class | information source | modeling strategy |
|---|---|---|
| **DERIVED** | rules, recursion, simulation, distributions | encode the generator and expose its causal parameters |
| **MIXED** | generated structure plus supplied local constraints | generate the common structure, then fit constrained regions |
| **SPECIFIED** | dense or unique constraints not implied by a compact rule | choose a representation that directly carries those constraints |

The classes describe information, not object categories. A single model may use
all three at different scales. Classify each semantic region independently and
compose the results in one structure graph.

For SPECIFIED form, the goal is not to avoid modeling; it is to avoid inventing
information through an unsuitable representation. Build the shared low-frequency
structure first, then carry supplied constraints through parameterized surfaces,
deformation fields, control meshes, cross-sections, landmarks, or other
continuous representations. Use primitives only for primary masses and use
procedural detail only where an actual rule exists.

A representation is adequate when it can express all of these without unrelated
coordinate edits:

1. outer silhouette from the required views;
2. depth and cross-section changes between those views;
3. semantic part layout and attachment relationships;
4. intentional openings, rims, gaps and overlaps;
5. secondary plane and curvature transitions;
6. bounded local deviations from the shared structure.

If the model reads incorrectly under a neutral material, return to the earliest
failed level. Do not add high-frequency detail, texture, noise or presentation
to compensate for a missing primary or secondary form.

### Step 2 — pick the generator, in this order

Prefer the highest tier that can express the target.

1. **Native structured generators.** Prefer curves, modifiers, Geometry Nodes,
   arrays, solidification, bevels and simulations when they directly encode the
   intended relation. They preserve exact structure and avoid voxel aliasing.
2. **Structured direct meshes** for surfaces, cards, section lofts and repeated
   elements whose topology is known explicitly.
3. **SDF field + mesher** when organic blending, robust CSG or a guaranteed
   closed union is central to the form. Accept the sampling cost deliberately.
4. **Deformation representations** — cages, basis fields, control meshes and
   shape parameters — when many coupled landmarks must move coherently.
5. **Displacement or material relief** for microstructure that does not change
   the required silhouette, openings or edge thickness.

Choose the representation whose controls correspond to the target's structure.
Do not choose it because it is the representation already used by a previous
script.

### Step 3 — sampling-rate discipline (SDF route only)

Aliasing, not modeling effort, is what makes sampled surfaces look chiselled
and crude. Measure it before blaming the model:

- A feature needs roughly **4 or more samples across its narrowest span** to
  read smoothly. If it is smaller, change the representation, enlarge the
  feature, or increase resolution before adding more detail.
- Prefer continuous blends and adjacent volumes for smooth transitions. A cut
  groove is a topology and sampling event; use it only when the opening or
  boundary is semantically required and it is adequately resolved.
- For high resolution, use a narrow band around the surface. Surface work scales
  with area while a full volume scales with the cube of resolution. Cull only
  with a measured bound that cannot remove a sign crossing; pad by several
  samples and audit the band against a lower-resolution full sample.

## Verifier-first workflow

Write the verifier **before** the model, like a test. It converts modeling from
 taste into a loop with an error signal.

```
1. STRUCTURE  declare semantic regions, relations, openings and expected topology
2. VERIFIER   assert structure, topology, proportions, silhouettes and features
3. BUILD      choose the representation and lowest adequate resolution
4. SCORE      fix the earliest and worst failing structural level only
5. REVIEW     discover defect classes that have no metric yet
6. PROMOTE    turn each confirmed defect into an assertion, then repeat
7. FINAL      build at final quality and verify again
```

Do not proceed to a finer level while a coarser level fails. A defect that is
only visible is easy to reintroduce; a defect expressed as a relation or
measurement stays fixed.

## The rubric

Semantic structure is a task-declared precondition. The existing six-axis
scorecard remains programmatic; hard gates come first. Full thresholds, weights
and reward shaping are in `references/rubric.md`, and the implemented common
checks remain in `scripts/verify_model.py`.

| stage | gate? | measured by |
|---|---|---|
| **Semantic structure** | task-declared gate | named regions, part relations, meaningful openings, adjacency and intended repetition |
| **Topology** | yes | shells, boundary/non-manifold edges, watertightness and task-declared genus |
| **Physical validity** | yes | support, contacts, centre of mass and task-declared constraints |
| **Metric accuracy** | no | landmarks, cross-sections, lengths, widths and normalized proportions |
| **Silhouette fidelity** | no | multi-view IoU / Chamfer, including a held-out view when available |
| **Detail adequacy** | no | feature size versus sampling or edge length; continuity audit |
| **Generative quality** | no | determinism, parameter liveness and scaling response |

**Semantic structure is not cosmetic.** A closed, manifold mesh may still fail if
its named regions are missing, its openings are painted instead of geometric,
its attachments are accidental, or repeated parts have no coherent relation.
Check the structure map before rewarding surface quality.

Topology gates must be declared per task, never assumed. A blanket one-shell
requirement can reject a correct multi-part or open-surface result. Universal
checks remain non-finite vertices, invalid indices, duplicate faces when
forbidden, zero-area faces, unintended boundaries and non-manifold edges.

Generative quality must test parameter liveness: perturb each named control and confirm the
intended region changes while unrelated regions remain stable. It must also test
scaling response so coordinate dumping and pure resampling do not masquerade as
generative structure.

## Authoring tasks for SFT / RL

Each task is a triple: **prompt, verifier, optional reference**. A task without a
verifier is unusable — do not add it to the set. Full spec format, difficulty
ladder and harness requirements are in `references/task-specs.md`.

- **Reward** uses multiplicative hard gates plus dense partial credit on the
  remaining axes. A single pass/fail gives little learning signal.
- **Declare task-specific topology and semantic structure.** Do not assume that
  every correct result has the same shell count, openness or part graph.
- **Anti-gaming.** Determinism blocks retry-until-lucky; scaling response blocks
  coordinate dumps; held-out observations block view overfitting; a complexity
  cap blocks refinement that adds no structure.
- **Record failures in the task trajectory.** Keep the first failed structural
  level, the measurement that exposed it, the responsible representation or
  control, and the repair that changed the score. Do not move these
  object-specific paths into the reusable skill.
- **Use review for discovery, not reward.** Once a defect is confirmed, encode it
  as a structural assertion or measurement before using it for training.

## Pitfalls specific to this route

**A numerical change can be imperceptible.** Calibrate every threshold against
the local object scale and the views where the feature must read. "Non-zero" is
not a useful target.

**Measure the intended region.** A global slice, bounding box or projection may
include unrelated structures. Define semantic masks or spatial support before
computing a dimension, profile or curvature statistic.

**Landmarks need a readable profile.** A landmark can satisfy its coordinate
constraint and still disappear inside the surrounding envelope. Check its
prominence and the intended monotonic or inflected profile between neighboring
landmarks.

**Higher resolution can change connectivity.** Fine sampling may remove an
accidental bridge that existed at coarse resolution. Fix the structural
connection or feature thickness; never use resolution as a welding strategy.

**Trust neither metric nor review alone.** When they disagree, convert the exact
claim into a direct measurement. Repair the metric if it measures the wrong
region; reject the review if the measured claim is false.

**Never name a module after a standard-library module.** Verifier code must
import cleanly outside the DCC application and remain suitable for a headless
pipeline.

## Verifying the verifier

The scorecard is code, so it needs tests before you trust its numbers. Use
meshes whose answers are known in closed form — `scripts/verify_model.py` ships
against 24 such assertions:

| fixture | expected |
|---|---|
| closed cube | shells 1, chi 2, genus 0, watertight, gate pass |
| two disjoint cubes | shells 2, chi 4, gate fail when 1 expected, pass when 2 |
| cube with lid removed | 4 boundary edges, gate fail |
| torus | shells 1, chi 0, genus 1; gate pass at genus 1, fail at genus 0 |
| offset-top cube | centre of mass outside footprint, physics gate fail |
| features at 1-8 voxels | known `frac_under_3` and score |

The torus case is the one that catches a wrong genus formula, and the two
gate-direction cases catch a verifier that always passes. A verifier that only
ever returns "pass" is worse than none: it launders failures into training data.

Axis 4 gets the same treatment — 20 assertions against outlines with closed-form
answers: a sphere's silhouette is a disc (area fraction `pi/4`, matched to
0.7202 vs 0.7261 theoretical, the gap being the inscribed polyhedron), a sphere
looks identical from all six views, two half-overlapping squares give IoU
exactly 1/3, and identical meshes give IoU 1.0 with Chamfer 0.

**Then run the verifier on representative real outputs, not just analytic
fixtures.** Fixtures establish correctness on known answers; real outputs expose
wrong universal assumptions, blind measurements and route-specific failure
modes. Record those failures in the task trajectory and promote only the
cross-task invariant into the reusable verifier.

## Session handling: probe, protect, export

### Write the script FIRST, then run the file

Over MCP, code is `exec`'d from a string. Verified on a live session:
`__file__` raises **NameError** and `__name__` is `"builtins"` — there is no
file on disk. So a "copy my source file" export silently produces a `.blend`
with **no `.py` beside it**: the scene survives, the reproducible artifact does
not, and it looks like success until someone tries to diff or re-run the model.

Sending code straight over MCP is therefore a one-way trip. Invert the order:

```python
import session as S
S.write_then_run(code, "~/blender_out/thing.py")   # writes, then runs the FILE
```

The file becomes the source of truth. The script gets a genuine `__file__`,
`__name__ == "__main__"` fires normally (`runpy` handles this), and the `.py`
can be re-run, diffed, parameterised, and fed to a training pipeline. From a
shell the equivalent is `blender -b -P thing.py`.

Verified end to end on a live 52-object scene: both artifacts landed, then the
object was **deleted and rebuilt from the file alone** — 49,926 polys, identical
placement, and the user's 52 objects untouched throughout.

Never reference a bare `__file__` in a model script. Resolve it defensively and
let it be `None`:

```python
SELF = globals().get("__file__")
SELF = os.path.abspath(SELF) if SELF and os.path.exists(SELF) else None
```

`S.finish()` raises by default when it has no source, rather than shipping half
a deliverable. Pass the code *text* if that is all you have.

### Protect what is already in the scene

Before building anything, detect what you are working in.
`scripts/session.py` implements this; the decision table is:

| detected | action |
|---|---|
| live scene, already holds real work | **save it to a timestamped `.blend` first**, then clear and build |
| live scene, empty or factory default (Cube+Camera+Light) | clear and build; nothing worth preserving |
| live scene, task says *"add X to this scene"* | **append in place — never clear** |
| no live Blender | the `.py` is the entire deliverable |

```python
import session as S
S.has_workspace()          # is a live scene reachable at all?
S.scene_census()           # what is in it: counts, polys, has_assets, filepath
S.prepare_scene(mode=...)  # auto | append | replace
S.finish(__file__, ...)    # writes .py, plus .blend and scorecard when live
```

**Distinguish "model X" from "add X to this scene".** The append case is the one
where clearing destroys the point of the task, and it cannot be inferred from
the scene — only from the request. Read the task, then set the mode.

**Always export both artifacts.** A `.blend` is an opaque binary only Blender
opens; the `.py` is the reproducible one — diffable, reviewable,
parameterisable, and the actual training-data payload. Ship the scorecard too,
so "this passed" travels with its evidence instead of living in a chat message.

Two implementation details that matter:

- Save with `bpy.ops.wm.save_as_mainfile(filepath=..., copy=True)`. Without
  `copy=True` you **hijack the user's session** — their editor silently starts
  pointing at your backup file. Verified on a real 152-object scene: the session
  still pointed at the user's own `.blend` afterwards.
- Timestamp every filename. Clobbering someone's previous save while
  "helpfully" saving is the worst possible outcome.

## Starting a new model

Copy `templates/new_model.py` and fill in three things, in this order:

1. **`SPEC`** — declare the gates *before* building. Writing
   `expect_shells` / `expect_genus` / `require_closed` forces the question
   "what does correct mean here?" while you can still choose the route. Set
   `session_mode` here too: `"auto"` to preserve-then-build, `"append"` when the
   task is to add to an existing scene.
2. **`build(n, seed)`** — one function, parameterised by a complexity knob,
   deterministic. If you cannot name a complexity parameter, the model is
   SPECIFIED and its detail will not scale — say so rather than discovering it
   at high resolution.
3. **`feature_sizes()`** — the aliasing audit for SDF routes; return `()` for
   others.

Then `python3 new_model.py` probes the session, scores the model, links it into
a live scene if there is one, and exports the `.py` + `.blend` + scorecard. It
runs headless; add `blender -b -P` only when the *build* needs Blender (curve
bevel, cloth, hair), or paste it into a live MCP-driven session.

The template sweeps all three scaling measures and scores against whichever sees
the route's detail, because none of them is universal. Its own example
demonstrates the trap: blending `n` bumps into a core *smooths* the outline
(-0.08) while adding real surface relief (+0.42). Read the three-line breakdown
rather than trusting a single number.

## References

| File | Contents |
|------|----------|
| `references/rubric.md` | Semantic precondition, six-axis thresholds, reward shaping and anti-gaming |
| `references/task-specs.md` | Task structure declarations, verifier configuration and trajectory logging |
| `scripts/verify_model.py` | Axes 1, 2, 5, 6: topology, physics, aliasing audit, scaling response, determinism, parameter liveness |
| `scripts/silhouette.py` | Axis 4: numpy silhouette rasterization, multi-view IoU, Chamfer, held-out cameras, outline complexity |
| `scripts/test_verify_model.py` | 34 assertions against closed-form fixtures. Run before trusting a score |
| `scripts/test_silhouette.py` | 20 assertions: disc area, isotropy, exact IoU values, determinism |
| `scripts/ab_c1_vs_cut.py` | The C1-blend vs cut-groove roughness experiment, re-runnable via `SDF_CORE_DIR` |
| `scripts/session.py` | MCP/workspace probe, scene census, preserve-vs-append triage, dual `.blend` + `.py` export |
| `templates/new_model.py` | Copy-to-start scaffold: session handling, task spec, build stub, full scorecard, scaling-measure sweep |

Both scripts are pure numpy and import cleanly **outside** Blender. Keep it that
way — a scoring pipeline that needs a GUI cannot run. Blender is required only to
*build* certain routes (curve bevel, cloth sim), never to score.
