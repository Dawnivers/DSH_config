"""A/B: is a C1 smooth-union valley really less aliased than a cut groove?

The SKILL claims "prefer C1 blends over cut grooves". That was an inference from
sampling theory, not a measurement. This tests it.

Both models make the SAME visible feature -- a valley running across a slab --
by two different constructions:

  A) two adjacent bulges joined with smooth_union  -> the valley is a C1 blend
  B) one slab with a capsule subtracted from it    -> the valley is a cut slot

Roughness metric: the dihedral angle between adjacent faces inside the feature
region. A smooth surface has small, slowly-varying dihedrals. Voxel staircasing
produces alternating near-90-degree flips, so the mean and the tail of the
dihedral distribution both rise. Measured across a resolution sweep, so we can
see which construction CONVERGES and which stays rough.
"""
import os
import sys

import numpy as np

# Optionally override this with a directory containing sdf_core.py. Otherwise
# resolve the sibling modeling skill relative to this checkout/install.
HERE = os.path.dirname(os.path.abspath(__file__))
SDF_DIR = os.environ.get(
    "SDF_CORE_DIR",
    os.path.abspath(os.path.join(HERE, "..", "..", "procedural-3d-modeling", "scripts")),
)
sys.path.insert(0, SDF_DIR)
import sdf_core as sc


def make_c1(valley_width):
    """Two bulges whose blend leaves a valley of roughly `valley_width`."""
    f = sc.Field()
    k = valley_width * 0.9          # blend radius sets the valley softness
    f.add(sc.Box((0, 0, -0.30), (0.60, 0.30, 0.20), round_r=0.05))
    off = valley_width * 0.5 + 0.16
    f.add(sc.Ellipsoid((0, -off, 0.0), (0.55, 0.17, 0.17), smooth=k))
    f.add(sc.Ellipsoid((0, off, 0.0), (0.55, 0.17, 0.17), smooth=k))
    return f


def make_cut(valley_width):
    """One slab with a capsule cut into it -- same silhouette, cut construction."""
    f = sc.Field()
    f.add(sc.Box((0, 0, -0.30), (0.60, 0.30, 0.20), round_r=0.05))
    f.add(sc.Ellipsoid((0, 0, 0.0), (0.55, 0.33, 0.17), smooth=0.05))
    f.add(sc.Capsule((-0.65, 0, 0.17), (0.65, 0, 0.17),
                     r=valley_width * 0.5, subtract=True, smooth=0.01))
    return f


def dihedral_stats(verts, faces, region=None):
    """Mean/p95 dihedral angle (degrees) between adjacent faces.

    Staircasing shows up as a heavy tail: alternating flips near 90 degrees.
    """
    V = np.asarray(verts, dtype=float)
    normals, centres = [], []
    for f in faces:
        p = V[list(f)]
        n = np.cross(p[1] - p[0], p[2] - p[0])
        ln = np.linalg.norm(n)
        if ln < 1e-12:
            normals.append(None); centres.append(p.mean(0)); continue
        normals.append(n / ln)
        centres.append(p.mean(0))

    edge_faces = {}
    for fi, f in enumerate(faces):
        n = len(f)
        for i in range(n):
            a, b = f[i], f[(i + 1) % n]
            k = (a, b) if a < b else (b, a)
            edge_faces.setdefault(k, []).append(fi)

    angs = []
    for k, fl in edge_faces.items():
        if len(fl) != 2:
            continue
        n1, n2 = normals[fl[0]], normals[fl[1]]
        if n1 is None or n2 is None:
            continue
        if region is not None:
            c = (centres[fl[0]] + centres[fl[1]]) / 2.0
            if not region(c):
                continue
        angs.append(np.degrees(np.arccos(np.clip(float(n1 @ n2), -1, 1))))
    if not angs:
        return None
    a = np.asarray(angs)
    return {"n_edges": len(a), "mean": float(a.mean()),
            "p95": float(np.percentile(a, 95)), "max": float(a.max())}


# the valley runs along x at y~0, z~top: only score faces near it
def valley_region(c):
    return abs(c[1]) < 0.12 and c[2] > 0.02 and abs(c[0]) < 0.45


VALLEY_W = 0.055        # a deliberately small feature, like a real groove
print(f"valley width = {VALLEY_W}\n")
print(f"{'res':>5} {'voxel':>8} {'vox/feat':>9} | "
      f"{'C1 mean':>8} {'C1 p95':>7} | {'CUT mean':>9} {'CUT p95':>8}")
print("-" * 72)

rows = []
for res in (60, 90, 130, 180, 240):
    out = {}
    for label, mk in (("c1", make_c1), ("cut", make_cut)):
        f = mk(VALLEY_W)
        v, fc, st = sc.build_mesh(f, res=res, newton=2, verbose=False)
        lo, hi = f.bounds(pad=0.06)
        voxel = float((hi - lo).max() / res)
        d = dihedral_stats(v, fc, region=valley_region)
        out[label] = (voxel, d, len(v))
    vox = out["c1"][0]
    c1, cut = out["c1"][1], out["cut"][1]
    if c1 and cut:
        print(f"{res:5d} {vox:8.4f} {VALLEY_W / vox:9.2f} | "
              f"{c1['mean']:8.2f} {c1['p95']:7.2f} | "
              f"{cut['mean']:9.2f} {cut['p95']:8.2f}")
        rows.append((res, vox, VALLEY_W / vox, c1, cut))

print("\ninterpretation")
if rows:
    r0, rN = rows[0], rows[-1]
    print(f"  C1  mean dihedral {r0[3]['mean']:.2f} -> {rN[3]['mean']:.2f} deg "
          f"as voxels-per-feature goes {r0[2]:.1f} -> {rN[2]:.1f}")
    print(f"  CUT mean dihedral {r0[4]['mean']:.2f} -> {rN[4]['mean']:.2f} deg")
    print(f"  p95 tail at the LOWEST res:  C1 {r0[3]['p95']:.1f}  CUT {r0[4]['p95']:.1f}")
    print(f"  p95 tail at the HIGHEST res: C1 {rN[3]['p95']:.1f}  CUT {rN[4]['p95']:.1f}")
    ratio_lo = r0[4]['mean'] / max(r0[3]['mean'], 1e-9)
    ratio_hi = rN[4]['mean'] / max(rN[3]['mean'], 1e-9)
    print(f"  CUT/C1 roughness ratio: {ratio_lo:.2f}x at low res, "
          f"{ratio_hi:.2f}x at high res")
