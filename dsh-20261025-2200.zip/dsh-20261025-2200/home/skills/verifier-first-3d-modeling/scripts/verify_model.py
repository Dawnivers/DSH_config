"""verify_model.py -- programmatic scorecard for a scripted 3D model.

No human and no LLM appears in this score. Implements rubric axes 1 (topology),
2 (physical validity), 5 (detail adequacy) and 6 (generative quality); axes 3
and 4 need a per-task spec or reference and are left as hooks.

Run inside Blender, or pass raw arrays:

    import verify_model as vm
    card = vm.score(verts, faces, source_path="model.py", voxel=0.021,
                    feature_sizes=[...], build=lambda: build_fn())
    print(vm.format_card(card))

Everything returns plain dicts so a data pipeline can log them as JSON.
"""

import json
import numpy as np


# ------------------------------------------------------------------ topology

def geometry_quality(verts, faces, duplicate_tol=1e-9,
                     strict_duplicates=True, area_tol=1e-12):
    """Check geometric validity that edge topology alone cannot see.

    Duplicate vertices are reported separately because UV seams can make them
    intentional in some mesh routes. Set ``strict_duplicates=False`` when they
    are a warning rather than a hard task gate.
    """
    V = np.asarray(verts, dtype=float)
    duplicate_vertices = 0
    nonfinite_vertices = 0
    if V.ndim != 2 or V.shape[1] != 3:
        return {"duplicate_vertices": 0, "duplicate_faces": 0,
                "degenerate_faces": 0, "invalid_faces": len(faces),
                "nonfinite_vertices": len(V), "gate": False,
                "reason": "vertices must have shape (N, 3)"}

    finite = np.isfinite(V).all(axis=1)
    nonfinite_vertices = int((~finite).sum())
    if len(V):
        scale = max(float(np.abs(V[finite]).max()) if finite.any() else 1.0,
                    1.0)
        tol = max(float(duplicate_tol), np.finfo(float).eps * scale)
        keys = np.round(V / tol).astype(np.int64) if finite.all() else None
        if keys is not None:
            duplicate_vertices = int(len(keys) - len({tuple(k) for k in keys}))

    duplicate_faces = 0
    degenerate_faces = 0
    invalid_faces = 0
    seen_faces = set()
    for face in faces:
        try:
            idx = tuple(int(i) for i in face)
        except (TypeError, ValueError):
            invalid_faces += 1
            continue
        if len(idx) < 3 or any(i < 0 or i >= len(V) for i in idx):
            invalid_faces += 1
            continue
        canonical = tuple(sorted(idx))
        if canonical in seen_faces:
            duplicate_faces += 1
        seen_faces.add(canonical)
        if len(set(idx)) < 3:
            degenerate_faces += 1
            continue
        p = V[list(idx)]
        if not np.isfinite(p).all():
            degenerate_faces += 1
            continue
        area = 0.0
        for i in range(1, len(p) - 1):
            area += 0.5 * float(np.linalg.norm(np.cross(
                p[i] - p[0], p[i + 1] - p[0])))
        if area <= float(area_tol):
            degenerate_faces += 1

    gate = (nonfinite_vertices == 0 and invalid_faces == 0 and
            degenerate_faces == 0 and duplicate_faces == 0 and
            (not strict_duplicates or duplicate_vertices == 0))
    return {
        "duplicate_vertices": duplicate_vertices,
        "duplicate_faces": duplicate_faces,
        "degenerate_faces": degenerate_faces,
        "invalid_faces": invalid_faces,
        "nonfinite_vertices": nonfinite_vertices,
        "strict_duplicates": bool(strict_duplicates),
        "gate": bool(gate),
    }


def topology(verts, faces, expect_shells=1, expect_genus=None,
             require_closed=True, reject_duplicate_vertices=False):
    """Axis 1. A gate: a non-manifold or open mesh is unusable.

    The gate is TASK-DEPENDENT, not universal. Pass `expect_shells=None` to skip
    the component check and `require_closed=False` for open surfaces. Both are
    needed by legitimate routes: a curve-bevelled tree measured 25718 shells
    (every branch tube and leaf card is its own solid) and a heightfield terrain
    is an open sheet. Gating those on "shells == 1, watertight" would reject
    correct models, so the task spec must declare the intent.
    """
    V = len(verts)
    quality = geometry_quality(verts, faces,
                               strict_duplicates=reject_duplicate_vertices)

    valid_faces = []
    for face in faces:
        try:
            idx = tuple(int(i) for i in face)
        except (TypeError, ValueError):
            continue
        if len(idx) >= 3 and all(0 <= i < V for i in idx):
            valid_faces.append(idx)
    F = len(valid_faces)
    edge_count = {}
    for f in valid_faces:
        n = len(f)
        for i in range(n):
            a, b = f[i], f[(i + 1) % n]
            k = (a, b) if a < b else (b, a)
            edge_count[k] = edge_count.get(k, 0) + 1

    E = len(edge_count)
    boundary = sum(1 for c in edge_count.values() if c == 1)
    nonmanifold = sum(1 for c in edge_count.values() if c > 2)

    # union-find over edges -> connected components
    parent = list(range(V))

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    for a, b in edge_count:
        ra, rb = find(a), find(b)
        if ra != rb:
            parent[ra] = rb
    used = {find(i) for e in edge_count for i in e}
    shells = len(used)

    chi = V - E + F
    genus = None
    if shells and boundary == 0 and nonmanifold == 0:
        # chi = 2*shells - 2*genus_total  for closed orientable surfaces
        g2 = 2 * shells - chi
        genus = g2 // 2 if g2 % 2 == 0 else None

    ok_shells = expect_shells is None or shells == expect_shells
    ok_manifold = nonmanifold == 0
    ok_closed = (boundary == 0) or not require_closed
    ok_genus = expect_genus is None or genus == expect_genus
    ok_geometry = quality["gate"]

    return {
        "V": V, "E": E, "F": F, "euler_chi": chi,
        "shells": shells, "boundary_edges": boundary,
        "nonmanifold_edges": nonmanifold, "genus": genus,
        "geometry": quality,
        "checks": {
            "shells": ok_shells, "manifold": ok_manifold,
            "watertight": ok_closed, "genus": ok_genus,
            "geometry": ok_geometry,
        },
        "gate": bool(ok_shells and ok_manifold and ok_closed and ok_genus and
                      ok_geometry),
    }


# ------------------------------------------------------------------- physics

def convex_hull_2d(points, tol=1e-12):
    """Monotonic-chain convex hull, pure NumPy/Python and scipy-free."""
    P = np.asarray(points, dtype=float)
    if P.ndim != 2 or P.shape[1] != 2 or len(P) == 0:
        return np.zeros((0, 2), dtype=float)
    unique = sorted({(float(x), float(y)) for x, y in P
                     if np.isfinite(x) and np.isfinite(y)})
    if len(unique) <= 1:
        return np.asarray(unique, dtype=float)

    def cross(o, a, b):
        return ((a[0] - o[0]) * (b[1] - o[1]) -
                (a[1] - o[1]) * (b[0] - o[0]))

    lower = []
    for p in unique:
        while len(lower) >= 2 and cross(lower[-2], lower[-1], p) <= tol:
            lower.pop()
        lower.append(p)
    upper = []
    for p in reversed(unique):
        while len(upper) >= 2 and cross(upper[-2], upper[-1], p) <= tol:
            upper.pop()
        upper.append(p)
    return np.asarray(lower[:-1] + upper[:-1], dtype=float)


def _point_in_convex_polygon(point, polygon, tol=1e-9):
    P = np.asarray(point, dtype=float)
    H = np.asarray(polygon, dtype=float)
    if len(H) == 0:
        return False
    if len(H) == 1:
        return bool(np.linalg.norm(P - H[0]) <= tol)
    if len(H) == 2:
        d = H[1] - H[0]
        t = float((P - H[0]) @ d) / max(float(d @ d), tol)
        q = H[0] + np.clip(t, 0.0, 1.0) * d
        return bool(np.linalg.norm(P - q) <= tol)
    signs = []
    for i in range(len(H)):
        a, b = H[i], H[(i + 1) % len(H)]
        signs.append((b[0] - a[0]) * (P[1] - a[1]) -
                     (b[1] - a[1]) * (P[0] - a[0]))
    signs = np.asarray(signs)
    return bool(signs.min() >= -tol or signs.max() <= tol)


def _point_segment_distance(point, a, b):
    d = b - a
    t = float((point - a) @ d) / max(float(d @ d), 1e-30)
    q = a + np.clip(t, 0.0, 1.0) * d
    return float(np.linalg.norm(point - q))


def physical_validity(verts, faces, ground_z=None, contact_tol=0.02):
    """Axis 2. A gate: centre of mass must sit over the support footprint.

    Uses the area-weighted surface centroid as a shell-mass proxy, which is the
    right model for a printed or cast object and needs no volume integration.
    """
    Vp = np.asarray(verts, dtype=float)
    if ground_z is None:
        ground_z = float(Vp[:, 2].min())

    cents, areas = [], []
    for f in faces:
        p = Vp[list(f)]
        # fan triangulation; polygons here are tris or quads
        for i in range(1, len(p) - 1):
            a, b, c = p[0], p[i], p[i + 1]
            n = np.cross(b - a, c - a)
            ar = 0.5 * float(np.linalg.norm(n))
            if ar > 0:
                areas.append(ar)
                cents.append((a + b + c) / 3.0)
    if not areas:
        return {"gate": False, "reason": "no area"}
    areas = np.asarray(areas)
    com = (np.asarray(cents) * areas[:, None]).sum(0) / areas.sum()

    contact = Vp[Vp[:, 2] <= ground_z + contact_tol][:, :2]
    hull = convex_hull_2d(contact)
    inside = _point_in_convex_polygon(com[:2], hull)
    margin = None
    if len(hull) >= 2:
        margin = min(_point_segment_distance(com[:2], hull[i],
                                             hull[(i + 1) % len(hull)])
                     for i in range(len(hull) if len(hull) > 2 else 1))
    return {
        "com": [round(float(c), 4) for c in com],
        "contact_points": int(len(contact)),
        "com_over_support": inside,
        "hull_margin": margin,
        "support_hull": np.round(hull, 6).tolist(),
        "gate": bool(inside),
    }


# -------------------------------------------------------------------- detail

def detail_adequacy(feature_sizes, voxel, need=4.0):
    """Axis 5. Aliasing is measurable; measure it instead of arguing.

    `feature_sizes` are the smallest dimension of each authored feature (groove
    width, lip thickness, finger diameter) in world units.
    """
    if not len(feature_sizes) or not voxel:
        return {"score": None, "reason": "no features or voxel given"}
    r = np.asarray(feature_sizes, dtype=float) / float(voxel)
    return {
        "voxel": voxel,
        "ratio_min": round(float(r.min()), 2),
        "ratio_median": round(float(np.median(r)), 2),
        "frac_under_2": round(float((r < 2).mean()), 3),
        "frac_under_3": round(float((r < 3).mean()), 3),
        "frac_ok": round(float((r >= need).mean()), 3),
        "score": round(float((r >= need).mean()), 3),
        "worst_features": np.argsort(r)[:8].tolist(),
    }


# ---------------------------------------------------------------- generative

def _source_lines(path):
    """Non-blank, non-comment lines of a source file.

    Returns [] when the path is missing or unreadable. That happens for real
    under MCP, where code is exec'd from a string and there is no file at all --
    the line count degrades to 0 instead of crashing the whole scorecard.
    """
    try:
        with open(path) as fh:
            src = fh.read()
    except (OSError, TypeError, ValueError):
        return []
    return [l for l in src.split("\n")
            if l.strip() and not l.strip().startswith("#")]


def surface_roughness(verts, faces):
    """Mean dihedral angle (degrees) between adjacent faces.

    An interior-detail measure: it sees relief that never reaches the outline,
    which is exactly what silhouette complexity misses on a heightfield.
    """
    V = np.asarray(verts, dtype=float)
    normals = []
    for f in faces:
        p = V[list(f)]
        n = np.cross(p[1] - p[0], p[2] - p[0])
        ln = np.linalg.norm(n)
        normals.append(None if ln < 1e-12 else n / ln)
    ef = {}
    for fi, f in enumerate(faces):
        n = len(f)
        for i in range(n):
            a, b = f[i], f[(i + 1) % n]
            ef.setdefault((a, b) if a < b else (b, a), []).append(fi)
    angs = []
    for fl in ef.values():
        if len(fl) != 2:
            continue
        n1, n2 = normals[fl[0]], normals[fl[1]]
        if n1 is None or n2 is None:
            continue
        angs.append(np.degrees(np.arccos(np.clip(float(n1 @ n2), -1, 1))))
    return float(np.mean(angs)) if angs else 0.0


def poly_measure(verts, faces):
    return float(max(len(faces), 1))


def scaling_response(build_at, values, source_path=None, measure=None):
    """The compressibility test: does output grow while source does not?

    `build_at(v)` builds the model with its complexity parameter set to `v` and
    returns (verts, faces). Fit `log(measure)` against `log(v)`.

    **The output measure must match the route, and no single one works.**
    Measured across five models:

    - `poly_measure` (default) counts geometry. It cannot tell new detail from
      resampling: raising a mesher's resolution on a fixed 1105-primitive figure
      scored slope 1.99, indistinguishable from a terrain at 2.02.
    - `silhouette.outline_complexity` sees detail that reaches the outline. It
      correctly flattened to -0.001 for that resampled figure and rose to +0.236
      for an involute gear as tooth count grew — but it saturates when a canopy
      closes (a tree scored -0.92 as foliage occluded its own structure) and is
      blind to interior relief (a heightfield stayed flat at +0.003).
    - `surface_roughness` sees interior relief: the same heightfield rose 0.195
      with noise octaves versus 0.105 for pure resampling.

    The structural diagnostic is more reliable than any of them: **ask whether a
    model-level complexity parameter exists at all.** A rule-based model has one
    (teeth, max_depth, octaves) that adds features with the source untouched. A
    hand-specified model has none — its only knob resamples what is already
    there, which is precisely what makes it incompressible.
    """
    m = measure or poly_measure
    xs, ys = [], []
    for v in values:
        try:
            r = build_at(v)
            verts, faces = (r[0], r[1]) if isinstance(r, tuple) else (r, [])
            xs.append(float(v))
            ys.append(float(max(m(verts, faces), 1e-9)))
        except Exception as exc:
            return {"slope": None, "error": f"{type(exc).__name__}: {exc}"}
    if len(xs) < 2:
        return {"slope": None, "error": "need >= 2 parameter values"}

    lx, ly = np.log(np.asarray(xs)), np.log(np.asarray(ys))
    slope = float(np.polyfit(lx, ly, 1)[0]) if lx.std() > 1e-12 else 0.0
    out = {
        "values": xs,
        "polys": [int(y) for y in ys],
        "slope": round(slope, 3),
        "growth": round(float(ys[-1] / max(ys[0], 1)), 2),
    }
    if source_path:
        out["source_lines"] = len(_source_lines(source_path))
    # slope >= 1 means detail scales at least linearly with the parameter for
    # free; that is the signature of a generative description
    out["score"] = round(float(np.clip(slope / 2.0, 0.0, 1.0)), 3)
    return out


def generative_quality(n_polys, source_path, build=None, params=None,
                       anchor_hi=9465.0, anchor_lo=127.0, scaling=None):
    """Axis 6. Does the script encode rules, or transcribe coordinates?

    `polys_per_line` is reported for continuity but is NOT used in the score:
    measured across five models it failed to separate the classes (gear 11 and
    cloth 37, both fully rule-derived, fell below a hand-specified figure at
    111). Pass `scaling` from `scaling_response()` for the metric that works.
    """
    lines = _source_lines(source_path)
    ppl = n_polys / max(len(lines), 1)
    lo, hi = np.log10(anchor_lo), np.log10(anchor_hi)
    compress = float(np.clip((np.log10(max(ppl, 1.0)) - lo) / (hi - lo), 0, 1))

    out = {
        "source_lines": len(lines),
        "polys": int(n_polys),
        "polys_per_line": round(float(ppl), 1),
        "polys_per_line_normed": round(compress, 3),
        "_note": "polys_per_line is diagnostic only; use scaling_response",
    }
    if scaling is not None:
        out["scaling"] = scaling
        out["compressibility"] = scaling.get("score")
    else:
        out["compressibility"] = None

    if build is not None:
        a = build()
        b = build()
        va = np.asarray(a[0] if isinstance(a, tuple) else a, dtype=float)
        vb = np.asarray(b[0] if isinstance(b, tuple) else b, dtype=float)
        same = va.shape == vb.shape and bool(np.allclose(va, vb, atol=1e-9))
        out["deterministic"] = same
    else:
        out["deterministic"] = None

    # params: {"name": (setter, expected_direction)} -- perturb and confirm the
    # mesh actually moves. Catches parameters that are comments pretending to
    # be code, e.g. a rotation applied to one primitive's axes rather than to a
    # part group, which changes no landmark at all.
    if params:
        resp = {}
        for name, (setter, _dir) in params.items():
            try:
                before = np.asarray(build()[0], dtype=float)
                setter()
                after = np.asarray(build()[0], dtype=float)
                moved = (before.shape != after.shape or
                         float(np.abs(before - after).max()) > 1e-6)
                resp[name] = bool(moved)
            except Exception as exc:
                resp[name] = f"error: {exc}"
        out["param_response"] = resp
        live = [v for v in resp.values() if v is True]
        out["param_live_frac"] = round(len(live) / max(len(resp), 1), 3)

    parts = []
    if out["compressibility"] is not None:
        parts.append(out["compressibility"])
    if out["deterministic"] is not None:
        parts.append(1.0 if out["deterministic"] else 0.0)
    if "param_live_frac" in out:
        parts.append(out["param_live_frac"])
    out["score"] = round(float(np.mean(parts)), 3) if parts else None
    return out


# ----------------------------------------------------------------- scorecard

def shell_report(verts, faces, top=8):
    """Per-component diagnostics: size and bounding box of each shell.

    When a build reports "4 shells", the only useful next question is WHICH
    four. The bounding boxes point straight at the offending part -- that is how
    a stray sliver at z~2.5 was traced to a crease cutter that tunnelled under a
    thin flap instead of passing clear through the surface.
    """
    V = np.asarray(verts, dtype=float)
    n = len(V)
    if n == 0:
        return []
    parent = list(range(n))

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    for f in faces:
        r = find(int(f[0]))
        for i in f[1:]:
            r2 = find(int(i))
            if r != r2:
                parent[r2] = r
                r = find(r)

    roots = np.array([find(i) for i in range(n)])
    uniq, counts = np.unique(roots, return_counts=True)
    out = []
    for k in np.argsort(-counts)[:top]:
        sub = V[roots == uniq[k]]
        out.append({
            "verts": int(counts[k]),
            "frac": round(float(counts[k]) / n, 4),
            "lo": np.round(sub.min(axis=0), 3).tolist(),
            "hi": np.round(sub.max(axis=0), 3).tolist(),
        })
    return out


WEIGHTS = {"metric": 0.30, "silhouette": 0.30, "detail": 0.15, "generative": 0.25}


def score(verts, faces, source_path=None, voxel=None, feature_sizes=(),
          build=None, params=None, expect_shells=1, expect_genus=None,
          ground_z=None, metric_score=None, silhouette_score=None,
          weights=None, assembly_report=None,
          reject_duplicate_vertices=False):
    """Full scorecard. Gates are multiplicative; the rest is dense credit."""
    w = dict(WEIGHTS)
    if weights:
        w.update(weights)

    card = {
        "topology": topology(verts, faces, expect_shells, expect_genus,
                              reject_duplicate_vertices=reject_duplicate_vertices),
        "physics": physical_validity(verts, faces, ground_z),
        "detail": detail_adequacy(feature_sizes, voxel) if voxel else None,
        "generative": (generative_quality(len(faces), source_path, build, params)
                       if source_path else None),
        "metric": metric_score,
        "silhouette": silhouette_score,
        "assembly": (None if assembly_report is None else {
            "gate": bool(assembly_report.get("ok", False)),
            "report": assembly_report,
        }),
    }

    gate = 1.0 if (card["topology"]["gate"] and
                    card["physics"].get("gate") and
                    (card["assembly"] is None or
                     card["assembly"]["gate"])) else 0.0

    terms, used = 0.0, 0.0
    for key, wt in w.items():
        s = card.get(key)
        if isinstance(s, dict):
            s = s.get("score")
        if s is None:
            continue
        terms += wt * float(s)
        used += wt
    quality = terms / used if used else 0.0

    card["gate"] = gate
    card["quality"] = round(quality, 4)
    card["total"] = round(gate * quality, 4)
    card["weights_used"] = {k: v for k, v in w.items()
                            if card.get(k) is not None}
    return card


def format_card(card):
    t, p = card["topology"], card["physics"]
    L = ["--- scorecard ---",
         "GATE %s   quality %.3f   TOTAL %.3f" % (
             "PASS" if card["gate"] else "FAIL", card["quality"], card["total"]),
         "topology  shells=%d nonmanifold=%d boundary=%d chi=%d genus=%s -> %s" % (
             t["shells"], t["nonmanifold_edges"], t["boundary_edges"],
             t["euler_chi"], t["genus"], "ok" if t["gate"] else "FAIL"),
         "physics   com=%s over_support=%s -> %s" % (
             p.get("com"), p.get("com_over_support"),
             "ok" if p.get("gate") else "FAIL")]
    if card.get("assembly") is not None:
        a = card["assembly"]
        L.append("assembly  gate=%s -> %s" % (
            a["gate"], "ok" if a["gate"] else "FAIL"))
    if card.get("detail"):
        d = card["detail"]
        L.append("detail    median %.2f voxels, %.0f%% under 3, score %s" % (
            d.get("ratio_median", 0), 100 * d.get("frac_under_3", 0), d.get("score")))
    if card.get("generative"):
        g = card["generative"]
        comp = g.get("compressibility")
        L.append("generative %d polys / %d lines = %.0f per line (diagnostic), "
                 "compressibility %s, deterministic %s, score %s" % (
                     g["polys"], g["source_lines"], g["polys_per_line"],
                     "n/a (no scaling sweep)" if comp is None else "%.2f" % comp,
                     g["deterministic"], g["score"]))
        if g.get("scaling"):
            s = g["scaling"]
            L.append("scaling   slope %s over %s -> growth %sx" % (
                s.get("slope"), s.get("values"), s.get("growth")))
    return "\n".join(L)


def to_json(card, path):
    with open(path, "w") as fh:
        json.dump(card, fh, indent=2, default=str)
