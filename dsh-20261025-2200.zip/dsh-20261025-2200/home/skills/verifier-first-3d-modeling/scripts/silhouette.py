"""silhouette.py -- rubric axis 4: multi-view silhouette fidelity.

This is the axis that answers the blindness problem. An agent cannot see whether
its model looks right, but it CAN compute how much its outline overlaps a
reference outline. That turns an aesthetic question into a gradient.

Design choice: silhouettes are RASTERIZED FROM THE MESH with numpy, not rendered.
No GPU, no render engine, no Blender needed, bit-identical across machines, and
fast enough to sit inside a scoring loop. A render pass would add a dozen
settings (samples, denoiser, colour management) that all leak into the score.

    import silhouette as sil
    masks = sil.mask_set(verts, faces, res=256)          # 6 canonical views
    card  = sil.score(masks, ref_masks, holdout=("three_quarter",))
"""

import numpy as np

# Canonical view directions. Names are what the scorecard reports, so keep them
# stable -- a task spec refers to them when declaring a held-out view.
VIEWS = {
    "front":         (0.0, -1.0, 0.0),
    "back":          (0.0, 1.0, 0.0),
    "left":          (-1.0, 0.0, 0.0),
    "right":         (1.0, 0.0, 0.0),
    "top":           (0.0, 0.0, 1.0),
    "three_quarter": (-0.707, -0.707, 0.0),
}


def _frame(view_dir, up=(0.0, 0.0, 1.0)):
    """Orthonormal camera frame looking along `view_dir`."""
    f = np.asarray(view_dir, dtype=float)
    f /= np.linalg.norm(f)
    u = np.asarray(up, dtype=float)
    if abs(float(f @ u)) > 0.99:          # looking up/down: pick another up
        u = np.array([0.0, 1.0, 0.0])
    r = np.cross(u, f)
    r /= np.linalg.norm(r)
    u2 = np.cross(f, r)
    return r, u2 / np.linalg.norm(u2)


def rasterize(verts, faces, view_dir, res=256, margin=0.04, bounds=None):
    """Boolean silhouette mask of the mesh seen along `view_dir`.

    Uses edge-function (barycentric sign) rasterization per triangle over its
    own pixel bounding box, so cost scales with covered area rather than with
    grid size.

    `bounds` lets several meshes share one projection so their masks are
    directly comparable; pass the value returned in the result dict.
    """
    V = np.asarray(verts, dtype=float)
    r, u = _frame(view_dir)
    P = np.stack([V @ r, V @ u], axis=1)

    if bounds is None:
        lo, hi = P.min(0), P.max(0)
        c = (lo + hi) / 2.0
        half = float((hi - lo).max()) / 2.0
        half *= 1.0 + margin
        bounds = (float(c[0] - half), float(c[1] - half), 2.0 * half)
    x0, y0, span = bounds

    # pixel coordinates
    Q = np.empty_like(P)
    Q[:, 0] = (P[:, 0] - x0) / span * (res - 1)
    Q[:, 1] = (P[:, 1] - y0) / span * (res - 1)

    tris = []
    for f in faces:
        n = len(f)
        for i in range(1, n - 1):
            tris.append((f[0], f[i], f[i + 1]))
    T = np.asarray(tris, dtype=np.int64)

    mask = np.zeros((res, res), dtype=bool)
    A, B, C = Q[T[:, 0]], Q[T[:, 1]], Q[T[:, 2]]

    # cull degenerate triangles: zero projected area contributes nothing
    area2 = ((B[:, 0] - A[:, 0]) * (C[:, 1] - A[:, 1]) -
             (B[:, 1] - A[:, 1]) * (C[:, 0] - A[:, 0]))
    keep = np.abs(area2) > 1e-12
    A, B, C, area2 = A[keep], B[keep], C[keep], area2[keep]

    xmin = np.clip(np.floor(np.minimum.reduce([A[:, 0], B[:, 0], C[:, 0]])), 0, res - 1).astype(int)
    xmax = np.clip(np.ceil(np.maximum.reduce([A[:, 0], B[:, 0], C[:, 0]])), 0, res - 1).astype(int)
    ymin = np.clip(np.floor(np.minimum.reduce([A[:, 1], B[:, 1], C[:, 1]])), 0, res - 1).astype(int)
    ymax = np.clip(np.ceil(np.maximum.reduce([A[:, 1], B[:, 1], C[:, 1]])), 0, res - 1).astype(int)

    for k in range(len(A)):
        i0, i1, j0, j1 = xmin[k], xmax[k], ymin[k], ymax[k]
        if i1 < i0 or j1 < j0:
            continue
        xs = np.arange(i0, i1 + 1) + 0.5
        ys = np.arange(j0, j1 + 1) + 0.5
        gx, gy = np.meshgrid(xs, ys, indexing="ij")
        a, b, c, s = A[k], B[k], C[k], np.sign(area2[k])
        w0 = ((b[0] - a[0]) * (gy - a[1]) - (b[1] - a[1]) * (gx - a[0])) * s
        w1 = ((c[0] - b[0]) * (gy - b[1]) - (c[1] - b[1]) * (gx - b[0])) * s
        w2 = ((a[0] - c[0]) * (gy - c[1]) - (a[1] - c[1]) * (gx - c[0])) * s
        inside = (w0 >= 0) & (w1 >= 0) & (w2 >= 0)
        if inside.any():
            mask[i0:i1 + 1, j0:j1 + 1] |= inside

    return {"mask": mask, "bounds": bounds, "res": res}


def mask_set(verts, faces, res=256, views=None, shared_bounds=True):
    """Rasterize every canonical view. Returns {name: mask}.

    With `shared_bounds` the same world-space window is used for all views, so a
    lopsided model cannot win by being re-framed per view.
    """
    names = list(views or VIEWS.keys())
    V = np.asarray(verts, dtype=float)
    out, bounds = {}, None
    if shared_bounds:
        c = (V.min(0) + V.max(0)) / 2.0
        half = float((V.max(0) - V.min(0)).max()) / 2.0 * 1.04
        # a shared square window centred on the model, valid for any direction
        bounds = (-half, -half, 2.0 * half)
        V = V - c
    for n in names:
        out[n] = rasterize(V, faces, VIEWS[n], res=res, bounds=bounds)["mask"]
    return out


# ------------------------------------------------------------------- metrics

def iou(a, b):
    a = np.asarray(a, dtype=bool)
    b = np.asarray(b, dtype=bool)
    u = np.count_nonzero(a | b)
    return 1.0 if u == 0 else float(np.count_nonzero(a & b) / u)


def _outline(m):
    m = np.asarray(m, dtype=bool)
    p = np.zeros((m.shape[0] + 2, m.shape[1] + 2), dtype=bool)
    p[1:-1, 1:-1] = m
    er = (p[:-2, 1:-1] & p[2:, 1:-1] & p[1:-1, :-2] & p[1:-1, 2:] & m)
    return m & ~er


def chamfer(a, b, normalize=True):
    """Symmetric mean nearest-neighbour distance between the two outlines.

    Sensitive to shape error that IoU shrugs off: a slightly-too-wide limb
    barely moves IoU but moves the outline distance immediately.
    """
    pa = np.argwhere(_outline(a))
    pb = np.argwhere(_outline(b))
    if len(pa) == 0 or len(pb) == 0:
        return float("inf")
    try:
        from scipy.spatial import cKDTree
        d1 = cKDTree(pb).query(pa)[0].mean()
        d2 = cKDTree(pa).query(pb)[0].mean()
    except Exception:
        d1 = np.sqrt(((pa[:, None, :] - pb[None, :, :]) ** 2).sum(-1)).min(1).mean()
        d2 = np.sqrt(((pb[:, None, :] - pa[None, :, :]) ** 2).sum(-1)).min(1).mean()
    d = float((d1 + d2) / 2.0)
    return d / np.asarray(a).shape[0] if normalize else d


def score(masks, ref_masks, holdout=(), lam=0.5):
    """Axis 4 score.

    `lam` weights a variance penalty: a model that nails the front view and
    collapses in profile should not score like one that is consistently close.
    Held-out views are measured and reported but excluded from the score, which
    is how you detect overfitting to the scored cameras.
    """
    per = {}
    for name, m in masks.items():
        if name not in ref_masks:
            continue
        per[name] = {"iou": round(iou(m, ref_masks[name]), 4),
                     "chamfer": round(chamfer(m, ref_masks[name]), 5)}
    scored = {k: v for k, v in per.items() if k not in holdout}
    if not scored:
        return {"per_view": per, "score": None, "reason": "no scored views"}
    vals = np.array([v["iou"] for v in scored.values()], dtype=float)
    s = float(max(0.0, vals.mean() - lam * vals.std()))
    held = {k: per[k] for k in per if k in holdout}
    out = {
        "per_view": per,
        "mean_iou": round(float(vals.mean()), 4),
        "std_iou": round(float(vals.std()), 4),
        "score": round(s, 4),
        "holdout": held,
    }
    if held:
        hv = np.mean([v["iou"] for v in held.values()])
        out["holdout_mean_iou"] = round(float(hv), 4)
        # a large gap means the model was tuned to the scored cameras
        out["overfit_gap"] = round(float(vals.mean() - hv), 4)
    return out


# ------------------------------------------------------------------ reference

def mask_from_image(path, res=256, threshold=0.5, invert=False):
    """Load a reference silhouette from an image (e.g. a photo of the target).

    Anything darker than `threshold` counts as inside, which suits a subject
    photographed against a bright background; pass `invert` for the opposite.
    """
    try:
        from PIL import Image
    except ImportError as exc:
        raise RuntimeError("mask_from_image needs Pillow") from exc
    im = Image.open(path).convert("L")
    w, h = im.size
    side = max(w, h)
    sq = Image.new("L", (side, side), 255)
    sq.paste(im, ((side - w) // 2, (side - h) // 2))
    a = np.asarray(sq.resize((res, res), Image.BILINEAR), dtype=float) / 255.0
    m = a < threshold
    return (~m if invert else m).T


def save_mask(mask, path):
    """Write a mask as PNG, for eyeballing what the scorer actually compared."""
    from PIL import Image
    Image.fromarray((np.asarray(mask).T * 255).astype(np.uint8)).save(path)


def outline_complexity(verts, faces, res=384, views=("front", "left", "top")):
    """Scale-free outline detail: perimeter / sqrt(area), averaged over views.

    An output measure for `verify_model.scaling_response`. Because it is
    rasterized at a FIXED resolution, resampling the same shape leaves it
    unchanged while genuinely new features raise it.

    Measured behaviour, so you know when it applies: a resampled SDF figure
    scored slope -0.001 (correctly flat) and an involute gear +0.236 as tooth
    count rose (correctly positive). It FAILS on two shapes — a tree canopy
    saturates and then falls (-0.92) once foliage occludes its own structure,
    and a heightfield stays flat (+0.003) because its relief never reaches the
    outline. Use `verify_model.surface_roughness` for interior detail.
    """
    vals = []
    for name in views:
        m = mask_set(verts, faces, res=res, views=[name])[name]
        area = float(np.count_nonzero(m))
        if area < 4:
            continue
        vals.append(float(np.count_nonzero(_outline(m))) / np.sqrt(area))
    return float(np.mean(vals)) if vals else float("nan")
