"""bootstrap.py -- make this skill's scripts importable from anywhere.

WHY THIS EXISTS
A skill that hard-codes a machine-local project path only works on one machine.
Every script here resolves its siblings relative to ITS OWN location instead,
so the skill directory can be copied, shared, or checked into a repo and still
work.

USAGE -- put this at the top of any model script:

    import os, sys
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    import bootstrap                      # noqa: F401  (side effect: sys.path)

...or, when the script lives elsewhere, point at the skill once:

    import sys
    sys.path.insert(0, "/path/to/verifier-first-3d-modeling/scripts")
    import bootstrap
    bootstrap.add_sibling_skill("procedural-3d-modeling")   # engine + session

Nothing here touches bpy, so it is safe headless.
"""

import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
SKILL_DIR = os.path.dirname(HERE)                 # .../<skill-name>
SKILLS_ROOT = os.path.dirname(SKILL_DIR)          # .../<category>


def _add(path):
    path = os.path.abspath(path)
    if os.path.isdir(path) and path not in sys.path:
        sys.path.insert(0, path)
        return True
    return False


# always make our own scripts/ importable
_add(HERE)


def add_sibling_skill(name, category_root=None):
    """Put a sibling skill's scripts/ on sys.path. Returns the path or None.

    Skills live at <category>/<skill>/scripts, so a sibling is one level up.
    Falls back to standard user skill locations, then to an env override, so
    this keeps working whether the skill is installed, vendored into a repo, or
    run straight from a checkout.
    """
    roots = [category_root] if category_root else []
    roots += [
        SKILLS_ROOT,
        os.environ.get("SKILLS_HOME", ""),
        os.path.expanduser("~/.skills/creative"),
        os.path.expanduser("~/.skills"),
    ]
    for root in roots:
        if not root:
            continue
        cand = os.path.join(root, name, "scripts")
        if _add(cand):
            return os.path.abspath(cand)
    return None


def engine():
    """Import and return the SDF engine, wherever it lives.

    Looks beside this file first (a self-contained skill), then in the sibling
    modelling skill, then on the existing sys.path.
    """
    try:
        import sdf_core
        return sdf_core
    except ImportError:
        pass
    for name in ("procedural-3d-modeling", "verifier-first-3d-modeling"):
        if add_sibling_skill(name):
            try:
                import sdf_core
                return sdf_core
            except ImportError:
                continue
    raise ImportError(
        "sdf_core not found. Expected it in this skill's scripts/ directory or "
        "in a sibling skill. Set SKILLS_HOME if your skills live "
        "somewhere non-standard."
    )


def out_dir(sub=None):
    """Where to write artifacts. Overridable, never hard-coded to one machine."""
    base = os.environ.get("BLENDER_OUT_DIR") or os.path.expanduser("~/blender_out")
    path = os.path.join(base, sub) if sub else base
    os.makedirs(path, exist_ok=True)
    return path


def report():
    """Print what got resolved -- the first thing to check when imports fail."""
    print("bootstrap: skill dir   %s" % SKILL_DIR)
    print("bootstrap: skills root %s" % SKILLS_ROOT)
    print("bootstrap: out dir     %s" % out_dir())
    for mod in ("sdf_core", "session", "measure", "verify_model", "silhouette"):
        try:
            m = __import__(mod)
            print("  %-13s %s" % (mod, getattr(m, "__file__", "?")))
        except ImportError:
            print("  %-13s NOT FOUND" % mod)
