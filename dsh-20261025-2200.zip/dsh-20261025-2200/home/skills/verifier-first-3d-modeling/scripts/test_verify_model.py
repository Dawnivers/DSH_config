"""Validate verify_model.py against meshes whose answers are known exactly."""
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import verify_model as vm
import silhouette as sil

CUBE_V = [(0, 0, 0), (1, 0, 0), (1, 1, 0), (0, 1, 0),
          (0, 0, 1), (1, 0, 1), (1, 1, 1), (0, 1, 1)]
CUBE_F = [(0, 3, 2, 1), (4, 5, 6, 7), (0, 1, 5, 4),
          (1, 2, 6, 5), (2, 3, 7, 6), (3, 0, 4, 7)]


def box(cx=0.0, cy=0.0, cz=0.0, s=1.0):
    v = (np.asarray(CUBE_V, dtype=float) - 0.5) * s + np.array([cx, cy, cz])
    return v, CUBE_F


def uv_sphere(r=1.0, n=48, m=24):
    V, F = [], []
    for i in range(m + 1):
        th = np.pi * i / m
        for j in range(n):
            ph = 2 * np.pi * j / n
            V.append((r * np.sin(th) * np.cos(ph), r * np.sin(th) * np.sin(ph),
                      r * np.cos(th)))
    for i in range(m):
        for j in range(n):
            a = i * n + j
            b = i * n + (j + 1) % n
            c = (i + 1) * n + (j + 1) % n
            d = (i + 1) * n + j
            F.append((a, b, c, d))
    return np.array(V), F

fails = []


def check(name, got, want, tol=None):
    ok = abs(got - want) <= tol if tol is not None else got == want
    print(("  PASS  " if ok else "  FAIL  ") + f"{name}: got {got!r} want {want!r}"
          + (f" +-{tol}" if tol else ""))
    if not ok:
        fails.append(name)


print("closed cube -> shells 1, chi 2, genus 0, watertight, gate pass")
t = vm.topology(CUBE_V, CUBE_F)
check("shells", t["shells"], 1)
check("euler_chi", t["euler_chi"], 2)
check("genus", t["genus"], 0)
check("boundary_edges", t["boundary_edges"], 0)
check("nonmanifold_edges", t["nonmanifold_edges"], 0)
check("gate", t["gate"], True)

print("\ntwo disjoint cubes -> shells 2, chi 4, gate FAIL when 1 expected")
V2 = CUBE_V + [(x + 4, y, z) for x, y, z in CUBE_V]
F2 = CUBE_F + [tuple(i + 8 for i in f) for f in CUBE_F]
t2 = vm.topology(V2, F2)
check("shells", t2["shells"], 2)
check("euler_chi", t2["euler_chi"], 4)
check("gate", t2["gate"], False)
check("gate when 2 expected", vm.topology(V2, F2, expect_shells=2)["gate"], True)

print("\nopen cube (lid removed) -> boundary edges 4, gate FAIL")
t3 = vm.topology(CUBE_V, CUBE_F[1:])
check("boundary_edges", t3["boundary_edges"], 4)
check("gate", t3["gate"], False)

print("\ntorus -> shells 1, chi 0, genus 1")
R, r, n, m = 1.0, 0.35, 16, 10
TV, TF = [], []
for i in range(n):
    a = 2 * np.pi * i / n
    for j in range(m):
        b = 2 * np.pi * j / m
        TV.append(((R + r * np.cos(b)) * np.cos(a),
                   (R + r * np.cos(b)) * np.sin(a), r * np.sin(b)))
for i in range(n):
    for j in range(m):
        a0 = i * m + j
        a1 = i * m + (j + 1) % m
        b0 = ((i + 1) % n) * m + j
        b1 = ((i + 1) % n) * m + (j + 1) % m
        TF.append((a0, a1, b1, b0))
t4 = vm.topology(TV, TF, expect_genus=1)
check("shells", t4["shells"], 1)
check("euler_chi", t4["euler_chi"], 0)
check("genus", t4["genus"], 1)
check("gate (genus 1 expected)", t4["gate"], True)
check("gate (genus 0 expected)", vm.topology(TV, TF, expect_genus=0)["gate"], False)

print("\nphysics: centred cube passes; overhang cube fails")
p = vm.physical_validity(CUBE_V, CUBE_F, ground_z=0.0)
check("com_over_support", p["com_over_support"], True)
TIP_V = [(x, y, z) if z < 0.5 else (x + 6, y, z) for x, y, z in CUBE_V]
p2 = vm.physical_validity(TIP_V, CUBE_F, ground_z=0.0)
check("overhang gate", p2["gate"], False)

print("\ndetail adequacy: known ratios against voxel 0.021")
d = vm.detail_adequacy([0.021 * k for k in (1, 2, 3, 4, 8)], 0.021)
check("frac_under_3", d["frac_under_3"], 0.4)
check("score (>=4 voxels)", d["score"], 0.4)

print("\npolys-per-line is diagnostic only and must NOT drive the score")
# scored against this file, so the test is self-contained
SELF = os.path.abspath(__file__)
for polys, label in [(1211564, 'high-poly'), (74150, 'low-poly')]:
    g = vm.generative_quality(polys, SELF)
    print(f"  {label:10s} {g['polys_per_line']:8.0f} polys/line  "
          f"({g['source_lines']} lines)")
    check(f"{label}: compressibility None without scaling", g["compressibility"], None)

print("\nscaling_response separates real detail from resampling")
# a generator whose parameter adds real elements: N boxes -> 6N faces
def n_boxes(n):
    V, F = [], []
    for k in range(int(n)):
        b = len(V)
        v, f = box(cx=2.0 * k)
        V += [tuple(p) for p in v]
        F += [tuple(i + b for i in q) for q in f]
    return V, F

real = vm.scaling_response(n_boxes, (2, 4, 8, 16))
print(f"  added elements: slope {real['slope']}  growth {real['growth']}x")
check("added-element slope ~1", round(real["slope"], 2), 1.0, tol=0.05)

# a generator whose parameter only resamples: sphere tessellation density
def resample(n):
    return uv_sphere(n=int(n), m=max(4, int(n) // 2))

res = vm.scaling_response(resample, (16, 24, 32, 48))
oc = vm.scaling_response(
    resample, (16, 24, 32, 48),
    measure=lambda V, F: sil.outline_complexity(V, F, res=192, views=("front",)))
print(f"  resampling:     poly-slope {res['slope']}  "
      f"outline-complexity slope {oc['slope']}")
check("poly-slope cannot see resampling (>1.5)", res["slope"] > 1.5, True)
check("outline complexity flat on resampling (<0.1)", abs(oc["slope"]) < 0.1, True)

print("\nsurface_roughness: a flat sheet is 0, a jagged one is not")
flat_v = [(x, y, 0.0) for x in range(6) for y in range(6)]
idx = np.arange(36).reshape(6, 6)
grid_f = [(int(idx[i, j]), int(idx[i + 1, j]), int(idx[i + 1, j + 1]),
           int(idx[i, j + 1])) for i in range(5) for j in range(5)]
check("flat sheet roughness 0", round(vm.surface_roughness(flat_v, grid_f), 6), 0.0)
rng = np.random.default_rng(3)
jag_v = [(x, y, float(rng.normal(0, 0.4))) for x in range(6) for y in range(6)]
check("jagged sheet roughness > 10 deg",
      vm.surface_roughness(jag_v, grid_f) > 10.0, True)

print("\ntask-declared topology gates (a universal gate rejects correct models)")
check("open sheet fails when closure required",
      vm.topology(flat_v, grid_f, expect_shells=1)["gate"], False)
check("open sheet passes when declared open",
      vm.topology(flat_v, grid_f, expect_shells=1, require_closed=False)["gate"], True)
check("many shells pass when shells check skipped",
      vm.topology(V2, F2, expect_shells=None)["gate"], True)

print("\nfull scorecard on the closed cube")
card = vm.score(CUBE_V, CUBE_F, ground_z=0.0,
                source_path='fixture_source.py',
                voxel=0.021, feature_sizes=[0.1, 0.2],
                metric_score=0.8, silhouette_score=0.7)
print(vm.format_card(card))
check("gate", card["gate"], 1.0)

print("\nmesh quality: duplicate and degenerate geometry must fail")
bad_v = list(CUBE_V) + [CUBE_V[0]]
bad_f = list(CUBE_F) + [(0, 0, 1)]
q = vm.geometry_quality(bad_v, bad_f)
check("duplicate vertices", q["duplicate_vertices"], 1)
check("degenerate faces", q["degenerate_faces"], 1)
check("quality gate", q["gate"], False)

print("\nassembly gate participates in the unified scorecard")
failed_assembly = {"ok": False, "stages": {"orphan_parts": {"ok": False}}}
blocked = vm.score(CUBE_V, CUBE_F, ground_z=0.0,
                   metric_score=1.0, silhouette_score=1.0,
                   assembly_report=failed_assembly)
check("assembly blocks total", blocked["gate"], 0.0)
check("assembly reported", blocked["assembly"]["gate"], False)

print("\nscipy-free support hull rejects a point inside AABB but outside triangle")
support = vm.convex_hull_2d([(0, 0), (1, 0), (0, 1), (0.2, 0.2)])
check("triangle hull has 3 corners", len(support), 3)
check("inside triangle", vm._point_in_convex_polygon((0.2, 0.2), support), True)
check("outside triangle despite AABB", vm._point_in_convex_polygon((0.8, 0.8), support), False)

print("\n" + ("ALL PASS" if not fails else f"FAILURES: {fails}"))
sys.exit(1 if fails else 0)
