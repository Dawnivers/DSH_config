"""session.py -- MCP probe, scene triage, and dual-artifact export.

The workflow this implements, in one line: detect whether a live Blender is
reachable; if it is and the scene already holds someone's work, preserve that
work before touching anything; always leave behind BOTH a .blend and a
standalone .py that regenerates the model from nothing.

Why the script matters as much as the .blend: a .blend is an opaque binary that
only Blender can open, while the .py is the reproducible artifact -- diffable,
reviewable, parameterisable, and the actual training-data payload. If there is
no live workspace at all, the .py is the entire deliverable.

Import this from a model script. Every function degrades gracefully when bpy is
absent, so the same file works headless and inside Blender.
"""

import datetime
import os
import shutil

try:
    import bpy
except ImportError:                                    # pragma: no cover
    bpy = None


# ============================================================== MCP / WORKSPACE

def has_workspace():
    """True when a live Blender session is driving this code.

    `bpy` importing is not enough: it is also importable in `blender -b`
    (headless) where there is no GUI to look at but scene state still matters.
    What we actually care about is whether a scene exists to read and write.
    """
    return bpy is not None and getattr(bpy, "context", None) is not None \
        and getattr(bpy.context, "scene", None) is not None


def is_background():
    """True in `blender -b`: no GUI, so no viewport screenshots are possible."""
    return bool(bpy and bpy.app.background)


def scene_census(ignore_default=True):
    """What is already in the scene, split by category.

    `ignore_default` treats a factory-fresh startup file (the default Cube,
    Camera and Light) as empty, because a stock startup scene is not somebody's
    work and does not need preserving.
    """
    if not has_workspace():
        return {"live": False}

    default_names = {"Cube", "Camera", "Light"}
    meshes, lights, cameras, other = [], [], [], []
    for ob in bpy.context.scene.objects:
        if ob.type == "MESH":
            meshes.append(ob.name)
        elif ob.type == "LIGHT":
            lights.append(ob.name)
        elif ob.type == "CAMERA":
            cameras.append(ob.name)
        else:
            other.append(ob.name)

    names = set(meshes) | set(lights) | set(cameras) | set(other)
    is_default = ignore_default and names.issubset(default_names)
    tri_count = 0
    for ob in bpy.context.scene.objects:
        if ob.type == "MESH" and ob.data:
            tri_count += len(ob.data.polygons)

    return {
        "live": True,
        "background": is_background(),
        "scene": bpy.context.scene.name,
        "meshes": meshes, "lights": lights, "cameras": cameras, "other": other,
        "n_mesh": len(meshes), "n_total": len(names), "polys": tri_count,
        "materials": len(bpy.data.materials),
        "has_assets": (not is_default) and len(meshes) > 0,
        "looks_default": is_default,
        "filepath": bpy.data.filepath or None,
        "dirty": bool(getattr(bpy.data, "is_dirty", False)),
    }


# =================================================================== TRIAGE

def prepare_scene(mode="auto", save_dir=None, label="autosave", verbose=True):
    """Decide what to do with an occupied scene, then do it.

    mode:
      "auto"      preserve existing work and start clean (the safe default)
      "append"    leave the scene alone and add to it -- use when the task says
                  "add X to this scene" rather than "model X"
      "replace"   wipe without saving. Only when the caller is certain.

    Returns a dict describing what happened, so a report can state it plainly
    instead of the user having to guess whether their work survived.
    """
    info = scene_census()
    out = {"mode": mode, "census": info, "preserved": None, "cleared": False}

    if not info.get("live"):
        out["action"] = "no-workspace"
        if verbose:
            print("[session] no live Blender -- script-only output")
        return out

    if mode == "append":
        out["action"] = "append-in-place"
        if verbose:
            print("[session] appending to '%s' (%d objects kept)"
                  % (info["scene"], info["n_total"]))
        return out

    if not info["has_assets"]:
        # empty or factory-default: nothing worth preserving, just tidy up
        if info["looks_default"]:
            _wipe()
            out["cleared"] = True
        out["action"] = "started-clean"
        if verbose:
            print("[session] scene was %s -- starting clean"
                  % ("factory default" if info["looks_default"] else "empty"))
        return out

    if mode == "replace":
        _wipe()
        out.update(action="replaced-without-saving", cleared=True)
        if verbose:
            print("[session] WARNING: wiped %d objects without saving"
                  % info["n_total"])
        return out

    # auto: existing work -> preserve it first, then clear
    path = save_scene(save_dir, label=label, verbose=verbose)
    out["preserved"] = path
    _wipe()
    out.update(action="preserved-then-cleared", cleared=True)
    if verbose:
        print("[session] preserved %d objects (%d polys) -> %s"
              % (info["n_total"], info["polys"], path))
    return out


def _wipe():
    """Remove every object and orphaned datablock from the current scene."""
    if not has_workspace():
        return
    for ob in list(bpy.data.objects):
        bpy.data.objects.remove(ob, do_unlink=True)
    for coll in (bpy.data.meshes, bpy.data.curves, bpy.data.materials,
                 bpy.data.lights, bpy.data.cameras, bpy.data.images):
        for item in list(coll):
            if item.users == 0:
                coll.remove(item)


# =================================================================== EXPORT

def _stamp():
    return datetime.datetime.now().strftime("%Y%m%d-%H%M%S")


def default_dir():
    return os.path.expanduser("~/blender_out")


def save_scene(out_dir=None, label="scene", verbose=True):
    """Save the live scene to a .blend. Returns the path, or None if headless.

    Never overwrites: a timestamp goes in the filename, because clobbering the
    user's previous save while "helpfully" saving is the worst possible outcome.
    """
    if not has_workspace():
        return None
    out_dir = out_dir or default_dir()
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, "%s-%s.blend" % (label, _stamp()))
    bpy.ops.wm.save_as_mainfile(filepath=path, copy=True)
    if verbose:
        print("[session] saved scene -> %s" % path)
    return path


def save_script(source, out_dir=None, label=None, verbose=True):
    """Persist the generating script. Accepts a PATH or the SOURCE TEXT.

    This dual form exists because of how MCP delivers code. Over MCP the script
    arrives as a string and is `exec`'d: there is no file on disk, `__file__`
    raises NameError, and `__name__` is "builtins". A copy-the-source-file
    approach therefore silently produces a .blend with no .py beside it -- the
    scene state survives, the reproducible artifact does not.

    So: pass `source_text=` (or just hand this the code string) when running
    over MCP, and a path when running from a real file.
    """
    out_dir = out_dir or default_dir()
    os.makedirs(out_dir, exist_ok=True)

    looks_like_path = (
        isinstance(source, str)
        and "\n" not in source
        and source.endswith(".py")
        and os.path.exists(source)
    )
    if looks_like_path:
        label = label or os.path.splitext(os.path.basename(source))[0]
        path = os.path.join(out_dir, "%s-%s.py" % (label, _stamp()))
        shutil.copyfile(source, path)
    else:
        label = label or "model"
        path = os.path.join(out_dir, "%s-%s.py" % (label, _stamp()))
        with open(path, "w") as fh:
            fh.write(source)

    if verbose:
        print("[session] saved script -> %s" % path)
    return path


def current_source():
    """Best-effort source of the running script, or None under MCP/exec.

    Returns None rather than guessing, so a caller can fail loudly instead of
    writing an empty or wrong .py.
    """
    import inspect as _inspect
    try:
        frame = _inspect.currentframe().f_back
        path = frame.f_globals.get("__file__")
        if path and os.path.exists(path):
            return os.path.abspath(path)
    except Exception:
        pass
    return None


def write_then_run(code, path, run=True, verbose=True):
    """Write `code` to `path`, then execute THAT FILE. The MCP-safe pattern.

    This inverts the usual order and that inversion is the whole point. Sending
    code straight over MCP means it is exec'd from a string: nothing lands on
    disk, `__file__` raises NameError, and afterwards the .py cannot be
    recovered at all -- you get a .blend and nothing to reproduce it with.

    Writing first makes the file the source of truth. The script then has a real
    `__file__`, can be re-run, diffed, parameterised, and handed to a training
    pipeline. Over MCP, call this with the code you were going to send.
    """
    path = os.path.abspath(os.path.expanduser(path))
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as fh:
        fh.write(code)
    if verbose:
        print("[session] wrote script -> %s (%d bytes)" % (path, len(code)))

    if not run:
        return {"path": path, "ran": False}

    # runpy gives the module a genuine __file__ and __name__ == "__main__",
    # so `if __name__ == "__main__":` blocks fire exactly as they would when
    # the file is run directly.
    import runpy
    runpy.run_path(path, run_name="__main__")
    return {"path": path, "ran": True}


def finish(source=None, out_dir=None, label="model", scorecard=None,
           verbose=True, require_script=True):
    """Export everything a task should leave behind.

    `source` may be a file path OR the source text. Over MCP there is no file,
    so pass the code string you sent -- see save_script().

    `require_script=True` makes a missing script LOUD. That default is
    deliberate: the failure mode this guards against is shipping a .blend with
    no .py, which looks like success until someone tries to reproduce or diff
    the model and finds only an opaque binary.
    """
    out_dir = out_dir or default_dir()
    os.makedirs(out_dir, exist_ok=True)
    res = {"dir": out_dir, "blend": None, "script": None, "scorecard": None}

    if source is None:
        msg = ("[session] NO SCRIPT SOURCE. Under MCP `__file__` does not exist "
               "(the code is exec'd from a string), so the .py cannot be "
               "recovered after the fact. Pass source=<the code text>, or "
               "write the script to disk first and run it with "
               "blender -b -P <file>.")
        if require_script:
            raise ValueError(msg)
        if verbose:
            print(msg)
    else:
        res["script"] = save_script(source, out_dir, label, verbose=verbose)

    if has_workspace():
        res["blend"] = save_scene(out_dir, label, verbose=verbose)
    elif verbose:
        print("[session] no live scene -- script is the sole deliverable")

    if scorecard is not None:
        import json
        p = os.path.join(out_dir, "%s-%s.scorecard.json" % (label, _stamp()))
        with open(p, "w") as fh:
            json.dump(scorecard, fh, indent=2, default=str)
        res["scorecard"] = p
        if verbose:
            print("[session] saved scorecard -> %s" % p)

    if verbose:
        missing = [k for k in ("script", "blend") if not res[k]]
        if missing:
            print("[session] NOTE missing artifacts: %s" % ", ".join(missing))
    return res
