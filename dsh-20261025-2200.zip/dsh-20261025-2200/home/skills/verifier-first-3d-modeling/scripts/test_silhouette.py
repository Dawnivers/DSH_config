"""Validate silhouette.py against shapes whose projected outlines are known."""
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import silhouette as sil

fails = []


def check(name, got, want, tol=None):
    ok = abs(got - want) <= tol if tol is not None else got == want
    print(("  PASS  " if ok else "  FAIL  ") +
          f"{name}: got {got!r} want {want!r}" + (f" +-{tol}" if tol else ""))
    if not ok:
        fails.append(name)


def box(cx=0.0, cy=0.0, cz=0.0, sx=1.0, sy=1.0, sz=1.0):
    v = np.array([(0, 0, 0), (1, 0, 0), (1, 1, 0), (0, 1, 0),
                  (0, 0, 1), (1, 0, 1), (1, 1, 1), (0, 1, 1)], dtype=float)
    v = (v - 0.5) * np.array([sx, sy, sz]) + np.array([cx, cy, cz])
    f = [(0, 3, 2, 1), (4, 5, 6, 7), (0, 1, 5, 4),
         (1, 2, 6, 5), (2, 3, 7, 6), (3, 0, 4, 7)]
    return v, f


def uv_sphere(r=1.0, n=48, m=24, c=(0, 0, 0)):
    V, F = [], []
    for i in range(m + 1):
        th = np.pi * i / m
        for j in range(n):
            ph = 2 * np.pi * j / n
            V.append((c[0] + r * np.sin(th) * np.cos(ph),
                      c[1] + r * np.sin(th) * np.sin(ph),
                      c[2] + r * np.cos(th)))
    for i in range(m):
        for j in range(n):
            a = i * n + j
            b = i * n + (j + 1) % n
            cc = (i + 1) * n + (j + 1) % n
            d = (i + 1) * n + j
            F.append((a, b, cc, d))
    return np.array(V), F


print("cube silhouette fills its square window (padded by 1.04)")
v, f = box(sx=2, sy=2, sz=2)
m = sil.rasterize(v, f, (0, -1, 0), res=200)["mask"]
check("cube front fill", round(float(m.mean()), 3), round(1 / 1.04 ** 2, 3), tol=0.02)

print("\nsphere silhouette is a disc: area fraction -> (pi/4)/1.04^2")
vs, fs = uv_sphere(r=1.0, n=64, m=32)
ms = sil.rasterize(vs, fs, (0, -1, 0), res=300)["mask"]
check("sphere disc fraction", round(float(ms.mean()), 4),
      round(np.pi / 4 / 1.04 ** 2, 4), tol=0.01)

print("\nsphere looks identical from every direction (IoU ~ 1)")
sets = sil.mask_set(vs, fs, res=200)
base = sets["front"]
for name in ("back", "left", "right", "top", "three_quarter"):
    check(f"sphere {name} vs front", round(sil.iou(base, sets[name]), 3), 1.0, tol=0.02)

print("\nidentical meshes -> IoU 1.0, chamfer 0")
a = sil.mask_set(v, f, res=128)
b = sil.mask_set(v, f, res=128)
check("self IoU", round(sil.iou(a["front"], b["front"]), 6), 1.0)
check("self chamfer", round(sil.chamfer(a["front"], b["front"]), 6), 0.0)

print("\ndisjoint masks -> IoU 0")
m1 = np.zeros((64, 64), bool); m1[:20, :20] = True
m2 = np.zeros((64, 64), bool); m2[40:, 40:] = True
check("disjoint IoU", sil.iou(m1, m2), 0.0)

print("\nhalf-overlap squares -> IoU = 1/3 exactly")
h1 = np.zeros((64, 64), bool); h1[0:20, 0:20] = True
h2 = np.zeros((64, 64), bool); h2[10:30, 0:20] = True
check("half-overlap IoU", round(sil.iou(h1, h2), 4), round(1 / 3, 4), tol=1e-3)

print("\ncube vs sphere: IoU strictly between 0.5 and 0.9")
cs = sil.mask_set(v, f, res=200)
ss = sil.mask_set(vs, fs, res=200)
i_cs = sil.iou(cs["front"], ss["front"])
print(f"    cube-vs-sphere front IoU = {i_cs:.4f}, "
      f"chamfer = {sil.chamfer(cs['front'], ss['front']):.5f}")
check("cube vs sphere IoU < 0.9", i_cs < 0.9, True)
check("cube vs sphere IoU > 0.5", i_cs > 0.5, True)

print("\nscore(): variance penalty and held-out camera")
ref = sil.mask_set(vs, fs, res=128)
tall = np.array(vs) * np.array([1.0, 1.0, 1.35])
got = sil.mask_set(tall, fs, res=128)
card = sil.score(got, ref, holdout=("three_quarter",))
print("    per-view IoU:", {k: v["iou"] for k, v in card["per_view"].items()})
print(f"    mean {card['mean_iou']}  std {card['std_iou']}  score {card['score']}"
      f"  holdout {card.get('holdout_mean_iou')}  gap {card.get('overfit_gap')}")
check("holdout excluded from scored set", "three_quarter" in card["holdout"], True)
check("score <= mean (variance penalty)", card["score"] <= card["mean_iou"], True)
check("stretched sphere scores < 1", card["score"] < 0.95, True)

print("\nself-score is 1.0 with no variance penalty")
perfect = sil.score(ref, ref)
check("perfect score", round(perfect["score"], 4), 1.0)
check("perfect std", round(perfect["std_iou"], 4), 0.0)

print("\ndeterminism: same mesh twice -> bit-identical masks")
d1 = sil.mask_set(vs, fs, res=128)["front"]
d2 = sil.mask_set(vs, fs, res=128)["front"]
check("bit-identical", bool(np.array_equal(d1, d2)), True)

print("\n" + ("ALL PASS" if not fails else f"FAILURES: {fails}"))
sys.exit(1 if fails else 0)
