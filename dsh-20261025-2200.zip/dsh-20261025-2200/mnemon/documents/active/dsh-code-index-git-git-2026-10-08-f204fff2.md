---
id: "f204fff2-1d15-4b10-803c-d9274de524ff"
title: "dsh-code-index 非 git 工作区启用实测：.git 门禁、内置排除与凭据顺序（2026-10-08 本机）"
description: "dsh-code-index 的核心索引能力不依赖 git，但被「必须找到 .git 祖先」的门禁挡住；本文记录门禁源码位置、空 git init（0 commit）即可索引的实测、DEFAULT_EXCLUDED_DIRS 内置排除、插件自身读 .gitignore 的语义、本机全局 gitignore 验证结果，以及智慧地铁项目的体量评估与结论。选型依据见 4b7d494f。"
status: "active"
created_at: "2026-10-08T01:26:34.027Z"
updated_at: "2026-10-08T01:26:34.027Z"
content_hash: "37a9883f9ed2226130f3736b39c37eba3a09d65e740e2b4d9ddd3178c039a1e7"
source_paths:
  - ".audit-code-index/src-extracted/buildIndex.ts"
  - ".audit-code-index/src-extracted/config.ts"
  - ".audit-code-index/src-extracted/scan.ts"
session_ids:
  - "7d47f38c-1109-414e-93c3-db3253a8111c"
memory_body_ids:
  []
---

# dsh-code-index 非 git 工作区启用实测（2026-10-08 本机）

补充文档：插件选型、工具面、PageRank 仓库地图、能力边界的依据见 `dsh-vs-mcp-4b7d494f`（id `4b7d494f-5c4b-4c71-8ea5-80f19359a2cb`）。本文只记「为什么非 git 目录用不了 / 怎么才能用起来 / 有什么风险」的实测结论。

## 1. 一句话结论

**索引能力与 git 无关，但「允许被索引」这件事被绑在 git 上。** 唯一真正需要 git 的功能是 `code_change_context`；其余全部是纯文件系统 + tree-sitter 解析 + 图计算。作者的 `.git` 门禁是**反误操作护栏**，不是技术依赖。

## 2. 依赖分层（按源码模块）

| 模块 | 需要 git |
|---|---|
| `scan.ts` 目录扫描 | 否，纯 fs |
| `extract.ts` tree-sitter 符号解析 | 否 |
| `store.ts` 索引落盘 | 否 |
| `repomap.ts` 仓库地图（导入图 PageRank） | 否 |
| `refgraph.ts` 调用图 | 否 |
| `health.ts` 循环依赖 / 孤儿 | 否 |
| `git-diff.ts` | **是**（要 diff 一个 ref 才知道改了什么） |

## 3. 门禁实现（源码证据）

`buildIndex.ts` 的 `findRepoRoot(startDir, maxLevels = 12)`：从会话 cwd 逐层向上 `stat('.git')`，最多 12 层。

- 接受 `.git` **目录**（普通仓库）和 `.git` **文件**（worktree / 子模块）。
- 找不到返回 `null`，**所有工具直接拒绝工作**。
- 报错形态：`code_index: no git repository found from <cwd>`；自动注入的仓库地图同时为空。
- 注释明示动机：*"callers must NOT index an untagged directory (the fs root is the classic footgun: indexing `C:\` by accident)"*。
- `config.ts` 共 9 项配置（`excludeDirs` / `mapTopFiles` / `mapMaxChars` / `mapTtlMs` / `autoInject` / `codeHealth` / `toolSurface` / `externalWatch` / `watchDebounceMs`）—— **没有任何「允许非 git 目录」的开关**。

## 4. 实测：空 `git init`（0 commit）就够了

在临时仓库里 `git init` 后**不 commit**（`git log` 报 `does not have any commits yet`），实测结果：

```text
files indexed: 1 / symbols: 3 / index up to date
definitions: loadConfig(input) — sample.mjs:1
callers (1): saveConfig
callees (2): normalize（→ sample.mjs:4）、trim（external）
```

即 `code_index`、`code_refs` 全正常，调用图解析正确。**不需要提交、不需要远程、不需要改动任何现有文件。**

未验证项（勿替它打包票）：`code_change_context` 需要 diff 一个 ref，推定为**至少一次 commit（有 HEAD）**，本次未实测。

## 5. 插件自己会读 `.gitignore`（决定索引范围）

`scan.ts` 里 `.gitignore` 是**索引过滤器**：按目录层级累积 matcher，命中即跳过（`ignore().add(readFileSync(...))` → `matcher.ignores(scoped)`）。

内置排除目录 `DEFAULT_EXCLUDED_DIRS`（**无需手写**）：`node_modules`、`.git`、`.idea`、`.vscode`、`dist`、`build`、`out`、`coverage`、`.next`、`.nuxt`、`.cache`、`target`、`vendor`。

推论：**你不需要为了索引去写 `.gitignore`，只为 git 写。**

## 6. 本机全局 gitignore（已配置并验证）

| 项 | 值 |
|---|---|
| 文件 | `C:\Users\林先语\.config\git\ignore`（Git 默认全局路径，`core.excludesFile` 未显式设置） |
| 内容 | `.dsh-code-index/` |
| 验证 | `git check-ignore -v` 输出 `.../git/ignore:1:.dsh-code-index/  .dsh-code-index/index.json` —— 明确命中 |
| 效果 | 被索引仓库的 `git status` 从 `?? .dsh-code-index/` 变为完全干净，且**未改动任何仓库内容** |

注意区分：全局 ignore 只管 `.dsh-code-index/` 缓存，**挡不住 `config.js` 这类凭据文件**——那必须靠项目自己的 `.gitignore`。

## 7. 非 git 项目启用流程（精确条件）

前提：**会话目录的祖先链上（≤12 层）存在 `.git`**。

- **祖先，不是兄弟**：只给 `Translation` init → 在 `Translation_BE` 里开会话不生效。要前后端一起覆盖必须在共同项目根 init 一次（索引根 = 项目根）。
- 流程 A（只要索引、不要版本控制）：`cd <项目根> && git init`，然后到此为止——不 `add`、不 `commit`、不配远程，在该目录开会话即可。
- 流程 B（正经上版本控制）：**先写 `.gitignore`** → `git init` → `git add .` → **`git status --porcelain` 逐行确认凭据文件不在列表里** → 才 `git commit`。

红线：

1. `.gitignore` 必须早于第一次 `git add`。一旦被 add 过，后再写 ignore 不生效（需 `git rm --cached` 补救；已 commit 则凭据永久进历史）。
2. `.git` 必须是会话目录的祖先，兄弟目录不算。
3. **绝不要在盘根或用户主目录 `git init`** —— 会真的把整棵树索引进去，等于绕过作者加的护栏。
4. 不要在「参考项目 / 不该动的目录」里 init —— 那本身就是改动它。

可选调优：编辑 `%USERPROFILE%\.dsh\profiles\desktop\cordis.patch.yml` 覆盖插件 config（如 `autoInject: false` 省 token、`mapTopFiles`、`mapMaxChars`、`excludeDirs`），改完热重载。另：工具支持显式传 `repoRoot`，会话不在仓库内也能查指定仓库，但**系统提示里那张自动地图只在 cwd 位于仓库内时才有**。

## 8. 智慧地铁项目：结论是什么都不做

实测体量（`D:\WebGIS\web三维开发\智慧地铁项目`）：

| 目录 | 源文件 | 行数 | node_modules |
|---|---|---|---|
| `Translation`（Vue3 前端） | 40（含 12 个 `.vue`） | ~17,440 | 374 MB |
| `Translation_BE` | 2（`index.js` + `config.js`） | ~188 | 3 MB |

- 三个位置（项目根、`Translation`、`Translation_BE`）`rev-parse` 全部失败 → **不是 git 仓库**，插件在这里原本完全用不上。
- 这就是「中小仓库索引挣不回成本」的极端场景，`Translation_BE` 只有 2 个文件，索引属于自娱自乐 → **别为这个插件建仓库**；建不建 git 是工程决策，不该是插件的安装步骤。
- 项目根下还躺着参考项目 `综合项目：智慧地铁\` 及其 zip（用户要求不要动）→ **即使将来要做版本控制，也不能在根目录无脑 `git init`**，必须先 `.gitignore` 排除。
- 凭据红线：`Translation_BE\config.js`（17 行中 8 行命中凭据关键词，PostgreSQL 连接串 + 高德 Key）是全项目唯一高危文件，任何 `git add` 之前必须先排除。`Translation` 已有脚手架自带 `.gitignore`（含 `node_modules`/`dist`/`coverage`/`logs`），`Translation_BE` 没有。

## 9. 本文档的自我修正记录

曾把「空 `git init` 能绕过门禁」当成建议反复推荐，方向错了：那是为刚装的工具让路、把一个版本控制系统的语义引进用户并不需要它的项目，还顺带引入凭据泄露风险。正确表述是第 1 节那句话。
