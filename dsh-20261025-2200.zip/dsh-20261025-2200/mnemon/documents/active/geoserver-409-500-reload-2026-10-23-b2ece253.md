---
id: "b2ece253-2d4b-4e6c-b5d2-904167fde9a3"
title: "GeoServer 何时需要「通知」：教学版三命令重跑实测（409/500 不对称）与 reload 边界实验（2026-10-23）"
description: "两组在本机实跑的对照实验：教学版三条 curl 重复执行的真实返回（工作区 409、数据源/图层 500，失败无害但无法靠状态码判存在）；以及数据行改动无需任何操作、加字段需 POST /rest/reload、新表需发布、删表需删图层的边界划分，附 GWC 缓存导致的「图上不变」陷阱与 PowerShell curl 别名注意点。"
status: "active"
created_at: "2026-10-23T11:37:41.013Z"
updated_at: "2026-10-23T11:37:41.013Z"
content_hash: "336d65368a9d38a524fc340a7e57d182b54264e29af5e7512c52a4b0abed812d"
source_paths:
  []
session_ids:
  - "f3f5dee9-f335-4bb8-89d1-724eff76eb10"
memory_body_ids:
  []
---

# GeoServer：什么时候必须动它，什么时候不必

前情（本文不重复）：`Spatial` 库与首次发布 `e2a4925e-c390-44f3-bd15-8bf165e70b28`；REST 与 UI 的等价关系 `be91eaef-f93d-4d77-803d-b34651d1dfd1`；幂等 ps1/sh 脚本交付与 `$(...)` 子 shell 坑 `3a851d56-7d49-45cc-be1b-76552c1139a3`。

本文只补两件那三篇没覆盖、且都是**本机实跑**出来的结论。

## 1. 「教学版三条命令」重复执行的实测结果

为讲解用，把发布链路写成完全展开的三条 curl（`WS=wuhan`、`DS=spatial_db`、`TABLE=admin_area` 全用变量拼接，每条上方标注 `POST` 的 URL 与请求体含义），首次执行三条全 201，出图 200 / 34350 bytes。

**原样再跑一遍：**

| 步骤 | 返回 |
|---|---|
| ① 建工作区 | `409 Conflict` — `Workspace 'wuhan' already exists` |
| ② 连数据库 | `500 Internal Server Error` — `Store 'spatial_db' already exists in workspace 'wuhan'` |
| ③ 发布图层 | `500 Internal Server Error` — `Resource named 'admin_area' already exists in store: 'spatial_db'` |

两个推论：

1. **失败是无害的**——重跑后 `wuhan:admin_area` 仍在，GetMap 仍 200。坏处不是搞坏东西，而是「脚本中途非零退出，CI 标红，而实际状态是好的」。
2. **不能靠状态码判断「已存在」。** 同类冲突，工作区给语义正确的 409，数据源与图层却给 500。所以 `|| [ $? -eq 409 ]` 这种写法在第 2、3 步必然失效；**只能先 `GET` 探存在性**（`curl -sf` 让 ≥400 变非零退出码，判断即「存在性检查」）。这正是幂等脚本里那串 `if` 的真正理由，而非「写得温柔些」。

「一次动作」vs「期望状态」是这里的思维分界：三条命令表达动作（只在理想情况对），脚本表达期望状态（任何情况都对）。同构于 `docker run` vs `docker compose up`、`mkdir` vs `mkdir -p`。

## 2. reload 的边界：数据行 / 表结构 / 新表

问题背景：往库里加数据后，是否无论如何都要手动重跑命令刷新 GeoServer。结论是**分三种情况**，用临时表 `test_poi` 做了两组对照实验（训毕已清理：删图层 200 → `DROP TABLE` → reload 200，并复查 `admin_area` 出图仍 55324 bytes）。

**实验一：只插数据行，完全不碰 GeoServer。** 用 WFS 计数：库里 1 行→查得 1；插入第 2 行→立刻查得 2（Point A, Point B）；再插第 3 行→立刻查得 3。查询直接透传数据库，实时。

**实验二：`ALTER TABLE test_poi ADD COLUMN category text;` + UPDATE 回填。** 不 reload 时属性键只有 `name`（`category` 不出现）；`POST /rest/reload`（HTTP 200）后再查，属性键为 `name, category`，值 `school` 可见。

机理：GeoServer 不是数据库的镜像，它只维护「目录」（`data_dir` 里的 XML）——有哪些图层、每个图层有哪些**字段**、坐标系与样式绑定。数据行不进目录 → 实时；字段定义在目录里 → 结构变了目录即过期，需 reload。reload 只是重扫配置进内存，**不重启进程，通常 1–3 秒**，远轻于重新发布（发布是重建对象）。

| 你做了什么 | 要动 GeoServer 吗 | 怎么做 |
|---|---|---|
| 增/删/改**数据行** | 不用 | 什么都不做，刷新即见新数据 |
| 加/删/改**字段** | 要 | `curl -u "$AUTH" -X POST "$GS/rest/reload"` |
| 加了**新表** | 要 | 走一次发布（三步里的第 3 步） |
| 删了表 | 要 | 删掉对应图层，否则一查就报错 |

一句话：**GeoServer 管「有哪些图层、每个图层长什么样」，不管「图层里有哪些数据」。**

## 3. 两个附带坑

- **瓦片缓存会推翻上面的结论。** 一旦启用 GeoWebCache，数据变了但瓦片还是旧的，图上不变。此时需 truncate seed：`POST $GS/gwc/rest/seed/<ws>:<layer>.json`，body `{"seedParameter":{"type":"truncate"}}`。开发阶段未开缓存，但规律值得记：**缓存层越多，「数据变了图上不变」的原因就越多**。
- **Windows 上必须写 `curl.exe`。** PowerShell 里 `curl` 是 `Invoke-WebRequest` 的别名，参数不兼容（`-u`/`-X`/`-d` 全部语义不同）；要么用 `curl.exe` + 反引号续行，要么直接在 Git Bash 里跑 bash 版。相关表现：错误页是 HTML 时 `ConvertFrom-Json` 会抛 `Unexpected character encountered while parsing value: <`，暴露的正是「把 HTML 错误页当 JSON 解析」——排查时先看 status code，别先看解析报错。

## 4. 交付物演进（同日）

`deploy/README.md` 由纯用法文档扩为两段式：上半「怎么用」（文件 / 前置条件 / Windows 与 Linux 用法 / 行为 / 脚本做了什么对照 UI），下半「原理篇」（完整可复制写法、curl 五段解剖、REST 层级树、XML 标签↔UI 输入框、Windows 注意点、教学版 vs 脚本版）。**原理篇与脚本版并存是有意的**：先用展开版把原理跑通，再用脚本工程化；顺序反了就会变成「脚本能跑但不知道它在干嘛」。校验手法：代码块反引号计数需为偶数、标题层级排除代码块内 `# 注释` 后再看。
