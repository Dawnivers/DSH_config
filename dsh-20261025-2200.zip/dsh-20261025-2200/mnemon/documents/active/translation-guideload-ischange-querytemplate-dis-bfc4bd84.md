---
id: "bfc4bd84-5376-4b42-9aee-82361f557fa3"
title: "Translation 智慧地铁：路线规划（guideload）起终点/换乘站气泡 — isChange 由本地站点表透传、点击复用 queryTemplate 详情卡链路、异步标签的 disposed 清理"
description: "2026-10-19 在 Translation/src/components/bottom/StationPanel/QueryModePanel/guideload/renderRoute.js 为规划路线补上起点/终点/换乘站气泡：isChange 由 planModel 从本地站点表算出（换乘点恒为 1）并同时驱动气泡外观与详情卡字段；clickable 让点击气泡走 popup.js showQueryPopup()，与站点管理点站名标签完全同链路；addLabel 内部异步 import 模板，clear 用 disposed 标记收掉迟到挂载的 DOM；含验证选择器、/getStationInfo 实测数据与「纯 div 不在可访问树里，真点击未验证」的遗留项。queryTemplate 卡片样式与字体结论见 9b55863a，站点标签单例与相机见 497acdb0。"
status: "active"
created_at: "2026-10-19T05:36:03.302Z"
updated_at: "2026-10-19T05:36:03.302Z"
content_hash: "56e1f6af4cfa1aa2ca6c4f496734d9cff908291f56bee7cfa7618114aacdacde"
source_paths:
  - "Translation/src/components/bottom/StationPanel/QueryModePanel/guideload/renderRoute.js"
  - "Translation/src/components/bottom/StationPanel/QueryModePanel/guideload/planModel.js"
  - "Translation/src/components/bottom/StationPanel/MarkerTemplate.vue"
  - "Translation/src/components/bottom/StationPanel/queryTemplate.vue"
  - "Translation/src/cesiumTools/lineAndpoints/popup/popup.js"
session_ids:
  - "9d6984b5-49b2-4db9-a8b5-693f5baa2150"
memory_body_ids:
  []
---

# 路线规划气泡：起终点 + 换乘站（renderRoute.js）

## 1. 改动范围

文件：`Translation/src/components/bottom/StationPanel/QueryModePanel/guideload/renderRoute.js`

规划结果渲染原本只画线与光柱/圆环标记（`renderLines` + `addMarker`），本次补齐**文字气泡**：

```js
const first = plan.segments[0];
const last  = plan.segments[plan.segments.length - 1];
addMarker(viewer, first?.fromCoord, MARKERS.start, markers);
addMarker(viewer, last?.toCoord,   MARKERS.end,   markers);
plan.transfers.forEach((t) => addMarker(viewer, t.coord, MARKERS.transfer, markers));

// 起终点各带一个站名气泡：颜色跟各自光柱一致
addLabel(viewer, first?.fromCoord, first?.from, MARKERS.start.color, first?.fromIsChange, labels);
addLabel(viewer, last?.toCoord,   last?.to,   MARKERS.end.color,   last?.toIsChange,   labels);
plan.transfers.forEach((t) => addLabel(viewer, t.coord, t.name, MARKERS.transfer.color, 1, labels));
```

关键点：`isChange` **不是写死的**。`fromIsChange / toIsChange` 由 `planModel.js`（约 L213）从本地站点表算出，换乘点（`transfers`）恒传 `1`。

## 2. 一个 `isChange` 同时管两处

| 消费方 | 效果 |
|---|---|
| `MarkerTemplate.vue`（气泡外观） | `isChange` 为真 → 底色强制半透明红 + 加「换」徽标 |
| `queryTemplate.vue`（详情卡） | 「是否换乘站」一栏读 `attr.isChange` |

所以「莘庄这种换乘站被当作起点时气泡也是红的」是**设计如此**，与站点管理里的表现一致，不是 bug。

## 3. 点击气泡 → 详情卡（复用既有链路）

气泡传 `clickable: true`，点击即进入 `popup.js`（约 L89）的 `showQueryPopup()`：请求 `/getStationInfo`，用返回的 `address`（所属线路）与 `peopleFlow` 渲染 `queryTemplate` 详情卡。

这与「站点管理点站名标签」是**同一条链路**，因此详情卡的既有能力全部白拿：

- 同时只存在一张卡（`popup.js` 的 module 级 `activeQueryOwner`）；
- 卡片靠近屏幕右缘时自动镜像到站点左侧；
- 跟随相机距离缩放。

**清理也是天然成立的**：`clear()` 遍历 `labels` 调 `removeMarker()`，而它第一行就是 `removeQueryPopup()` —— 换方案 / 退出规划模式时详情卡不会留在半空。

## 4. 异步气泡模板的 `disposed` 保护

`addLabel` 内部是异步的（动态 `import` 模板 + `createVNode` 挂载），`renderRoute` 不等它：

```js
labels.forEach((label) => {
  label.addLabel().then((el) => {
    if (disposed && el) label.removeMarker();  // 迟到挂载的 DOM 自己收掉
  });
});
```

`disposed` 在 `clear()` 的第一行置真，随后才移除实体/标记/标签，避免「标签已清但模板刚回来」留下没人管的 DOM 气泡。

## 5. 验证（浏览器桥 + 选择器）

| 检查 | 结果 |
|---|---|
| 换乘气泡挂上并可见 | `.LabelPlot-container:not([style*="display: none"])[style*="255, 0, 0"]` → **换人民广场**（红底 + 换徽标） |
| 终点气泡 | 金色选择器 → **滴水湖** |
| 起点是换乘站时的透传 | 莘庄作起点时是 **换莘庄**（红），说明 `fromIsChange` 传到了 |
| 换方案时旧气泡清掉 | 改起终点后红/金气泡全部消失，重新查询才再出现 |
| 详情卡数据源非空 | `/getStationInfo`：陕西南路 441、人民广场 477、龙阳路 844、莘庄 953 人，均 `code=200`；`address` 返回如「上海地铁10号线;上海地铁12号线;上海地铁1号线」（分号分隔多条线） |
| 可点击性 | 模板根节点 `pointer-events: all; cursor: pointer`，`onClick → clickCallback` 现取 `this.clickable` |

性能旁证：本次 5 个标签各自一个 `postRender` 监听，**没有**走 400 站点那套管理器，未见异常。

## 6. 遗留 / 未验证项

- **「点下去弹卡片」这一步没有自动化验证**：气泡是纯 `div`，不在浏览器桥的可访问元素树里（快照里没有它的 index），当时 Chrome 窗口又是最小化的，桌面点击也够不到。需要人工点一次确认（弹出的是 620px 宽详情卡，站点靠右会自动翻到左侧）。
- 曾尝试用 `document.querySelector` 抓 `.LabelPlot-container` 判定气泡存在，**选择器写法很容易空匹配**（`#cesium-viewer > div > div:last-child .LabelPlot-container` 命中不到；改用 `style*="255, 0, 0"` 这类按颜色匹配才稳定）。判定气泡请优先按颜色/文本匹配，而不是假定固定的 DOM 层级。

## 7. 相关文档

- `9b55863a-1c10-4f00-baa0-479ddaed58ab` — queryTemplate 详情卡的 HUD 化、620×286 尺寸、右缘自动换边，以及「Rajdhani 从未加载、实际生效的是 Chakra Petch / JetBrains Mono / Noto Sans SC」的字体实测结论。
- `497acdb0-e3ab-4f1c-9679-e606ccb49406` — StationPanel 点站飞行弹卡、详情卡单例 `activeQueryOwner`、相机居中几何修正。
- `6a2ebece-f1d0-4be5-bc4d-b3484073c688` — 详情卡实拍图资产管线（stationImg glob 接入）。
