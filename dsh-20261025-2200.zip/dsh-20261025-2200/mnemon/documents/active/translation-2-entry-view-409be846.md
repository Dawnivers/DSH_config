---
id: "409be846-4517-43eb-9e36-134353f682bc"
title: "Translation 发展历程（迭代2）：纠正为固定入场视角 ENTRY_VIEW（六参数），并按路由进入/线路切换区分触发时机"
description: "2026-10-12 智慧地铁 Translation 对上一版「按线路包围球飞行取景」的纠正落地：用户明确不做按线路跳转，改为记录固定相机参数（lon/lat/height/heading/pitch/roll），仅在路由切进 /strategy 时飞一次、换线路相机不动；含 ENTRY_VIEW 结构、flyTo 实现、假值验证实测、通过面板内临时探针经浏览器桥读取用户当前相机的取值流程、Vue 模板里带花括号字符串用 HTML 实体的坑，以及「刷新会重置相机」的操作约束。前置 b366e21c（被本文纠正其第 2 节）。"
status: "active"
created_at: "2026-10-12T10:58:35.225Z"
updated_at: "2026-10-12T10:58:35.225Z"
content_hash: "7e6d8396842a6d95aca503c46b779d334d830cc59da1c61d6dc48181c650d29b"
source_paths:
  - "Translation/src/components/bottom/HistoryPanel/historyPanel.vue"
  - "Translation/src/cesiumTools/lineAndpoints/line/polyGlowflow.glsl"
session_ids:
  - "a35a3baf-12d6-49ee-81e1-6333518d3be4"
memory_body_ids:
  []
---

# 发展历程入场视角：从「按线路飞行」纠正为「固定 ENTRY_VIEW」

日期：2026-10-12。项目：`D:\WebGIS\web三维开发\智慧地铁项目\Translation`。
用户纠正原话：「**不是按线路跳转，而是记下我现在的相机参数，如果切换到这个路由，就飞到这个视角**」。

## 0. 与既有文档的关系（重要）

- **本文纠正 `b366e21c-881e-4624-8050-c8e9e97ec779` 的第 2 节**：那一版的「整条折线包围球 + `bearing + π/2` heading + 按线路尺度算 range」的取景方案**已被用户否决并删除**，不要再照着实现。
  `b366e21c` 的其余部分（第 1 节补亮、第 3 节连续进度条）仍然有效，本文不重复。
- 相关前置：生长线关流线 `e4980b77-d459-420c-811f-8bd0cee77a36`；流线溯源 `a1513ccf-8374-4c20-9a66-3ecb52505879`；生长动画本体 `bed0b7b7-e1e3-491b-80bd-51ffa66f4956`。

## 1. 需求语义（这里踩过一次误解，记下来防复发）

「视角飞到我现在这个画面」= **记录用户当前相机参数，作为固定入场视角**，不是「根据目标线路几何自动算一个合适的取景」。
关键差别：

| | 按线路自动取景（旧，已删） | 固定 ENTRY_VIEW（现方案） |
|---|---|---|
| 视角来源 | 运行时由线路几何算出 | 事先记录的一组常量 |
| 换线路时 | 相机重新飞一次 | **相机纹丝不动** |
| 高度 | 随线路长度变（1 号线 49 138 m / 11 号线 88 246 m） | 恒定 |

判断「视角飞到某地」这类需求时，先确认是**几何驱动**还是**参数回放**。

## 2. 实现

`historyPanel.vue` 中：

```js
const ENTRY_VIEW = null;   // ← 六个值：相机 位置 + 姿态（度）
// { lon, lat, height, heading, pitch, roll }
```

```js
const flyToEntryView = (viewer) => {
  if (!ENTRY_VIEW) return;
  viewer.camera.flyTo({
    destination: Cesium.Cartesian3.fromDegrees(
      ENTRY_VIEW.lon, ENTRY_VIEW.lat, ENTRY_VIEW.height,
    ),
    orientation: {
      heading: Cesium.Math.toRadians(ENTRY_VIEW.heading),
      pitch:   Cesium.Math.toRadians(ENTRY_VIEW.pitch),
      roll:    Cesium.Math.toRadians(ENTRY_VIEW.roll),
    },
    duration: ENTRY_VIEW.duration ?? 1.6,
  });
};
```

`lon/lat/height/heading/pitch/roll` 就是 Cesium `camera.positionCartographic` + `camera.heading/pitch/roll` 换算成度的六个值，
所以「在任意时刻抓一次相机状态」就能直接填进来。用 `entryViewApplied` 布尔量保证**一次会话只飞一次**（进入路由时触发，不跟线路变化绑定）。

**注意**：`ENTRY_VIEW = null` 时整个飞行是 no-op，所以这块代码可以安全地先留在仓库里等填值。

## 3. 取值流程（给「用户当前的相机」这类需求复用）

用户不在同一个进程里，拿不到他的相机 → 两条路子：

1. **DevTools 一行**（无需刷新，页面 viewer 还活着时可直接跑）：读 `positionCartographic` 与 `heading/pitch/roll`，乘 `180/Math.PI`，
   heading 归一化到 `(-180, 180]`（`((deg + 540) % 360) - 180`），`copy(JSON.stringify(...))` 直接进剪贴板。
   只返回 JSON 标量 —— 直接 `page.evaluate` 返回 Cesium 对象会报 `Cannot serialize result: object reference chain is too long`。
2. **面板内临时探针**（无 DevTools）：在组件里挂一个 `setInterval`，把当前相机参数写进 DOM 一行小字，外部浏览器桥读 DOM 就能拿到。
   本轮的探针实测输出：
   `CAMPROBE {"lon":121.458201,"lat":31.270543,"height":4821.76,"heading":131.1964,"pitch":-45.3461,"roll":0.0108}`。

**坑**：探针一开始放在面板外/被裁切的区域，元素被父级 `clip-path` 裁掉、桥读不到（读出来是 `CAMPROBE (waiting)`）——
探针要放在**面板内可见处**。探针是脚手架，拿到数后应当删除。

**操作约束**：刷新页面会把相机重置回默认视角，所以若用户是在「已经拖好的视角」上刷新，就白拖了 ——
要取用户当前相机，**先取值再刷新**；反之若面板因 HMR 刷坏，刷新能恢复（同一份代码在干净页面里实测面板、18 条线路、三个按钮都正常）。

## 4. 验证（用假值验证「这套逻辑真的生效」）

策略：`ENTRY_VIEW` 先填一组明显假的常量 `{lon:121.6, lat:31.15, height:25000, heading:45, pitch:-55}`，验证飞行行为本身，最后再换成真值。

| 时刻 | 相机 lon / lat / height / heading / pitch |
|---|---|
| 首页（默认视角） | 121.4582 / 31.2705 / 4822 / 131.2 / -45.35 |
| 进入发展历程后 | **121.6 / 31.15 / 25000 / 45 / -55**（与配置完全一致） |
| 再切到 18 号线 | 121.6 / 31.15 / 25000 / 45 / -55 ✅ **没再动** |

第三行就是本次纠正的核心断言：**换线路不再触发相机飞行**。

## 5. 模板里的字符串坑

在 Vue 模板里输出带花括号的字符串（如探针的 `CAMPROBE {...}`）必须用 HTML 实体写：
`CAMPROBE &#123;...&#125;`，否则会被 Vue 当成插值表达式解析。

## 6. 未完成

`ENTRY_VIEW` 截至本轮仍是 `null`，等用户给出六个数；填值后需同时删除临时探针。
