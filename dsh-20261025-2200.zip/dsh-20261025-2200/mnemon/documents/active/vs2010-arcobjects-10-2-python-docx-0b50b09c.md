---
id: "0b50b09c-791d-4bc1-8b09-d58be68a1901"
title: "VS2010 + ArcObjects 10.2 地图/图层控件程序 + python-docx 模板填报报告（实验三交付记录）"
description: "实验三的完成记录与可复用要点：为何只能用 ArcObjects 而非 ArcGIS JS API、MapControl/PageLayoutControl 共用 IMap 与布局联动的实现要点、本机 ArcObjects 运行环境的三个实测坑、以及「python-docx 填 docx 模板 → WPS COM 转 PDF/doc → PyMuPDF 逐页目视」的报告生成回路与踩过的排版问题。模板排版类流程另见 bda3f457。"
status: "active"
created_at: "2026-10-18T08:58:49.423Z"
updated_at: "2026-10-18T08:58:49.423Z"
content_hash: "579c25b0aced23bed669731d10e2fd1cc70ab4e593b420124ab166658116074d"
source_paths:
  - "MapLayerControl/MapLayerControl/Form1.cs"
  - "MapLayerControl/MapLayerControl/Form1.Designer.cs"
  - "_build_report.py"
  - "shots"
session_ids:
  - "2e94a30c-c451-4480-ae6c-f35568e432f2"
memory_body_ids:
  []
---

# VS2010 + ArcObjects 10.2 地图/图层控件实验（实验三）交付记录

工作区 `F:\AE 开发\实验三`。一次会话内完成：可运行程序 + 6 页实验报告（docx/doc）+ 源码压缩包。

## 1. 关键技术选型（有争议的一点，结论明确）

用户最初提到「ArcGIS SDK for JS」，但那是 **Web 端 API**，无法与 VS2010 的 WinForms 控件（`axMapControl`、`axPageLayoutControl`、`axTOCControl`、`axToolbarControl`）配合；实验内容要求的正是 **ArcObjects 组件式开发**。因此按 **VS2010 + ArcObjects SDK 10.2（C# / .NET 4.0，x86）** 实现——这是在 VS2010 里做出该界面的唯一路径。

- 工程：`MapLayerControl\MapLayerControl.sln`
- 数据：`D:\World\World.mxd`（World Cities / Continents / World 三个图层）
- 产物：`MapLayerControl\MapLayerControl\bin\Debug\MapLayerControl.exe`（23 040 bytes）

## 2. 程序实现要点（`Form1.cs`，约 296 行）

- ToolbarControl1 的「打开地图」命令把 mxd 载入 `axMapControl1`；`axTOCControl1` 与之绑定，勾选即控制图层显示。
- 底部选项卡在**数据视图 / 布局视图**间切换。布局控件加载同一文档的 PageLayout，**地图框与地图控件共用同一个 `IMap` 对象**，并用 `IMapFrame.MapBounds` 同步显示范围——这是「两个控件同一份地图、范围联动」的正常做法。
- 联动刷新会互相触发事件，故用 `m_isSyncing` 布尔标志做递归保护。
- 视图互斥：数据视图时 Toolbar2 灰显，布局视图时 Toolbar1 灰显。
- 事件挂接顺序：`Load` 里初始化伙伴控件、工具按钮并共享 `IMap`；`Resize`/`FormClosed` 在 Designer 中挂接（`Form1.Designer.cs` L163–167）。

## 3. 本机 ArcObjects 运行环境的三个实测坑

1. **`ArcGISVersion.dll` 不在 PATH**：直接启动报绑定失败；工程在启动时从注册表补 PATH 后即可运行。
2. **`PageLayoutControl` 需要 `OcxState`**，否则控件不初始化。
3. **窗体 `Load` 中过早调用 `LoadMxFile` 导致地图不绘制**：把加载推迟到控件就绪后再执行。
4. 运行前提仍是本机装有 **ArcGIS 10.2 运行时**（Desktop 10.2 在 `D:\arcgis\arcgisData\Desktop10.2\`，与 `4c9e5e3a-3e5a-46d0-899b-1366e2dbd754` 记录的环境一致）。

## 4. 报告生成回路：填模板 → 转格式 → 逐页目视

与「用 WPS COM 从零排版」（`bda3f457-c9ce-46b9-bca8-e239586f7f52`）互补：**模板已存在时优先填模板**，排版稳定性高得多。

```
_template.docx  --(_build_report.py, python-docx, 305 行)-->  2244275060-林先语-实验三.docx
   --(WPS COM 导出)-->  _preview.pdf  --(PyMuPDF 渲染)-->  shots/pages/p1..p6.png  （目视检查）
   --(WPS COM 另存)-->  2244275060-林先语-实验三.doc  --(_preview_doc.pdf)--> doc_p*.png（复核一致）
```

- **填之前先 dump 合并结构**：模板是单个大表（8 行），单元格大量跨列——row0 跨 9 列做标题，row1/row2 依次是姓名/学号/专业/年级/实验时间/实验地点/指导教师/实验成绩，row6 跨 9 列、43 个段落承载「实验过程及结果」，row7 为「实验总结」。用脚本打印每个 `tc` 的 `span` 与段落数再填，能避免索引错位。
- 验收：PDF 页数 + 页面尺寸（595.3×841.9 ≈ A4）确认无多余空白页，再逐页渲染 PNG 目视。

### 踩过的排版问题与修法

| 现象 | 原因 | 修法 |
|---|---|---|
| 日期/地点填到了邻居格 | 合并单元格后视觉列 ≠ 网格列索引 | 按 `tc` 实际位置重映射（`cell(2,0..8)`） |
| 出现空白页 | 模板 `trHeight=7465` twips（`hRule=atLeast`）把行撑高 | 去掉固定行高 |
| 截图带桌面边缘 | 整屏截图 | 从 1100×760 裁到 1064×754 再插图 |
| 代码块跨页断开 | 无段落级分页控制 | 加 `keepNext` 类控制，最终压回 6 页 |
| 小标签被迫换行 | 列宽不够 | 合并第二行相邻单元格 |
| 标题丢失 | 覆盖内容时把「实验过程及结果」「实验总结」段一起替换了 | 重新补回并微调小标签字号 |

## 5. 交付物

| 文件（`F:\AE 开发\实验三\`） | 大小 | 说明 |
|---|---|---|
| `2244275060-林先语-实验三.docx` | 222 467 | 主报告，6 页 |
| `2244275060-林先语-实验三.doc` | 256 000 | WPS 另存版（外观与 docx 逐页一致） |
| `2244275060-林先语-实验三-程序.zip` | 59 035 | 源码（Form1.cs 9 343 / Designer 10 260 / resx 13 116 / csproj 4 130 / Program.cs 2 981） |
| `shots\` | — | `initial_view.png`、`data_view.png`、`layout_view.png`、`pages\p1..p6.png`、`doc_p1/doc_p5.png` |

报告内容：封面信息（姓名/学号/专业/年级、时间、地点、目的与要求、内容、过程及结果、总结）、3 张程序实拍截图、5 段关键代码、遇到的问题与解决方法、AI 使用说明。

## 6. 收尾状态

- 已移除测试用的命令行入口，源码无调试残留（仅保留打开失败时的 `MessageBox` 提示）。
- **用户仍需自行补**：指导教师、实验成绩（模板留空）；实验地点「GIS 实验室」与时间如与实际上课不符可直接改。
