---
id: "3a0ce399-303d-4a00-95ef-e3c3d0db18af"
title: "Translation 智慧地铁站点管理面板（StationPanel）实现与两个真 bug：Vue 响应式代理破坏 Cesium remove()、overflow-x 隐含裁切"
description: "2026-10-10 站点管理控制栏落地记录：StationPanel.vue / stationState.js / lineAndStationStyle.js 新增与 foot.vue 接线，含换乘站归属规则、两侧栏布局可用区（1076 设计 px）、Teleport 到 .hud-canvas 的定位方案、不用路由的原因，以及两个已实机验证的真 bug（reactive 代理使 entities.remove 静默失败、overflow-x:hidden 导致 overflow-y 计算为 auto 造成裁切穿透）与逐步 Playwright 实测数据。"
status: "active"
created_at: "2026-10-10T09:46:22.479Z"
updated_at: "2026-10-10T09:46:22.479Z"
content_hash: "4d57f3544eb10a4e67d68b97df66f71012544fb9c7b3937ea964e65bcacc4a1e"
source_paths:
  - "Translation/src/components/screenUI/StationPanel.vue"
  - "Translation/src/components/screenUI/foot.vue"
  - "Translation/src/components/screenUI/Toolbar.vue"
  - "Translation/src/stores/stationState.js"
  - "Translation/src/config/lineAndStationStyle.js"
session_ids:
  - "e1861faf-45c8-4a76-908e-a32bc9bfb84a"
memory_body_ids:
  []
---

# Translation 智慧地铁：站点管理面板实现与两个真 bug

日期：2026-10-10。前序诊断见 `8d3c4c05-ec6a-4bb9-98de-8a40750572a5`（站点特效渲染链路与实测复盘），其中列为 P0 的「线路开关管不到站点、面板没有控站点入口」由本轮实施解决。

## 1. 交付物与改动文件

| 文件 | 改动 |
|---|---|
| `Translation/src/components/screenUI/StationPanel.vue` | 新增。双栏控制面板：左栏 18 条线路（3 列 + 色块 + 勾选框），右栏当前线路站点（换乘站描洋红点），右上角「全部显示 / 全部隐藏」 |
| `Translation/src/stores/stationState.js` | 新增。跨组件站点开关状态（共享 store，非路由） |
| `Translation/src/config/lineAndStationStyle.js` | 新增。抽出的 `LINE_COLORS` 与换乘站色——控制栏与图例必须同色，复制一份迟早出现两套配色 |
| `Translation/src/components/screenUI/Toolbar.vue` | 站点注册表 + 显隐同步 + 代理 bug 修复 |
| `Translation/src/components/screenUI/foot.vue` | NODES 按钮接线 + 渲染面板 + 标题让位 |

行为：加载时 400 个光锥 + 400 个光圈全部 `show=false`（对象保留、不销毁）；点 NODES「站点管理」面板浮出且站点显形；再点一次、点中央「首页」或切到别的导航 → 面板收起、站点全部 `show=false`。

## 2. 🔴 真 bug 1：Vue 响应式代理让 Cesium `remove()` 静默失败

`stationObjs` 原是 `ref([])`，Vue 会把 Cesium 对象包成响应式代理；而 Cesium 的 `remove()` 内部按引用 `indexOf` 查找——传代理进去返回 `false` 且**不报错**。实测：

```
reactiveIsProxy: true            ← 确实被包成代理
removeProxyReturns: false        ← 用代理删：404→404，没删掉
tempRemoveRawReturns: true       ← 用原始对象删：404→403，成功
```

后果：`clearStationMarkers()` 根本删不掉光锥。目前只因线路数据只加载一次才未暴露，一旦重新拉取数据会叠出 400 个幽灵光锥。

修法：`stationObjs` / `linesEnts` 改为普通数组保存原始引用（二者不参与模板渲染，本就不需要响应式）。组件 `onBeforeUnmount` 里遍历移除线路实体、清空数组并调 `clearStationMarkers()`。

**可复用教训**：任何交给 Cesium（或其他按引用比较的第三方库）持有/删除的对象集合，不要放在 `ref()`/`reactive()` 里；需要响应式时用 `shallowRef` + `markRaw`。

## 3. 🔴 真 bug 2：`overflow-x: hidden` 隐含把 `overflow-y` 变成 `auto`，面板上半截被裁掉且点不到

第一版把面板挂在 `.foot-page` 内。`.foot-page` 写了 `overflow-x: hidden`——按 CSS 规则，若另一轴的 `overflow` 是 `visible`，其**计算值会变成 `auto`**，于是 `.foot-page` 成为滚动容器，把面板上溢部分（设计 y 721–828）整个裁掉。症状具有极强欺骗性：

- `elementFromPoint` 在该区域直接**穿透**到底下的 Cesium `<canvas>`，左栏勾选框点不动（Playwright 报 `canvas ... intercepts pointer events`，30s 超时）
- 但面板自身祖先链完全干净（`.station-panel` 是 `pe: auto`、`z-index: 60`），逐层查指针事件继承链**查不出问题**
- 面板中心点命中正常（`button.sp-station`），只有被裁区域异常 → 容易误判为「没渲染出来」，实际截图看是画出来的

诊断方法：取多个采样点（面板中心、勾选框、站点块、导航按钮、左栏容器）分别看 `elementFromPoint` 命中的最上层元素，对比正常与异常点的差异。

修法：面板 `<Teleport to=".hud-canvas">`，直接在 1920×1080 设计坐标里定位（Toolbar 两个弹层即此做法），不受 zoom 和裁切影响，也免掉 `.foot-page` 的 `zoom: 1.4` 单位换算。

**可复用教训**：项目里凡是 `overflow-x`/`overflow-y` 只写一个轴的容器，另一轴都已是 `auto`；往上挂浮层会被静默裁切。浮层一律 Teleport 到 `.hud-canvas` 用设计坐标定位。

## 4. 布局可用区（实测，设计 px，1920×1080）

```json
sideLeft:  { x: 0,    y: 96, w: 422, h: 732 }
sideRight: { x: 1498, y: 96, w: 422, h: 732 }
navDeck:   { x: 64,   y: 937, w: 1792, h: 137 }
```

- 左右侧栏各占 x 0–422 与 x 1498–1920 → **中间可用宽度正好 1076**（以 960 居中）
- 导航条顶边 y=937，底部面板底边需 ≤ 937
- 第一版做 1190 宽，两边各多出 57px 压到侧栏，左侧栏 `.line-row` 拦截了勾选框点击；收窄到 54%（1037）后落到 x 442–1479，正常
- 最终面板 1040×232，居中贴导航条（实测 x 440–1480 / y 703–935）。想更大必须从两侧栏借空间

## 5. 三类设计决策（原因记录）

1. **换乘站归属规则**：一个站点属于多条线时，「只要还有一条所属线路开着就保持显示」。因此取消 1 号线不是少 28 个而是少 16 个（12 个换乘站被 2/3/8 号线带亮）。为此维护 owner 映射，让面板计数与三维严格一致，否则面板会谎报。可用「按主线路一刀切」替换，取决于产品意图。
2. **不用路由**：`router/index.js` 的 `routes: []` 是空的（控制台 `No match found "/"` 警告即源于此）。用路由会重建 Cesium 场景组件，等于整个三维重新初始化（参见 `46077717-b034-4315-a3c1-f04be09fed52` 的 KeepAlive 改造结论），风险过大。改用共享 store（`stationState.js`）实现同等效果——纯开关，零重建。
3. **面板尺寸被两侧栏卡死**（见上节）。

## 6. Playwright 实机验证记录（本机真实 Chrome，0 控制台报错）

| 操作 | 光锥（总/可见） | 光圈 | 面板 |
|---|---|---|---|
| 加载后 | 400 / **0** | 400 / 0 | 不在 DOM |
| 点「站点管理」 | 400 / **400** | 400 / 400 | 1号线 28/28 |
| 取消 1号线 | 400 / 384 | 400 / 384 | 1号线 **12/28**（16 个独有站灭，12 换乘站仍被其他线带亮） |
| 再单关非换乘站「富锦路」 | 400 / 399 | — | 27/28 |
| 再单关换乘站「呼兰路」 | 400 / 398 | — | 26/28，面板压暗 2/28 |
| 收起 → 再展开 | 400 / **398**（记住状态） | — | 状态保留 |
| 「全部隐藏」/「全部显示」 | 0 / 400 | — | 压暗 28 块 |

回归测试：齿轮工具箱「线路图层」正常（18 条折线 18→0→18，折线颜色 3 类不变）；开站点管理后折线仍 18/18；切「发展历程」自动收起站点面板；点中央「首页」全清空。

**测试工具坑**：中央罗盘按钮 `.compass-core-btn` 带无限旋转动画，Playwright 永久判定「元素不稳定」而超时——不是应用 bug，需强制点击（`force: true`）或绕过动画。同类「元素不稳定」超时要先怀疑动画。

## 7. 回归风险提示

- 前序文档中的 `cone.glsl` / `polyGlowflow.glsl` 仍用 `czm_frameNumber` 帧驱动闪烁与流光（本次未修）；400 个独立 Primitive 也未按颜色批处理。这两项在站点不再默认常显后，性能压力有所缓解但仍存在。

## 8. 截图证据

`.review/站点控制栏-已展开.png`、`.review/站点特效-线路全关后.png`、`.review/站点特效-默认视角.png`
