---
id: "c57db830-7398-42ec-87c4-718df048024f"
title: "Translation 鼠标工具「方案 A」落地交接：系统级图片光标 + 右下角读数面板"
description: "Translation 大屏「显示鼠标位置」工具按方案 A 改造完成：指针换 64×64 图片光标（cursor: url(...) 32 32，由系统合成器绘制、与页面帧率无关），读数改为右下角固定面板；含 foot.vue 具体改法、PNG 素材来源与热区、旧跟随式皮肤代码的清除范围，以及 Playwright 四态实测数据与残留的可选方向。"
status: "active"
created_at: "2026-10-07T13:33:52.446Z"
updated_at: "2026-10-07T13:33:52.446Z"
content_hash: "59b4132b8d5997964138e8d192aee92e50400c3d5d58fecf33c8f1725d9706cf"
source_paths:
  - "Translation/src/components/screenUI/foot.vue"
  - "Translation/src/assets/cursor-hud.png"
session_ids:
  - "76687cd2-e0b4-40df-ace2-b632d27878ce"
memory_body_ids:
  []
---

# Translation 鼠标工具「方案 A」落地交接：系统级图片光标 + 右下角读数面板

日期：2026-10-07。状态：**已实现并运行时验证通过**。

源文件：`Translation/src/components/screenUI/foot.vue`（约 2265 行）、新增素材 `Translation/src/assets/cursor-hud.png`（64×64，5132 字节）。

相关文档：
- `75da7559-5010-47fe-b292-58bd88afa63f` —— 帧率归因实验与 A/B/C 三方案（本文只记 A 的落地与验证，性能数据不重复）。
- `715e6684-4186-4c51-82f8-1db889099650` —— 旧的跟随式 HUD 皮肤设计（金环/青菱/脉冲）与两个 Vue 过渡坑；**其「皮肤跟随指针」的形态已被本文取代**，过渡坑的经验仍然有效。

## 1. 方案要点

用户选择「先完成 A」：**指针本体交给浏览器/系统合成器绘制**，读数与指针解耦。

理由（承自上述归因文档）：三维场景把整页压到约 6.5 FPS 且瓶颈在主线程，皮肤自身开销已≈0（6.6 vs 6.2 FPS），因此任何 DOM 跟随式指针都必然被拖住；系统绘制的光标与页面帧率完全无关，永远跟手。

## 2. 改动清单

| 环节 | 实现 |
|---|---|
| 指针本体 | `cursor: url(<cursor-hud.png>) 32 32, crosshair`；素材经 Vite `import cursorSkinUrl from "/src/assets/cursor-hud.png?import"` 拿到 URL，再由 foot.vue 写入 CSS 变量 `--hud-cursor-skin` |
| 全局生效 | 规则必须写在 **非 scoped** 样式块：`html.hud-cursor-none, html.hud-cursor-none * { cursor: var(--hud-cursor-skin, none) !important }` |
| 读数 | 右下角**固定面板** `.hud-cursor-panel`（Teleport 到 `body`，`v-if="mouseToolOn"`），两行：金色 `SCREEN X/Y`、青色 `GEO 经纬度`（`.hcp-row` / `.is-geo`） |
| 写 DOM 方式 | `textContent` 直写，不经 Vue 响应式；GEO 限 **10Hz**；画布矩形 `getBoundingClientRect()` **缓存 1 秒**（该调用会强制同步布局，每帧调用是实打实的开销），窗口尺寸变化置空重算 |
| 关闭路径 | 与旧版一致：去掉 `html.hud-cursor-none` 恢复默认光标 + 浮窗提示「鼠标已隐藏 ESC 按键重新显示鼠标」，点浮窗或 `Esc` 均可恢复 |

实测面板位置（1600×900）：`rect ≈ (1388, 799) 196×87` → 贴右边约 16px、贴底约 14px，不压任何 HUD 控件。

## 3. 素材为什么是 PNG

Chrome 的 `cursor` **不支持 SVG**，只吃位图。做法：把原来那套 SVG 准星（金环 + 青菱 + 十字 + 中心辉光）用 Chrome 画到 canvas 再导出 PNG；并额外加**深色描边**，保证在亮色底图上也看得清。

代价（已在交付时向用户明示）：**失去旋转环与脉冲动画**——静态图光标只能静止。

## 4. 本次清除的旧代码

跟随式皮肤整体退场，校验脚本断言以下标记从组件产物中消失：`hc-reticle`、`hc-ring`、`hc-pulse`、`hc-label`、`cursorRef`。保留下来的是 `Teleport` 到 body 的面板与提示浮窗两处挂载点。

## 5. 运行时验证（Playwright，真 GPU）

| 步骤 | 结果 |
|---|---|
| ① 默认（工具开） | 面板在，读数占位 `X -- Y --` / `--`；`cursor` 计算值 = `url(".../cursor-hud.png") 32 32`；`--hud-cursor-skin` 已设置；素材加载 OK；提示浮窗未出现 |
| ② 移动指针 | `SCREEN X 900 Y 420`、`GEO 121.5031°E 31.2391°N` 实时更新 |
| ③ 关闭工具 | 面板消失、`cursor` 回 `auto`、浮窗提示出现 |
| ④ 按 ESC | 面板与图片光标全部恢复，读数继续更新 |

页面控制台报错：**无**。素材 `HTTP 200 image/png 5132 bytes`；后端 `getLine` 200（18 条线路）、前端 200，页面数据正常（全网 807.3 km / 18 条线路在网）。

## 6. 未做 / 可选后续

1. **多帧动画光标**（实验性）：原生光标只能是静态图，但可在 JS 里按帧切换 `cursor` 值（如 4 张图轮播）；OS 光标重绘有自己的节奏，效果不保证。
2. **方案 C（三维减负）**：数据已指路——tileset 约占一半帧预算、底图在线瓦片占另一半。下手点是 tileset 的 `maximumScreenSpaceError`、底图换静态瓦片或关在线影像、`requestRenderMode` 按需渲染；收益是整个大屏，不只鼠标。
