---
id: "007be982-5811-4726-b040-4b2575d9877b"
title: "gs-apply-schema.sh：按「库里已完成的动作」调用 GeoServer（reload/publish/unpublish/check）与 REST 路径固定段（2026-10-23 实测）"
description: "交付并端到端实测的 deploy/gs-apply-schema.sh 使用说明：四种子命令与数据库操作的对应表、表不存在时由脚本反查 information_schema 列出真实表、删表必须先 unpublish、位置参数 ACTION/TABLE 语义、脚本不依赖当前目录与 Git Bash 相对路径写法、GeoServer REST URL 中固定关键字与自命名值的区分（datastores 与 stores 互为别名）。"
status: "active"
created_at: "2026-10-23T12:53:57.331Z"
updated_at: "2026-10-23T12:53:57.331Z"
content_hash: "db42861c3c3d61eb24d4f4f9d269becaea6af19040414d67e24620f2ad8f9c3e"
source_paths:
  []
session_ids:
  - "f015d9bb-c78d-41cc-aea0-f007d56190fc"
memory_body_ids:
  []
---

# gs-apply-schema.sh：把「库里已完成的动作」翻译成 GeoServer 操作

前情（本文不重复）：三层发布与 `Spatial` 库事实 `e2a4925e-c390-44f3-bd15-8bf165e70b28`；reload 边界实验与 409/500 不对称 `b2ece253-2d4b-4e6c-b5d2-904167fde9a3`；REST 与 UI 等价、幂等脚本写法 `be91eaef-f93d-4d77-803d-b34651d1dfd1`。

本文记录一次性收口脚本 **`D:\WebGIS\web三维开发\gis-access\deploy\gs-apply-schema.sh`**（位于工作区之外，仅作路径记录）：前置约定是「SQL 已用 psql / Navicat / QueryTool 跑完」，脚本只负责让 GeoServer 知道表结构变了，**从不碰数据库、也从不执行 DROP**。

## 1. 子命令 ↔ 数据库动作对应表

| 你在库里做了 | 跑什么 |
|---|---|
| `ALTER TABLE ... ADD/DROP COLUMN`、`ALTER TYPE` | `./gs-apply-schema.sh reload` |
| `CREATE INDEX` | `reload`（可有可无） |
| `INSERT / UPDATE / DELETE` 数据行 | **什么都不用跑** |
| `CREATE TABLE` 新表 | `./gs-apply-schema.sh publish <表名>`（reload 发现不了新表） |
| `DROP TABLE` | 正确顺序是先 `unpublish` 再 DROP；若已误删，`unpublish` 仍可补救 |

一句话判断：**「改了表的样子」→ reload；「多一张表」→ publish；「少一张表」→ unpublish。**

`reload` 是单条 `POST /rest/reload`，全量刷新、不需要表名；`publish` / `unpublish` 以 `[ -z "$TABLE" ] && usage` 强制要求表名。

**删表顺序不能反**：脚本刻意不提供 DROP，危险动作留给用户显式的 `psql -c "DROP TABLE ..."`。

## 2. 位置参数语义

```bash
ACTION="${1:-check}"   # 第一个词，决定做什么；不给参数默认 check
TABLE="${2:-}"         # 第二个词，表名；缺省为空字符串
```

表名必须是**库里真实存在的表名且大小写敏感**（`poi` ✓，`POI` ✗）。脚本把它拼进 `.../featuretypes/<table>`，GeoServer 找不到即 400。

日常三条：

```bash
psql -d Spatial -f migrations/005_add_phone.sql && ./gs-apply-schema.sh reload
psql -d Spatial -f migrations/006_roads.sql && ./gs-apply-schema.sh publish roads
./gs-apply-schema.sh unpublish roads && psql -d Spatial -c "DROP TABLE roads;"
```

## 3. 设计要点（比功能更值得复用）

- **存在性判断用 `curl -sf`**，不用状态码分类：`exists()` 封装 `curl -sf -u "$AUTH" "$1" -o /dev/null`，≥400 即非零退出。原因是同类冲突 GeoServer 给码不一致（工作区 409、Store/图层 500），见 `b2ece253`。因此重复 `publish` 输出「图层已存在，跳过」并 exit 0。
- **发布后立刻出图验证**：`GetMap ... bbox=113.7,29.9,114.6,30.9&srs=EPSG:4326` 打印 `HTTP %{http_code} %{size_download} bytes`。200 才算发布成功，与「端口通 ≠ 装好」同一验收思路。
- **400 时反查真实表名**：GeoServer 只说 `no attributes were specified`，脚本转而用 psql 查 `information_schema.tables`（`table_schema='public' AND table_type='BASE TABLE'`）打印表清单。实测发布 `not_exist` 得到：`spatial_ref_sys / empty_poi / admin_area / poi`，一眼看出是拼错还是没建成。
- **unpublish 先探存在再删**，`DELETE ...?recurse=true`；若 GWC 里有同名缓存则 `POST $GS/gwc/rest/seed/<ws>:<layer>.json` + `{"seedParameter":{"type":"truncate"}}`，最后 `POST /rest/reload`。
- 全部参数走环境变量默认值：`GS`、`AUTH=admin:geoserver`、`WS=wuhan`、`DS=spatial_db`，另用 `DB_PASS/DBHOST/DBPORT/DBUSER/DBNAME` 供 psql 反查。
- 脚本无 `cd`、不读任何本地文件，**不依赖当前目录**，任何目录用绝对路径调用都行。这反过来意味着：若脚本要读同目录 SQL，才需要 `cd "$(dirname "$0")"`。

## 4. 端到端实测（全部走通）

```
1. psql 建表 station_demo（2 行）            CREATE TABLE / INSERT 0 2
2. gs-apply-schema.sh publish station_demo    OK 已发布；WMS 200  4022 bytes
3. psql 加字段 wifi                          ALTER TABLE
4. gs-apply-schema.sh reload                 OK reload 完成
5. WFS 验字段                                 name, wifi
6. gs-apply-schema.sh unpublish station_demo OK；reload 200
7. psql 删表                                 DROP TABLE
```

清理后 `wuhan` 工作区剩 3 层：`admin_area`（13 区）、`poi`、`empty_poi`。

## 5. 路径与执行方式

Windows 路径 `D:\WebGIS\web三维开发\gis-access\deploy\gs-apply-schema.sh`；Git Bash 里写作 `/d/WebGIS/web三维开发/gis-access/deploy/`（盘符小写、正斜杠）。

- `.sh` 里的 `./` 是相对路径。「必须写 `./`」是因为无斜杠的裸文件名只去 `PATH` 找；**只要路径含 `/`，shell 就当路径处理**，所以 `deploy/gs-apply-schema.sh`、绝对路径同样有效。
- PowerShell 不认 `./x.sh`，需 `& "C:\Program Files\Git\bin\bash.exe" -c "bash '/d/.../gs-apply-schema.sh' reload"`；且 PowerShell 的 `grep` 是无效命令（实测报「术语 'grep' 不会被识别」），过滤输出要在 bash 内做或改用 `Select-String`。
- 同目录另有 `init-geoserver*.sh|ps1`、`scenario-1/2/3-*.sh`、`demo-add-table.sh`、`.env.example`、`README.md`；三个 `scenario-*` 与 `gs-apply-schema.sh` 功能重叠，是合并前的独立版。
- 想免 `cd`：把 deploy 目录加进 Git Bash 的 `~/.bashrc` PATH，或做 `.bat` 双击入口（内嵌 `set /p TABLE=` 后转调 bash）。

## 6. GeoServer REST URL：哪些段固定，哪些是自己起的名

`/geoserver/rest/workspaces/{ws}/datastores/{ds}/featuretypes/{table}`

| 段 | 性质 |
|---|---|
| `rest`、`workspaces`、`datastores`、`featuretypes` | **固定关键字**（源码写死，改成 `ws` 之类即 404） |
| `wuhan`（WS）、`spatial_db`（DS）、`admin_area`（TABLE） | 自己命名 / 来自数据库 |

- 规律：**紧跟 `rest` 之后、决定「资源类型」的名词段固定；夹在其中由脚本变量拼进去的值才是自定义的。**
- **`stores` 与 `datastores` 互为别名**，都能用；`datastores` 更贴切（专指矢量源），推荐统一写它。
- 其余固定分支：`styles`、`layers`、`namespaces`、`security`、`gwc`、`reload`、`about/version.json`。
- 可变的还有数据源**类型**本身（PostGIS ↔ Shapefile 时连接参数 XML 结构整体改变，见 `be91eaef`）。
