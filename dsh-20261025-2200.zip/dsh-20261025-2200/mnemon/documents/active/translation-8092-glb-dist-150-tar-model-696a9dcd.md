---
id: "696a9dcd-f643-4962-8452-b2296776993e"
title: "Translation 智慧地铁线上化：8092 反代全绿实测、glb 进 dist 的打包事实、150 万白膜瓦片 tar 上传与 /model/ 静态托管方案"
description: "Translation 后端 8092 通过 nginx 反代的实测验证结果、数据库 user/postgres 权限根因、glb 随 vite build 进 dist 的证据与子目录 base 坑、以及 150 万白膜 3D Tiles 用 tar 上传+解压+/model/ 静态托管的完整步骤与遗留待办。"
status: "active"
created_at: "2026-10-20T11:33:06.542Z"
updated_at: "2026-10-20T11:33:06.542Z"
content_hash: "ee17ca2d0b4e18272e92f7ccb692a036fd22ce67588b9cbbf547e4fb07e13896"
source_paths:
  - "Translation/src/cesiumTools/lineAndpoints/train/trainRoam.js"
  - "Translation/src/api/baseApi.js"
  - "Translation/src/cesiumTools/sceneManager.js"
  - "Translation/src/views/cesiumView.vue"
  - "Translation/vite.config.js"
session_ids:
  - "6f03eac7-8eb7-4fed-9d25-524bbdbe8ce9"
memory_body_ids:
  []
---

# Translation 智慧地铁线上化：反代验证 + 打包事实 + 大量瓦片上传

日期：2026-10-20。项目：`D:\WebGIS\web三维开发\智慧地铁项目`（前端 `Translation`，后端 `Translation_BE`）。
本记录只覆盖「上服务器」这一段的实测证据与决策，数据库 dump 细节见 `cdaa0177-267d-4849-814e-19a5b4961664`，密钥外置见 `60592d56-a0fc-4a32-bd93-1bf0fcabea37`。

## 1. 线上拓扑与环境事实

| 项 | 值 |
|---|---|
| 服务器 | `101.43.119.248`（CentOS，宝塔面板，hostname `VM-0-5-centos`） |
| 后端端口 | `8092`，进程名显示为 `MainThread`（即 `python`/`node` 裸跑，`ss` 显示 `*:8092`） |
| 后端域名 | `https://translationbe.dawnivers.top` → nginx 反代到 `127.0.0.1:8092` |
| 证书 | TrustAsia LiteSSL RSA CA 2025，`CN=translationbe.dawnivers.top`，2026-10-20 → 2027-01-18，校验 `Verify return code: 0`，TLSv1.3 |
| 白膜瓦片目标路径 | `/www/wwwroot/nginx_assets/Translation/`（本地源 `F:\public\shangHaiBuilds_new_toPlane`） |

## 2. 反代链路实测（全绿）

- `ss -lntp | grep :8092` → `LISTEN *:8092 users:(("MainThread",pid=3341283))`。
- 直连后端：`/getLine` 200 / 0.045s，`/getWeather` 200 / 0.189s。
- 走域名：`/getLine` 200 / 0.069s，`/getWeather` 200 / 0.145s ——**反代未引入故障**。
- 响应头：`server: nginx`、`x-powered-by: Express`、`access-control-allow-origin: *`、`etag`、`strict-transport-security`、HTTP/2 + alt-svc h3。
- 内容抽查（域名）：
  - `/getLine` → `{"code":200,...,"data":[{"id":7,"name":"上海地铁1号线","basicPrice":"3","length":"37.74161714",...`，`content-length: 60516`（18 条线）。
  - `/getStationInfo?name=人民广场` → `address: 上海地铁1号线;上海地铁2号线;上海地铁8号线`，`peopleFlow: 310`（直连时 394，说明该值是浮动的/按查询变，不是常量）。
  - `/getWeather?city=310000&extensions=base` → 高德返回正常（雾/25℃/湿度77）。
  - `/getLinePlan` 参数缺失时返回 `{"code":400,"message":"缺少参数 origin 或 destination"}` —— 参数校验是通了的。

### 2.1 数据库权限：根因是「导出用 postgres，服务用 user」

用户从 pgAdmin4 导出时用的是 `postgres` 超级用户，而服务器上后端连接用的库用户是 `user`（两者密码相同）。**用超级用户完成导入/授权后四个接口全部 `code:200`**。
可复用的结论：恢复 dump 时若用 `postgres`，必须补一句把表权限授给应用用户，否则 `user` 查表会 permission denied，表现为接口 500/空数据而反代一切正常：

```sql
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO "user";
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO "user";
```

## 3. 排查时的命令坑（不是故障）

- `curl: (23) Failure writing output to destination` —— 管道给 `head -c 120` 提前关闭所致，**正常**。
- 宝塔网页终端里 `\` 后跟空行会把命令拆断，于是出现 `--data-urlencode: command not found`、`curl: no URL specified!`。**在面板终端里一律写单行命令**。
- `curl -G --data-urlencode "origin=121.424698,31.391582"` 是正确的参数传法（逗号不要手动转义）。

## 4. 遗留的运维两个风险

1. **8092 监听 `*` 而非 `127.0.0.1`**：反代只用本机回环，所以公网 IP:8092 若能直连就绕过了 HTTPS 与反代。验证 `curl -m 3 http://<公网IP>:8092/getLine`，应为非 200；同时在宝塔「安全」与 `firewall-cmd --list-ports` 里不放行 8092。
2. **进程裸跑**：`MainThread` 说明是直接 `node index.js`，SSH 一断/重启即消失。应改为宝塔「Node 项目」托管或 systemd。
3. 可选一行加固：关掉 `x-powered-by`。

## 5. 前端 `pnpm build` 与 glb 模型的实测结论

模型源文件：`Translation/src/assets/trainAndChisa_static.glb`（23.56 MB）。

```js
// Translation/src/cesiumTools/lineAndpoints/train/trainRoam.js:39
const MODEL_URL = new URL('../../../assets/trainAndChisa_static.glb', import.meta.url).href;
```

`new URL(静态路径, import.meta.url)` 是 Vite 认得的资源引用写法，构建**会**把它搬进产物，且**不会被 base64 内联**（超过 4KB `assetsInlineLimit`）：

```
dist/assets/trainAndChisa_static-CU8atkpj.glb   24,706.71 kB (23.56 MB)
✓ built in 1.08s
[compress-dist] 174 个文件 · 8.04MB → gzip 2.64MB(33%) · brotli 2.10MB(26%) · 15.6s
```

产物里只有 2 处 base64 命中，均为 Cesium 自带解码器，与模型无关：
`basis_transcoder.js`、`draco_decoder_nodejs.js`（`data:application/octet-stream;base64,"`）。

产物 `dist/` 体量分布：glb 23.56 MB（单文件最大）> `cesium/` 9.6 MB > `assets/*.jpg` ≈22 MB（400 张站点照，按需）> `assets/*.js` ≈0.9 MB。glb 只在进入「REALTIME 线路轨迹」、`TrainRoam` 首次 load 时才请求，不拖首屏。

**部署注意**：编译后引用变成 `new URL(`/assets/trainAndChisa_static-CU8atkpj.glb`, import.meta.url)`，是**绝对路径**，依赖 `vite.config.js` 的 `base: '/'`；若部署在子目录（如 `/subway/`）必须同步改 `base`，否则模型 404 且页面白屏。

**压缩选项**：nginx gzip/brotli 对 glb 无效（二进制几何，`compressDist` 也已跳过非文本）；有效手段是 Draco 压缩 `npx @gltf-transform/cli optimize in.glb out.glb --compress draco`（一般降到 1~3 MB，Cesium 自带 `draco_decoder.wasm`，无需改代码），或删掉看不见的车厢内部节点。

## 6. 150 万文件的白膜 3D Tiles 怎么上服务器（用户选定方案 B）

事实：白膜有分级 LOD，`F:\public\shangHaiBuilds_new_toPlane` 下约 **1,509,600 个文件**；宝塔/系统层面的「上传」限制主要不是单文件大小，而是**海量小文件本身**（1 file ≈ 4KB 簇 → 光空间就 ≥6 GB，更致命的是 inode，以及中途断开无法续传）。用户明确不想扫描目录（太慢），所以流程设计成「打包 → 传一个文件 → 服务器解开」。

### 6.1 方案排序（先否掉「不能做的」）

- **A（最优）在服务器上直接生产瓦片**：把原始数据（osgb/CityGML/无 LOD 模型，几百 MB）传上去，用 `3d-tiles-tools` / `ctb-tile` / Cesium Ion 在服务器切 LOD，文件本地生成，根本不产生小文件传输。前提是手上还有可再生成的源数据；若只有这 1.5M 个已是 LOD 产物的文件，则走 B。
- **B（本次选定）tar 一个包传上去再解**：详见 6.2。
- **C 在服务器重切瓦片**：与 A 同源，只是强调切瓦片这一步放服务器上。

### 6.2 方案 B 的完整步骤

```bash
# 第 0 步（必做）服务器：inode 是 1.5M 文件最可能先满的东西，满了连删都难
df -i /www && df -h /www
#   IUse% 看余量，IFree 必须 > 1,550,000
```

```powershell
# 第 1 步 本地打包：在上一级目录 F:\public 下打包，包内路径即 shangHaiBuilds_new_toPlane/...
cd F:\public
tar -cf shangHaiBuilds_new_toPlane.tar shangHaiBuilds_new_toPlane
# 不加 -z：glb/b3dm/png 多为已压缩数据，gzip 收益小、150 万文件压一遍极慢
(Get-Item shangHaiBuilds_new_toPlane.tar).Length/1GB

# 第 2 步 上传（别用宝塔面板「上传」按钮，会转本地临时文件、易被限制挡）
scp F:\public\shangHaiBuilds_new_toPlane.tar root@101.43.119.248:/www/wwwroot/nginx_assets/Translation/
```

```bash
# 第 3 步 服务器解压
cd /www/wwwroot/nginx_assets/Translation
ls -lh shangHaiBuilds_new_toPlane.tar          # 先确认包完整
tar -xf shangHaiBuilds_new_toPlane.tar
ls shangHaiBuilds_new_toPlane | head           # 解压后应为 .../shangHaiBuilds_new_toPlane/tileset.json
rm -f shangHaiBuilds_new_toPlane.tar           # 确认无误再删

# 第 4 步 核对文件数（本地 PowerShell 也要跑一遍，两边数字一致才算传全）
find /www/wwwroot/nginx_assets/Translation/shangHaiBuilds_new_toPlane -type f | wc -l
# 本地：(Get-ChildItem F:\public\shangHaiBuilds_new_toPlane -Recurse -File -Force).Count
```

坑：Windows 自带 `tar.exe` 是 bsdtar，产出标准 tar 没问题；但**路径别带中文**（CRLF 与中文文件名解压后易乱码）。

### 6.3 nginx 暴露瓦片目录（对应前端 `localhost:666/model/...`）

宝塔：网站 → `translationbe.dawnivers.top` → 设置 → 配置文件，在 `server{}` 内加：

```nginx
location /model/ {
    alias /www/wwwroot/nginx_assets/Translation/;
    autoindex off;
    expires 30d;
    add_header Cache-Control "public";
    types {
        application/octet-stream b3dm i3dm pnts cmpt;
        application/json json;
    }
}
```

- `location /model/` 与 `alias .../Translation/` 的**末尾斜杠必须成对**，否则拼错一层目录。
- 与反代后端的那段（`/getLine` 等）不冲突。
- 验证：`curl -sI "https://translationbe.dawnivers.top/model/shangHaiBuilds_new_toPlane/tileset.json"` 期望 `HTTP/2 200` + `content-type: application/json`。
- 这样不用另开 666 端口（CORS、HTTPS 都已在域名上验过），前端 5 处 `http://localhost:666/model/...`（`sceneManager.js:39/49/123/134`、`cesiumView.vue:111/115`）改读 `VITE_TILES_BASE`：本地 `http://localhost:666/model`，线上 `https://translationbe.dawnivers.top/model`。

### 6.4 先问「这 1.5M 真都要上线吗」

大屏演示场景下，完整 LOD 金字塔里最细 2~3 层往往占文件数 90% 以上却只在贴脸时用到。可先统计层级分布，砍掉再上线：

```bash
find . -type d | awk -F/ '{print NF-1}' | sort -n | uniq -c
```

另：Cesium 1.97 支持 `3DTILES_implicit_tiling`，能把「每 tile 一个 json」换成规则命名，减少元数据文件数与解析开销（不减 b3dm 本身）。此外 1.5M 文件的备份、`rsync`、迁移成本都要提前算进去。

## 7. 待办

- [ ] 服务器 `df -i /www` 结果 → 决定能否直接 tar 解压（IFree > 1.55M）。
- [ ] 解压并核对文件数、`tileset.json` 可访问。
- [ ] nginx 加 `location /model/`。
- [ ] 前端 `baseApi.js:3` 改 `import.meta.env.VITE_API_BASE`（本地 `http://127.0.0.1:8092`，线上 `https://translationbe.dawnivers.top`）——**https 页面请求 http 会被 Mixed Content 拦掉**。
- [ ] 前端 5 处 `localhost:666` 换 `VITE_TILES_BASE`。
- [ ] 收敛 8092 公网暴露、改为守护进程托管。
