---
id: "e8f75bd1-e9be-4c78-905a-1b26d413d40d"
title: "DSH 内置浏览器停靠右侧停靠栏：三方案调研与本地补丁"
description: "dsh-builtin-browser 插件为何只能浮层显示、DSH 右侧边栏 tab 注册 API 形状、A/B/C 三条停靠路径的取舍，以及已实施的「贴右侧」补丁位置、生效方式、回滚命令与读取能力验证证据。"
status: "active"
created_at: "2026-10-06T14:45:23.065Z"
updated_at: "2026-10-06T14:45:23.065Z"
content_hash: "d5e8db6a5214b08d0bfa3325b1214885ba52badffa6221456f1168e5de019468"
source_paths:
  []
session_ids:
  - "ee63c0c2-2937-47f2-a616-8ac1ef720ad9"
memory_body_ids:
  []
---

# DSH 内置浏览器停靠右侧停靠栏：三方案调研与本地补丁

来源：一次「如何让安装的插件浏览器显示在侧边栏」的排查 + 实施会话。约束条件来自用户：**必须让模型能读取侧边栏里那块浏览器的画面内容**。最终落地的是「贴右侧」的浮层形态（路 C），不是真·侧边栏 tab。

## 1. 关键约束（决定了可选范围）

- 插件 `dsh-builtin-browser`（clone 自 `github.com/EnZzzzzz/dsh-builtin-browser`）只有两个注册点：
  - `sidebar.footer.action` —— 左侧栏底部的开关按钮；
  - `shell.overlay` —— 全屏浮层，构建产物里为 `lib/client.js` 的 `position: "fixed"; inset: 0; zIndex: 1e3`。
  - 结论：**插件本体没有侧边栏面板位**，要停靠必须换承载方式。
- 官方包 `@deepseek-ai/dsh-client-ui-sidebar-browser` 的 README 明确写着「**模型体验：无**。Browser tab 是用户侧呈现状态，不注册工具、prompt section 或 Session event」。也就是说官方那个侧边栏浏览器**设计上就不给模型看**。
- 因此「侧边栏显示 + 模型能读」只能由**插件引擎**（`window.__dshBrowser` → store / 控制器 / webview）承载的视图实现；`dsh-sidebar-live` 之类的视图也是复用同一套引擎。
- 环境：DSH `0.2.0-rc.2`（`@deepseek-ai/dsh`、`dsh-base`、`dsh-web-app`、`dsh-client-ui-sidebar-right` 同版本），Desktop 外壳（`dsh-desktop-version=2.0.17`、`browserPort=44721`），桌面 profile。本机已具备 rc08 的 `ctx.remote.fileReferences`（见 `dsh-api-remotes/lib/client.js`、`dsh-api-session-controller/lib/typert.remote-client.js`）。

## 2. DSH 右侧边栏 tab 的注册 API（真停靠要做到这一步）

右侧栏是 tab 注册表制，官方浏览器就是这么挂上的：

```js
// 1) 声明 tab 类型
ctx.sidebarRightTabs.register({   // 服务由 dsh-client-ui-sidebar-right 提供
  id: 'builtin-browser', kind: 'builtin-browser', multiple: true, priority: 'builtin',
  title: () => '内置浏览器', keepMounted: true,
  guide: [{ id: 'new', order: 30, title: () => '内置浏览器', description: () => '真 webview 浏览器' }],
})
// 2) tab 正文（每会话一个座位）+ 3) 标题
ctx.slots.inject('sidebar.right.pane.tab', () => ctx.slots.register(
  { name: 'sidebar.right.pane.tab', key: 'builtin-browser', store, inject: (sid, actions) => controller }, BrowserBody))
ctx.slots.inject('sidebar.right.pane.tab.title', () => ctx.slots.register(
  { name: 'sidebar.right.pane.tab.title', key: 'builtin-browser', store }, BrowserTitle))
// 4) 让 agent 的 browser_* 打开这个 tab，并压掉浮层
setOpenHandler(() => ctx.sidebarRight.openTabFromTarget('builtin-browser', target))
```

官方 `browserDefinition` 的实际形状（可照抄）：`{ id: BROWSER_ID, kind: BROWSER_KIND, multiple: true, priority: "builtin", title: () => t("type.label"), guide: [{ id: "new", commandId: "browser.new", order: 30, title/description/icon }] }`；中文文案 `type.label: "浏览器"`、`guide.description: "浏览网页"`。

## 3. 三条路径与取舍

| 路径 | 做法 | 结果 | 代价 |
| --- | --- | --- | --- |
| A 配套包 | 装 `dsh-sidebar-live`（真身是 `EnZzzzzz/dsh-slide-bar` 的 `packaged/`），经 `ctx.modules.import('dsh-builtin-browser/client')` 复用同一引擎，并用**同名空槽条目**压掉插件浮层与侧边栏按钮（组合级二选一） | 整包重绘侧边栏（活动栏 + 资源管理器 + 会话面板接管）；浏览器的呈现仍是**全局浮层**（右上角地球按钮开合、Esc 关闭），**不是贴边停靠** | 需 clone + `cd packaged && node build.mjs`、profile `package.json` 加 `"link:<绝对路径>"` 并追加 `dsh.profile.bundles`、建 node_modules 软链、重启；README 面向 **web profile**，本机是 rc.2 + 桌面 profile，未必完整可用 |
| B 真 tab | 按第 2 节的 API 给插件补一个右侧边栏 tab（可多开、参与布局、`keepMounted`、出现在 + 菜单），内核换成插件的真 `<webview>` | 形态与官方侧栏一致，**读取能力与路 C 完全相同** | 要改 `src/client/index.ts` + 新增 docked 变体组件；仓库没有 `node_modules`，需先 `npm install`（tsdown / typescript / react-dom）再 `npm run build:client` |
| C 贴右侧（已采用） | 只改那处 inline style，把「铺满窗口」改成「贴右」 | 左边照常看对话，右边固定一块浏览器面板；刷新即生效 | 仍是浮层：不参与侧边栏布局、不能拖拽调宽 |

## 4. 已实施的补丁（路 C）

改动两处（产物 + 源码同步，重建不丢）：

- 构建产物 `lib/client.js`（实际生效）：`inset: 0` → `inset: "0 0 0 auto"; width: "min(46vw, 640px)"; minWidth: 340px`，并加左边框与投影。
- 源码 `src/client/BrowserPanel.tsx`（第 427 行附近，同样的 style 对象）。

主题背景/前景仍走 `var(--bg, #fff)` / `var(--fg, #111)`，`role="dialog"` 与工具栏 CSS 未动。

- **生效方式**：给 DSH 窗口发 Ctrl+R 重载渲染进程——客户端 bundle 由 web 服务按需从磁盘读，**不需要重启 dsh**。（GUI 首页直接 HTTP 取会 401，不能用 `Invoke-WebRequest` 探测。）
- **回滚**：`git checkout -- lib/client.js src/client/BrowserPanel.tsx`（这两处在打补丁前是干净的；`lib/index.js`、`package.json`、`src/index.ts` 属于更早的另一次补丁改动，未动）。
- 浅色注意：`BrowserPanel.tsx` 里 `position: 'fixed'` 只有 1 处，`lib/client.js` 里也只有 1 处，改动点唯一、可安全替换。
- 该目录 git 远端为 `github.com/EnZzzzzz/dsh-builtin-browser.git`，最新提交 `3c2fd7b feat(browser): 按预设控制工具可见性，默认在极简模式隐藏`；`lib/client.js` 与 `src` 时间戳一致，说明产物跟得上源码。

## 5. 验证证据（用户的核心诉求：模型能读画面）

面板实测宽 640px（= `min(46vw, 640px)`），三项能力全部通过：

- `browser_content`：读到页面全文（「地铁三维可视化管控平台」「全网运营总里程 807.3 km」「18条线路在网」等）。
- `browser_eval`：`{title:"Vite App", h1:"地铁三维可视化管控平台", canvas:3, fps:"6 FPS", topFrame:true}` —— `topFrame:true` 证明是真 `<webview>` 而非 iframe。
- `browser_screenshot`：出图 640×1102，正好是该面板视口；探针 `webviewCount: 1`。

## 6. 后续可选升级

- 调尺寸：只改一个值，例如 `width: "42vw"` 或固定 `520px`。
- 升级为真·右侧边栏 tab（路 B），读取能力不变；前置工作是补源码 + 装构建依赖。
- 想用路 A 时注意它的组合级开关语义：装了配套包就会压掉本插件的浮层与左侧栏按钮，二选一。
