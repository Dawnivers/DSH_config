---
id: "f1f56bad-9c05-4309-ac7e-f2ae428f6d96"
title: "Translation：站点标记的「聚焦线路 + 活动站让位给光柱」与 popup 可点击性运行时化 —— 含 maxDistance 用「真实斜距」而非相机高度这个真凶，与「新组件先 mount、旧组件后 unmount」时序坑"
description: "Translation 站点图层跨栏目复用最终版：四个量（stationPanelOpen / stationMarkerMode: panel|all|none / stationPopupOn / focusedStationLine），'all' 可见集合 = 聚焦线路的站点 − 该线有重点活动的站（活动站让位给光柱，判据直接取 activityOfLine，不另存状态，换乘站按聚焦线路算）；含两点非显然结论——popupManager 的 maxDistance 判据是相机到站点的真实斜距而非相机高度（长线路 flyTo 后可达 98km，已由 80000 抬到 150000），以及旧组件后 unmount 导致必须早退的时序坑、popup.clickable 必须运行时判定。验证：18 条线逐条切换，可见标签数精确等于「站点数 − 活动数」且零泄漏。"
status: "active"
created_at: "2026-10-14T08:26:56.317Z"
updated_at: "2026-10-14T08:53:40.841Z"
content_hash: "8e9412364f8a960284591b1fc71d5791485e7aa919aeb1d2aa3b1d4d152fc532"
source_paths:
  - "Translation/src/stores/stationState.js"
  - "Translation/src/components/bottom/Toolbar.vue"
  - "Translation/src/components/bottom/StationPanel/StationPanel.vue"
  - "Translation/src/cesiumTools/lineAndpoints/popup/popup.js"
  - "Translation/src/components/bottom/ActivePanel/ActivePanel.vue"
session_ids:
  - "session-d6cbf69c-ac7f-4b6b-a2a9-8468919b087a"
memory_body_ids:
  []
---

# Translation：站点标记的「聚焦线路 + 活动站让位给光柱」与 popup 可点击性运行时化

日期：2026-10-14。项目：`Translation`。
需求原话（三轮）：
1. 「我希望进入重点活动，除了重点保护的圆柱，将站点管理的站点也显示，不过禁用 querytemplate 点击显示功能」
2. 「只显示当前重点活动所在线路上的站点」
3. 「如果是重点活动的站点就只显示光柱」

重点活动栏目本体见文档 `898c7711-8359-4297-8e5c-4fd4ef2b9a07`。

## 1. 最终模型：四个量，全部由路由/面板推导

```js
// stores/stationState.js
const routePath = computed(() => router.currentRoute.value.path);

const stationPanelOpen  = computed(() => routePath.value === '/nodes');  // 只管侧栏与底栏罗盘
const stationMarkerMode = computed(() => {
  if (routePath.value === '/nodes')      return 'panel';   // 显隐归 StationPanel 的开关组合
  if (routePath.value === '/experiment') return 'all';     // 聚焦线路的站点，活动站除外
  return 'none';
});
const stationPopupOn    = computed(() => routePath.value === '/nodes');  // 只有站点管理可点
const focusedStationLine = ref('');   // 线路全名，ActivePanel 写、Toolbar 读
```

**为什么不能复用 `stationPanelOpen`**：它同时被 `panel.vue:63,69`（收左右侧栏）与
`foot.vue:428`（罗盘避让）消费，而两个栏目对侧栏的要求正好相反 —— 站点管理收起、重点活动保留。
合并就会连坐。

**为什么 `focusedStationLine` 放 store 而不是留在面板里**：显示的唯一执行者是 Toolbar。
面板只负责「说要看哪条线」，Toolbar 负责落 `show`，这样不会出现两个组件各写一半互相覆盖
（StationPanel 退场与新面板挂载的先后顺序问题就是这么来的）。

## 2. 显示权归属（唯一的写法）

```js
watch(
  [stationMarkerMode, stationPopupOn, focusedStationLine,
   () => lines.value.length, () => stationObjs.length],
  ([mode, popupOn, lineName]) => {
    const allNames = stationObjs.map((i) => i.name);

    if (mode === 'all') {
      const line = lines.value.find((i) => i.name === lineName);
      // 有重点活动的站让位给光柱：那个站已经有 3km 高的柱子在标了，
      // 再叠一个光锥 + 底圈 + 站名标签只会打架。
      // 判据直接取自活动数据集本身（与面板立光柱用的是同一份），不另存状态，
      // 这样「哪些站有柱子」和「哪些站被让位」永远是同一批。
      const activityStations = new Set(
        activityOfLine(shortLineName(lineName)).map((a) => a.station),
      );
      const on = (line?.stations ?? [])
        .map((s) => s.name)
        .filter((n) => !activityStations.has(n));
      const onSet = new Set(on);
      hideStationByName(stationObjs, on, true);
      hideStationByName(stationObjs, allNames.filter((n) => !onSet.has(n)), false);
    } else if (mode === 'none') {
      hideStationByName(stationObjs, allNames, false);
    }

    stationObjs.forEach((i) => { if (i.popup) i.popup.clickable = popupOn; });
  },
  { immediate: true },
);
```

- **'panel' 模式下 Toolbar 绝不碰 `show`**，否则和 StationPanel 的 checked/lineStationOn/forced 打架。
- `lines.value.length` 与 `stationObjs.length` 两个依赖都不能省：线路数据到达会清空重建 stationObjs，
  而聚焦线路也可能先于线路数据到达（面板先挂载）。少了它们就只会在「路由变了」时才重算。
- `renderStationMarkers` 里 `isShow` 一律给 `false`，显隐**只**由这个 watcher 落 ——
  写成「mode==='all' 就可见」的话，创建时还不知道聚焦哪条线，会先把 400 个站全亮一帧再收窄。
- `hideStationByName` 一次同时切光锥（Primitive.show）、底圈（Entity.show）、站名标签（popup.isDisplay），
  所以「让位」是整站让位，不会留下一个没有标签的光锥。

**换乘站的注意点**：让位是**按聚焦线路**算的。人民广场是 8 号线的活动站、但不是 1/2 号线的活动站，
所以聚焦 1 号线时它照常显示站点标记，聚焦 8 号线时才让位。这是对的。

## 3. 时序坑：新组件先 mount、旧组件后 unmount

Vue Router 换页（默认 transition 同时进行）的实际顺序：

```
ActivePanel.mount          → 站点被显示
StationPanel.unmount       → 原来这里 hideStationByName(all, false)，又收掉
```

而且之后路由已切完、mode 仍是 'all'，**没有任何响应式依赖会再变** → 站点会一直不显示。
挡法（StationPanel.vue 的 onBeforeUnmount 里）：

```js
if (stationMarkerMode.value === 'all') return;   // 交给 Toolbar 按路由管
```

反方向 `/nodes → /`、`/nodes → /strategy` 不受影响：那时 mode 是 'none'，两处都收一次是幂等的。

## 4. popup.js：clickable 必须是运行时开关

原实现 `clickCallback: this.clickable ? () => this.showQueryPopup() : () => {}` 是**创建时二选一**，
而标签只在 `addLabel()` 时挂一次 —— 栏目按路由改写 `this.clickable` 对已挂载的标签无效。改成：

```js
clickCallback: () => {
  if (!this.clickable) return;
  this.showQueryPopup();
},
```

`MarkerTemplate.vue` 只认 `props.clickCallback()`，换成「永远存在、内部判空」的函数，模板侧零改动。

## 5. 真凶：maxDistance 量的是「真实斜距」，不是相机高度

**现象**：1 号线一切正常（28/28 标签），切到 11 号线变成 **0 个**。
探针显示 `found=true`、`onLen=37`、站名全对、`isDisplay=true`，
但每个标签的 `style.display` 都是 `none`。

**根因**在 `popupManager.postRender`：

```js
if (marker.filterStructage === 'distance')
  filterFactor = Cesium.Cartesian3.distance(camera.position, marker.position);  // ← 真实斜距
else
  filterFactor = Math.ceil(camera.positionCartographic.height);                  // ← 相机高度
...
const maxDistance = marker.maxDistance ?? 12000;
const condition2 = filterFactor > maxDistance;
```

站点的 `filterStructage` 是 **`'distance'`**，所以判据是**相机到该站点的三维斜距**。
俯视时斜距≈高度，一斜看就会是高度的两三倍。实测：

| 线路 | 取景后相机高度 | 到各站斜距 | 结果 |
|---|---|---|---|
| 1 号线 | 4822 m | 53.7 ~ 61.1 km | < 80km，全部可见 |
| 11 号线（74.3km 长、伸到花桥） | 34786 m | **83.5 ~ 98.2 km** | > 80km，**整条线被剔除** |

「重点活动」点线路时 `viewer.flyTo(highlight)` 按整条线取景，**线路越长相机拉得越高**，
斜距就顶破了阈值 —— 于是长线路的站点整批消失。

**处置**：`Toolbar.vue` 的 `POPUP_CONF.maxDistance` 由 **80000 抬到 150000**（覆盖最坏 98.2km 并留余量），
`near/far/farScale` 不动，避免改变已有的近大远小观感。
实测 /nodes 的可见标签数不变（49，那里是被屏幕范围而非距离限制），所以这次抬高没有副作用。

**另一个隐蔽点**：`postRender` 里 `wgs84ToWindowCoordinates` 失败时是 `continue`，
**不重写 `display`**，元素会保留上一次的值。所以「上一步被隐藏过」的标签，
即使这一步 `isDisplay` 变成 true，只要投影失败就会一直停在 none。

## 6. 实机验证（Playwright，1920×1080）

**18 条线逐条切换的扫描**，判定标准三条：可见标签名全部属于该线、
**不含任何该线的活动站**、且数量 = 该线站点数 − 活动数。

| 线路 | 活动数 | 站点数 | 期望可见 | 实测 | 活动站泄漏 | 越线 |
|---|---|---|---|---|---|---|
| 1 | 4 | 28 | 24 | 24 | 0 | 0 |
| 2 | 4 | 31 | 27 | 27 | 0 | 0 |
| 3 | 2 | 29 | 27 | 27 | 0 | 0 |
| 4 | 3 | 26 | 23 | 23 | 0 | 0 |
| 5 | 3 | 15 | 12 | 12 | 0 | 0 |
| 6 | 3 | 28 | 25 | 25 | 0 | 0 |
| 7 | 3 | 33 | 30 | 30 | 0 | 0 |
| 8 | 4 | 30 | 26 | 26 | 0 | 0 |
| 9 | 3 | 34 | 31 | 31 | 0 | 0 |
| 10 | 4 | 34 | 30 | 30 | 0 | 0 |
| 11 | 4 | 37 | 33 | 33 | 0 | 0 |
| 12 | 3 | 32 | 29 | 29 | 0 | 0 |
| 13 | 3 | 31 | 28 | 28 | 0 | 0 |
| 14 | 4 | 32 | 28 | 28 | 0 | 0 |
| 15 | 4 | 30 | 26 | 26 | 0 | 0 |
| 16 | 3 | 14 | 11 | 11 | 0 | 0 |
| 17 | 3 | 14 | 11 | 11 | 0 | 0 |
| 18 | 3 | 32 | 29 | 29 | 0 | 0 |

**18/18 全部精确命中，零个活动站泄漏，零个越线，零条为空。**

其余：

| 检查 | 结果 |
|---|---|
| /experiment 点标签 | → `.query-popup` **0** ✅ |
| /nodes 点「全部显示」后点标签（回归） | → **1** ✅，关闭 → 0 ✅ |
| 回首页 | 可见标签 **0** ✅ |
| 控制台 / 临时探针 | 零错误 / 已删除 ✅ |

**性能**（同一路由、rAF 3 秒同法实测）：铺满 400 站 **30 FPS** → 聚焦一条线 **45 FPS**。
（受控测量过：把 346 个标签的 DOM 全压掉只回收约 5ms，
说明大头是**光锥 Primitive 的绘制**，不是标签 DOM —— 所以收窄线路同时也把绘制量收窄了。）

截图：`.review/final-line11.png`（让位前：11 号线 37 个标签）、
`only-columns.png`（让位后：18 号线 29 个标签 + 3 根柱，活动站没有标记）、
`station-1-experiment.png`（最早的全量对照：346 个标签铺满）。

## 7. 一句话

站点标记的显隐不该挂在「侧栏收不收」那个开关上：拆成 `stationPanelOpen`（侧栏）、
`stationMarkerMode`（panel / all / none）、`stationPopupOn`（可点性）、`focusedStationLine`（看哪条线）
四个量，显示权只在非 'panel' 模式归 Toolbar；`all` 的可见集合再减掉「该线有重点活动的站」，
让位给光柱；`popup.clickable` 必须运行时判定；
而「标签到底显不显示」的最后一关在 `popupManager` 的 `maxDistance` —— 那里量的是**斜距**不是高度，
长线路取景后斜距能到 98km，阈值必须留够。
