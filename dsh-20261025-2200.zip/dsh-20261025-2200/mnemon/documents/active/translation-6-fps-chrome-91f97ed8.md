---
id: "91f97ed8-2a88-4141-8fbf-2c6cb97cecfa"
title: "Translation 智慧地铁：三维 ~6 FPS 的真根因——Chrome 跑在集显上（附实测基线与改法）"
description: "一次 CDP 实测定位：项目 6 FPS 不是场景/后处理/LOD 问题，而是 Windows 让 Chrome 用 AMD 集显；强制 RTX 4070 后 6.3→56.8 FPS。含实验数据、对既有「主线程瓶颈」结论的推翻、setScene 死代码证实、以及三条改法（Windows 显卡偏好 / NVIDIA 面板 / --force_high_performance_gpu）与验证步骤。"
status: "active"
created_at: "2026-10-07T14:11:10.609Z"
updated_at: "2026-10-07T14:11:10.609Z"
content_hash: "080a28c79506341a30fd55be6610e765d02513056d23aab82f0abc47b743dc47"
source_paths:
  - "Translation/src/cesiumTools/sceneManager.js"
  - "Translation/src/views/cesiumView.vue"
session_ids:
  - "fe6d892d-d251-49a4-bd12-b912f3c8114b"
memory_body_ids:
  []
---

# Translation 智慧地铁：三维 ~6 FPS 的真根因 = Chrome 误用集显

起因：用户问「我的项目可以使用 GPU 渲染吗？我看项目运行时 GPU 占用为 0」。
结论：**GPU 一直在用，只是用错了那块**——项目跑在 AMD 集显上，机器上的 RTX 4070 全程闲置。

**本文取代 `979eb2d7-7e66-4046-944a-52cd4f5c884c` 中「场景帧率」那条遗留结论**（该文当时判断为「降分辨率无效 → 主线程瓶颈」，并建议调 SSE / 换静态底图 / requestRenderMode）。实测证明这三条方向基本都是白费力气：瓶颈不在场景设计，在渲染它的那块 GPU。

## 1. 决定性证据：同一页面、同 589 条绘制命令、同分辨率，只换 GPU

| 运行方式 | WebGL 实际渲染器 | 帧率 | 帧时间 |
|---|---|---|---|
| 系统默认（Windows「节能」） | `ANGLE (AMD, AMD Radeon(TM) Graphics (0x0000164E) Direct3D11 …)` | **6.3 FPS** | 158.7 ms |
| 强制高性能独显 | `ANGLE (NVIDIA, NVIDIA GeForce RTX 4070 Laptop GPU (0x00002820) Direct3D11 …)` | **56.8 FPS** | 17.6 ms |

**9 倍差距**，唯一的自变量是 GPU。同一方法的其余采样：`commands=589`、`dpr=1` 两项完全一致。

硬件清单里其实是三个适配器：`GameViewer Virtual Display Adapter`（远控虚拟显示器）、`AMD Radeon(TM) Graphics`（集显）、`NVIDIA GeForce RTX 4070 Laptop GPU`。

## 2. 为什么用户看到「GPU 占用 0%」

- 实时采样 Chrome GPU 进程 3 秒，按 LUID 分引擎统计：`eng=3d` 在 AMD 的 LUID 上平均 **73.6%**，NVIDIA 的 LUID 上 **0.0%**。活全在集显上。
- 任务管理器的「GPU 占用」是各引擎**忙碌时间占比**，不是算力占用；混合显卡机器上不按适配器实例+3D 引擎展开看，必然误判（用户看的多半是 NVIDIA 那一栏）。
- 附带坑：窗口最小化或被遮挡时 Chrome 会节流渲染，GPU 也会掉到 0%。

根因线索在注册表 `HKCU\Software\Microsoft\DirectX\UserGpuPreferences`：用户给一大堆游戏写过 `GpuPreference=2;`（独显），**唯独没有 chrome.exe**，于是 Windows 按「节能」把浏览器丢给了集显。

## 3. 场景侧调参为什么全部无效（实测归因）

静置 45 s 等瓦片流式收敛后的稳态：**6 FPS / 166.7 ms 每帧**，而主线程每秒只被占用 **78.6 ms**（JS 44.7 + 布局 3.7 + 样式 4.8）——主线程才忙 8%。

| 实验 | 结果 |
|---|---|
| 基线稳态 | **6 FPS / 166.7 ms·帧** |
| 隐藏 2 个 3D Tiles | 15.5 FPS |
| 隐藏地球（对照上限） | 30.3 FPS |
| 隐藏整个三维画布 | 125 FPS（页面本身没问题） |
| 分辨率 0.5× | 11 FPS（+83%，远小于像素数降幅） |
| 关 bloom / 关 fxaa / 关 HDR / 关地表大气 / 关天空盒 / 关腾讯影像层 / SSE 16→32 / cull 恢复默认 + 内存预算 2048→512MB / 开 `requestRenderMode` | **全部在 ±0.7 FPS 内** |

绘制命令数很反常：376 个瓦片只提交 54 条命令，而 **7 个瓦片提交 475 条**——说明「外滩 + 流光特效」那套模型是逐要素/逐实例绘制，这才是场景侧的大头（换独显后属锦上添花，数据量上来再处理）。

## 4. 顺带纠正一个死代码判断

前一轮曾断言「项目的后处理栈很重（bloom + HDR + FXAA + brightness）」，**不成立**：
`setScene()` 定义在 `Translation/src/cesiumTools/sceneManager.js:52`，但只在 `Translation/src/views/cesiumView.vue:8` 被 import，**全项目没有任何调用点** —— 那段后处理配置是死代码。
运行时读数印证：`hdr:false / fxaa:false / brightness:null / postProcessCount:0 / resolutionScale:1`（`resolutionScale = devicePixelRatio` 那行同样没生效）。
教训：这类「读代码猜」必须用运行时读数验证。

## 5. 改法（设置层，不改一行代码，都可逆）

1. **Windows 设置（推荐，永久）**：设置 → 系统 → 屏幕 → 显示卡 → 添加桌面应用 → 选 `C:\Program Files\Google\Chrome\Application\chrome.exe` → 选项 → **高性能** → 重启 Chrome。它写的正是机器上已有游戏在用的 `HKCU\Software\Microsoft\DirectX\UserGpuPreferences` → `GpuPreference=2;`（用户级、无需提权）。
2. **NVIDIA 控制面板**：管理 3D 设置 → 程序设置 → 添加 Chrome → 「高性能 NVIDIA 处理器」。
3. **临时验证**：`chrome.exe --force_high_performance_gpu`。上面那组 56.8 FPS 就是这么测出来的，**已实测有效**（Chromium 开关，非官方文档承诺，但可复现）。

代价：会让**整个 Chrome**（所有标签页）走独显，耗电与发热上升，笔记本离电时建议改回「让 Windows 决定」。若也在 DSH 内置浏览器里看项目，同理给 `DSH Desktop.exe` 加这条。

## 6. 30 秒验证

1. `chrome://gpu` 看 **GL_RENDERER** 是否变成 `NVIDIA GeForce RTX 4070...`。
2. 页面上执行：
```js
(() => { const c=document.createElement('canvas'); const gl=c.getContext('webgl2')||c.getContext('webgl');
const d=gl.getExtension('WEBGL_debug_renderer_info'); return d ? gl.getParameter(d.UNMASKED_RENDERER_WEBGL) : 'n/a'; })()
```
3. 项目自带 HUD：`sceneManager.js` 里开了 `debugShowFramesPerSecond = true`（左上角读数），应从个位数跳到 50+。

## 7. 未验证 / 未做

- `scene.msaaSamples = 1`（官方默认 4）**未测**，收益未知。
- 用户**尚未确认是否已应用**上述显卡偏好设置（会话在「要不要我帮你写注册表那一条」处结束）。
- 腾讯影像层 `//rt{s}.map.gtimg.com/tile?...styleid=4` 整层 400 的问题依旧存在（底图实际靠 ArcGIS 那层撑着）。
- `requestRenderMode` 开了没变化：推断是该场景每帧都在变（流光/水体挂在 `postRender`、两层在线影像持续拉瓦片、瓦片仍在流式加载），要收敛掉「每帧都在变的东西」才可能见效——换独显后已不急。
- 590 条绘制命令的优化：可用 `tileset.debugShowRenderingStatistics = true` 定位，或改为分层显示两个 tileset。

## 8. 方法留档（临时脚本，非仓库文件）

`%TEMP%\perf-lab2/3/4.mjs`、`gpu-compare.mjs`：通过 CDP 连接本机真实 Chrome，注入 experiment 脚本逐项改场景属性并读帧率，用 `Performance` 域取每秒主线程耗时，用 `WEBGL_debug_renderer_info` 读真实渲染器。这类一次性实验脚本用完即弃，方法本身可复用。
