---
id: "35e41148-3b28-4bb7-9efa-1e6779f4ef1c"
title: "GVHMR 手臂回弹/全局朝向翻转的定位与四元数修复 + 现成舞蹈动捕数据源选型（D:\\mocap\\gvhmr）"
description: "对 5b6b78e9 产出的 458 帧舞蹈数据做后处理：定位肘部回弹真因（大衣/长发/黑道具遮挡 + ViTPose 置信度被骗 + 逐帧独立猜深度），说明旋转向量线性滤波为何反而更糟、改用四元数连续化与单帧 slerp 修补；给出修复前后量化对比、HaMeR 能力边界（只到手腕以下）、以及现成舞蹈动捕数据源选型与\"先修 Chisa bind pose\"的前置顺序。"
status: "active"
created_at: "2026-10-17T04:24:20.186Z"
updated_at: "2026-10-17T04:24:20.186Z"
content_hash: "def03c9211d206d0727d686dfb92009d144186e49440a3f42e59b2deea4e977c"
source_paths:
  - "mocap/gvhmr/fix_arms.py"
  - "mocap/gvhmr/check_orient.py"
  - "mocap/gvhmr/compare_fix.py"
  - "mocap/gvhmr/outputs/dance/hmr4d_results.pt"
session_ids:
  - "f1d277ff-3cc9-4cce-afab-64da146888ab"
memory_body_ids:
  []
---

# GVHMR 手臂回弹修复与舞蹈数据源选型（2026-10-17）

上游：`5b6b78e9`（458 帧 hmr4d_results.pt 产出）、`c16da0c6`（Biped 重定向与噪声诊断）、`16979651`（可行性方案）。

## 1. 结论先行

- 手臂"回弹"不是重定向数学问题，也不是模型精度不够，而是**源视频里手臂被遮挡、2D 置信度被骗**导致的逐帧独立错猜。
- 修法是**在 SMPL-X 参数层**（旋转/四元数）定向修补跳变帧，不碰重定向代码。
- 若只是想拿到一段好看的舞蹈，**换数据源比继续修视频更划算**：AIST++ / DanceDB / FineDance 是 SMPL 格式，与 `hmr4d_results.pt` 同构，重定向代码写一次即可换源。

## 2. 回弹真因（已定位到帧）

抽帧核对：**142–156 帧**、**424–433 帧**角色披大衣、长发，且抱着大黑道具，前臂完全被挡。但 ViTPose 在这几帧给出 **0.80–0.88** 的 2D 置信度——它测到的是**披风边缘**。3D 肘部深度因此全靠猜，且**每帧独立猜**，导致肘角在 143° ↔ 60° 之间来回翻转。

判据：单帧测地角跳变 **52.8°/帧** ⇒ 瞬时角速度约 **1580 °/s**，物理上不可能。

## 3. 一个反直觉的坑：旋转向量不能直接线性滤波

第一版用"对 body_pose 轴角做时间平滑"，结果**变差**：

| 指标 | raw | 线性平滑后 |
|---|---|---|
| `smpl_params_global` 帧间变化 mean / max | 27.52 / 171.5 | **44.44 / 176.2** |
| `smpl_params_global` >60° 帧数 / >90° 帧数 | 44 / 2 | **77 / 34** |
| `smpl_params_incam` >90° 帧数 | 2 | **14** |

原因：**旋转向量跨 ±180° 时数值不连续**（171° 与 −171° 只差 18° 的角度，数值上却像跳了 342°），线性滤波会跨奇点插值，人为制造翻转。**必须转四元数做连续化（slerp / hemisphere 对齐）后再滤波。** 这条对任何"轴角平滑"都成立，属通用教训。

## 4. 最终修复方案（`D:\mocap\gvhmr\fix_arms.py`）

1. 轴角 → 四元数，做 hemisphere 对齐消除 q/−q 二义性，再时间滤波，最后回轴角写回。
2. **只改跳变帧**：对测地角速度超阈值的帧做局部修补，其余帧不动，避免抹掉真实动作。
3. **`global_orient` 单帧翻转单独处理**：170–171 帧各有一个 **171°** 瞬时翻转（表现为整个身体突然掉头），用四元数 slerp 在相邻帧间补回。
4. 校验脚本 `D:\mocap\gvhmr\check_orient.py`（统计 mean/max/>60°/>90° 帧数、worst frames、transl 范围、路径长度）；对照图脚本 `D:\mocap\gvhmr\compare_fix.py` → `D:\mocap\gvhmr\outputs\dance\compare_fix.png`。

### 修复效果

| 关节 | 原始最大帧间跳变 | 修复后 | >20° 跳变帧数 |
|---|---|---|---|
| L_Elbow | 52.8° | **17.1°** | 12 → **0** |
| R_Elbow | 35.8° | **18.9°** | 16 → **0** |
| L_Shoulder | 17.5° | 9.2° | 0 → 0 |
| R_Wrist | 14.1° | 7.3° | 0 → 0 |

保真度：与原始数据角度相关系数 **0.992 / 0.987**，平均只改 **1.1°** —— 只削掉非物理抖动，真实动作保留。

### 产物与备份

- 修复版：`D:\mocap\gvhmr\outputs\dance\hmr4d_results.pt`
- 原始备份：`D:\mocap\gvhmr\outputs\dance\hmr4d_results_raw.pt`
- 渲染对照：`outputs\dance\1_incam.mp4`、`outputs\dance\dance_3_incam_global_horiz.mp4`
- 数据体检（修复后仍成立）：transl 范围 X 0–0.22 / Y 1.24–1.51 / Z −0.01–0.28，路径长度 5.84 m。

## 5. HaMeR 的能力边界（别指望它治回弹）

HaMeR 输入手部裁剪图，输出 MANO 参数（手掌朝向 + 15 手指关节），**不输出 elbow / shoulder**，即**只管手腕以下**。

| 部位 | 骨骼 | HaMeR |
|---|---|---|
| 大臂 | L/R_Shoulder | ❌ |
| 小臂 | L/R_Elbow | ❌ |
| 手掌朝向 + 手指 | SMPL-X `hand_pose` | ✅ |

且当前 GVHMR 输出的 `hand_pose` 为**全零**，手指保持默认张开、完全不动。所以装 HaMeR 的收益只有"手指能动"，与回弹无关。

## 6. 现成舞蹈动捕数据源（换源省掉修视频）

关键判断：**Plask / Rokoko Vision / DeepMotion 这类"视频转动作"站点与 GVHMR 同属单目重建**，遮挡场景照样抖，换站点不换方法 = 同样结果。真正省事的是直接用成品动捕数据。

| 来源 | 内容 | 格式 | 费用 | 适配度 |
|---|---|---|---|---|
| [AIST++](https://google.github.io/aistplusplus_dataset/) | 1408 段专业舞蹈 + 音乐配对 | **SMPL** | 研究许可 | ★★★★★ 与现有管线同格式 |
| [Bandai Namco 动捕集](https://www.cgchannel.com/2022/05/download-3000-free-mocap-moves-from-bandai-namco-research/) | 3000+ 段含舞蹈 | BVH | 免费（非商用） | ★★★★★ 直接进 Blender |
| [Mixamo](https://www.mixamo.com/) / [HF 全量快照](https://huggingface.co/datasets/Linzhan/Mixamo-Animations-Characters) | 约 2317 段，舞蹈偏基础 | FBX | 免费 | ★★★★ 需先修 bind pose |
| [BowlRoll](https://bowlroll.net/) (MMD) | 上万段 K-pop/日系舞蹈，质量最高 | VMD | 免费（多需作者密码） | ★★★ 需 MMD Tools |
| [DanceDB](https://dancedb.cs.ucy.ac.cy/) / [FineDance](https://github.com/li-ronghui/FineDance) | 动捕级舞蹈 | SMPL | 研究许可 | ★★★★★ |
| [Rokoko Motion Library](https://www.rokoko.com/products/motion-library) | 100–150 段免费 | FBX | 免费 | ★★★★ |
| [Cinevva](https://app.cinevva.com/tools/animations) | 260 段 CC0，浏览器内重定向 | — | 免费 | ★★★★ |
| [MocapDancer](https://www.mocap-dancer.com/) | 600 独舞 + 120 双人 | — | 付费 | ★★★ |

**选 SMPL 那条线的理由**：与 `hmr4d_results.pt` 完全同构，重定向代码写一次、数据源随便换，不必为每段视频单独修一遍。

## 7. 必做的前置步骤：修 Chisa 的 bind pose

Chisa（`D:\Blender\assets\trainAndChisa.blend`，376 骨中仅 32 根身体骨）**rest pose 是屈膝坐姿**，这是所有重定向都会歪、Mixamo 自动绑定会直接失败的根因（详见 `c16da0c6`）。

正确顺序：

```
① 修 Chisa bind pose（Blender ~10 分钟）
      ↓
② 选数据源（AIST++ / BVH / VMD / Mixamo）
      ↓
③ 做一次通用重定向
      ↓
④ 以后换舞蹈 = 换文件重跑
```

## 8. 关于"还要不要更准"

单目 3D 在当前信息量下已近上限——被道具挡住的帧，任何模型都只能猜。可继续改进的三条路（性价比降序）：
1. 手部可见时用 HaMeR 补手指（只解决手指）；
2. **手动修关键帧**（业界对遮挡段的标准做法，优于全自动）；
3. 若目标是最终 Chisa 动画，**跳过 1:1 复刻**，直接在 Blender 里修滑出的骨骼——要的是好看的舞蹈，不是原片复刻。
