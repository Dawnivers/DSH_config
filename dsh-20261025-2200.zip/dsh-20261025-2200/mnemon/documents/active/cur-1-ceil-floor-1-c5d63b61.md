---
id: "c5d63b61-caf7-4516-b11e-7758e9425f5a"
title: "发展历程生长动画 cur 逐帧计算参考：1 号线实测「站点→坐标」映射与每里程碑切片结果（含 ceil/floor+1 语义、边界与拆除顺序）"
description: "2026-10-12 智慧地铁 Translation 对 historyPanel.vue 逐帧变量 cur 的工作例级说明：Cesium.Cartesian3[] 语义、与 Cesium 渲染循环通过 CallbackProperty 解耦、为何用普通 let、五步计算（时间→段号→站点空间插值→坐标空间插值→ceil/floor+1→slice）、1 号线真实映射表与 7 条里程碑的 cur.length（54/155/196/196/196/278/337，非线性）、至少 2 点的边界兜底、先摘实体再清 geom 的顺序要求；本文是「生长动画本体」的数值补充，不重复其结论。"
status: "active"
created_at: "2026-10-12T11:42:22.013Z"
updated_at: "2026-10-12T11:42:22.013Z"
content_hash: "0cb85999ecc686ab89fe4d70ef2933e55d8f0d261e1ad5ee0f15ff4158a8ace0"
source_paths:
  - "Translation/src/components/bottom/HistoryPanel/historyPanel.vue"
  - "Translation/src/config/shmetroHistory.js"
  - "Translation/src/cesiumTools/lineAndpoints/line/setlines.js"
session_ids:
  - "e52a4aa3-4522-42fa-b1f8-460a0614aedd"
memory_body_ids:
  []
---

# `cur` 逐帧计算参考（1 号线实测）

日期：2026-10-12。项目：`D:\WebGIS\web三维开发\智慧地铁项目\Translation`。
文件：[historyPanel.vue](../../Translation/src/components/bottom/HistoryPanel/historyPanel.vue)（约 700 行，`cur` 在 L145 声明）。

## 0. 与既有文档的关系

- 生长动画本体、range 区间插值、站点→坐标映射、端点夹取、4 号线环线、3 个真 bug：
  `bed0b7b7-e1e3-491b-80bd-51ffa66f4956` —— 本文只补它没有的**数值工作例**，不重复其结论。
- 固定入场视角 `ENTRY_VIEW`：`409be846-4517-43eb-9e36-134353f682bc`。
- 连续进度条、`flowLength: 0` 关流线、临时探针技巧：`0fc7e703-b0e7-4610-999f-c040d0d0bab8`。

## 1. `cur` 是什么

```js
/** 每帧被 CallbackProperty 读走的「已开通那一段」顶点 */
let cur = [];
```

| | |
|---|---|
| 类型 | `Cesium.Cartesian3[]`（**不是**扁平经纬度数组，是已转好的世界坐标点） |
| 语义 | 当前帧该线**已建成那一段**的顶点 |
| 生命周期 | 一帧；每帧整个换掉，从不原地修改 |
| 写 | 自己的 raf 循环（`applyFrame()`，L225） |
| 读 | Cesium 渲染循环，经 `CallbackProperty(() => cur, false)` 的 getter |

两端**完全解耦**，只通过一个变量名相遇：raf 停了没人写，Cesium 仍每帧读到同一个 `cur`（线静止）；
帧率掉到 5 FPS 时两边都慢，但进度按 `deltaTime` 推进（L247），**动画总时长不变**。

getter 闭包捕获的是**变量绑定**而非当时的值，所以 `cur = xxx` 重新赋值后下一帧自然生效。
写成 `() => cur.slice()`（每帧多余拷贝）或 `const snapshot = cur; () => snapshot`（永远读到最初的空数组）就废了。

## 2. 为什么是普通 `let` 而不是 `ref`

1. **不需要**：只被逐帧回调读，不参与模板渲染；
2. **不能**：`ref` 会把数组及其中每个 `Cartesian3` 包成 `Proxy`，而 Cesium 大量按**引用**比较并写 typed array —— 项目里已踩过同类坑（`entities.remove()` 按引用查找被 Proxy 破坏、静默返回 `false`）。

`geom`、`growthEntity` 同理。相反 `playing` **必须**是 `ref`（播放键高亮要驱动模板），这是对照组。

## 3. 五步算出一帧的 `cur`（1 号线真实数据）

**① 时间 → 段号 + 段内进度**（10 单位 = 一个里程碑）

```js
const seg = t / UNIT;                       // UNIT = 10
const i = clamp(floor(seg), 0, N - 2);
const f = seg - i;
```

**② 相邻里程碑 `range` 之间插值（站点空间、浮点）** —— `stationRangeAt()` L211。
以 1993-05 `[21,25]` → 1995-04 `[13,25]`、`f = 0.5` 为例：
`loS = 21 + (13-21)×0.5 = 17`，`hiS = 25 + (25-25)×0.5 = 25`。

**③ 站点空间 → 坐标空间（站内再插一次值）** —— `stationToCoord()` L200：
`coordOf(17) = 193.00`（一大会址·黄陂南路）、`coordOf(25) = 295.00`（锦江乐园）。
不插值只取整的话，线在跨站的一瞬间会「跳一格」。

**④ 取整：左 `ceil`、右 `floor + 1`** —— 只取完整落在区间内的顶点，`+1` 是 `slice` 右开语义的补偿。

```js
a = ceil(stationToCoord(loS));      // 193
b = floor(stationToCoord(hiS)) + 1; // 296
```

**⑤ 切片**：`cur = geom.cart.slice(a, b)` → 长度 103。
`geom.cart` 是建线时**一次性**转好的完整数组（L163），`slice` 只新建一个数组壳，里面的 `Cartesian3` **全部复用**（对照课程参考项目每帧 `fromDegreesArray`：11 号线 816 点、60fps 每秒新建近 5 万个对象）。

## 4. 1 号线实测映射表（站点下标 1 基 → 坐标下标）

337 个坐标点对 28 个站：

```
1.富锦路=1    2.友谊西路=23   3.宝安公路=38   4.共富新村=59   5.呼兰路=73
6.通河新村=76  7.共康路=78    8.彭浦新村=91   9.汶水路=100   10.上海马戏城=112
11.延长路=123 12.中山北路=132 13.上海火车站=141 14.汉中路=165  15.新闸路=170
16.人民广场=178 17.一大会址·黄陂南路=193 18.陕西南路=200 19.常熟路=203 20.衡山路=232
21.徐家汇=242 22.上海体育馆=247 23.漕宝路=253 24.上海南站=275 25.锦江乐园=295
26.莲花路=305 27.外环路=318   28.莘庄=333
```

两点一眼可见，也解释了两条修正为何缺一不可：

1. **密度不均匀**：富锦路→友谊西路跨 22 个坐标点，汉中路→新闸路只跨 5 个。直接拿站点下标当坐标下标，生长速度会忽快忽慢并站间跳格。
2. **端点不在折线端点上**：`map[1] = 1`（不是 0）、`map[28] = 333`（不是 336），折线两端各留余量（3 号线首点离上海南站 534m）。所以 `stationToCoord()` 首末站直接夹到折线首尾（L204-L205），否则画完只有 333 点，比全局线路的 337 少 4 个，切回首页看得出「接上一段」。

## 5. 每里程碑的 `cur.length` **不随时间线性增长**

| 里程碑 | `range` | `slice(a, b)` | `cur.length` |
|---|---|---|---|
| 1993-05 | `[21,25]` | `(242, 296)` | **54** |
| 1995-04 | `[13,25]` | `(141, 296)` | **155** |
| 1996-12 | `[13,28]` | `(141, 337)` | **196** |
| 1997-07 | `[13,28]` | `(141, 337)` | **196** ← 区间没变，只有文案翻 |
| 1999-12 | `[13,28]` | `(141, 337)` | **196** |
| 2004-12 | `[4,28]` | `(59, 337)` | **278** |
| 2007-12 | `[1,28]` | `(0, 337)` | **337** ← 与全局线路点数**完全一致** |

- 起点**不是 0**：1993 年那一帧是 `cart[242..295]`（徐家汇—锦江乐园），后面两次往两头扩。
- 1997-07 到 1999-12 **三帧 `cur` 一模一样** —— 「贯通」「上海南站开通」属于**中段补站**性质，线不长只翻文案。这正是当初否掉「方向开关」而改用 `range: [lo, hi]` 的直接证据。

## 6. 两个边界处理

**① 至少两个点**（L237-L239）：Cesium 折线少于两点会抛错。区间极窄、或 `ceil/floor` 把两端收成同一坐标点时会触发。

```js
if (b - a < 2) b = Math.min(geom.nPt, a + 2);
if (b - a < 2) a = Math.max(0, b - 2);
```

**② 空数组顺序**：`if (!geom) { cur = []; return; }` / `if (!r) { cur = []; return; }`。
平时到不了「Cesium 读到空数组」那一步，但**拆除顺序必须对**（L288 注释）：先 `viewer.entities.remove(growthEntity)` 再 `geom = null; cur = []`；反过来写的话实体还挂着 getter，下一帧就会拿到 `[]`。

## 7. 一个易忽略点：`cur` 替换掉了建线时的静态 positions

`renderLines()` 建出的实体，`polyline.positions` 原本是静态整条线的 `ConstantProperty`，随即被 `new Cesium.CallbackProperty(() => cur, false)` 顶掉 —— **那份静态几何建完即弃**。
给 `renderLines` 传整条线只是为了放行它的 `positions.length < 4` 守卫（`setlines.js:16`），不能拿「只有起点两个数」去建。

第二个参数 `isConstant = false` 是整段动画的总开关：写成 `true` 或省掉，Cesium 就按一次性三角化缓存，线永远是满的。

## 8. 链路总括

```
line.positions（扁平经纬度 337×2）
      │ 建线时一次
      ▼
geom.cart（Cartesian3[337]） ─────┐
      │ slice(a, b)               │ 对象复用，不新建
      ▼                           │
cur（Cartesian3[54…337]）◄────────┘ 每帧只换数组壳
      │ () => cur
      ▼
CallbackProperty(isConstant = false) 每帧 getValue
      ▼
Cesium 重建该 polyline 顶点缓冲 → 线从已建成的一端长出去
```

## 9. 维护提醒

`range` 是**库内 `stationList` 排序后的 1 基下标**，后端站点数据一变就整体错位；
`Translation/scripts/gen-metro-history-ranges.mjs --check` 可随时校验。
