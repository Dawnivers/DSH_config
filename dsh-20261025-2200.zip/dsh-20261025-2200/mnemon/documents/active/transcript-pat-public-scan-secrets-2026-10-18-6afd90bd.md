---
id: "6afd90bd-37d7-4f8c-bbf9-0c641ffc0bf2"
title: "备份包会带走会话 transcript：一次活的 PAT 被推上 public 仓库后的处置与 scan-secrets 活体检疫闸（2026-10-18 实测）"
description: "DSH 周备份首推成功后扫包发现会话 session.v4.jsonl.zstd 内含当天对话里贴入的 Fine-grained PAT 且仍可用，据此从 main 强制下架 zip、并把 scan-secrets.py 活体检疫接进 publish-dsh.ps1 的完整处置记录：zstd 分帧解压手法（Node zlib 不可用，需 Python zstandard）、exit 码语义、死串放行策略与仍待用户撤销旧 token 的收尾状态。"
status: "active"
created_at: "2026-10-18T02:57:14.877Z"
updated_at: "2026-10-18T02:57:14.877Z"
content_hash: "9e9fd30eecfd7bc5a7e382227addddfae579f291489a32343cc9a3c0594573e6"
source_paths:
  - "dsh-migration/publish-dsh.ps1"
  - "dsh-migration/scan-secrets.py"
  - "dsh-migration/RESTORE.md"
session_ids:
  - "4b61478a-1ae8-4167-a5a0-a1613c3a831f"
memory_body_ids:
  []
---

# 备份包会带走会话 transcript：活 PAT 上 public 仓库的处置与「活体检疫」闸

日期：2026-10-18（Windows，用户 `林先语`，DSH Desktop 2.0.17）

承接文档：
- `284e4a5f-9725-4a26-bd8c-7ad334658199`（周备份到 GitHub：单提交 force push、代理探测、定时卡）
- `07e71f80-40ef-4238-99b3-8ad8d4d37bc0`（整机迁移三件套与四个坑）

## 0. 核心结论

**备份包 = home 全量 + `sessions/` 原始 transcript。凡是用户在对话里直接粘贴过的明文密钥，早已落进 `.zstd` 会话文件，打包时必然一起上传。** 因此「排除 `.credentials.yaml` / `.env`」这种按文件名的硬闸不足以保护仓库——真正的门必须做**内容级、且判断密钥是否仍然有效**的扫描。这次事件中，一把当天贴进对话的 Fine-grained PAT 被推上 public 仓库 `Dawnivers/DSH_config`，存活检测为 `alive: true`。

## 1. 事件链（全部有工具输出佐证）

1. 首推成功：`dsh-20261018-1041.zip`（68.82 MB）上 main，远端 sha256 与本地 `Get-FileHash` 完全一致，耗时 498.8 s。
2. 验收时顺手扫包，发现包里 212 个会话文件之一——本会话的 `session-830cdffb-…/session.v4.jsonl.zstd`——命中 5 处，样本含 `github_pat_...` 前缀（用户当轮把 token 贴进对话要求代为写入文件）。
3. 对已推送快照（从 zip 内提取的同一文件）复扫：同样 5 hits，证明泄漏确实随包上传，而非仅存在于本机。
4. 强制下架：`git push --force … HEAD:refs/heads/main`，`e151e23...4dd93de HEAD -> main (forced update)`；随后 `main` 上只剩 `LATEST.json`（0.10 KB）与 `README.md`（0.70 KB），zip 已不在分支上。本地 zip 保留（未推上去时它是唯一副本）。
5. 新增 `dsh-migration/scan-secrets.py` 并接进 `publish-dsh.ps1`：对含活密钥的包 **exit=2** 中止发布，已撤销的死串只警告、**exit=0** 放行。
6. 自测：对含活 PAT 的包 `{"result":"live-secret","liveCount":1,…}` `exit=2`；处理干净后 `exit=0`。

## 2. 技术要点：dsh 会话文件怎么扫

- 文件形态：`~/.dsh/sessions/<workspace>/<session-id>/session.v4.jsonl.zstd`，**分帧压缩**（本次样本 485926 B 压缩 / 约 336 个 zstd 帧魔数；解压后正文约 1.57 M 字符）。只解第一帧会得到 242 字节的假象，得到「hits 0」的错误结论——这是本次最容易踩的坑。
- Node 24.16.0 的 `node:zlib` **不能**直接解这些帧（自写 zscan 走 `require` 亦在 ESM 下报 `require is not defined`）；本机已装 **Python `zstandard 0.25.0`**（`D:\python\lib\site-packages\zstandard`），用它将整个流帧帧解出后按正则扫。
- PowerShell 侧坑：`Set-Content -Encoding Byte` 在 pwsh 7 报 `'Byte' is not a supported encoding name`，取二进制要用 `[IO.File]::WriteAllBytes()`。
- 扫描对象要覆盖两处：本机 `sessions/` **以及**已推送到远端的 zip 内同一成员（用 `tar -xOf` 取成员），否则无法区分「本机有」与「已经外泄」。

## 3. 闸门设计取舍

| 决策 | 理由 |
|---|---|
| 只对候选串做**活体**检测，不做纯模式拦截 | 纯模式会让历史死串永久阻断备份，用户撤销后备份应当自动恢复 |
| 活密钥 → `exit=2` 硬中止，死串 → 警告放行 | 中止是给「还没修」的信号；已废的字符串留在旧本地包里无害 |
| 扫描放在组装提交之后、`git push` 之前 | 此时包已成型，扫的就是将要上传的那一份字节 |
| 下架用 force push 改写历史，而非 revert | 单提交 + 常量化历史的仓库结构下，revert 会把 69 MB 留在历史里 |

## 4. 处置规范（下次同类事故照做）

1. **撤销**泄露的凭据（Delete，不是降权），不要指望「下架 zip」了事。
2. 从分支上 force push 下架产物；承认旧提交对象在 GitHub 侧可能仍可访问直到 GC，公开过的即视为已泄露。
3. 补内容级扫描闸，并把「有活密钥」设为不可跳过的中止条件。
4. 之后的密钥一律**直接写文件**：`%USERPROFILE%\.dsh-config-publish\token`（目录 ACL 仅本人可读，内含 `README.txt` 创建步骤：Repository access 选 `Dawnivers/DSH_config`，Permissions 仅 **Contents: Read and write**）。**不要再贴进对话**——会话 transcript 会被打进每一个后续备份包。
5. 用户已知会保留的两份残留：本地 288 MB 完整包与 68.82 MB 已下架 zip 内仍有该字符串，撤销后即为废串，无需处理。

## 5. 收尾状态 / 遗留

- 任务卡 `ead69e05-d364-4703-bce7-90dda8467e4e`（cron `0 22 * * 0`）描述已改写为事故现状：**待用户撤销旧 PAT、新建一把并直接写入 token 文件**；在此之前定时执行会撞上疫情闸而失败（失败记录留在卡上，不损坏任何东西）。
- 仓库仍为 **public**（用户明确选择）：包内 `MEMORY.md` / `USER.md` 与 212 个会话对所有人可见，这是长期暴露面，不只是密钥问题。
- 直连 GitHub 必 `Connection was reset`，仍须走代理（脚本自动探测 `127.0.0.1:7897`）；69 MB 上行约 8 分钟。

## 6. 源文件

- `dsh-migration/publish-dsh.ps1`（闸门接入点）
- `dsh-migration/scan-secrets.py`（内容级活体扫描）
- `dsh-migration/RESTORE.md`（人工验收清单，已补远端备份与泄密处置章节）
- 临时探针（非交付物，可删）：`dsh-migration/_scan-token.py`、`_scan-token.cjs`
