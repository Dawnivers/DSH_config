---
id: "0ce9c65f-6c6b-48c8-872b-d98bc80502a1"
title: "Translation 站点拥挤度热力图最终形态：视口 LOD + 三段式半径（近处地面尺度、远处屏幕像素、两端封顶）"
description: "2026-10-18 收尾版：把「半径按地面米数固定 → 拉近只是放大图」改为视口 LOD（moveEnd 220ms 防抖按视野重画贴图）+ 三段式半径 clamp(250m÷屏幕每像素米数, 16px, 64px)；含 heatmap.js-fixed 两个库坑、画布按地面长宽比、颜色标尺取全量数据、两次反例与实测换算表。"
status: "active"
created_at: "2026-10-18T11:32:55.861Z"
updated_at: "2026-10-18T11:32:55.861Z"
content_hash: "79a56524703e7007a525d33dd72f986b934a8b360cd766913ce66d8236187199"
source_paths:
  - "Translation/src/components/bottom/StationPanel/QueryModePanel/heatmap/cesiumHeatMap.js"
  - "Translation/src/components/bottom/StationPanel/QueryModePanel/heatmap/heatSource.js"
  - "Translation/src/components/bottom/StationPanel/QueryModePanel/heatmap/useHeatmap.js"
  - "Translation/src/components/bottom/StationPanel/QueryModePanel/QueryModePanel.vue"
  - "Translation/src/components/bottom/StationPanel/StationPanel.vue"
session_ids:
  - "2c6179c5-98fc-4d7a-af98-940176c67c8b"
memory_body_ids:
  []
---

# 站点拥挤度热力图：最终形态（视口 LOD + 三段式半径）

日期：2026-10-18。主文件 `Translation/src/components/bottom/StationPanel/QueryModePanel/heatmap/cesiumHeatMap.js`（约 400 行）。
前置：`eeba367f-a6db-44b9-a14c-a185f6d329bd`（四步流水线原理、bbox 决定清晰度、`SingleTileImageryProvider` 快照语义）、`49c36e87-8cf9-4863-bf43-4722e3abb524`（「近地满屏红」根因＝半径随视高插值，改为固定地面米数）、`3a0ce399-303d-4a00-95ef-e3c3d0db18af`（StationPanel 挂载）。
**本文覆盖 49c36e87 的两处结论**：① 固定地面米数半径已被否决（见 §3）；② 49c36e87 §5 遗留的「近距离模糊 LOD」已落地（见 §2）。

## 1. 目录与挂载

```
components/bottom/StationPanel/QueryModePanel/
├─ QueryModePanel.vue     外壳：站点拥挤度 / 路径规划 / 站控措施 三个模式按钮
├─ heatmap/               heatSource.js（纯数据）、cesiumHeatMap.js（引擎）、useHeatmap.js（生命周期）
├─ guideload/             路径规划（空占位）
└─ stationcontrol/        站控措施（空占位，空目录靠 .gitkeep 保命）
```
挂在 `StationPanel.vue:419`，引入路径 `./QueryModePanel/QueryModePanel.vue`。

## 2. 机制总览：视口 LOD

热力图仍是「heatmap.js 画离屏 canvas → `getDataURL()` → `SingleTileImageryProvider` 贴一个矩形（影像层，不是实体）」，但**矩形与画布尺寸每次按当前视野重算**：

1. `camera.moveEnd` → **220ms 防抖**（`UPDATE_DELAY`）→ `camera.computeViewRectangle()` 取真实视野矩形（含俯仰，不靠 fov 估算）。
2. 视野外扩 `VIEW_PAD = 1.18`，再裁到数据 bbox；视野里一个站点都没有就直接撤层，省一次 PNG 编码。
3. `canvasSizeFor(rect)`：按**地面**长宽比分配画布——`aspect = (Δlng×cos(midLat)) / Δlat`，面积预算 `CANVAS_AREA = 1e6` 像素，单边 `CANVAS_MAX_SIDE = 1400`，下限 128。
4. 只投影视野内（含一个半径余量）的点，其余丢弃。
5. 半径换算：`CANVAS 每像素地面米数` ÷ `屏幕每像素地面米数`，把屏幕半径折成本次画布像素半径。
6. `setData` → `getDataURL()` → 用等于视野的矩形换上一层新影像层。

要点：画布长宽比必须按地面长宽比，直接甩度数比会让热团横向压扁约 1.17 倍（上海 cos(31°)≈0.857）。
颜色标尺 `max/min` 必须取**全量**数据，不随视野变；否则缩放时整体变色，看起来像数据变了。
异步重绘（停稳后才跑）的错误不会冒泡到 mount 的 try/catch，必须通过 `onError` 回调落回面板红字，否则只能「热力图突然消失」。

## 3. 半径：三段式（当前最终版）

```
屏幕半径 = clamp( RADIUS_GROUND_NEAR ÷ 屏幕每像素地面米数 , RADIUS_SCREEN_MIN , RADIUS_SCREEN_MAX )
```

| 常量 | 值 | 作用 |
|---|---|---|
| `RADIUS_GROUND_NEAR` | 250 m | 近处物理影响半径，决定圈多大 |
| `RADIUS_SCREEN_MIN` | 16 px | 远处屏幕半径下限，决定聚合程度 |
| `RADIUS_SCREEN_MAX` | 64 px | 近处屏幕上限，防糊满屏 |
| `MIN_RADIUS_PX` | 2.5 px | 兜底，避免视野极大时热点彻底消失 |
| `maxOpacity` | 0.8 | 热点中心最大不透明度，压到 0.6 可让底图透出来 |

效果（1920 宽、fov 60° 折算）：

| 视高 | 屏幕半径 | 地面半径 | 相对最初 16px |
|---|---|---|---|
| 0.2–5 km | 64 px | 8–192 m | 4.0× |
| 7 km | 59 px | 250 m | 3.7× |
| 10 km | 42 px | 250 m | 2.6× |
| 20 km | 21 px | 250 m | 1.3× |
| 40 km | 16 px | 385 m | 1.0× |
| 80 km | 16 px | 770 m | 1.0× |
| 150 km | 16 px | 1443 m | 1.0× |

语义：**拉远＝同样 16px 覆盖更大地面 → 相邻站热团重叠 → 自然聚合；拉近＝圈按 250m 地面尺度张开（最多 64px）→ 不再是个小点，但不会糊满屏。**

## 4. 三个反例，别再改回去

1. **半径按地面米数固定**（`RADIUS_METERS = 1000 → 13.7px`，49c36e87 的方案）：图与相机无关，拉近只是把同一张图放大，钻到热点内部就满屏红，且永远不会聚合。
2. **半径随相机高度插值**（参考项目 `nearHeight 500 / farHeight 60000 / min 9 / max 46`）：500m 视高 46px、20km 只剩 17.5px，热区 ∝ 半径²，同一份数据贴地就红 6.9 倍——拥挤度变成「取决于相机」的量。
3. **恒定 16 屏幕像素**（前一版）：聚合正确，但贴地看每团只有 32px 直径，用户反馈「圈太小」→ 才有了 §3 的近处地面尺度 + 64px 封顶。

## 5. 两个库坑（heatmap.js-fixed@2.0.2）

1. 包 `package.json` 的 `main` 写着 `heatmap.min.js`，但包里没有这个文件（产物在 `build/`），`import 'heatmap.js-fixed'` 必报 Failed to resolve → 必须 `import 'heatmap.js-fixed/build/heatmap.js'`。
2. **不能用压缩版 `build/heatmap.min.js`**：其 `_colorize` 里 `k.data = l` 直接给 `ImageData.data` 赋值，ESM 严格模式抛 `TypeError: Cannot assign to read only property 'data' of object '#<ImageData>'`。正确入口是未压缩的 `build/heatmap.js`。

## 6. 数据侧事实

- 18 条线 `stationList` 共 **510 条**，按站名去重 **400 站**（89 换乘站）。
- `peopleFlow` 来自后端 `index.js:15`：换乘站 300~999、普通站 50~299；直接当热力值。面板实测显示 `400 站 · 客流 50–990`。
- bbox 由站点现算：`120.947 / 30.898 – 121.937 / 31.422`（0.99° × 0.524°），约 94.3km × 58.3km；按 CANVAS_AREA 出图约 1293×800（≈73 m/px，这是最初整城贴图的分辨率）。
- `destroy()` 在切模式与组件卸载时调用（`useHeatmap` 内注册 `onBeforeUnmount`），实测切走后离屏 canvas 消失。

## 7. 验证与遗留

✅ 编译通过；热力层正常挂载（`400 站 · 客流 50–990`）。
✅ 触发真实 `moveEnd`（点「上海火车站」飞到 2200m）后：面板无报错、离屏 canvas 仍在 → 异步重绘链路跑通。
❌ 视觉未截图取证：桌面连续返回 `USER_CONTROL`（用户占用桌面），需人工拖远拉近目视确认手感。
遗留：每次停稳要重编码一张约 100 万像素 PNG，所以拖动过程不重画、换层瞬间可能有一帧空白。若日后要的不是「光晕重叠式聚合」而是真聚类（按距离把相邻站合并成代表点、值取平均或求和），那是另写的网格聚合算法。
