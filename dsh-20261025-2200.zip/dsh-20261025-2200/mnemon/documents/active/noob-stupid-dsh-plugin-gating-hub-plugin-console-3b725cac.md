---
id: "3b725cac-20bd-4a06-b1d1-eae5d2348c6b"
title: "Noob-stupid/dsh-plugin-gating-hub（Plugin Console）调研：定位、机制与本机适配风险"
description: "社区插件 dsh-plugin-gating-hub（npm @noob-stupid/dsh-plugin-console，旧名 dsh-plugin-hub）的定位与核心机制（升级契约预检、回滚点/自动回滚、semver 门控、适配闸门、确证式自动禁用、多源市场与安装通道），及其与本机 DSH Desktop 外壳补丁的潜在冲突；截至 2026-10-10 本机未安装，仅被社区索引收录。"
status: "active"
created_at: "2026-10-10T03:22:29.850Z"
updated_at: "2026-10-10T03:22:29.850Z"
content_hash: "cb802a208ef022dad0bd28e98a5f54ec8a4ae0b150d4cca82e65d5c1da02577c"
source_paths:
  []
session_ids:
  - "ef2e5a17-99d2-471f-a59f-9c8d36ddb5ae"
memory_body_ids:
  []
---

# dsh-plugin-gating-hub（Plugin Console）调研

来源：https://github.com/Noob-stupid/dsh-plugin-gating-hub （README，HTTP 200；GitHub 页面正文被截断，以下以 README 摘要与仓库元数据为准）
npm 包名 `@noob-stupid/dsh-plugin-console`；旧名 `dsh-plugin-hub`（旧仓库链接会重定向）。非官方社区项目，MIT，约 99★ / 647 commits / 8 forks，支持 Web 与 Desktop 形态。
入口挂在官方插件管理页自身的插槽 `plugins.bundle.config`（非 DOM 注入），装后位置：设置 → 插件 → Plugin Console。

## 1. 核心能力 A：框架升级安全 / 插件门控

| 机制 | 说明 |
|---|---|
| 契约预检 | 升级前跑数据驱动的 contract pre-check：消息契约 / 依赖 API / 配置 schema / 被删 API / loader 契约；规则库 `lib/contracts/rules.json`（接受 PR） |
| 回滚点 | 升级前备份配置 + 整棵 profile 树快照；安装失败或重启失败自动整树回滚，另有常驻「回滚上一版」按钮 |
| 版本门控 | 内置零依赖 semver，按 `dsh.engines.framework` / `engines.dsh` / `@deepseek-ai/*` peer 范围判断插件能否在该宿主运行；不合规拒绝安装而非装上后崩 |
| 适配闸门 | 新框架加载不了的插件被强制禁用（服务端对 `/toggle` 返回 409）；须经「检测更新 → 更新并适配」验证后解锁 |
| 环境指纹 | 即使框架由官方桌面更新器或手敲 pnpm 改动，也能指纹识别并自动跑只读预检 |
| 自动禁用策略 | **仅确证证据**才自动写 `disabled: true`（包在所有解析基上都找不到 / `file://` 目标消失 / 启动失败日志点名）；`@deepseek-ai/*` 与核心保护行永不自动禁用；每次自动禁用留一键恢复记录 |
| 假成功检测 | 版本复核 + 15 分钟硬超时 + 卡死检测；不自动授权 install scripts，也不绕过 pnpm 的供应链闸门 |

## 2. 核心能力 B：多源插件市场 / 发现层

- 静态索引 `marketplace/index.json`（jsDelivr CDN + 10 分钟宿主缓存）：500+ 个 `dsh-plugin` 主题仓库按星排序 + 最多 300 个技能，**零 GitHub API 调用**；仅搜索走实时通道。
- 源可切换：GitHub / Gitee（改为直填 `owner/repo`）/ 自定义搜索源（URL 模板 + header 鉴权），`⊞` 可并行合并多源。
- 技能 Tab：git clone 安装到 `~/.dsh/skills/<name>/`，需 profile 启用 `@deepseek-ai/dsh-skill-filesystem`。
- 安装通道按包形态自动选择：有 npm 包 → pnpm / curl tarball（版本号写回 manifest）；无 npm 包 → Release 资产 / git clone / archive 降级，实体化到 `~/.dsh/plugin-src/` 并写为 `link:`。
- `link:` 通道额外做开发态挂载：把 profile 中缺失的 `@deepseek-ai/*` peer 以 link 指向 profile 的 node_modules，保证 Cordis service 与 LLM 错误类与宿主**模块同一性**共享。
- 另含 AI Empower（本地 AI 起草部署计划，需显式勾选成本同意才执行）与服务器组件浮动卡（启停 / 状态 / 打开 Web UI）。

## 3. 安装与版本要求

```powershell
dsh plugin --profile web add @noob-stupid/dsh-plugin-console   # npm 预构建，推荐
# 或从源码：
dsh plugin --profile web add github:Noob-stupid/dsh-plugin-gating-hub
```

要求 DSH ≥ `0.1.0-rc.6`（web profile，带 `dsh-client-modules` / `dsh-host-plugin-inventory`）；README 实测兼容矩阵为框架 ≥ `0.1.5-rc.2`。老框架上退化为「旧 Plugins 页 + 全功能」，不会白屏。

## 4. 与本机（DSH Desktop）环境相关的判断

- **截至 2026-10-10 本机未安装**。仅在 `@linxin666/dsh-client-ui-community-plugins` 的社区索引 `community.json`（desktop 与 web 两个 profile，第 126 行附近）中被收录，条目仍为旧名 `dsh-plugin-hub` 与旧 repo 地址；索引收录 ≠ 已安装。
- 潜在冲突一：本机 DSH Desktop 外壳（`electron-runtime-*.js` + `preload.cjs` + `dsh-builtin-browser-shell.js`）是**本地打过补丁的**，而该插件的「框架一键升级 / 自动重启」主要接管 `@deepseek-ai/*` 框架与 profile 树版本，**大概率覆盖不到 Electron 外壳内的 app 资源改动**，升级覆盖风险仍在。缓解点：检测到 desktop-host 形态时，非手动设置的 managed 模式会自动退回 Observer（只看不接管）。
- 潜在冲突二：其版本/peer 门控逻辑与本机已知约束一致——link: 插件必须把 `@deepseek-ai/*` 列入自身 peerDependencies 才能被路由。
- 未验证项：`lib/contracts/rules.json` 的规则覆盖面、升级/回滚链路是否触碰外壳补丁，均未读源码核实。

## 5. 关联文档

- `ef9c5437-40a6-4953-a697-f6b47b8d934b`（ARS 插件安装实录）：同为第三方插件安装/回滚实践，含 profile 备份路径模式。
- `502b4a5c-16a2-4ea4-953c-b861592308b7`（dsh-browser 安装实录）：desktop profile 插件只能由外壳管理、pnpm 版本 shim 等本机约束。
- `4b7d494f-5c4b-4c71-8ea5-80f19359a2cb`（DSH 代码索引方案选型）：其中已论证 DSH 官方无插件市场、社区市场与社区清单现状，可与此插件的多源市场定位互参。
