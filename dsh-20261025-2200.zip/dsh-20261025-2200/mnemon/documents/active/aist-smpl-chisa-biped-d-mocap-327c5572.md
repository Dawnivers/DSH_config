---
id: "327c5572-dafb-4758-83e9-764ec8add0bd"
title: "AIST++ SMPL 舞谱 → Chisa Biped 骨旋转重定向：可行方案与实测校验（D:\\mocap）"
description: "把 AIST++（SMPL 24 关节，60fps）舞蹈数据重定向到 Chisa Biped rig 的已跑通方案：为何位置拟合（Kabsch）失败、静止方向相对的逐骨旋转公式、C=Rx(180) + 100.35 单位/米、Chisa 小腿主骨零权重/枢轴在地板原点的绕过办法、脚部解析摆放、实测校验数字（双脚间距 0.576→0.583 m）、当前缺口（裙摆头发未驱动、无手指）与产出路径。"
status: "active"
created_at: "2026-10-17T04:41:38.357Z"
updated_at: "2026-10-17T04:41:38.357Z"
content_hash: "fd5eaa1c1bd6f95c97de76e309f1c31030e07541204f4dc2dbc566ab5d60c786"
source_paths:
  - "mocap/aist_export.py"
  - "mocap/retarget_aist.py"
  - "mocap/render_aist.py"
  - "mocap/render_video.py"
  - "mocap/probe_chain.py"
  - "mocap/check_smpl_legs.py"
  - "blender-bridge/bones_body_list.py"
session_ids:
  - "efe7c745-006d-4a11-a8c7-8c73cb1c0e06"
memory_body_ids:
  []
---

# AIST++ → Chisa 重定向（SMPL 旋转驱动版）

D:\mocap 下第一支可用成品已经跑通：AIST++ **Waack** 一支（`gWA_sBM_cAll_d25_mWA0_ch01`）12 秒 / 720 帧 @60fps，降采样 360 帧 @30fps 驱动 Chisa，脚底贴地、动作忠实。结论：**纯旋转驱动 + FK + 脚踝解析摆放**可行，位置拟合不可行。

## 1. 数据

- 位置：`D:\mocap\aist\motions\`，411 支完整舞蹈，275,270 帧（约 1.3 h），60 fps，10 个流派。
- 每支 `*.pkl` 的键：`smpl_poses (N,72)`（24 关节 × 3×3 轴角）、`smpl_trans`、`smpl_scaling`。
- **SMPL 的 24 关节顺序与 SMPL-X 前 22 个一致** → GVHMR 类管线可直接读，无需改写。
- 流派日系感排序（用户目标为二次元感）：Waack ★5（手臂爆发+定格）、Lock ★5、Ballet Jazz ★4、Pop ★4；Break 地板动作多不适合穿裙。
- 注意：AIST++ 是日本舞者跳的街舞，**不是 B 站/V 家 MMD 舞**。MMD 的 VMD 动作在 BowlRoll，多数带密码且版权受限；但重定向代码与动作来源无关，换输入即可。

## 2. 关键坑一：不能用位置拟合（Kabsch）求尺度

第一版把 SMPL 关节位置与 Chisa 骨位置做 Kabsch 对齐求 scale，残差 **15.9 cm**（拟合 scale 74.4），完全不可用。
原因：**SMPL rest 是 T-pose，Chisa rest 是屈膝坐姿**，两者关节位置本来就不在同一形状上，位置拟合会把姿态差异误当成缩放/旋转误差。改为**只用旋转、位置全交给 FK** 后残差问题消失。

## 3. 核心公式（静止方向相对）

对每根骨 i，用其**静止时指向子关节的方向**（不是父→本关节；写错会让静止偏移从 3–5° 变成 26–76°）：

```
G_i = 把 Chisa 静止骨方向 转到 C × SMPL 静止骨方向 的旋转
R_i = C · W_smpl,i · C⁻¹ · G_i        # W_smpl = SMPL 该关节的轴角旋转
local basis = R_rest,i⁻¹ · R_i
```

- `C` 实测**精确等于绕 X 轴 180°**：SMPL 是 +Y 朝上 / +Z 向前，Chisa armature 空间是 **−Y 朝上 / −Z 向前**。写成 `Rx(180)` 即可，不必再拟合。
- 尺度：Chisa 腿长 37.81 单位、SMPL 腿长 0.3768 m → **100.35 单位/米**（约等于 1 单位 = 1 cm）。仅用于根位移/脚部摆放，不参与旋转。
- 实测静止方向偏移（修正后，deg）：大臂 56.3 / 55.7（左右对称 ✓）、前臂 62.3、大腿 4.5、小腿 3.4、脚 26.8。

## 4. 关键坑二：Chisa 的小腿主骨是废的

- `Bip001LCalf_0280`（标准 Biped 小腿名）**蒙皮权重为 0，且 head 落在地板原点 (0,0,0)** → 绕它旋转等于绕地面转，膝盖位置全错。
- 真正驱动小腿网格的是辅助骨 **`Bip001_L_Calf_0285`**（head ≈ (7.99,−48.51,2.91)）；但它**不是脚踝 `Bip001LFoot_0281` 的父级**，所以它驱动的 FK 不会带动脚。
- 判定办法：`probe_chain.py` 式逐骨施加 40° 局部旋转，看各骨 head 位移；以及 `bones_body_list.py` 的命名判别——**真 Biped 身体骨 `Bip001` 前缀后无下划线**（`Bip001LCalf`），辅助/扭转骨**有下划线**（`Bip001_L_Calf`、`..._Knee_F`）。
- 绕过方案：小腿旋转施加到 `Bip001_L_Calf`，然后**解析地把脚踝放到「小腿旋转 × 静止偏移」算出的位置**，再键帧（`KeyError: 'Bip001_L_Calf_0285'` 曾因骨名未做后缀归一化而报错，取骨要按带 `_0285` 后缀的真实名）。
- 骨名带导入后缀 `_NNNN`，匹配时先 `re.sub(r'_\d+$','',name)` 归一化，但实际取 pose bone 仍用全名。

## 5. 校验（判定"忠实搬运"而非"调参凑出来"）

| 项 | SMPL 原始 | 重定向后 |
|---|---|---|
| 第 0 帧双脚间距 | 0.576 m | **0.583 m** |
| 脚底高度 | ≈0 | −0.04 ~ +0.03 m（贴地） |
| 骨盆高度起伏 | 2.06 m 基准 | 84–88 单位波动 |

- 宽站姿是 **Waack 本身风格**，不是映射错误——先用 `check_smpl_legs.py` 对比 SMPL 原始 hip/knee/ankle 坐标再下结论。
- 渲染多帧拼图（`sheet_aist.png`）比只看数字有效；数值正确但观感怪时，优先回原始关节位置核对。

## 6. 环境/脚本坑

- Blender 5.2 的 MCP 桥（9876）在 WSL 侧运行，**路径必须是 Windows 形式**（`D:/mocap/...`），`/mnt/d/...` 会 `FileNotFoundError`。
- 该 Blender 构建**没有 FFMPEG 输出**：`image_settings.file_format='FFMPEG'` 报 enum 不存在（只有 PNG/JPEG/EXR/WEBP…）→ 先渲 PNG 序列再用 `ffmpeg` 合 mp4。
- 保存时用 `save_as_copy` 之类写副本到 `D:/mocap/chisa_dance/chisa_dance.blend`，保持用户原场景不被覆盖。

## 7. 脚本与产物

- `D:\mocap\aist_export.py` → `smpl_rest.json` + `dance.json`（SMPL 静置关节、选定舞蹈、降采样帧）
- `D:\mocap\retarget_aist.py` → 逐骨旋转求解 + 键帧 + 校验打印
- `D:\mocap\render_aist.py`（多帧拼图 `D:\mocap\renders\sheet_aist.png`）、`D:\mocap\render_video.py` → `D:\mocap\renders\aist_preview.mp4`（240×360，360 帧）
- `D:\mocap\probe_weights.py` / `probe_chain.py`（骨链与权重探测）、`check_smpl_legs.py`
- 骨骼清单：`D:\Users\林先语\Documents\deepseek-harness\default-workspace\blender-bridge\bones_body_list.py`

## 8. 当前缺口与下一步

- **只驱动 22 根身体骨**：裙摆 `Bone_Skirt*`、头发 `Bone_Hair*`、飘带 `Bone_Piao*` 保持静置 → 动作显硬、裙不飘。这是观感提升最大的一步（可做惯性/滞后跟随）。
- **手指无数据**（AIST++ 无手指），只能留静置。
- 换流派只需换 pkl 文件名重跑，约 5 分钟出片；可批量导出做串烧。

## 相关文档

- Chisa rig 清单与既有坐标陷阱：`065c7b95-72ee-4323-96c0-2a5b179e432e`
- MediaPipe → Biped 方向匹配旧管线与噪声诊断：`c16da0c6-1c61-4678-a995-db2ed3fc734e`
- 整体可行性与分期方案：`16979651-4dbf-4432-8bc0-29541f6fc50f`
