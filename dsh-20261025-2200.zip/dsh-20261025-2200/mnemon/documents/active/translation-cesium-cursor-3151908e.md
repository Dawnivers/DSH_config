---
id: "3151908e-e946-40cd-88b9-2760bddfc25c"
title: "Translation 鼠标工具「要么皮肤、要么全隐藏」：常驻托管类与 Cesium 行内 cursor 的修正"
description: "修正并取代 c57db830 的关闭路径：鼠标工具的托管类改为常驻 <html>，只切换 CSS 变量（皮肤 PNG / none），页面内永不出现系统默认光标；含 Cesium 给 canvas 写行内 cursor 需 !important 压过的坑、用户明确要求原文与三态逐元素实测。"
status: "active"
created_at: "2026-10-07T13:41:32.386Z"
updated_at: "2026-10-07T13:41:32.386Z"
content_hash: "d4e54620108347ff0d1259d15bb7085feef8904c4535b4cced7b309d73c8cc04"
source_paths:
  - "Translation/src/components/screenUI/foot.vue"
  - "Translation/src/assets/cursor-hud.png"
session_ids:
  - "b4075c7d-bc12-4334-a42f-93ac0b9b1459"
memory_body_ids:
  []
---

# Translation 鼠标工具「要么皮肤、要么全隐藏」

日期：2026-10-07。状态：**已实现并运行时验证通过**。源文件：`Translation/src/components/screenUI/foot.vue`、素材 `Translation/src/assets/cursor-hud.png`。

相关文档：
- `c57db830-7398-42ec-87c4-718df048024f` —— 方案 A 的整体落地（图片光标素材来源与热区、右下角读数面板写法、旧跟随式皮肤清除范围、四态实测）。**本文取代其「关闭路径」一处**：那份文档写的「关闭 = 去掉 `html.hud-cursor-none` 恢复默认光标」已作废，其余内容仍然有效。
- `715e6684-4186-4c51-82f8-1db889099650` —— 皮肤造型（金环 + 青菱 + 脉冲）与两个 Vue 过渡坑的来源。
- `75da7559-5010-47fe-b292-58bd88afa63f` —— 为什么指针必须交给系统绘制（帧率归因实验）。

## 1. 用户要求（原话，术语按此执行）

> 观察到关闭鼠标指针后，还残留着系统默认的鼠标，我需要将其隐藏，一切出现在这个页面内的鼠标样式都要是我的皮肤样式，要么显示，要么隐藏。

即：**页面内只有两种合法状态——自定义皮肤，或彻底不可见；任何时候都不允许出现系统默认光标。**

## 2. 之前为什么错

旧实现是**切换类**：`root.classList.toggle('hud-cursor-none', mouseToolOn.value)`。类一摘掉，全局那条 `cursor: … !important` 规则随之失效，浏览器把系统默认光标交还回来。逻辑本身与此要求冲突，不是样式没写对。

另外用户看到「残留」很可能发生在地图区域：**Cesium 会自己给 canvas 写行内 `cursor`**（`grab` / `crosshair` 之类），组件级或未加 `!important` 的规则压不住行内值。

## 3. 现在的实现

类的名字与语义都变了：`hud-cursor-none` → **`hud-cursor-managed`，且常驻**，只切 CSS 变量。

```js
const syncNativeCursor = () => {
  const root = document.documentElement;
  root.classList.add('hud-cursor-managed');        // 常驻：页面永远由我们接管
  root.style.setProperty(
    '--hud-cursor-skin',
    mouseToolOn.value ? CURSOR_SKIN : 'none',      // 开=准星皮肤；关=none（彻底不可见）
  );
};
```

```css
/* 必须写在非 scoped 样式块 */
html.hud-cursor-managed,
html.hud-cursor-managed * {
  cursor: var(--hud-cursor-skin, none) !important;
}
```

- 变量缺省值也是 `none`，任何漏设变量的路径都只会退化成「看不见」，不会退回系统光标。
- `!important` 在这里是必需的，作用是压过 Cesium 写给 canvas 的行内 `cursor`。
- 找回入口不变：`Esc`，或点击提示浮窗「鼠标已隐藏 ESC 按键重新显示鼠标」。

## 4. 运行时验证（Playwright，逐元素取样计算值）

| 取样位置 | 工具开 | 工具关 |
|---|---|---|
| `<html>` | `url("…/cursor-hud.png") 32 32, crosshair` | `none` |
| `<body>` | 皮肤 | `none` |
| Cesium `<canvas>` | 皮肤 | **`none`** ← 原本残留处 |
| HUD 导航按钮 | 皮肤 | `none` |
| 齿轮按钮 | 皮肤 | `none` |
| 右下角读数面板 | 皮肤 | 面板已隐藏 |
| `--hud-cursor-skin` | `url(/src/assets/cursor-hud.png) 32 32, crosshair` | `none` |

另外：`hud-cursor-managed` 类在「开 / 关 / ESC 恢复」三个状态中都存在（常驻 ✓）；工具关闭时提示浮窗出现；按 `Esc` 后皮肤与读数面板同时恢复；页面控制台报错 **无**；编译产物 HTTP 200 且新类已进产物。

## 5. 可复用的教训

1. **「隐藏系统光标」不要用加/摘类实现**——摘类就是显式地请求系统光标回来。用常驻托管类 + 变量切换，缺省值取 `none`。
2. **第三方 WebGL 控件（Cesium 等）会在元素上写行内 `cursor`**，全局接管必须 `!important`；排查「残留的默认光标」应先取该元素的 `getComputedStyle().cursor` 逐点确认，而不是只看组件根节点。
3. 该组件的全局光标规则必须放在**非 scoped** 样式块，scoped 无法作用到 `html` 与 Teleport 出去的节点。
