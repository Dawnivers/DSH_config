---
id: "c561501d-15a9-4c3e-b468-deaaa91880dc"
title: "verify-shell-patch.ps1 依赖名单动态化与 -Fix 判定修复（2026-10-10，desktop profile）"
description: "记录 verify-shell-patch.ps1 相对首版的行为演进：依赖名单每次实时读 profile manifest（新装插件自动纳入 + 指纹变化触发全量）、新增 unversioned 来源分类与 bundles 孤儿 warn、-Fix 后判定重算（修复前失败项落 fix.repairedFrom）；附「被抹→抓到→自动修复」仿真实测数字与报告查看/刷新语义。承接 98bbab1e、727cfe91。"
status: "active"
created_at: "2026-10-10T04:21:26.250Z"
updated_at: "2026-10-10T04:21:26.250Z"
content_hash: "828c5c95c9e0cb6b9e6145bd93ff7999993a64495eb5a5247e33d52931c5c5bf"
source_paths:
  - "dsh-builtin-browser/desktop/verify-shell-patch.ps1"
session_ids:
  - "5779110d-fdc6-4d1c-ac8a-33c766f5e747"
memory_body_ids:
  []
---

# verify-shell-patch.ps1 依赖名单动态化与 -Fix 判定修复（2026-10-10，desktop profile）

脚本落地与 PS 5.1 三条硬约束见 `98bbab1e-d1f4-48c5-bac6-0db6a81271a7`；定时载体与三层设计见 `727cfe91-252c-4513-be57-710ddaf03945`。**本文只记两篇文档之后发生的行为演进与仿真实测**，避免与它们重复。

## 1. 依赖更新检测：从「声明名单」改为「每次实时读活清单」

首版设计写的是「读 profile manifest 的 15 个第三方依赖」。实际实现改为**每次运行都重新读** `~/.dsh/profiles/desktop/package.json` 的 `dependencies`，按来源分类，因此**新装的插件自动进入名单，不需要改脚本**。

闭环链条（全量检查的实际触发方式）：

```
装新插件 → profiles/desktop/package.json 变 → 基线指纹包含该 manifest 的哈希 → 指纹变
        → 下一次 schtasks（登录后 30s 或 09:30）不再秒退，自动转全量
        → 新插件当天出现在依赖表；09:35 的任务板卡本就带 -Force，也会带上它
```

按来源分三类处理：

| 来源 | 处理 | 状态值 |
|---|---|---|
| registry（npm 包） | 比对 npm `dist-tags.latest` | 正常 / `outdated` |
| `link:` 本地目录 | 无版本概念，只查目录存在性（静态断言段） | — |
| `github:` / git URL / tarball / `file:` | 没有上游版本可比，只报告已装版本 | `unversioned` |

**修复的噪音**：改前非 registry 来源的包被当作 registry 包去查 npm，查不到就报 `unknown`；现在单列 `unversioned` 并写明「来源不是 registry（git/tarball/file），只报告已装版本」。合成用例实测：`some-git-plugin  status=unversioned`。

**新增的覆盖盲区告警**：只出现在 `dsh.profile.bundles`、`dependencies` 里没有的第三方条目，改前完全隐形，现在点名 warn：`只在 dsh.profile.bundles 里、dependencies 里没有：ghost-bundle —— 这些条目不会被版本检测覆盖`（合成用例专造 `ghost-bundle` 验证）。

**仍覆盖不到的三类**（已向用户说明，非遗漏）：聚合包的子包（只跟踪聚合包自身版本，不展开 `dsh-client-ui-*` 之类）；装在别的 profile（`web` 或新建 profile）的插件——脚本盯 `profiles/desktop`，可加 `-ProfileDir` 参数跑第二份；走 `repository` 插件机制（`.dsh-plugin` 目录 / `cordis.patch.yml` 的 `repository-plugins.repositories`）的插件根本不是 npm 依赖。`@deepseek-ai/*` 官方组合包是**故意不查**，由指纹里的 app version 覆盖。

**语义要点**：`outdated` 永远是 `warn`，判定仍 PASS、退出码仍 0、taskschd 仍绿；脚本不自动升级、不改 `package.json`、不重启应用。

## 2. `-Fix` 判定缺陷修复（本次仿真的副产物）

**现象**：改前 `-Fix` 修复成功后，判定**仍显示 fail、退出码仍为 1**——因为修复前的失败项被一并计入结果。修复成功却报红。

**改法**：`-Fix` 分支在重放 `apply-shell-patch.mjs` 后**丢弃修复前的断言结果、重新断言**，并把修复前的失败项落档到 `fix.repairedFrom`。

实测输出：`判定 pass 退出码 0`，`repairedFrom` 逐条列出 7 项（`runtime-content-publish`、`runtime-base-options`、`runtime-renderer-publish`、`runtime-webviewtag-count`、`preload`、`main-import`、`shell-deployed`），另有 `修复后仍失败: 无`。

## 3. 「被抹 → 抓到 → 自动修复」实景仿真（2026-10-10 实跑）

用 `app-lib-backup-*` 里的**原版文件**冒充「更新后的干净 app」、版本号写成 2.0.18，三个阶段实跑：

| 阶段 | 条件 | 判定 | 退出码 | counts |
|---|---|---|---|---|
| 0 平常的一天 | schtasks 快路径，真实 profile | — | 0 | **592 ms**，报告文件数 8 → 8（零写入），`LastTaskResult=0` |
| 1 更新抹掉补丁 | `-Force` + 原版 app 文件 | **fail** | **1** | ok16 / warn3 / **fail7** / skip1 |
| 2 `-Fix` 自我修复 | 同上 + `-Fix` | pass | 0 | 7 条落 `fix.repairedFrom` |
| 3 复查 | 普通全量 | pass | 0 | ok24 / warn2 / fail0 / skip1 |

阶段 1 的 7 条 FAIL：内容视图补丁、基础窗口选项补丁、窗口渲染器补丁、`webviewTag: true` ≥2、`preload.cjs` 补丁、`main.js` 引入 shell、`lib\dsh-builtin-browser-shell.js` 已部署。

**退出码 1 就是 `taskschd.msc` 里「上次运行结果」变红的机制**，任务板卡会话同时逐条报出失败项。

**一个必须知道的互补关系**：阶段 1 里 **live 探测那半场仍全绿**，因为真实的老进程还跑着 44721 端点。桌面更新后 app 会重启、端点会随之消失，所以**静态断言是先手**（老进程还活着时就能发现补丁被抹），**live 是后手**；两者互补而非重复。

仿真产物（临时）：`%TEMP%\dsh-incident-rehearsal\{out1,out2,out3}\latest.html`；合成用例产物：`%TEMP%\dsh-selfcheck-test\out\`。

## 4. 报告在哪看、什么时候被刷新

报告目录 `%USERPROFILE%\.dsh\shell-patch-selfcheck\`：

| 文件 | 用途 |
|---|---|
| `latest.html` | 最近一次全量的完整报告（自包含、内联 CSS、无外链，可拷走） |
| `latest.json` | 同一份报告的机器可读版 |
| `report-<YYYYMMDD-HHMMSS>.html/.json` | 每次全量的历史快照 |
| `state.json` | 指纹 + 上次判定 + counts（快路径依据） |

`-Retain` 默认 20，只留最近 20 次全量。**快路径秒退不写报告**，所以历史里每条都代表真的做过一次全量。

刷新语义：`latest.html` 是**覆盖写**——每次全量检查重写一次。因此「报告的日期 = 最后一次全量检查的时刻」。典型日子：DSH 开着且到 09:35 → 卡片 `-Force` 每天刷一次；DSH 没开且无变化 → schtasks 两次都秒退，`latest.html` 停在上次全量的日期（不是漏报，是没东西变）；被抹补丁或装了插件 → schtasks 发现指纹变化即自动转全量，**不依赖 DSH 开着**。

报告头部元信息可直接判新旧：`2026-10-10 12:06:52 · 用时 842 ms · app dsh-plugin-desktop 2.0.17 · 指纹 dea620d37898eac1 · 指纹与上次一致 / 指纹有变化`。

另两个视角：`taskschd.msc` → `DSH-ShellPatchSelfCheck`（上次运行结果 / 下次运行时间 / 历史页签）；DSH Web GUI → 任务板 → 卡片「DSH 外壳补丁 live 体检」→ 执行记录（sessionId + 结果）。**DSH GUI 里没有这个脚本的面板**，因为它不是插件，只是脚本 + 任务板卡。

## 5. 保持现状的能力边界与可选调整

- 无法让 `latest.html` 「不管有没有变化都保证是当天」——除把 schtasks 那条 Action 的 `-Quiet` 后再加 `-Force`（代价：每天多跑约 20 秒 + 一次 registry 查询，不花 token）。截至本记录用户尚未决定。
- 用户提出的三个可选增强（均未实施）：`latest.html` 的桌面快捷方式；包成 DSH 自定义命令（如 `/shellcheck`）；让任务板卡**只在 `verdict=fail` 时开口**、平时静默。
- 本次演进后实测基线：真实 profile `PASS 24 / warn 3 / fail 0 / skip 0`，8 个 registry 依赖中 5 个可更新；合成用例 `PASS 16 / warn 3 / fail 0 / skip 1`（含 `-NoNetwork`）。schtasks 复跑确认未被改坏：`LastRunTime=12:07:05 LastTaskResult=0 NextRunTime=10/11 09:30`。
