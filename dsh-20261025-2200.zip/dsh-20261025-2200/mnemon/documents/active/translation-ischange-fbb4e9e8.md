---
id: "fbb4e9e8-65be-4d52-bbbf-d3213ae79e03"
title: "Translation 智慧地铁：路径规划起终点的「角色气泡」（换乘站时角色信息被 isChange 吞掉的分层解法）"
description: "2026-10-19 在 guideload/renderRoute.js 的增量：起点/终点本身是换乘站时，名字气泡被 MarkerTemplate 的 isChange 强制染红加「换」徽标，导致「这是终点」信息丢失；解法是额外挂一枚不可点、青/金色的「起点/终点」角色气泡（ROLE_OFFSET [0,158] 叠在名字气泡上方，isChange 传 0），仅在起终点是换乘站时添加。含两组建模场景验证与「真点击仍未验证」遗留项。前置文档 bfc4bd84。"
status: "active"
created_at: "2026-10-19T05:41:01.354Z"
updated_at: "2026-10-19T05:41:01.354Z"
content_hash: "ab8a49cb33fed57d436837b6f3a58eac7d2122b62abd2363ad6869f36150b35c"
source_paths:
  - "Translation/src/components/bottom/StationPanel/QueryModePanel/guideload/renderRoute.js"
  - "Translation/src/components/bottom/StationPanel/MarkerTemplate.vue"
session_ids:
  - "1697f4da-2051-4b45-a0fd-c5404830189d"
memory_body_ids:
  []
---

# 路径规划起终点的「角色气泡」

日期：2026-10-19。前置文档：`bfc4bd84-5376-4b42-9aee-82361f557fa3`（起/终/换乘站气泡、`isChange` 透传、点击走 `showQueryPopup()` → `queryTemplate`、`disposed` 清理）。**本文只记该文档之后的增量，不重复其内容。**

## 1. 用户提出的问题

`MarkerTemplate.vue`（约 L45）里 `isChange` **优先于传入的 color**：换乘站一律半透明红底 + 「换」徽标。于是当**终点站本身是换乘站**（如世纪大道 2/4/6/9），金色终点气泡会变成红色的「换 世纪大道」，"这是终点"这条信息被换乘样式吃掉。起点侧同理（莘庄 1/5）。

## 2. 解法：不动名字气泡，额外叠一枚角色气泡

名字气泡保持换乘站观感（与站点管理一致，是设计不是 bug），**在上方补一枚纯提示气泡**：

```js
const ROLE_OFFSET = [0, 158];
const addRoleChip = (viewer, coord, text, color, bucket) => { /* 同 addLabel，offset: ROLE_OFFSET */ };

if (first?.fromIsChange) addRoleChip(viewer, first.fromCoord, '起点', MARKERS.start.color, labels);
if (last?.toIsChange)   addRoleChip(viewer, last.toCoord,   '终点', MARKERS.end.color,   labels);
```

关键约束（改这块别再破坏）：

| 决定 | 原因 |
|---|---|
| 名字气泡 `offset [0,120]`、角色气泡 `[0,158]` | 角色气泡正好在上方，间隔约 10px，不互相遮挡 |
| 角色气泡 `clickable: false` | 它只是提示；点它不开卡，下面名字气泡照旧弹 `queryTemplate` |
| 角色气泡 `isChange: 0` | 只为**别被染红**；详情卡读的是 `attr.isChange`，不受影响 |
| 颜色取 `MARKERS.start/end.color` | 与起点/终点光柱同色，青/金一眼分得清 |
| 仅在 `fromIsChange / toIsChange` 为真时添加 | 非换乘站的起终点，名字气泡本身就是青/金，再叠「起点」纯冗余 |
| 塞进同一个 `labels` 数组 | `clear()` 统一 `removeMarker()`，换方案/退出规划模式无残留 |

**留的口子**：若以后要求"起点/终点"永远显示（不区分是否换乘站），把那两个 `if` 去掉直接调用即可，一行事。

## 3. 验证

| 场景 | 结果 |
|---|---|
| 起点 莘庄（换乘）、终点 五角场（非换乘） | 出现青色 **起点**；终点侧无多余气泡（只有金色「五角场」） |
| 起点 五角场（非换乘）、终点 世纪大道（换乘） | 出现金色 **终点**，与「换 世纪大道」并存 |
| 换方案 / 退出规划模式 | 角色气泡随其他标签一起被 `clear()` 收掉 |

**未验证**：真点一下气泡弹卡片——气泡是纯 `div`，不在浏览器桥的可访问元素树里（快照无 index），当时 Chrome 窗口又最小化，桌面点击也够不到；需人工手点确认。这一点与前置文档的遗留项相同。

## 4. 相关文档

- `bfc4bd84-5376-4b42-9aee-82361f557fa3` — 本增量的前置：气泡层次、`isChange` 双消费、点卡链路、`disposed` 清理、验证选择器经验。
- `44fe1831-c29a-4d4c-aed8-334dfb8fa556` — 路径规划模式整体结构（planModel / renderRoute / useRoutePlan / RouteDesign）。
