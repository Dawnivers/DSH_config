---
id: "98bbab1e-d1f4-48c5-bac6-0db6a81271a7"
title: "外壳补丁自检脚本落地与双定时注册（verify-shell-patch.ps1，2026-10-10 本机 desktop profile）"
description: "verify-shell-patch.ps1 的实施结果与 Windows PowerShell 5.1 三条硬约束（UTF-8 BOM、必须 -ExecutionPolicy Bypass -File、$PSScriptRoot 在 param 默认值为空）、脚本开关与报告路径、schtasks 任务 DSH-ShellPatchSelfCheck 与任务板 cron 卡的分工及实测证据、3 条常驻 warn 的正常噪声清单、以及\"编辑后必须重补 BOM\"的维护注意事项。承接设计文档 727cfe91。"
status: "active"
created_at: "2026-10-10T04:02:45.706Z"
updated_at: "2026-10-10T04:02:45.706Z"
content_hash: "8d570f02d042d63d33acd56c9665d6e7e1944ee6f4194853656e8a9e685f9b6d"
source_paths:
  - "dsh-builtin-browser/desktop/verify-shell-patch.ps1"
  - "dsh-builtin-browser/desktop/apply-shell-patch.mjs"
session_ids:
  - "0be6f57d-0ffc-4d75-8a15-410df9d3b80b"
memory_body_ids:
  []
---

# 外壳补丁自检脚本落地与双定时注册（2026-10-10，本机 desktop profile）

设计取舍见文档 `727cfe91-252c-4513-be57-710ddaf03945`（三种定时载体对比与三层设计）。**该文档写作时脚本与两个定时均未落地；本文记录已完成的实施结果、实测证据与本机硬约束。**

## 1. 交付物

| 物 | 路径 |
|---|---|
| 自检脚本 | `dsh-builtin-browser\desktop\verify-shell-patch.ps1`（约 726 行，与 `apply-shell-patch.mjs`、`restart-and-verify.ps1` 同目录） |
| 人类可读报告 | `%USERPROFILE%\.dsh\shell-patch-selfcheck\latest.html`（另有按时间戳归档的 `report-YYYYMMDD-HHMMSS.html/.json`） |
| 机器可读结果 | 同目录 `latest.json`（断言与依赖明细）、`state.json`（指纹 / 判定 / 计数，供快路径比对） |

## 2. Windows PowerShell 5.1 的三条本机硬约束（最容易翻车处）

1. **本机只有 Windows PowerShell 5.1，没有 pwsh 7**（`C:\Program Files\PowerShell\7`、`Program Files (x86)`、`AppData\Local` 三处均不存在）。
2. **`.ps1` 必须存为 UTF-8 *with BOM***。无 BOM 时 5.1 按 GBK 解码，脚本内中文全部乱码。已实测：编辑工具写回会去掉 BOM，**每次编辑后需重新补 BOM**；脚本头注释已写死这条提醒。
3. **`& script.ps1` 会报「AuthorizationManager 检查失败」**，即使 `Get-ExecutionPolicy -List` 显示 LocalMachine=Unrestricted、文件也没有 Zone.Identifier 流。唯一可靠调用方式是：
   `powershell.exe -NoProfile -ExecutionPolicy Bypass -File <脚本路径>`（schtasks 的 Action 必须同样写法）。
4. 附带坑：`$PSScriptRoot` 在 PS 5.1 的 `param` 默认值里是空的，必须在脚本体（param 之后）解析。

## 3. 脚本开关与行为

- **无参数** = 快路径：先算基线指纹（app `package.json` version + `electron-runtime-*.js` / `preload.cjs` / `lib/dsh-builtin-browser-shell.js` 的 SHA256 + `cordis.patch.yml` 的 `controlPort` + 8 个 `link:` 目录），与 `state.json` 一致即秒退，**退出码 0**，输出形如「指纹未变（dea620d37898eac1），上次判定 pass —— 跳过全量检查」。
- `-Force` 全量校验（含 live 探测）；`-Fix` 重放 `apply-shell-patch.mjs`；`-NoNetwork` 跳过依赖更新检测；`-Quiet` 不弹控制台。
- 退出码语义：**0=通过 / 1=有 fail**，正好落到 `taskschd.msc` 的「上次运行结果」。
- 基线指纹固定为 `dea620d37898eac1`（2026-10-10 状态）。

## 4. 实测结论：PASS 23 / 警告 3 / 失败 0 / 跳过 0

报告内确认为真的断言包括：`lib` 下有且仅有一个 `electron-runtime-*.js`（`electron-runtime-C_4WapB_.js`）、内容视图补丁（`webviewTag` + 发布 `__dshBuiltinBrowserContent`）、窗口渲染器补丁、`webviewTag: true` 出现 ≥2 处（实测 2 处）、`preload.cjs` 补丁（`window.desktopBridge` + `browserPort`）、`main.js` 引入 `dsh-builtin-browser-shell.js`、控制端点模块与源一致（sha256 `efb5e5a1a99e0f80`）、救援备份 `app-lib-backup-*` 存在、8 个 `link:` 包全部就位、`op=ping` 返回 `ok=true page=true port=44721`、preload 桥携带 `browserPort=44721 isDesktopShell=true`。
live 段实测：`live.ping.ok=True live.ping.page=True live.webPort=23776`。

### 3 条常驻 warn（均为正常噪声，不应报成事故）

| warn | 含义 |
|---|---|
| profile 补丁层未声明 `controlPort` | 插件退回页面回报的 `desktopBridge.browserPort`，实测端口一致；想钉死就在 builtin-browser 行加 `controlPort: 44721` |
| 内置浏览器面板控制器已挂载 | 面板未打开时 `webview=0 iframe=0` 判不了；想看它变绿需打开面板后加 `-Force` |
| DSH Web 端口与 pinned 43120 不同（已回退） | 本次 host 实际 23776，与 `cordis.patch.yml` 钉的 43120 不符，报告记为「已回退」；与 Chrome 扩展链无关 |

### 已修掉的两个假警报

- `$PSScriptRoot` 在 param 默认值为空导致路径判错（改为脚本体解析）。
- `@local/dsh-agnes-core` 是共享库、没有 `dsh` 字段，本就不该进 bundles，原先误报为 warn。

## 5. 两个定时已注册并各自实测通过（分工：OS 兜底 + 活宿主全量）

**① Windows 任务计划 `DSH-ShellPatchSelfCheck`**
- 触发器：登录后 30s（Delay=`PT30S`）+ 每日 09:30。
- Action：`powershell.exe -NoProfile -ExecutionPolicy Bypass -File "<repo>\dsh-builtin-browser\desktop\verify-shell-patch.ps1" -Quiet`（**不带 `-Force`**，走指纹快路径）。
- Principal：`林先语` / LogonType=**Interactive** / RunLevel=**Limited**（不用 S4U——取不到网络会让依赖检测失效；静态检查无需提权）。
- Settings：`StartWhenAvailable`（关机错过的当天补跑）、MultipleInstances=IgnoreNew、超时 10 分钟。
- 实测：注册后立刻真跑一次，`LastRunTime=2026-10-10 11:58:45`、**`LastTaskResult=0`**、`NextRunTime=10/11/2026 09:30:00`。

**② 任务板卡 `DSH 外壳补丁 live 体检`**（id `ff0dfc95-48d5-48d1-b34a-3bb8e7d3d5e3`，标签「自检」）
- cron `35 9 * * *` / `Asia/Shanghai`（与 09:30 的 schtasks 错开 5 分钟）；`goalRun=false`、`skipVerification=true`、`reuseSession=false`；权限**沿用会话默认而非 read-only**（脚本要写 `~/.dsh/shell-patch-selfcheck/`）。
- 内容：跑 `-Force` 全量（含 44721 live 探测），读 `latest.json`：`verdict=fail` 逐条列失败断言与修复动作（补丁被抹掉就重放 `apply-shell-patch.mjs`），pass 则一行汇报并列出 `status=outdated` 的包；脚本 exit 1 一律按 fail 处理。四条正常噪声已写进卡片 prompt。
- 实测：试跑 `11:59:07 → 11:59:22`（约 15 秒）、result=succeeded；磁盘证据 `report-20261010-115910.json` 落在试跑窗口内，且本次 `fingerprintChanged=False`。

时间表：每次登录 +30s / 每日 09:30 → OS 快路径（零 token，DSH 未开也跑）；每日 09:35 → 任务板卡全量。日常运维命令：`Get-ScheduledTaskInfo` / `Start-ScheduledTask` / `Disable-ScheduledTask` / `Unregister-ScheduledTask -TaskName 'DSH-ShellPatchSelfCheck'`。

## 6. 未完成与可选后续

- **像素级渲染验证未做**：浏览器桥报 `no browser extension is connected`，只完成了 HTML 结构自查（`<style>` 注入正常、无 `$css` 残留、3 表 / 4 卡片、中文无乱码、`</html>` 收尾），需人工双击报告确认。
- 依赖检测报 **5 个可更新**：`dsh-tui 0.13.0→0.14.0`、`dsh-better-sidebar 0.24.1→0.25.0`、`dsh-context 0.64.0→0.66.1`、`dsh-cost-meter 1.8.15→1.8.17`、`dsh-mnemon 0.5.24→0.5.27`（按方案 A，升级 = `dsh plugin --profile desktop add <包名>` 重装后重启 Desktop 进程）。
- 待查：host 实际端口 23776 vs `cordis.patch.yml` 钉的 43120，`dsh-bridge-port-shim.mjs` 是否真的生效。

## 7. 维护铁律

任何对 `verify-shell-patch.ps1` 的编辑之后，**必须重新补 UTF-8 BOM**；否则 5.1 会按 GBK 解码，中文断言文案全部乱码。（脚本头注释已写死，仍需人手执行。）
