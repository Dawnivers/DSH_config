---
id: "8328e42a-03f8-4b41-b3a7-de40645db95d"
title: "POI 补全到 16016 条后验证「库变图层即变」：WFS hits 版本坑、GeoServer 2.28 的「发布」入口与 latLonBoundingBox 必填（2026-10-25）"
description: "D4 收尾实证：poi 表从 3346 补到 16016 条（13 区全类、四分类分布、按几何落区），在完全不改 GeoServer 配置的前提下用 WMS PNG 字节数 10.1→16.1→82.9 KB、黄陂/新洲 WFS hits 0→421、全库 hits=16016 三条独立证据证明 PostGIS 加行即时生效；另记 WFS 1.0.0 resultType=hits 返回 0 必须用 1.1.0、GeoServer 2.28 中「发布」实为数据源页标签页（直链 NewLayerPage 更快）、编辑图层页报 latLonBoundingBox is required 只差两个 Compute 按钮，以及 ETL 每轮 400 次上限与 resume、配额账。"
status: "active"
created_at: "2026-10-25T05:37:07.355Z"
updated_at: "2026-10-25T05:37:07.355Z"
content_hash: "a67f7735ab4f188edeaf9320e9cf2ad6c3c6ebdfc7e4480ecf1026c26f6855f8"
source_paths:
  - "gis-prep/poi-wms-full.png"
  - "etl/main.py"
session_ids:
  - "3b8c9c01-f2c2-4530-a015-5d6e3c369138"
memory_body_ids:
  []
---

# POI 补全到 16k 与「库变即图层变」的实证

承接 `7037e9c5-10d0-4357-b833-67bb1a1d8bfe`（发布前必须先删旧 featuretype）与 `8d2fc1c9-4493-4ece-88e1-59e02ad49c43`（行/列/范围/缓存四档处置）。本文只补三个本轮新得到、且下次还会用到的东西：**WFS 计数的版本坑**、**GeoServer 2.28 里「发布」到底在哪**、以及**用字节数证明图层跟着库变的证据链**。库名/Store 的底层事实仍以 `e2a4925e-c390-44f3-bd15-8bf165e70b28` 为准（数据库是 `Spatial`，大写）。

## 1. 收尾状态

`poi` 表结构 **16 列**：`amap_id / name / category / typecode / address / adcode / tel / lon / lat / geom(Point) / raw / detail / detail_fetched_at / source / fetched_at`（+ 主键）。图层 `wuhan:poi` 已发布，Name 与表名一致、声明 SRS `EPSG:4326`、启用+广告均勾选。

数据体检：**16,016 条**，SRID≠4326 / 越界坐标 / 重复 amap_id / 空名称 **全 0**；唯一非零是「归区口径差异 781」（高德 adcode 与矢量边界不一致，非坐标错误，口径规则见 `8d2fc1c9`）。

| 分类 | 条数 | | 按几何落区（ST_Within，共 16,005） | 条数 |
|---|---|---|---|---|
| hospital 医院/诊所 | 5347 | | 洪山区 | 1870 |
| mall 商场/超市 | 4858 | | 武昌区 | 1782 |
| school 学校 | 4648 | | 江夏区 | 1583 |
| park 公园 | 1163 | | 蔡甸区 | 1376 |
| | | | 黄陂区 | 1360 |
| | | | 东西湖区 | 1307 |
| | | | 江岸区 | 1229 |
| | | | 汉阳区 | 1193 |
| | | | 硚口区 | 1185 |
| | | | 新洲区 | 1167 |
| | | | 江汉区 | 1155 |
| | | | 青山区 | 596 |
| | | | 汉南区 | 202 |

洪山（光谷+大学城）/武昌/江夏最高、青山/汉南最低，形状合理 → 方位与投影没转错、没漏区。用户在 QGIS 中叠加比对「大致不出错」，独立佐证链路可信。

## 2. 核心结论：PostGIS 加行 → 图层即时可见，无需任何 GeoServer 动作

全程**没动** GeoServer 任何配置（没 reload、没重发、没清瓦片），只让数据库变：

| 时点 | 表内行数 | 全武汉 GetMap PNG | 黄陂/新洲 bbox 的 WFS hits | 全库 WFS hits |
|---|---|---|---|---|
| 补采前 | 3,346 | 10.1 KB | 0 | — |
| 中途 | 9,446 | 16.1 KB | 0（还没轮到该区） | — |
| 补完 | 16,016 | 82.9 KB | **421** | **16,016** |

三条独立证据互相印证：①PNG 体积随行数单调涨；②此前一个点都没有的区域从 0 变 421；③WFS 全库 hits 与 `SELECT count(*)` 完全相等。

**验收方法论（可复用）**：判断图层是否「跟着库变」，不要靠肉眼看图，用 **① GetMap 返回字节数 ② 特定小 bbox 的要素计数 ③ 全库 hits 对 SQL count** 三点交叉。空白图的判据是几百字节，有内容是几十 KB。

落盘图：`gis-prep/poi-wms-full.png`（1200×900，84.9 KB，WMS 直出）。

## 3. 坑一：WFS 计数必须用 1.1.0，1.0.0 的 hits 恒为 0

```
/geoserver/wuhan/ows?service=WFS&version=1.0.0&request=GetFeature&typeName=wuhan:poi&resultType=hits
→ numberOfFeatures="0"   （数据明明有 1.6 万条）
```

换 `version=1.1.0`（同一请求、无 bbox）立即返回 `numberOfFeatures="16016"`。所以**以后写 WFS 计数一律用 1.1.0 或 2.0.0**；`1.0.0 + resultType=hits` 在这台环境不可信，别据此判断「数据没入库」。

附带：`GetCapabilities` 里没搜到 `wuhan:poi` 段，是响应体过大被 curl 截断，不是图层缺失。

## 4. 坑二：GeoServer 2.28 的「发布」不是一个按钮，是数据源页的标签页

用户在这一步反复卡住（连问两轮「发布在哪里」），真实层级是：

```
存储仓库列表 → 点 spatial_db（存储仓库名称列）→ 编辑数据源页
  → 顶部三个标签：数据源 | 发布 | 属性      ← 「发布」是第二个标签页
  → 表清单里每行末尾还有一个「发布」链接      ← 这个才真执行发布
```

同一个词出现两次、含义不同，是最容易混的地方。这版 UI 在该页有时不渲染标签，**更稳的路是直达新建图层页**：

```
http://localhost:8080/geoserver/web/wicket/bookmarkable/org.geoserver.web.data.layer.NewLayerPage
```

或 顶栏「图层」→「添加新的资源」→ 选 `wuhan:spatial_db` → 同一份表清单。少一层点击。

## 5. 坑三：编辑图层页报 `Field 'latLonBoundingBox' is required.`

看到这行红字**不需要改任何文本字段**，只差两个按钮：

1. Native Bounding Box 区块 → **「从数据中计算」**（Compute from data）
2. 纬度/经度边框区块 → **「Compute from native bounds」**

点完 8 个数字框自动填好（武汉约 `113.9/30.4/114.5/30.7` 量级），红字消失。1.6 万行算 bbox 约 1–2 秒，别连点。

判读小技巧：属性列表里出现 `amap_id`、`detail_fetched_at` 说明读到的是**新的 16 列表**；若仍是 `phone/email/open_hours`，就是旧结构缓存，必须删 featuretype 重发（reload 不够，见 `7037e9c5`）。

## 6. ETL 轮次上限与配额

采集脚本每轮有 **400 次请求硬上限**，触顶会打印 `[中断] ... 已达本轮上限` 并**保存进度**，重跑同一命令即续跑（resume 语义）：

| 轮次 | 结果 |
|---|---|
| 第 1 轮 | 31 次 + 200 次，写入 3254 条，累计 3,346 |
| 第 2 轮 | 400 次触顶（停在东西湖区 hospital），累计 9,446 |
| 第 3 轮 | 417 次跑完 13 区，累计 16,016 |

当日消耗 1,048 次；当月 1,081 / 5,000，余 ≈3,919。**配额是本项目最稀缺资源**（详见 `8d2fc1c9` 的 count=600 天花板），继续补数前先算账。

## 7. 口径提醒（面试/文档措辞）

16,016 是「高德细分码 × 200/页 能覆盖到的量级」，**不是武汉全部 POI**。武昌/江岸等高密度区的 school/hospital 因 `count=600` 封顶只能采样。对外表述用「采集到 1.6 万条 POI」，把「这是采样下限而非全量」讲清楚，比夸大全量更能体现数据边界意识。
