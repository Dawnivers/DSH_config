---
id: "f9eff4ea-e646-436b-bfcc-2baffb6b4321"
title: "gaode-study-React「拆分组件」改造为可上线结构：Express + node:sqlite 后端、高德 JSAPI 安全密钥代理（三个实测坑）与宝塔部署"
description: "本项目从纯前端 json-server 学习项目改造成「前端 + 独立 server/ 后端 + 高德安全密钥代理」的可部署结构的实施记录：接口设计、代理必须原样透传 query 与 serviceHost 必须绝对地址两个硬坑、Web端 key 打 restapi 必回 10009 的误判、node:sqlite/备份脚本写法、宝塔 + nginx + PM2 部署清单与已验证的构建产物数据。"
status: "active"
created_at: "2026-10-22T01:17:57.794Z"
updated_at: "2026-10-22T01:17:57.794Z"
content_hash: "830887d5d7716ff905bbc832bbf970ac960f540f943116109494a4873d7ecaa5"
source_paths:
  - "server/index.js"
  - "server/db.js"
  - "server/load-env.js"
  - "server/routes/api.js"
  - "server/routes/amap-proxy.js"
  - "server/seed.js"
  - "server/backup.js"
  - "src/components/MapContainer.jsx"
  - "src/components/Search.jsx"
  - "src/api/index.js"
  - "vite.config.js"
  - "DEPLOY.md"
  - "deploy/nginx-gaode.conf"
  - "deploy/ecosystem.config.cjs"
session_ids:
  - "72419a8c-e1b2-405d-91c5-2a123e913be2"
memory_body_ids:
  []
---

# gaode-study-React「拆分组件」：从学习项目到可上线结构（2026-10-22）

工作目录 `D:\WebGIS\web二维开发\高德开发\gaode-study-React - 拆分组件`。前端 React 19 + Vite 8 + Tailwind 3 + 高德 JSAPI 2.0。
原来的问题是：数据靠 json-server（`db.json`、`setTimeout(50)` 补丁），安全密钥 `securityJsCode` 硬编码在前端，等于把密钥交给浏览器。
本轮把它改造成「前端（Vite/dev 或 dist）+ 独立 `server/`（Express 4 + Node 内置 `node:sqlite`）+ 高德安全密钥代理」的可部署结构。

## 1. 后端结构

| 文件 | 职责 |
|---|---|
| `server/index.js` | Express 入口：挂 `/api`、`/_AMapService`，可选托管 `dist`；`PORT`/`HOST` 读环境变量 |
| `server/db.js` | 用 `node:sqlite` 打开 `server/data/app.db`，零原生依赖 → 宝塔不会因编译失败卡住 |
| `server/load-env.js` | 自己读 `server/.env`，不引入 dotenv |
| `server/routes/api.js` | 历史 POI 增删查 + `/api/health`；`toPoi(row)` 做行→DTO，`parseLocation(loc)` 解析 `"经度,纬度"` |
| `server/routes/amap-proxy.js` | 高德 Web 服务代理：把 `/_AMapService/*` 转发到 `https://restapi.amap.com/*` 并追加 `jscode` |
| `server/seed.js` | 把旧的 `api.json` 导入 SQLite，按 `poi_id` 去重（9 条 → 4 条） |
| `server/backup.js` | 在线热备份到 `server/data/backups/`，按时间戳命名，保留最近 14 份 |

接口：

| 方法 | 路径 | 行为 |
|---|---|---|
| GET | `/api/health` | 自检：返回记录数与运行时长（部署验收用） |
| GET | `/api/historical-poi?limit=50` | 按 `updated_at` 倒序 |
| POST | `/api/historical-poi` | 新增；同 `poi_id` 已存在则**只更新时间**，避免全局共享时刷重复 |
| DELETE | `/api/historical-poi/:id` | 删单条，命中 204 / 未命中 404 |

历史记录是**全局共享、无鉴权**的（服务端只有一个池子，不再按浏览器 localStorage 隔离）。这是有意的取舍：换设备/换浏览器能看到同一条轨迹；代价是线上任何人可删，若对外开放需要加 `ADMIN_TOKEN` 之类的口令保护（本轮未做，留作待定项）。

## 2. 三个实测踩过的坑（最重要）

### 2.1 `serviceHost` 必须是绝对地址

`window._AMapSecurityConfig = { serviceHost: '${location.origin}/_AMapService' }`。
写成相对路径 `/_AMapService` 时，JSAPI 会弹「使用 JSAPI 安全模式，代理服务请以_AMapService 作为一级路由」并**阻断地图初始化**（实测 `canvas:false, containerChildren:0`）。改成绝对地址后 `alerts: []`，`canvas:true`，容器有子节点。
即：`VITE_AMAP_SERVICE_HOST` 也要给绝对地址，兜底用 `${window.location.origin}` 拼接。

### 2.2 代理不能重新拼 query，必须原样透传

第一版用 `URLSearchParams` 重新序列化，结果 `/v3/geocode/regeo` 的 `location=经度,纬度` 逗号被编码成 `%2C` → 返回 `INVALID_USER_KEY`；而 `place/text`、`weather/weatherInfo` 却工作正常，极易误判成「key 有问题」。
修法：拿原始 `req.originalUrl` 的 query 原样拼到 `https://restapi.amap.com` 后面，再追加 `jscode`。验证方式是在页面里 hook `fetch`/XHR，把实际发出的 `/_AMapService/...` URL 打出来核对。

### 2.3 Web端(JS API) key 直接打 restapi 一律 `10009 USERKEY_PLAT_NOMATCH`

手工 curl `restapi.amap.com/v3/...?key=<Web端key>` 必然返回 10009，这**不是配置错**：该 key 只允许 JSAPI 自带参数经代理转发。只有走 `/_AMapService` + 服务端补 `jscode` 才通。别被手工 curl 的结果带偏。

## 3. 前端改动

- `src/api/index.js`：baseURL 改为 `import.meta.env.VITE_API_BASE || '/api'`，并修掉原第 24 行 URL 里带空格的 bug、去掉 `setTimeout(50)`。
- `src/components/MapContainer.jsx`：删掉 `securityJsCode`，只保留 `serviceHost`。
- `src/components/Search.jsx`：修 `poi_id: item.poi_id || item.id` 的隐性 bug —— 历史记录里的本地数字 id 会被当成高德 `poi_id` 再插一条重复数据。
- `vite.config.js`：`/api`、`/_AMapService` 代理到 `127.0.0.1:3000`，让 dev 与线上链路一致。
- `.env.local` 只有 `VITE_AMAP_KEY`（Web端 key，公开、靠域名白名单）与 `VITE_API_BASE`；`.env.example` 可提交。

**安全结论**：`VITE_` 变量会被 Vite 内联进 `dist` 的 js（同 Translation 项目的实测结论，见文档 `60592d56-a0fc-4a32-bd93-1bf0fcabea37`），所以能真正藏住的只有 `jscode`——它现在只存在于服务器环境变量里。构建后扫描产物确认：**不含 `securityJsCode`**，只含公开的 Web 端 key，且带 `serviceHost` 路径。

## 4. `node:sqlite` 与备份脚本的两个写法教训

- `node:sqlite` 需 **Node ≥ 22.13**（免 `--no-wasm`/flag），本机 v24.16 可用；低版本会直接报模块不可用 → 宝塔 Node 版本管理器要装 22.14+ 或 24。
- 备份要写成**模块级函数** `backup(db, path)`，不要指望 `db.backup()`。首版写成 `await db.backup(target)` 连续两次 `TypeError: db.backup is not a function`。
- 时间戳原先用 `toISOString().slice(0,10)` 之类拼出 `app-2026-10-22-01-16-34.db`，与本地时区/排序不一致；改成手写 `pad()` 生成 `app-20261022-091639.db` 这种紧凑可排序格式。实测产出 `server/data/backups/app-20261022-091639.db`（20480 B）。

## 5. 已验证结果（可作为回归清单）

| 项 | 结果 |
|---|---|
| `/api/health` | `{"ok":true,"poi":4}` |
| POST 去重 | 同 `poi_id` 再提交，id 不变、只更新时间 |
| DELETE | 命中 204 / 未命中 404 |
| 地图链路（dev :5173，走 `/_AMapService`） | 逆地理编码 `complete/OK`、POI 搜索 62 条、天气「晴 4℃」 |
| 构建 | `dist` 主包 266 KB（gzip 87 KB），675–756 ms |
| 生产托管 | Node 托管 `:3000` 打开正常，`serviceHost` 自动变成 `http://localhost:3000/_AMapService`，代理请求全部成功 |
| 产物扫描 | 无安全密钥；`/` 200、js 200、未知路径 404 |
| lint | 0 error，5 warning（多为 `react-hooks/exhaustive-deps` 与失效的 `eslint-disable`） |

## 6. 部署（宝塔 + 腾讯云，详见 `DEPLOY.md`）

1. 宝塔 Node 版本管理器装 Node 22.14+/24（`node:sqlite` 门槛）。
2. 建站，根目录指向 `dist`，开 SSL + 强制 HTTPS（浏览器定位要求 HTTPS）。
3. 把 `deploy/nginx-gaode.conf` 的两段 `location`（`/api`、`/_AMapService`）贴进站点配置，反代到 `127.0.0.1:3000`。
4. `cp server/.env.example server/.env` 填 `AMAP_SECURITY_CODE`，`chown -R www:www server/data`。
5. 宝塔「Node 项目」：目录 `server`、启动文件 `index.js`、端口 3000、用户 `www`；也可用 `deploy/ecosystem.config.cjs` 走 PM2。
6. `npm run seed && npm run build`，再 `curl 域名/api/health` 验收。
7. **去高德控制台作废旧 key/旧安全密钥**（旧值已进 git 历史），新 key 绑域名白名单。

## 7. 遗留待定

- 删除接口无鉴权，是否加 `ADMIN_TOKEN` 需用户决定。
- 旧高德 key 作废必须用户本人操作，agent 无法代做。
