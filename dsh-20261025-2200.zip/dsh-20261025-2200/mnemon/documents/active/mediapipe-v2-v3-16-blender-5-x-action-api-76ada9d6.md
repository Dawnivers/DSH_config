---
id: "76ada9d6-3534-48c4-9bda-72faeb3e1573"
title: "MediaPipe 动捕 v2→v3 收敛与落地：16 骨驱动集、时间平滑、限速，及 Blender 5.x Action API 变更"
description: "D:\\mocap 视频动捕链路的收敛与落地阶段：v2/v3 三轮修复的实测数字（逐帧跳变 v1→v2→v3）、驱动集从 20 缩到 16 骨的依据、Blender 5.2 slotted Action 无 .fcurves 的兼容写法、关键帧写入与网格形变的验证证据、场景复原纪律，以及交付时仍存在的六项缺陷。"
status: "active"
created_at: "2026-10-16T14:52:07.699Z"
updated_at: "2026-10-16T14:52:07.699Z"
content_hash: "eac4bc474fe35cfcae6f2822d6c63c47ca3daadcc2aced2d4a71e8aa1fea4ca8"
source_paths:
  - "mocap/retarget_compute.py"
  - "mocap/apply_and_render.py"
  - "mocap/video_to_joints.py"
session_ids:
  - "02aa7a0e-75b0-4e08-baed-5acbf2e126a0"
memory_body_ids:
  []
---

# 视频动捕 v2→v3 收敛与落地（2026-10-16 第二轮）

上游见 `c16da0c6-1c61-4678-a995-db2ed3fc734e`（v1 实现 + 噪声诊断：短线段噪声、rig 静置屈膝姿态、sys.exit 事故），方案论证见 `16979651-4dbf-4432-8bc0-29541f6fc50f`，rig 骨骼/坐标陷阱见 `065c7b95-72ee-4323-96c0-2a5b179e432e`。本文只记**收敛与落地这一步新增的东西**。

## 1. 结论

链路已端到端打通：网络舞蹈视频 → MediaPipe Tasks → 方向匹配重定向 → 写入 Chisa 骨架关键帧，并用逐帧包围盒证明网格真的在形变。数字上收敛（16 骨里 15 根进入 12–35°/帧）。

## 2. 修复策略与其依据（不是试参数，每条对应实测根因）

| 修复 | 依据 |
|---|---|
| **驱动集 20 → 16 骨**：砍掉 `LClavicle/RClavicle`、`LHand/RHand`、手指与脚趾 | 锁骨源线段仅 14.6 cm、方向散布 p95 = 147.5°（≈随机）；腕→食指 6.5 cm、单帧 >90° 翻转 39 次。改为 `basis = identity` 跟随父骨，视觉上远好于乱翻 |
| **landmarks 5 帧滑动平均**再算方向 | 治短线段抖动的主药 |
| **短线保护 `min_segment_m = 0.08`**：线段短于 8 cm 时保持上一帧方向 | 朝镜头的投影退化帧不参与方向解算 |
| **转向限速 `turn_limit_deg_per_frame = 40`** | 抑制阶跃式翻转 |
| **输出四元数 3 抽 slerp 平滑**，QC 改在**最终**关键帧上量 | 旧 QC 用"绝对角度"是错误判据（该 rig 静置姿态本身是屈膝坐姿，天生偏 87°），真正该看**逐帧最大跳变** |

最终驱动集（父先子后）：`Pelvis, Spine, Spine1, Spine2, Neck, Head, LUpperArm, RUpperArm, LForearm, RForearm, LThigh, RThigh, LCalf, RCalf, LFoot, RFoot`。

## 3. 三轮收敛实测（逐帧最大跳变 °/帧，越小越好）

| 骨 | v1 | v2 | v3 |
|---|---|---|---|
| LUpperArm | 302.3 | 99.1 | **22.0** ✅ |
| RUpperArm | 302.7 | 73.5 | **20.5** ✅ |
| RForearm | 267.5 | 107.2 | **34.7** ✅ |
| LThigh | 74.2 | 14.2 | **12.2** ✅ |
| RThigh / LCalf / RCalf / LFoot / RFoot / Neck / Pelvis | 74–117 | — | **≤ 24.1** ✅ |
| LClavicle（v1 300°/帧） / LHand（197°/帧） | 炸 | **不再驱动** | ✅ |
| **LForearm** | 235.9 | 139.9 | **66.1** ⚠️ 仅剩这一根 |

自检始终不变：`selfcheck_max_dir_err ≈ 2.6e-6`、`det_R_sa = 1.0`。v3 的 `held_turn` 计数（RForearm 115 帧、RUpperArm 75 帧被限速）反过来成为「MediaPipe 手臂交叉时左右手认反」的量化证据 —— 平滑治不了阶跃错认，需要时序一致性后处理。

## 4. Blender 5.x Action API 变更（踩过一次，别再踩）

Blender 5.2 用新版 **slotted Actions**，`Action` 对象**没有 `.fcurves`**，AttributeError；fcurve 改在 layers → strips → channelbags 下。`apply_and_render.py` 已写成**新旧两种 API 兼容**，并用 `try/finally` 保证渲染失败也能复原场景、且脚本可重复执行。

## 5. 落地验证证据（`mocap/apply_and_render.py`）

- action `mocap_dance_v3`：**7328 个关键帧 / 64 条 fcurve**（16 骨 × 4 分量）/ **29312 个关键点** = 64 × 458，一个不差。
- **回读误差 `max_eval_err = 0.0`**（逐位一致，抽样 Pelvis f1/f230/f458 与 Spine f1）。
- **网格形变证据**（比"姿势看着对"强）：变形包围盒 X 跨度 第 1 帧 0.69 m → 第 229 帧 **1.02 m**；三帧身高 1.50/1.52/1.50 m；包围盒中心漂移 7.3 cm。
- 渲染纪律：**全程只渲 3 张 320×320 验证图**（`D:\mocap\renders\pose_f001/f229/f458.png`），看完即弃。
- **场景复原**：临时相机已删、相机回 `Camera`、引擎回 EEVEE、分辨率回 1920×1080 —— 对用户场景只做两件事：写该 action、改帧范围（**副作用：帧范围被改成 1–458，原为 1–250**）。

先核对再计算的做法值得复用：重新 dump `rig_rest.json` 与上一版差分，得 `max_head_tail_delta = 0.0`、`max_quat_delta = 0.0`，确认用户新开的文件骨架逐位一致后才开算。

## 6. 交付时仍存在的六项缺陷（先说清，避免验收落差）

1. **LForearm 66°/帧**跳变 —— MediaPipe 手臂交叉时左右手认反（阶跃错，平滑无效）。
2. **右臂 115 帧触发限速** → 真实动作被"按住"，比原视频迟钝（保稳定换的代价）。
3. **无根位移** —— 世界地标以胯为原点，角色只能原地跳。
4. **只匹配方向、不控 twist/roll** —— roll 来自静置姿态。
5. 锁骨 / 手 / 手指 / 脚趾不驱动。
6. **脚会滑**（无 IK 落地锁定）。

动作 `mocap_dance_v3` **仅在内存、未存盘**；用户按空格即可播放。

## 7. 下一步选项（用户未选）

① 用户先播一遍看效果（免费）；② 加左右手一致性检查 + 放宽限速修手臂（2–3 轮）；③ 转 B 路线 GVHMR 求世界坐标 + 根位移（需用户本人申请 SMPL/SMPL-X 许可，GB 级依赖）；④ 脚部 IK 治滑步；⑤ 上网页 —— 但 376 关节蒙皮的 WebGL uniform 上限那堵墙仍在（见 `7ef18a4e-8175-45fa-a008-a62bf4b59cb4`）。
