---
id: "16979651-4dbf-4432-8bc0-29541f6fc50f"
title: "舞蹈视频 → 3D 动捕 → Chisa 骨骼动画：可行性与分阶段方案（含 blender-mcp 通道现状）"
description: "面向「下载网络舞蹈视频、提取人体骨骼、让本地 Chisa（376 骨 Blender rig）做同样动作」的可行性与风险评估：难点不在姿态估计而在重定向；含 GVHMR/WHAM/TRAM/MediaPipe 等方案现状、为何不装 MCP 插件（已有任意 Python 通道、插件 auto_start 默认 True）、关键帧如何顺带解决 glTF rest-pose 丢姿态、以及 P0–P3 分阶段成本控制计划。"
status: "active"
created_at: "2026-10-16T13:47:14.890Z"
updated_at: "2026-10-16T13:47:14.890Z"
content_hash: "a4426f7e79306f9b2a1c8d1ae549532a552c2987aa5e3c0cf1f7ac4d4032bd0b"
source_paths:
  []
session_ids:
  - "75fd71df-583e-4dc8-a478-a9baab736f3f"
memory_body_ids:
  []
---

# 舞蹈视频 → 3D 动捕 → Chisa 骨骼动画：可行性与分阶段方案

**适用场景**：用户要求"读网络视频里的舞蹈、提取骨骼、让本地模型做同样动作"。本文是**可行性判断 + 方案选型 + 成本分期**，不是已执行的实现记录。

**结论**：能做。但用户预设的难点（"视频→骨骼"）恰恰是最不缺方案的一段；真正的风险在**重定向到本地 rig**。

---

## 1. 四条管道与真实难度分布

| 段 | 干什么 | 难度 | 现成方案 |
|---|---|---|---|
| ① 拿视频 | 下载 + 解码 | ★ | `yt-dlp` + ffmpeg（本机有代理，网络非瓶颈） |
| ② **视频 → 3D 骨骼** | 单目姿态估计 | ★★★ | 方案最成熟（见 §2） |
| ③ **重定向到本地 rig** | 骨骼映射 + 姿态差 + 比例 + 脚部 IK | **★★★★★** | Blender 侧有插件，但本 rig 有已知地雷（见 §4） |
| ④ 播放/导出 | glTF / 网页 | ★★★ | 376 关节老坑（见 §4） |

**核心判断**：② 是最好解决的一段，③ 才是会卡住的地方。**姿态估计是纯数值的**——一个关节一个坐标，不需要"看"视频。

## 2. ② 段的方案现状（已核实存在）

- **[GVHMR](https://github.com/zju3dv/GVHMR)**（ZJU3DV，SIGGRAPH Asia 2024 → TPAMI 2026）：单目视频恢复**世界坐标 + 重力对齐**的 3D 人体运动；"重力对齐"正好治单目通病。已有社区把它包成 [ComfyUI-MotionCapture](https://www.reddit.com/r/StableDiffusion/comments/1p4pkbk/release_comfyuimotioncapture_full_3d_human_motion/) 端到端流程。
- **[WHAM](https://arxiv.org/html/2312.07531v1)**（CVPR 2024，[主页](https://wham.is.tue.mpg.de/)）：针对移动相机下的世界坐标轨迹与**脚底打滑**。
- **TRAM**：长视频、in-the-wild 的全局轨迹 + 局部动作。
- **便宜的对照**：[MediaPipe Pose Landmarker](https://developers.google.com/edge/mediapipe/solutions/vision/pose_landmarker/python)：33 个 3D landmark，**CPU 即可跑**，适合先跑通管道；但它是"从 2D 抬升"，无世界坐标、抖动、脚会飘，不适合出成品。
- 在线商业：Rokoko Video/Vision、Plask、DeepMotion——花钱省事，直接吐 FBX/BVH。

## 3. ③ 段的 Blender 生态与"不要额外装插件"的理由

**通用套路**：骨骼映射表 + 静置姿态差补偿 + 比例缩放 + 脚部锁定。现成工具：[Cgvirus 免费 retarget 插件](https://www.blendernation.com/2021/08/17/retargeting-any-motion-capture-data-in-blender-addon-and-tutorial/)（Mixamo / BVH / iClone → Rigify / Daz / 自定义 rig）、[Rokoko 重定向流程](https://www.rokoko.com/insights/ace-retargeting-in-blender-with-this-simple-workflow-i-the-ultimate-retargeting-guide)、付费 [BlendCap](https://superhivemarket.com/products/blendcap)；社区还有 [ahujasid/mcp-for-blender](https://github.com/ahujasid/mcp-for-blender)（原 blender-mcp）、[maghonemi/blender-mcp](https://github.com/maghonemi/blender-mcp/blob/master/ANIMATION_SPEC.md)（带 `ANIMATION_SPEC.md` 的动画向分支）。

**为何本机不需要装任何 MCP 插件（重要结论）**：现有通道已是「**在运行中的 Blender 进程里执行任意 Python**」，而任何 MCP 插件内部都只是"调 bpy 的某个函数"。
→ **「任意 Python」⊇「任何插件的工具集」**；装插件反而把能力锁进它暴露的固定操作集里，属于降级。

**通道现状（已核实）**：
- 插件 `blender_mcp.py` 的 `Scene.blendermcp_auto_start_server` 属性 **`default=True`**，即**一开 Blender，9876 端口自动起服务**，无需手工点击（源码亦支持手动开关与 `_user_stopped_server` 记忆）。
- 当次检查时 Blender 未运行、9876 未监听；工作区最近改过的 `.blend` 均为 `backup_before_*.blend`，说明先前改动走的是备份式操作。
- 最近打开文件（`recent-files.txt`）中相关项：`D:\Blender\assets\trainAndChisa.blend`（列车 + Chisa）、`D:\Blender\assets\train.blend`。

## 4. 本 rig 的已知地雷（沉淀自既有记录，必须提前规避）

- **376 根骨骼、大量辅助骨**（如 `Bip001LCalf_0280`）头位于**世界原点**、长度极短——naive 骨骼映射会直接崩；详见文档 `cd47800f-18e5-43e4-b6c6-fa223c7432a7`。
- **骨架轴 ≠ 世界轴**（本例 骨架 Z=世界 Y、骨架 Y=世界 −Z）——重定向旋转必须做坐标系换算，否则整个动作是歪的；同见 `cd47800f`、`5817151f-e256-4cec-a192-8d77cd1671a6`。
- 需先**筛出真正的人形子集**（hips/spine/arm/leg），这要先 dump 骨骼清单与层级。
- **终点若是网页**：Cesium 1.97 按关节数声明 `u_jointMatrices`，376 关节超出 WebGL 顶点 uniform 上限（376×4=1504 个 vec4）导致蒙皮图元被**静默丢弃**；详见 `7ef18a4e-8175-45fa-a008-a62bf4b59cb4`。

## 5. 一个顺带的收获：关键帧正好解 glTF 丢姿态的坑

既有记录指出 `export_scene.gltf` 默认 `export_rest_position_armature=True`，"只摆姿势、没有关键帧/动作 → 姿态被整个丢弃"（`7ef18a4e`）。

**打关键帧本身是 Blender 最基础的操作**，本质三行：

```python
pb = arm.pose.bones["Thigh.L"]
pb.rotation_quaternion = q                    # 第 1 帧姿势
pb.keyframe_insert("rotation_quaternion", frame=1)
# 改 q → keyframe_insert(frame=40) → Blender 自动插值 → 模型动起来
```

→ **做动画不只是"让它动"，还是"让姿势能带出去"的正解**：有了 action，导出器才有东西可导。

## 6. 质量预期（别被宣传骗）

单目视频 → 3D → 任意 rig 的典型症状：**脚底打滑、抖动、比例怪、手穿模**。"看起来像在跳"与"能交付"之间隔着大量清理（脚部 IK 锁定 + 曲线平滑 + 手工修 F-Curve）。

## 7. 分阶段计划（P0–P3，每阶段可停）

| 阶段 | 内容 | 成本量级 |
|---|---|---|
| **P0 只读侦察** | dump Chisa 的骨骼清单、层级、命名规范、静置姿态、已有 action/fcurve、帧范围——**一轮脚本拿全，不写 probe2.py** | 几分钟，几毛钱 |
| **P1 离线动捕** | 装 GVHMR（或先用 MediaPipe 跑通），拿一段短舞蹈出 BVH | 一次，可能几十分钟 |
| **P2 重定向** | 映射 + 坐标变换 + 比例，数值验证 | **最容易烧钱的一段** |
| **P3 精修导出** | 脚部锁定、平滑、导出；上网页则再面对 376 关节问题 | — |

**成本纪律**：这是多小时、多轮、GPU 密集的活儿，比单次低价会话更容易烧钱——**每阶段一个脚本 + 数值回读验证**；**全程不渲染图片**，除非用户明确要求渲给他看。

**硬件前提**：本机有 NVIDIA 独显（GeForce Overlay），P1 装 torch + 跑模型可行，但需下载数 GB 依赖与权重，**要有时间心理准备**。

## 8. P0 的判别价值（决定"半天"还是"一周"）

- 若 Chisa 是 **Mixamo 风格命名**（`mixamorig:Hips` 或 `Hips / Spine / LeftArm / LeftUpLeg …`）→ ③ 段难度**降一个数量级**，BVH→Mixamo 映射现成可脚本化。
- 若是自定义命名（现有证据指向 `Bip001` 系列）→ 需人工核对映射表，P2 明显更贵。

## 9. 尚待用户拍板

1. 目标是 Chisa（`trainAndChisa.blend`）还是别的模型？
2. 终点是「Blender 里能播」还是「网页里也能播」？（后者需先解决 376 关节蒙皮）
3. 有没有指定的视频（链接或本地文件）供 P1 直接跑？

> 注：P0 只读侦察与终点选择无关，可先行执行。
