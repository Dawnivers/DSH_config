---
id: "e4980b77-d459-420c-811f-8bd0cee77a36"
title: "Translation 发展历程：生长线关闭流线的落地（方案 A）——必须用 flowLength=0 而非 flowIntensity=0，含副效应与验证局限"
description: "2026-10-12 落地「生长线只生长、不跑流线」：唯一正确关闭点是 flowLength=0（分支恒不成立），flowIntensity=0 反而跑出一条黑带；改动仅 historyPanel.vue 传参并删掉无意义的 flowOffset；并记录关流线后线变细变暗（glowPower/taperPower 可补）与像素 A/B 验证在本场景不可用的原因（远景瓦片 LOD 漂移 2.5~3%、运行时改自定义材质属性似不重绘）。"
status: "active"
created_at: "2026-10-12T10:39:53.717Z"
updated_at: "2026-10-12T10:39:53.717Z"
content_hash: "b0aa9e3e8e391f6cd95a9979630158bb2a583135967c6ef62da6412e2e2db880"
source_paths:
  - "Translation/src/components/bottom/HistoryPanel/historyPanel.vue"
  - "Translation/src/cesiumTools/lineAndpoints/line/PolylineFlowMaterialProperty.js"
  - "Translation/src/cesiumTools/lineAndpoints/line/polyGlowflow.glsl"
  - "Translation/src/cesiumTools/lineAndpoints/line/setlines.js"
session_ids:
  - "eb0fafaf-b306-41e1-9fe0-f76cf70b450c"
memory_body_ids:
  []
---

# 生长线关掉流线：方案 A 的落地记录

日期：2026-10-12。项目：`D:\WebGIS\web三维开发\智慧地铁项目\Translation`。

前因与根因诊断见文档 `a1513ccf-8374-4c20-9a66-3ecb52505879`（该文停在「三方案抛给用户、未落地」）。
用户在 A/B/C 中直接选了 **A（关掉流线，只留生长）**，本文件只记录**落地之后新得到的东西**。

生长动画本体、端点夹首尾、验证中抓到的 3 个 bug 见 `bed0b7b7-e1e3-491b-80bd-51ffa66f4956`；
`[lo,hi]` 区间模型见 `507aed4a-c907-4012-b6ae-69aadb2f8edb`。

## 1. 改动只有一处

`historyPanel.vue` 里造私有实体时加参：

```js
growthEntity = renderLines(viewer, {
  positions: line.positions,
  color: line.color,
  name: line.name,
  flowLength: 0,        // ← 关掉流动高亮段（唯一的正确关闭点，见第 2 节）
});
```

顺便删掉两个已无意义的字段：`flowOffset`（流线关了，相位无从谈起）和 `lines` 里没人用的 `index`。
因为参数是**建线时传进去**的，材质从第一帧起就是「没有流线」的状态，不需要任何运行时切换。

## 2. 关键陷阱：**不能用 `flowIntensity: 0` 关**（会跑出一条黑带）

直觉上「亮度乘数置零」应该等于关掉，实际更糟 —— 看 `polyGlowflow.glsl:40-45`：

```glsl
if (st.s > iTime && st.s < iTime + flowLength) {
    alpha = smoothstep(iTime, iTime + flowLength, st.s);
    material.emission *= flowIntensity;   // ← 乘 0 把发射光清零
}
material.alpha = alpha;                   // ← 但 alpha 仍被拉满
```

`flowIntensity: 0` 让该段发射光变 **0**、`alpha` 却拉满，结果是线上多一条**黑带**在跑。
真正管用的是 `flowLength: 0`：条件退化成 `st.s > iTime && st.s < iTime`，**恒不成立**、整支不执行。
这条已写进代码注释，防止后人「顺手」改成 `flowIntensity`。

（同类教训：这个材质里 `st.s` 是**当前渲染折线**的归一化弧长，任何按比例变化的参数都会随生长被扭曲，
详见 `a1513ccf` 第 3 节。）

## 3. 副效应：关掉流线后这条线明显变细、变暗（**尚未处理**）

平时线路的亮度有相当一部分来自流线高亮段；关掉后只剩基础泛光。`renderLines` 的相关默认值：

| 参数 | 现值 | 作用 |
|---|---|---|
| `glowPower` | 0.5 | 线横截面中心亮带亮度，调大更亮 |
| `taperPower` | 0.05 | 沿长度两端锥形淡出，<1 两端强渐隐；调到 ~0.5 更「实」 |

当时给出的补偿建议是 `glowPower: 1.2, taperPower: 0.5`，**用户尚未答复是否要试**。这是下次可继续的点。

## 4. 验证方法与它的局限（比结论更值得复用）

**可信的三条证据**：

1. 运行时从实体上读材质参数：`{ flowLength: 0, flowIntensity: 1, flowSpeed: 0.3, glowPower: 0.5 }`；
2. 着色器分支恒不成立（纯代码推理）；
3. 贴着线路约 1.5km 拍的特写截图，线上是均匀一条线、没有跑动亮带。

**没能做成的验证**：本想用「同位置连拍两张比像素」做 A/B，失败原因有两条，以后再想用像素差做证据要先看：

- **远景下场景自身漂移就有 2.5~3%**（瓦片 LOD），比流线占的像素比例还大 —— 背景噪声淹没信号，
  这种对比在远景**无判别力**（改前实测基线 drift 18.8%、开/关各 ~3%，无法归因）；
- 拉近后漂移降到 0，但**运行时改这个自定义材质属性似乎不触发重绘**（改了 `flowLength` 画面不变）。
  也就是说：`PolylineFlowMaterialProperty` 只适合**构造时传参**，不适合当运行时开关来验证。

另有一个写 `page.evaluate` 时的坑：直接返回 Cesium 对象会报
`Cannot serialize result: object reference chain is too long`，只返回普通 JSON 标量。
