---
id: "979eb2d7-7e66-4046-944a-52cd4f5c884c"
title: "Translation 智慧地铁：系统级图片光标皮肤（方案 A）+ 全屏沉浸模式交接"
description: "2026-10-07 后续两轮改造：鼠标皮肤从 DOM 跟随改为浏览器系统级 PNG 光标（含性能实测依据、CSS 变量与!important 压过 Cesium 行内 cursor），光标关闭语义改为「彻底隐藏」而非恢复系统默认；并新增全屏沉浸模式（screenState store、App.vue v-show 隐藏 HUD、原位退出按钮与提示浮窗、三条退出路径）。本文取代 715e6684 的鼠标皮肤实现细节。"
status: "active"
created_at: "2026-10-07T13:56:10.139Z"
updated_at: "2026-10-07T13:56:10.139Z"
content_hash: "b59b6190f145571e95171487dd56e53d820c4ded911fd2c337ef6f7873512bd9"
source_paths:
  - "Translation/src/components/screenUI/foot.vue"
  - "Translation/src/App.vue"
  - "Translation/src/stores/screenState.js"
  - "Translation/src/assets/cursor-hud.png"
session_ids:
  - "cfa7e514-5a82-4dec-bdb6-5895790d451a"
memory_body_ids:
  []
---

# Translation 智慧地铁：系统级图片光标皮肤 + 全屏沉浸模式

实现日期：2026-10-07（晚），项目根 `D:\WebGIS\web三维开发\智慧地铁项目`，前端目录 `Translation/`。

**取代关系**：本文取代 `715e6684-4186-4c51-82f8-1db889099650` 第 2 节关于鼠标皮肤的**实现细节**（DOM 跟随 `.hud-cursor` + Teleport + rAF 节流 + `cursor: none !important` 那套已作废，本文第 2 节的"关闭=彻底隐藏"是用户最终语义）。该文档的**交互规则（第 1 节）与两个 Vue 过渡坑（第 3 节）仍然有效**。

相关文档：`715e6684-4186-4c51-82f8-1db889099650`（齿轮工具箱交互规则 + 过渡坑）、`fc4a4675-20f3-47bd-9576-90465837c1b9`（工具箱/线路栏架构、EBUSY 坑）、`46077717-b034-4315-a3c1-f04be09fed52`（KeepAlive 与 NODE_ENV 陷阱）、`d6dc91dd-bff2-4971-897a-5b2fe5bf1580`（启动与 `getLine` 接口语义）。

## 1. 为什么指针必须交给系统绘制（性能证据链）

用户抱怨"鼠标怎么那么卡"。实测（Playwright 驱动真 Chrome、AMD 集显、1600×900）：

| 状态 | 帧率 |
|---|---|
| 皮肤开 + 三维在 | 6.6 FPS |
| 皮肤关 + 三维在 | 6.2 FPS ← **皮肤自身开销≈0**（DOM 跟随优化已到位） |
| 皮肤开 + 三维隐藏 | 124.8 FPS ← 页面本体很快 |
| 分辨率降到 0.5 | 11 FPS（几乎无效 → **主线程瓶颈**，非像素填充瓶颈） |
| 关掉 2 个 3D Tiles | 12.8 FPS |
| 再关掉地球影像 | 31.8 FPS |

结论：只要指针由 DOM 绘制，就注定被三维的 6~10 FPS 拖动；**交给浏览器/系统合成器绘制是唯一解**——系统光标重绘与页面帧率彻底无关，"永远跟手"。

## 2. 方案 A：系统级图片光标

- **素材** `Translation/src/assets/cursor-hud.png`（64×64，热区 32,32，5.1 KB）：用 Chrome 把同一套 HUD 准星（金环 + 青菱 + 十字 + 中心辉光）画到 canvas 再导出，并加深色描边保证亮底可见。**Chrome 的 `cursor` 不支持 SVG，只吃位图**——这是走 PNG 的唯一原因；代价是旋转/脉冲动画消失（`715e6684` 里的动效皮肤因此作废）。
- **CSS 写法**（必须写在 **非 scoped** 样式块）：

```css
html.hud-cursor-managed,
html.hud-cursor-managed * {
  cursor: var(--hud-cursor-skin, none) !important;
}
```

- **状态切换**（foot.vue）：`hud-cursor-managed` 类**常驻** `<html>`，只改 CSS 变量：

```js
root.classList.add('hud-cursor-managed');              // 常驻：页面永远由我们接管
root.style.setProperty('--hud-cursor-skin',
  mouseToolOn.value ? CURSOR_SKIN : 'none');           // 开=准星；关=none
```

- **`!important` 的作用**：压过 **Cesium 给 canvas 写的行内 `cursor`**（`grab`/`crosshair` 等）。用户报"关掉后还残留系统默认鼠标"，就是类被摘掉后页面局部（尤其地图区）恢复系统光标的旧写法造成的（`classList.toggle('hud-cursor-none', on)` 关时移除类 → 规则失效）。
- **用户明确语义（2026-10-07）**：页面内只允许两种状态——**皮肤** 或 **彻底隐藏**，绝不出现系统默认光标。关闭路径 = 再点工具图标（提示浮窗「鼠标已隐藏 ESC 按键重新显示鼠标」）/ 按 ESC / 点浮窗本身。
- **读数面板**：右下角常驻 `.hud-cursor-panel`（Teleport 到 body + `v-if="mouseToolOn"`），不再跟随指针——`SCREEN X/Y` + `GEO 经纬度`，`textContent` 直写、GEO 限 10 Hz、画布矩形缓存 1 s。

## 3. 全屏（沉浸）模式

需求（用户原话）：点击全屏时隐藏大屏 panel 组件，并在**全屏按钮原地**显示退出全屏按钮；点按钮或按 ESC 退出（有浮窗提示）。

- **新 store** `Translation/src/stores/screenState.js`（18 行）：`immersive`（状态）+ `exitAnchor`（退出按钮定位锚点）。
- **隐藏 HUD**：`App.vue` 用 `<Panel v-show="!immersive" />`——**必须 `v-show` 不能 `v-if`**。`foot.vue` 挂着光标皮肤、齿轮工具栏、全局 ESC 监听，卸载会把它们一并带走，全屏里鼠标皮肤会失效。
- **退出按钮 `.immersive-exit`**：由 `App.vue` Teleport 到 body，位置取「进入时那颗工具按钮的 rect」换算成**距视口右下角的距离**（进入浏览器全屏后视口尺寸会变，用右下角锚定才不会跑位；实测进入前 (1340,821) → 进入后 (1337,806)）。提示浮窗 `.immersive-hint`「已进入全屏模式 ESC 退出全屏」同处渲染。
- **三条退出路径**：点按钮 / 按 ESC（`App.vue` 自己接 keydown 兜底，因为 HUD 隐藏后全屏状态归 App 管）/ 浏览器 `fullscreenchange` 同步（用户用系统方式退出时内部状态不卡住）。
- 进入时同时 `documentElement.requestFullscreen()`（**被拒不影响沉浸效果**——HUD 隐藏逻辑不依赖浏览器全屏）。
- `foot.vue` 的「全屏模型」工具 `ready=true` → `enterImmersive()`。
- **小重叠修复**：全屏时读数面板加 `.is-immersive` → `bottom: 62px`，避免压住右下角退出按钮。

## 4. 验证证据（Playwright 真 GPU，页面无报错）

逐元素取样 `cursor` 计算值：

| 取样点 | 工具开 | 工具关 |
|---|---|---|
| `<html>` / `<body>` / Cesium `<canvas>` / 导航按钮 / 齿轮 | `url(cursor-hud.png) 32 32, crosshair` | **none** |
| 右下角读数面板 | 皮肤（面板已隐藏时不取样） | — |

`hud-cursor-managed` 类在三个状态下均存在 ✓；素材 `HTTP 200 image/png 5132 bytes` ✓；ESC 恢复后全部回到皮肤 ✓。

全屏流程五步实测：初始 → 点「全屏模型」（HUD 隐藏、退出按钮出现、提示浮窗文案正确、`document.fullscreenElement` 为真）→ ESC 退出（HUD 回来，全屏为假）→ 再进入 → 点退出按钮退出，全部通过。

## 5. 已知遗留（本次未做）

1. **场景帧率**：三维把整页压到 ~6.5 FPS，拆账为 3D Tiles 约一半、地球影像约一半；降分辨率无效 → 主线程瓶颈。可选方向：tileset `maximumScreenSpaceError`、底图换静态瓦片、`requestRenderMode` 按需渲染（"方案 C"）。
2. **腾讯地图瓦片 400**：`rt0/1/2.map.gtimg.com/tile?...&styleid=4` 整层 400，底图实际靠 ArcGIS 那层撑着（原有问题，未改）。
3. 全屏工具按钮的"选中态高亮"未做（Panel 整体隐藏，按钮本身也看不见，看起来就是"按钮换成退出按钮"）。
