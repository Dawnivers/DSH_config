---
id: "4b7d494f-5c4b-4c71-8ea5-80f19359a2cb"
title: "DSH 代码索引/上下文方案选型调研：原生插件 vs MCP 桥接（含证据与反方修正）"
description: "在 DSH 0.2.0-rc.2 宿主要装什么来提升代码理解：dsh-code-index / dsh-codegraph / ast-grep-mcp·Serena 三层推荐，MCP 桥接的 token 税依据，被否方案（claude-context、codebase-memory-mcp、dsh-code-intel）的原因，embedding 对代码的真实证据边界，以及装前审源码的流程与风险。"
status: "active"
created_at: "2026-10-08T01:10:21.566Z"
updated_at: "2026-10-08T01:10:21.566Z"
content_hash: "1cd528d4567a751ef7f31c7c4ef454f7e3964aea3711294d5104f3d06424c3c1"
source_paths:
  []
session_ids:
  - "64c32626-bdd7-4dfb-9df7-e00c88a715b3"
memory_body_ids:
  []
---

# DSH 代码索引 / 代码上下文方案选型调研

日期：2026-10-08。议题：用户想在 DSH 里让 agent「动手前就拿到相关源码上下文」，据此调研 DSH 生态里的代码索引插件与 MCP 方案，并给出可执行的接入顺序。

宿主版本闸门与内置 `@deepseek-ai/dsh-mcp-client` 的接线字段（stdio / streamable-http、`mcp__<serverName>__<tool>` 命名、`maxInstructionBytes` 等）已单独记录在运行时记忆，本文不重复，只记选型结论与依据。

证据文件（在 DSH 安装目录，不在本工作区内，仅作来源标注）：
- `D:\DSH\dsh_data\DSH Desktop\resources\app\package.json`（宿主与包组版本）
- `D:\DSH\dsh_data\DSH Desktop\resources\app\node_modules\@deepseek-ai\dsh-mcp-client\lib\index.js`（MCP 客户端配置 schema 与工具暴露命名）

## 1. 结论：三层推荐

```
第 1 层  lemonxiny55/dsh-code-index   ← 首选：零依赖、免 embedding、会注入有界仓库地图
第 2 层  jiangzhenguo/dsh-codegraph   ← 需要调用链/影响分析时叠加（依赖全局 codegraph CLI）
第 3 层  ast-grep-mcp / Serena        ← 结构性精确搜索 / 符号级重构
不用     claude-context 类「默认走云 embedding」的方案
```

选型原则：**DSH 原生插件优先于 MCP 桥接**（理由见 §3），且不要为代码默认引入云端 embedding。

## 2. 首选 `dsh-code-index`（v0.9.0，MIT）的关键事实

- **零依赖**：tree-sitter WASM 纯解析，无原生编译、无常驻服务、无 API key、无外部二进制。（这正是它比 `codebase-memory-mcp` 更适合现阶段的原因。）
- **工具面**：`code_map`（有界仓库地图）、`code_context`（招牌：按任务裁剪的上下文包）、`code_refs`（调用图）、`code_search` / `code_symbols`（排名查找）、`code_change_context`（改动感知 + 可能受影响的测试）、`code_health`（循环依赖/孤儿模块）。
- **关键设计**：自动向系统提示注入一段**有界的仓库地图**（`code-index:repo-map`，order 60），排序算法是**导入图上的个性化 PageRank**——专门解决「hub 文件被其他 hub 引用时应排更前」，即 aider / Cline 走通的那条路。
- **预算控制**：`code_context` 返回带**理由**与**来源标注**（`exact` / `import-scoped` / `name-only`）的上下文包，**硬上限 5000 字符**；证据不足时明说「没有」，不编置信度。
- **索引位置与隔离**：
  - 索引落在仓库内部 `<repo>/.dsh-code-index/`（JSON 缓存），**隔离键是「最近的 `.git`」**，不是 DSH workspace id；拿会话 cwd（`agent.session.header.cwd`）向上找 `.git`，**找不到仓库标记的目录不会被索引**。
  - 按**真实仓库路径**认，同一仓库的多个会话**共享同一份索引**（省一次建索引，但意味着隔离粒度是「按仓库」而非「按会话」）。
  - 插件本体是 profile 级、全局唯一，进程内最多保留 **4 个项目上下文**，多仓库时按上下文切换——「每个工作区独立」指**数据与变更状态独立**，不是每工作区跑一份插件。
  - 自动注入的仓库地图跟当前会话工作区；agentless 装配时回退到 DSH 进程工作目录；**新项目第一次 prompt 可能拿到空地图**（索引未建完）。
  - ⚠️ `.dsh-code-index/` 会出现在仓库里，建议加 `.gitignore`（或全局 `core.excludesFile`），否则污染 `git status`。
- **能力边界（别误会）**：❌ 不是类型检查器（parser + 图，无类型推导），函数内局部变量不入索引；❌ 不是语义搜索（**刻意不用 embedding**），「记得意思但不记得符号名」的场景它帮不上；⚠️ >1MB 的文件、以及索引快照后又被改动的文件，读源码时会被拒；大 monorepo 每次调用仍要扫一遍目录元数据（解析是增量的，扫描延迟随仓库大小与磁盘变化）；⚠️ 仅 8 种语言（TS/JS/Python/Go/Rust/Java/C/C++）。

## 3. 走 MCP 是有「税」的（所以原生插件优先）

官方 `dsh-mcp-client` README + 源码实读确认：

- MCP 工具的**描述与 schema 会进入每一次请求**；`mcp__<server>__<tool>` 这种长名还要额外花 token。
- 工具列表一变**可能让 KV 缓存失效**。
- 慢 server 会拖启动。
- `maxInstructionBytes` 决定对方能往系统提示里塞多少字 —— **接第三方 MCP 时唯一需要额外警惕的注入面**。

因此「原生插件 > MCP 桥接」是有依据的选择，不是偏好。

## 4. 被否 / 被下调的方案及原因

| 方案 | 处置 | 原因 |
|---|---|---|
| `claude-context` 类 | 不用 | 默认要 OpenAI key + Zilliz 云；约 3 个月未推；147 个开放 issue |
| `codebase-memory-mcp`（46k★） | 下调 | 安装器会改 agent 配置、装 hooks、起常驻守护进程；Defender 误报。对一个 7★ 生态，性价比不如原生插件 |
| `lonelymoon87/dsh-code-intel` | 装不上 | 唯一带 embedding 路径的 DSH 插件，但 peer 是 `>=0.1.0-rc.6 <0.2.0`，与宿主 0.2.0-rc.2 不兼容；且 0★、11 commits |
| `serena`（30k★）、`ast-grep-mcp` | 备用 | 符号级重构 / 结构性精确搜索，作为第 3 层 |
| `jiangzhenguo/dsh-codegraph`（采用率设计） | 第 2 层 | 能力不如首选但方向一致，需要时叠加 |

## 5. Embedding 对代码：证据比传言更微妙（含一条打脸的自我修正）

- **支持「不用默认云 embedding」的**：代码专用 benchmark **CoREB** 发现**短关键词查询（最接近真实开发者搜索的形态）让所有模型跌到接近零 nDCG@10**；代码专用 embedding 比通用 encoder 强约 **2×**。Cline 的反索引长文核心论据是**索引腐化**——「助手会自信地建议调用已经不存在的函数」。
- **反方（推翻「grep 一定赢」的过度概括）**：被广泛引用的「grep 打败向量」论文（arXiv 2605.15184），**语料是对话问答而非代码，作者自己在论文里声明不适用于代码语义**。拿它证明「grep 对代码更强」是过度解读。
- **诚实结论**：「**通用的切块 + embedding 是个坏默认**」成立；「**embedding 对代码没用**」不成立。要上就上代码专用模型 + reranker。

## 6. 生态结构事实（比插件清单更重要）

1. **DSH 官方没有插件市场。** `dsh-plugin` 那个 GitHub topic 显示的 18,306 个仓库是**被标签灌水灌出来的**，社区维护者自己在 discussion #1045 里警告过；`dsh-plugin.org` 一类站点全是社区运营，自称「Community Official」不代表官方。
2. 好消息：**Desktop 外壳自带社区市场**（`dsh-community-market` + `dshmarket`），加上 profile 里那份 131 条社区清单，够用。

## 7. 风险与未验证项

- `dsh-code-index` 只有 **7★**、单人维护；性能数据全是**作者自报**（其 README 倒很实在地写了「仓库里只有基础设施和样例任务，不含实测性能声明」）。
- **至今没有任何独立第三方做过这几个方案的同仓库横向对比**（两路调研都确认）；Reddit 被反爬挡住，只能看搜索摘要。

## 8. 落地的既定流程（第三方 npm 包 = 要在本机跑的代码，先审再装）

1. `npm pack dsh-code-index@0.9.0` 或 clone 仓库 → 审 `src/`（纯 TS、体量小）、看 `cordis.patch.yml` 注入了什么、**确认没有网络调用**；
2. 审过后再 `dsh plugin --profile desktop add dsh-code-index@0.9.0`；
3. 拿工作区建一次索引，实测：`code_map` 的仓库地图质量、模型行为是否被指引改变、**PageRank 地图实际吃多少 token**（顺便验证 DSH 的工具暴露链路）；
4. 不满意：`dsh plugin --profile desktop remove dsh-code-index` —— 只留一个 `.dsh-code-index/` 缓存目录，删掉即可。

**当前状态**：已完成调研与版本核实，等待用户确认后才开始第 1 步（拉源码审计）。
