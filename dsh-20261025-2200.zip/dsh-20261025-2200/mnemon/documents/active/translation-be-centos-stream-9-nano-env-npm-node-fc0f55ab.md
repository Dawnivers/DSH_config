---
id: "fc0f55ab-66a4-41aa-8d8e-199fd1c953a1"
title: "Translation_BE 部署到 CentOS Stream 9 的实操清单：无 nano 建 .env（格式坑实测矩阵）、npm 锁定、Node≥20.12 与 PG18 版本门槛"
description: "后端真正上 Linux 服务器那一段的可复用操作记录：CentOS Stream 9 最小化安装（只有 vi、无 nano）下用 heredoc/read/vi 建 .env 并 chmod 600，.env 格式坑实测矩阵（BOM 使首行失效、未加引号的 # 被截断、CRLF 与空格无碍、加引号正确），后端是 npm（lockfileVersion 3，用 npm ci）而非 pnpm，NodeSource 装 Node 22 以支持 process.loadEnvFile，PG 18 归档版本与 CentOS 仓库旧版 pg_restore 不兼容，以及 firewalld / SELinux 两个容易卡住的点。补充 cdaa0177 的部署边界与 dump 体检结论。"
status: "active"
created_at: "2026-10-20T10:09:36.020Z"
updated_at: "2026-10-20T10:09:36.020Z"
content_hash: "3f26758e609e5bdafa2d074d25424913bd7ccf7159ee093f12bdaf93ba5f6d78"
source_paths:
  - "Translation_BE/config.js"
  - "Translation_BE/index.js"
  - "Translation_BE/package.json"
  - "Translation_BE/package-lock.json"
  - "Translation_BE/.env.example"
  - "Translation/pnpm-lock.yaml"
  - "Translation/pnpm-workspace.yaml"
session_ids:
  - "da09a297-3334-4196-869b-7deb5b8ec431"
memory_body_ids:
  []
---

# 为什么单独记这份

[cdbee](cdaa0177-267d-4849-814e-19a5b4961664) 已记录「哪些文件上传、服务器上现建 .env、dump 的三个坑」这条**原则层**结论。本文补的是真正照敲那一段的可操作细节：目标是 **CentOS Stream 9 最小化安装**（只有 `vi`，没有 `nano`），并且所有格式类结论都在本地实测过，不是推测。

## 1. 建 .env：CentOS 上没有 nano 的四条路

推荐顺序（都是"服务器上现建"，不从本地传）：

**A. heredoc（不装任何东西，密钥不进 bash 历史）**

```bash
cd ~/Translation_BE
umask 077                 # 新建文件直接就是 600
cat > .env <<'EOF'
PORT=8092
AMAP_KEY=<粘贴高德 Web服务 Key>
AMAP_CITY=021
AMAP_ADCODE=310000
PGUSER=postgres
PGPASSWORD=<粘贴服务器上的库密码>
PGHOST=127.0.0.1
PGPORT=5432
PGDATABASE=Translation
EOF
ls -l .env                # 期望 -rw-------
```

要点：heredoc 正文不进 `~/.bash_history`，只有 `cat > .env <<'EOF'` 这一行进。反例 `echo "AMAP_KEY=xxx" >> .env` 会把密钥原样留在历史里。单值补写用 `read -r -p "AMAP_KEY: " K && printf 'AMAP_KEY=%s\n' "$K" > .env`，输入同样不进历史。

**B. 装 nano**：`sudo dnf install -y nano`（Stream 9 的 baseos/appstream 里有，网络通即可）。

**C. 用自带 vi**：粘贴前必须先 `Esc` → `:set paste` → `i`，否则每行被自动缩进逐层推右，格式立刻废掉；保存 `:wq`，放弃 `:q!`。

**D. 本地 scp 过去**：`scp .env deploy@IP:~/Translation_BE/.env` 后**必须**再 `ssh ... "chmod 600 ~/Translation_BE/.env"`。别走网盘/微信中转。

用 `cp .env.example .env` 起手而非手打：变量名错一个字不会报错，只会静默回落默认值（例如漏 `PGHOST` 就回落 `localhost`，同机部署看着一切正常，换机才暴露）。

## 2. .env 格式坑实测矩阵（Node 24 的 `process.loadEnvFile`，用长度不打印值来验证）

| 情形 | 实测结果 | 处理 |
|---|---|---|
| UTF-8 无 BOM + LF | ✅ 正确读到，`len=32` | 基准 |
| **带 BOM**（记事本"UTF-8 with BOM"另存、Windows 上传） | ❌ **第一行整条失效**，`AMAP_KEY` 读出 `undefined`，**Node 一句错都不报** | 用 `nano`/`vim` 建，或 `sed -i '1s/^\xEF\xBB\xBF//' .env` |
| CRLF 行尾 | ✅ 正常，Node 会处理 | 不用管 |
| **值里含 `#` 未加引号**（如密码 `abc#123`） | ❌ 静默截断成 `abc`，登录失败但看不出原因 | 加引号：`PGPASSWORD="abc#123"`（引号版本实测 ✅） |
| 值里有空格 | ✅ `SPACE="hello world"` 正常 | 加引号即可 |

另：`.env` 里不写 `export`、不用引号包变量名，一行一个 `KEY=VALUE`。

## 3. 校验三步（改完必须重启进程才生效）

```bash
ls -l .env                                   # ① 权限 600、属主=运行 node 的用户
node -e "const c=require('./config.js');console.log('AMAP_KEY len=',c.amap.key.length,'| PGHOST=',c.db.host,'| DB=',c.db.database)"
# ② 期望 AMAP_KEY len= 32；len= 0 → 文件没读到（回看 BOM/引号）
curl -s "http://127.0.0.1:8092/getWeather?city=310000&extensions=base"
# ③ 期望 {"code":200,...,"weather":...}；若 INVALID_USER_KEY → key 没读到，或这把 key 不是「Web服务」类型
```

重启：`systemctl restart translation-be` / `pm2 restart translation-be` / 重跑 `node index.js`。

## 4. 包管理器：后端 npm，前端 pnpm，别混

| 目录 | 锁文件 | `node_modules` 标记 | 结论 |
|---|---|---|---|
| `Translation_BE` | `package-lock.json`（lockfileVersion **3**） | `.package-lock.json` | **npm** |
| `Translation` | `pnpm-lock.yaml` + `pnpm-workspace.yaml` | `.modules.yaml` + `.pnpm/` | pnpm |

锁定关键版本：`express 5.2.1`、`pg 8.23.0`、`cors 2.8.6`。服务器上：

```bash
cd ~/Translation_BE
rm -rf node_modules    # 别把 Windows 上装的 node_modules 传上去
npm ci                 # 严格按 lockfile 装；报 in sync 时临时用 npm install 兜底
```

三条禁忌：① 别在 `Translation_BE` 里跑 `pnpm install`（会生成 pnpm-lock.yaml、把 node_modules 换成符号链接结构，且默认不提升依赖，`express`/`pg` 的间接依赖可能解析不到）；② 别跨平台搬 `node_modules`；③ 别把前端的 `pnpm-workspace.yaml` 混传进后端。npm 随 Node 自带，不需要额外装 pnpm。

## 5. 两个版本门槛（这条链路最容易卡的地方）

- **Node ≥ 20.12**：`config.js` 用 `process.loadEnvFile`（20.12 / 21.7 才有）。低于此版本该 API 为 `undefined`，调用抛 `TypeError`，而它被包在 `try/catch` 里 → **被静默吞掉、`.env` 根本不加载**，只剩一条 `[config] 未配置 AMAP_KEY` 警告。CentOS 9 仓库的 nodejs 偏旧，用 NodeSource：`curl -fsSL https://rpm.nodesource.com/setup_22.x | sudo bash -` 然后 `sudo dnf install -y nodejs`。
- **PostgreSQL 18**：用户那份 dump 是 PG 18.4 写的（归档版本 1.16），CentOS 9 仓库是 13/15/16 系 → `pg_restore` 报 `unsupported version`。要么装 PGDG 的 PG 18，要么改用纯文本导入（`pg_dump -Fp`，约 45.3 KB / 781 行，任何版本 psql 都能导；代价是体积比二进制的 20 KB 大）。
- 另一条已验证的好消息：纯文本版 `COPY` 块实测 `station` 510 行、`line` 18 行，`createdb -E UTF8 -T template0` + `pg_restore --no-owner --no-privileges` 零错误，临时库已清理 —— 数据本身是完整的，导入失败只源于"怎么用"。

## 6. CentOS 上另外两个会卡住的点

```bash
sudo firewall-cmd --add-port=8092/tcp --permanent && sudo firewall-cmd --reload   # 不开端口外网访问不到
sudo setsebool -P httpd_can_network_connect 1                                     # 上 nginx 反代后 502 时
```

## 7. 与 .env 无关但会让它白弄的两件事

1. `.env` 里的 `PGHOST`/`PGPASSWORD` 必须是**服务器那台 PG** 的值，不是本地的。
2. 去高德控制台给这把 key 配 **IP 白名单**（服务器出口 IP）——key 被拷走也只能在别的 IP 上吃 `INVALID_USER_KEY`。这一层比 `.env` 更实在。

参考：[60592d56](60592d56-a0fc-4a32-bd93-1bf0fcabea37)（密钥外置的落点与前端 key 藏不住的实测）、[d6dc91dd](d6dc91dd-bff2-4971-897a-5b2fe5bf1580)（本地启动与接口联调基线，端口 8092、库 Translation）。
