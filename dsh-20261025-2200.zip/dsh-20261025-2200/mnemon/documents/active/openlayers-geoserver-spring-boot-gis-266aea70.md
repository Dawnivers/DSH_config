---
id: "266aea70-7a25-4d94-8359-39555b8b651f"
title: "OpenLayers + GeoServer + Spring Boot 全链路 GIS 练手项目设计（武汉公共服务设施可达性平台）"
description: "为补齐 Java/Spring Boot、GeoServer 地图发布、OpenLayers 前端与空间分析四项缺口而设计的独立项目方案：选题理由、三服务边界、PostGIS 数据模型与格网 SQL、2026-10 版本基线、18 天分期里程碑、8 个高发坑、JD 对照与两个待用户决定项。"
status: "active"
created_at: "2026-10-23T01:41:36.659Z"
updated_at: "2026-10-23T01:41:36.659Z"
content_hash: "3642db5f01783e08eff310adc97dead5a4606042e8d45c740999bd76c8ea818d"
source_paths:
  []
session_ids:
  - "3eba10d7-2124-401e-9449-25c7043657f6"
memory_body_ids:
  []
---

# OpenLayers 全链路 GIS 练手项目设计（2026-10-23 提出，用户尚未确认选题）

背景：用户此前评估某 GIS 公司后端实习岗（JD 要求 Java/Spring Boot/MyBatis + PostGIS + 地图服务 + WebGIS），判断现有能力在「后端工程化」「地图服务发布」「空间分析」「测试」四处有缺口，决定自写一个 OpenLayers 项目把这些知识串起来。本文是当时给出的项目构造方案，**用户只提出需求、尚未选定题目，也未开始落地**。

## 1. 选题与理由

推荐题目：**武汉公共服务设施可达性分析平台**。
理由：同时需要面（行政区）、点（设施/小区）、格网（分析单元）三类几何，能把坐标系、空间索引、空间分析、地图发布、前端渲染一次串完；产出热力图便于面试演示。
备选：地铁站点可达性（复用现成 29 个站点数据，省约两天，但只有点线，练不到面与格网）。取舍原则是「缺什么补什么」——当时缺的是面与格网，故选前者。

## 2. 架构边界（面试高频追问点）

```
浏览器
 ├─ WMS/WMTS/WFS/MVT → GeoServer → PostGIS   （只负责渲染与协议，不写业务）
 └─ REST/JSON        → Spring Boot → MyBatis → PostGIS （只负责业务与聚合，不画图）
```

必须能说清的分工：GeoServer 管渲染与协议（WMS 出 PNG、WMTS 出瓦片、WFS 出要素），后端管业务与聚合（统计、分页、导出、权限）；要素少走 WFS，要素多走 MVT，出图走 WMS。
反模式：把业务逻辑塞进 GeoServer 的 SQL 视图，或在 Java 里做地图渲染。
端口约定：Spring Boot 8090 / GeoServer 8080 / 前端 5173（与既有项目习惯一致）。

## 3. 数据层

新建独立库 `gis_demo`（不污染既有 `fencengfenhu`），`CREATE EXTENSION postgis`。

| 表 | 几何 | 说明 |
|---|---|---|
| admin_area | MULTIPOLYGON(4326) | 武汉 13 个区边界 |
| poi | POINT(4326) + category | 设施点，分类：学校/医院/商场/公园 |
| residential | POINT(4326) | 居住点（小区） |
| grid_500m | POLYGON(3857) | 500m 分析格网（米制投影） |
| grid_stats | 物化视图 | 每格设施数、覆盖率 |

三张原始表均建 GiST 索引（`CREATE INDEX ON poi USING GIST (geom);`）——这是「空间索引」知识点的唯一实证。
数据来源按成本排序：行政区划用阿里 DataV 免费 GeoJSON（adcode 420100，WGS84，ogr2ogr 入库）；POI 用高德 Web 服务 API 按关键词拉几百条；底图先用 OSM 公开瓦片或天地图。

## 4. 版本基线（2026-10 实测查询结果）

| 组件 | 版本 | 备注 |
|---|---|---|
| OpenLayers | `ol@10.11.0` | npm 包名 `ol`；`openlayers` 是 4.6.5 的遗留包，别装错 |
| Spring Boot | 3.5.16 | 3.x 末线；最新稳定 4.1.2，但教程与存量都在 3.x |
| MyBatis Starter | 3.0.5 | 配 Boot 3.5；Boot 4 对应 4.1.0 |
| GeoServer | 2.28.5 | 最新 3.0.2（Spring Boot 3 重写版），教程少、先用 2.28 |
| PostgreSQL/PostGIS | 18.4 + 3.5 | 本机已有 |
| JDK | 17.0.10 | 本机 `java` 走 Oracle javapath（`C:\Program Files\Common Files\Oracle\Java\javapath`），实际 JDK 在 `D:\java`，`JAVA_HOME` 为空，Maven/Gradle 未安装；`psql` 在 `D:\PostgreSQL18.4\data\18\bin\psql.exe` |

## 5. 里程碑（约 18 天，先闭环后扩展）

P0 环境 1 天（`mvn -v` 通、GeoServer 8080 可登录）→ P1 数据 2–3 天（4 表 + GiST，QGIS 能连看图）→ P2 发布 1–2 天（3 个图层，浏览器直开 WMS GetMap 出图）→ P3 前端 3–4 天（OL 叠 WMS + 点击查询）→ P4 后端 4–5 天（3 个接口 + JUnit）→ P5 分析 3–4 天（格网 + 物化视图 + 热力图）→ P6 收尾 2 天（README + 截图 + 接口文档）。

关键排期建议：把「PostGIS 一张表 → GeoServer → 浏览器看到图」这条最小闭环提前到第一周内完成。不通时极易误判为前端写错，实际是数据或服务问题，会白耗数天。

## 6. 高发坑（按概率排序）

1. **高德 POI 是 GCJ-02 而非 WGS84**，偏移 300–800 米；入库前必须转 WGS84，否则空间分析结果全错且图看起来正常。
2. **坐标系混用**：存储 4326，距离与格网用 3857；`ST_DWithin(4326 几何, 半径)` 单位是度不是米，需先 `ST_Transform(geom,3857)` 或用 `geography`。
3. **MyBatis 映射不了 geometry**：先用 `ST_AsGeoJSON(geom) AS geom_json` 返 String + 前端 `new GeoJSON().readFeatures()`，别一上来写 TypeHandler。
4. **Maven 本地仓库默认落 C 盘**：在 `D:\maven\conf\settings.xml` 设 `<localRepository>D:\m2repo</localRepository>` 或命令带 `-Dmaven.repo.local`（用户有「不放 C 盘」的硬要求）。
5. **GeoServer CORS**：不改 `web.xml`，用 Vite proxy `/geoserver → http://localhost:8080`，前端写相对路径。
6. **WMS 1.3.0 在 EPSG:4326 下轴序为 lat,lon**，会得到空白图；统一用 1.1.1 规避。
7. **GeoServer 的 MVT 是插件**：2.28 默认不带，`vectortiles` 扩展版本必须与主程序完全一致（2.28.5），差一个小版本启动失败。
8. **`ST_SquareGrid(500, geom)` 的单位是坐标系单位**：在 4326 下即 500 度（覆盖全球），必须传 3857 几何。

## 7. 核心分析 SQL（技术心脏）

```sql
CREATE TABLE grid_500m AS
SELECT row_number() OVER () AS id, g.geom
FROM (SELECT ST_Union(ST_Transform(geom, 3857)) AS geom FROM admin_area) a,
     ST_SquareGrid(500, a.geom) AS g;

CREATE MATERIALIZED VIEW grid_stats AS
SELECT g.id, g.geom,
       count(p.id) FILTER (WHERE p.category = 'school') AS schools,
       count(r.id) AS houses,
       CASE WHEN count(r.id) > 0
            THEN round(count(p.id)::numeric / count(r.id), 2) ELSE 0 END AS ratio
FROM grid_500m g
LEFT JOIN poi p ON ST_Contains(g.geom, ST_Transform(p.geom, 3857))
LEFT JOIN residential r ON ST_Contains(g.geom, ST_Transform(r.geom, 3857))
GROUP BY g.id, g.geom;
```

需能口头解释：为何用 3857、为何用物化视图、`ST_Contains` 与 `ST_Intersects` 的区别，以及「一万个点快速找出落在面内的」＝ GiST 索引 + `ST_Contains`。

## 8. 代码骨架

后端（Spring Initializr：Spring Web + MyBatis + PostgreSQL Driver + Lombok）：
`controller`（仅参数校验与调 service）/ `service`（事务、业务规则）/ `mapper`（只写 SQL）/ `entity`+`dto` / `common`（`R<T>` 统一返回、`GlobalExceptionHandler`）/ `resources/mapper/*.xml`。
三个接口即够：`GET /api/stats/coverage?district=洪山区`、`GET /api/poi/nearby?lon=&lat=&radius=800`（练 `ST_DWithin`）、`GET /api/grid/{id}`。

前端：Vite + 原生 JS，**不套 Vue**。理由是 OpenLayers 的 map/layer/source 是命令式对象，放进 `reactive` 会被 Proxy 包裹导致诡异行为；且 OL 教程多为原生 JS。摸熟后再封装进 Vue。

## 9. 与 JD 的对照

Java+Spring Boot+MyBatis ← P4；RESTful ← 三接口 + 统一返回；PostGIS ← P1/P5；地图服务与坐标系 ← P2 与坑 2/6；OpenLayers/WebGIS ← P3；GeoServer ← P2；空间分析 ← P5；测试 ← P4 的 JUnit（补最大空白）；技术文档 ← P6 README；AI 辅助编程 ← 全程。README 串起来即简历上的「独立完成从空间数据库到地图服务到前端的全链路 WebGIS 项目」。

## 10. 待用户决定（截至记录时未答）

1. 题目选「公共服务设施可达性」（练格网，数据成本高）还是「地铁站点可达性」（复用 29 站数据，省两天）。
2. 是否由助手直接在 `D:\WebGIS\web三维开发\` 下建 `gis-access` 目录，一次性生成 Spring Boot 骨架、Vite+OL 初始页、建库建表 SQL 与 GeoServer 安装清单。
