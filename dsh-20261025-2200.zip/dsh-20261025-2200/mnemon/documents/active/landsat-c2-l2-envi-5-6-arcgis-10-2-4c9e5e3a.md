---
id: "4c9e5e3a-3e5a-46d0-899b-1366e2dbd754"
title: "Landsat C2 L2 东湖水体提取实验：环境与数据源可行性核查（ENVI 5.6 + ArcGIS 10.2）"
description: "针对「Landsat C2 L2 地表反射率 → NDWI/MNDWI → 二值化 → 东湖水面」实验的实测可行性结论：本机 ENVI 5.6/ArcGIS 10.2(ArcInfo+Spatial) 环境核实、用地理空间数据云替代 USGS EarthExplorer 的等价性与检索坑（必须选\"数据=有\"）、完整七步流程、QA_PIXEL 位定义、已知坑与自检清单。"
status: "active"
created_at: "2026-10-13T06:22:25.482Z"
updated_at: "2026-10-13T06:22:25.482Z"
content_hash: "68895fd89bf1e1b031de1b614ed7ba36907496eb00833d69d53b46618c35c70b"
source_paths:
  - "_src/doc_text.txt"
  - "."
session_ids:
  - "1ec09f81-72ad-402c-8c01-23e8b60c7236"
memory_body_ids:
  []
---

# 东湖水体提取实验可行性核查与实施流程

结论：**用现有环境可以完整复现原实验方法**。地理空间数据云上架的就是 USGS 原版 Landsat Collection 2 Level-2 地表反射率产品，与原文档要求从 EarthExplorer 下载的是同一份数据（同样的 SR 波段、同样的 ×0.0000275−0.2 缩放系数、同样的 QA_PIXEL 位定义），因此方法链条不变，无需改方案。

## 1. 环境核查（实测，非推测）

| 项目 | 实测结果 | 状态 |
|---|---|---|
| ENVI | ENVI 5.6 装在 `D:\ENVI\ENVI56`，IDL 8.8；启动器 `D:\envi\ENVI56\IDL88\bin\bin.x86_64\envi_idl.exe`；另有 ENVI Classic 5.6、ENVI LiDAR、深度学习/Crop Science 模块 | 可用 |
| ArcGIS | ArcGIS 10.2 for Desktop 在 `D:\arcgis\arcgisData\Desktop10.2\`，`ArcMap.exe` 10.2.0.3348 | 可用 |
| ArcGIS 许可 | arcpy 实测 `ProductInfo = ArcInfo`，`CheckExtension('Spatial') = Available`（3D、GeoStats 同样 Available）——**这是第 6 步 Raster Calculator / Raster to Polygon 的关键依赖** | 可用 |
| ArcGIS Python | `C:\Python27\ArcGIS10.2\python.exe`（2.7.3，32 位），arcpy 正常 | 可用 |
| 解压 / 附加 | WinRAR 已装；QGIS 3.44 已装（可作兜底） | 可用 |
| 磁盘 | D 剩 237 GB，F 剩 132 GB（单景约 900 MB，足够） | 可用 |

唯一未能非侵入式验证的一项：ENVI 许可（`D:\ENVI\license` 下只有 FlexNet 信任存储文件，没有可见 `.lic`），需实际启动一次 ENVI 确认。

## 2. 数据源：地理空间数据云可等价替代 EarthExplorer

- 数据集：**Landsat 8-9 OLI/TIRS C2 L2**（发布者 usgs，免费），页面 `https://www.gscloud.cn/sources/accessdata/2c79f880a0304edebac6c48592d8e088?pid=263`
- 后台检索接口核实（武汉 WRS Path 123 / Row 039）：记录总数 **423 景**，其中本地有实体文件（可下载）**174 景**；单景标识格式如 `LC09_L2SP_123039_20230313_20230315_02_T1`（`data_type_l2 = OLI_TIRS_L2SP`，Collection 2，Tier 1），单景包约 900 MB。
- 低云量候选（可直接用第一景）：

| 数据标识 | 云量% | 日期 |
|---|---|---|
| `LC09_L2SP_123039_20230313_20230315_02_T1` | 0.03 | 2023-03-13 |
| `LC08_L2SP_123039_20220403_20220412_02_T1` | 0.21 | 2022-04-03 |
| `LC09_L2SP_123039_20230124_20230126_02_T1` | 0.26 | 2023-01-24 |
| `LC08_L2SP_123039_20151025_20200908_02_T1` | 0.01 | 2015-10-25 |

- **最大检索坑**：423 景中有 249 景仅编目、本地无文件（元数据 `dataexists=0`），没有下载按钮。检索时「数据」条件必须选 **有**。

## 3. 与原实验文档的差异

仅数据来源一处（EarthExplorer → 地理空间数据云），产品本身一致；SR_B3/SR_B5/SR_B6/QA_PIXEL、缩放系数、ENVI + ArcGIS 步骤全部照做。

## 4. 实施流程

**Step 0 目录准备（先做）**：`D:\RS_Lab\` 下建 `01_raw`（压缩包）/`02_extract`（解压庭）/`03_work`（ENVI 中间产物）/`04_out`（成果）。**必须纯英文路径**——ENVI/IDL 对非 ASCII 路径支持不稳，ArcMap 10.2 在中文路径+中文文件名下偶发报错；工作区 `F:\遥感数字图像处理` 只放文档/报告。

**Step 1 下载**：登录 gscloud（下载必须登录）→ 数据集选 `Landsat 8-9 OLI/TIRS C2 L2` → 空间位置按条带号 Path 123 / Row 039（或行政区武汉市，或地图框选东湖约 114.33–114.48°E、30.50–30.60°N）→ 时间范围如 2022-01-01 至 2023-12-31，云量 ≤ 10，**数据 = 有** → 选 `LC09_L2SP_123039_20230313_20230315_02_T1` 下载，WinRAR 解压到 `02_extract`。解压后应含 `*_SR_B3.TIF`(Green)、`*_SR_B5.TIF`(NIR)、`*_SR_B6.TIF`(SWIR1)、`*_QA_PIXEL.TIF`、`*_MTL.xml/.txt`。

**Step 2 ENVI 打开与裁剪**：启动 ENVI 5.6 → `File → Open` 分别打开三个 SR 的 TIF（不要依赖 MTL.txt 自动导入，见坑 2）→ 用 `Layer Stacking` 或 Display RGB 设 R/G/B = SR_B6/SR_B5/SR_B3 做假彩色目视 → 裁剪到同一范围：方法 A（推荐，保证对齐）用 ROI Tool 画东湖多边形后 `Toolbox → Regions of Interest → Subset Data from ROIs` 一次裁出三波段；方法 B 用 `File → Save As → Spatial Subset` 对三波段输入**完全相同**的行列/经纬度参数；**不要用 Resize Data 重采样**（易像元错位）→ 逐个 Quick Stats 确认行列数、30 m 像元、UTM Zone 50N/WGS84 一致。

**云掩膜（条件性）**：文档仅在研究区有云/云影时才要求。所选 2023-03-13 景观云量 0.03%，东湖上空基本无云，可省略，但报告中需写明未使用 QA_PIXEL 的理由。若换景后有云：`Band Algebra → Band Math` 对 QA_PIXEL 算 `(b1 and 24) ne 0`（bit3 云 | bit4 云影 = 8+16）→ `Masks → Build Mask` → `Masks → Apply Mask` 应用于三个 SR 波段。

**Step 3 恢复地表反射率**：`Toolbox → Band Algebra → Band Math`，表达式 `float(b1) * 0.0000275 - 0.2`，b1 依次选 SR_B3→Green、SR_B5→NIR、SR_B6→SWIR1；输出 TIFF、数据类型 Floating Point (32-bit)。自检：反射率约 −0.2 ~ 1.0；水体 < 0.1，植被 NIR 约 0.2–0.5；若呈 0–10000 量级说明缩放未生效。

**Step 4/5 NDWI 与 MNDWI**：同一 Band Math 表达式 `(float(b1) - float(b2)) / (float(b1) + float(b2))`，NDWI 用 b1=Green / b2=NIR，MNDWI 用 b1=Green / b2=SWIR1。

**Step 6 ArcMap 10.2 二值化**：打开 ArcMap → `Customize → Extensions` 勾选 Spatial Analyst（首次需开许可）→ 拖入 NDWI/MNDWI → 工具条 **Raster Calculator**，先在 `Environment → Raster Analysis` 设像元大小 30 与坐标系，再运行 `Con("NDWI" > 0, 1, 0)`、`Con("MNDWI" > 0, 1, 0)`（栅格不在 TOC 时写全路径；输出到文件地理数据库或英文文件夹）。面积核对：值为 1 的像元数 × 900 m²。

**Step 7 对比出图**：四联图（假彩色原图 + NDWI + MNDWI + 两幅二值图）→ `Spatial Analyst → Conversion → From Raster → Raster to Polygon` 转面 → 加字段用 `Calculate Geometry → Area` 统计水面面积（数据框 UTM 50N）→ 重点观察湖岸建筑屋顶、道路、深色沥青、云影的误分：MNDWI 以 SWIR1 替代 NIR，对建成区抑制更好，这正是实验待验证的核心结论 → 可选定量比较：在建成区/植被/土壤/水体四类各采样本点，统计两指数均值与标准差；`File → Export Map` 出 300 dpi 图并存 `.mxd`。

## 5. 已知坑（按重要性）

1. **中文路径**：数据放 `D:\RS_Lab\` 等纯英文路径，不要在 `F:\遥感数字图像处理\` 下跑 ENVI。
2. **ENVI 5.6 原生不认 Collection 2 的 MTL 元数据**（双击 MTL.txt 无反应）：ENVI 5.6.0 及以下原生仅支持 C1，C2 支持需 5.6.1/5.6.2（官方说明 https://envi.geoscene.cn/appstore/opeldtsant/ ，该页同时列出 5.6.2 已原生支持全部 Landsat 级别与格式）。对本实验无影响，因为文档本就要求在 Band Math 手工缩放，ENVI 读 GeoTIFF 地理信息正常。
3. **gscloud 必须选「数据 = 有」**，否则挑到无实体文件的景。
4. 单景约 900 MB + 解压，一次只下一景即可。
5. **ArcMap 10.2 是 32 位进程**：裁剪后小范围没问题，别把整景丢进 Raster Calculator。
6. **分母为 0**：仅原始值为 0 的填充像元会使 Green+SWIR1 = 0（缩放后为 −0.2）；裁到东湖后基本不存在，担心时可用 `Con(("Green"+"SWIR1") == 0, 0, ...)` 兜底。
7. **阈值 0 只是初始值**，不是最优阈值，不能当作结论。
8. 输出栅格名不要以数字开头、不要带空格。

## QA_PIXEL 位定义（C2 L2，供掩膜使用）

- Landsat 8 C2 L2 QA_PIXEL：bit0 Fill、bit1 Dilated_Cloud、bit2 Cirrus、bit3 Cloud、bit4 Cloud_Shadow、bit5 Snow、bit6 Clear、bit7 Water；bit8-9 Cloud_Confidence、bit10-11 Cloud_Shadow_Confidence、bit12-13 Snow_Ice_Confidence、bit14-15 Cirrus_Confidence（0 无 / 1 低 / 2 中 / 3 高）。
- Landsat 4-7 C2 L2 QA_PIXEL：bit2 为 Unused（无 Cirrus），其余同结构；置信度位上值 2 为 Reserved。
- 参考：USGS L2SP Guide（LSDS-1619 / LSDS-1618）与 https://sdtaylor.github.io/unpackqa/Landsat.html （USGS 官方页有反爬，直接访问返回 405）。

## 6. 自检清单

- [ ] 三个 SR 波段裁剪后行列数、像元大小、坐标系完全一致
- [ ] 缩放后反射率约 −0.2 ~ 1.0
- [ ] NDWI/MNDWI 值域在 −1 ~ 1
- [ ] 二值图中东湖主体为 1，湖岸外建成区尽量为 0
- [ ] 东湖水面面积量级合理（东湖水域约 33 km²）
- [ ] MNDWI 在建成区/道路上的误分明显少于 NDWI

## 7. 兜底方案

若 ENVI 无法启动：L2SP 本身已是地表反射率，ENVI 在本实验只承担「缩放 + 波段运算 + 裁剪」，这三件事 ArcMap 10.2 的 Raster Calculator 或已装 QGIS 3.44 栅格计算器均可完成，方法链条不变，仅需在报告中说明软件差异。

## 8. 其他

原实验 docx 正文已提取为纯文本存于工作区 `_src\doc_text.txt`（原始 docx 为只读副本，未修改）。后续可做：搭建 `D:\RS_Lab` 目录结构 + 含每步截图位的可勾选实验步骤清单。
