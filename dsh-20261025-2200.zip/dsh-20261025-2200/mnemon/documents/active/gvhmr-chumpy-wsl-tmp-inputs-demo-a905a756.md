---
id: "a905a756-d31b-43df-ad45-b474ba4655e6"
title: "GVHMR 依赖安装实测增量：chumpy 构建隔离根因、WSL /tmp 跨调用被清、inputs/ 相对路径约定与 demo 命令"
description: "GVHMR 在 WSL2/Ubuntu22 上的依赖安装增量实测：chumpy 构建隔离根因与 --no-build-isolation 修法、pip -r 事务性失败导致整片 MISS、WSL /tmp 跨调用被清需用持久路径、inputs/ 必须在 repo 内（相对 ckpt_path）、静态机位 demo 命令与 import 冒烟测试法、收尾检查清单。背景见 e8d0b5ea 与 72feafbd。"
status: "active"
created_at: "2026-10-17T02:09:24.889Z"
updated_at: "2026-10-17T02:09:24.889Z"
content_hash: "3730539e229a8711459b2aa22f968bb7cefa95003fded4a746e7d426682b751f"
source_paths:
  - "mocap/gvhmr/repo/requirements.txt"
  - "mocap/gvhmr/repo/tools/demo/demo.py"
session_ids:
  - "b2958dcb-0809-4101-a7f5-0118afb744bc"
memory_body_ids:
  []
---

# GVHMR 依赖安装实测增量（WSL2 / Ubuntu 22.04 / py3.10）

> 前置背景见 `e8d0b5ea-bf31-4a81-a9d9-23306865e995`（WSL 落地、hf-mirror 权重、SMPL 校验、SMPL-X 缺口）与 `72feafbd-2625-4f82-ac10-0e47afc7a94d`（B 路线实施规格）。本文只记录**那次之后新踩到、可复用的四条硬结论**，避免下次重走弯路。

## 1. 能装上的部分（已实测成功）

- `torch 2.3.0+cu121`：`torch.cuda.is_available() == True`，驱动直通 OK。
- `pytorch3d 0.7.6`：直接用官方 Linux 预编译轮子装上，**无需编译**：
  `https://dl.fbaipublicfiles.com/pytorch3d/packaging/wheels/py310_cu121_pyt230/pytorch3d-0.7.6-cp310-cp310-linux_x86_64.whl`
  （它顺带拉入 `fvcore` / `iopath` / `yacs` / `termcolor` / `tabulate` / `portalocker`）
- `chumpy 0.70`、`cython_bbox 0.1.5`：按第 2 节方式**都能编出来**。
- `gvhmr` 本体：`pip install -e .` 可编辑安装成功；`import hmr4d` 通过。

## 2. chumpy 失败的真正根因与修法（关键）

报错长这样：

```
chumpy setup.py → ModuleNotFoundError: No module named 'pip'
ERROR: Failed to build 'chumpy' when getting requirements to build wheel
```

**根因**：chumpy 是 2019 年的老包，`setup.py` 里 `import pip`；而 pip 默认的**构建隔离环境**是干净 venv，里面没有 pip 模块。

**修法**：`pip install --no-build-isolation chumpy` —— 让它用系统解释器里的 pip/numpy。

**顺序约束**（同样的坑适用于 `cython_bbox`）：
1. 先把 `numpy` 钉到 **1.23.5** 并装 `cython`（否则 `cython_bbox` 编译时对不上头文件）；
2. 再 `--no-build-isolation` 装 `chumpy`；
3. 再 `--no-build-isolation` 装 `cython_bbox`；
4. 最后装其余 requirements。

**⚠️ 事务性陷阱**：`pip install -r requirements.txt` 是一条**事务**，其中任一包构建失败（如 chumpy）会让**后面所有包一个都不装**，且退出码仍可能是 0（脚本里若只 `set -e` 而没检查 python 调用就会漏掉）。症状是"前面 OK、后面整片 MISS"。稳妥做法是**把 chumpy / cython_bbox 从清单里剔出来单独装**，再做一次逐包 import 验证。

## 3. WSL 的 `/tmp` 在两次调用之间会被清空

实测：第一次调用写到 `/tmp/req.txt` 并在同一次调用里用掉；下一次调用 `grep /tmp/req.txt` 直接 `No such file or directory`。

**原因**：WSL 发行版在两次 shell 调用之间会停机（idle 终止），`/tmp` 随实例生命周期消失。

**规则**：跨调用的中间文件**一律放 D 盘持久路径**（如 `D:\mocap\gvhmr\req4.txt` → `/mnt/d/mocap/gvhmr/req4.txt`），或者每次从 repo 的 `requirements.txt` **现场重新生成**清单，不依赖上一轮遗留文件。

## 4. 路径约定：`inputs/` 必须在 repo 根目录内

配置文件里写的是**相对路径**：

```
ckpt_path: inputs/checkpoints/gvhmr/gvhmr_siga24_release.ckpt
```

→ 隐含两条硬要求：**必须在 repo 根目录下执行**、且 `inputs/` 位于 repo **内部**。

先前为不打断下载，权重落在了 repo 外面一层（`D:\mocap\gvhmr\inputs\`）。修法：同盘 `mv` 进 `D:\mocap\gvhmr\repo\inputs\`（同盘移动秒完成，不必重下）。

整理后的期望布局（`-s` 静态机位模式可跳过 DPVO）：

```
repo/inputs/checkpoints/
├── gvhmr/gvhmr_siga24_release.ckpt
├── hmr2/epoch=10-step=25000.ckpt
├── vitpose/vitpose-h-multi-coco.pth
├── yolo/yolov8x.pt
├── dpvo/dpvo.pth                      ← 可选，-s 用不上
└── body_models/
    ├── smpl/SMPL_NEUTRAL.npz + .pkl
    └── smplx/SMPLX_NEUTRAL.npz
```

## 5. 推理入口与命令

```bash
cd /mnt/d/mocap/gvhmr/repo
python tools/demo/demo.py --video=/mnt/d/mocap/media/dance.mp4 \
       --output_root=/mnt/d/mocap/gvhmr/outputs -s
```

- `-s` = `static_cam`：固定机位，**跳过 DPVO**（省掉那条最难编的依赖）。
- 冒烟测试技巧：`python3 -c "import sys; sys.argv=['x','--help']; exec(open('tools/demo/demo.py').read())"` 可以在不跑推理的情况下暴露缺失 import（本次正是靠它一眼看出还差 `cv2`）。

## 6. 收尾检查清单（下次照做）

1. 逐包 import 验证：`torch / pytorch3d / numpy / smplx / hmr4d / cv2 / pytorch_lightning / timm / ultralytics / pycolmap / lapx / wis3d / chumpy`
2. `smplx.create(...)` 能真正加载 `SMPLX_NEUTRAL.npz`
3. `inputs/` 位于 repo 内、当前工作目录为 repo 根
4. 小视频跑一遍 `-s`，确认 `outputs/` 出世界坐标 SMPL 结果
5. 之后才进重定向层（本项目自有的方向匹配 + 平滑 + 限速，位于 `mocap/retarget_compute.py`）
