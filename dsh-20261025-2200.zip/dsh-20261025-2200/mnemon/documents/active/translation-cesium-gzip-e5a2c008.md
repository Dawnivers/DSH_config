---
id: "e5a2c008-2ce6-446c-bb70-81dc323f7317"
title: "Translation 智慧地铁构建包体实测：Cesium 外部化到底赚了什么、gzip 是唯一还没拿的收益"
description: "对照参考项目 smart-subway-warehouse 那套「externals + insert-html + static-copy + compression」四件套，实测本项目 Translation 的外部化 vs 不外部化产物体积/构建耗时/首屏 gzip，并给出真实体积构成（23.56MB 列车 glb、396 张站名 jpg、9.6MB Cesium 静态资源）与按性价比排序的优化结论。"
status: "active"
created_at: "2026-10-20T00:56:27.134Z"
updated_at: "2026-10-20T00:56:27.134Z"
content_hash: "64586ab2601a10ac1bd3c917501b3b5f5343810e00072f705ea77adef41ec644"
source_paths:
  - "Translation/vite.config.js"
  - "Translation/package.json"
  - "综合项目：智慧地铁/smart-subway-warehouse/vite.config.js"
  - "Translation/src/cesiumTools/lineAndpoints/train/trainRoam.js"
  - "Translation/src/components/bottom/StationPanel/queryTemplate.vue"
  - "Translation/src/views/cesiumView.vue"
session_ids:
  - "c5b83e1c-4049-4238-89b7-511206117cd8"
memory_body_ids:
  []
---

# Translation 构建包体实测（2026-10-20）

对象：`D:\WebGIS\web三维开发\智慧地铁项目\Translation`（Vite 8.2.2 / Vue 3.5 / **cesium 1.97** / `vite-plugin-cesium` 1.2.23）。
触发：用户读到一份语雀《项目优化策略》（参考 `综合项目：智慧地铁\smart-subway-warehouse` 的那套配置），问「这种策略对性能提升大吗、本项目有没有可取之处」。

结论先说：**那套策略本项目基本已经等价具备，且它优化的是「发版首屏传输」，与「卡不卡/帧率」基本无关。** 唯一还没拿的收益是 gzip，占比 3MB/总 50MB+。

## 1. 参考项目那 4 条 = 它的 vite.config.js 原文

`综合项目：智慧地铁\smart-subway-warehouse\vite.config.js`：

| # | 插件 | 作用 |
|---|---|---|
| ① | `vite-plugin-externals({ cesium: 'Cesium' }, { disableInServe: true })` | cesium 不参与打包，走全局 `window.Cesium`；dev 不启用 |
| ② | `vite-plugin-insert-html` | 按 `VITE_CESIUM_BASE_URL` 往 head 塞 `<script src=…Cesium.js>` + `widgets.css` |
| ③ | `viteStaticCopy` | dev 模式拷 `node_modules/cesium/Build/CesiumUnminified/` → `libs/cesium/` |
| ④ | `vite-plugin-compression` | 预生成 `.gz` / `.br` |

本项目的 [vite.config.js](Translation/vite.config.js) 只剩 `vue() + vueDevTools() + cesium()`，但 `vite-plugin-cesium` 内部做的就是 ①②③：

- ①②③ → ✅ 已具备：build 时注入 `external:['cesium']` + `external-globals({cesium:'Cesium'})`；产出的 `dist/index.html` 里确实有 `<script src="/cesium/Cesium.js">` 和 `/cesium/Widgets/widgets.css`；`dist/cesium/` 371 个文件 / 9.6MB。
- ④ → ❌ **缺失**：产物里 `.gz/.br` 文件数为 0。

⚠️ 不要再照文档手写那 4 个插件：会和 `vite-plugin-cesium` 打架，两套都在往 head 塞 `<script src="/cesium/Cesium.js">`，等于加载两次 3.25MB。

## 2. 实测：外部化 vs 不外部化（临时配置，产物已删）

做法：临时另写一份去掉 `cesium()` 插件的配置各打一次包对比，验证后 `dist-tmpexp` / `dist-tmpreal` 与临时配置全部删除（结束时目录只剩 `dist`）。

| 指标 | 外部化（现状） | 不外部化 |
|---|---|---|
| 首屏关键 JS | `Cesium.js` 3.25MB + `index` 0.49MB = **3.74MB / 2 个请求** | 单 chunk **3.32MB / 1 个请求** |
| 构建耗时 | 3.6s | 1.6s |
| 产物目录 | 792 文件 / 56MB | 424 文件 / 49.5MB，但**缺 Workers/Assets**，真跑起来还得再补 9.6MB |
| 实测 index js | `index-Da-TcDr1.js` 511,631 B（gz 176,617，35%） | `index-BfK_kzz1.js` 3.32MB |

即：**外部化没省字节，反而多 0.4MB，构建还更慢**（每次要拷 371 个文件）。它真正的唯一收益是**缓存粒度**——改一行业务代码，用户只重下 0.49MB 而不是 3.3MB。这是「第 N 次访问」的收益，不是首访，更不是帧率。

## 3. gzip 实测（doc 里唯一实打实的）

| 文件 | 原始 | gzip | 比例 |
|---|---|---|---|
| `cesium/Cesium.js` | 3,406,969 B (3.25MB) | 927,709 B | 27% |
| `assets/index.js` | 566,610 B (0.54MB) | 198,862 B | 35% |
| 首屏合计 | **3.74MB** | **≈1.05MB** | **−72%** |

但**只在真部署时才有意义**：需要 nginx `gzip_static on` 或 `gzip on`；`vite preview` 不会使用这些预生成的 `.gz`。本项目日常在 dev（localhost）里跑，所以做了完全感觉不到——这也是「做了没效果」的口径差异来源。

## 4. 项目产物真实构成（重新打包后实测，不是 10/10 的旧 dist）

| 类型 | 数量 | 体积 |
|---|---|---|
| `.glb` 列车模型 `trainAndChisa_static.glb` | 1 | **23.56MB** |
| `.jpg` 站名照片（`assets/stationImg/`） | 396 | **22.07MB**（均值 57.1KB；离群：丹阳路 500×375 / 230KB / 10.06 bpp，金海路 26KB） |
| `.js` + `.css` | 21 | 0.80MB |
| Cesium 全家桶 | 371 | 9.6MB |

- 站名图片是 `import.meta.glob(..., { eager: true, query: '?url' })`（[queryTemplate.vue:170](Translation/src/components/bottom/StationPanel/queryTemplate.vue#L170)）：**只收 URL**，单张命中才下载 → 这条本身不卡。
- 列车 glb 走 `new URL('../../../assets/trainAndChisa_static.glb', import.meta.url).href`（[trainRoam.js:38](Translation/src/cesiumTools/lineAndpoints/train/trainRoam.js#L38)），23.56MB 不内联。
- 城市白膜**不在 dist 里**：`url: 'http://localhost:666/model/shangHaiBuilds_new_toPlane/tileset.json'`（[cesiumView.vue:111](Translation/src/views/cesiumView.vue#L111)），由外部服务提供。
- `src/assets/Shanghai.glb` 9.87MB **全项目 0 处引用**、打包不产出，可直接删。

所以语雀那套要抠的 3MB 只占项目 ~5%，且和加载体感无关。

## 5. 按性价比排序的结论

1. **值得做、成本≈0：gzip。** 部署侧让 nginx 开压缩，或加 `vite-plugin-compression` 预生成 `.gz`（一个 devDependency + 一行插件），dev 零影响。首屏 3.74MB → 1.05MB。
2. **已经白拿，别动**：外部化 + 静态资源拷贝 + 缓存分离。
3. **不建议**：Cesium 挂 CDN / 用 `.env` 切 base url（内网大屏反而更慢，除非多项目共享缓存）；`devMinifyCesium`（省一点 dev 首屏，但断点调试失效，localhost 不值当）。
4. **真要提帧率，方向不在这份文档里**：23.56MB 列车 glb 的减面 / Draco（预估 50~80% 空间）、~400 个站点 HTML 标签的 `postRender` 遍历、热力图重绘。

## 6. 两个顺手发现

- `src/assets/Shanghai.glb`（9.87MB）零引用，可删以减小仓库体积。
- 当时的 `dist/` 是 **10/10 19:42** 的旧产物，早于 10/15 的列车 glb，真要部署必须重打。

## 7. 附：同轮站控改动的收尾更正（详见 `97877f64-b8d0-4662-8c7b-4b7a0af34d23`）

`StationControl.vue` 里的 `frameStations()`（进模式 `flyTo` 到有措施站外接矩形）已整段删除，进模式只灌数据 + 点亮站点，**相机不动**；措施方框由文字改为 9 个内联 SVG（`MeasureIcon.vue`，24×24、`currentColor`、不依赖 iconfont）。

**并纠正该文档末尾那个「所有 `.LabelPlot-container` 都是 `display:none`」的疑似阻塞：气泡没坏。** 站点气泡有 150km 可见阈值（站点图层既有设置），默认全局视角高于该阈值 → 整批剔除；相机拉近后 `display: block` 正常出现。教训：HTML 标签批量不可见时，先怀疑 `DistanceDisplayCondition` / 视角，而不是标签管线崩了。
