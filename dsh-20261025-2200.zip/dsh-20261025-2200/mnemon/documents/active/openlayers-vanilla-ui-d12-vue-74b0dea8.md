---
id: "74b0dea8-c01f-4df9-b499-4b3fc3b0ae0a"
title: "OpenLayers vanilla 前端模块化与 UI 面板架构（含 D12 迁 Vue 检查单）"
description: "openlayers服务平台开发 Project 的前端架构决策：为何先保持 vanilla（framework-agnostic 而非“原始”）、UI 三种来源与 index.html 只留空壳、图层注册表单数据源、多 JS 模块目录与面板工厂契约（mount/destroy）、大屏 transform:scale 命中偏移与 pointer-events 分层、极简 store、Vue3 接缝（shallowRef+markRaw）与迁移触发信号。"
status: "active"
created_at: "2026-10-24T08:34:15.206Z"
updated_at: "2026-10-24T08:34:15.206Z"
content_hash: "d11960743f23ca11c9ba3345fc5c47fffd18a1e038bd9465a3b7f58b80bd93fe"
source_paths:
  - "Project/src/main.js"
  - "Project/index.html"
  - "Project/vite.config.js"
  - "Project/src/style.css"
session_ids:
  - "e939e6ac-9f69-4a8f-a708-c2982b16ac3d"
memory_body_ids:
  []
---

# OpenLayers vanilla 前端模块化与 UI 面板架构（含 D12 迁 Vue 检查单）

> 承接 D3 闭环记录 `7c851184-26c4-45e2-827d-aad6bc4f375a`（pnpm + Vite + `ol@10.11.0` + ImageWMS + 天地图底图）。本文只回答一个后续问题：**这个 vanilla 项目要加 UI / 大屏面板时，代码放哪、怎么组织、什么时候该迁 Vue**。不改动 D3 已有实现，属架构决策与实施契约。

## 1. 先纠正前提

「原生 JS 的 OL 项目才流行」是伪命题。OL 是框架无关（framework-agnostic）的库，真实分布分三层：

| 场景 | 主流写法 | 原因 |
|---|---|---|
| 官方示例 / 教程 / demo | 几乎全 vanilla | 示例必须能脱离框架独立跑，`new Map({...})` 无需解释三板斧 |
| 国内 GIS 业务系统、大屏 | Vue3 / React + OL | 图层树、工具栏、查询表格、弹窗、权限都是框架强项 |
| 2012 年代老项目 / 极简内部页 | script 标签 + jQuery + 全局 `ol` | 「OL 项目很原始」的印象来源 |

当前 `Project` 属第一层而非第三层：Vite + ESM + `import Map from 'ol/Map.js'`，模块化、tree-shaking、HMR 齐全。缺的只是 UI 框架那一层，不是工程化。

## 2. 当前项目先不套 Vue 的理由（有意减负，非落后）

1. **学习目标不在框架**：链路是 `PostGIS → GeoServer → WMS/WFS → 前端渲染`，要搞懂坐标系、轴序、bbox、proxy、图层类型；Vue 是用户已会的东西（Translation 项目即 Vue3 + Cesium）。
2. **排错少一个变量**：白图时可二分「OL 参数错」与「服务端返回错」；套框架会多出「响应式包坏 OL 对象 / 生命周期实例丢失」第三因。
3. **官方示例可直接照抄**：examples 全站 vanilla，改 `LAYERS` 与 URL 即可；套 Vue 要先做一遍「示例翻译」，翻译错就变成排查自己。
4. **命令式 vs 声明式有天然摩擦**：`new Map({ target: 'map' })` 是「给我 DOM，剩下我接管」，与 Vue 的「描述状态→渲染」需要一个明确接缝。

## 3. UI 的三种来源（index.html 只留空壳）

| UI 类型 | vanilla 做法 | 是否改 index.html |
|---|---|---|
| OL 自带控件（缩放、比例尺、鼠标经纬度、鹰眼、版权） | `new ScaleLine()` / `new MousePosition()` 塞进 `controls` 数组（`defaultControls({zoom, attribution}).extend([...])`） | 否，纯 JS |
| 静态面板/工具条（图例、标题、开关面板、测量按钮） | 骨架写在 index.html，JS `querySelector` 绑事件 | 是 |
| 动态列表（图层树、查询结果、POI 列表） | JS 生成 DOM，HTML 只留**空容器** | 只需空容器 |

需要写进 HTML 的只有挂载点，且必须是 `#map` 的**兄弟节点**（OL 会把 `.ol-viewport`、canvas、图层容器塞进 target，子元素会被覆盖或事件打架）：

```html
<div id="map"></div>
<div id="toolbar"></div>   <!-- JS 填按钮 -->
<div id="panel"></div>     <!-- JS 填图层开关 -->
<div id="hud"></div>       <!-- 大屏面板总挂载点 -->
```

钉在坐标上的信息卡片用 `Overlay({ element, positioning })` + `map.addOverlay`，元素仍是普通 DOM。

## 4. 图层注册表：现在就能改的一处（单数据源）

当前 `Project/src/main.js` 是 `layers: []` 加三次 `map.addLayer(...)`（天地图影像、注记、`admin_area`），三个图层散在三个变量里，UI 无从得知它们存在。

改为单一注册表，`map.addLayer` 与其后所有面板都从同一数组派生：

```js
const LAYERS = [
  { id: 'base',  name: '天地图影像', layer: tiandituLayers },
  { id: 'label', name: '天地图注记', layer: MasktiandituLayers },
  { id: 'admin', name: '武汉区划',   layer: adminLayer },
]
LAYERS.forEach(l => map.addLayer(l.layer))
```

这是 D12 图层开关面板的直接数据源，也是后来平滑长成 Vue 的路径。图层开关面板四条纪律：注册表 → 遍历生成 checkbox（`dataset.id` 存身份）→ **只在容器上挂一个 `change` 委托**（`e.target.dataset.id` 反查，增删图层不重挂事件）→ 副作用收口到单一 `applyVisibility(id, checked)` 里只调 `layer.setVisible()`。

## 5. 多 JS 文件的工程化

可以且应该拆多个 js，但 index.html 只写**一个入口** `<script type="module" src="/src/main.js">`，其余靠 `import` 连接。ESM 每文件独立作用域，未 export 者外部不可见，全局污染消失。性能无需担心：dev 下一模块一请求属本机；`pnpm build` 后打进一两个 chunk，**文件多 ≠ 请求多**。

按职责分目录（不按类型）：

```
src/
├── main.js            接线板：建 map → 建各面板 → mount（目标 < 60 行）
├── map/
│   ├── map.js         createMap()：Map/View/controls
│   ├── layers.js      LAYERS 注册表（含 name、可见、图例色）
│   └── interaction.js click → 取坐标 → 请求 → 派发（D12 才写）
├── ui/
│   ├── layerPanel.js  图层开关
│   ├── legend.js      图例
│   ├── statCard.js    数字卡片
│   └── popup.js       点击弹窗
├── services/
│   ├── wms.js         GetFeatureInfo 等，fetch 只在这里出现
│   └── store.js       跨面板状态 + 极简订阅
└── styles/
    ├── main.css       reset、布局骨架
    └── hud.css        大屏皮肤（边框、发光、字体）
```

判据一条：**「这个文件删了，谁坏？」** 只有一个答案 → 模块化合格；三处都坏 → 它其实是公共状态，该进 store。

## 6. 面板工厂契约（每个 ui 模块的统一形状）

导出单个工厂函数，依赖全靠参数注入，DOM 自己造，必须能销毁：

```js
export function createLayerPanel({ layers, mountEl }) {
  let el = null
  const handlers = []

  function build() { /* createElement + 静态骨架 + 按 layers 生成行，append 到 mountEl */ }
  function bind() {
    const onChange = e => { /* e.target.dataset.id → layer.setVisible */ }
    el.addEventListener('change', onChange)
    handlers.push(() => el.removeEventListener('change', onChange))
  }
  function mount() { build(); bind() }
  function destroy() { handlers.forEach(off => off()); el?.remove(); el = null }

  return { mount, destroy }
}
```

三条纪律（框架本来替你做、vanilla 里自己负责）：

| 纪律 | 理由 |
|---|---|
| 依赖参数传入（`layers`、`mountEl`），不 import 单例 map | 否则只能在本项目本位置用一次，也无法单测 |
| DOM 自己造，外部只给挂载点 | 避免「HTML 里必须有个 `#legend`」的隐形契约耦合 |
| 必须实现 `destroy()` | 大屏切页/HMR 时旧面板仍在监听 `moveend`，内存与事件会翻倍涨——vanilla 最易漏 |

`main.js` 由此退化成配置式流水线：`createMap('map')` → 建面板数组 → `panels.forEach(p => p.mount())`。

## 7. 大屏两个必踩的坑

**坑 1：`transform: scale()` 不能罩住地图容器。**
OL 的像素命中依赖 `viewport.getBoundingClientRect()` 与 `clientWidth`；CSS transform 只改前者不改后者（clientWidth 是布局尺寸）。地图被 scale 包住后，视觉位置与命中坐标错位（点在区县 A，`map.forEachFeatureAtPixel` 报 B）。正确切法：**`#map` 铺满真实视口，只有 UI 层 `#hud` 做 scale**，两者为兄弟节点：

```css
#map { position: absolute; inset: 0; }
#hud { position: absolute; inset: 0; transform-origin: 0 0; pointer-events: none; }
#hud .hud-panel { pointer-events: auto; }
```

`pointer-events: none` + 子项 `auto` 这一对是必须的：否则透明容器盖住 canvas，地图拖不动、滚轮不缩（「地图没反应」的常见成因）。纯装饰层（标题、边框、图例）保持 `none`。

**坑 2：面板多了要分层，别挤一个容器。** 常规三层：底（地图）→ 中（装饰/边框/标题，`pointer-events:none`）→ 顶（可点面板），各一个 div 各管一档 z-index。另注意面板在地图上方会先吃掉滚轮。

## 8. 面板间通信：20 行极简 store

避免「点区县 → 详情面板各自 fetch 一遍」。核心三函数：`getState` / `setState(patch)`（整体替换后通知）/ `subscribe(fn)`（返回退订函数）。**store 只放布尔值、id、字符串等「意图」，绝不放 `Map`/`Layer`/`Feature` 实例**；需要改地图时集中在一个 `apply()` 里把意图翻译成 `layer.setVisible()`。

## 9. Vue3 接缝（D12 迁移时照此执行）

- **OL 实例一律不进深层响应式**：`reactive` 的 Proxy 会破坏 OL 依赖的对象身份与私有状态（瓦片缓存、渲染队列、事件表），症状是「地图能出来但不动 / 缩放按钮失灵 / 选中无反应」。正确写法 `const map = shallowRef(null); map.value = markRaw(new Map({ target: 'map' }))`。Cesium 的 `viewer` 同理。
- 实例只在 `onMounted` 后创建（DOM 未挂载时 `target` 为空）。
- `onBeforeUnmount` 必须 `map.setTarget(undefined)` 或 `map.dispose()`，否则切路由后旧实例仍在监听。
- 原则：**Vue 只做壳，OL 只做核。** Vue 管面板显隐、图层开关布尔、选中区名、弹窗内容；OL 管实例、图层、feature、渲染；接缝只传两样——`ref` 拿 DOM 节点，`watch` 把布尔翻译成 `layer.setVisible()`。
- 落地顺序：先用 vanilla 写 3 个面板（图例 + 图层开关 + 数字卡片）跑通 `mount/destroy` 手感，D12 再把同样三个改成 `.vue`，同一功能写两遍，差价即面试可讲的 3 分钟。

**迁移触发信号（量化，不看心情）**：同一状态需 3 处以上同步（开关↔高亮↔URL）；面板出现增删改排序列表；2–3 处复用同一面板且参数不同；UI 模块 > 8 个，或跨面板状态 > 5 个且有派生关系；需要二级页面/复杂显隐。到点再迁，之前 vanilla 更快。

## 10. 与岗位的关系

目标是 **Java 后端**实习，前端是 JD 加分项。面试官关心的是能否说清 WMS/WFS 分工、GeoServer 发图层、坐标系为何偏 500 米，与是否用 Vue 无关。简历上「Vue3 + OpenLayers 的响应式陷阱」是好故事，但前提是先在 vanilla 下把 OL 本身摸熟。
