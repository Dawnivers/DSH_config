---
id: "7d3ba5c3-9ce9-4b7c-8105-0346b8cbba3d"
title: "Translation 后端 API 缓存启用 SOP：proxy_cache 死配置、按接口分档 TTL、宝塔插入位置与 MISS→HIT 验证"
description: "translationbe.dawnivers.top 的 nginx proxy_cache_path 声明却未启用问题、getLine/getWeather/getLinePlan 按数据来源分档 TTL（省高德配额 vs 省带宽）、配置必须插在 #PROXY-CONF-START/END 之外、add_header 覆盖 server 层的坑，以及 x-cache-status MISS→HIT 验收与 nginx -t 常见报错对照。"
status: "active"
created_at: "2026-10-21T13:19:35.835Z"
updated_at: "2026-10-21T13:19:35.835Z"
content_hash: "62dfcbc690bb6b71b574a7248d8a8d5690302e8a1627857bdd08e81dc137f584"
source_paths:
  - "src/views/cesiumView.vue"
  - "dist/index.html"
session_ids:
  - "1777640e-6373-4cd7-a670-68ffe74a1cc8"
memory_body_ids:
  []
---

# Translation 后端 API 缓存启用 SOP

对象：`translationbe.dawnivers.top`（Express 后端跑在 `127.0.0.1:8092`，对外走高德 API）。
背景与带宽证据见 [Translation 三维站点加载慢与 HTTP/1.1 溯源](9c15ce40-c2f9-4c44-afe6-ede26e6cb8d3)；部署/前缀问题见 [公网实测诊断](933d3b7b-396a-4f92-a8ff-62bd719670a8)。

## 1. 根因：`proxy_cache_path` 是死配置

配置文件顶部声明了缓存区：

```nginx
proxy_cache_path /www/wwwroot/translationbe.dawnivers.top/proxy_cache_dir levels=1:2 \
    keys_zone=translationbe_dawnivers_top_cache:20m inactive=1d max_size=5g;
```

但下面 `location ^~ /` 里**没有任何 `proxy_cache` 指令** → 5GB 缓存目录永远不写入。声明与启用是两件独立的事，缺一不可。

## 2. 先定策略：该缓存什么

后端不是静态站，是 Express 包高德 API + 本地 Postgres。按「数据源 / 变更频率」分档：

| 接口 | 数据来源 | 变更频率 | TTL | 价值 |
|---|---|---|---|---|
| `/getStationInfo` | 本地 DB（含人流量，可能实时） | 不确定 | **默认不缓存** | 有风险，先留空 |
| `/getLinePlan` | 高德 `v5/direction/transit/integrated` | 基本不变 | **1h** | 最高（路径规划配额最贵） |
| `/getWeather` | 高德 `v3/weather/weatherInfo` | 分钟级 | **5m** | 高（省日配额） |
| `/getLine` | 本地 DB，约 60KB | 几乎不变 | **10m** | 中（只省回源，不省传输） |

关键判断：**服务端 `proxy_cache` 省的是「回源」（本地约 70–320ms），省不了客户端传输**。本项目瓶颈是 ~3Mbps 出口，所以 `/getLine` 那 60KB 的收益主要来自给浏览器发 `Cache-Control`，而不是 `proxy_cache`。真正值得开服务端缓存的是两个烧高德配额的接口。

实测响应头（未缓存态）：`/getLine` 60501B、`ETag` 存在、`Vary: Accept-Encoding`、无 `Cache-Control`；`/getWeather` 278B；`/getStationInfo` 129B — 都是小响应、低延迟，进一步说明服务端缓存是为了配额不失效，不是为速度。

## 3. 插入位置（宝塔特有坑）

必须插在 `#WEBSOCKET-SUPPORT END` 之后、`#PROXY-CONF-START` **之前**：

```
#WEBSOCKET-SUPPORT END
  ...新增三段 location = ...
#PROXY-CONF-START
location ^~ / { ... }   ← 兜底，原样保留不能删
#PROXY-CONF-END
```

原因：宝塔面板重写反向代理时只覆盖 `#PROXY-CONF-START … #PROXY-CONF-END` 之间的内容，写在 marco 外面才不会在面板改代理时被冲掉。

`location = /xxx` 是精确匹配，优先级高于 `location ^~ /`，因此书写顺序无所谓，也不会对抗 `/nginx/` 前缀段。

## 4. 单接口模板

```nginx
location = /getLine {
    proxy_pass http://127.0.0.1:8092;
    proxy_set_header Host $http_host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
    proxy_set_header X-Forwarded-Host $host;

    proxy_cache translationbe_dawnivers_top_cache;
    proxy_cache_valid 200 10m;
    proxy_cache_key "$scheme$request_method$host$request_uri";
    proxy_cache_lock on;                  # 并发只回源一次
    proxy_cache_use_stale error timeout updating http_500 http_502 http_503 http_504;
    proxy_cache_background_update on;

    add_header X-Cache-Status $upstream_cache_status always;
    add_header Cache-Control "public, max-age=600" always;
    add_header Strict-Transport-Security "max-age=31536000" always;
}
```

差异点：`/getWeather` 用 `proxy_cache_valid 200 5m` + `max-age=300`；`/getLinePlan` 用 `1h` + `max-age=3600`，且因查询参数多（每对起终点一个缓存键），可选 `proxy_cache_min_uses 2` 防膨胀。

`proxy_cache_key` 含 `$request_uri`，所以带 `?city=310000&extensions=base` 的请求会按参数整键区分 —— 这是期望行为。

想去重可用 `include`：把公共 proxy 头与缓存指令抽到 `/www/server/nginx/conf/proxy_api_common.conf`（路径相对 nginx prefix），每段只剩 3–4 行。注意 `include` 里**不要再写 `add_header Cache-Control`** 以外的实例差异项，否则重复头。

## 5. 三个必知坑

1. **`add_header` 不继承**：location 内一旦有自己的 `add_header`，server 层的 `Strict-Transport-Security` 与 `Alt-Svc` 全部不再下发。每个 location 都要补一遍（API 响应影响小，但报错路径会看见不一致）。
2. **CORS 头会随响应进缓存**：Express 返回的 `Access-Control-Allow-Origin: *` 会被一起缓存，因此跨域仍正常；反过来说，**带 `Set-Cookie` 或用户态的接口绝对不能进缓存区**。
3. **`immutable` 只对内容哈希文件名安全**：`index-<hash>.js`、`trainAndChisa_static-<hash>.glb` 可以；无哈希的 `tileset.json` 不能长期 immutable，否则替换瓦片后客户端不更新。

## 6. 部署与验收

```bash
CONF=/www/server/panel/vhost/nginx/translationbe.dawnivers.top.conf
cp -a "$CONF" "$CONF.bak-$(date +%Y%m%d-%H%M%S)"
mkdir -p /www/wwwroot/translationbe.dawnivers.top/proxy_cache_dir
chown -R www:www /www/wwwroot/translationbe.dawnivers.top/proxy_cache_dir
nginx -t && nginx -s reload
```

```bash
curl -sI https://translationbe.dawnivers.top/getLine | grep -i x-cache-status   # 第一次 MISS
curl -sI https://translationbe.dawnivers.top/getLine | grep -i x-cache-status   # 第二次 HIT
```

两次都 `MISS` 的常见原因：`proxy_cache_path` 目录不存在或 www 无权限；后端响应自带 `Cache-Control: no-cache`（当前 Express 没带，可排除）。

`nginx -t` 报错对照：

| 报错 | 原因 | 处理 |
|---|---|---|
| `proxy_cache_path directive is not allowed here` | 该行被放进 `server{}` | 移到文件最顶部、`server {` 之前 |
| `zone "translationbe_dawnivers_top_cache" is unknown` | `proxy_cache_path` 未生效 | 同上 |
| `unknown directive "http3"` | nginx 未编译 QUIC | 删 `http3 on;` 与 `listen 443 quic;` |

## 7. 与前端/静态资源的关系（分层结论）

- 前端**不需要任何改动**：缓存是纯服务器行为。前端只剩「上传 dist」一步。
- 分层优先级：**浏览器 `Cache-Control` > 服务端 `proxy_cache`**。要让人「第二次打开快」，靠前者；要保高德配额，靠后者。
- 666 瓦片静态服（`location /nginx`，`alias /www/wwwroot/nginx_assets`）要同时做三件事：`autoindex off`（原 `autoindex on + autoindex_localtime on` 会暴露目录、大目录列表 30s）、`add_header Cache-Control "public, max-age=31536000, immutable" always`、`access_log off`。
- 但宝塔反代模板默认 `if ($static_file... = 0) { add_header Cache-Control no-cache; }`（溯源见 9c15ce40）会盖掉上游缓存头 —— **不改反代，666 那头白改**。改反代 conf 时注意 `proxy_pass http://127.0.0.1:666;` 结尾不许有斜杠、不许带 URI，否则 `/nginx` 前缀被剥、瓦片 404。
- **`PRELOAD_TRAIN` 权衡**（`src/views/cesiumView.vue`，开屏是否等列车模型解析完）：`true` 在 3Mbps 下首开多等约 25s（8.62MB 模型），但进「线路轨迹」立即出模型；`false` 首开 2–4s，第一次看轨迹要等加载。演示场景建议 `true` + 提前自开一次页面预热（首次落缓存，现场秒开），比现场点开发现列车不出来稳。
