---
id: "8de40912-656f-46d4-adae-7a63db262ae3"
title: "/realtime 面板点站点起跑：jumpTo 只挪 clock.startTime 不重建漫游（startTimeBetweenStations + startOffset 语义）"
description: "点击面板站点让列车从两站间折点起跑的落地实现：startTimeBetweenStations、jumpTo/startOffset 语义、为何不能挪时间表原点、实测数据，以及 follow/third 视角模式未接入 UI 的现状。"
status: "active"
created_at: "2026-10-17T14:51:01.286Z"
updated_at: "2026-10-17T14:51:01.286Z"
content_hash: "e3a2db7e261183a0cb10358c01d127c74eafcef2e9ef9050e62ae1a6e8798776"
source_paths:
  - "Translation/src/cesiumTools/lineAndpoints/train/trainSchedule.js"
  - "Translation/src/cesiumTools/lineAndpoints/train/trainRoam.js"
  - "Translation/src/components/bottom/RealtimePanel/RealtimePanel.vue"
session_ids:
  - "9686214f-cbbc-4952-899d-2405886f9ea0"
memory_body_ids:
  []
---

实现层记录，补充 `6ec9d498-16c2-4821-b81b-e680ce4da503`（采样表/addSample）、`3fe1947f-509c-4def-b914-757bbb86722b`（handleTick 与朝向）、`7f1a6f08-9d0f-4d25-adfe-c436ac157c88`（内核纪律）。源文件：`Translation/src/cesiumTools/lineAndpoints/train/trainSchedule.js`、`trainRoam.js`、`Translation/src/components/bottom/RealtimePanel/RealtimePanel.vue`。

需求：点击 `/realtime` 面板上的站点，列车从「该站与上一站之间的某个线路折点」出发，且不要重新调用 `startRoam` 重建漫游。

## 1. 方案：移动时间轴起点，不重建任何资源

采样表、24MB 模型、相机全部复用，切换瞬间完成。只有切线路（`switchLine`）和点 ⇄ 反向（`reverseDirection`）才走 `startRoam({ keepCamera: true })` 重建。

## 2. `trainSchedule.js`：`startTimeBetweenStations(schedule, index)`

给定站点下标，返回该站与上一站之间**折线折点**在时间表上的时刻。

- 取区间**正中那个顶点**，保证每次点同一站都停在同一位置，且确实落在两站之间；
- 首站（index 0）无「上一站」→ 返回 0，等价正常发车；
- 两站紧邻、中间没有折点 → 退化为从该站到站时刻起跑。

## 3. `trainRoam.js`：`jumpTo(t)` 与 `startOffset`

```js
jumpTo(t) {
  this.startOffset = clamp(t, 0, total);
  clock.startTime  = startTime + startOffset;   // 循环时回到这个新起点
  clock.currentTime = clock.startTime;
}
```

**关键约束：`this.startTime`（时间表原点）必须保持不变，只挪 `clock.startTime`。**
因为 `handleTick` 里算的是 `t = currentTime − startTime`；若把原点一起挪，t 归零，高亮与站序会直接跳回第一站。

`restart()`（面板 ↺ 重播）随之改成回到 `clock.startTime`（新起点），而不是首发时刻。

## 4. `RealtimePanel.vue`：站点行可点击

```js
const jumpToStation = (index) => {
  if (!roam?.schedule) return;
  roam.jumpTo(startTimeBetweenStations(roam.schedule, index));
};
```

配套加了 `cursor: pointer`、悬停高亮、`title` 提示（形如「从常熟路 与 衡山路 之间起跑」）。数据结构上站点行已是 `rp-station` 的 `v-for`，直接挂 `@click`。

## 5. 验证

离线（node，1 号线真实数据）：

| 点击站点 | 上一站发车 s | 起跑 s | 本站到站 s | 顶点区间 |
|---|---|---|---|---|
| 第 2 站 | 0.0 | 26.6 | 76.4 | 1..23 |
| 第 6 站 | 374.6 | 387.6 | 433.9 | 73..76 |
| 第 20 站 | 1467.2 | 1499.4 | 1536.2 | 203..232 |
| 第 28 站 | 2233.3 | 2269.6 | 2316.7 | 318..333 |

全部落在两站区间内；index 0 与越界 index 均返回 0；失败数 0。

浏览器实测：初始偏移 0（高亮 1 富锦路，已过 0）；点第 20 站 → 1499 s（node 侧 1499.4），高亮 19 常熟路，已过 18；点回首站 → 0 s。零 pageerror。

## 6. 已知行为与未决项

- **点第 20 站（衡山路）时高亮落在第 19 站（常熟路）**，这是正确的：车被放在「常熟路—衡山路」中间，尚未到衡山路，当前站即刚离开的常熟路，再跑约 36 s 才高亮衡山路。若要求「点哪站高亮哪站」，需改成从该站**到站时刻**起跑（车停在站上），语义就变成「从站上出发」而非「两站之间出发」——待用户确认。
- **`followMode` 的 `third` / `free` 目前是死代码**：`trainRoam.js` 中 `this.followMode = 'follow'` 初始化后无任何赋值，`setFollow` 仅在 `load()` 里以当前值调用一次，面板无切换入口（只能控制台 `roam.setFollow('third')`）。
  - `follow`：`camera.lookAt(pos, HeadingPitchRange(viewHeading, viewPitch, range))`，方位由鼠标拖出的 `viewHeading/viewPitch` 决定，列车转弯时相机不跟转；默认 190 m、俯角 −22°。
  - `third`：`camera.lookAtTransform(frame, Cartesian3(-90, 0, 36))`，航向取自 `entity.computeModelMatrix` → `Transforms.fixedFrameToHeadingPitchRoll`，并按帧间隔指数平滑（时间常数约 0.3 s，`heading += diff * (1 - Math.pow(0.001, delta / 0.3))`），车尾 90 m、上 36 m（≈97 m 距离），相机随车转。
  - 鼠标处理只挡了 `followMode === 'free'`，切到 `third` 后拖拽仍会改 `viewHeading` 却无效果——放开该模式前需一并修掉（挡住或切模式时同步）。
