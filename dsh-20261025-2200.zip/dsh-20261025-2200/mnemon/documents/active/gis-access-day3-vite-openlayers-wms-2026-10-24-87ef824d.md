---
id: "87ef824d-134d-45ca-8303-d0278b2f3c7c"
title: "gis-access Day3 前端闭环：Vite+OpenLayers 跑通 WMS 武汉区划与四个实测坑（2026-10-24）"
description: "记录 D3 让武汉区划在地图上跟随拖动的落地过程与证据：Vite 起站反复失败的四类根因（npm 不装 devDependencies、中文路径 GBK 乱码、OSM 国内不可达、npx 交互卡死）、Vite proxy 绕 CORS 的实测数据、WMS 1.3.0 轴序与 GCJ-02/WGS84 偏移的看图判读，供后续 D4+ 与排障复用。"
status: "active"
created_at: "2026-10-24T03:05:05.385Z"
updated_at: "2026-10-24T03:05:05.385Z"
content_hash: "061f8f54946be13fd65304746761f4e05265349a56f37dcc05cd5642e72f9a9f"
source_paths:
  - "gis-prep/Day3-记录.md"
  - "gis-prep/day3-map.png"
session_ids:
  - "5b998bb9-e533-4b59-baa8-70ad689b34cd"
memory_body_ids:
  []
---

# gis-access Day3：前端最小闭环（2026-10-24 实测）

执行层来自计划 `90391f9a-6af3-43b5-bf4d-7fe334b99d59`（W1 D3「武汉区划跟着地图拖动」），设计方案见 `266aea70-7a25-4d94-8359-39555b8b651f`，图层与 Store 见 `e2a4925e-c390-44f3-bd15-8bf165e70b28`，GeoServer 启停见 `0f56bc48-134c-47d0-8881-8f32190f65aa`。本文只记 D3 当天真正踩到并修掉的东西。

项目根（工作区外）：`D:\WebGIS\web三维开发\gis-access`，涉及 `src/main.js`、`index.html`、`src/style.css`、`vite.config.js`、`package.json`。

## 1. 验收结果

- 技术栈：Vite + 原生 JS + OpenLayers `ol@10.11.0`，不套 Vue（按 266aea70 的结论）。
- `http://localhost:5173/` 打开后：高德 XYZ 底图 + 半透明 WMS 武汉 13 区叠加。
- 拖动实测（屏幕拖拽约 250px）区划与底图同步位移、只剩新洲区一小块顶在左侧，说明投影换算全程正确；「回到武汉」视图复位正常。
- 截图 `gis-prep/day3-map.png`，过程记录 `gis-prep/Day3-记录.md`。
- 服务实测：GeoServer 8080 → HTTP 302，Vite 5173 → HTTP 200；WMS GetMap 直连与经 proxy 均 HTTP 200、**55759 bytes 完全一致**（证明 proxy 透明转发、未改写请求）。

## 2. 四个真坑（按耗时排序）

### ① `npm install ol` 不装 devDependencies（最隐蔽）
`package.json` 写着 `"vite": "^8.3.4"`，但 `node_modules/vite/` 根本不存在，`npm install` 还回报 `up to date`；`npm ls` 只显示 `ol@10.11.0`。目录顶层依赖齐全、唯独 dev 依赖缺失 → 之前安装时 dev 被跳过（`NODE_ENV`/`--omit=dev` 一类），后续 `npm install` 因 lock 已记录而不会自动补齐。
修法：`npm install --include=dev`（"added 15 packages"），再确认 vite 落地。
**规则**：`npm install <包名>` 只装该包，不顺带补齐 devDependencies；项目脚本跑不起来先 `npm ls` 看 dev 依赖是否缺席。

### ② 中文路径被 Node 按 GBK 解码成乱码
`node node_modules/vite/bin/vite.js` 报
`Cannot find module 'D:\WebGIS\web涓夌淮寮€鍙慭gis-access\node_modules\vite\bin\vite.js'`。
即 `三维开发` 的 UTF-8 字节被按 GBK 解释，路径整体失效。
修法：不把中文路径写进命令参数——用 `-WorkingDirectory`/`cd` 切进目录，参数只写相对路径。

### ③ OSM 底图在国内不可达，必须换源
`tile.openstreetmap.org` 15 s 超时（HTTP 000，0 bytes），首次打开只有区划没有底图，极易误判为「OL 写错」。
实测：**高德 `webrd0X` HTTP 200（13651 bytes）✅**；`GeoQ` 瓦片 HTTP 000 ❌。
结论：本项目及后续项目底图默认用高德 XYZ，不要直接挂 OSM。

### ④ `npm create vite` 遇非空目录 + `npx vite` 交互卡死
- 目录已存在 `deploy/` 时 `npm create vite` 直接 `Operation cancelled`，需 `--overwrite`。
- `npx vite --port 5173` 停在 `Need to install the following packages: vite@8.3.5 / Ok to proceed? (y)`，dev server 永远不起，5173 无响应；还会产生日志占用冲突（`Start-Process: cannot access 'vite.log' because it is being used by another process`）。
- 处置：`Get-Process` 找出残留 `npx-cli.js vite --port 5173` 杀掉、清日志，再直接用本地 `node node_modules/vite/bin/vite.js` 起。**脚本化场景一律用本地 vite 可执行文件，不用 npx。**

## 3. Vite proxy 绕 CORS（本机实证）

`vite.config.js` 配 `/geoserver → http://localhost:8080`，前端写相对路径。
- 浏览器只与 5173 同源通信，同源策略不触发 → 不必改 GeoServer `web.xml`（与 266aea70 坑 5 一致）。
- 代理就绪前会看到 `proxy GetMap HTTP 502`（GeoServer 未起），GeoServer 起来后立刻 200。
- 本次 GeoServer 冷启约 **9 s 到 302**；既往记录为 21.5–28 s。别写死等待，用轮询探测。

## 4. 看图判读：WMS 轴序与坐标偏移

- **WMS 1.3.0 在 EPSG:4326 下 bbox 是 lat,lon**（1.1.1 是 lon,lat），按 1.1.1 习惯传参会把图丢到南半球；统一用 1.1.1 或显式版本参数。面试高频题。
- 原理：`ImageWMS` 要图不要数据——把当前视野范围与分辨率发给 GeoServer，服务端渲染 PNG 返回；视野一变就重新出图，所以拖动时区划不会拉伸变形。
- **区划边界与高德省界错开一小段，是坐标系而非代码错**：`admin_area` 是 WGS84，高德瓦片是 GCJ-02，中国境内差约 300–800 m，与 `3f371166-c605-42a6-8eff-2b12279a73ca`（智慧地铁请求高德未转 GCJ-02 导致错站）同源。
- 当前取舍：当形状参照物够用先不动；做热力图时再选「换 WGS84 底图（天地图/Mapbox）」或「给 `admin_area` 另存 GCJ-02 副本」。

## 5. 会话结束后的重启姿势

Vite dev 挂在后台任务里，**会话结束后可能被回收**（同 `e2a4925e` §6 的进程树连坐问题）。重启：

```powershell
cd D:\WebGIS\web三维开发\gis-access
$env:NODE_ENV='development'
node node_modules/vite/bin/vite.js --port 5173
```

起 dev 后先探测 5173 是否 200，再谈页面。

## 6. 下一步（D4）

1. 建 `poi` 表 + GCJ-02 → WGS84 转换 + GiST 索引。
2. GeoServer 发布 POI 图层、配点样式。
3. 前端加载 POI 与图例。
