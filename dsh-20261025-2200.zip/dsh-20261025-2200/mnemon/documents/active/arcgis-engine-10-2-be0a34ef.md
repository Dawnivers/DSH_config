---
id: "be0a34ef-6f39-4e5b-a4d1-eb0c3b469dfa"
title: "ArcGIS Engine 10.2 几何演示程序：数据准备与运行前置条件"
description: "第3章 ArcObjects 几何演示程序落地所需的最小数据集：Geometry.mxd + multipoint/polyline/polygon 三个空 shapefile 的命名、几何类型、投影坐标系、图层顺序与可写性要求，含 CanAlterSpatialReference 对 shapefile 行为的勘误（ESRI NIM007619）。"
status: "active"
created_at: "2026-10-07T03:09:35.839Z"
updated_at: "2026-10-07T03:09:35.839Z"
content_hash: "39cf860fece46200ea6b2b7db78e49acf26a1de2b3ae356781956aedeecd1484"
source_paths:
  - "第3章界面和代码(1).doc"
session_ids:
  - "3b2e8126-ad2d-43cf-a14f-759c77e390aa"
memory_body_ids:
  []
---

# ArcGIS Engine 10.2 几何演示程序：数据准备与运行前置条件

相关文档：`11573488-6d27-44e6-837a-400007e4ea72`（第3章《界面和代码》的 .doc 提取过程、菜单项与代码缺陷清单）。本文只记录该章程序**跑起来需要在数据侧准备什么**，以及一条关于空间参考接口的勘误。

## 1. 结论：不需要任何真实地理数据

程序没有一行代码往地图控件里加载数据；三个图层只是"容器"，几何对象全部由代码构造。所需的全部数据是**一个 mxd + 三个名字和类型都卡死的空图层**。

```
D:\ArcGISData\Geometry\          ← 建议纯英文路径
├─ Geometry.mxd                  ← ArcMap 10.2 建立并保存
├─ multipoint.shp/.shx/.dbf/.prj ← 几何类型必须是「多点 MultiPoint」
├─ polyline.shp/.shx/.dbf/.prj   ← Polyline
└─ polygon.shp/.shx/.dbf/.prj    ← Polygon
```

| 图层 | 必须的几何类型 | 使用方 | 初始要素数 |
|---|---|---|---|
| multipoint | **多点 MultiPoint（不是 Point）** | AddGeometry、AddGeometryCollection、InsertGeometriesCollection、SetGeometries、AddPointCollection | 0 即可 |
| polyline | Polyline | AddSegments、SetSegments | 0 即可 |
| polygon | Polygon | CreatePolygon | 0 即可 |

QuerySegments、QueryPoints、UpdatePoint 只在内存中造几何并弹窗，不落盘、不依赖数据。

## 2. 每个图层的硬性要求

1. **图层名必须恰好为 `multipoint` / `polyline` / `polygon`**。`addFeature()` 用 `layer.Name.ToLower() == layerName` 按名匹配；ArcMap 加载 shapefile 后图层名默认等于文件名（去扩展名），所以按上述命名即可，大小写不敏感。
2. **可以 0 个要素，但 schema 必须已建好**。`addFeature` 先删光再插 1 个；空图层里 `NextFeature()` 返回 null，属正常路径。
3. **必须有坐标系（.prj）**。`GetSpatialReference` 打印 `IGeoDataset.SpatialReference.Name`，缺 .prj 时为 `"Unknown"`；shapefile 的坐标系参数保存在同前缀的 .prj 文件中（ESRI 文档：https://desktop.arcgis.com/zh-cn/arcmap/latest/manage-data/shapefiles/fundamentals-of-a-shapefiles-coordinate-system.htm ）。
4. **建议统一用投影坐标系（单位：米）**，如 Beijing 1954 3 度带或 WGS 1984 UTM。理由：代码写入的坐标量级只有 0～60，当地理坐标系处理会被当成"度"，数据跑到赤道附近、比例尺异常。
5. **不需要任何属性字段**。`featureBuffer` 只赋 `Shape`；shapefile 自带的 FID/Shape/Id 足够。

## 3. 数据与工程侧最易翻车之处

- **mxd 必须真的把三个图层加载进去并保存**。`loadMapDocument()` 只做 `LoadMxFile`，随后全靠 `Map.get_Layer(i)` 按名找图层；数据本体仍是磁盘上的独立文件，mxd 只记录数据源路径。
- **图层顺序有讲究**：`GetSpatialReference` 与 `ChangeLayerSpatialReference` 只操作 `get_Layer(0)`（TOC 最顶层）。想让它们作用于 multipoint，就在最后一次添加 multipoint（新加图层默认压在最上层），再存 mxd。
- **必须可写、且不能被占用**：`addFeature` 走 `IWorkspaceEdit` 真写盘。运行前关掉 ArcMap（否则 .shp/.shx/.dbf 被锁，编辑失败）；数据目录别放只读位置或网络共享；mxd 只读时 `saveDocument` 只会提示"地图文件是只读的"。
- **路径避免中文/空格**：本机用户名是"林先语"，`D:\Users\林先语\...` 这类路径下跑 ArcGIS 10.2 文件型数据源是老毛病高发区，建议放 `D:\ArcGISData\Geometry\`。
- **建好后别搬动数据**：mxd 出现红叹号后 `addFeature` 打开要素类会直接失败。存 mxd 时勾"存储相对路径"，或保持数据原位。
- **不要用"嵌入图层数据"把数据塞进 mxd**：本章代码不需要，只会让 mxd 体积暴涨。
- 非数据但缺一不可：ArcGIS Engine Runtime 10.2（或 Desktop 10.2）+ 有效授权；Engine SDK for .NET（配 VS2010），引用 `ESRI.ArcGIS.*` 程序集且**别漏 `ESRI.ArcGIS.CatalogUI`**（`ISpatialReferenceDialog` 需要）；目标平台 x86；窗体放 `axMapControl1` 与 `axTOCControl1`，设计器里把 TOC 的 BuddyControl 设为 MapControl；mxd 版本必须 ≤ 运行时版本。

## 4. 勘误：shapefile 的 `CanAlterSpatialReference` 是被支持的场景

先前（第3章审阅阶段）判断"shapefile 的 `CanAlterSpatialReference` 大概率返回 false"，**该判断不准确，已收回**。

证据：ESRI 缺陷记录 **NIM007619**（IGeoDatasetSchemaEdit::CanAlterSpatialReference should perform check for read/write access in case of shapefile in a network share，提交 2007-03-27，状态 Non-Reproducible）——标题本身把"网络共享上的 shapefile"当作该接口应支持的正常场景，说明 shapefile 可以通过 `AlterSpatialReference` 改写 .prj。社区通行做法（ArcEngine 为数据添加坐标参考，https://developer.aliyun.com/article/657936 ）也是同一套 QI + `CanAlterSpatialReference` + `AlterSpatialReference`，并以 GP 的 `DefineProjection` 作为替代方案。

仍需注意两点：
- 数据只读、被 ArcMap 占用或位于受限共享时，`CanAlterSpatialReference` 返回 false，此时**代码会静默跳过不做任何事，却照样弹"更改图层空间参考成功"**。想确认真的改了，改完再点一次 GetSpatialReference 看名字是否变化。
- 它只改**元数据**，不做投影变换，坐标数值不变。因此把 4214（Beijing 1954，地理坐标系）套到 0～60 的坐标上，地图表现会怪，属正常现象。

## 5. 一次性准备步骤

1. 建目录 `D:\ArcGISData\Geometry\`。
2. 在 ArcCatalog 的该目录下新建三个 shapefile：`multipoint`（要素类型选"多点 MultiPoint"）、`polyline`、`polygon`；每步都在"编辑"里指定同一个投影坐标系。
3. 打开 ArcMap 新建空白文档 → 数据框坐标系设为同一坐标系 → 先加 polyline、polygon，**最后加 multipoint**（保证它在 TOC 最顶层）→ 另存为 `Geometry.mxd`（勾"存储相对路径"）。
4. 关掉 ArcMap，确认三个图层无进程占用。
5. 运行程序，在"打开地图文档"对话框选 `Geometry.mxd`。
6. 验证：先点 `IGeometryCollection → AddGeometry`，地图上应出现 10 个点（坐标 (0,0)~(18,18)）。

运行前自查三条：TOC 里三个图层齐全且无红叹号；multipoint 在最顶层；ArcMap 已关闭。

## 6. 已知代码侧几何缺陷（不是数据建错）

AddGeometry / AddGeometryCollection / SetGeometries 构造的是一串**共线点**（都落在 y=x 上），包围盒面积为零，随后的 `Extent = multipoint.Envelope` 可能缩放到空白甚至报错。想看到直观点群，用 InsertGeometriesCollection（三批点不共线）或 AddPointCollection。

若 mxd 里没有匹配图层：循环结束时 `layer` 停在最后一个图层，几何会被**写错图层**；几何类型不匹配则直接抛异常；mxd 里一个图层都没有时 `layer` 为 null，在 `featureLayer.FeatureClass` 处 **NullReferenceException**。
