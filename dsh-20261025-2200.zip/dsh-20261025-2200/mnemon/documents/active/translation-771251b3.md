---
id: "771251b3-3cd0-40fd-9317-f7f609285a72"
title: "Translation 智慧地铁：路径规划「开始规划前清场」——站点/气泡全灭与逐条快照还原"
description: "2026-10-19 在 guideload/useRoutePlan.js 实现「点开始规划先清场」：清场前逐条快照（cone/circle/popup）、走 hideStationByName 一次灭掉三类对象、发请求前同步执行，并在改起终点/退出模式/站点晚渲染三处还原；含不动 StationPanel 三开关的取舍与计数不同步的已知代价，以及用气泡 DOM 选择器做的三步验证。"
status: "active"
created_at: "2026-10-19T05:52:24.741Z"
updated_at: "2026-10-19T05:52:24.741Z"
content_hash: "435a6383685f22d2b13b0db2fde3bea02f258e1259514b0a520557f37b65cfaa"
source_paths:
  - "Translation/src/components/bottom/StationPanel/QueryModePanel/guideload/useRoutePlan.js"
  - "Translation/src/cesiumTools/lineAndpoints/setpoints.js"
session_ids:
  - "20b0e8aa-484e-40db-aa92-22e833197d7d"
memory_body_ids:
  []
---

# 路径规划：点「开始规划」先清场（站点与气泡全灭 + 快照还原）

日期：2026-10-19。入口：`/nodes` → 站点面板 → 查询模式「路径规划」。

前置/相关文档：
- `44fe1831-c29a-4d4c-aed8-334dfb8fa556` — 路径规划模式四层结构（planModel / renderRoute / useRoutePlan / RouteDesign），本文只记其后的增量。
- `bf56739f-8abd-4325-b4b9-bb55421a5d19` — 起终点气泡「起/终」徽标覆盖（清场清掉的就是这些气泡）。

## 1. 用户要求

> 「优化：每次点击开始规划后，先清除场上所有站点和气泡」

即进入一次规划，画面上只应剩下本次路线，18 条全局线、400 个站点标记和它们的名字气泡都要先消失。

## 2. 做法（`guideload/useRoutePlan.js`）

新增一对函数，围绕 `setpoints.js` 的官方入口 `hideStationByName(stationObjs, names, false)` 展开：

```js
const hideAllStations = () => {
  stationObjs.forEach((s) => s.popup?.removeQueryPopup?.());  // 屏上的详情卡先收掉
  stationObjs.forEach((s) => {                                // 逐条记显隐快照
    savedStationShow.set(s, { cone: …, circle: …, popup: … });
  });
  hideStationByName(stationObjs, names, false);               // 光锥/底圈/气泡一起灭
};
```

调用点在 `search()` 里，**紧跟 `clearRoute()` 之后、发请求之前**：清场是同步的，接口还没回来屏幕已经干净，不会出现「旧站点 + loading」并存的一帧。

### 为什么走 `hideStationByName` 而不是自己逐个改 `show`

一个站点由三类对象组成，形态各不相同：

| 组成 | 类型 |
|---|---|
| 光锥 | Primitive |
| 底圈 | Entity |
| 名字气泡 | DOM |

三者的显隐 API 不同，`hideStationByName` 已经把差异兜住；自己写循环极易只灭掉其中两种，留下「气泡飘在空处」。

### 为什么记快照，而不是退出时一律点亮

用户进来前可能只开着 1 号线、或手动关掉了两条线。一律置 `true` 会把他原本的状态打开。所以清场前对每个站点存一份 `{ cone, circle, popup }`，还原时逐条写回。

## 3. 三处还原（缺一就会留下空场面）

| 触发 | 动作 |
|---|---|
| 改起点 / 终点 | 走 `watch([origin, destination])` → 旧方案作废的同时站点回来 |
| 切走或退出路径规划 | `onBeforeUnmount` 里 `clearRoute()` 顺手还原 |
| Toolbar 的站点实体比面板晚渲染（`stationObjs.length` 变化且已有方案） | 补清一次，否则新冒出来的那批还是亮的 |

第三条是直接刷 `/nodes` 时的时序问题，与 `useRoutePlan.js` 里 `watch(() => lineEnts.length, hideGlobalLines)` 补藏全局线是同一类补丁。

## 4. 有意的取舍：不动 StationPanel 的三开关

StationPanel 那套状态机（`checked` / `lineStationOn` / `forced`）**完全没碰**，只改三维对象的 `show`。

- 好处：退出规划后用户原来的站点状态能原样回来，不需要从零重建。
- 代价：清场期间左下角「N/M 显示」的计数仍按开关算，与屏幕上实际看到的不一致。

判断：可接受。计数错位是一段临时状态，而改开关再重建要处理三开关的互相覆盖，风险大得多。

## 5. 验证（浏览器桥读 DOM）

气泡是 DOM 元素，可当作清场是否生效的探针；光锥/底圈是 Cesium 图元，DOM 看不到。

| 步骤 | 现象 |
|---|---|
| 点「全部显示」，取源深路（2 号线，粉色 `#ff7fb0`）的气泡选择器 | 命中 → 气泡确实在显示 |
| 进路径规划 → 五角场 → 世纪大道 → 开始规划 | 同一选择器 **no element matched** → 全场气泡已清 |
| 再点「路径规划」退出模式 | 源深路气泡**又命中** → 快照还原生效，用户原状态没被吞 |

气泡变了即说明 `hideStationByName` 这次调用跑到位——三类对象的 `show` 是在同一次调用里一起切的。

## 6. 改这块时的约束

- 清场必须在**发请求前**，不要挪到 `then` 里，否则请求失败时旧站点已经灭了、面板又是旧数字，观感更乱。
- 还原必须逐条按快照，别图省事改成 `show = true`。
- `removeQueryPopup()` 不能漏，否则详情卡会压在路线之上。
