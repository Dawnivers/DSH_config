---
id: "60592d56-a0fc-4a32-bd93-1bf0fcabea37"
title: "Translation 智慧地铁：Cesium ion / 高德 / PG 密钥外置到环境变量的做法与实测（前端 key 藏不住的证据）"
description: "Translation 项目把三处硬编码密钥（Cesium ion 令牌、高德 Web 服务 key、PostgreSQL 密码）迁到环境变量的完整落地记录：文件落点、Node 自带 process.loadEnvFile 免 dotenv 方案、Vite 把 VITE_ 变量内联进 dist 的实测证据、后端 IP 白名单/ion 资产限制等加固建议，以及明文残留扫描与接口联调验证数据。"
status: "active"
created_at: "2026-10-20T07:39:11.522Z"
updated_at: "2026-10-20T07:39:11.522Z"
content_hash: "82bfa8c88891cd04f3517c00cc0ac73818397c067c4fa1ecac0d0975f3eea7c3"
source_paths:
  - "Translation/src/cesiumTools/sceneManager.js"
  - "Translation/.env.example"
  - "Translation/.gitignore"
  - "Translation/README.md"
  - "Translation_BE/config.js"
  - "Translation_BE/.env.example"
  - "Translation_BE/.gitignore"
  - "Translation_BE/PROMPT.md"
session_ids:
  - "5967f7e8-45e6-4b32-841d-a5c6b737ef75"
memory_body_ids:
  []
---

# Translation 智慧地铁：密钥外置到环境变量（2026-10-20）

需求原话：「搜索我的项目中的 cesium ion key 和后端的高德 key 应该如何设置到环境变量中，不被别人发现」。
工作目录 `D:\WebGIS\web三维开发\智慧地铁项目`，前端 `Translation/`（Vue3 + Vite + Cesium），后端 `Translation_BE/`（Express 5 + pg，Node v24.16）。

**核心结论一句话**：后端的 key 能真正藏住；前端以 `VITE_` 开头的 key 无论怎么写都会被 Vite 内联进 `dist` 的 js，只能减小危害，不能保密。

## 1. 三处密钥的原始位置（迁移前）

| 密钥 | 位置 | 形态 |
|---|---|---|
| Cesium ion 访问令牌 | `Translation/src/cesiumTools/sceneManager.js` 第 2 行 `Cesium.Ion.defaultAccessToken = '…'` | JWT，293 字符 |
| 高德 Web 服务 key | `Translation_BE/config.js`（`amap.key`） | 32 位 hex |
| PostgreSQL 密码 | `Translation_BE/config.js`（pg 连接池）+ `Translation_BE/PROMPT.md` 两处文档明文 | 短数字串 |

`Translation_BE` 当时**没有 `.gitignore`**，即 `.env` 与 `node_modules` 都会入库——这是迁移前必须一起修的前提。

## 2. 后端方案（可真正保密）

| 文件 | 作用 |
|---|---|
| `Translation_BE/.env` | 真值：`AMAP_KEY` / `AMAP_CITY` / `AMAP_ADCODE` / `PGUSER` / `PGPASSWORD` / `PGHOST` / `PGPORT` / `PGDATABASE` / `PORT` |
| `Translation_BE/config.js` | 全部改为读 `process.env`，缺 `AMAP_KEY` 时 `console.warn` |
| `Translation_BE/.env.example` | 可提交的模板 |
| `Translation_BE/.gitignore`（新建） | `node_modules` / `.env` / `*.log` |
| `Translation_BE/PROMPT.md` | 明文密码替换为 `<PGPASSWORD>` 并指向 `.env` |

**关键取舍：不引入 dotenv。** 用 Node 20.12+ 自带的 `process.loadEnvFile(path.join(__dirname, '.env'))`，本机 v24.16 直接可用，`node index.js` 启动命令完全不用改、`package.json` 无需加依赖。若将来 Node 版本降到 20.12 以下才需要换回 dotenv。

`.env` 写入时确认无 BOM（前 3 字节 `23 20 E5` = `# ` 开头正常的），Windows 下用 UTF-8 no-BOM 写，否则第一条变量名会带上 BOM 而失效。

## 3. 前端方案（只能减小危害）

| 文件 | 作用 |
|---|---|
| `Translation/.env.local` | `VITE_CESIUM_ION_TOKEN=…`（`*.local` 本就在 `.gitignore` 里） |
| `Translation/src/cesiumTools/sceneManager.js` | `Cesium.Ion.defaultAccessToken = import.meta.env.VITE_CESIUM_ION_TOKEN ?? ''` |
| `Translation/.env.example` | 模板 + 「前端没有秘密」的说明 |
| `Translation/README.md` | 补一段环境变量说明 |

## 4. 实测验证数据（可复用为回归检查清单）

| 检查 | 方法 | 结果 |
|---|---|---|
| 后端确实从 env 取值 | 起 8093 临时实例调接口 | `/getWeather` → 上海市 小雨 27℃（真打高德）；`/getLine` → 18 条线路（密码来自 env） |
| 源码明文残留 | 扫 107 个源文件（排除 `node_modules`/`dist`/参考项目/`.env`） | 迁移后 **0 命中**（迁移前 2 处：`PROMPT.md`） |
| 前端令牌是否进产物 | `npm run build`（1.0–1.6s）后 grep `dist/assets/index-*.js` | **1 个文件命中，令牌原样可读** → 内联实证 |
| 是否还有别的拷贝 | 令牌清空后 rebuild 再 grep | **0 命中**，说明除 `sceneManager.js` 外无第二处引用 |

## 5. "不被别人发现"实际可行的做法

**后端（真藏得住）**：key 只在 Node 进程里用，浏览器拿不到。再补两道：高德控制台把该 key 的**服务平台设为「Web服务」而非「Web端(JS API)」**，并给它配**IP 白名单**（只放部署机出口 IP）；`.env` 永不入库，部署时用环境变量注入。

**前端（藏不住，只能减害）**：
1. **本项目其实完全不用 ion**：底图是 ArcGIS `UrlTemplateImageryProvider`、地形用默认椭球、无 ion 的 3D Tiles/地形资产（`sceneManager.js` 中 terrain 相关是注释状态）。所以最彻底的做法是把 `.env.local` 那行**留空**，令牌根本不进产物，代码里 `?? ''` 兜底；空令牌构建已验证产物 0 命中。（本次因浏览器桥断开未做画面视觉验证，故先还原了真实令牌，这条是留给用户的选项。）
2. 若确实要用：ion 控制台 → Access Tokens → 把 token 限制到**具体资产**，并设置 **Allowed URLs** 为站点域名，被抄走也调不动其他资产。

## 6. 遗留 / 待办

- 那把高德 key **已在源码里明文存在过**（备份、会话记录、可能的压缩产物都可能带出），建议直接去高德控制台**删除重建**，新值填进 `.env`。改配置只能防「以后」。
- 当时运行中的 8092 实例仍是旧的内存配置（值相同，行为不变），**重启后**才走 `.env`。
- 前端若真要彻底去令牌，需在空令牌状态下补一次画面验证（底图/站点/线路是否正常）。

相关：`46077717-b034-4315-a3c1-f04be09fed52`（本项目 vite 的 `import.meta.env` 行为与 NODE_ENV 陷阱，与本次 `VITE_` 内联现象同源）。
