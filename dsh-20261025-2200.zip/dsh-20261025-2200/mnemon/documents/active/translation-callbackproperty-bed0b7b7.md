---
id: "bed0b7b7-e1e3-491b-80bd-51ffa66f4956"
title: "Translation 发展历程：线路生长动画实现（区间插值 + CallbackProperty）与站点→坐标映射实测"
description: "2026-10-12 落地发展历程线路生长动画：range 区间插值 + CallbackProperty 逐帧切片、站点→坐标映射实测（17/18 单调、4 号线是闭合环线无需特判）、端点夹到折线首尾的 534m 修正，以及验证中抓到的 3 个真 bug（playing 非响应式、三入口重复起播、端点差一截）与逐步实测数据；另记录未做的「相机飞到线路」及其实测注意点。"
status: "active"
created_at: "2026-10-12T10:27:31.583Z"
updated_at: "2026-10-12T10:27:31.583Z"
content_hash: "0ae397f1b0d6e2d612f10f4ef615c9d778a593722798499034baca922f33d2db"
source_paths:
  - "Translation/src/components/bottom/HistoryPanel/historyPanel.vue"
  - "Translation/src/stores/stationState.js"
  - "Translation/src/components/bottom/Toolbar.vue"
  - "Translation/src/config/shmetroHistory.js"
session_ids:
  - "session-d6cbf69c-ac7f-4b6b-a2a9-8468919b087a"
memory_body_ids:
  []
---

# 发展历程「线路生长动画」实现（Translation / 智慧地铁）

日期：2026-10-12。项目：`D:\WebGIS\web三维开发\智慧地铁项目\Translation`。
**本文取代记忆库文档 `34066e27-5ad4-41df-8448-8029411158f8` 的第 7 节**（那一节写的是「本轮有意没接动画、以及接动画的障碍」，现已落地）。

需求原话：「使用方案A，段头翻，不用闪光，不拖」——即：创建私有实体；里程碑文案在**段头**翻；中段补站的里程碑不做闪光提示；进度条不可拖动。

## 1. 改动文件

| 文件 | 改动 |
|---|---|
| `src/components/bottom/HistoryPanel/historyPanel.vue` | 接上生长动画：几何缓存、区间插值、raf 播放循环、三个按钮、生命周期清理 |
| `src/stores/stationState.js` | 新增共享 `lineEnts`（reactive 容器 + 元素 markRaw），并把文件注释改成「底部栏目面板与三维场景的共享状态」 |
| `src/components/bottom/Toolbar.vue` | 原本组件局部的 `let linesEnts = []` 改成用 store 里的 `lineEnts`；push 时 `markRaw(entity)`，重置时 `lineEnts.length = 0`（原来是 `linesEnts = []` 整体替换） |
| `src/components/bottom/StationPanel/StationPanel.vue` | 只改了一行注释里的变量名 |

## 2. 算法

**不给每条线配方向。** 数据侧用 `shmetroHistory.js` 每个里程碑的 `range: [lo, hi]`（已开通站的区间），每帧：

```js
const seg = t / 10;                                  // t 是当前进度，10 单位 = 一个里程碑
const i   = clamp(floor(seg), 0, N - 2);
const f   = seg - i;                                 // 段内进度
const loS = lerp(R[i][0], R[i + 1][0], f);           // 站点空间插值
const hiS = lerp(R[i][1], R[i + 1][1], f);
const a   = ceil(stationToCoord(loS));               // 站点空间 → 坐标空间
const b   = floor(stationToCoord(hiS)) + 1;
cur = CARTESIAN.slice(a, b);                         // 复用预转好的 Cartesian3
entity.polyline.positions = new Cesium.CallbackProperty(() => cur, false);
```

三种延伸情形自然覆盖：单头延伸只有一端动、两头延伸两端一起动、中段补站区间不动只是文案变。

**性能上的关键改进**：整条折线**只转一次** `Cartesian3` 数组，每帧只做 `slice`（复用对象）。
参考项目 `Progress.vue` 每帧 `Cesium.Cartesian3.fromDegreesArray(curPaths)`，11 号线 816 个点、
60fps 下每秒新建近 5 万个对象纯喂 GC。

## 3. 站点下标 → 坐标下标（这张表是整个动画的前提）

`line.positions` 是从 `src/assets/line1to18_2.json` 的 `geometry.coordinates` 来的**加密折线**，
站点下标不能直接 slice。做法：对每个站扫描全部坐标点取最近的一个，建 `map[站点sort] = 坐标下标`。

18 条线实测（2026-10-12）：

| 检查 | 结果 |
|---|---|
| 站→坐标下标严格递增 | **17/18 条是**（唯一例外见下）；这是 slice 能成立的前提 |
| 站点到折线的最近距离 | 绝大多数 **0m**（折线就是穿过站点的）；16 号线最差 95m |
| 相邻两站最多跨多少坐标点 | 2 号线 79、17 号线 67、16 号线 62 —— 站间生长连续，不会跳 |
| 唯一一处并列 | **14 号线第 13、14 站映射到同一个坐标点（140）**，最近距离 16m |

那处并列**不是新问题**：正是文献 `21ac9373-f092-4af2-9997-ead39da982cf` 里抓到的库内数据错误
（14 号线凭空多出的「东昌路」离真实「浦东南路」只有 16m）。而且 **14 号线只有 1 条里程碑**，
没有区间扩张，所以对动画无害。代码里仍然写了 `map[i + 1] = Math.max(best, map[i])` 强制非递减兜底。

## 4. 端点要夹到折线首尾（否则画完比全局线路短一截）

折线是数字化出来的，端点**不完全**落在终点站上：

- 3 号线首点离上海南站 **534m**、尾点离江杨北路 34m
- 1 号线首点离富锦路 242m、尾点离莘庄 316m

如果严格按「最近坐标点」slice，1 号线画完只有 333/337 个点、3 号线只有 559/565 ——
离开栏目切回全局线路时能看出「接上一段」。

所以 `stationToCoord()` 里首末两站直接对齐折线的第一个/最后一个坐标：

```js
if (v <= 1) return 0;
if (v >= last) return nPt - 1;
```

改完实测：1 号线画满 = **337 == 全局线路的 337**，3 号线 = **565 == 565**。

## 5. 4 号线环线**不需要特判**

原本打算给「环线运营」单独写绕圈逻辑，实测发现不必：4 号线的 GeoJSON **首尾坐标相距 < 1m，
是闭合 LineString**。里程碑 2→3 是 `[15,22] → [1,26]`，lo 和 hi 同时向两头扩张，
扩到头时切片覆盖整个数组（含首尾那个重合点），**画出来天然是闭合的环**。
其余 17 条线的首尾相距 24–57km（正常开放折线）。

## 6. 验证时抓到的 3 个真 bug

1. **`playing` 写成普通变量 → 播放键高亮不刷新。** `let playing = false` 不是响应式，
   模板里的 `:class="{ 'is-active': playing }"` 拿不到变化。改成 `ref(false)` 后实测
   「播放中 `playActive: true`」正确。（这类「普通变量驱动模板」的坑在本项目要留意。）
2. **三个入口重复启动动画。** 原来是 `onMounted(setupGrowth)` + `watch(currentLine)` +
   `watch(viewer)`，挂载期三者先后各触发一次，每次 `setupGrowth` 都把 `currentTime` 归零重起，
   肉眼是「刚开始又从头来」。合并成**一个** `watch([currentLine, () => dataStore.Viewer], setupGrowth, { immediate: true })`。
3. **端点差一截**（见第 4 节）。

## 7. 实机验证（1920×1080 真实 Chrome）

| 检查项 | 结果 |
|---|---|
| 进入栏目 | `lineEntities 19`（18 全局 + 1 私有）、`linesShown **1**` —— 18 条全局线路确实全被藏了 |
| 顶点数随时间 | 采样 24 次 **单调不回缩**：124 → 156 → … → 333 |
| 中段补站那几条 | 1996-12 与 1997-07 两条 range 都是 `[13,28]`，顶点数连续 4 次采样停在 193 —— 符合预期 |
| 文案段头翻 | 1993-05 → 1995-04 → 1996-12 → 1997-07 → 1999-12 → 2004-12 → 2007-12，逐节点推进 |
| 播完 | 1 号线 337/337、3 号线 565/565，与全局线路点数完全一致 |
| 暂停 | 点暂停后 1.2s 顶点数不变 |
| 播放 | 再点播放 1.2s 后从 105 → 161 |
| 重播 | 归零重放，播放键高亮亮起 |
| 切换线路 | 实体总数稳定在 419、`dynCount` 恒为 1 —— 私有实体是**替换**不是累加，没有泄漏 |
| 离开栏目 | `dynCount 0`（私有实体已移除）、`lineEntities 18`、**`linesShown 18`**（全局线路按进入前状态还原）、实体总数 419 → 418 |
| 控制台 | 无新增报错（只剩既有的腾讯底图瓦片 400） |

截图：`.review/growth-1-start.png`、`growth-2-mid.png`、`growth-3-end.png`（对比 mid 与 end 能看出
北端 2007 年那一段是后长出来的）。

## 8. 遗留：相机没有飞到线路上

参考项目 `Progress.vue` 点线路时会 `flyToCentroid(paths)`（turf 求质心 + `flyTo` 带
`HeadingPitchRange`），**本实现没有做**。后果是：在默认的城市全景视角下，
线路生长只占屏幕中间很小一段，**几乎看不出效果**（本轮截图就吃了这个亏，得手动 `camera.setView` 才拍得清）。

如果要做，建议不要照抄 turf 求质心（会引入依赖），直接**对当前私有实体取包围球再 `viewer.flyTo(entity)`**：
实体是完整的线，取景一次即可，之后重播相机不动。注意实测 `flyTo(hiddenEntity, {duration: 0})`
没有生效（高度没变），要对**可见的那条私有实体**取景。
