---
id: "bbb7fcbf-0682-468d-b7e0-54be35852fee"
title: "用户自建 OpenLayers 项目（openlayers服务平台开发\\Project）D3：ImageWMS 接入验收、天地图 WGS84 底图抉择与三处待修（2026-10-24）"
description: "用户亲手写的 OL 项目（pnpm + Vite，非 gis-access 参考答案）在 D3 打通「前端 → Vite proxy → GeoServer WMS → 武汉 13 区」的实测证据：项目路径归属纠正、View 选 EPSG:3857 的理由、天地图 img_w+cva_w 与高德 GCJ-02 偏移对照、VERSION 1.1/1.1.1 容错实测、Vite 样式须走 import，以及截图上残留的左下白块与未改的 VERSION 两处收尾项。"
status: "active"
created_at: "2026-10-24T07:27:09.030Z"
updated_at: "2026-10-24T07:27:09.030Z"
content_hash: "1855bcbaf9860cd1069ef98784ea97ed11194c5e0070cd9e29c87a37b3e490ea"
source_paths:
  - "gis-prep/user-day3-page.png"
  - "gis-prep/user-day3-v2.png"
session_ids:
  - "1371398d-1e43-42e7-8344-3fc7494ea842"
memory_body_ids:
  []
---

# 用户自建 OL 项目 D3 实录（2026-10-24）

承接设计 `266aea70-7a25-4d94-8359-39555b8b651f`、GeoServer 发布 `e2a4925e-c390-44f3-bd15-8bf165e70b28`、参考实现 D3 `87ef824d-134d-45ca-8303-d0278b2f3c7c`。**本文记录的是用户自己动手写的项目**，与 `gis-access`（agent 写的参考答案，只在对答案时启动）是两套东西，不要再混淆。

## 1. 路径归属（agent 曾给错建议，已纠正）

```
D:\WebGIS\web二维开发\openlayers服务平台开发\   ← 二维 OL 项目，用户自己的分类
D:\WebGIS\web三维开发\智慧地铁项目\             ← Cesium 三维
D:\WebGIS\web三维开发\gis-access\               ← agent 的参考答案，别常驻
```

用户按「二维归二维、三维归三维」自建目录，这是正确安排；agent 之前建议把 OL 项目放进 `web三维开发` 属于为了路径整齐而破坏用户分类，**以后以用户分类为准**。
目标项目根：`D:\WebGIS\web二维开发\openlayers服务平台开发\Project`，涉及 `vite.config.js`、`index.html`、`src/main.js`、`src/style.css`、`package.json`；数据已在 `..\data\wuhan.json`（137.7 KB，DataV 420100）。
教学方式：agent 只给骨架 + 每层验收标准，**代码由用户自己写**；用户明确反对 agent 把练习整套跑完。

## 2. 环境与依赖

- 项目用 **pnpm**（有 `pnpm-lock.yaml`），装包用 `pnpm add ol`，`pnpm install` 只按 lock 补全，不要混用 npm 命令。
- `ol@10.11.0` 已装；`vite ^8.3.4` 为 devDependency。
- 本机 Maven 3.9.9 装在 `D:\maven`、JDK 17.0.10 在 `D:\java`（`mvn -v` 已通），平台编码 GBK —— 与 `87ef824d` 记的中文路径 GBK 乱码坑同源，命令里别塞中文路径。
- 端口：昨日遗留的 `gis-access` dev 曾占 5173 把用户页面挤到 5174，已停掉；现用户项目跑 5173。

## 3. 已验收（截图证据：`gis-prep/user-day3-page.png`、`user-day3-v2.png`）

| 项 | 结果 |
|---|---|
| Vite proxy `/geoserver → http://localhost:8080` | 通，直测 `/geoserver/wuhan/wms` HTTP 200 |
| WMS GetMap | 200，35122 bytes，`image/png`（`wuhan:admin_area` 13 区完整叠上） |
| 坐标对齐 | 区划边界与天地图影像的水系（长江、府河、东荆河）严丝合缝 |
| 底图注记 | 加 `cva_w` 后出现「麻城市/红安县/孝感市」等注记，`img_w` 单独用时无字 |

对齐好不是运气：**天地图是 WGS84**，与库里的 4326 数据同源；`gis-access` 当初用高德（GCJ-02）时边界是错开的，两者差约 500 m。做可达性分析前这个差异必须先定下来。

## 4. 本次定下的三个技术决定

1. **View 用 EPSG:3857（默认，不写 projection）**，center 用 `fromLonLat()` 转入。理由：后续 800 m 缓冲区、覆盖率这类分析必须是米制；4326 下 1 度 ≠ 1 米，数值全错。用户原 `ol-study` 旧代码用了 4326 + 3857 瓦片，属于会拉伸变形但中纬度看不出来的写法。
2. **WMS 参数写字符串 `'1.1.1'`**，不写数字 `1.1`。实测 GeoServer 对 `version=1.1` 与 `1.1.1` 返回完全相同的 35122 bytes（容错），但 WMS 规范只有 `1.0.0/1.1.0/1.1.1/1.3.0`，换服务器就会 500 或空图。轴序：1.3.0 在 4326 下 bbox 是 lat,lon，1.1.1 是 lon,lat。
3. **WMS 与 WFS 混合用**：面/格网等大数据量走 WMS（服务端出图省流量），需要 hover/点击/热力图的那几百个点走 WFS 前端渲染。WMS 样式并非不能自定义——在 GeoServer 里写 SLD；但 WMS 做不了热力图、hover 变色、动画。MVT 是更现代的折中（需 GeoServer `vectortiles` 插件，2.28 默认不带），列为加分项。

## 5. 未收尾（下次接着看）

- `VERSION: 1.1` 仍是数字，未改成 `'1.1.1'`。
- 截图上左下仍有白块：先把样式改成 `main.js` 里 `import './style.css'`（删掉 `index.html` 的 `<link>`），`#map` 用 `height: 100%` 而非 `100vh`，`html,body` 加 `overflow: hidden` 兜底。
- 遗留思考题未答：`img_w` 与 `cva_w` 都设 `opacity: 0.7` 会怎样（图层透明度是乘法叠加，注记会被洗白）。
