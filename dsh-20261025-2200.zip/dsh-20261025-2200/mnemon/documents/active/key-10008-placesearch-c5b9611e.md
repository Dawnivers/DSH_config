---
id: "c5b9611e-b969-4fc6-ab5e-8aed3cb585d8"
title: "高德换 Key 后的两类故障排错与防御加固（10008 配对失败 → 一拖地图白屏、PlaceSearch 静默无反应）"
description: "gaode-study-React 项目实测的运维排错手册：换 Key 未同步换安全密钥导致全站 10008；moveend 触发天气框读 null 抛错使 React 卸载整树白屏；server/.env 改了没重启导致改动静默不生效、美食分类点击无反应；含 ErrorBoundary、天气框守卫、PlaceSearch 判空、check:amap 验签脚本与 CDP 复现验证方法。"
status: "active"
created_at: "2026-10-22T01:41:38.574Z"
updated_at: "2026-10-22T01:41:38.574Z"
content_hash: "b8cba29173f02f060e76ccac68642aa43b7a752005880c34f67c984bf89da134"
source_paths:
  - "server/index.js"
  - "server/routes/amap-proxy.js"
  - "server/check-amap.js"
  - "src/components/City.jsx"
  - "src/components/ErrorBoundary.jsx"
  - "src/main.jsx"
  - "src/components/Search.jsx"
  - "DEPLOY.md"
session_ids:
  - "8a7c4234-35f0-4d53-ad00-e203aa96cb93"
memory_body_ids:
  []
---

# 高德换 Key 后的排错与防御加固（gaode-study-React「拆分组件」，2026-10-22）

本轮是改造上线结构之后的两次线上式故障：用户「换了高德 key」→ 一移动地图整页白屏；随后「点美食没反应」。
两个故障表面无关联，实际是同一类问题的两种表现：**Key / 安全密钥 / 进程状态三者不同步，而代码对失败毫无防御**。
（改造结构与代理本身的三个坑见 [f9eff4ea](f9eff4ea-e646-436b-bfcc-2baffb6b4321)，本文只记售后排错这一层。）

## 1. 故障一：换 Key 后一拖地图就白屏

### 现象与误导
底图瓦片正常显示，页面交互也没问题；**一拖动地图，整页变白**（`#root` 长度从 6726 字节变 0，canvas 消失）。

### 证据链
- 代理日志：`key` 已是新的（`bbd7a018…`），但每个 Web 服务请求都返回
  `{"info":"INVALID_USER_SCODE","infocode":"10008","status":"0"}`。
- `server/.env` 里的 `AMAP_SECURITY_CODE` 仍是**旧 Key 对应的安全密钥**。
- 控制台异常（CDP 抓取）：
  `TypeError: Cannot read properties of null (reading 'weather') at CitySelect (City.jsx)`，
  随后 `Uncaught TypeError: Cannot read properties of undefined (reading 'fireEvent')`。

### 因果链（为什么"偏偏一移动"才炸）
1. 初始化时 `zoom` 为 `null`，天气框渲染条件 `null > 8` 为 false → 不渲染 → 页面正常。
2. 拖动地图 → `moveend` → `setcenter` → `setzoom(13)` → 天气框条件成立，开始渲染。
3. 天气接口因 10008 失败，`weatherNow` 恒为 `null` → 读 `weatherNow.weather` 抛错。
4. 项目当时**没有错误边界**，React 直接卸载整棵组件树 → 整页空白。

> 高德安全密钥是**跟着 Key 走**的，换 Key 必须同步换它。底图瓦片不走 jscode 代理，所以"底图还能看"极具迷惑性。

### 修复
| 位置 | 改动 |
|---|---|
| `server/.env` | `AMAP_SECURITY_CODE` 换成新 Key 配套的安全密钥 |
| `src/components/City.jsx` | 天气框改为 `Isweathershow && weatherNow && weatherForecast?.forecasts?.[0]` 三重守卫，数据未到则不渲染 |
| `src/components/ErrorBoundary.jsx`（新建） | class 组件错误边界，`getDerivedStateFromError` + `componentDidCatch`，渲染「页面出了点问题 + 刷新」 |
| `src/main.jsx` | 用 `<ErrorBoundary>` 包住 `<App/>` |
| `server/check-amap.js`（新建） | 验签脚本，`npm run check:amap` |

### 验证
用同一份坏配置再拖一次地图：`rootLen` 保持 6726、`canvas:true`、**0 异常**（改造前 `rootLen:0`、`canvas:false`）。

## 2. 故障二：点「美食」分类毫无反应

### 现象
点分类按钮后：面板关掉、地图上没有标记、列表不出现、控制台也没有明显报错——完全的静默失败。

### 根因：后端进程没重启
诊断输出（请求侧 + 进程侧对照）：

```
代理实际用的 jscode 指纹与 .env 不一致
后端进程启动时间: 09:13:29
server/.env 修改时间: 09:36:40
```

`server/load-env.js` 只在**进程启动时**读一次 `.env`，改文件不重启等于没改。
于是后端仍拿旧的 `AMAP_SECURITY_CODE` 补 jscode → `place/text` 全返 `10008` → `AMap.PlaceSearch` 回调里 `result` 为 `null`，而旧代码直接读 `result.poiList.pois`，抛出的异常被高德 JSONP 回调吞掉 → 界面上什么都看不到。

> 对照表：`10008 INVALID_USER_SCODE` = 安全密钥不对（换 Key 未同步换它）；`10009 USERKEY_PLAT_NOMATCH` = Key 平台类型不对（必须是「Web 端 (JS API)」）；`10001` = Key 错/删/未启用；`10003` = 当日配额用尽。

### 修复
- 重启后端；`server/index.js` 启动时打印密钥指纹：
  `[server] 高德安全密钥: a71705…144c（改了 .env 必须重启本进程）` —— 让"改了没生效"一眼可见。
- `src/components/Search.jsx` 的 `ClickOnes()` 加判空：`status !== 'complete'` 或 `result` 为空时打
  `[分类搜索] "美食" 失败：<error> (<infocode>)` 并清空列表；城市为空时兜底用「全国」。

### 验证
开发（5173）与生产构建（3000）各点一次「美食」：地图 **10 个**红色标记、列表 10 条（首条「延吉市鲜牛街烤串旗舰店」）、0 控制台异常；`setFitView()` 正常缩放到结果范围，天气框显示 `晴 -3℃|11℃`。
同一轮 `npm run build` 产物：`dist/assets/index-*.js` 267.53 kB（gzip 87.30 kB），0 errors / 5 条 hooks 依赖 warning。

## 3. 可复用的排错顺序（换 Key / 上线验收先跑这几步）

1. 高德控制台建 Key：类型选 **Web 端 (JS API)** + 配域名白名单。
2. 前端根目录 `.env.local` 的 `VITE_AMAP_KEY` 换新（构建时读这里，读不到 `server/.env`）。
3. **同时**换 `server/.env` 的 `AMAP_SECURITY_CODE`（每个 Key 独立）。
4. **重启 Node 进程**，看启动日志的密钥指纹是否等于 `.env` 里的新值。
5. `npm run check:amap` 验签，必须输出 `✅ 配对正确`；失败时按 10008/10009/10001/10003 对照表定位。
6. `npm run build` 重新打包——**Key 是编译进前端的，换了 Key 不重新 build，线上仍是旧 Key**。
7. 在浏览器里实测一次交互（拖地图、点分类），而不只是看首页有没有底图。

## 4. 无头复现/验证方法（本轮实际用的）

用 CDP 起无头 Chrome 连 5173，脚本化：加载页面 → 记录 `#root` 长度与 `canvas` 存在性 → 派发拖动地图 → 再记录一次 → 收集 `Runtime.exceptionThrown`。
产出 JSON 形如
`{before:{rootLen:6726,canvas:true}, after:{rootLen:0,canvas:false}, exceptions:[...]}`
—— 这个「前后对比 + 异常栈」比截图更能证明白屏根因，也适合回归时复用。
截图落在 `.review/*.png`（`prod-check.png`、`food-click.png`）。

## 5. 其它运维事实

- `dist` 必须在**项目根目录**打包，产物与 `server/` 保持同级：`server/index.js` 读的是 `path.resolve(here, '../dist')`，挪走就断了 Node 托管整站那条路。
- `server/package.json` 只有 `start / dev / seed`，没有 `build`；别 `cd server` 后跑 `npm run build`（会报 Missing script）。
- 后端备份产物：`server/data/backups/app-YYYYMMDD-HHmmss.db`（本轮 20480 bytes），脚本保留最近 14 份。
- 前端代码更新流程：`npm run build` → 宝塔重启 Node 项目（重启只为刷新后端内存态，静态文件即时生效）。
