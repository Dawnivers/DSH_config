---
id: "1056d83b-fc4b-4598-834b-404ed7f42702"
title: "Translation 智慧地铁：站点管理改用 vue-router 驱动（Cesium 不重建）——推翻「用路由会重建三维场景」的旧判断"
description: "2026-10-10 把 Translation 的导航/站点面板从共享 store 开关改为 vue-router 驱动：关键前提是三维组件必须与 RouterView 平级（分层分户项目 App.vue 的参考写法），实测 6 次路由跳转（含浏览器前进后退）viewer 对象与 canvas DOM 节点均未重建、0 控制台报错，含路由表、状态推导方式、SPA fallback 部署注意点，并修正文档 3a0ce399 中「用路由会重建 Cesium」的结论。"
status: "active"
created_at: "2026-10-10T10:25:21.181Z"
updated_at: "2026-10-10T10:25:21.181Z"
content_hash: "7b9fda40d1ddc19b23aec57f81d964fe6762c425c15680ab55b1f5a1274f3571"
source_paths:
  - "Translation/src/router/index.js"
  - "Translation/src/App.vue"
  - "Translation/src/stores/stationState.js"
  - "Translation/src/components/screenUI/foot.vue"
session_ids:
  - "42fcab83-91f5-4fd0-aa86-4e7b3770dd6d"
memory_body_ids:
  []
---

# Translation 智慧地铁：站点管理改用 vue-router 驱动

日期：2026-10-10。目标：让导航按钮与站点管理面板走路由（URL 成为界面状态唯一真相来源），同时**不重建 Cesium 场景**。

相关文档：
- `3a0ce399-303d-4a00-95ef-e3c3d0db18af`（StationPanel 实现；其中第 5 节「不用路由」的理由本次被推翻，见下）
- `46077717-b034-4315-a3c1-f04be09fed52`（KeepAlive 场景缓存改造，本方案的前置基础）
- `8d3c4c05-ec6a-4bb9-98de-8a40750572a5`（站点光锥/光圈渲染链路与性能实测）

## 1. 结论：路由不会重建 Cesium，前提是三维组件与 RouterView 平级

参考项目 `D:\WebGIS\web三维开发\分层分户项目\Project\src\App.vue` 给出了正确写法：

```html
<RouteMenu />
<RouterView />          <!-- 路由只切换 UI 面板：SetBuild / SetInfo / ScanInfo -->
<keep-alive>
  <CesiumView />        <!-- 三维组件在 RouterView 外面，路由怎么跳都碰不到它 -->
</keep-alive>
```

**真正起作用的是「三维组件是 RouterView 的兄弟节点」这一条**，不是 `<keep-alive>`。参考项目那个 `keep-alive` 包的是写死的静态子节点，永不 deactivate，等于空转；Translation 用 `<component :is>` + `sceneVisible` 让 KeepAlive 真正生效，写法更严谨。

之前的判断「用路由会重建 Cesium，风险过大」只在一种写法下成立：**把三维组件放进 `<RouterView>` 内部**，路由切走就会卸载重挂。参考项目正是反例，该顾虑已不成立。

## 2. 落地改动（4 个文件）

| 文件 | 改动 |
|---|---|
| `Translation/src/router/index.js` | 原本 `routes: []` 是空的（控制台一直刷 `[VUE_ROUTER_R0004] No match found for location with "/"`）。新增 5 条路由 + `/:pathMatch(.*)*` 兜底重定向 |
| `Translation/src/App.vue` | 新增 `<RouterView />`，与 `.scene-layer`、`<Panel>` 平级 |
| `Translation/src/stores/stationState.js` | `stationPanelOpen` 改为 `computed(() => route.path === '/nodes')`，删掉独立布尔量 |
| `Translation/src/components/screenUI/foot.vue` | 导航按钮改为推路由；高亮由路由反查；移除本地渲染面板的分支 |

路由表：

| 按钮 | 路由 | 面板 |
|---|---|---|
| 首页 CORE | `/` | 无 |
| REALTIME / EXP.TRIAL / STRATEGY | `/realtime` `/experiment` `/strategy` | 暂无（预留） |
| NODES 站点管理 | `/nodes` | StationPanel.vue（懒加载） |

**设计原则**：URL 是唯一真相来源。面板开关不再单独存布尔量，而是从 `route.path` 推导，避免「路由与本地状态两份真相不一致」。

## 3. 实测证据（本机真实 Chrome，0 控制台报错）

给 `viewer` 对象与 canvas DOM 节点打标记，组件一旦重建标记即丢失：

| 操作 | url | 面板 | 站点可见 | 高亮 | viewer 标记 | canvas |
|---|---|---|---|---|---|---|
| 初始 | `/` | 无 | 0 | `[]` | 存活 | 原节点 |
| 点站点管理 | `/nodes` | 有 | 400 | `["NODES站点管理"]` | 存活 | 原节点 |
| **浏览器后退** | `/` | 无 | 0 | `[]` | 存活 | 原节点 |
| **浏览器前进** | `/nodes` | 有 | 400 | `["NODES站点管理"]` | 存活 | 原节点 |
| 点发展历程 | `/strategy` | 无 | 0 | `["STRATEGY发展历程"]` | 存活 | 原节点 |
| 点首页 CORE | `/` | 无 | 0 | `[]` | 存活 | 原节点 |
| 整页打开 `/nodes` | `/nodes` | 有 | 400 | — | 丢失（整页硬加载，自然重建） | — |

**六次路由跳转（含前进后退）中 viewer 对象与 canvas 节点自始至终是同一个**。整页打开 `/nodes` 属正常刷新，同时验证了直接落地该 URL 可用。

路由模式下交互与改造前完全一致：进入 `/nodes` → 400 可见；取消 1 号线 → 384（右栏 1号线 12/28）；全部隐藏 → 0；全部显示 → 400；单关一站 → 399。面板几何仍为 x 440 / y 703 / 1040×232，命中测试返回 `button.sp-station`。

## 4. 部署注意点

1. **生产要配 SPA fallback**：`createWebHistory` 下直接访问 `/nodes` 需要服务器把未知路径回退到 `index.html`（nginx：`try_files $uri $uri/ /index.html;`）。开发环境 Vite 自带 fallback，粘 `http://localhost:5173/nodes` 即可用。
2. **URL 会变成 `/nodes`**：既是代价也是收益——刷新、分享链接、前进后退都能落回同一界面状态。

## 5. 可复用教训

- **判断「路由会不会销毁组件」时先看组件在模板里的位置**，而不是只看有没有用路由。放在 `<RouterView>` 内外的差别是决定性的。
- **`<keep-alive>` 包静态子节点是无效的**，必须配 `<component :is>` 之类的动态组件才会触发 deactivate/activate。
- 「用 X 技术风险太大」这类结论应写明它成立的具体写法前提，否则后续会被当成普适禁令沿用（本次即是纠正）。
