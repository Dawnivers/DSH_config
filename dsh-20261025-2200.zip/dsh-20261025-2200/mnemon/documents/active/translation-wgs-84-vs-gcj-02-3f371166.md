---
id: "3f371166-c605-42a6-8eff-2b12279a73ca"
title: "Translation 智慧地铁：路径规划送达站错站根因——库内 WGS-84 vs 高德 GCJ-02（仅请求侧转换）"
description: "2026-10-19 定位「富锦路→人民广场被送到新闸路」的根因：项目 xy_coords 是 WGS-84，高德接口吃 GCJ-02，上海一带恒偏约 480 m 导致最近站吸附错站；记录 planModel 新增 wgs84ToGcj02/gcj02ToWgs84 与 stationQueryCoord、只在请求高德时转换而渲染保持 WGS-84 的边界规则、三组对照数据与浏览器验证，并修正前文「723 m 假步行」的归因。"
status: "active"
created_at: "2026-10-19T05:59:18.413Z"
updated_at: "2026-10-19T05:59:18.413Z"
content_hash: "696ae50bdce862fcb39540877a8eae073ab837e1d7d0dec3585189b5c3fa5d8f"
source_paths:
  - "Translation/src/components/bottom/StationPanel/QueryModePanel/guideload/planModel.js"
  - "Translation/src/components/bottom/StationPanel/QueryModePanel/guideload/useRoutePlan.js"
  - "Translation/src/cesiumTools/sceneManager.js"
  - "tmp-coord/check.mjs"
session_ids:
  - "abc531e8-3370-4719-bb5b-6bbd66302173"
memory_body_ids:
  []
---

# 路径规划送达站错站：WGS-84 / GCJ-02 坐标系根因与修法

日期：2026-10-19。入口：`/nodes` → 站点面板 → 查询模式「路径规划」。

前置/相关文档：
- `44fe1831-c29a-4d4c-aed8-334dfb8fa556` — guideload 四层结构（planModel / renderRoute / useRoutePlan / RouteDesign）。
- `4b4b2f1f-f963-4446-89f8-d87657b8102c` — 线路同色、可展开行程、**把「723 m 进出站步行」当假数据只留档不展示**。本文给出该现象的真正归因，是对那一条的更正，但保持该文档所述的面板行为不变。
- `771251b3-3cd0-40fd-9317-f7f609285a72` — 开始规划前清场与逐条快照还原（同一次会话的另一项改动）。

## 1. 现象与用户问题

用户选「起点 富锦路 → 终点 人民广场」，返回方案却把终点送成**新闸路**（人民广场的上一站），并附带一段不合常理的末段步行。用户自己猜「是不是高德接口的坐标系原因」——**猜对了**。

## 2. 根因：两套坐标系，稳定偏约 480 m

| 数据源 | 坐标系 |
|---|---|
| 本地库 `xy_coords` / `getLine` 返回的站点坐标 | **WGS-84** |
| 高德全系列接口（含本项目后端转发的规划接口） | **GCJ-02** |

同一点实测差值（上海一带基本恒定）：

| 站点 | WGS-84（库里） | GCJ-02 | 差值 |
|---|---|---|---|
| 富锦路 | 121.420041, 31.393363 | 121.424698, 31.391582 | 约 430 m 东 / 215 m 北 |
| 人民广场 | 121.470895, 31.234068 | 121.475427, 31.232135 | 同上 |

直接传 WGS-84 时，「人民广场」这个点实际落在真人民广场**西偏北约 480 m**，高德按最近站吸附 → 新闸路。两站仅隔一站地，480 m 足够跨过去。

## 3. 对照实验（同一查询，只变坐标系）

`tmp-coord/check.mjs`（临时脚本）直接打真接口：

```
① 现状：直接传 WGS-84
   送达站 = 新闸路（1号线 富锦路→莘庄），末段步行 710 m
② 修正：传 GCJ-02
   送达站 = 人民广场，末段步行 134 m
   到达站坐标 121.475108,31.232687 vs 本地点(转换后) 121.475427,31.232135
③ 对照：起点也用高德自己的站坐标
   送达站 = 人民广场，末段步行 125 m
```

②与③相差 10 m 量级，说明转换公式正确、710 m 那种「步行」纯粹是偏移造成的假距离。前文 `4b4b2f1f` 记录的「起点在莘庄却要走 723 m」是**同一个原因**，不是接口数据不自洽。

## 4. 修法与边界规则（关键）

**只有发给高德的那一份坐标转换；场景渲染一律保持 WGS-84。**

- `planModel.js` 新增标准 `wgs84ToGcj02`（克拉索夫斯基椭球那套偏移公式，与 gcoord / coordtransform 等价，保留 6 位小数）与反算 `gcj02ToWgs84`；导出 `stationQueryCoord(station)` 作为「站点 → 请求坐标」的唯一入口。
- `useRoutePlan.js` 的 `coordOf()` 改为走 `stationQueryCoord`：请求体里起终点坐标已转 GCJ-02，站名与其余参数不变。
- 三维渲染、站点光锥、起终点标记、路线高亮**继续用库里的 WGS-84**——底图是 ArcGIS World Imagery（WGS-84），转成 GCJ-02 反而会整体偏 480 m。
- `gcj02ToWgs84` 用于兜底：高德返回的 `polyline` 是 GCJ-02，本地线路切片对不上时（磁浮之类）用它反算后再画，否则那条线会平行压在真线旁 480 m 处。落点是 `planModel.js` 的 `parseAmapPolyline` / `normalizePlan` 路径。

判断依据一句话：**坐标系转换只发生在与高德交互的边界上，且只做单向（去 GCJ-02、回 WGS-84），绝不改写库内数据或场景实体坐标。**

## 5. 验证

浏览器 `/nodes` 重查「富锦路 → 人民广场」：

```
5 元 · 42 分钟 · 19.7 km · 换乘 0 次
1号线 · 富锦路 → 人民广场   16 站 · 38 分钟 · 19.4 km
```

送达站由新闸路变为人民广场，16 站、38 分钟与真实站序一致。

## 6. 遗留与提醒

- 后端若改为直接收站名做 POI 检索（`/v5/place/text`），返回同样是 GCJ-02，回填三维前必须 `gcj02ToWgs84`。
- 既然偏移已修正，`4b4b2f1f` 中「进出站步行一律不展示」的理由（假数据）已不成立；是否恢复展示属产品取舍，本次未改动。
