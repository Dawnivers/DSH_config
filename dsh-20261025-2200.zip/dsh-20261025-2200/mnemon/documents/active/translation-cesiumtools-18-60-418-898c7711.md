---
id: "898c7711-8359-4297-8e5c-4fd4ef2b9a07"
title: "Translation 智慧地铁「重点活动」栏目：光柱/线路高亮两套 cesiumTools 工具 + 18 线 60 条活动数据集 + 面板与实机验证（实体数 418 基线）"
description: "Translation 重点活动（重保活动）栏目落地记录：/experiment 新面板、cesiumTools 下新增「光柱」与「线路高亮」两套工具（wall + 自定义 isConstant 材质 + canvas 一维贴图、相位走 czm_frameNumber；高亮改画独立叠线而非改原材质）、18 线 60 条按站名组织并经 /getLine 校验的活动数据集，以及实体数 418 基线与进出/切线清理的实测数据。"
status: "active"
created_at: "2026-10-14T03:53:31.390Z"
updated_at: "2026-10-14T03:53:31.390Z"
content_hash: "9ac23188b168e7a1ad49c07c67f1da2c033c9c50510badd23ca3d44781cf0654"
source_paths:
  - "Translation/src/components/bottom/ActivePanel/ActivePanel.vue"
  - "Translation/src/cesiumTools/lineAndpoints/points/circleAndcone/setlightcolumn.js"
  - "Translation/src/cesiumTools/lineAndpoints/points/circleAndcone/lightColumnMaterialProperty.js"
  - "Translation/src/cesiumTools/lineAndpoints/points/circleAndcone/lightcolumn.glsl"
  - "Translation/src/cesiumTools/lineAndpoints/line/lineHighlight.js"
  - "Translation/src/config/shmetroActivity.js"
  - "Translation/src/router/index.js"
  - "Translation/src/cesiumTools/lineAndpoints/line/setlines.js"
session_ids:
  - "session-d6cbf69c-ac7f-4b6b-a2a9-8468919b087a"
memory_body_ids:
  []
---

# Translation 智慧地铁：重点活动（重保活动）栏目 —— 光柱工具 + 面板 + 18 线数据集

日期：2026-10-14。项目：`D:\WebGIS\web三维开发\智慧地铁项目\Translation`。
需求原话：「在 src/bottom/ActivePanel 下新建重点活动组件，重保信息和之前一样，按照线路不同，在网上搜索。如果涉及到什么方法（光柱的创建）等，就封装为工具，写在 src/cesiumTools 文件夹下，引入回项目中」。

课程原方案存档见文档 `a29177f1-d76e-4ea5-a05f-29ed71258be7`（含参考项目 `KeyActivity.vue` /
`effectController.js` 全文与逐行核对）。本文只记本项目这一版**做成了什么、怎么做的、验证数据**。

## 1. 新增/改动的文件

| 文件 | 作用 |
|---|---|
| `src/cesiumTools/lineAndpoints/points/circleAndcone/lightcolumn.glsl` | 光柱着色器（新建） |
| `src/cesiumTools/lineAndpoints/points/circleAndcone/lightColumnMaterialProperty.js` | 光柱材质 Property + canvas 贴图 + 注册进 `_materialCache`（新建） |
| `src/cesiumTools/lineAndpoints/points/circleAndcone/setlightcolumn.js` | 光柱工具：创建 / 全部清除 / 相机飞到（新建） |
| `src/cesiumTools/lineAndpoints/line/lineHighlight.js` | 线路高亮叠线工具：高亮一条 / 清除（新建） |
| `src/config/shmetroActivity.js` | 18 条线 × 60 条活动数据集 + `activityOfLine()`（新建） |
| `src/components/bottom/ActivePanel/ActivePanel.vue` | 面板本体（新建） |
| `src/cesiumTools/lineAndpoints/line/setlines.js` | **加了一个 `width` 选项**（默认仍是 3，行为不变），供高亮叠线用 |
| `src/router/index.js` | `/experiment` 由 `EmptyView` 改为懒加载 `ActivePanel.vue` |

## 2. 为什么光柱用 wall 而不是项目里已有的 cone

项目里原本就有两套点特效（`setpoints.js` 用的）：

- `setcone.js` → `coneWithLight()`：**光锥**，`CylinderGeometry`（topRadius 0）+ `Primitive` + `MaterialAppearance`，矮、上尖，给每个站点标记用；
- `setcircle.js` → `bottomCircle()`：底部光圈。

重点活动要的是**高、等宽、面上有自下而上流动光带、上端渐隐**的柱子，这三件事都得自己写着色器，
而 `wall` 图元（一圈底面点 + `minimumHeights`/`maximumHeights`）正好能把任意自定义材质挂上去，
`st` 语义也干净（`s` 沿周长、`t` 沿柱高）。所以新开一个 `setlightcolumn.js`，**没有去改 cone**。

## 3. 光柱着色器的三个决定（都踩过或差点踩）

1. **绝不能用 `st.s` 做明暗。** 墙是一个绕一圈的条带，`s=0` 和 `s=1` 是同一条缝；
   参考项目用 `distance(st, vec2(0.5))`（含 s 分量）会在柱面留一道竖向暗缝。
   本项目改成横向给常数，明暗只由 `t` 决定。
2. **流动相位用 `czm_frameNumber`，不用外部推 `time` uniform。**
   参考项目 fabric 里 `time: 0` 且从未更新，所以它那句 `fract(st.t - time)` **其实从来没滚动过**。
   本项目直接在着色器里 `float flow = fract(czm_frameNumber / 60.0 * flowSpeed)`，
   代价是 0，好处是材质可以 `isConstant = true` 只编译一次（与项目里 `PolylineFlowMaterialProperty` 同一套路）。
3. **不透明度的坑：`opacity` 默认不能给 1.0。**
   `alpha = 贴图a(≤0.95) × color.a × 顶部渐隐 × 呼吸(峰值1.3) × opacity`，
   给 1.0 时中段会有一大截被 clamp 到 1 —— 柱子变成一块实心色板（第一版实测就是这个效果）。
   呼吸系数下调到 `mix(0.90, 1.30, ...)`、默认 `opacity = 0.55` 之后峰值 alpha ≈ 0.6，才是半透明光柱。

贴图不用 png 资源，沿用项目里 `circleBottomGlowMaterialProperty.js` 的做法用 canvas 现场画：
4×256 的一维竖直剖面，**首尾 alpha 必须相等**（都是 0.22），否则 `fract()` 回卷那一帧会闪出一条接缝。

## 4. 工具对外 API

```js
// setlightcolumn.js
lightColumn(viewer, { lng, lat, height=3000, radius=160, baseHeight=0, color, name,
                      opacity, flowSpeed, breatheSpeed })  → { name, entity, lng, lat, height, radius, color } | null
removeAllLightColumns(viewer)          // 只清本模块创建的
flyToLightColumn(viewer, name, { heading=40, pitch=-40, range=6000, duration=1.5 }) → boolean
getLightColumns()                      // 只读快照，供自检

// lineHighlight.js
highlightLine(viewer, { name, positions, color, width=8, glowPower=1.2, taperPower=0.5 }) → Entity | null
clearLineHighlight(viewer)
```

**不用 `viewer.flyTo(entity)` 飞到光柱**：EntityView 对 `wall` 图元能否算出包围球没有保证，
算不出来时 `flyTo` 会静默失败。改成自己造 `BoundingSphere(点, radius 1)` + 显式
`HeadingPitchRange` 走 `flyToBoundingSphere`，结果可预期。`pitch` 必须给 —— 默认 -90° 正俯视时竖直柱子会缩成一个圆点。

**线路高亮没做「改原线路 glowPower 再改回来」**：`PolylineFlowMaterialProperty.isConstant`
在参数都是普通数字时返回 `true`，运行时改属性能否可靠触发重编译**本项目没有被证实过**
（之前做过像素级 A/B，信号被远景瓦片 LOD 漂移淹没）。改成用 `renderLines` 另画一条
`width: 8`、`flowLength: 0`（关流动必须用 `flowLength: 0`，置 `flowIntensity: 0` 会拉出黑带）的
**独立叠线**：是新增实体，生效与否当场可见；切换线路时删掉即可，原实体自始至终没被碰过。

## 5. 数据集：18 条线 × 60 条活动

字段（比参考项目更能落地）：

```js
{ time: '08:30', place: '国家会展中心', station: '国家会展中心', activity: '中国国际进口博览会安保' }
```

- **`station` 写站名而不是数组下标**。参考项目 `staticData.activity` 的 `id` 是 `stationsList` 的下标，
  换个线路点就落错站；站名是稳定的。
- 面板按 `station` 去 `dataStore.Lines[].stationList` 里取 `xy_coords`；
  取不到时卡片照常显示但标 `is-missing`（虚线边框 + 「库内无此站」），**不静默少一根光柱**。
- 每条的**场所都是真实存在的大型活动场所**，且最近车站必须能在本项目库里逐字找到。
  来源（进博会/国家会展中心、F1/上海赛车场、梅赛德斯-奔驰文化中心/中华艺术宫、
  豫园灯会/豫园、上海体育场演唱会）见配置文件头部注释里的链接；
  其余（迪士尼、龙华古寺、顾村公园、滴水湖、江湾体育场、浦东足球场、源深体育中心、
  东方体育中心、新国际博览中心、世博展览馆、朱家角、东方绿舟、野生动物园、新场古镇、
  七宝老街、佘山、桂林公园、上海动物园、自然博物馆、一大会址、各高校校庆、三大铁路枢纽）
  是同名/紧邻既有车站的常识性对应。
- **`time` 是演示用的典型时段，不是官方通告的精确时刻** —— 这一点必须如实标注，接真实业务数据时替换该字段即可。
- 分布：1/2/8/10/11/14/15 号线各 4 条，4/5/6/7/9/12/13/16/17/18 号线各 3 条，3 号线 2 条。

数据完整性已用脚本对 `/getLine` 校验：**18/18 条线命中，60 条活动的 station 全部能在库内找到**。

## 6. 面板

尺寸与位置和 `historyPanel.vue` **完全一致**（设计 1040×232、`bottom: 145px`、`left: 50%` 居中），
两个栏目互切时面板不跳；同样 `Teleport to .hud-canvas`、同样不收起左右大屏侧栏
（`stationPanelOpen` 只对 `/nodes` 为 true）。

- 左栏 31%：18 条线路（3 列 grid），色块索引必须与 `Toolbar.vue` 一样取 `index % LINE_COLORS.length`，否则和三维里对不上；
- 右栏：抬头「重点活动 + 当天日期 + N 项 / 全网 60 项」，正文是活动卡片（时间/场所/事项/站名）；
- 点线路 → 高亮叠线 + `viewer.flyTo(highlight)` + 按该线活动立光柱；
- 点卡片 → `flyToLightColumn` 并标记 `is-active`；
- 一个 `watch([currentLine, () => dataStore.Viewer], setup, { immediate: true })` 承担全部装配
  —— 拆成 onMounted + 两个 watch 会在挂载期各触发一次，每次都先 teardown 再重建，肉眼是闪烁（发展历程踩过同一个坑）；
- `onBeforeUnmount` → `removeAllLightColumns` + `clearLineHighlight`。

## 7. 实机验证数据（Playwright，1920×1080，真实页面）

场景实体总数基线 = **418**（18 条线路实体 + 400 个站点标记，与记忆库既有记录一致）：

| 步骤 | 光柱（wall 实体） | 高亮叠线 | 实体总数 | 相机高度 |
|---|---|---|---|---|
| 进 /experiment（1号线） | 上海火车站 / 上海马戏城 / 徐家汇 / 上海体育馆 | 上海地铁1号线 | 423 = 418+4+1 | 34786 |
| 切 11号线 | 迪士尼 / 上海赛车场 / 上海游泳馆 / 龙华 | 上海地铁11号线 | 423（旧 4+1 已清） | 62556 |
| 点第 1 张卡片 | 不变 | 不变 | 423 | **5358**（确实飞过去了） |
| 切 3号线 | 上海南站 / 虹口足球场 | 上海地铁3号线 | 421 = 418+2+1 | 31557 |
| 点首页离开 | **[]** | 无 | **418**（回到基线） | — |

- 面板 DOM：18 个线路按钮、卡片随线路正确变化、`is-active` 跟随点击；
- 面板盒模型实测 `1040×232`、底边距 145 —— 与 historyPanel 完全一致；
- 控制台**零错误**（仅剩既有的腾讯底图瓦片 400）；
- 截图：`.review/active-1-line1.png`（城市尺度，四根柱被弹窗/面板遮住属正常）、
  `active-2-line11.png`、`active-3-column.png`（飞到迪士尼光柱，半透明+流动光带+顶部渐隐）、
  `active-4-line3.png`、`active-final.png`。

## 8. 两个操作/环境注意点

- **「渲染环境正常」弹窗**在首次进入时盖在城市中心，正好压住活动站，截图验证前要先点「我知道了」。
- 本机这个 vite 实例的 `import.meta.env.DEV` 为 **false**（以 production 语义启动），
  因此 `globalThis.__cesiumViewer` **没有挂载**，无法从 Playwright 直接读 Viewer。
  这次的取数办法：在 `ActivePanel.vue` 里临时挂一个 `window.__activeProbe`（**非根组件，改它不会整页刷新、不重置相机**），
  验证完必须删除 —— 已在最终自检里确认 `typeof window.__activeProbe === 'undefined'`。
  根治办法仍是按启动约定显式 `$env:NODE_ENV='development'` 重启 vite。

## 9. 一句话

wall 图元 + 自定义 `isConstant` 材质（canvas 一维贴图、相位全走 `czm_frameNumber`）做成可复用的光柱工具；
线路高亮用「另画一条更粗的叠线」而不是改原材质（未证实能可靠生效）；
数据按**站名**而不是下标组织，18 条线 60 条全部对得上库；进出与切线的实体增减都实测回到基线 418。
