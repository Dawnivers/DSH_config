---
id: "70090dce-2a73-410b-ad55-cb3d040aaaa0"
title: "Translation_BE 上线后反向代理全链路验证清单（实测真值）、多行粘贴坑与 /getLine 500 的定位结论"
description: "2026-10-20 服务器实测记录：translationbe.dawnivers.top（nginx + TrustAsia LiteSSL + HTTP/2）反代 127.0.0.1:8092 全绿的分段验证脚本与期望输出、CORS/x-powered-by 观察、CentOS 终端粘贴多行命令被拆行的具体报错形态与修正版单行命令，以及 /getLine、/getStationInfo 报 database \"Translation\" does not exist 的判定与修复路径。前置参见 cdaa0177、fc0f55ab。"
status: "active"
created_at: "2026-10-20T10:21:40.604Z"
updated_at: "2026-10-20T10:21:40.604Z"
content_hash: "5fa6d97f9ec3127300cb432622bafc2f1b1cf6bd4b0c742accc8d0f4daafb184"
source_paths:
  - "Translation_BE/index.js"
  - "Translation_BE/config.js"
  - "Translation/src/api/baseApi.js"
  - "Translation/src/models/planModel.js"
session_ids:
  - "9d850e74-248f-4417-b661-d21c1e5a483a"
memory_body_ids:
  []
---

# 背景与定位

后端已上传并在 CentOS Stream 9 上跑起来（`node index.js`，pid 形态见下），nginx 反代 `127.0.0.1:8092`，域名 `translationbe.dawnivers.top`。本文记录**上线后怎么证明"配对了"**这一步的分段验证法、服务器终端实测真值，以及实测中暴露的两个问题（粘贴拆行、数据库未导入）。

前置文档：
- `cdaa0177-267d-4849-814e-19a5b4961664` —— 上传边界、 dump 格式与恢复、前端硬编码清单
- `fc0f55ab-66a4-41aa-8d8e-199fd1c953a1` —— CentOS 无 nano 建 .env、npm 锁定、Node/PG 版本门槛

# 1. 验证要分三段，不要一把梭

| 段 | 测什么 | 绿了说明 |
|---|---|---|
| ① `ss -lntp \| grep ':8092'` | 进程在不在听 | Node 进程活着 |
| ② `curl http://127.0.0.1:8092/...` | 直连后端 | 应用、.env、PG、高德都通 |
| ③ `curl https://域名/...` | 走反代 | nginx + 证书 + 转发规则正确 |

关键顺序原则：**先直连，再走域名**。直连就 500 的问题，不要浪费时间怀疑 nginx。

## 实测真值（2026-10-20）

| 检查项 | 结果 |
|---|---|
| 8092 监听 | `LISTEN 0 511 *:8092`，`users:(("MainThread",pid=3336214,fd=18))` |
| 直连 `/getLine` | HTTP 200，0.0116s |
| 直连 `/getWeather?city=310000&extensions=base` | HTTP 200，0.3286s |
| 走域名 `/getLine` | HTTP 200，0.0560s |
| 走域名 `/getWeather...` | HTTP 200，0.0924s |
| 响应头 | `server: nginx`、`content-type: application/json; charset=utf-8`、`access-control-allow-origin: *`、`strict-transport-security: max-age=31536000`、`alt-svc: h3`、`x-powered-by: Express` |
| 证书 | `CN=translationbe.dawnivers.top`，TrustAsia LiteSSL RSA CA 2025 签发，链 3 张完整，`TLSv1.3 / TLS_AES_256_GCM_SHA384`，`Verify return code: 0 (ok)`，有效期 2026-10-20 → 2027-01-18 |

**结论：网络链路、反代、证书全绿。** `/getWeather` 200 同时证明了 `.env` 里的 AMAP_KEY 已生效（该接口不碰数据库）。

# 2. 实测中发现的真问题

## 2.1 `/getLine`、`/getStationInfo` 全部 500

```json
{"code":500,"message":"database \"Translation\" does not exist","data":null}
```

即：Node 活着、`.env` 读到了、pg 能连上 5432，但**目标库没建或没导**。排查顺序：

```bash
systemctl status postgresql --no-pager | head -5
sudo -u postgres psql -l            # 列表里有没有 Translation；只有小写 translation 则是 PGDATABASE 写错
psql --version                      # dump 是 18.4 导的（dump version 1.16），必须 ≥18
sudo -u postgres createdb -E UTF8 -T template0 Translation
sudo -u postgres pg_restore -d Translation --no-owner --no-privileges Translaion.sql
sudo -u postgres psql -d Translation -c "select count(*) from line; select count(*) from station;"
# 期望 18 与 510
```

改完 `.env` 必须**重启 node 进程**。
判据：`/getWeather` 200 而 `/getLine` 500 → 一定是数据库层，不是 key 层，也不是反代层。

## 2.2 进程名 `MainThread` 是 Node 22 的正常线程名

`ss -lntp` 里看到 `MainThread` 不要当成野进程——Node 22 的 v8 主线程名就是它。用 `ps -o pid,lstart,cmd -p 3336214` 确认是不是 `node index.js` 裸跑在 SSH 里（会随终端退出而死，建议转 systemd）。

## 2.3 `x-powered-by: Express` 暴露技术栈

生产可 `app.disable('x-powered-by')`，一行即可。

# 3. CentOS 终端粘贴多行命令的坑（本轮真实报错形态）

反斜杠续行 + 空行在交互 shell 里会被提前提交，表现为：

```
curl -sS -m 15 --resolve translationbe.dawnivers.top:443:127.0.0.1 \
  → curl: no URL specified!
      -o /dev/null -w ... → bash: -o: command not found
curl ... -G "$D/getStationInfo" --data-urlencode "name=人民广场"
  → {"code":400,"message":"缺少参数 origin 或 destination"}（参数根本没进去）
      --data-urlencode: command not found
```

这不是系统问题，**是把带 `\` 和多行续写的命令分段粘进了交互终端**。两条修法：

1. 一次性整体粘贴，粘贴完不要按回车；
2. 写成**单行**（推荐写进脚本后用 `bash check.sh` 跑）：

```bash
curl -sS -m 15 --resolve translationbe.dawnivers.top:443:127.0.0.1 -o /dev/null -w '  HTTP %{http_code}\n' "https://translationbe.dawnivers.top/getLine"
curl -sS -m 30 "https://translationbe.dawnivers.top/getLinePlan?origin=121.424698,31.391582&destination=121.475427,31.232135" | head -c 220; echo
curl -sI -m 15 -H "Origin: http://localhost:5173" "https://translationbe.dawnivers.top/getLine" | grep -i -E 'access-control-allow-origin|server'
```

# 4. 可复现的接口契约（本机实测真值，用于比对）

| 接口 | 期望 |
|---|---|
| `/getLine` | `code=200`，18 条线路，首条 `上海地铁1号线` |
| `/getStationInfo?name=人民广场` | `data.address="上海地铁1号线;上海地铁2号线;上海地铁8号线"`，`peopleFlow` 为随机数 |
| `/getWeather?city=310000&extensions=base` | `code=200`，字段 province/city/weather/temperature/... |
| `/getLinePlan?origin=GCJ&destination=GCJ` | 富锦路→人民广场 `distance=19660`(m)、`duration=2486`(s)，即 19.7 km / 41 min，segments=2 |

`/getLinePlan` 吃的是 **GCJ-02** 坐标（前端已用 `planModel.js` 的 `wgs84ToGcj02` 转换，L109）。测试用的那对坐标就是项目自己算出来的：人民广场 `121.475427,31.232135`、富锦路 `121.424698,31.391582`。WGS84 值（`121.470895,31.234068` 等）直接拿去测会偏差。

# 5. 故障对照表

| 现象 | 原因 / 修法 |
|---|---|
| 直连 200，域名 404 | `proxy_pass` 末尾斜杠：要 `proxy_pass http://127.0.0.1:8092;`（保留 /getLine），不能带尾斜杠吃掉前缀 |
| 直连 200，域名 502 | 反代连不到上游；CentOS 上 SELinux 需 `setsebool -P httpd_can_network_connect 1` |
| 域名 200 但 `/getWeather` 返回 `INVALID_USER_KEY` | `.env` 没加载（BOM / 引号 / Node <20.12），用 `config.js` 打印 key 长度应 32 |
| `/getLine` 500 `database "..." does not exist` | 库没建或没导，见 2.1 |
| 服务器上 `--resolve` 200、本机打不开 | DNS 未解析或安全组没放 443 |
| 8092 可从公网直连 | 防火墙/安全组只应放 80、443；8092 留在 127.0.0.1 |

Windows 侧验证要用 `curl.exe`（PowerShell 里 `curl` 是 `Invoke-WebRequest` 的别名）。
前端上线前必须把 [baseApi.js:3](Translation/src/api/baseApi.js#L3) 的 `http://127.0.0.1:8092` 改为 `https://translationbe.dawnivers.top`，否则 https 页面会被混合内容策略拦截；更稳妥的做法是改走 `VITE_API_BASE`（`.env.local` 本地填 127.0.0.1，服务器填域名），这样两边不用改代码。
