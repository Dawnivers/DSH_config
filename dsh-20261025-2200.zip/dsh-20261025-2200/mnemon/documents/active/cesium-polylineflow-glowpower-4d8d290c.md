---
id: "4d8d290c-8c3c-4257-910a-f5951dee59dc"
title: "Cesium 自定义 PolylineFlow 材质「线太白发不出本色」的成因与调参手册（glowPower / 白芯半径公式 / 色板近白陷阱）"
description: "Translation 项目线路高亮的白色饱和问题：polyGlowflow.glsl 中 glow 项在横截面中心发散导致纯白芯，白芯占线宽比例 = glowPower/(2+2·glowPower)；给出 renderRoute.js ROUTE_STYLE 调参位、各档观感对照、flowLength:0 与 glowPower:0 两个坑，以及全局色板第 5 项 #f2f2f2 导致 5 号线本身即白的结构性限制。"
status: "active"
created_at: "2026-10-19T05:19:45.998Z"
updated_at: "2026-10-19T05:19:45.998Z"
content_hash: "eeedca9bc19b51686217fcf40f9a9f43a61a8de31ae657713d110b80e4c79bf1"
source_paths:
  - "Translation/src/cesiumTools/lineAndpoints/line/PolylineFlowMaterialProperty.js"
  - "Translation/src/cesiumTools/lineAndpoints/line/polyGlowflow.glsl"
  - "Translation/src/components/bottom/StationPanel/QueryModePanel/guideload/renderRoute.js"
  - "Translation/src/cesiumTools/lineAndpoints/line/lineHighlight.js"
  - "Translation/src/config/lineAndStationStyle.js"
session_ids:
  - "c05a7ea3-3e78-41b1-bff3-673e4d4f3e1a"
memory_body_ids:
  []
---

# 线路高亮「只剩白色、看不出本色」的成因与调参手册

日期：2026-10-19。场景：Translation 智慧地铁 `/nodes`，路径规划的逐段高亮线颜色发白、看不出是哪条线。前置文档：`44fe1831-c29a-4d4c-aed8-334dfb8fa556`（guideload 路径规划四文件）、`4b4b2f1f-f963-4446-89f8-d87657b8102c`（面板展开与全局同色规则）。本文只讲材质泛光这一层。

## 1. 白色是怎么来的（着色器层面）

材质：[PolylineFlowMaterialProperty.js](Translation/src/cesiumTools/lineAndpoints/line/PolylineFlowMaterialProperty.js) 注册类型 `PolylineFlow`，uniforms 为 `color / glowPower / taperPower / flowSpeed / flowLength / flowIntensity / flowOffset`，GLSL 在 [polyGlowflow.glsl](Translation/src/cesiumTools/lineAndpoints/line/polyGlowflow.glsl)：

```glsl
float glow = glowPower / abs(st.t - 0.5) - (glowPower / 0.5);   // 第 16 行
fragColor.rgb = max(vec3(glow - 1.0 + color.rgb), color.rgb);   // 第 23 行
```

`st.t` 是横截面位置 0~1，线中心 `st.t → 0.5` 时分母趋 0、`glow` 发散，`glow - 1.0 + color.rgb` 远超 1，被帧缓冲截断成**纯白**。因此「白」不是颜色配错，而是泛光项在线中心饱和。

## 2. 白芯半径公式（调参的唯一算式）

令 `glow = 1` 即为「刚刚烧到纯白」的边界：

```
x = glowPower / (2 + 2·glowPower)      // x = 白芯半径占「半线宽」的比例，等效白芯占线宽 2x
```

| glowPower | 白芯占线宽 | 观感 |
|---|---|---|
| 1.2 | 54% | 半条线是白芯，本色只剩边缘一圈 |
| 0.5 | 33% | 与全局 18 条线同档，亮芯但本色占主导 |
| 0.3 | 23% | 本色为主，中间一条细亮线（路径规划最终采用） |
| 0.1 | 8% | 近乎纯色平涂 |

**不要写 0**：中心会出现 0/0 得 NaN，整条线可能消失或变成噪点。

## 3. 系数在哪里改

调参位收敛成一个常量 [`renderRoute.js`](Translation/src/components/bottom/StationPanel/QueryModePanel/guideload/renderRoute.js) 的 `ROUTE_STYLE`（原来散在 `renderLines(...)` 内联参数里）：

```js
const ROUTE_STYLE = {
  width: 8,          // 线宽，全局线是 3
  glowPower: 0.3,    // ← 白不白只调这个
  taperPower: 0.05,  // 两端淡出强度，越小淡出越短
  flowLength: 0,     // 关掉流动高亮段
};
```

背景：初版 `glowPower: 1.2` 是从 [`lineHighlight.js:55`](Translation/src/cesiumTools/lineAndpoints/line/lineHighlight.js#L55) 抄来的——那套服务于「重点活动」的粗高亮闪动，泛光故意开到很大；直接挪到路径规划上就成了白条。

调参经验：想把线「调亮」优先加 `width`，不要加 `glowPower`，后者只会继续吃掉本色。

## 4. 两个容易踩的坑

- **关流动要写 `flowLength: 0`，不能写 `flowIntensity: 0`。** `flowIntensity` 参与的是 `material.emission *= flowIntensity`，归零后流线段 alpha 仍被拉满，结果是整条**黑带**，而不是「不流动」。
- **色板里本身有近白色。** [`lineAndStationStyle.js:13`](Translation/src/config/lineAndStationStyle.js#L13) 的 `LINE_COLORS` 第 5 项是 `#f2f2f2`（近白），按「下标 4 → 5 号线」分配。路径里只要有 5 号线，那条线**材质层面就是白的**，`glowPower` 降到 0.1 也只是灰白。真要改得换 `LINE_COLORS[4]`（如 `#9c8bd4`），但那是全局色板，站点光锥、线路图层会一起变；只给 5 号线单独换色需改成按线号映射，不是调系数能解决的。

## 5. 验证范围与其局限

改后 `/nodes` 面板查询正常（莘庄→五角场：5 元 / 84 分钟 / 28.9 km / 换乘 1 次 / 换乘步行合计 303 m，1号线 11 站 + 10号线 13 站）、无 Vite 错误浮层、实体照常生成。但**像素级效果未能验证**（该机器截图被系统限制），"还白不白"必须靠人眼确认——若 0.3 仍偏白继续降到 0.15，若嫌不亮改 `width`。

经验：涉及 GLSL 泛光/透明的改动，在没有截图能力的环境里只能保证「实体生成 + 无报错」，颜色观感必须交回人工复核，不要声称已验证视觉效果。
