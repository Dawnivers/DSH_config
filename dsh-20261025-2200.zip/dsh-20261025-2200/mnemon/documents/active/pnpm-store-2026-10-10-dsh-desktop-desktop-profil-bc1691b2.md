---
id: "bc1691b2-c8c1-41ad-a301-37cac4c79602"
title: "pnpm store 误删插件事故与恢复全记录（2026-10-10，DSH Desktop desktop profile）"
description: "2026-10-10 C 盘清理把 pnpm store 当缓存删除，导致 16 个插件全灭、profile 依赖被重写为空；记录「先移入暂存区」为何是唯一救命设计、逐层恢复步骤、三层验证证据（日志零错误 / healthy-startup 快照指纹 / 实测调用）以及脚本新增硬护栏。更正文档 db2c5a2b 中把 pnpm store 归入可清理缓存的分类。"
status: "active"
created_at: "2026-10-10T05:19:21.966Z"
updated_at: "2026-10-10T05:19:21.966Z"
content_hash: "c9592857b5af0301d31a749872237533aa0e76369ddf0b7c96a70e3b51037ee8"
source_paths:
  - "c-drive-cleanup/插件丢失事故与恢复报告.md"
  - "c-drive-cleanup/clean-c-drive.ps1"
  - "c-drive-cleanup/clean-c-drive.cmd"
session_ids:
  - "ad92799a-2c9c-4285-a042-721019da5640"
memory_body_ids:
  []
---

# pnpm store 误删插件事故与恢复全记录（2026-10-10）

## 0. 与既有文档的关系（重要更正）

- 流程与脚本设计见文档 `db2c5a2b-468a-48c1-8d5f-4e64e45e25dd`（C 盘安全清理流程与 2026-10-10 实机结果）。本文不重复其暂存区机制，只记录**事故、恢复与由此产生的新护栏**。
- **该文档 §4 的分类已过时且危险**：它把 `pnpm store` 与 `npm / pnpm / pip / puppeteer` 并列当作「包管理器缓存」，并在 §5 中把「pnpm store 0.85 GB」记为成功释放项。事实上 `%LOCALAPPDATA%\pnpm\store` 在本机**不是内容寻址缓存，而是 DSH 插件的实体存放地**。以本文为准；`db2c5a2b` 保持原样不改（工具只支持新建）。

## 1. 事故经过

- 在 C 盘清理中，`%LOCALAPPDATA%\pnpm\store` 仅依据「目录大小 + 时间戳」被判定为缓存并移出。
- 该目录真实内容：`store\v11\projects\<hash>\node_modules` 下就是 desktop / web 两个 profile 的插件实体；同级还保存该 profile 的 `package.json`、`cordis.patch.yml`、`pnpm-lock.yaml`、`pnpm-workspace.yaml` 快照。读该目录 `.modules.yaml` 的 `virtualStoreDir` 可对上 `.dsh\profiles\<name>`。
- 后果：16 个插件全部失效；DSH 启动时触发 `migrating legacy Profile dependency layout`，把 profile 依赖重写成**空**（`package.json` 依赖数由 16 变 1）；8 个 `link:` 本地插件源目录（含用户自研插件）被清成空壳，1719 个源码文件一度消失。

## 2. 为什么能救回来

唯一原因：清理脚本的设计是**先跨盘 `Move-Item` 到暂存区 `D:\_CDriveCleanupStash\<时间戳>`，确认无误后才 `-Purge`**。

- 若当初直接用 `Remove-Item`，1719 个自研源码文件不可逆丢失。
- 教训：这类操作**宁可多一步、不省一步**；「暂存区」不是保守，而是唯一可回滚路径。

## 3. 恢复步骤（可复用）

1. **配置回填**：把 `store\v11\projects\<hash>\` 下的 `package.json` / `cordis.patch.yml` / `pnpm-lock.yaml` / `pnpm-workspace.yaml` 复制回 `.dsh\profiles\<name>\`（desktop 与 web 各一份 hash 目录）。
2. **依赖回填**：`node_modules` 用 `robocopy /E` 从同一 `projects\<hash>\node_modules` 搬回 profile；最终 43014 个文件。
3. **link 源码回填**：8 个 `link:` 插件的源码从 `node_modules\<包名>` 复制回其源目录（含 `.git`，共 1719 个文件）。
4. **运行时补齐**：`codex-runtimes` 补回 1440.6 MB。
5. **重启验收**：必须完全退出并重开 DSH Desktop，磁盘文件才会被重新加载为插件。
6. 结果：C 盘可用 38.46 → 69.71 GB（净释放 31.25 GB）；暂存区仍保留 34 GB 于 D 盘，待确认后再 Purge。

## 4. 三层恢复验证证据（本次实测，非「看起来没报错」）

- **第一层：DSH 自身判定**
  - 最新启动日志零插件错误、零 pending。
  - 重启后**不再出现** `migrating legacy Profile dependency layout`（该迁移正是上次把依赖写空的元凶）。
  - `package.json` 保持恢复版（1965 字节，未再被重写）。
  - 13:16:21 自动健康快照 manifest 标记 `reason: "healthy-startup"`，记录的配置指纹与恢复版一致（`package.json` 1965 字节、`cordis.patch.yml` 1690 字节；快照位于 `%APPDATA%\DSH Desktop\health-snapshots\<hash>\slot-1\`）。
- **第二层：实际调用插件功能**
  - `dsh-mnemon`：`mnemon_status` → healthy，v0.2.10，1 个记忆空间，41 洞察 / 401 边。
  - `@linxin666/dsh-web-all`：`task_board_list` → 完整看板（含 armed 定时卡）。
  - `dsh-context7`：检索真实返回库索引。
  - `@local/dsh-mcp-anysearch`：搜索 ~1348ms 返回真实结果。
  - `dsh-code-index`：正确响应（返回 "no git repository" 属正常，当前工作区非 git 仓库）。
- **第三层：清单与构建产物**
  - desktop profile 18 项 bundles，其中 15 个第三方/自研插件全部存在且版本正常。
  - 3 个「缺失」是**误报**：`@deepseek-ai/dsh-base`、`dsh-web-app`、`dsh-experimental-schedule-bundle` 是官方内置 bundle，从 DSH 安装目录加载，本就不在 profile 的 `node_modules` 里（路径已逐一验证存在）。
  - `@linxin666` 下 20 个客户端 UI 包 `lib/` 全部存在（20/20）；host+client 插件构建产物（`lib` / `dist`）齐全。
  - 技能：`.dsh\skills` 9 个 Python 数据栈技能 + `academic-research-skills` 4 个 + `archify` 1 个 = 14 个全部就位。
- **盲区**：Electron 界面入口（侧边栏各 UI 插件、内置浏览器）无法由 agent 侧工具确认，需用户目视核对。

## 5. 由此新增的硬护栏

1. `pnpm store` **永久移出**清理脚本的目标清单，任何级别都不再包含它。
2. 新增「**目标目录含 `package.json` 即一律拒绝清理**」的硬校验：不再凭目录名判断是不是缓存。
3. 既有暂存区（先移不删、独立时间戳 + manifest、可 `-Rollback`）保留为强制流程。

## 6. 交付物

| 物 | 路径 |
|---|---|
| 事故与恢复报告 | `c-drive-cleanup\插件丢失事故与恢复报告.md` |
| 清理脚本（含新护栏） | `c-drive-cleanup\clean-c-drive.ps1` |
| 双击包装器 | `c-drive-cleanup\clean-c-drive.cmd` |
