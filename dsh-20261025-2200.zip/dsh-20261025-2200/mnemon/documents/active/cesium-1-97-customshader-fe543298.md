---
id: "fe543298-52a6-443f-98f1-d523ad5fe3eb"
title: "Cesium 1.97 CustomShader 实测参考（含与新版官方文档的三处差异）"
description: "在 Translation 智慧地铁项目本机安装的 Cesium 1.97.0 源码上逐项核对过的 CustomShader API：构造选项、入口函数签名、可用 attributes/材质字段、UniformType，以及 fromUrl / fromGltfAsync / normalEC 三处与新版文档不一致的坑。"
status: "active"
created_at: "2026-10-07T02:10:10.264Z"
updated_at: "2026-10-07T02:10:10.264Z"
content_hash: "f68ca3662f7180b5a0dc5004b1d3d15760f9e94ed88a4d864730016dcc576fa7"
source_paths:
  - "Translation/node_modules/cesium/Source/Scene/Model/CustomShader.js"
  - "Translation/node_modules/cesium/Source/Scene/Model/CustomShaderPipelineStage.js"
  - "Translation/node_modules/cesium/Source/Scene/Model/CustomShaderMode.js"
  - "Translation/node_modules/cesium/Source/Scene/Model/CustomShaderTranslucencyMode.js"
  - "Translation/node_modules/cesium/Source/Scene/Model/UniformType.js"
  - "Translation/node_modules/cesium/Source/Shaders/Builtin/Structs/modelMaterial.glsl"
session_ids:
  - "007ceaf1-aed9-4057-b50c-24f122e46c42"
memory_body_ids:
  []
---

# Cesium 1.97 CustomShader 实测参考

来源：一次「查 Cesium CustomShader」的会话。当时通过 context7 插件拿到的是**最新版**官方 API 参考与 CustomShader Guide，版本对不上，于是改为直接读用户本机安装的 Cesium 源码逐项核对。结论均以 1.97.0 源码为准。

核对对象：`D:\WebGIS\web三维开发\智慧地铁项目\Translation`（Vue3 + Cesium 前端，见关联文档 `d6dc91dd-bff2-4971-897a-5b2fe5bf1580`），`node_modules/cesium` 版本号 1.97.0。

核对用的源码文件：
- `node_modules/cesium/Source/Scene/Model/CustomShader.js`（473 行）
- `node_modules/cesium/Source/Scene/Model/CustomShaderMode.js`
- `node_modules/cesium/Source/Scene/Model/CustomShaderTranslucencyMode.js`
- `node_modules/cesium/Source/Scene/Model/CustomShaderPipelineStage.js`（643 行，代码生成与属性注入逻辑）
- `node_modules/cesium/Source/Scene/Model/UniformType.js`
- `node_modules/cesium/Source/Shaders/Builtin/Structs/modelMaterial.glsl`（`czm_modelMaterial` 结构体真实定义）

## 1. 三处「照抄新文档就报错」的版本坑

| 新版文档写法 | 1.97 实际 | 说明 |
|---|---|---|
| `Cesium3DTileset.fromUrl(url, { customShader })` | 不存在 | 1.97 只能 `new Cesium.Cesium3DTileset({ url, customShader })` + `scene.primitives.add` |
| `Model.fromGltfAsync({ ... })` | 不存在 | 1.97 只有回调式 `Model.fromGltf = function (options)`（`Source/Scene/Model/Model.js:2568`） |
| `material.normal = ...` | 字段名不同 | 1.97 是 `material.normalEC` |

`fromUrl` / `fromGltfAsync` 是 1.104+ 引入的异步工厂方法。**该项目的 Cesium 锁在 1.97，不能照抄 cesium.com 现行文档的示例。**

## 2. 构造函数全部选项

```js
new Cesium.CustomShader({
  mode,              // 默认 MODIFY_MATERIAL
  lightingModel,     // PBR / UNLIT，不填则沿用模型自带
  translucencyMode,  // 默认 INHERIT
  uniforms,          // Object.<String, UniformSpecifier>
  varyings,          // Object.<String, VaryingType>
  vertexShaderText,  // 含 vertexMain()
  fragmentShaderText // 含 fragmentMain()
})
```

- `mode`：`Cesium.CustomShaderMode.MODIFY_MATERIAL`（默认）/ `REPLACE_MATERIAL`（保留原光照、只替换材质）
- `lightingModel`：`Cesium.LightingModel.PBR` / `UNLIT`；做「自发光、不受光照影响」必须 UNLIT
- `translucencyMode`：`INHERIT`（默认）/ `OPAQUE` / `TRANSLUCENT`；**要半透明必须显式设为 TRANSLUCENT，只改 `material.alpha` 不会生效**
- 可作用于 `Cesium3DTileset`、`Model`、`VoxelPrimitive`

## 3. 两个入口函数

参数名必须一字不差（Cesium 靠参数名做代码生成）：

```glsl
void vertexMain(VertexInput vsInput, inout czm_modelVertexOutput vsOutput) { }
void fragmentMain(FragmentInput fsInput, inout czm_modelMaterial material) { }
```

`vertexMain` 是模型空间进、模型空间出；`fragmentMain` 的 `material` 是 `inout`，就地修改。

## 4. 可用 attributes（`vsInput.attributes` / `fsInput.attributes`）

只注入「模型里真实存在 且 shader 里用到」的属性，缺失时按 `CustomShaderPipelineStage.js` 里的 `attributeDefaultValueLUT` 给默认值：

| 属性 | GLSL 类型 | 缺失默认值 |
|---|---|---|
| `positionMC` / `positionWC` / `positionEC` | vec3 | — |
| `normalMC`（片元内为 `normalEC`） | vec3 | `vec3(0.0, 0.0, 1.0)` |
| `tangentMC` / `bitangentMC` | vec3 | `vec3(1,0,0)` / `vec3(0,1,0)` |
| `texCoord_0`, `texCoord_1`… | vec2 | `vec2(0.0)` |
| `color_0`, `color_1`… | vec4 | `vec4(1.0)` |
| `joints_0` / `weights_0` | ivec4 / vec4 | `ivec4(0)` / `vec4(0.0)` |

- 后缀含义：`MC` 模型坐标、`WC` 世界坐标、`EC` 眼坐标
- **`normalMC` 在片元着色器里会被自动重命名为 `normalEC`**（源码含此转换逻辑）
- `positionWC` / `positionEC` 属于派生于 `positionMC` 的 builtin，单独处理
- 另有 `fsInput.featureIds.featureId_0`、`fsInput.metadata.*`（3D Tiles 属性），1.97 已支持

## 5. 可修改的材质字段（`czm_modelMaterial` 真实定义）

```glsl
struct czm_modelMaterial {
    vec3  diffuse;    // 漫反射基色
    float alpha;      // 不透明度
    vec3  specular;   // 高光 / PBR 的 f0
    float roughness;  // 0=光滑 1=粗糙（注意不叫 shininess）
    vec3  normalEC;   // 眼坐标法线
    float occlusion;  // 环境光遮蔽
    vec3  emissive;   // 自发光
};
```

颜色值在**线性色彩空间**，直接填 sRGB 数值会偏亮。

## 6. UniformType 与一个源码 bug

`UniformType` 在 1.97 位于 `Source/Scene/Model/UniformType.js`（**不在** `Source/Renderer/`，按旧路径找不到文件）：`FLOAT/VEC2/VEC3/VEC4`、`INT/INT_VEC2..4`、`BOOL/BOOL_VEC2..4`、`MAT2/MAT3/MAT4`、`SAMPLER_2D/SAMPLER_CUBE`。

⚠️ 1.97 源码 bug：`UniformType.MAT3` 的值被写成 `"mat2"`（`UniformType.js:107`）。用 3×3 矩阵 uniform 需自行规避。

## 7. 可运行示例（1.97 写法）

```js
import * as Cesium from 'cesium'

const customShader = new Cesium.CustomShader({
  uniforms: {
    u_time:      { type: Cesium.UniformType.FLOAT, value: 0 },
    u_highlight: { type: Cesium.UniformType.VEC4,  value: new Cesium.Cartesian4(1.0, 0.45, 0.0, 1.0) },
  },
  varyings: { v_stripe: Cesium.VaryingType.FLOAT },
  lightingModel: Cesium.LightingModel.UNLIT,
  translucencyMode: Cesium.CustomShaderTranslucencyMode.TRANSLUCENT, // 不加不会透明
  vertexShaderText: `
    void vertexMain(VertexInput vsInput, inout czm_modelVertexOutput vsOutput) {
      v_stripe = vsInput.attributes.positionMC.y;
    }
  `,
  fragmentShaderText: `
    void fragmentMain(FragmentInput fsInput, inout czm_modelMaterial material) {
      float wave = 0.5 + 0.5 * sin(v_stripe * 20.0 - u_time * 4.0);
      material.diffuse = mix(material.diffuse, u_highlight.rgb, wave);
      material.alpha  = 0.55 + 0.35 * wave;
    }
  `,
})

const tileset = new Cesium.Cesium3DTileset({ url: '你的/tileset.json', customShader }) // 1.97：先 new
viewer.scene.primitives.add(tileset)

viewer.scene.preRender.addEventListener(() => {  // 每帧更新 uniform
  customShader.setUniform('u_time', performance.now() / 1000)
})
```

## 8. 其他注意点

- CustomShader 是 `@experimental`，基于尚未定稿的 3D Tiles 规范，不受 Cesium 标准弃用策略保护，**跨版本升级必须重新验证**。
- 用了纹理 uniform 时，不再使用需手动 `customShader.destroy()`，GC 不会代劳；`setUniform` 之外还有 `update(frameState)` / `isDestroyed()`。
- 纹理 uniform 用 `new Cesium.TextureUniform({ url })`，也支持 TypedArray。

参考：[CustomShader API 参考](https://cesium.com/learn/cesiumjs/ref-doc/CustomShader.html) · [官方 Custom Shader Guide](https://github.com/cesiumgs/cesium/blob/main/Documentation/CustomShaderGuide/README.md)（两者均为最新版，使用前按上文差异校正）
