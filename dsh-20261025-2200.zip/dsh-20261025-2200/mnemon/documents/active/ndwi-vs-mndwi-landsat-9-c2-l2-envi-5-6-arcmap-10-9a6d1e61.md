---
id: "9a6d1e61-5598-45f2-afa8-2bbe2df41884"
title: "东湖 NDWI vs MNDWI 水体提取实验结果（Landsat 9 C2 L2，ENVI 5.6 + ArcMap 10.2）"
description: "东湖子集（1494×1173）上 NDWI/MNDWI 阈值 0 提取水体的实测结果：面积 283.286 / 296.941 km²（+4.82%）、多边形数 5329/6518、植被/建成区/土壤三类背景均值对比（建成区 −0.2336 vs −0.2836）、双实现交叉复算证据、ENVI 配对被阻断改走 ArcGIS Raster Calculator 的偏差、QA_PIXEL 子集全 0、中文输入法吞键与 PowerShell 重命名坑、成果清单与 16 张截图编号。承接可行性文档 4c9e5e3a。"
status: "active"
created_at: "2026-10-13T08:30:49.953Z"
updated_at: "2026-10-13T08:30:49.953Z"
content_hash: "acb9ee7d333e4fbefb1e41726498cf2c806d5bafd7a2b4ed7e7db68c8f1ca668"
source_paths:
  []
session_ids:
  - "0eadd7ee-3103-495f-a5a6-ce2e16f8ea82"
memory_body_ids:
  []
---

# 东湖 NDWI vs MNDWI 水体提取实验结果

承接实验前的环境与数据源可行性核查文档：`4c9e5e3a-3e5a-46d0-899b-1366e2dbd754`（本机 ENVI 5.6 / ArcGIS 10.2 核实、地理空间数据云检索坑、七步流程）。本文档只记录**实测结果与偏差证据**，流程本身以该文档为准。

## 1. 输入与工作区

- 影像：`LC09_L2SP_123039_20230313_20230315_02_T1`（Landsat 9、Collection 2 Level-2 地表反射率、云量 0.03%、Path 123 / Row 039）。
- 裁剪：以用户 POI 多边形投影到 UTM 49N 后换算窗口，`File → Save As → Spatial Subset` 裁出 **1494 × 1173 像元（≈1577.2 km²）**，落盘为 `SR_B3_sub.dat` / `SR_B5_sub.dat` / `SR_B6_sub.dat`。
- 对齐与几何核验（arcpy 独立复读）：`ALIGNED = True`，三波段行列、左下角坐标、30 m 像元一致，无填充值。
- 反射率换算系数：`2.75e-05 / −0.2`（Landsat C2 L2 官方系数），结果 −0.067 ~ 1.60，量级合理。

## 2. 主要数值结果

阈值为 0 的二值化水体提取：

| 指标 | NDWI | MNDWI |
|---|---|---|
| 水面面积 | **283.286 km²** | **296.941 km²**（+4.82%） |
| 差值 | — | **+13.66 km²** |
| 水面多边形数 | 5,329 | 6,518 |

面积由「值为 1 的像元数 × 900 m²」统计，并与矢量 geometry 面积交叉核对一致。

**阈值 0 下两种指数在背景类别上的均值（子集内，已剔除水体像元）**：

| 类别 | 像元/面积 | NDWI 均值 | MNDWI 均值 | NDWI>0 | MNDWI>0 |
|---|---|---|---|---|---|
| 植被 NDVI>0.25 | 755154 px / 679.64 km² | −0.4245 | −0.3772 | 0.000% | 0.000% |
| 建成区 | 340119 px / 306.11 km² | −0.2336 | **−0.2836** | 0.000% | 0.000% |
| 土壤/其他 | 323508 px / 291.16 km² | −0.1993 | −0.2022 | 0.000% | 0.000% |

**核心结论**：建成区上 MNDWI 均值比 NDWI 低约 0.050（−0.2836 vs −0.2336），即建成区在短波红外反射更强、换成 SWIR1 后指数被压得更负，**MNDWI 对建成区的抑制确实优于 NDWI**，与 Xu (2006) 的论点一致；两类指数在非水体背景上均无 >0 的误分像元，MNDWI 的收益主要体现在水面连通性与面积。

指数范围：NDWI 子集 min=−0.0707 / max=1.0235 / mean=0.0939；全图 7681×7541 uint16 的读出仅用于定位子集。NDVI 全图范围 −0.8739 ~ 7.0119（含异常高值，仅用于背景分类）。

## 3. 复算方式（证据强度）

验证不是信软件自述，而是**双实现交叉核对**：

- 裁剪结果的行列/范围/DN 统计由 arcpy `RasterToNumPyArray` 独立读取核对。
- NDWI/MNDWI 用 **arcpy 与 NumPy 两套独立实现**分别计算，范围与像元数逐位相同。
- 面积：栅格像元统计 与 矢量 geometry 面积完全吻合。
- ArcMap 工程重建核对：`water_compare.mxd` 成功载入 `mndwi_water.shp` / `ndwi_water.shp` / `MNDWI.tif` / `NDWI.tif`。

## 4. 必须记录的偏差与异常

1. **NDWI/MNDWI 最终在 ArcGIS Raster Calculator 计算，而非 ENVI Band Math。** 原因：ENVI `Variables to Bands Pairings` 对话框在本机 **无法交互** —— 主事件处理器抛 `Error: Variable is undefined: T_NS.`，随后弹出模态 `Band Math Input File` 框阻断全部操作，重启 ENVI 后复现；单击/双击/滚轮/键盘/剪贴板/挪窗口/放大对话框均无法选中波段树。应变：改在 ArcGIS Raster Calculator 使用**同一公式** `(Float(b1)-Float(b2))/(Float(b1)+Float(b2))`，输入仍是 ENVI 产出的反射率栅格，ENVI 在链路中仍承担裁剪与反射率反演。实验报告第七章已记录该偏差，证据截图 `14_envi_eventhandler_error.png`、`12_bandmath_inputfile.png`。
2. **QA_PIXEL 在本景子集内数值全为 0**，故未做云掩膜。本景云量仅 0.03%、东湖上空无云，不影响本次提取；**换景复做前必须先确认 QA_PIXEL 是否有值**，否则云掩膜步骤会静默失效。
3. **本机中文输入法会吞按键**：向 ENVI/对话框直接键入会丢字符，全程改用剪贴板粘贴才稳定。手动操作 ENVI 时若「输入框输不进字」，多半同因。
4. **PowerShell 批量重命名截图不可靠**：出现 `numpy.ndarray has no attribute 'tobytes'`，以及脚本内把 `_shots\e02_file_menu.png` 拼成看似绝对路径却被当相对路径、导致 13 个文件报 MISSING，而 `Test-Path` 直接验证同一路径返回 `True`；改用 JSON 映射表 + 直接路径复制后一次成功。另：本机无 `pwsh`，只有 Windows PowerShell。
5. `F:\RS_Lab\04_out` 下两个 `.shp` 残留 `.lock` 文件（ArcMap 仍打开 `water_compare.mxd` 所致），关闭 ArcMap 后释放；ENVI 窗口已从后台还原回屏幕。

## 5. 成果清单（均在 `F:\RS_Lab`）

- 报告：`05_report\遥感数字图像处理实验报告.md`（15.7 KB，含第七章偏差说明）。
- 图件：`04_out\fig1_NDWI_MNDWI_compare.png`（四联对比图，2536 KB）、`04_out\fig2_arcmap_layout.png`（ArcMap 布局导出）。
- 栅格与矢量：`04_out\NDWI.tif`、`MNDWI.tif`、`ndwi_water.tif/.shp`、`mndwi_water.tif/.shp`、`water_compare.mxd`。
- 中间产物：`03_work\` 下 `SR_B3_sub.dat` / `SR_B5_sub.dat` / `SR_B6_sub.dat` 及 `Green.dat` / `NIR.dat` / `SWIR1.dat` 反射率栅格。
- 过程截图：`05_report\screenshots\` 16 张，编号含义为 01 打开三 SR 波段 → 02 File 菜单 → 03 SaveAs 空间裁剪 → 04 裁剪范围 → 05 输出参数 → 06 SWIR1 景 → 07 三个子集 → 08 三景反射率 → 09 反射率 Band Math 表达式 → 10 NDWI 表达式 → 11 变量—波段配对 → 12 Band Math 输入文件（异常） → 13 ArcMap → 14 ENVI 事件处理器报错 → 15 四联对比图 → 16 ArcMap 布局导出。

## 6. 可续做的方向

- 用直方图拐点 / Otsu 求最优阈值与固定阈值 0 对比，检验 4.82% 的面积差有多少来自阈值选择。
- 换一景有云数据，把 QA_PIXEL 位掩膜（bit3 云 | bit4 云影 = 8+16）真正跑一遍。
