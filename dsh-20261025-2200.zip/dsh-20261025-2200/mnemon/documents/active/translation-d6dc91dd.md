---
id: "d6dc91dd-bff2-4971-897a-5b2fe5bf1580"
title: "Translation 智慧地铁项目：启动与接口联调说明"
description: "Translation（Vue3+Cesium 前端）/ Translation_BE（Express+PostgreSQL 后端）的目录结构、启动方式、pnpm 自检绕过方法、全链路验证步骤与本次实测证据。"
status: "active"
created_at: "2026-10-06T13:12:20.541Z"
updated_at: "2026-10-06T13:12:20.541Z"
content_hash: "6b147d1adc3e4304f4fcf61b704bb350ccf9c0b47e023bb6d5ecd20f12a4f91e"
source_paths:
  - "Translation/package.json"
  - "Translation/vite.config.js"
  - "Translation/src/api/baseApi.js"
  - "Translation/src/api/request.js"
  - "Translation_BE/package.json"
  - "Translation_BE/config.js"
  - "Translation_BE/index.js"
session_ids:
  - "b5f07018-9381-44c8-8e98-b5b10799e745"
memory_body_ids:
  []
---

# Translation 智慧地铁项目：启动与接口联调说明

来源：一次「启动 Translation 项目」的完整排查会话。项目根目录 `D:\WebGIS\web三维开发\智慧地铁项目`，下含 `Translation`（前端）、`Translation_BE`（后端）、`综合项目：智慧地铁`（另一个独立项目）。

## 1. 项目构成

### 前端 `Translation`
- `package.json`：`type: module`；脚本 `dev` = `vite`、`build` = `vite build`、`preview` = `vite preview`；引擎要求 `node ^22.18.0 || >=24.12.0`
- 主要依赖：`vue ^3.5.42`、`vue-router ^5.3.1`、`pinia ^4.0.3`、`cesium 1.97`、`@cesium-china/cesium-map`、`cesium-heatmap-es6`、`turf`、`axios`、`dayjs`、`video.js` + `@videojs-player/vue`、`flv.js`、`dat.gui`、`lodash`
- devDependencies：`vite ^8.2.2`、`@vitejs/plugin-vue ^6.0.8`、`vite-plugin-cesium ^1.2.23`、`vite-plugin-vue-devtools ^8.2.1`
- `vite.config.js`：插件 `vue() / vueDevTools() / cesium()`，别名 `@` → `./src`；**未配置 server.proxy**，前端直连后端绝对地址
- 关键源码：
  - `src/api/baseApi.js`：`axios.create({ baseURL: 'http://127.0.0.1:8092', timeout: 3000 })`；响应拦截器在 `res.data.code == 200` 时直接返回 `res.data`，否则 `Promise.resolve(res)`
  - `src/api/request.js`：封装 `getLinePlan / getWeather / getLine / getStationInfo`
  - 页面：`src/views/cesiumView.vue`（约 34.7 KB，首屏主要逻辑在此）

### 后端 `Translation_BE`
- `package.json`：`type: commonjs`，`start` = `node index.js`；依赖 `express ^5.2.1`、`cors ^2.8.6`、`pg ^8.23.0`
- `config.js`（统一配置，含端口/数据库/高德）：
  - `port: 8092`
  - PostgreSQL：`localhost:5432`，库 `Translation`，用户 `postgres`（密码见本地 `config.js`）
  - 高德：`amap.city = '021'`（上海 citycode，同城规划）、`amap.adcode = '310000'`（天气接口只认 adcode）
- `index.js`（202 行）接口清单，全部返回 `{ code, message, data }` 包装：
  | 路由 | 参数 | 说明 |
  |---|---|---|
  | `GET /getLinePlan` | `origin`, `destination`（`lng,lat`） | 转调高德 v5 `transit/integrated`，`strategy=7`（地铁优先）、`AlternativeRoute=1`、`show_fields=cost,polyline`；返回 `cost/duration/distance/segments` |
  | `GET /getWeather` | `extensions=base\|all`, `city`（adcode，默认 310000） | 转调高德 v3 `weatherInfo`；`base` → `lives[0]`，`all` → `forecasts[0]` |
  | `GET /getLine` | — | 查 `line`(id,name,basicPrice,length,xs,ys) 与 `station`(name,name_2,lon,lat,ischange,sort)；按 `name_2` 分组站点、组内按 `sort`；线路名按其中数字排序（无数字排最后） |
  | `GET /getStationInfo` | `name` | 查 `station`，同名站点跨线路去重后用 `;` 拼接为 `address`，并返回 `peopleFlow` |
- 业务约定：人流量为**随机模拟**——换乘站（`ischange=1`）300~999，普通站 50~299（`genPeopleFlow`）
- 坐标格式化：高德要求小数点后 ≤6 位，`fmtCoord` 统一 `toFixed(6)`
- 数据库表：`line`、`station`（`name` = 站名，`name_2` = 所属线路名）

## 2. 启动步骤

后端（Windows PowerShell）：

```powershell
cd "D:\WebGIS\web三维开发\智慧地铁项目\Translation_BE"
npm start          # 或 node index.js
# → Translation_BE server running at http://localhost:8092
```

前端：

```powershell
cd "D:\WebGIS\web三维开发\智慧地铁项目\Translation"
pnpm dev           # 交互式终端下正常可用
```

**无 TTY 环境下的已知坑**：以非交互方式调用 `pnpm dev` 时，pnpm 会在依赖自检阶段尝试重装/清理 `node_modules`，报
`ERR_PNPM_ABORTED_REMOVE_MODULES_DIR_NO_TTY`（`Aborted removal of modules directory due to no TTY`）并退出（exit 1，Vite 根本没有启动）。
绕过方式二选一：
1. 直接绕过 pnpm 启动器：`node node_modules/vite/bin/vite.js`
2. 先设 `$env:CI = "true"`（或 `confirmModulesPurge=false`）再执行 `pnpm dev`

## 3. 启动状态与全链路验证（本次实测）

| 服务 | 地址 | 结果 |
|---|---|---|
| 前端 Vite dev（Vue3 + Vite 8 + Cesium） | http://localhost:5173/ | ✅ 本次启动，冷启动 23.5 s，无报错 |
| 后端 Express | http://127.0.0.1:8092 | ✅ 已由 `E:\node.exe index.js`（pid 48524）在跑，无需重复启动 |

验证方法与实测结果：
- 页面：`GET http://localhost:5173/` → 200（len 633），HTML 已注入 `/cesium/Widgets/widgets.css` 与 Vue DevTools overlay
- 模块编译：`/src/main.js` 200 (1862)、`/src/App.vue` 200 (4316)、`/src/views/cesiumView.vue` 200 (34728)
- dev server 日志：无新增输出/无报错；Vue DevTools 面板 `http://localhost:5173/__devtools__/`
- 接口链路：
  - `GET /getLine` → `code=200`，**18 条线路**（1 号线 28 站、2 号线 31 站、3 号线 29 站…）
  - `GET /getWeather` → `code=200`，「上海市 晴 18℃」
  - `GET /getStationInfo?name=人民广场` → `code=200`，`address = "上海地铁1号线;上海地铁2号线;上海地铁8号线"`，`peopleFlow = 475`（换乘站随机值在 300~999 区间，符合预期）

## 4. 环境事实与排查注意点

- 端口现状：`8092` 由 node 监听；`5173` / `5174` 空闲（Vite 默认占用 5173，被占会自动 +1）
- Windows PostgreSQL 服务有三个实例：`postgresql-x64-13` Stopped、`postgresql-x64-14` Stopped、`postgresql-x64-18` **Running** —— 后端连的 5432 实际由 18 提供，故数据库查询正常
- 本机工具链：Node v24.16.0、npm 11.13.0、pnpm 11.8.0
- 排查经验：`Translation` 与 `Translation_BE` 目录内各自带 `node_modules`，但 `Translation_BE/node_modules` 只有 `config.js/index.js/package-lock.json/PROMPT.md` 一层平铺（见目录列表），启动前先确认 `express/pg/cors` 依赖确实到位
- 启动前先查端口占用（`netstat`）+ 进程命令行，确认 8092 上跑的确实是 `index.js`，避免重复拉起后端造成 `EADDRINUSE`

## 5. 可复用的验证命令模板

```powershell
# 端口占用 + 后端进程归属
Get-NetTCPConnection -LocalPort 8092 -State Listen | Select-Object -First 1 LocalPort,OwningProcess
Get-CimInstance Win32_Process -Filter "ProcessId=<pid>" | Select-Object CommandLine

# 前端页面与关键模块编译
curl.exe -s -o NUL -w "%{http_code}" http://localhost:5173/
curl.exe -s -o NUL -w "%{http_code} %{size_download}" http://localhost:5173/src/views/cesiumView.vue

# 接口冒烟
curl.exe -s "http://127.0.0.1:8092/getLine"       # 期望 code=200 且线路数 18
curl.exe -s "http://127.0.0.1:8092/getWeather"    # 期望 code=200，上海实况
curl.exe -s "http://127.0.0.1:8092/getStationInfo?name=人民广场"
```
