---
id: "7ef18a4e-8175-45fa-a008-a62bf4b59cb4"
title: "Chisa+列车模型导出 Cesium Web 端：376 关节蒙皮不渲染与 glTF 丢姿态的排查/烘焙流程"
description: "项目 D:\\WebGIS\\web三维开发\\Cesium 中「列车正常显示、角色完全不显示」的完整诊断与修复记录：Cesium 1.97 按关节数声明 u_jointMatrices 导致 376 关节蒙皮超出 WebGL uniform 上限而静默丢弃图元；以及 Blender glTF 导出器默认按 rest pose 导出导致坐姿丢失。含「复制网格→烘焙→解除父子→导出副本」的正确静态化脚本、以现场姿态为参照的验证方法，以及循环论证式验证的教训。"
status: "active"
created_at: "2026-10-15T08:48:24.951Z"
updated_at: "2026-10-15T08:48:24.951Z"
content_hash: "9265ce375e0900bc9ca6102d478b2db389718dcc8f43062c02cba64356dc6c37"
source_paths:
  - "blender-bridge/export_static_live.py"
  - "blender-bridge/parse_glb.py"
  - "blender-bridge/dump_materials.py"
  - "blender-bridge/verify_export.py"
session_ids:
  - "6f62f16d-8806-4eed-b41a-4a99f3f3fda0"
memory_body_ids:
  []
---

# Chisa + 列车模型导出 Cesium Web 端：两个致命坑与静态化烘焙流程

对象：`D:\WebGIS\web三维开发\Cesium`（vite 项目，Cesium **1.97.0**），`src/lib/RoamTool.js:32` 用 Cesium Entity 的 `modelURL` 加载 `assets/gltf/trainAndChisa.glb`（列车 2 网格 + Chisa 角色 7 网格，角色带 376 骨骼）。日期：2026-10-15。

角色 rig 结构、命名、尺寸基准与摆姿方法见文档 `cd47800f-18e5-43e4-b6c6-fa223c7432a7`；Cesium 1.97 源码级 API 差异见 `fe543298-52a6-443f-98f1-d523ad5fe3eb`。本文只记**导出到 Web 端**的坑与流程。

## 1. 症状与第一个根因：376 关节蒙皮超 WebGL uniform 上限

**症状**：Web 端「只有列车、没有人」。

**决定性线索 / 判别特征**：列车 2 个网格**无 skin** → 正常显示；角色 7 个网格**全部带 skin** → 全部不显示。「只有列车没有人物」精确等于「只有非蒙皮网格渲染成功」。

**根因**（Cesium 1.97 源码，已逐行核对）：

```js
// node_modules/cesium/Source/Scene/Model/SkinningPipelineStage.js:47
`u_jointMatrices[${jointMatrices.length}]`        // uniform 数组长度 = 关节数
// 着色器里用法：skinnedMatrix += a_weights_N.c * u_jointMatrices[int(a_joints_N.c)];
```

本 rig **376 个关节** → `uniform mat4 u_jointMatrices[376]` → **376 × 4 = 1504 个 vec4 顶点 uniform**。WebGL2 规范只保证 256，多数集显/移动端报 1024 → 顶点着色器编译失败 → Cesium **静默丢弃**这些图元（无报错）。

这是 Sketchfab 那套 Biped 全骨架（376 根，含大量辅助骨）的通病：Blender 里看不出问题，一到 Web 就撞上限。

**已排除的干扰项**：材质不是全透明——角色 7 个材质全部 `alphaMode=OPAQUE`、`doubleSided=True`、贴图齐全；位置正确——重新导入 Blender 量世界包围盒，角色确实坐在车顶 `x≈1.09~1.47`。

## 2. 第二个坑：glTF 导出会丢弃当前姿态

**现象**：静态化文件上线后用户立刻发现「之前的坐姿全没了」——角色变成站立、双臂张开的 A/Bind 姿态。

**根因**：`export_scene.gltf` 默认 **`export_rest_position_armature=True`**，即按**骨骼静置姿态(rest)** 导出关节变换。只摆姿势、**没有关键帧/动作**时，摆好的姿态被整个丢弃。

**次要坑（同一坑的另一半）**：`parent_clear` / `modifier_apply` 之后再导出，节点名会带 `_BAKED` 后缀（纯命名，不影响渲染；要清干净需临时改名再还原）。

## 3. 教训：不能用「另一个导出文件」当验证参照（循环论证）

第一次验证时拿「静态化文件」和「原蒙皮文件」对比包围盒，看到逐网格小数点后三位完全一致就通过——**可两个文件都带着同一个错误（rest pose）**，等于拿错误证明错误，把坐姿丢失完全掩盖了，最后被用户当场发现。

**正确参照只能是「现场场景的当前姿态」**：用 depsgraph 取形变后包围盒（`evaluated_get(dg).to_mesh()`；直接读 `mesh.vertices` 得到的是静置坐标）。

坐姿与站姿的高度差是很灵敏的判别量：
- 现场坐姿 `min=[1.103,−0.354,3.331] max=[1.955,0.337,4.513] size=[0.851,0.691,1.182]` → **高 1.182**
- 错误的 rest 姿态导出 `size=[0.374,0.682,1.523]` → **高 1.523（站立）**

## 4. 正确流程：复制 → 烘焙 → 解除父子 → 只导出副本（现场骨骼不动）

脚本：`blender-bridge/export_static_live.py`（读**运行中的 Blender 现场会话**，Blender 窗口必须开着）。

```powershell
D:\Blender\blender.exe --background --python <workspace>\blender-bridge\export_static_live.py
```

步骤：

1. 复制角色 7 个网格：`obj.copy()` + `data.copy()`（副本共享 ARMATURE 修改器，会随**当前姿态**变形）。
2. 在**副本**上 `modifier_apply`（把坐姿烘进顶点）。
3. `parent_clear(type='CLEAR_KEEP_TRANSFORM')` 保住世界变换。
4. `use_selection=True`，只选「列车整棵树 + 7 个烘焙副本」导出（`export_skins=False`）。
5. 删除副本，现场恢复原样（脚本收尾打印 `CLEANED leftovers=[]`）。

**现场那套 376 骨骼 rig 与坐姿原样保留，可继续调姿势**；用户调完姿势必须**再跑一次该脚本**才会上线——现场摆姿势与导出文件是两件事，导出器不会自动带上当前姿态。

**关键校验输出**（脚本内建）：

```
BAKED_BBOX  ... size=[0.851, 0.691, 1.182]
BAKED_MATCHES_LIVE True          ← 烘焙副本与现场形变包围盒逐位相同
```

**回读导出文件的校验**：`skins 1→0`、`nodes 393→13`（后续版本 12）、9 网格 / 9 材质（含车窗 BLEND 玻璃）、无 armature 残留；`GROUP CHAR` 包围盒与现场坐姿逐位相同。文件体积 25.10 MB → 23.56 MB（体积主要是列车，收益是**兼容性**：节点数 393→12）。

## 5. 接入方式

`src/lib/RoamTool.js:32`：

```js
modelURL: 'assets/gltf/trainAndChisa_static.glb',  // 静态化版
```

项目根 `D:\WebGIS\web三维开发\Cesium` 就是 Vite 服务根，原文件既已用相对路径 `assets/gltf/...` 加载，同目录新文件自动生效，**无需改配置**；原 `trainAndChisa.glb` 保留作备份。改完需**重启 dev server + Ctrl+F5 强刷**。

（排查中的环境提示：`5173` 端口上跑的是这个 Cesium 项目，不是「智慧地铁项目\Translation」——判断页面属于哪个项目要看 5173 监听进程的命令行，别按项目名猜。）

## 6. 无浏览器诊断两件套

1. **纯 Python 解 glb**：头 12 字节（magic/version/length）+ 各 chunk 的 length/type，JSON chunk 的 `type=0x4E4F534A`；据此看 `scenes/nodes/meshes/skins/animations` 与材质 `alphaMode`。脚本 `blender-bridge/parse_glb.py`、`blender-bridge/dump_materials.py`。
2. **重新导入 Blender 量包围盒**：确认角色存在、位置尺寸正确、无蒙皮残留。脚本 `blender-bridge/verify_export.py`（早期路径 `bake_export.py`）。

## 7. 若以后需要角色动起来

静态化就没有骨骼了。替代方案：① 精简骨架（376 根辅助骨压到 100 根以内）；② 换 three.js 的骨纹理蒙皮（不受顶点 uniform 上限约束）。按「坐在地铁车顶」的静态需求，静态化是最稳选择。
