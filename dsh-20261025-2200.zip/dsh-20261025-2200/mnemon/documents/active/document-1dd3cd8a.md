---
id: "1dd3cd8a-1778-49f3-a6bd-17d76b44838e"
title: "延吉市土地覆盖分类精度评价（第五位组员）：三个上游数据缺陷的查实与修正、五组特征实验的统计结论"
description: "F:\\yaogan 遥感小组作业第五位组员环节的完整工程记录：ENVI 分类栅格地理参考丢失、Validation.shp 的 .prj 错、样点 1/2 类别互换、研究区外未掩膜四个问题的判定证据与修法；五组特征实验（A 光谱 / B +指数 / C +3×3纹理 / D 融合 / E +5×5纹理）的 OA、Kappa、McNemar 结论；脚本 01→30 可复跑链路与交付物路径。"
status: "active"
created_at: "2026-10-20T14:45:03.583Z"
updated_at: "2026-10-20T14:45:03.583Z"
content_hash: "6745392407dd4a87f8bac97d89473c480ca1aae00c6ab00568b82e5b57e99c8c"
source_paths:
  - "08_Accuracy/scripts/ylc_common.py"
  - "08_Accuracy/scripts/10_build_workset.py"
  - "08_Accuracy/scripts/11_accuracy.py"
  - "08_Accuracy/scripts/12_stats_xlsx.py"
  - "08_Accuracy/scripts/20_maps.py"
  - "08_Accuracy/scripts/30_report.py"
  - "08_Accuracy/scripts/07_label_check.py"
  - "08_Accuracy/reports/任务路线与执行记录.md"
  - "08_Accuracy/tables/精度评价结果.xlsx"
  - "09_Maps/Fig01_延吉市土地覆盖分类专题图.png"
session_ids:
  - "f737147b-005f-437b-acd3-cbe53d50ff1f"
memory_body_ids:
  []
---

# 延吉市土地覆盖分类精度评价（第五位组员环节）

日期：2026-10-20。项目根：`F:\yaogan`。产出目录：`F:\yaogan\08_Accuracy`（脚本与表）、`F:\yaogan\09_Maps`（图件）。
本环节是小组作业的"精度评价与成图"部分，输入是前四位组员的预处理成果与分类结果。

## 1. 三个致命上游数据缺陷（含判定证据，是本环节最有复用价值的部分）

### ① 分类栅格地理参考丢失（第四位组员的 ENVI 产物）
- 现象：`4\ROI\RF_A~E.dat`、`4\Stack_*.dat`、`3\` 纹理、`tif\*` 等 ENVI 文件头里 `map info` 的 tie point 被写成 `0.000, 0.000`，GDAL/ENVI 读出后 transform origin=(0,0)，栅格被放到坐标原点；但**行列数与像元大小是正确的**。
- 修法：**不要重投影**，直接按参考网格重赋 transform —— Origin `(501850, 4806390)`、像元 10 m、`EPSG:32652`（UTM 52N）。重投影会把问题放大。
- 复核证据：导出后 `crs=32652 res=(10,10) origin=(501850, 4806390)`，五组栅格 5489×6644 完全一致。

### ② `Validation.shp` 的 `.prj` 错误
- 坐标在 50 万米量级（UTM 米制），`.prj` 却声明 WGS84 地理坐标（度）。ArcMap 会按度解释，全部点整体偏移。
- 修法：重写 prj 为 UTM Zone 52N，另存 `validation_fixed.shp` / `training_fixed.shp`。

### ③ 样点 `Class_ID` 的 1 与 2 互换
- 形文件里 1 实为林地、2 实为水体，与分类栅格（1 水体 / 2 林地）相反。
- 判定证据（客观、可复现）：标 2 的 20 点 **100%** 满足 `MNDWI>0 且 B08<1500`；标 1 的 29 点 **0%** 满足。按原标签一致率仅 **49.5%**，互换 1↔2 后升至 **92.7%**。
- 处理：按互换修正，原值保留在 `Class_Orig` 字段；报告同时给出未修正对照。修正后验证集分布 `{1:20, 2:29, 3:30, 4:30}`，训练集 `{1:29, 2:29, 3:30, 4:30}`。
- 反证意义：不修正时五组 OA 全在 47.7%~49.5%，这是标签错位而非分类失败的旁证。

### ④ B~E 组研究区外像元未掩膜
- A 组研究区外已置 0，B~E 组研究区外被赋了类别值（B/C/D 多为建设用地，E 为耕地）。
- 处理：评价与成图统一用 `B02 ≠ 65535` 掩膜，五组评价范围一致。

### 对位正确性的客观锚点（可复用的一般方法）
市界多边形 UTM 面积 **1705.4 km²**，与 B02 有效像元统计面积 17,053,760 × 100 m² = **1705.4 km²** 完全一致 —— 用"矢量面积 = 有效像元面积"证明栅格与矢量对位正确，比目视判断可靠。

### 被排除、不参与评价的两个文件
- `4\YZ\JDYZ_*.dat`：ENVI 规则影像中间产物（6 波段 0/1），语义无法对应标准混淆矩阵。
- `tif\*.tif`：0/255 三波段渲染图，不是类别栅格；任务书明确"不要只交渲染图"。

## 2. 执行链路（全脚本、可全量复算，无人工抄写）

`08_Accuracy\scripts` 下按序可复跑：清点(51 个栅格) → 校验 → 诊断 → 标签核验 → 修复工作集 → 提值 → 混淆矩阵 → 五指标 → McNemar → Excel → 制图 → 报告（脚本 01→30）。

关键脚本：
- `07_label_check.py` 标签核验（光谱反证 1/2 互换）
- `ylc_common.py` 公共层：`ROOT/DATA/TAB/CLS/REF_TRANSFORM/REF_EPSG/GROUPS/class_path()`；**栅格命名改过之后必须走 `class_path(g)`**，硬编码 `Class_%s.tif` 会踩空（曾导致 11/12/20 三个脚本同时失效，已统一 patch）
- `10_build_workset.py` 导出带地理参考的 GeoTIFF + 市界转 UTM + 修 prj/标签
- `11_accuracy.py` 提值 + 混淆矩阵；`12_stats_xlsx.py` 统计与 Excel；`20_maps.py` 四张图；`30_report.py` docx 报告
- `06_render_overview.py` 真彩色/标准假彩色 + 验证点目视核查图

提值方法等价性验证：按坐标重新取样得到的光谱值 vs 第二位组员用 ArcMap 提取的形文件属性，**相关系数 1.000、均值完全相同**。

## 3. 精度结果（N = 109 验证点）

| 组 | 特征 | OA | Kappa | Macro-F1 | OA 95%CI |
|---|---|---|---|---|---|
| A | 五波段（B02/B03/B04/B08/B11） | 92.66% | 0.9014 | 0.9322 | 86.18–96.23 |
| B | A + NDVI/MNDWI/NDBI | 91.74% | 0.8889 | 0.9221 | 85.05–95.60 |
| C | A + 3×3 Contrast/Entropy/Homogeneity | 89.91% | 0.8644 | 0.9068 | 82.83–94.27 |
| D | A + 三指数 + 3×3 三纹理 | 89.91% | 0.8642 | 0.9063 | 82.83–94.27 |
| E | A + 三指数 + 5×5 三纹理 | 91.74% | 0.8890 | 0.9247 | 85.05–95.60 |

**McNemar 配对检验七组比较 p 值全部 > 0.05**（A vs D：6:3，p=0.508；D vs E：1:3，p=0.625；A vs B：3:2，p=1.000）。正确表述只能是"**在现有样本与参数下，加指数/加纹理/融合都没有统计上可检出的精度提升**"，**不能写"A 组最好"** —— 这正是任务书"不提前假定特征融合一定提高精度"的落点。

误差结构：五组共同短板是**耕地/草地 ↔ 建设用地互混**（每组 4~5 点），集中在南部城乡过渡带；水体五组全部 100%/100%。A 与 D 像元一致率 89.9%，差异仅在过渡带，整体格局未变。

面积（km²，研究区 1705.4）：A 水体 6.2 / 林地 1187.0 / 耕地草地 245.4 / 建设 266.8；E 林地 1195.7、建设 253.2 —— 组间面积差异 <5%，与"精度差异不显著"一致。

## 4. 交付物（已验证存在）

- 5 个带地理参考的类别栅格 `08_Accuracy\data\Class_A_Spectral.tif`、`Class_B_Spectral_Index.tif`、`Class_C_Spectral_Texture3.tif`、`Class_D_Fusion_Texture3.tif`、`Class_E_Fusion_Texture5.tif`（按任务书命名重命名过，旧名 `Class_A~E.tif` 已不再存在）
- `data\boundary_utm52.shp`、`data\training_fixed.shp`、`data\validation_fixed.shp`
- `tables\精度评价结果.xlsx`（11 表：00_说明、01_精度汇总、02~06 五张混淆矩阵、07_逐类指标、08_显著性检验、09_类别面积、10_验证样本清单）、`tables\metrics.json`、`tables\mcnemar.json`、`tables\validation_points_all.csv`
- `reports\延吉市土地覆盖分类_精度评价与分析报告.docx`（85 段、13 表、4 图，8 章 + 附录）
- `reports\任务路线与执行记录.md`
- `09_Maps\Fig01_延吉市土地覆盖分类专题图.png`（2880×3900，300 dpi，含标题/图例/比例尺/指北针/坐标网/数据来源/坐标系/面积与精度）、`Fig02_五组分类结果对比.png`、`Fig03_A与D分类差异.png`、`Fig04_逐类精度对比.png`

## 5. 遗留待定（交给组长/用户）

1. 1↔2 互换属对上游样本的**实质性修改**，建议第二位组员确认后再定稿。
2. 验证样本仅 109 点（每类 20~30），OA 的 CI 宽约 ±5 个百分点 —— 这是"五组差异都不显著"的根本原因；若要明确组间结论需补到每类 ≥50。
3. 题目所说"多尺度"：E 组只是 5×5 单尺度，严格是"尺度对比"而非"多尺度融合"；要保住题目需补 F 组（3×3 + 5×5 同时入模，16 特征）。

## 6. 环境坑（本项目实测）

- pandas 的 `.str` 访问器不能直接用在 `np.array(...).astype(str)` 上（`AttributeError: 'numpy.ndarray' object has no attribute 'str'`），需先转 `pd.Series`。
- 大量中文路径 + PowerShell 下用 `python -c` 传含引号的多行脚本容易报 `ParserError`（引号转义失配），改为写临时脚本文件再执行。
- 编辑脚本前若文件已被上一次运行/重写改动，edit 会报 "file changed since it was read"，需重新读取再改。
