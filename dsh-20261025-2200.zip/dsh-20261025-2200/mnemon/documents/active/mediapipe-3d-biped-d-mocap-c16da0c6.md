---
id: "c16da0c6-1c61-4678-a995-db2ed3fc734e"
title: "视频→MediaPipe 3D 姿态→Biped 骨架重定向：管线实现与噪声诊断（D:\\mocap）"
description: "D:\\mocap 上「网络视频 → MediaPipe Tasks 3D 姿态 → Biped 骨架方向匹配重定向」的已实现管线：环境与安装坑（中文路径、镜像+绕代理、1.x 无 solutions API）、实测坐标约定与数字、基座公式与自检、短线段噪声诊断（肩段 14.6cm 39 次翻转）、rig 静置姿态是屈膝坐姿导致绝对角度判据失效、Blender 桥 sys.exit 杀进程事故与 v2 修复计划。"
status: "active"
created_at: "2026-10-16T14:44:28.946Z"
updated_at: "2026-10-16T14:44:28.946Z"
content_hash: "c207955a1fc8a3ef4559cb4a0bb45d3c9de368cfd827adcf172044f14e404bc3"
source_paths:
  - "mocap/video_to_joints.py"
  - "mocap/retarget_compute.py"
session_ids:
  - "b18ccd94-95fa-4707-b7a7-39af7d74cad0"
memory_body_ids:
  []
---

# 舞蹈视频 → MediaPipe 3D 姿态 → Biped 骨架重定向：实现与诊断

2026-10-16 一轮实测的完整落地记录。上游方案论证见 `16979651-4dbf-4432-8bc0-29541f6fc50f`（可行性/分阶段），本 rig 的骨骼与坐标陷阱见 `065c7b95-72ee-4323-96c0-2a5b179e432e`。本文只记**已实现的东西 + 实测数字 + 踩过的坑**。

## 0. 结论速览

| 环节 | 状态 |
|---|---|
| 环境（MediaPipe 1.1.1 / yt-dlp / cv2 5.0.0 全在 D 盘） | ✅ |
| 视频获取 → 姿态提取 | ✅ 458/458 帧全检出，16.6 s |
| 骨架静置朝向 dump | ✅ 32 根身体骨，scale 0.01 |
| 方向匹配式重定向（20 骨 × 458 帧） | ✅ 算完并落盘，数学自检误差 3.9e-6 |
| 动作质量 | ⚠️ 手臂/锁骨疯翻、脚系统性偏 97° —— 根因已定（见 §4） |
| Blender 进程 | ❌ 被脚本里的 `sys.exit` 弄退出，用户未存盘场景丢失（见 §5） |

## 1. 环境与工具链（踩坑密集区）

- **纯 ASCII 路径是硬要求**：MediaPipe 的 C++ 层读不了含中文的路径 —— 模型文件明明存在（`os.path.exists` 通过、8.96 MB），Tasks API 仍报 `FileNotFoundError: Unable to open file at D:\Users\林先语\...`。工作区路径含中文，因此**媒体/模型/中间产物一律放 `D:\mocap`**：`media\dance.mp4`、`models\*.task`、`joints\*.json`。
- **MediaPipe 安装（国内网络）**：pip 直连 pypi 约 45 kB/s 且走 Clash 代理（`HTTP_PROXY=http://127.0.0.1:7897`）；改清华镜像后**镜像 403 Forbidden**（镜像拒绝境外出口 IP）。正解 = **清华镜像 + 绕过代理**，约 100 MB 30 秒装完（快了约 100 倍）。
- **不要再犯的误判**：pip 是**下完一个文件才写缓存**，所以「缓存 12 秒零增长」≠ 卡死。当时据此杀掉了一个正常工作的下载，白费时间。
- **API 版本**：python 3.10 + mediapipe **1.1.1 已删除 `mp.solutions`**（`mp.solutions.pose unavailable`），必须改用 Tasks API + 显式 `.task` 模型文件：`pose_landmarker_full.task`(8.96 MB) / `pose_landmarker_lite.task`(5.51 MB)；实测用 full，`backend = tasks/pose_landmarker(full)`。
- 视频来源 yt-dlp，落到 `D:\mocap\media\dance.mp4`：**2.97 MB / 15.27 s / 1920×1080 @30fps / 458 帧**；绕代理后 5.65 MiB/s。

## 2. 姿态提取（`mocap/video_to_joints.py`）

输出 `D:\mocap\joints\dance.joints.json`（785 KB）。关键实测：

- `frames_detected = 458 / 458` → `detect_rate = 1.0`，耗时 16.6 s（CPU）。
- 33 landmark，`pose_world_landmarks`，**世界坐标以胯为原点、无全局位移** → 角色只能原地跳。
- **Y 轴朝下**（shoulder_mean.y ≈ −0.43、ankle_mean.y ≈ +0.71）；**+X = 受试者左侧**（`left_hip − right_hip` 均值 +0.997X）；`hip → shoulder` 即 up；肩宽均值 0.292 m。

## 3. 重定向实现（`mocap/retarget_compute.py` → `D:\mocap\joints\chisa_keys.json`）

- 场景侧先 dump 骨架静置数据 `D:\mocap\rig_rest.json`：armature `Object_3`，**32 根身体骨**，scale 0.01；world 基座矩阵 X→(0.01,0,0) / Y→(0,0,0.01) / Z→(0,−0.01,0)。
- **方法 = 方向匹配**：把源关节线段方向映射到对应 Biped 骨方向，按父先子后（Pelvis→Spine→Spine1→Spine2→Neck→Head→Clavicle→UpperArm→Forearm→Hand→Thigh→Calf→Foot）求解局部 basis。
- 基座公式（mathutils，Quaternion 相乘结果仍是 Quaternion，**不要写 `.to_quaternion()`**）：
  ```python
  basis = rest_rot[tk].inverted() @ rest_rot[p] @ pose_rot[p].inverted() @ pose_rot[tk]
  ```
- **未映射的骨（手指/脚趾）必须完全不给目标**，留 `basis = identity` 自然跟随父骨。若给它们「绝对静置朝向」，它们会**反向补偿并抵消父骨运动**（手指出现在世界方向钉死、不听手的话）。
- 自检：`selfcheck_max_dir_err = 3.92e-06`（用 Blender 姿态公式反推方向），`det_R_sa = 1.0` → 源坐标系→骨架是真旋转、非镜像。**公式已证明正确。**
- QC 输出（落在同一个 keys 文件里）：驱动 20 根、未驱动 12 根、458 帧、`bone_channels = 20`。

## 4. 质量诊断：乱翻不是数学错，是源数据噪声

两类症状：① 锁骨/手臂逐帧跳变 197–302°（物理不可能）② 脚**恒定偏 97°**。分别定位：

**② 脚的大偏角是伪问题** —— 该 rig 的 **bind/rest 姿态不是中性站姿**：大腿朝世界 −Z，**小腿朝世界 +Y（水平）**，脚朝 −Y，是一副**屈膝坐姿**。所以「局部 basis 相对静置转了多少度」天生就大（小腿 86.7°）。**结论：绝对角度不能当判据，要看逐帧跳变。**

**① 是短线段噪声**。对源里每条线段量「方向角速度」，分界极其干净：

| 线段 | 长度 | 平均°/帧 | p95 | >90°/帧 翻转次数 |
|---|---|---|---|---|
| 躯干 hip→shoulder | 46.3 cm | 4.7 | 14.6 | **0** ✅ |
| L hip→knee / knee→ankle | 39.3 / 35.9 cm | 4.8 / 5.2 | 18.0 / 15.1 | **0** ✅ |
| ankle→toe | 15.7 cm | 6.8 | 24.1 | **0** ✅ |
| **shoulderMid→Lshoulder** | **14.6 cm** | 21.0 | **129.2** | **39** ❌ |
| **elbow→wrist** | 21.5 cm | 26.0 | 96.7 | **30** ❌ |
| **wrist→index** | **6.5 cm** | 30.7 | **109.7** | **39** ❌ |

重定向里翻得最狠的骨（锁骨 300°/帧、手 197°/帧）**正好对应这两条最短线段**（方向散布 p95 = 147.5°，等同随机）；而 36–46 cm 的腿/躯干散布只有 21–34°、0 次翻转。**媒介的毫米级抖动在 6–15 cm 尺度上就是几十度方向误差。**

## 5. 事故：Blender MCP 桥里 `sys.exit` 会杀掉整个 Blender

- `mocap/retarget_compute.py` 末尾写成 `os.sys.exit(main())`。该脚本是被插件在 `bpy.app.timers` 主线程回调里 `exec` 的，`SystemExit` 无人接管 → **整个 Blender 进程退出**：插件响应中断（桥报 `No valid JSON response within 180 s (got 0 bytes)`）、9876 断开、随后进程消失。
- **损失**：用户本次未存盘的场景没了（`quit.blend` 与 autosave 全是前一天 19:5x 的，本次没留恢复文件）；磁盘上 `D:\Blender\assets\trainAndChisa.blend`（24.55 MB，10-15 15:35 存过）仍在，**脚本对场景只有只读操作**。
- **意外收获**：`chisa_keys.json` 其实已写完（0.34 MB），只是响应被 `SystemExit` 掐死 —— 说明**算完但没回包**。
- **规则**：桥里 exec 的脚本结尾只写 `main()`，绝不能 `sys.exit`；桥本就会把异常连同 traceback 作为 JSON 回传。另：`bl.ps1 -Code/-File` 中 `sys.argv` 是 Blender 自己的命令行参数，不能拿来传参，要传就写常量或在 wrapper 里设 `sys.argv`。

## 6. v2 修复计划（针对 §4 实测根因，尚未实施）

1. **时间平滑**：对 landmarks 先做 5 帧滑动平均再算方向（治翻转主药）。
2. **驱动集 20 → 16 根**：砍掉**锁骨和手**，让其留 `basis = identity` 跟随父骨。
3. **短线保护**：线段长度 < 8 cm 时保持上一帧方向，不拿噪声算方向。
4. **换 QC 判据**：主看逐帧最大跳变，弃用绝对角度。

## 7. 待办与未决

- P3（等 Blender 恢复后）：把 keys 应用成关键帧（16 骨 × 458 帧）并**回读 fcurve 自验**；渲一张 320×320、3 帧拼图供验收（一次性，看完即弃）；导出/上网页另议 —— **376 关节蒙皮那堵墙仍在**（见 `7ef18a4e-8175-45fa-a008-a62bf4b59cb4`）。
- **未决，需用户定**：Blender 现在关着。A 直接重开磁盘版 `D:\Blender\assets\trainAndChisa.blend`（含列车+Chisa，注意不是当晚那版）/ B 用户自己开好 / C 换文件。
- 成本提示（已告知用户）：本会话上下文已很大，P3 新开会话可显著降低单轮成本，记忆与文档可无缝接续。

## 8. 落地文件

```
D:\mocap\media\dance.mp4                       2.97 MB
D:\mocap\models\pose_landmarker_full.task      8.96 MB
D:\mocap\models\pose_landmarker_lite.task      5.51 MB
D:\mocap\joints\dance.joints.json              0.75 MB (458 帧姿态)
D:\mocap\joints\chisa_keys.json                0.34 MB (20 骨 × 458 帧 + QC)
D:\mocap\rig_rest.json                         6.7 KB  (32 骨静置朝向)
```
脚本：`mocap/video_to_joints.py`（提取）、`mocap/retarget_compute.py`（重定向，只读场景）；桥：`blender-bridge/bl.ps1 -Ping|-Code|-File`（TCP 9876）。
