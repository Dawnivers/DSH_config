---
id: "05e11901-878e-4f4a-8d82-49d73afedc09"
title: "DSH Desktop 的 pwsh 执行器解析与本机 PowerShell 7.6.7 安装实录（含重启才生效的坑）"
description: "2026-10-16 实测：pwsh 工具实际执行的是本机系统 shell；源码 dsh-pwsh-local 的候选顺序（Program Files\\PowerShell\\7 → PATH 里的 pwsh.exe → 兜底 System32 的 powershell.exe）、lstat 识别 MSIX 别名、构造时解析并缓存导致「装完不重启不切换」；用 winget 免管理员装 PowerShell 7.6.7.0 的路径与回滚，以及仍需按 PS5.1 处理中文编码/嵌套引号的插件清单。"
status: "active"
created_at: "2026-10-16T11:06:49.715Z"
updated_at: "2026-10-16T11:06:49.715Z"
content_hash: "dd21aabb9509bbcef576a879f71feaf58514a72d001c85fe38aa19253fdad39a"
source_paths:
  - "node_modules/@deepseek-ai/dsh-pwsh-local/lib/index.js"
session_ids:
  - "8969c15f-9cae-4bb3-99a0-b0d80d96befc"
memory_body_ids:
  []
---

# DSH Desktop 的 pwsh 执行器解析与 PowerShell 7.6.7 安装实录

日期：2026-10-16 · 环境：Windows，DSH Desktop（`D:\DSH\dsh_data\DSH Desktop`）· 权限：danger-full-access，无管理员

## 1. 结论速览

- DSH 的 `pwsh` 工具**没有自带 shell**，执行的是**本机** powershell 可执行文件；父进程是 `DSH Desktop.exe`。
- 2026-10-16 安装前：本机只有系统自带 **Windows PowerShell 5.1.26100.9711**（PSEdition=Desktop，ANSI 代码页 936/GBK），机器上**没有** PowerShell 7（PATH 无 `pwsh`，`C:\Program Files\PowerShell` 不存在，DSH 资源目录内也无 `pwsh.exe`）。
- 2026-10-16 已用 winget 装上 **PowerShell 7.6.7.0**；但**当前宿主进程仍然跑 5.1**，需要重启 DSH Desktop 才切换。

## 2. 执行器解析顺序（源码依据）

源码：`node_modules/@deepseek-ai/dsh-pwsh-local/lib/index.js`

- `candidatePwshPaths(env)`（L23-L34）按顺序返回候选：
  1. `%ProgramFiles%\PowerShell\7\pwsh.exe`
  2. 遍历 `PATH` 每个目录拼 `pwsh.exe`
  3. 兜底 `%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe`
- `resolvePwshPath(configured, env, platform)`（L59-L65）：配置里显式给了 `pwshPath` 就原样信任；win32 下返回**第一个存在的候选**，都不存在才返回 `"pwsh"` 交给 PATH 解析。
- `candidateExists`（L42-L49）用 `lstatSync`，`isFile() || isSymbolicLink()` 都算存在——源码注释明确说明这是为了认得出 Store/MSIX 的 app execution alias（`stat` 会被 ACL 挡成 EACCES）。**即 MSIX 安装路径是 DSH 明确支持的，不是硬凑。**
- 命令形态：`pwsh -NoLogo -NoProfile -NonInteractive -Command <command>`，跑在 `ctx.subprocess` 管理的进程里。

## 3. 关键坑：解析结果在构造时缓存一次

同一文件 L149-L167：`constructor` 里 `this.resolvedPwshPath = resolvePwshPath(this.declaredPwshPath)`，而 `get pwshPath()` 只在 `config.pwshPath` 发生变化时才重新解析，否则永远返回缓存值。

实测后果：**装完 PowerShell 7 的当下，工具命令仍报告 5.1.26100.9711**。→ 装卸 PowerShell 7 之后**必须重启 DSH Desktop**（刷新页面不够）；若仍不生效，可在 profile 的 `cordis.patch.yml` 里显式钉住 `pwshPath`。

## 4. 安装实录（PowerShell 7.6.7.0）

```powershell
winget install --id Microsoft.PowerShell -e --source winget
```

- winget v1.29.380（`%LOCALAPPDATA%\Microsoft\WindowsApps\winget.exe`）；机器上**没有 choco/scoop**；有 `dotnet` 6.0.33 / 8.0.0 运行时但**没有 .NET SDK**（`dotnet --version` 会报错）。
- 安装器类型 **msixbundle（按用户安装）→ 免管理员、不弹 UAC**；返回 exit 0「已成功安装」。
- 落点：包 `Microsoft.PowerShell` 7.6.7.0 x64 → `C:\Program Files\WindowsApps\Microsoft.PowerShell_7.6.7.0_x64__8wekyb3d8bbwe`；入口是 app execution alias `%LOCALAPPDATA%\Microsoft\WindowsApps\pwsh.exe`。
- **PATH 不用改**：`%LOCALAPPDATA%\Microsoft\WindowsApps` 本就在用户 PATH 上（解析因此命中候选 2，候选 1 的 `Program Files\PowerShell\7` 并不存在）。
- 实跑验证：`pwsh` → **7.6.7**，默认输出编码 **utf-8**，exit 0。
- 回滚：`winget uninstall Microsoft.PowerShell`，或在「设置 → 应用」里卸载。

## 5. 切换到 PS7 后仍按 5.1 处理的地方

插件里**硬编码 `powershell.exe`** 的调用不受 PATH 影响，行为不变：`dsh-native-command`、`dsh-host-open-in-app`、`dsh-api-workspace-controller`（`lib/index.js` / `lib/types/*.js` 里直接 spawn `powershell.exe`）。

因此在仍是 5.1 的场合：

- `Get-Content -Raw | ConvertFrom-Json` 读**含中文的 UTF-8 文件**会按 GBK 误解码，报「传入的对象无效」（`。`=E3 80 82 与紧随的 `"`=22 在 GBK 里凑成合法双字节，吞掉结尾引号）；对策：显式 `-Encoding UTF8`，读文本一律优先用 read 工具。
- 命令里塞含**嵌套引号**的正则/字符串会直接 ParserError「字符串缺少终止符: '」，命令一个字符都不执行。
- PS5.1 缺 `&&`、三元、`??`、`Test-Json`、`Join-String`；`Invoke-WebRequest` 需带 `-UseBasicParsing`。

## 6. 关联文档

- `98bbab1e-d1f4-48c5-bac6-0db6a81271a7`（verify-shell-patch.ps1）——其中「本机只有 5.1、没有 pwsh 7」的机位前提**已被本文的安装结果更新**，其余 PS5.1 硬约束（UTF-8 BOM、`-ExecutionPolicy Bypass -File`、`$PSScriptRoot`）仍然有效。
