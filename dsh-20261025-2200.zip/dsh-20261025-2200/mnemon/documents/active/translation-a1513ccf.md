---
id: "a1513ccf-8374-4c20-9a66-3ecb52505879"
title: "Translation 发展历程：生长动画新线上的「流线在跑」溯源诊断（材质内建流线 + 生长期被长度扭曲）与三种处置选项"
description: "2026-10-12 诊断用户疑问「点击线路时道路流线特效仍在显示」：实测确认 18 条全局线路全部 show:false、唯一可见者是动画私有实体；结论是流线来自 PolylineFlowMaterialProperty 材质本身而非残留实体；并说明生长期 st.s 是当前折线弧长导致亮带被长度扭曲；含 renderLines 关流线的参数方案与 width 写死 3 的约束。"
status: "active"
created_at: "2026-10-12T10:34:10.059Z"
updated_at: "2026-10-12T10:34:10.059Z"
content_hash: "2d967c2564608a11697fff487f5056432f7cc6a940f493d16651a95a3f0f4496"
source_paths:
  - "Translation/src/components/bottom/HistoryPanel/historyPanel.vue"
  - "Translation/src/cesiumTools/lineAndpoints/line/setlines.js"
  - "Translation/src/cesiumTools/lineAndpoints/line/PolylineFlowMaterialProperty.js"
  - "Translation/src/cesiumTools/lineAndpoints/line/polyGlowflow.glsl"
  - "Translation/src/stores/stationState.js"
session_ids:
  - "bacf900a-1772-4640-99d8-04cbfa95b3f8"
memory_body_ids:
  []
---

# 生长动画新线上为什么还有「跑动的流线」

日期：2026-10-12。项目：`D:\WebGIS\web三维开发\智慧地铁项目\Translation`。
起点是用户原话：「注意到点击地铁线路时，原先的道路流线特效仍然存在，怎么回事？它们不是相互独立的两条实体线吗？为什么会显示」

生长动画本体（区间插值 + `CallbackProperty`、端点夹首尾、三个在验证中抓到并修掉的 bug）见文档
`bed0b7b7-e1e3-491b-80bd-51ffa66f4956`；「已开通区间 `[lo,hi]`」模型与其前提事实见文档 `507aed4a-c907-4012-b6ae-69aadb2f8edb`。

## 1. 结论：那不是残留的老线，就是正在看的新线

先排除「旧的还在」这个假设 —— 两种进入方式各量一遍（真机，非肉眼）：

| 场景 | 线路实体总数 | 实际 `show:true` 的 | 站点光锥(400) | 站点底圈(400) |
|---|---|---|---|---|
| 首页 | 18 | **18** | 全 `show:false` | 全 `show:false` |
| 发展历程 | **19**（18 全局 + 1 私有） | **1** | 全 `show:false` | 全 `show:false` |

进入发展历程后 18 条全局线路**逐条** `show:false`，唯一可见者是：

```json
{ "name": "上海地铁1号线", "show": true, "dynamic": true,
  "ctor": "CallbackProperty", "mat": "PolylineFlowMaterialProperty", "n": 160 }
```

`dynamic:true` 且 `n` 在变（160 → 196）—— 就是生长动画的私有实体。
点线切换后再次采样，结论不变。旧线一条都没漏网，所以用户看到的是**新线自己的流线**。

## 2. 根因：流线不是外挂特效，是建线函数写死的材质

```js
// setlines.js:62 —— 材质在 renderLines() 里直接构造，没有开关
material: new PolylineFlowMaterialProperty(materialColor, glowPower, taperPower,
                                           flowSpeed, flowLength, flowIntensity, flowOffset),
```

流线是材质的一部分（`polyGlowflow.glsl:37-45`）：

```glsl
float iTime = czm_frameNumber / 300. * flowSpeed + flowOffset;
if (st.s > iTime && st.s < iTime + flowLength) {
    material.emission *= flowIntensity;   // 那一段亮起来、alpha 拉满
}
```

所以 **只要用 `renderLines()` 建线就必然带这条跑动亮带**。新线是老线的视觉克隆，两者看起来一模一样 ——
这就是「原先的还在」这个误判的直接来源。这条也回答了一个更容易复发的疑问：
私有实体不是「一条不带特效的新线」，而是**同材质同外观的另一条线**。

## 3. 生长期间它还被长度扭曲（这才是真正会看出不对的地方）

`st.s` 是**当前渲染出来的那条折线**上的归一化弧长（0 起点、1 终点），**不是整条线的弧长**。
于是亮带的世界坐标 ≈ `iTime × 当前长度`：

- 平时（整条线）：亮带匀速从起点跑到终点；
- 生长中：长度从 2 个站涨到 28 个站，同一个 `iTime` 对应的实际位置被放大约十几倍 ——
  亮带看着往前**窜**，线越短窜得越明显。

即：不只是「流线还在」，它在动画期间的行为本身就是被生长扭曲的。

## 4. 三种处置方案（当时抛给用户，未落地）

- **A（推荐）关掉流线，只留生长**。`renderLines` 参数从 `options` 读，传两个值即可：
  `renderLines(viewer, { positions, color, name, flowIntensity: 0, flowLength: 0 })`。
  线仍是带泛光的线（`glowPower` 保留），但不再有跑动亮带；唯一可见的动就是生长，
  也不会被长度扭曲 —— 与「不闪光」的既有取向一致。
- **B** 保持现状，与全站其它线路视觉一致。
- **C** 让它明显不同（换色 / 改粗细）。粗细需先给 `renderLines` 加 `width` 选项，目前**写死 3**。

## 5. 顺带确认的边界事实

- `setlines.js:16` 有 `positions.length < 4` 守卫，所以**不能拿 2 个点去建线**；动画必须
  「先建实体、再替换 `positions`」（替换成 `CallbackProperty`）。
- 站点光锥 / 底圈（共 400 个 `Primitive`）在首页与发展历程下**均为隐藏**，与线路无关，
  排查线路问题时不必怀疑它们。
