---
id: "cae9f685-f116-4336-b935-5efccac23ac0"
title: "智慧地铁上线版：开屏加载复刻到工作区 + initialTilesLoaded 一次性语义与「超时放行」决策"
description: "把本地 Translation 的开屏加载（SciFiLoader + loadingState + 三资源校验）复刻进上线版工作区 Project，含三处适配（tileset 可能为 null、列车 8.62MB、LOD 保留）、构建产物指纹与部署命令；并记录 Cesium3DTileset.js:2855 的 _initialTilesLoaded 只触发一次这一源码依据、三层兜底的必要性、「放行≠停止加载」，以及用户尚未拍板的 A/B/C 三种严格等待方案与轮询改进建议。"
status: "active"
created_at: "2026-10-21T12:37:53.295Z"
updated_at: "2026-10-21T12:37:53.295Z"
content_hash: "3e8e63ba1a33ba45c3dba7d7d99f11d6d05f14fc797b533905c0fb877fdad6fd"
source_paths:
  - "src/views/cesiumView.vue"
  - "src/stores/loadingState.js"
  - "src/components/loading/SciFiLoader.vue"
  - "src/App.vue"
  - "index.html"
session_ids:
  - "20776400-e31a-4cfb-885b-154f8fc33925"
memory_body_ids:
  []
---

# 上线版工作区：开屏加载复刻 + 为何要「超时放行」（2026-10-21）

对象：上线版工作区 `D:\WebGIS\web三维开发\智慧地铁_上线版\Project`（部署目标 `https://project2.dawnivers.top/`，服务器出口约 3 Mbps）。
来源：本地实验项目 `D:\WebGIS\web三维开发\智慧地铁项目\Translation` 上先做好的开屏加载（见 `8a2ce03b-0dd7-4b4c-9492-354d34a889f2` 动画本体、`55afe1e9-54f3-43e2-83f1-9f367614bad6` 逐资源校验与加权进度）。本文只记「搬到上线版工作区」这一步与随后的语义澄清，不重复两文已有细节。

触发：用户先问「有做各 3dtiles 和列车模型加载的检验吗」（促成本地版三项校验），随后说「在工作区复刻」；复刻完成后又追问「为什么会有超时放行？」。

## 1. 工作区改了哪些文件

| 文件 | 改动 |
|---|---|
| `src/components/loading/SciFiLoader.vue` | 新增（与本地版逐字节一致） |
| `src/stores/loadingState.js` | 新增（三项资源状态机 + 加权进度） |
| `src/App.vue` | 挂载 `<SciFiLoader />`，与 `.scene-layer` / `Panel` 并列 |
| `src/views/cesiumView.vue` | 接入 `trackTileset()` ×2 + `preloadTrainModel()` + `setBase` 节点 |
| `index.html` | 加静态 `boot-splash` 底，消掉 JS 下载前的白闪 |

## 2. 工作区独有的三处适配（直接抄会出问题）

1. **tileset 可能是 `null`**：工作区的 `loadTilesets` 带 fallback，失败项返回 `null` 而不抛错，并且下游都做了 `if (x)` 保护。因此 `trackTileset(key, null)` 必须显式标红「未加载」，否则会静默卡住。
2. **列车模型已瘦身为 8.62MB**（`trainAndChisa_static-*.glb`）：预载逻辑不变，但字节进度从 `0 / 8.6 MB` 起步，比本地版 23.5MB 快得多；压缩缘由见 `9c15ce40-c2f9-4c44-afe6-ede26e6cb8d3`。
3. **LOD 逻辑原样保留**：`tileset-L*`、`maximumScreenSpaceError`、`?lod=` 与 `VITE_TILE_LOD` 不受影响（见 `cf0fbafd-3d5e-4f89-b00b-0db4e02bcf70`）。

## 3. 构建与产物指纹

- `vite build` 通过（2.34s，无报错）；`compress-dist` 175 文件 8.05MB → gzip 2.64MB (33%) / brotli 2.10MB (26%)。
- 入口 `dist/index.html → index-heqFi9JB.js`，522,336 B；`dist` 文件总数 1142；比上一版多约 6KB（加载动画代码）。
- 产物内串校验通过：`智慧地铁`、`SYS.BOOT`、`TILES`、`initialTilesLoaded`、`已缓存`、`tileset-L`、`boot-assets`、`progressiveResolution`。
- 列车资源：`dist/assets/trainAndChisa_static-Wyqy541i.glb` = 8.62MB。
- 部署：`scp -r dist/* root@101.43.119.248:/www/wwwroot/Translation/Project/dist/`。
- 本地 dev 侧同样以 Vite 转换接口验编译：`/src/views/cesiumView.vue`、`/src/components/loading/SciFiLoader.vue`、`/src/stores/loadingState.js`、`/` 全 200。

## 4. 待定取舍：PRELOAD_TRAIN

`src/views/cesiumView.vue` 顶部 `const PRELOAD_TRAIN = true;`，复刻时与本地保持一致（true）。

- `true`：开屏全量预载，3 Mbps 出口下约 **+25s**，且会与城市瓦片抢带宽；换来「实时轨迹」秒开。
- `false`：该行显示「按需加载」，开屏更快，首次进实时轨迹再等（8.6MB 尚可接受）。

建议：局域网/展厅保持 `true`，纯线上带宽受限时改 `false` 重新 build。

## 5. 为什么必须留「超时放行」——源码依据

`initialTilesLoaded` 在 Cesium 里是**一次性事件**，不是「加载完了就通知」。`Cesium3DTileset.js` 中（约 2855 行）：

```js
if (!tileset._initialTilesLoaded) {
  tileset._initialTilesLoaded = true;
  tileset.initialTilesLoaded.raiseEvent(tileset);   // 仅此一次
}
```

错过就永远等不到，因此没有兜底会让用户**永久卡在开屏页**。会错过的情形：

- 浏览器缓存命中、秒开：事件在 `addEventListener` 挂上之前已发过；
- 相机在飞（`flyToHome` ~1.2s）或用户拖拽：视锥一变就要补瓦片，`tilesLoaded` 回落，首屏完成被推迟；
- 某块瓦片 404 / 卡住重试：`tilesLoaded` 永不为 true；
- 模型体量大 + 出口 3 Mbps：L14 全量 2.22GB，「真正加载完」可达十几分钟。

现有三层兜底（每项 tileset 独立）：

```js
target.initialTilesLoaded.addEventListener(done);              // ① 正常路径
setTimeout(() => { if (target.tilesLoaded) done(); }, 1200);   // ② 缓存秒开补判
setTimeout(() => done('超时放行'), 20000);                     // ③ 异常兜底
```

另在 `SciFiLoader.vue` 有一道 40s 看门狗，覆盖 `onMounted` 抛错等连 ③ 都没跑起来的情况。

## 6. 关键澄清：「放行」≠「停止加载」

超时放行只撤遮罩，Cesium 后台继续请求瓦片、继续细化。所以 20s 不是「放弃」，而是「最多让用户盯 20s，之后边看边流式加载」。代价：**进度条到 100% 不代表模型全在内存**，只代表首屏够看。

## 7. 用户尚未拍板的三种「严格等待」改法

- **A. 删掉 20s 超时**：最严格，但上表任一情形即永久卡死，只能刷新，展厅不建议。
- **B. 上限拉长到 60/120s**：简单，最坏情况是干等一两分钟黑屏。
- **C. 超时后改为「仍在加载，点击进入」**：文案换成「城市模型仍在加载（已 37 块瓦片）+ [点击进入]」，想看的人立刻进、想等的人继续等，不卡死。store 加 `canEnter` + 一个按钮，约 10 行。
- 附带改进：② 的「1.2s 单次检查」改为**每 300ms 轮询直至命中或到 20s**，避免检查瞬间恰好有瓦片在飞而漏判。

助手建议 **C + 轮询**；用户未回复，故两份代码均未改动。若要实施，本地 Translation 与上线版工作区需同时同步。
