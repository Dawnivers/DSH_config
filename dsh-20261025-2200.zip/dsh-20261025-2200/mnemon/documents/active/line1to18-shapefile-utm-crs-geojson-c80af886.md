---
id: "c80af886-b5d3-4d9b-94b2-473cab3df58a"
title: "line1to18 地铁线路 shapefile：缺失配套文件恢复 + 自定义 UTM 变体 CRS 反解与 GeoJSON 导出"
description: "单个无 .shx/.dbf/.prj 的 shapefile 如何用 SHAPE_RESTORE_SHX 读出、借项目已有 JSON 逐顶点反解出上海本地化 UTM 变体投影（lon_0=121.43480174…、k=0.9996、假东 500000、GRS80，无 EPSG 码）、导出并验证 0.000 m 偏差的 GeoJSON，附 geo conda 环境（GDAL 201 个 exe、73/54 驱动、缺包清单、PROJ_DATA/IDE 激活要点）。"
status: "active"
created_at: "2026-10-10T03:17:16.933Z"
updated_at: "2026-10-10T03:17:16.933Z"
content_hash: "3348c5cda91d396501435171d4737e8f49e3ec7734d1a05c77a79e14eb0046e2"
source_paths:
  - "line1to18-export/export-geojson.py"
  - "line1to18-export/solve-crs.py"
  - "line1to18-export/match-vertices.py"
  - "line1to18-export/CRS_README.txt"
session_ids:
  - "5f8953de-46e5-480c-8f2f-e4689df906b8"
memory_body_ids:
  []
---

# line1to18 上海地铁线路 shapefile：CRS 反解与 GeoJSON 导出

日期：2026-10-10 前后。工作目录：`D:\Users\林先语\Documents\deepseek-harness\default-workspace\line1to18-export\`。

## 1. 输入的问题

用户给的附件目录里**只有 `line1to18_UTM.shp`（122436 字节）一个文件**，`.shx / .dbf / .prj / .cpg` 全部缺失；全盘常见位置（attachments、Downloads、Desktop、Documents、`D:\WebGIS`）也没有完整文件集。需求：导出成 GeoJSON。

相关参照数据（本项目已有的、坐标已知正确的 GeoJSON）：

- `D:\WebGIS\web三维开发\Cesium\assets\line1to18_2.json`（18 个 LineString）
- `D:\WebGIS\web三维开发\智慧地铁项目\Translation\src\assets\line1to18_2.json`（内容相同）
- 同目录的 `line1to18.json` 是 **0 个要素的空壳**，不要当参照

## 2. 缺配套文件时的读法（可复用技巧）

- 缺 `.shx`：GDAL 报 `ERROR 4: Unable to open ... .shx ... Set SHAPE_RESTORE_SHX config option to YES to restore or create it.`
  → 设环境变量 **`SHAPE_RESTORE_SHX=YES`** 即可直接打开并自动重建 `.shx`（本次生成 244 字节）。
- 缺 `.dbf`：仍可读几何，但**要素完全没有属性字段**（`fields: ['geometry']`），无法从 shp 恢复线路名/长度。
- 缺 `.prj`：`Layer SRS WKT: (unknown)`，坐标只是一堆无意义的米数，必须另行确定坐标系。
- 始终只操作工作副本，未改动用户原始 `.shp`。

读出结果：Layer `line1to18_UTM`，**LineString / 18 个要素**，范围 X 454641.184–546966.491、Y 3419605.837–3475145.626（约 92.3 × 55.5 km，Y 对应约 31.16°N）。

## 3. CRS 反解（核心结论）

**这不是任何标准分带投影。** 按 `EPSG:32651`（WGS84 / UTM 51N，CM 123°E）解算，数据会落到上海以东约 150 km 的海里。逐条试算 UTM 48–51N 与 CGCS2000 3°/6° 高斯分带，经度差 1.4–1.6°，纬度吻合而经度对不上 → 中央子午线非标准。

反解方法（关键：顶点级 1:1 配对，不能用顶点数聚类）：

1. 逐要素数顶点：shp 与 `line1to18_2.json` 完全相同（480, 400, 404, 418, 516, 439, 337, 565, 234, 309, 816, 450, 387, 439, 427, 233, 389, 340）→ 确认同一份数据、18 条线按顺序 1:1 对应。
2. 若按"顶点数相同就配对"，第 5 与第 13 条会误配，仿射拟合残差被撑到 max 0.276°（≈30649 m）。**必须按索引严格 1:1。**
3. 严格配对后 7583 个顶点做最小二乘：
   - 仅仿射：残差 max 0.001192°（132 m）/ mean 9.27 m —— 尺度近似但不足以定死。
   - 高斯-克吕格 k=1 强制：lon_0 ≈ 121.4543、rms 978 m —— 仍不精确。
   - **放开尺度 k 后得到精确解，残差 0.00000000°（0.000 m）**。

最终反解参数（写成 `.prj` 的 `Shanghai_Local_UTM_CM121.4348_GRS80`）：

```
投影    : Transverse_Mercator
lon_0   = 121.43480380°E    ← 自定义中央子午线，非标准分带
k       = 0.999600000       ← UTM 标志性比例因子
x_0     = 500000.000 m      ← UTM 标准假东
y_0     = 0.000 m
椭球    = GRS80 (CGCS2000/WGS84)
EPSG    : 无对应码，必须自定义 CRS
```

`k=0.9996` + 假东 500000 是 UTM 招牌常数，但 CM 121.4348°E 只服务上海，属**本地化 UTM 变体**。别人复用时**必须带 `.prj`**，否则整体偏移约 150 km。

## 4. 交付物与验证

目录 `line1to18-export\`：

| 文件 | 说明 |
|---|---|
| `line1to18.geojson`（308 KB） | 纯几何，EPSG:4326，18 个 LineString |
| `line1to18_attributed.geojson`（310 KB） | 附 `name` / `basicPrice` / `length`（属性取自项目 JSON，按几何完全相等做顺序 1:1 匹配） |
| `line1to18_UTM.shp / .shx / .prj` | 重建后的完整 shapefile（仍为投影坐标，**无属性表**） |
| `CRS_README.txt` | 缺口说明 + 反解过程 + 校验结果 |
| `export-geojson.py` / `infer-crs.py` / `solve-crs.py` / `match-vertices.py` / `inspect-jsons.py` / `polish.py` | 可复现脚本 |

验证：重投影后与项目数据**逐顶点比对，18 条线最大偏差全部 0.00000000 度 = 0.000 m**；范围 lon 120.959316–121.926305 / lat 30.908869–31.410934（上海主城区），匹配线路为 1–18 号线（13、12、15、14、9、18、1、3、5、17、11、16、7、10、2、6、4、8）。

注意事项：属性表不可恢复，ArcGIS 打开会看到空属性表；不要用标准 UTM 51N 套用。

## 5. 本机 geo conda 环境能力（`D:\conda-envs\geo`）

实测（2026-10 前后）：geopandas 1.2.0、GDAL 3.13.3、PROJ 可用。

- **驱动**：矢量 73 个（含 GeoJSON / GPKG / ESRI Shapefile / FlatGeobuf / SQLite），栅格 54 个。
- **命令行**：`Library\bin` 下有 **201 个 exe**，含 `gdalwarp` `gdal_translate` `gdal_rasterize` `gdalbuildvrt` `gdalinfo` `gdalsrsinfo` `gdaltransform` `gdal_contour` 等，外加 `projinfo` `cs2cs` `sqlite3`；`Scripts\rio.EXE` 可用。
- **已装**：folium、mapclassify。
- **缺失**：psycopg2 / psycopg / sqlalchemy / osgeo / pyarrow / pystac / stackstac / ee / laspy / pdal / torch / torchgeo / geemap / contextily / osmnx / rio_tiler / whitebox。
- **GDAL 无 PostgreSQL 驱动**（只有无关的 PGeo）→ 直连 PostGIS 需补 `psycopg2 + sqlalchemy` 或 `libpq`。
- `gdal2tiles` / `gdal_merge` / `gdal_polygonize` / `gdal_calc` / `gdal_proximity` **不在**（它们是 GDAL 的 Python 工具）→ 补 `gdal` 包；部分可用 `gdalwarp` + `rio` 组合替代。

### 激活与调用要点（含坑）

- 开始菜单用 **`Anaconda PowerShell Prompt (geo)`**；老式 cmd 的 `Anaconda Prompt` 在本机 conda 25.11 上是坏的（本目录下的两个 cmd 版入口已因不可用被移除，另建了 PowerShell 版）。
- 命令行：`D:\newanaconda\Scripts\conda.exe run -n geo --no-capture-output python your_script.py`。
- **坑**：`conda run ... python -c '...'` 在 PowerShell 下引号被吞，报 `NativeCommandError` / `SyntaxError: '(' was never closed` → 改为把代码写成 `.py` 文件执行。
- IDE 直连：解释器选 `D:\conda-envs\geo\python.exe`。**只需设 `PROJ_DATA=D:\conda-envs\geo\Library\share\proj`**（另可设 `GDAL_DATA=D:\conda-envs\geo\Library\share\gdal`）。这样可绕开机器的旧 `PROJ_LIB` 污染（本机曾残留 PostGIS 的 `D:\PostgreSQL18.4\data\18\share\contrib\postgis-3.6\proj`）。已实测通过：CRS 正确识别为 WGS 84。
