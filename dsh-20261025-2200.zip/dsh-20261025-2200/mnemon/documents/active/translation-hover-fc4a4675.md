---
id: "fc4a4675-20f3-47bd-9576-90465837c1b9"
title: "智慧地铁 Translation：底栏齿轮悬浮工具箱与线路图层面板（hover 交互实现交接）"
description: "foot.vue 齿轮按钮「划过即出」的竖向工具箱与线路图层面板：Teleport 到 1920×1080 设计画布的架构原因、hover 开合状态机与延迟常量、能开不能收的 bug 根因、Playwright 真实鼠标轨迹验证结果，以及两个占位工具的后续接口。"
status: "active"
created_at: "2026-10-07T12:53:28.876Z"
updated_at: "2026-10-07T12:53:28.876Z"
content_hash: "f32c11b37832659b58ea3349a6df6da7f8701aa71c173cc6e8dce1b7d0c2ec54"
source_paths:
  - "Translation/src/components/screenUI/foot.vue"
  - "Translation/vite.config.js"
  - "Translation/src/api/request.js"
session_ids:
  - "6289f177-b847-4d2a-bc05-65c3dd5d0702"
memory_body_ids:
  []
---

# 智慧地铁 Translation：底栏齿轮悬浮工具箱与线路图层面板

实现日期：2026-10-07。需求演进：先在底栏齿轮上做「点击浮出工具箱 + 线路图层面板」，随后用户要求**改为鼠标 hover 触发**，再之后报「能开不能收」并修复。最终 hover 交互已在用户自有 Chrome 标签页复核通过。

相关文档：`d6dc91dd-bff2-4971-897a-5b2fe5bf1580`（Translation 项目启动与接口联调，含 `getLine` 后端语义）、`46077717-b034-4315-a3c1-f04be09fed52`（cesiumView KeepAlive 改造）。

## 1. 涉及文件

| 文件 | 改动 |
|---|---|
| `Translation/src/components/screenUI/foot.vue` | 齿轮 `ref` / 激活态；工具定义 `GEAR_TOOLS`；线路数据加载；弹层定位；hover 开合状态机；模板新增两个 `Teleport` 弹层；样式 +300 行 |
| `Translation/vite.config.js` | `server.watch.ignored` 排除 `.*.tmpdir/*.tmp`（见第 5 节） |
| `Translation/src/api/request.js` | 数据来源，无需改动：复用其中 `getLine()` |

## 2. 非显然的架构决策（为什么必须这么做）

1. **两个弹层 Teleport 到 `.hud-canvas`（1920×1080 设计画布），并加 `defer`。**
   `.foot-page` 带 `overflow: hidden`，弹层若内嵌其中会被直接裁掉、根本不可见；挂到画布上既不被裁，又能随 HUD 的 `transform` 一起等比缩放。
2. **弹层坐标要用齿轮的实际 rect 反算回设计画布坐标**，窗口尺寸变化时需重算；因为画布本身有缩放，直接用 client 坐标会错位。
3. **弹层脱离 `.foot-page` 后不再继承设计令牌**（颜色/尺寸变量），必须在弹层自身的样式里重新声明，否则样式全丢。

## 3. hover 开合状态机

关键函数：`openGear` / `scheduleClose` / `cancelClose` / `onGearLeave` / `onToolEnter` / `onToolLeave`（附定时器清理）。

| 行为 | 说明 |
|---|---|
| 划过齿轮 | 浮出竖向工具箱（3 个图标，错峰弹出动画）；**点击仍保留**作为触屏/键盘兜底，非主路径 |
| 划过图标 | 停留 `TOOL_OPEN_DELAY = 120ms` 防抖后展开对应栏目；不加防抖，鼠标从齿轮快速扫到最上图标会一路误开 |
| 划过 `ready: false` 的占位图标 | 直接 return，**不顶掉**已打开的栏目，避免鼠标扫过时面板乱跳 |
| 移开齿轮/工具栏/线路栏 | 延迟 `HOVER_CLOSE_DELAY = 220ms` 收起；齿轮与工具栏之间有间隙，立即关闭会在半路闪掉 |
| 进入上述任一区域 | `cancelClose()` 取消关闭定时器，保持展开 |
| Esc / 点击空白处 | 立即收起 |

两个时间常量位于 foot.vue 齿轮段落开头，用户可直接调手感（改 0 = 立即收，改 400 = 多留 0.4s）。

## 4. 面板内容与数据

- 线路图层栏：金色切角面板 + 标题 + 「全选」+ 18 条线路色块图例 + 底部「共 18 条 · 暂未联动三维图层」。
- 每条含彩色小方块（选中发光）+ 线号简化（`上海地铁1号线` → `1号线`），悬停显示 `上海地铁1号线 · 37.7km · 28 站`。
- 数据用 `getLine()` **懒加载**：首次展开面板时才请求，不拖慢首屏。
- `LINE_COLORS` 目前是按参考图自配的 12 色循环，可整体替换为官方线路色。
- **勾选态仅本地**，尚未与地图联动。

## 5. 踩过的坑

1. **「能开不能收」的根因（用户报的 bug）**：齿轮只挂了 `@mouseenter="openGear"`，其原有 `@mouseleave="pressUp"` 未改（`pressUp` 只管按钮按下的微动效）——于是「划过齿轮 → 直接移开、没进工具栏」这条路径*没有任何代码安排关闭*，面板永久挂住。修复：新增 `onGearLeave = () => { pressUp(); scheduleClose(); }`。
   教训：hover 展开/移开收起的浮层，**关闭逻辑必须挂在所有触发元素上，包括"打开它的那个元素"**。
2. **自动化测试反而放过了该 bug**：原脚本每步都从齿轮移进工具栏/线路栏，恰好都走到了会触发关闭的路径。回归用例必须覆盖：沿底栏直接移开、直接移进三维场景、穿过间隙进工具栏（120ms 内不闪退）、从工具栏上方移出。
3. **Playwright 合成鼠标事件的假失败**：`page.mouse.move(x, y)` 不带 `{ steps: N }` 是"瞬移"，单次跳变不产生 `mouseout`/`mouseleave` 边界事件，会得到"收起没生效"的错误结论。测量 hover 行为时必须带真实轨迹（本项目用 `steps: 8`）。
4. **Vite dev server 会被编辑工具的原子写搞崩**：日志 `Error: EBUSY: resource busy or locked, watch '...\.foot.vue.<uuid>.tmpdir\foot.vue.tmp'`——编辑工具以「临时目录 + 原子替换」落盘，watcher 去监听马上要删的临时文件时被锁 → 未捕获错误 → 进程退出（实测崩过一次）。修复：`vite.config.js` 加 `server.watch.ignored` 排除 `.*.tmpdir/*.tmp`；用户自己编辑器的"原子保存"同样免疫。

## 6. 验证证据

- Playwright 驱动真实鼠标轨迹（全部 `steps: 8`），8 条路径全绿：划过齿轮展开、沿底栏移开收起、直接移进场景收起、穿间隙进工具栏不闪退、线路栏展开 18 条、面板内保持、移开全部收起、从工具栏上方移出收起；页面无报错。
- 界面量测：工具栏 3 个图标、Teleport 落在设计画布内、线路面板 178×328 设计像素、条目名 `1号线 … 18号线`。
- 用户自有标签页（浏览器桥）复核：工具栏 3 个纯图标按钮均在元素清单里（桥报告 "No visible changes" 曾误判——纯图标按钮不计为可见变化；另一次"点击没反应"是点击发生在页面 loading 阶段，非功能问题）；点开线路图层后读到 `线路图层 全选 1号线 … 18号线 共 18 条 · 暂未联动三维图层`。

## 7. 未完成与后续接口

- `GEAR_TOOLS` 中「显示鼠标位置」「全屏模型」为 `ready: false` 占位。实现方式：把对应 `ready` 改 `true`，再在 `onToolClick` 加分支（鼠标位置可参照参考项目的 `positionStatusBar`；全屏用 `document.documentElement.requestFullscreen()`）。
- 勾选态接三维图层：3D 线路画好后，在 `toggleLine` 里接图层显隐即可——`getLine()` 每条线路已带 `stationList`（含 `xy_coords`）与 `xs/ys`，画线数据现成。
