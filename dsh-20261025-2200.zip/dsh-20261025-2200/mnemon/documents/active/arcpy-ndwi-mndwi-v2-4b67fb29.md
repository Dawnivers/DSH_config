---
id: "4b67fb29-310f-4bcc-8a67-a5efb5139997"
title: "arcpy 复跑脚本集与两段式报告再生成管线（东湖 NDWI/MNDWI 实验报告 v2）"
description: "东湖水体提取实验报告从 21 页扩到 36 页时的可复用做法：6 个独立可复跑 arcpy 脚本（路径与对应步骤）、重跑数值逐位复现的证据、doc_content_base.json → update_doc_json.py → build_docx.ps1 两段式生成管线、ArcGIS 自带 Python 2.7 下 json 写入的 unicode 坑与原子写入修正。基础 WPS COM 流程见 bda3f457，实验数值见 9a6d1e61。"
status: "active"
created_at: "2026-10-13T09:29:48.383Z"
updated_at: "2026-10-13T09:29:48.383Z"
content_hash: "567040ee449b589ca3c636aa4f451c36ee5a30351b041573db37a3a8011f2e02"
source_paths:
  - "scripts/update_doc_json.py"
  - "scripts/doc_content_base.json"
  - "scripts/build_docx.ps1"
  - "05_report/遥感数字图像处理实验报告.docx"
session_ids:
  - "5ecedf29-9f11-473e-9b2b-ee59c05e1209"
memory_body_ids:
  []
---

# arcpy 复跑脚本集与两段式报告再生成管线

本文档只记录 **v2 增量**：把报告里散落的 arcpy 代码抽成可复跑脚本、现场重跑取证，以及随之改造的两段式生成管线。基础 WPS COM 排版流程见 `bda3f457-c9ce-46b9-bca8-e239586f7f52`，实验数值、ENVI 偏差与 QA_PIXEL 异常见 `9a6d1e61-5598-45f2-afa8-2bbe2df41884`。

## 1. 六个独立可复跑脚本（`F:\RS_Lab\scripts`）

每个脚本对应报告中的一个环节，均用 ArcGIS 自带解释器执行：`C:\Python27\ArcGIS10.2\python.exe <script>`。

| 脚本 | 对应报告位置 | 作用 |
|---|---|---|
| `step2_verify_subset.py` | 步骤 2 | 子集行列/范围/DN 与裁剪参数核对 |
| `step3_verify_reflectance.py` | 步骤 3 | 反射率量级与元数据系数核对 |
| `step45_indices.py` | 步骤 4/5 | NDWI/MNDWI 计算（arcpy 实现） |
| `step6_water.py` | 步骤 6 | `Con(NDWI>0,1,0)` 二值水体提取 |
| `step7_polygon_area.py` | 步骤 7 | 赋投影 EPSG:32649 + `RasterToPolygon_conversion(..., NO_SIMPLIFY)` + 面积汇总 |
| `step52_background_compare.py` | 5.2 节 | 建成区/植被/土壤背景上两指数均值对比 |

重跑在独立 cmd 窗口中逐个执行并录制控制台截图，**所有数值逐位复现**：283.286 / 296.941 km²、314762 / 329934 像元、多边形 5329 / 6518、建成区 NDWI −0.2336 vs MNDWI −0.2836（差 0.0500）。原成果被重跑覆盖后结果不变，这本身就是一次端到端复现验证。

## 2. 报告中代码与取证的组织方式

每个 arcpy 相关步骤下补三块，顺序固定：标题「核心实现代码（arcpy）」→ 脚本路径说明 + 等宽字体核心代码（含中文注释）→ **该脚本的真实控制台运行截图**。另新增**附录 A** 收录六个脚本全文，带用途说明与运行命令。

截图清单从 16 条扩到 22 条（新增 `17_arcpy_step2_子集验证.png` … `22_arcpy_step52_背景对比.png`），图号全部重排为连续的 图 1–图 22，表号 表 1–表 11。v2 版式为 **36 页 / 7,109 字 / 22 图 / 13 表 / 6.3 MB**，正文 `arcpy` 出现 106 次。

## 3. 两段式再生成管线

```
改 doc_content_base.json（基础内容，含图注/表格/章节）
   ↓ python.exe update_doc_json.py   # 插代码块+运行截图、重排图号、拼附录 A
   ↓ build_docx.ps1                  # WPS COM 重出 docx
```

- `update_doc_json.py` 由 ArcGIS 的 Python 2.7 执行，把生成结果写入 `doc_content.json`（本次 46 982 bytes / 144 个内容块）。
- 基础内容单独放 `doc_content_base.json`，**生成文件损坏也不会波及源文件**；生成产物 `doc_content.json` 可随时重建。

## 4. ArcGIS Python 2.7 的 JSON 写入坑（本次踩实）

1. `io.open(path,'w')` 先截断文件、随后 `json.dump` 才抛错 → **基础 JSON 被写成 0 字节**（`ValueError: No JSON object could be decoded`）。教训：写生成物一律先写 `.tmp` 再原子改名。
2. `json.dump(cfg, fh, ensure_ascii=False)` 报 `TypeError: must be unicode, not str`；改 `json.dumps` 后又报 `UnicodeDecodeError: 'ascii' codec can't decode byte 0xe5`。Python 2.7 下处理中文 JSON 需显式保证 unicode 输入与 UTF-8 输出编码。
3. 编辑器层的副作用：文件被外部改动后，编辑工具会拒绝直接覆写（file changed since read / no longer exists），需重新读取或删旧后新建。

## 5. 仍可增强（未做）

自动目录页（给标题段套用「标题 1/2」样式，WPS 左侧现仍显示"暂无目录"）、页眉页脚与页码、把六张运行截图裁掉窗口边框只留命令与输出、补 Otsu/直方图阈值与固定阈值 0 的对比。
