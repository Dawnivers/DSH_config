---
id: "a5560456-0f63-497f-b0b1-ba900c089823"
title: "gaode-study-React（拆分组件）项目通读：纯前端 + json-server mock 后端、状态中枢与已知坑"
description: "高德地图 React 学习项目的架构边界记录：无自研后端、json-server(api.json:3000) 三个 POI 接口、App.jsx 状态中枢与 zoom 分级、各组件职责，以及 api 地址空格/City.jsx 全局 AMap/天气空值等具体坑（含 file:line）。"
status: "active"
created_at: "2026-10-22T00:50:19.641Z"
updated_at: "2026-10-22T00:50:19.641Z"
content_hash: "943f4b6978c34194b7c13d23c6dc5b6f4a8de6574d0699aab358bf25c9f3d018"
source_paths:
  - "src/App.jsx"
  - "src/api/index.js"
  - "src/components/MapContainer.jsx"
  - "src/components/Search.jsx"
  - "src/components/City.jsx"
  - "src/components/Show_history.jsx"
  - "src/components/Route.jsx"
  - "src/components/SearchPoints.jsx"
  - "src/components/SearchResult.jsx"
  - "api.json"
  - "package.json"
session_ids:
  - "3cfc4f7d-30c0-4032-a273-37a15da97d5c"
memory_body_ids:
  []
---

# gaode-study-React（拆分组件）通读记录

日期：2026-10-22。项目根 `D:\WebGIS\web二维开发\高德开发\gaode-study-React - 拆分组件`，最新提交 `39e1734 06组件拆分`。

本记录解决的问题是：**这个项目的前后端边界在哪、各自管什么、有哪些已确认的缺陷。**

## 1. 结论：没有自研后端，只有 json-server mock

- 仓库内无任何 Node/Express/Java 后端源码，也没有后端启动脚本（`package.json` 只有 dev/build/lint/preview）。
- 唯一的「后端入口」是 `src/api/index.js`，axios 全写死 `http://localhost:3000`：
  - `POST /historical-poi` 保存历史 POI
  - `GET /historical-poi` 拉全部历史
  - `DELETE /historical-poi/:id` 删一条
- 运行时后端 = `json-server@0.17.4`（在 dependencies 里钉死版本），数据文件为根目录 **`api.json`**（`historical-poi` 有数据、`history-route` 是空数组）。启动方式靠手敲：`npx json-server api.json --port 3000`。
- 根目录 **`db.json`** 是 json-server 官方示例模板（posts/comments/profile），与业务无关，git 中为未跟踪状态。
- 第二层「后端」在云端：Geocoder / Weather / PlaceSearch / Driving / Geolocation 全走高德服务，key 与 securityJsCode 硬编码在 `src/components/MapContainer.jsx` 顶部（不要复制到文档或聊天里）。

技术栈：React 19 + Vite 8 + Tailwind 3.4 + axios + `@amap/amap-jsapi-loader`（JSAPI 2.0）。

## 2. 前端分层

| 文件 | 职责 |
|---|---|
| `src/App.jsx` | 状态中枢：`map / AMap / center / city / SearchCity / zoom` 全提到父层往下传 setter；`center` 变化时用 `AMap.Geocoder` 反查城市，并按 zoom 分级（>8 市 / >4 省 / 否则「全国」） |
| `src/components/MapContainer.jsx` | `AMapLoader.load()` 加载 JSAPI 2.0 + 9 个插件；`AMap.Geolocation` IP 定位取中心点；建 `AMap.Map('container')`；加 Scale/ToolBar/ControlBar；监听 `moveend` 回传 center |
| `src/components/Search.jsx` | 搜索业务总装（约 293 行）：AutoComplete 提示、PlaceSearch 分类搜索、两套 Marker ref 数组、`AMap.Driving` 驾车规划、历史 POI 增删 |
| `src/components/Input.jsx` / `Show.jsx` | 输入框（路书按钮、清空叉号）/ 美食·酒店·景点·小区四格快捷分类 |
| `Show_history.jsx` / `SearchResult.jsx` / `SearchPoints.jsx` | 历史列表（点击回查、hover 出 ×）/ 输入联想下拉 / 结果详情列表（单搜多搜共用）；三者都是纯展示 + 回调 props |
| `Route.jsx` | 起终点 + 「出发」面板，收起时用 `h-[0px]` + `duration-500` 做高度动画，关闭时 `driving.current.clear()` |
| `City.jsx` | 城市弹窗（热门城市 + 34 个省级行政区全量地级市坐标硬编码 500+ 行）+ `AMap.Weather` 实时/预报；`Isweathershow = zoom > 8` 控制天气框显示 |

`src/index.css` 只有 tailwind 三层指令，外加一条把高德 `.amap-controlbar` 缩到 0.7 的样式。

## 3. 已确认的坑（按严重度）

1. **删除接口 URL 多了个前导空格**：`src/api/index.js:24` 写的是 `` ` http://localhost:3000/historical-poi/${id}` ``，axios 会拼出非法 URL，删除大概率直接失败。
2. **`City.jsx:29` 用全局 `AMap` 而不是 props 传下来的 `AMap`**（同一函数的守卫却用 `window.AMap`），加载时序一变就 `ReferenceError`。
3. **`City.jsx:569-570` 天气框无空值保护**：`Isweathershow` 为真但 `weatherNow / weatherForecast` 还是 null 时直接崩（两个异步回调 setState 之后才可用）。
4. **`Search.jsx:225` `autoComplete.search(InputValue, ...)` 用的是未更新的旧 state**，快速输入时会慢一拍。
5. 依赖里新加了 `antd@6` 但代码一次都没 import；`City.jsx` 尚未 `git add`（`?? src/components/City.jsx`），`api.json`、`Search.jsx` 等有未提交改动。

## 4. 下一步（待用户选择）

- 把「手工敲 json-server」补成 `package.json` 脚本，顺手修掉 URL 空格；
- 或先按现版本跑通前后端验证（当时 3000 端口未监听）。
