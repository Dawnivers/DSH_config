---
id: "97db8d2a-53b7-408d-ad80-c2c20dee73f0"
title: "分层分户项目：密钥外置到 .env + 首次推送到 GitHub（含 git 不走系统代理的坑）"
description: "D:\\WebGIS\\web三维开发\\分层分户项目 的一次完整安全收尾与发布记录：从全仓扫密钥、把 pg-api 的 config.toml 密码与前端硬编码 Cesium Ion 令牌迁进 .env/.env.local（含改动文件与行号）、根级 .gitignore 规则、后端连库与 /api/v1/getBuild 200、vite build 与远端逐文件复查的验证证据，以及 git 必须显式带 http.proxy（系统代理 127.0.0.1:7897 不被读取）才能 push 的实测坑。"
status: "active"
created_at: "2026-10-22T08:41:54.654Z"
updated_at: "2026-10-22T08:41:54.654Z"
content_hash: "80f8aff2569cae85b14d85e48a3888c1bbde365d5a994bc5417959ccdad25c2e"
source_paths:
  - "pg-api/app.js"
  - "pg-api/servce.js"
  - "pg-api/.env.example"
  - "Project/src/config/env.js"
  - "Project/.env.example"
  - "Project/src/api/baseApi.js"
  - "Project/src/components/Popup.vue"
  - "Project/src/components/edit.vue"
  - "Project/src/views/CesiumView.vue"
  - "Project/src/cesiumTools/sceneManager.js"
  - ".gitignore"
  - "README.md"
session_ids:
  - "7881b9eb-7263-4c88-9575-6f4575297051"
memory_body_ids:
  []
---

# 分层分户项目：密钥外置 + 首次推送到 GitHub（2026-10-22）

项目根 `D:\WebGIS\web三维开发\分层分户项目`：`Project`（Vue3 + Vite 8 + Cesium）与 `pg-api`（Express 5 + pg）。
产物：公开仓库 **https://github.com/Dawnivers/CommunityProject**（默认分支 `main`，首个提交 `4f5df00`，52 个文件 / 3.39 MB）。

同族文档：`d760879a-f677-4859-9ad7-ddbdc04a93f3`（本项目三服务启动链路与本机端口）；`60592d56-a0fc-4a32-bd93-1bf0fcabea37`（姊妹项目 Translation 的同类密钥外置，含「前端 VITE_ 变量必被内联进 dist、只能减害不能保密」的实测结论，同样适用本项目的 Cesium Ion 令牌）。

## 1. 迁移前的两处真实密钥（值不记录）

| 位置 | 形态 | 处理 |
|---|---|---|
| `pg-api/config.toml` | 明文 `password = "…"`（短数字串） | 先 `move` 成 `config.toml.off` 规避误提交，确认 `.env` 可用后删除 |
| `Project/src/cesiumTools/sceneManager.js` | 硬编码 `Cesium.Ion.defaultAccessToken`（JWT） | 改为读 `import.meta.env.VITE_CESIUM_ION_TOKEN` |

全仓扫描（排除 `node_modules` / `dist`）后仅这两处为真密钥，其余命中只是 `DB_PASSWORD` 之类的键名。

## 2. 后端：配置改读 `pg-api/.env`

- 引入 `dotenv`，按 `__dirname` 显式加载 `pg-api/.env`（不依赖启动时的工作目录）。
- 取值优先级封装为 `envValue('DB_PASSWORD', legacyValue('password') || '')` 形式（`pg-api/app.js:145`）：**环境变量 > config.toml（仅本机遗留兜底）> 默认值**。`config.toml` 已删除，但代码里保留了 toml 兜底分支，属于有意为之的过渡。
- 缺密码时启动即打印告警而不是静默失败（`pg-api/app.js:159-161`：`! 未读取到数据库密码：请在 pg-api/.env 里配置 DB_PASSWORD（参考 .env.example）`）。
- `.env` 键名：`DB_HOST` / `DB_PORT` / `DB_USER` / `DB_PASSWORD` / `DB_NAME` / `SERVER_PORT`；仓库只提交 `pg-api/.env.example`（`DB_PASSWORD=` 留空）。
- **注意**：`pg-api/servce.js` 与 `pg-api/app.js` 内容完全相同（拼写错误的备份副本，两文件字节数一致）。改任何配置逻辑都要同步两份，否则「改了半天没生效」的假象多半来自跑的是另一个文件。

## 3. 前端：统一出口 `Project/src/config/env.js`

新建 `Project/src/config/env.js` 作为唯一读取 `import.meta.env` 的地方，业务代码只 import 它。变量：

| 变量 | 用途 |
|---|---|
| `VITE_CESIUM_ION_TOKEN` | Cesium Ion 访问令牌 |
| `VITE_API_BASE_URL` | 接口根（原 `baseApi.js` 里硬编码的 `http://127.0.0.1:8090/api/v1`） |
| `VITE_API_ORIGIN` | 图片/静态资源根（原 `Popup.vue` 里硬编码的 `http://127.0.0.1:8090`） |
| `VITE_MODEL_BASE_URL` | 三维服务根（原 `CesiumView.vue` / `sceneManager.js` 里硬编码的 `http://localhost:666`） |

改造点：`Project/src/api/baseApi.js`、`Project/src/components/Popup.vue`、`Project/src/components/edit.vue`、`Project/src/views/CesiumView.vue`、`Project/src/cesiumTools/sceneManager.js`（含其注释里的示例 URL，一并改成占位形式避免误导）。
真值放 `Project/.env.local`（`*.local` 天然在 `.gitignore` 内），模板放 `Project/.env.example`。

## 4. 根级 `.gitignore`

新建根 `.gitignore`：`node_modules/`、`dist/`、`.env`、`.env.*`、`*.local`、`config.toml`、日志与临时文件；**只放行 `.env.example`**（`!` 规则）。
实测 `git status --ignored` 确认被忽略：`Project/.env.local`、`pg-api/.env`、两侧 `node_modules/`、`Project/dist/`、`.dsh-code-index/`、`Project/.vscode/settings.json`。

## 5. 验证证据（可当回归清单复用）

| 检查 | 方法 | 结果 |
|---|---|---|
| 后端从 `.env` 起得来 | 因 8090 已被占用，另起 8092 临时实例 | 日志 `✓ PostgreSQL 数据库连接成功 / ✓ 数据库: fencengfenhu`；`GET /api/v1/getBuild` → 200；静态资源 200 |
| 前端未被打断 | `pnpm build`（Vite 8 / rolldown） | 3572 modules，12.43s，无错误；仅 `index-*.js 1.55 MB` 触发 chunk >500 kB 性能建议 |
| 源码明文残留 | 扫索引内源文件 | 0 处真密钥命中 |
| 远端是否干净 | 用 GitHub contents API 把 `app.js`、`servce.js`、`sceneManager.js`、`env.js`、两个 `.env.example`、`baseApi.js` 逐个拉回复查 | 全部 clean，无密码无令牌；远端树 69 项中不含 `.env` / `.env.local` / `config.toml` / `node_modules` / `dist` |

## 6. 关键坑：git 不走 Windows 系统代理

本机 IE/WinINET 代理为 `127.0.0.1:7897`（`ProxyEnable=1`，端口在听），但 git 默认不读它：

```
fatal: unable to access 'https://github.com/Dawnivers/CommunityProject.git/':
Recv failure: Connection was reset
```

解法（本次实际采用后者，凭据复用本机已存 GitHub 凭据，未写入任何配置文件）：

```powershell
git -c http.proxy=http://127.0.0.1:7897 -c https.proxy=http://127.0.0.1:7897 push -u origin main
# 或一次性 git config --global http.proxy http://127.0.0.1:7897
```

反向对照：`Invoke-RestMethod` / `Invoke-WebRequest` **会**自动走系统代理，所以「API 能查仓库、git push 却重置」的现象不代表网络不通。

另一个 PowerShell 小坑：在 `foreach` 管道里拼 `if (...) {...}` 当表达式会被当成命令解析（报 `术语 'if' 不会被识别为 cmdlet`），改为先算变量再输出即可——本次「远端逐文件复查」第一版失败就是这个原因，产物虽然对，但脚本要修。

## 7. 现状与后续可选项

- 本机真值位置：`pg-api/.env`（数据库密码）、`Project/.env.local`（Ion 令牌），均已 ignore；换机时复制 `.env.example` 自填。
- 三维场景依赖本机 `localhost:666` 的倾斜模型/地形服务（nginx，非本仓库），已写进 `README.md` 快速开始，注明他人 clone 后只能看表格类功能。
- 仓库 topics 已打：`cesium`、`vue3`、`express`、`postgresql`、`3d-tiles`、`webgis`、`gis`。
- 待定（用户可选）：加 MIT LICENSE；加 `.gitattributes` 统一换行，避免当前 Windows CRLF 在他人 clone 时反复报警告；`index-*.js` 体积可分块优化。
