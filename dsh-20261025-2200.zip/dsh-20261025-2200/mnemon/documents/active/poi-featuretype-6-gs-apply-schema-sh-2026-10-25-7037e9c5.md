---
id: "7037e9c5-10d0-4357-b833-67bb1a1d8bfe"
title: "发布 poi 图层前的必做清理：旧 featuretype 指向已改名表（+ 图形化 6 步与 gs-apply-schema.sh 丢失查证，2026-10-25）"
description: "D4 收尾「把 3346 条 poi 发出来」的实现交接：GeoServer 停着且 wuhan 工作区里的 poi featuretype 仍指向已改名的 poi_scratch_20261025（必须先删 featuretype 再发，否则出现旧字段 phone/email/open_hours 的假成功）、UI 六步与 REST 两条等价命令、PNG 字节数判据与报错对照表；另附 gs-apply-schema.sh 被 npm create vite 覆盖丢失的查证与「脚本必须进 git」结论。数据基线见 8d2fc1c9，reload 边界见 b2ece253，脚本语义见 007be982。"
status: "active"
created_at: "2026-10-25T05:11:59.883Z"
updated_at: "2026-10-25T05:11:59.883Z"
content_hash: "92b4ed0a876894cf48302eeb815ac96e33ca05fd3905a4e757f9973640c86480"
source_paths:
  - "etl/main.py"
  - "etl/spec.md"
session_ids:
  - "e85f46ff-951f-46fb-8350-6d6346989148"
memory_body_ids:
  []
---

# 发布 poi 图层：先清理，再发布

数据侧已就绪（3346 行，中心 3 区全类 + 武昌 school/hospital 部分），本文只处理「把它变成一个能出图的图层」。**规则层不重复**：行/列/范围/缓存四档处置、count=600 采样天花板、`ST_Within` 归区口径见 `8d2fc1c9`；reload 的实测边界见 `b2ece253`；reload/publish/unpublish 的脚本语义见 `007be982`。

## 1. 动手前的真实状态（这一步决定了顺序）

- GeoServer 当前是**停的**；`GEOSERVER_DATA_DIR = D:\geoserver\data_dir`（User 级环境变量，进程内可见）。
- `wuhan` 工作区下数据源只有 `spatial_db`，其 featuretype 有三个：**`admin_area` / `empty_poi` / `poi`**。
- 关键事实：那个 **`poi` featuretype 指向的表正是今天改名留档的 `poi_scratch_20261025`**，即该图层现在是坏的（表名已不存在，一查就报错）。

推论（本轮的坑）：**必须先删掉旧 `poi` featuretype，再发布新 `poi`**。直接「发布」会撞上「资源已存在」，或者更糟——发布成功但属性列表还是旧的 `phone / email / open_hours`，看起来像成功实则读的是旧结构缓存。同理也解释了早前库里那两张怪表的来历：那是旧实验层的残留。

删图层**只删 GeoServer 的目录配置（data_dir 里的 XML），不动数据库表**，3346 行数据安全。`admin_area`（13 区边界）绝对不要碰，删了要重发。

## 2. 图形化路径（6 步，顺序是唯一容易记混的地方）

1. 顶部 **存储仓库** → `wuhan:spatial_db` → **「发布」** 标签页，先确认表清单里能看到 `poi`（看不到说明数据源缓存了旧表清单，回存储仓库页点「重新加载」）。
2. 顶部 **图层** → 列表里勾选 `poi` → 顶部「删除所选图层」（稳一点的做法：点进 `poi`，拉到页面最底部点「删除图层」）。
3. 回 **存储仓库 → spatial_db → 发布** → 找到表 `poi` → 右侧「发布」。
4. 填新图层表单：Name=`poi`（与表名一致）、Title 随意、**声明 SRS = `EPSG:4326`**（必须与库里一致）、边界框点 **Compute from data** 与 **Compute from native bounds** 各一次。
5. 检查发布页 Coordinate Reference Systems 的 SRS 为 `EPSG:4326` → 保存。
6. **图层预览** → `wuhan:poi` → 格式下拉选 **PNG**（不要用 OpenLayers 预览，PNG 才是真实出图）。

## 3. 验收判据（D4 的正经验收物是「POI 叠天地图不偏移」）

最快判据是**字节数**，比肉眼看更可靠：

```
http://localhost:8080/geoserver/wuhan/wms?SERVICE=WMS&VERSION=1.1.1&REQUEST=GetMap
  &LAYERS=wuhan:poi&STYLES=&SRS=EPSG:4326
  &BBOX=113.95,30.40,114.55,30.72&WIDTH=1000&HEIGHT=600&FORMAT=image/png
```

| 看到什么 | 结论 |
|---|---|
| 几千字节 PNG + 点密集铺在江岸/江汉/武昌 | ✅ 通了 |
| 空白、只有边界；PNG 只有几百字节 | bbox 没算或 SRS 不对 → 回表单重算 |
| `table "poi" does not exist` 红字 | 旧 featuretype 没删干净 |
| 字段是 `phone/email/open_hours` | 发的是旧表结构缓存 → 删图层重发（reload 不够） |

## 4. 不想点界面时的等价 REST（两条，不动数据库）

```
curl.exe -u admin:geoserver -X DELETE ".../rest/workspaces/wuhan/datastores/spatial_db/featuretypes/poi?recurse=true"
curl.exe -u admin:geoserver -X POST -H "Content-Type: text/xml" --data-binary "@poi-featuretype.xml" \
  ".../rest/workspaces/wuhan/datastores/spatial_db/featuretypes"
```

要点：REST 路径里 `rest/workspaces/datastores/featuretypes` 是固定关键字，`wuhan`/`spatial_db`/`poi` 才是自命名值（`stores` 与 `datastores` 互为别名，见 `007be982` §6）；Windows PowerShell 必须写 `curl.exe`（`curl` 是 `Invoke-WebRequest` 别名）。

## 5. 附带查证：gs-apply-schema.sh 为什么找不到了

提问「之前那个脚本放哪了」的查证结论（三次独立搜索 + 回收站，均零命中）：

| 查了什么 | 结果 |
|---|---|
| `D:\WebGIS\web三维开发\gis-access\deploy\` | **不存在**，顶层只剩 `node_modules / public / src` + Vite 配置 |
| 全 `D:\WebGIS` 深度 5 搜 `gs-apply-schema*` / `init-geoserver*` | 零命中 |
| 回收站 | 没有 |

时间戳对得上原因：脚本创建于 10/23 12:53，而 `gis-access` 的 `package.json` / `vite.config.js` / `index.html` 是 10/24 10:56–11:03——**该目录被 `npm create vite` 重建时整个覆盖**，同批没的还有 `init-geoserver.sh|ps1`、`scenario-1/2/3-*.sh`、`demo-add-table.sh`、`.env.example`、`README.md`。

**设计可复原，代码不可**：`007be982` 记全了四种子命令语义、`curl -sf` 判存在、发布后立刻 GetMap 验 200、400 时反查 `information_schema`、GWC truncate、REST 固定段与自定义段，但没有脚本原文。

结论：`gis-access` 连 `.git` 都没有，**脚本不进 git 就会蒸发第二次**。重写时放当前项目的 `deploy\`（不再放 `gis-access`，那已不是主项目），并配一条「它解决什么问题」的 README 一起提交。当下只有一层要发，两条 curl 足够，重写脚本的时机是 D13 加格网表 / D18 加物化视图前后。

## 6. 下一步（按顺序，未完成）

```
☐ 启动 GeoServer（当前停着）
☐ 删除旧 poi featuretype（必须在前）
☐ 发布新 poi（SRS=4326 + 重算 bbox）
☐ WMS 出图 / QGIS 叠天地图验收：点位落在正确建筑上
☐ 有余额再补 420106|hospital 余量与 420111 洪山区 ×4 类
```
