---
id: "69d45ed3-6355-4e25-8855-993c74bb1706"
title: "GeoServer SLD 样式：文件即配置的存放/命名规则，与 ExternalGraphic 在本机全部失效的实证（2026-10-25）"
description: "GeoServer 样式的存放路径与命名规则；本机 ExternalGraphic 全部失效（含自带 grass_fill.png 对照）的实证与矢量徽章替代方案。"
status: "active"
created_at: "2026-10-25T05:57:18.916Z"
updated_at: "2026-10-25T05:57:18.916Z"
content_hash: "9cb24b3cfdd62e0e8259b0b73246a19ae76216bbc37245e1f99567d9b534d076"
source_paths:
  - "styles/poi_badge.sld"
  - "styles/poi_by_category.sld"
  - "styles/poi_icons_inline.sld"
  - "styles/png"
session_ids:
  - "41c4004b-1b92-4fb3-803c-055605c04d00"
memory_body_ids:
  []
---

# GeoServer SLD 样式：存放规则 + 图标无法加载的实证（2026-10-25）

前情（本文不重复）：REST 上传 SLD、UI 与 API 等价、幂等写法见 `be91eaef-f93d-4d77-803d-b34651d1dfd1`；`wuhan` 工作区与 `poi` 图层的发布见 `e2a4925e-c390-44f3-bd15-8bf165e70b28`。

本文记录两件事：**样式到底存在哪、为什么叫 `wuhan:xxx`**，以及**为什么 POI 图标图片在这台机器上怎么都画不出来**（结论：环境级限制，不是文件/路径问题）。

## 1. 样式没有数据库，就是成对的文件

```
D:\geoserver\data_dir\
├── styles\                      ← ① 全局样式，所有工作空间共用
│   ├── poi.sld                  ←   内容（SLD XML）
│   └── poi.xml                  ←   元数据
└── workspaces\wuhan\styles\     ← ② 工作空间样式，只属于 wuhan
    ├── poi_badge.sld
    ├── poi_badge.xml
    ├── poi_by_category.sld
    └── poi_by_category.xml
```

**一个样式 = `.sld` + `.xml` 一对文件。** 元数据 `.xml` 就是「它有名字有归属」的原因：

```xml
<style>
  <id>StyleInfoImpl-64c6c1f0:1a17182455d:-7fee</id>
  <name>poi_badge</name>
  <workspace><id>WorkspaceInfoImpl-5234625e:1a16863df02:-7ff1</id></workspace>
  <format>sld</format>
  <languageVersion><version>1.0.0</version></languageVersion>
  <filename>poi_badge.sld</filename>
</style>
```

## 2. 命名规则：前缀 = 工作空间名

| 存放位置 | 完整名称 | 请求里怎么写 |
|---|---|---|
| `workspaces/wuhan/styles/poi_badge.sld` | `wuhan:poi_badge` | `&styles=wuhan:poi_badge` |
| `styles/poi.sld`（全局） | `poi`（无前缀） | `&styles=poi` |

同一份 SLD 可在多个工作空间各存一份，靠前缀区分。只服务本项目 → 放工作空间；多工作空间复用（如统一水系样式）→ 放全局。

## 3. 三个推论（运维上真正有用的部分）

- **可以直接改文件**：编辑 `poi_badge.sld` → `POST /rest/reload` → 立刻生效，不必走 GUI 或 REST PUT。`curl -X PUT` 只是比网页贴 XML 快。
- **备份 = 拷目录**：`data_dir\workspaces\wuhan\styles\` 整个拷走即可。反过来 `data_dir` 被重置时样式会和图层配置一起消失。
- **三层真相**：磁盘是真相，REST 是索引，GUI 是视图。GUI 显示不一致时几乎永远是页面没刷新（Wicket 页面不自动刷；图层编辑页的「默认样式」下拉是加载那一刻渲染的），按 Ctrl+F5 或重进「样式」页。

一致性三连（三处一致 = 无缓存问题）：

```powershell
Get-ChildItem 'D:\geoserver\data_dir\workspaces\wuhan\styles'
curl.exe -s -u <user>:<pass> "http://localhost:8080/geoserver/rest/workspaces/wuhan/styles"
curl.exe -s -o out.png -w "%{http_code} %{size_download}`n" -u <user>:<pass> `
  "http://localhost:8080/geoserver/wuhan/wms?service=WMS&version=1.1.0&request=GetMap&layers=wuhan:poi&styles=wuhan:poi_badge&format=image/png&srs=EPSG:4326&bbox=114.29,30.53,114.32,30.55&width=800&height=600"
```

## 4. 关键结论：这台 GeoServer 加载不了任何 ExternalGraphic

目标原本是给 POI 挂真图标（学校/医院/商场/公园）。五条路全试，全部失败，共同指纹是**画成灰方块占位符、日志一句不报**：

| 方式 | 结果 |
|---|---|
| `http://localhost:8080/geoserver/www/icons/school.png`（图标放 `data_dir/www/`） | 灰方块 |
| `http://<局域网IP>:8080/...` | 灰方块 |
| `file:///D:/geoserver/data_dir/www/icons/school.png` | 灰方块 |
| classpath（放进 `webapps/geoserver/WEB-INF/classes/icons/`） | 灰方块 |
| 内嵌 base64 `InlineContent` | 上传直接 500：`SLDTransformer doesn't support InlineContent` |
| **对照：GeoServer 自带的 `grass_fill.png`** | **同样灰方块** ← 决定性证据 |

判读逻辑值得复用：

- **相对路径不是文件路径**。日志 `can't parse icons/school.svg as a java resource present in the classpath` 说明 GeoServer 把相对路径当 classpath 资源找，不是去 `data_dir` 找文件。图标要经静态目录暴露则放 `data_dir/www/`，走 `/geoserver/www/...`。
- **`InlineContent` 只存在于 SLD 1.1，而 GeoServer 用 SLD 1.0 的 `SLDTransformer` 编码**，所以这条路在 GeoServer 里根本不通（不是版本没升）。
- **拿自带素材做对照是排除「我的文件有问题」的最快办法**。自带 `grass_fill.png` 也画不出来 → 与图片格式、路径、权限、SVG 光栅化全部无关。
- **`data_dir/security/` 下没有 `urlchecks.xml`**，说明不是 URL Checks 白名单拦的；同时 `curl` 从本机访问 `/geoserver/www/icons/*.png|svg` 返回 200，说明静态目录本身正常。剩下的就是渲染侧的环境级限制（2.23+ 的 URL 访问策略且日志级别未开出）。
- 皮像素统计要用**颜色桶/直方图**验证，别靠肉眼：灰度桶（256/128/64/192/0）全灰、蓝色像素为 0 = 没加载到图，`sha` 相同 = 输出根本没变（图形缓存会记住失败结果，换 URL 加版本号也无效）。

## 5. 采用方案：纯矢量「徽章」样式（不依赖任何外部图片）

`poi_badge` = 三层叠加，参数都可调：

| 层 | 作用 | 参数 |
|---|---|---|
| 最底 | 柔光白圈，把点从底图"抬"起来 | `Size 26`、`Opacity 0.40` |
| 中间 | 彩底圆 + 2.5 px 白环（"高级感"主要来源） | `Size 17`、各分类色 |
| 最上 | 白色内嵌字形区分类别 | 医院=十字、公园=三角、商场=方块、学校=圆点 |
| 缩放 | 拉远变 4 px 小点；1:5万内出徽章；1:1.2万内出名称 | `Min/MaxScaleDenominator` |

配套另有 `poi_by_category`（简单四色圆，无白环）。测试期建的 7 个试验样式（`icons-v2/v3/v4/v5`、`test_icon`、`ti_file`、`ti_ip`、`ti_cp`、`ti_grass`、`poi_icons*`）已全部删除，工作空间只剩这两个。

挂到图层：图层 → `wuhan:poi` → 「发布」标签 → WMS 设置 → 默认样式 → 选 `poi_badge` → 保存 → 图层预览 PNG。

## 6. 遗留的两条可选路径

- **路 A（推荐，图标文件已备好）**：在「安全 → URL Checks」放行 `http://localhost:8080/geoserver/www/**`，即可恢复 4 个 SVG 图钉样式。图标文件仍在 `data_dir\www\icons\{school,hospital,mall,park}.{svg,png}`。
- **路 B**：`ttf://字体名#码点` 由 Java 直接读系统字体渲染，理论上绕开 URL 与文件加载，概率未验证（估 50%）。

## 相关文件

- `styles/poi_badge.sld` — 当前采用的三层徽章样式（约 10 KB，带注释）
- `styles/poi_by_category.sld` — 简单四色圆
- `styles/png/{school,hospital,mall,park}.png` — 已光栅化的 4 张图钉，路 A 放行后即可用
- `styles/poi_icons_inline.sld` — base64 内嵌版（已验证会被 GeoServer 拒绝，仅留作证据）
