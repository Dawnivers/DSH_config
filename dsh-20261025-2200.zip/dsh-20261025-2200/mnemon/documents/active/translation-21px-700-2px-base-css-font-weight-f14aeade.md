---
id: "f14aeade-11df-444a-a22b-8344139ec7cc"
title: "Translation 大屏六个组件标题尺寸统一（21px/700/2px）与「样式写了不生效」的根因：base.css 全局 font-weight 重置"
description: "2026-10-12 把 left1/left2/left3/right1/right2/right3 六个大屏组件的介绍标题统一为 21px/700/2px 的完整过程：6 个标题类名与行号、改前改后的 getComputedStyle 实测数据、只改了 4 个文件的原因，以及关键根因——src/assets/base.css 的 `* { font-weight: normal }` 直接命中元素、永远赢过父元素继承值（与选择器权重无关），含 right2 标题的正确修法与排版行高差异说明。"
status: "active"
created_at: "2026-10-12T05:49:54.188Z"
updated_at: "2026-10-12T05:49:54.188Z"
content_hash: "dfd29f2022f122a700defc3241a20d92711187d6f0ced1283e2e2b4d203c91d4"
source_paths:
  - "Translation/src/components/screenUI/left1.vue"
  - "Translation/src/components/screenUI/left2.vue"
  - "Translation/src/components/screenUI/left3.vue"
  - "Translation/src/components/screenUI/right1.vue"
  - "Translation/src/components/screenUI/right2.vue"
  - "Translation/src/components/screenUI/right3.vue"
  - "Translation/src/assets/base.css"
  - "Translation/src/cesiumTools/lineAndpoints/popup/popup.js"
session_ids:
  - "22082eda-43e1-4b18-b70b-599a548c27c3"
memory_body_ids:
  []
---

# Translation 大屏六个组件标题尺寸统一（21px / 700 / 2px）

日期：2026-10-12。状态：**已改完并用 Playwright 实测通过**。

需求：left/right 系列 6 个大屏组件的介绍文字（运营统计、建设历程、客流指标、线路概览、告警趋势、概念影像）视觉大小不一，要求统一。

## 1. 改前：6 个标题 6 个类名、4 种字号

| 标题 | 文件 | 模板位置 | 类名 | 字号 | 字重 | 字距 | 渲染宽度 |
|---|---|---|---|---|---|---|---|
| 运营统计 | `Translation/src/components/screenUI/left1.vue` | L170 | `.main-title`（CSS L500） | 18px | 700 | 0.9px | 63px |
| 建设历程 | `left2.vue` | L157 | `.panel-title`（CSS L350） | 21px | 700 | 2px | 76.7px |
| 客流指标 | `left3.vue` | L153 | `.title-text`（CSS L341） | **15px** | 700 | 2px | 56.7px |
| 线路概览 | `right1.vue` | L177 | `.widget-title`（CSS L353） | 21px | 700 | 2px | 76.7px |
| 告警趋势 | `right2.vue` | L236 | `div.main-title`（CSS L637）下的裸 `<span>` | 16px | **400** | 1.92px | 59.7px |
| 概念影像 | `right3.vue` | L661 | `.header-title`（CSS L886） | 21px | 700 | **3.78px** | 82.6px |

字号集合 `[15,16,18,21]`、字重 2 种、字体 2 种（Noto Sans SC / 系统字体）——这就是「看着大小不一」的全部来源。
每个组件是独立的 `<style scoped>`，所以同名类（`left1` 与 `right2` 都叫 `.main-title`）互不影响，但也意味着**改一处必须手动同步其余五处**。

## 2. 改动：统一为 21px / 700 / 2px（取原本占多数的那一档）

只改了 4 个文件，因为 `left2` / `right1` 本来就是目标值：

| 文件 | 类名 | 改动 |
|---|---|---|
| `left1.vue` | `.main-title` | 18px→21px，`letter-spacing: 0.05em`→`2px` |
| `left3.vue` | `.title-text` | 15px→21px |
| `right2.vue` | `.main-title` | 16px→21px，`letter-spacing: 0.12em`→`2px` |
| `right3.vue` | `.header-title` | `letter-spacing: 0.18em`→`2px` |

各文件内都留了「六个标题统一为 21px/700/2px，改这里请同步其余五个」的注释。

## 3. 关键根因：`* { font-weight: normal }` 让「在父元素上写 700」完全失效

`right2` 的 CSS 明明写着 `font-weight: 700`，实测 span 仍是 **400**（比其它五个细一档）。根因在 `Translation/src/assets/base.css:1-7`：

```css
*, *::before, *::after {
  box-sizing: border-box;
  margin: 0;
  font-weight: normal;   /* ← 关键 */
}
```

标题结构是 `<div class="main-title"><span>告警趋势</span></div>`：

- `*` 选择器**直接命中** span 元素本身；
- `.main-title` 上的 `700` 只能被 span **继承**；
- **直接命中的声明永远赢过继承来的值**——这条与选择器权重、`!important` 之外的优先级规则无关。

另外 5 个标题的元素自带类名（直接命中），所以都是 700，只有它被压成 400。修法是在 `right2.vue` 里补一条同样「直接命中」的规则：

```css
.main-title > span {
  font-weight: 700;
}
```

推论（可迁移）：只要 `base.css` 里保留这条 `* { font-weight: normal }`，**任何「父元素设字重、子元素继承」的写法都不会生效**；要么给子元素直接写类名，要么加 `> span` 之类的直指规则。

## 4. 验证：不信任 CSS 声明，只认 getComputedStyle 实测

用 Playwright 打开大屏，对 6 个标题逐个取 `getComputedStyle` 的 fontSize / fontWeight / letterSpacing / lineHeight，再量实际渲染宽度与标题行溢出：

| 标题 | 字号 | 字重 | 字距 | 渲染宽 | 换行 |
|---|---|---|---|---|---|
| 六项全部 | 21px | 700 | 2px | **76.7px** | 否 |

- 字号集合由 `[15,16,18,21]` 变为 `[21]`；6 个标题渲染宽度精确等于 76.7px。
- 标题行溢出检查（`scrollWidth/clientWidth`）全部正常，`客流指标` 从 15px 跳到 21px **没有撑破面板、没有换行**。
- 截图对比：`.review/hud-titles-before.png` / `.review/hud-titles-after.png`。

**遗留（未做，用户可选）**：渲染高度仍是 `17.5` / `28` 两个值，那是 `line-height` 差异（`建设历程`/`概念影像` 用 `line-height: 1`，其余继承 body 的 `1.6`），**不是字形大小差异**；若要标题栏高度也完全一致，需再统一 line-height。

## 5. 验证脚本踩坑

临时验证脚本里用 `Select-Object -First N` 截断输出时，**PowerShell 在收够对象后会直接终止上游进程**，node 还没跑到截图那一步就被杀掉，表现为「截图文件 not found」并可能留下游离浏览器进程。改用 `-Last` 或先落盘再过滤。

## 6. 相关记录

点击地铁站点后的气泡/详情卡偏移（`offset: [150, -20]` 等）位于 `Translation/src/cesiumTools/lineAndpoints/popup/popup.js`，同一文件约 L194 还有「详情卡靠右缘时自动镜像换边」的逻辑，详见既有文档 `9b55863a-1c10-4f00-baa0-479ddaed58ab`。
