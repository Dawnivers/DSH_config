---
id: "ab5164f9-c8fb-4ebb-befe-305e70609cb7"
title: "本机 DSH 框架版本来源与「是否装插件门控 / 升级安全网」结论（2026-10-10，desktop profile）"
description: "实测确认本机 DSH 框架包由 Electron 外壳打包（dsh-plugin-desktop 2.0.17 / dsh 0.2.0-rc.2，非 pnpm 布局），据此判定 Noob-stupid/dsh-plugin-gating-hub 在 desktop 宿主上不值得安装及其理由，并记录 desktop profile 当前激活清单与「外壳补丁无自检」这一运维缺口。承接文档 3b725cac 与 502b4a5c。"
status: "active"
created_at: "2026-10-10T03:33:48.865Z"
updated_at: "2026-10-10T03:33:48.865Z"
content_hash: "6f195faa7521524aba9d6bbfb4340f63acef70411762e4761dad1f3b70851bbb"
source_paths:
  - "dsh-browser/README.zh.md"
  - "dsh-builtin-browser/desktop/apply-shell-patch.mjs"
session_ids:
  - "c23c9efe-55e2-47f5-bd9d-0a98fe492250"
memory_body_ids:
  []
---

# 本机 DSH 框架版本来源 & 插件门控/升级安全网结论

日期：2026-10-10（本机 desktop profile）。承接文档：
- `3b725cac-20bd-4a06-b1d1-eae5d2348c6b`（dsh-plugin-gating-hub 调研）
- `502b4a5c-16a2-4ea4-953c-b861592308b7`（dsh-browser 安装实录）
- `ca3a1d81-f11d-4876-bdef-fdb32c7b9c83`（builtin-browser 残留清理）

引用的工作区外路径（只读记录，便于复查）：
`C:\Users\林先语\.dsh\profiles\desktop\package.json`、`C:\Users\林先语\.dsh\profiles\desktop\cordis.patch.yml`、`D:\DSH\dsh_data\DSH Desktop\resources\app\package.json`。

## 1. 关键实测：本机框架不是 pnpm 装的

| 检查位置 | 结果 |
|---|---|
| `~/.dsh/profiles/desktop/node_modules/@deepseek-ai/` | 只有 `cosmokit 1.8.5`、`schemastery 3.18.4` 两个传递依赖，**无框架包** |
| `~/.dsh/profiles/node_modules/@deepseek-ai/` | 不存在 |
| `D:\DSH\dsh_data\DSH Desktop\resources\app\node_modules\@deepseek-ai\` | **`dsh 0.2.0-rc.2`** + 250 余个 `dsh-* 0.2.0-rc.2`，属 `dsh-plugin-desktop 2.0.17` |

结论：框架包随 **Electron 外壳**打包在 app 内，由**桌面更新器**负责升级；profile 的 `dsh.profile.bundles` 只是按已知裸包路由规则指过去（与「`@deepseek-ai/*` 必须列进插件自身 peerDependencies 才被路由到安装目录」是同一机制）。**本机没有 pnpm 布局的框架树。**

## 2. 由此得出的判定：dsh-plugin-gating-hub 在这台机器上不值得装

理由是「头号卖点没有作用对象」，而非插件质量（约 99★ / 647 commits / 仍在发版）：

- 它公开文档描述的整套升级安全动作——定位「含 `.pnpm` 的顶层 node_modules」为真实安装根、镜像每个 `@deepseek-ai` 版本包 + 顶层 scope + `lock.yaml` 到 `~/.dsh/plugin-console/framework-backups/<version>/fw-tree/`、失败整树回滚并 relink——**前提就是 pnpm 布局的框架树，本机没有**。
- 检测到 **desktop-host 形态**时，非手动设置的 managed 模式会自动退回 **Observer（只看不接管升级）**；且其兼容矩阵当时只测到 `0.1.7-rc.2`，本机已是更新的 `0.2.0-rc.2` 线。
- 残余价值逐条落地后：一键启停（中）、版本检测/一键更新（低，8 条 `link:` 条目无版本概念）、适配闸门 409 锁死（≈0，须由它自己发起的升级才会写 `compat-pending.json`）、启动失败隔离（**唯一有真价值**，但触发条件是「DSH 起不来」）。
- 反向成本：8547 行单体 host 插件，拿到「写 profile 补丁层 + 启停 DSH 服务」的权限；本机最脆弱的手工外壳补丁链（见 §4）正是最不希望多出的变量。

它真正的适用场景：改用 CLI/pnpm 方式安装 DSH 的机器，或 rc 阶段升级事故排查。替代方案是**不注册为插件**，只 clone 仓库当工具箱，直接用其救援脚本：
```
node scripts/safe-boot.mjs --list
node scripts/safe-boot.mjs --restore-last-good
node scripts/safe-boot.mjs --disable-suspects
```
并把 `docs/contracts/rules.json` 当作「升级前 checklist」只读使用。

## 3. desktop profile 当前激活清单（2026-10-10）

- 依赖/bundle 共 17 条，其中 **8 条是 `link:` 本地目录**：`@local/dsh-agnes-{core,image,video}`、`@local/dsh-mcp-anysearch`、`@yuxianglin/dsh-bridge-browser`、`dsh-academic-research-skills`、`dsh-archify`、`dsh-context7`。其余第三方为 `@linxin666/dsh-web-all`、`@liustack/modlens`、`dsh-better-sidebar`、`dsh-code-index`、`dsh-context`、`dsh-cost-meter`、`dsh-mnemon`、`@deepseek-harness-tui/dsh-tui`（这些才可能受益于 npm 版本检测）。
- 用户补丁层 `cordis.patch.yml` 现有 6 条：`desktop-shell`（`mode: extended`、`openBrowser: false`、`networkExposure: loopback`、**`port: 43120` 钉死**）、`desktop-notifications`（turn/job/schedule 完成与失败通知）、`cost-meter`（显式启用）、`dsh-context7`（配置项中含 API key，**明文**，按插件 README 的存储方式）、`web-ui-usage`（禁用）。注意：该文件含凭据，**不要整份复制进文档或记忆**。
- `~/.dsh/skills` 现有 9 个技能：dask、geomaster、geopandas、networkx、polars、scientific-visualization、scikit-learn、uncertainty-and-units、zarr-python。
- `profiles/desktop/` 下另有 `cordis.yml`（空数组 `[]`）与一处 `.backup-before-ars-*` 备份目录（ars = academic-research-skills）。

## 4. 真正的运维缺口：外壳补丁没有自检

本机「够用」的能力里有几条是**手工维护、且可能被一次桌面更新静默抹掉**的：
- `electron-runtime-*.js` 的 `webviewTag: true` + `globalThis.__dshBuiltinBrowserContent`
- `preload.cjs` 的 `desktopBridge.browserPort`（失败回退 44721）
- `lib/dsh-builtin-browser-shell.js` 的 `127.0.0.1:44721/browser/command`
- `cordis.patch.yml` 里钉死的 `port: 43120`
- `%USERPROFILE%\.dsh\dsh-bridge-port-shim.mjs`

**目前没有任何东西自动检查「这些补丁还在不在」**，只有手动跑 `op=diag` 才会发现。替代机制是 `resources/app-lib-backup-20261006` 手工备份 + `apply-shell-patch.mjs` 幂等重放。

建议方向（待实施，非既成事实）：把 `op=ping` / `op=diag` 的自检封成可复跑的 `verify-shell-patch.ps1`（复用 `desktop\restart-and-verify.ps1` 的探测逻辑），检查「webview 通路 + 44721 端点 + 43120 端口 + 8 个 `link:` 目录是否仍在」，并挂一张 task_board 定时卡，在每次 DSH 更新后自动出体检报告。

一句话总结：**功能满足度高，可持续性中等**；短板不是缺功能或插件市场，而是手工补丁债缺乏告警。
