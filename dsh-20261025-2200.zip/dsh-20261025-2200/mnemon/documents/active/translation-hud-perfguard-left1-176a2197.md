---
id: "176a2197-fd01-482e-94ae-f8eda62baced"
title: "Translation 智慧地铁 HUD 维护：启动渲染环境检查卡（perfGuard）+ left1 面板重叠修复"
description: "2026-10-07 两笔 HUD 改动：新增每次启动固定弹出的「渲染环境检查」卡（WEBGL 渲染器三分类文案、三态标题、低画质一键切换与持久化、Transition 离场时长坑），以及 left1.vue 数显牌压住线路列表的根因定位（居中双向溢出）与不改变外框尺寸的压缩式修法。"
status: "active"
created_at: "2026-10-07T14:54:53.966Z"
updated_at: "2026-10-07T14:54:53.966Z"
content_hash: "16ee32476876c953c29df229f4f7383f2637f4d78b46727280422af12188a084"
source_paths:
  - "Translation/src/components/screenUI/perfGuard.vue"
  - "Translation/src/App.vue"
  - "Translation/src/components/screenUI/left1.vue"
session_ids:
  - "74dc0f3b-711d-405e-a007-f06ff8025d48"
memory_body_ids:
  []
---

# Translation 智慧地铁：HUD 渲染环境检查卡 + left1 面板重叠修复

实现日期：2026-10-07，项目根 `D:\WebGIS\web三维开发\智慧地铁项目`，前端目录 `Translation/`，开发服务器 `http://localhost:5173/`。

相关文档：
- `91f97ed8-2a88-4141-8fbf-2c6cb97cecfa` —— 6 FPS 真根因（Windows 把 Chrome 丢给集显）+ 显卡偏好改法，本卡的文案与建议直接沿用其结论。
- `979eb2d7-7e66-4046-944a-52cd4f5c884c` —— 系统级光标皮肤 + 全屏沉浸模式（`screenState` store、`v-show` 隐藏 HUD），解释本卡为何必须挂在 `App.vue` 而不是 HUD 画布内。

---

## 一、启动渲染环境检查卡 `perfGuard.vue`

**文件**：`Translation/src/components/screenUI/perfGuard.vue`（新增，约 423 行：逻辑 + 样式）；挂载点在 `Translation/src/App.vue`（`<PerfGuard />`）。**选 `App.vue` 的原因**：它不受 HUD 全屏隐藏（`v-show="!immersive"`）影响，全屏时提示仍在。UI 用 `<Teleport to="body">`，规避 HUD 画布的 transform/缩放。

### 1.1 用户明确需求（2026-10-07）

> 「改成每次启动项目固定弹出」

即**不读任何"已忽略"标记**，刷新/重新启动必弹。「我知道了」**只在本次会话内收起**（不写 localStorage）；只有**低画质偏好**持久化（`dsh-low-quality`），下次启动自动应用，不用每次点。

### 1.2 行为与三态标题

- 读 GPU：`WEBGL_debug_renderer_info` → `UNMASKED_RENDERER_WEBGL`，分三类组织文案 —— **软件渲染 / 集显 / 独显**，各自给不同的"该改哪里"指引（软件渲染→查硬件加速开关与驱动；集显→Windows「设置 → 系统 → 屏幕 → 显示卡」添加浏览器并选「高性能」）。
- 挂载即弹卡，并**立刻**开始按 2 秒窗口用 rAF 采样帧率；卡内实时显示帧率，未出结果时写「测量中…」。
- **8 秒后才下结论**，且要求**连续 2 个窗口 < 24 FPS** 才判卡顿 —— 加载期帧率天然很低（独显实测刚启动仅 2 FPS），立即下结论会让每次启动都先闪一条"卡顿"再变正常。

| 阶段 | 标题 | 外观 |
|---|---|---|
| 刚弹出（帧率未出） | 渲染环境检查 | 金色科技风 |
| 8 s 后帧率偏低、复核未完成 | 帧率偏低，复核中… | 金色 |
| 复核确认卡顿 | 检测到画面卡顿 | **橙色警示配色** |
| 复核确认正常 | 渲染环境正常 | 金色 |

正常态文案：当前已在用独立显卡，渲染正常。若后续出现卡顿，可随时点右侧按钮切换低画质。

### 1.3 低画质开关

「启用低画质」= `resolutionScale 0.75` + 两个 tileset `maximumScreenSpaceError 16→32` + `maximumMemoryUsage 512`，可一键还原（还原回 1 / 16）。

- **故意不动 `bloom`**：`DayorNight.js` 夜间会主动开它，两边会打架；且既有实测中关 bloom 的收益在噪声内（参见 `91f97ed8`）。
- 开启 **4 秒后回填**卡内「→ 开启低画质后 N FPS」，让用户立刻判断值不值得开，而不是盲信。

### 1.4 两个坑（复用时直接照抄结论）

1. **`<Transition>` 离场时长在极慢环境会失控**：默认离场依赖浏览器帧回调，在 1 FPS 软件渲染环境里卡片点掉后 **5.9 秒**才真正从 DOM 移除。显式绑定 `:duration="{ enter: 280, leave: 160 }"` 后降到 **1.9 秒**（正常 60 FPS 机器约 0.2 秒）。只要组件可能跑在低帧率环境，就别让过渡时长靠帧反馈。
2. **8 秒延迟 + 连续窗口确认是必需的双重保险**，不是保守过头：实测独显机器启动瞬间也只有 2 FPS（瓦片流式加载期）。

### 1.5 实测（两种环境各一轮，均有据）

| 环境 | 表现 |
|---|---|
| 软件渲染（SwiftShader，必然触发） | 刚启动＝「渲染环境检查」+ 1 FPS；10 s 后＝「检测到画面卡顿」+ 橙色 + 软件渲染建议；点我知道了收起 ✅；刷新重新弹出 ✅；启用后 `resolutionScale 0.75` / SSE 32，关闭还原 1 / 16 ✅ |
| 独显（RTX 4070 Laptop，56 FPS） | 刚启动＝「渲染环境检查」+ 2 FPS；10 s 后＝「渲染环境正常」+ 56 FPS + 独显文案 ✅；两环境 `errors: []` |

**复现卡顿环境的命令**（独立 `user-data-dir`，不污染日常浏览器 localStorage）：

```powershell
& "C:\Program Files\Google\Chrome\Application\chrome.exe" --use-angle=swiftshader --enable-unsafe-swiftshader --user-data-dir="$env:TEMP\cg-test" http://localhost:5173/
```

### 1.6 可调常量（文件顶部）

`SLOW_FPS = 24`（卡顿阈值）、`SAMPLE_WINDOW_MS = 2000`、`SLOW_STREAK = 2`、`JUDGE_DELAY_MS = 8000`、`START_DELAY_MS`、`LOW_RESOLUTION_SCALE = 0.75`。想回到"只在卡时弹"，把 `hintVisible` 初值改成 `ref(false)`。

---

## 二、`left1.vue`（运营统计面板）数显牌压住线路列表

**症状**：右上角「年度安全运营 12185 天」数显牌与线路列表重叠，且列表底部汇总被裁。**约束（用户要求）**：不改变组件占屏尺寸，两者都要完整显示。

### 2.1 根因：不是定位问题，是"内容比容器高 + 居中双向溢出"

设计像素实测（基准 1920×1080）：`.card-body` 高 **166.7**，而右侧 `.routes-section` 需 **262.2**（6 行列表 211.6 + 底部汇总 40.6 + 间距），**多出 95.5px**。因为 `.card-body` 是 `align-items: center`，溢出**上下各摊一半**：

- 向上 48.7px → 盖住头部，正好压住数显牌（重叠 **200.2 × 37.7**，几乎整幅宽度）；
- 向下 ~47px → 被卡片 `overflow: hidden` 裁掉，列表底部汇总消失。

**教训**：HUD 面板里「内容高于容器 + `align-items: center`」会**双向溢出**，症状是"莫名压住头部"而不是常见的贴底裁切，比单纯 `overflow: hidden` 隐蔽得多——看到"元素跑到上面去了"先怀疑居中溢出，别先怀疑定位写错。

### 2.2 修法：外框一像素不动，只压缩内部竖向开销

外框保持 **398.4 × 233.3**（设计像素）不变。

| 位置 | 原值 | 现值 |
|---|---|---|
| `.card-header` padding | 10px 14px | 5px 14px |
| `.safety-counter` padding | 4px 10px | 2px 9px |
| `.card-body` padding | 8px 14px 10px | 6px 14px 8px |
| `.route-grid` row-gap | 8px | 4px（`align-content: center`） |
| `.route-item` padding | 2px 1px | 0 1px |
| `.route-header-info` margin-bottom | 4px | 2px |
| `.route-name` / `.route-mileage` 字号 | 11px / 10px | 10.5px / 9.5px |
| `.stats-footer` margin-top | 10px | 5px（+ 允许 `flex-wrap`） |

另给 `.card-body` 加 `overflow: hidden` 作兜底：线路再变多时宁可贴边收住，也绝不再往上盖住头部。

### 2.3 实测对比（设计像素）

| 指标 | 修复前 | 修复后 |
|---|---|---|
| 卡片外框 | 398.4 × 233.3 | 398.4 × 233.3（不变） |
| 头部高度 | 61.6 | 47.6 |
| 可用主体高度 | 166.7 | 180.7 |
| 数显牌 ∩ 线路网格 | 重叠 200 × 37.7 | **间距 15.5px（不重叠）** |
| 网格相对主体顶部 | 超出 48.7 | 内缩 9.5 |
| 网格相对主体底部 | 溢出被裁 | 内缩 48.9 |
| 18 条线路 + 底部汇总 | 汇总被裁 | 全部完整显示 |

截图证据（临时文件）：`%TEMP%\left1-top.png`、`%TEMP%\left1-bottom.png`。

### 2.4 可复用的量测方法

用 Playwright/CDP 注入脚本，对面板根、卡片、头部、数显牌、`.routes-section`、`.route-grid`、`.stats-footer` 逐个取 `getBoundingClientRect()`，**除以 `.hud-canvas` 实际宽度再乘 1920** 换算回设计像素（本次 scale ≈ 0.833），并直接计算两两矩形的重叠宽/高（负值＝有间距）。这套"量矩形 + 换算设计像素"能精确定位 HUD 里的重叠，比看截图猜尺寸可靠。一次性脚本用完即弃（`%TEMP%\left1-measure.mjs`）。
