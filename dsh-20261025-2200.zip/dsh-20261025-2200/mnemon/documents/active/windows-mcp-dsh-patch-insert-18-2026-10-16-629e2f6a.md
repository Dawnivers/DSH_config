---
id: "629e2f6a-92c3-400d-ba7f-777d7d432f4b"
title: "Windows-MCP 接入 DSH 实录：patch 层 - insert: 写法、18 个工具、遥测双保险（2026-10-16 已验证上线）"
description: "2026-10-16 把 Windows-MCP（CursorTouch，桌面/UI 自动化）真正接入 DSH desktop profile 的落地记录：patch 层新增条目必须用 - insert:（- id: 只覆盖既有条目）、改 patch 层热生效且 MCP server 会被重新 spawn、stdio 配置与 --exclude-tools 裁剪、18 个工具名、遥测双保险（ANONYMIZED_TELEMETRY + POSTHOG_API_KEY）、桌控门 relaxed 的使用边界；后续复用或排障 MCP 挂载时参考。"
status: "active"
created_at: "2026-10-16T11:29:51.663Z"
updated_at: "2026-10-16T11:29:51.663Z"
content_hash: "8779fae813fcffce276b66b0adef54e47c1993c2ca46a5075bd1de770318dacc"
source_paths:
  - "dsh-context7/cordis.patch.yml"
  - "dsh-archify/cordis.patch.yml"
session_ids:
  - "15526996-e924-45a3-a817-22463f23b49e"
memory_body_ids:
  []
---

# Windows-MCP 接入 DSH 实录（desktop profile）

日期：2026-10-16。承接《为 DSH 补「看见并操作原生窗口」的 MCP 选型调研：Windows-MCP 为首选（截至 2026-10-16 未安装）》（id `8ba56185-2c41-4c6d-8b5a-903a6ba284ea`）——那份文里还写着「未安装」和一份**待核实**的配置草稿；本文记录实际落地后的确定结论，并以本文为准。

结论：**已上线并实测可用**，全程未重启 DSH。我的工具表里多出 18 个 `mcp__windows__*` 工具。

## 1. 安装链路（每步都有实测返回）

| 步骤 | 结果 |
|---|---|
| `pip install uv` | uv **0.13.1** → `D:\python\Scripts\uv.exe`（`uvx.exe` 同目录） |
| `uv tool install windows-mcp` | **windows-mcp 0.8.8**，uv 自动拉托管 **Python 3.14**，未影响本机 3.10.10 |
| 可执行文件 | `C:\Users\林先语\.local\bin\windows-mcp.exe`（该目录不在 PATH；已装工具直接按绝对路径调用） |
| 包位置 | `%APPDATA%\uv\tools\windows-mcp\Lib\site-packages\windows_mcp`（**不是** `%LOCALAPPDATA%`） |
| 挂载方式 | `@deepseek-ai/dsh-mcp-client`，transport `stdio` |

**装前先做了一次真实握手**（不依赖"装完应该就行"）：`initialize` 返回 `protocolVersion: 2025-06-18`、`serverInfo: {name: windows-mcp, version: 4.1.0}`、capabilities 含 `logging/prompts/resources/tools`。

## 2. 关键坑与定论：patch 层怎么加新插件行

profile 补丁层：`C:\Users\林先语\.dsh\profiles\desktop\cordis.patch.yml`。

- **`- id: X` 只能覆盖/修改已存在的 entry。** 新增一条时写 `- id: mcp-windows` 会被忽略，并在 `--dump-config` 里报 `patch: entry "mcp-windows" not found`——不报错、不生效（很容易误以为已挂上）。同层的 desktop-shell / desktop-notifications 也有同样的 not found 噪音，属既有现象。
- **新增必须用 `- insert:` 形式**（顶层 list 元素是 `insert:`，其下缩进列 `- id:` / `name:` / `config:`），与本工作区里各插件自带的 `cordis.patch.yml`（如 `dsh-context7/cordis.patch.yml`、`dsh-archify/cordis.patch.yml`）写法一致。
- **改这个文件不需要重启 DSH**：DSH 热重载 patch 层。实测 19:28:35 改文件，19:28:41（6 秒后）宿主已把 `windows-mcp.exe` 换成新 PID——插件重载并重新 spawn MCP server。这与「手工改 package.json / node_modules 装插件必须重启」不矛盾：那是 loader 启动时才解析 bundles。

工作行（stdio 形态）：

```yaml
- insert:
    - id: mcp-windows
      name: '@deepseek-ai/dsh-mcp-client'
      config:
        serverName: windows
        transport: stdio
        command: 'C:\Users\林先语\.local\bin\windows-mcp.exe'
        args: ['serve', '--exclude-tools', 'PowerShell,Registry,FileSystem']
        env:
          ANONYMIZED_TELEMETRY: 'false'
          POSTHOG_API_KEY: ''
```

## 3. 工具面：暴露 18 个，裁掉 3 个重复项

工具名 `mcp__windows__<Name>`，共 18 个：Snapshot、Screenshot、DisplayInventory、App、Click、Clipboard、ControlStatus、Move、MultiEdit、MultiSelect、Notification、Process、Scrape、Scroll、Shortcut、Type、Wait、WaitFor。

`Snapshot`/`Screenshot` 未出现在早先按模块文件的粗扫里（它们在 `tools/snapshot.py`），权威名要直接取 `@mcp.tool(name=...)`，别按文件名猜。

用 `--exclude-tools PowerShell,Registry,FileSystem` 砍掉了它自带的 `PowerShell` / `Registry` / `FileSystem`——这三个与 DSH 已有满权限 `pwsh` 工具完全重复，留着只是多开一道口子。实测工具表里确实没有它们（进程命令行亦为 `windows-mcp.exe serve --exclude-tools PowerShell,Registry,FileSystem`）。

## 4. 遥测：双保险（不要只设一个）

- `ANONYMIZED_TELEMETRY=false` **确实被认**，在 `windows_mcp/__main__.py:324` gate 住 `PostHogAnalytics()`——注意它不在 `analytics.py` 里，只 grep `analytics.py` 会误判为「空炮」。
- 但 `infrastructure/analytics.py` 的 `POSTHOG_API_KEY` **默认值是硬编码的真实 PostHog key**，上游改个变量名就会漏。
- 所以同时设 `POSTHOG_API_KEY: ''`，走源码里「空值即不初始化客户端」的分支。

## 5. 使用边界（沿用并收紧早先的风险评估）

- 桌控门默认 **relaxed**：需桌面空闲约 10 秒才允许直接输入，用户一动鼠标即被感知并让位。**不关它。**
- **不主动接管用户的键鼠**；动手前先说清要做什么、动哪里。
- 截图 / Snapshot 覆盖**整块屏幕**（不限某个应用），所以除非用户明确要求，不抓。
- 实测环境：单显示器 `\\.\DISPLAY5` 2560x1440 主屏，工作区高 1392（任务栏 48px），DPI 96 / 100%。`ControlStatus` 返回 `{"state":"ready","generation":1,"wait_seconds":0.0}`。
- 偏好用 `Snapshot`（返回**文本化 UI Automation 树**）而非 `Screenshot`：对文本模型可直接读控件树并按元素名定位，不用绕图片桥。

## 6. 相关文档

- 同主题前置选型调研（含 PowerShell.MCP 为何属重复的论证）：id `8ba56185-2c41-4c6d-8b5a-903a6ba284ea`。
- DSH MCP 客户端接线字段与 `mcp__<serverName>__<tool>` 命名：见《DSH 代码索引/上下文方案选型调研：原生插件 vs MCP 桥接》id `4b7d494f-5c4b-4c71-8ea5-80f19359a2cb`（该文明确不重复记录，指向运行时记忆）。
