---
id: "0a444300-3a3d-4461-9e4c-f6a7162e5428"
title: "Translation 发展历程播放循环的实现细节：rAF 时序模型（dt×SPEED 而非每帧 +0.1、0.1s 封顶、两处 rAF 分工）+ flat[k*2] 扁平坐标约定 + applyFrame 的幂等契约与 4 个调用点"
description: "发展历程播放动画的时钟与结构层补充：rAF 两处分工、dt×SPEED 与 0.1s 封顶的帧率无关性（本项目常掉到 9FPS）、play/pause/replay 防双链、applyFrame 幂等契约与 4 个调用点、以及扁平坐标 flat[k*2] 与 cart[k] 两种下标约定的对照。"
status: "active"
created_at: "2026-10-13T01:15:45.972Z"
updated_at: "2026-10-13T01:15:45.972Z"
content_hash: "7d5160d59b3c685893dda82f6ec34bc587a2a2a40313eab66d0f9ca8c538a3f0"
source_paths:
  - "Translation/src/components/bottom/HistoryPanel/historyPanel.vue"
  - "Translation/src/cesiumTools/lineAndpoints/line/setlines.js"
  - "Translation/src/components/screenUI/left1.vue"
  - "Translation/src/config/shmetroHistory.js"
session_ids:
  - "3fffc5b5-c6b3-41e9-970f-236124d47417"
memory_body_ids:
  []
---

# 发展历程播放循环：实现细节与约定（Translation / 智慧地铁）

日期：2026-10-13。项目：`D:\WebGIS\web三维开发\智慧地铁项目`。
文件：`Translation/src/components/bottom/HistoryPanel/historyPanel.vue`（`tick` L248-262、`pause` L264、`play` L273、`replay` L283、`applyFrame` L229）。

## 0. 与既有文档的关系（本文只补它们没有的）

- 生长动画本体、range 插值、站点→坐标映射、4 号线环线、3 个真 bug：`bed0b7b7-e1e3-491b-80bd-51ffa66f4956`
- `cur` 逐帧数值工作例（1 号线实测映射表、`ceil`/`floor+1` 语义、边界兜底）：`c5d63b61-caf7-4516-b11e-7758e9425f5a`
- 面板外壳、路由与数据集：`34066e27-5ad4-41df-8448-8029411158f8`

本文补的是**时钟/时序模型、rAF 结构、坐标数组的两种下标约定**这三件既有文档没写的事。

## 1. rAF 循环的骨架：两处 `requestAnimationFrame`

```js
const tick = (ts) => {
  if (!playing.value) return;
  if (!lastTs) lastTs = ts;
  const dt = Math.min(0.1, (ts - lastTs) / 1000);
  lastTs = ts;
  currentTime.value = Math.min(max.value, currentTime.value + dt * SPEED);
  applyFrame();
  if (currentTime.value >= max.value) { playing.value = false; rafId = null; return; }
  rafId = requestAnimationFrame(tick);
};
```

两处 `requestAnimationFrame(tick)` 是**标配而非重复**：

| 位置 | 角色 |
|---|---|
| `play()` L280 | **点火** —— 循环之外的第一帧，唯一来源 |
| `tick()` 末尾 L261 | **续航** —— 每帧末尾给自己排下一帧，形成循环 |

`requestAnimationFrame` 是**一次性**的「下次重绘前把 cb 调一次」，不会自动重复。少了 `play()` 那处：没有第一次 → `tick` 永不执行 → 末尾那行也永不执行（死循环般的不启动）。少了 `tick` 末尾那处：只播一帧就停。

两处都赋值给 `rafId`，因为它的语义是**「当前那个尚未执行的帧」的 id** —— 每产生新待执行帧就更新，`pause()` 才能取消到正确的那个；走完全程置 `rafId = null` 表示「无待执行帧」。

`tick` 被 `playing.value` 早退守卫（L249）兜住：`cancelAnimationFrame` 只能退掉尚未派发的号，已派发的那一帧取消不掉，需要它自己退场。

## 2. 时序模型：`dt × SPEED` 而不是「每帧 +0.1」

```js
const UNIT = 10;   // 一个里程碑占 10 个时间单位
const SPEED = 6;   // 单位/秒
```

- `ts` 是浏览器给的 `DOMHighResTimeStamp`（页面加载至今的毫秒**绝对**时间戳，不是帧间隔），所以第一帧必须 `lastTs = ts`，否则 `ts - lastTs` 会等于「页面已加载多久」→ 动画直接跳到终点。`lastTs = 0` 兼作「尚未计时」哨兵（`pause()` 重置为 0）。
- 除以 1000 让 `SPEED` 的单位是「单位/秒」。
- **`Math.min(0.1, …)` 封顶**：切后台 30 秒回来时首帧 `dt = 30s` → 一帧跳 `30×6 = 180` 个单位（1 号线 `max` 才 60）→ 线瞬移到终点。封顶后单帧最多 `0.6` 个单位。

**为什么不用课程参考项目的 `currentTime.value += 0.1`**：那把时长与帧率绑死。1 号线 `max = 60` 需 600 帧 → 60FPS 是 10 秒，30FPS 是 20 秒，而**本项目近景/瓦片加载/低画质时常掉到 9 FPS**，照搬会慢到 67 秒。改成 `dt × SPEED` 后时长与帧率无关：`60 ÷ 6 = 10 秒`。
巧合：60FPS 下 `(1/60)×6 = 0.1`，所以两种写法在满帧时数值完全相同 —— 这也是当初照抄看不出问题的原因。

`Math.min(max.value, …)` 把 `progress = currentTime / max` 封在 1，时间轴填充条不会冲出最后一个圆点。

**已知取舍**：单次卡顿超过 100ms 时那段时间被「丢掉」，总时长略偏长。这是故意的 —— 宁可时长略有偏差，也不要卡顿后瞬移一大段。要严格等时需改成按真实时间戳定位（`currentTime = (now - startTs)/1000 × SPEED`），代价是卡顿后线会跳一大段。

参数实测：1 号线 7 个里程碑 `max = 60`（10.0 秒）、11 号线 8 个 `max = 70`（11.7 秒）、14/15 号线只有 1 个里程碑 `max = 0` → `play()` 首行即 return，**不启动 raf**，直接显示全线。改快慢只调 `SPEED` 一个数（12 → 5 秒）。

## 3. 三个循环入口的分工（防重复起播）

- **`play()` 开头先 `pause()`** —— 连点两次播放会产生**两条 raf 链**，同一帧里 `tick` 被调两次、两次拿到**相同的时间戳**，于是每帧推进两次 → 动画 2 倍速且 `cur` 抽搐。（同一帧内调 N 次 rAF 不会推进 N 帧，只会在下一次重绘前回调 N 次。）
- **`pause()` 里 `lastTs = 0`** —— 下次 `play()` 首帧 `dt = 0`，不会因「暂停了很久」跳一大步。
- **`replay()` = `pause()` → `currentTime = 0` → `applyFrame()` → `play()`** —— 立刻缩回起点，不等下一帧。
- 终止判断必须放在 `applyFrame()` **之后**：末帧 `currentTime` 被夹到正好等于 `max`，这一帧才画得出完整那条线（1 号线 337/337）；判断提前则最后一段永远差一帧画不满。
- `rafId = requestAnimationFrame(tick)` 挂末尾：中途抛错时不会留下已排队的野循环。
- `teardownGrowth()` 首行也是 `pause()` —— 换线/离开栏目先停心跳再拆实体。

**可选的简化写法**（本实现**没有**采用）：让 `play()` 直接 `tick(performance.now())`，全文只剩一处 rAF。不采用的两个理由：①时序会变 —— 点击处理函数里立刻切 `cur`，把「算」和「画」揉进同一任务；②语义统一 —— 现在所有帧的 `ts` 都来自浏览器，无需自造 `performance.now()`。

**与 Cesium 渲染循环的关系**：两条独立时钟，互不同步。`tick` 只写 `cur`，Cesium 在自己的循环里通过 `CallbackProperty` 的 getter 读。Cesium 多渲染一帧或 rAF 漏一帧都不会错乱，只是同一份 `cur` 被读了两次或一次没换。

## 4. `applyFrame` 的幂等契约与 4 个调用点

`applyFrame()`（L229-246）是**「`currentTime` → `cur`」的唯一翻译器**，整个动画只有它真正改变可见内容。三不：不碰 Cesium API、不改 `currentTime`、除写 `cur` 外无副作用 —— 于是它**幂等**：同一 `currentTime` + 同一 `geom`，调一次和调十次结果一样。这正是它敢被重复调用的原因（`replay` 里 `applyFrame → play → applyFrame` 连调两次完全无害）。反过来说：**若把推进时间的逻辑写进 `applyFrame`，多调一次就会多播一帧。**

4 个调用点及各自理由（grep：L256 / L279 / L287 / L376）：

| 调用点 | 为什么必须有 |
|---|---|
| `tick` 每帧 | 主路径 |
| `play` 起播前 | 「播完再点播放」时 `currentTime` 重置为 0 但 `cur` 还是满线；不算一次，从点击到首帧 rAF 回调的约 16ms 内会**闪一下满线** |
| `replay` 归零后 | 同上且更明显 —— 用户要看的就是「从头开始」那一下 |
| `setupGrowth` 挂属性前 | 必须先算好 `cur`，否则 `CallbackProperty` 首次取值读到上一条线路残留的 `cur`（换线）或空数组 |

代价：一次 `slice` + 十几次浮点运算，微秒级，60fps 下可忽略。

## 5. 坐标数组的两种下标约定（最容易混的地方）

同一条线的点位在**两个数组里下标含义不同**：

| 数组 | 形态 | 点 k 在哪 | 长度（1 号线） |
|---|---|---|---|
| `line.positions` / `flat` / GeoJSON 压平结果 | 扁平数字数组，经度纬度交替 | `[k*2]` 经度、`[k*2+1]` 纬度 | **674** = 点数 337 × 2 |
| `geom.cart` | `Cesium.Cartesian3[]` 对象数组 | `[k]`（**没有 ×2**） | **337** = 点数 |

1 号线前 4 点实测（`flat[0..7]`）：

```
k=0  flat[0]=121.4194366 (lng)  flat[1]=31.395478  (lat)
k=1  flat[2]=121.4200409        flat[3]=31.3933626
k=2  flat[4]=121.4200952        flat[5]=31.3931577
k=3  flat[6]=121.4201789        flat[7]=31.3929003
```

因此逐点距离循环里 `nPt` 是**点数**（337）而非数组长度（674）：

```js
for (let k = 0; k < nPt; k++) {
  const dx = (flat[k * 2] - lng) * cosLat;
  const dy = flat[k * 2 + 1] - lat;
}
```

**为什么必须扁平**：`Cesium.Cartesian3.fromDegreesArray(arr)` 的入参按 `[lng, lat, lng, lat, …]` 排列，不吃 `[[lng,lat],[lng,lat]]` 嵌套格式。压平发生在 `left1.vue:55-59`：

```js
const flattenCoords = (coords) =>
  coords.reduce((flat, [lng, lat]) => {
    if (Number.isFinite(lng) && Number.isFinite(lat)) flat.push(lng, lat); // 先经度、后纬度
    return flat;
  }, []);
```

**先 push 经度、再 push 纬度** —— 这个顺序决定了上面的奇偶对应，写反则全错位。

另两处 `×2` 的语境分辨：

- `applyFrame`/`buildGeometry` 开头的 `if (!flat || flat.length < 4)` —— `4` 是「**2 个点**」，折线少于两点 Cesium 抛错。同一守卫见 `Translation/src/cesiumTools/lineAndpoints/line/setlines.js:16`。
- `shmetroHistory.js` 头注释里的 `const cur = coords.slice(lo0 * 2, (hi0 + 1) * 2)` —— 那是**「直接切扁平数组再丢给 `fromDegreesArray`」的路线**，所以有 ×2。**实际实现走的是另一条**：先 `fromDegreesArray(flat)` 一次性转成 `cart`，再 `cart.slice(a, b)`，因此实现里没有 ×2。两条路都对，区别是：切扁平数组要多一次每帧 `fromDegreesArray` 转换（每帧新建 337 个对象，11 号线 816 点 @60fps 每秒近 5 万个）；切 `cart` 则对象复用，只换数组壳 —— 采用后者。（注释易被误读为实现里有 ×2，宜标注「扁平路线」。）

## 6. 与既有实现的边界

- `currentTime`、`playing` 是 `ref`（要驱动模板）；`cur`、`geom`、`growthEntity` 是普通 `let`（`ref` 的 `Proxy` 会破坏 Cesium 的引用比较）—— 详见 `c5d63b61-caf7-4516-b11e-7758e9425f5a`。
- `teardownGrowth` 的「**先 remove 实体、再置 `geom = null`**」顺序保证 getter 不会在实体存活时读到 `[]`。
- `max = 0` 的线路（14/15 号线）永不启动 raf，是「无动画」而非 bug。
