---
id: "73fed651-a082-4abb-b150-7d3f4e9426f7"
title: "Translation 发展历程（迭代3）：ENTRY_VIEW 真实六参数定稿 —— 从用户截图探针取值、实测生效与刷新重置相机的操作顺序"
description: "2026-10-12 智慧地铁 Translation：固定入场视角 ENTRY_VIEW 由「null／假值」落定为真实值（lon 121.358358 / lat 31.129985 / height 130698.98 / heading -1.0786 / pitch -83.5848 / roll 0.0399）；关键路径是从用户标签页内的临时探针文字（截图/浏览器桥）取值，因刷新会把相机重置回默认视角；含前后相机对比实测、探针已从 DOM 摘除的复查、以及 height 单一调参点。前置于 409be846 / b366e21c。"
status: "active"
created_at: "2026-10-12T11:03:32.943Z"
updated_at: "2026-10-12T11:03:32.943Z"
content_hash: "b1ecdc25711b4ee690f4ca0317d9e188bd0d49c4d22d0c87939d4fc73035b916"
source_paths:
  - "Translation/src/components/bottom/HistoryPanel/historyPanel.vue"
session_ids:
  - "17b9d450-66f5-4279-8728-07b784da638a"
memory_body_ids:
  []
---

# ENTRY_VIEW 定稿：固定入场视角填上真实值

日期：2026-10-12。项目：`D:\WebGIS\web三维开发\智慧地铁项目\Translation`。
改动文件仍然只有一个：`Translation/src/components/bottom/HistoryPanel/historyPanel.vue`。

本文承接：
- `409be846-4517-43eb-9e36-134353f682bc` —— 把「按线路包围球飞行」纠正为**固定参数回放**，定义了 `ENTRY_VIEW` 六参数与 `entryViewApplied` 一次性触发；该文停在 `const ENTRY_VIEW = null;` 与假值验证。
- `b366e21c-881e-4624-8050-c8e9e97ec779` —— 其第 2 节（按线路自动取景）已被 `409be846` 纠正，第 1、3 节（生长线补亮、连续进度条）仍然有效。

## 1. 最终值（真实相机参数）

```js
const ENTRY_VIEW = {
  lon: 121.358358,
  lat: 31.129985,
  height: 130698.98,
  heading: -1.0786,      // 探针归一化到 ±180°，等价于 Cesium 原始的 358.9214°
  pitch: -83.5848,
  roll: 0.0399,
  duration: 1.6,
};
```

这是 **130 km 高、近乎正俯视**的视角，1 号线在其中只占中间一小块。
`height` 是唯一的「线太小」调参点：调到 40000 就贴近很多，其余五个值不用动。

## 2. 关键路径：真实值是从**用户标签页里的探针文字**取的

这一轮反复卡的根因不是代码，而是**取值通道**：

1. 用户不在同一个进程里，拿不到他的相机；
2. **刷新会把相机重置回默认视角** —— 所以「请用户刷新再拖到想要的视角」这条顺序是反的，先刷新就把用户已经调好的视角抹掉了；
3. 正确顺序是**先取值、后刷新**：趁页面 viewer 还活着，从面板内临时探针（`CAMPROBE {...}` 一行小字）读；
4. 本轮实际就是从用户提供的截图里读到探针文字，原样填入 `ENTRY_VIEW`。

其他要点沿用 `409be846` 第 3 节：探针必须放在**面板内可见处**（被父级 `clip-path` 裁掉时只读出 `CAMPROBE (waiting)`）；
DevTools 方案只返回 JSON 标量（直接返回 Cesium 对象会 `Cannot serialize result: object reference chain is too long`），heading 归一化用 `((deg + 540) % 360) - 180`。

## 3. 探针是脚手架，必须摘掉

用户明确反馈「并没有完成跳转，反而在画面上加了奇怪的数据显示」。
两条教训：
- `ENTRY_VIEW = null` 时整个飞行是 no-op，**留空等于没做**，不能把「等填值」当成已交付；
- 取值脚手架（临时探针、调试字）一旦拿到数就应删除，**不许留在页面上**。

摘除后复查实测：`{"probeInDom":false,"camProbeText":false,"panel":true,"lines":18,"btns":"暂停/播放/重新播放","lineEnts":19,"shown":1,"dyn":1,"barW":339.6}` —— DOM 无 `.cam-probe`、页面文本无 `CAMPROBE`，面板与生长动画均正常。

## 4. 定稿后的实测断言

| 时刻 | 相机 lon / lat / height / heading / pitch |
|---|---|
| 首页（默认视角） | 121.4582 / 31.2705 / **4 822** / 131.2 / -45.35 |
| **进入发展历程后** | 121.3584 / 31.13 / **130 699** / -1.08 / -83.58 ← 与 `ENTRY_VIEW` 完全一致 |
| 再切到 18 号线 | 121.3584 / 31.13 / 130 699 / -1.08 / -83.58 ✅ **相机没再动** |

第三行是本轮的核心断言不变：**换线路不触发相机飞行**，飞行只在从别的路由切进 `/strategy` 时发生一次。

顺带复查保持正常：面板 18 条线路 + 三个按钮、动态实体 1 条、可见线路 1 条、进度条在填充、无新增报错。
（三处验证脚本运行时的 400 Bad Request 在改动前后一直存在，是既有的无关噪声。）

## 5. 验证方法论（本轮直接可用）

- 探针/脚本只输出 **JSON 标量**，逐项比对相机六参数与 `ENTRY_VIEW` 是否一致；
- 用「再切一条线路相机是否变化」作为**负向断言**，确认触发时机绑定的是路由而不是线路；
- 用例后段固定复查「离开栏目」清理：动态实体 0 条、线路实体 18 条、18 条全部还原显示。

成品截图：`.review/entry-view-final.png`。
