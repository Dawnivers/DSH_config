---
id: "3fe1947f-509c-4def-b914-757bbb86722b"
title: "/realtime 列车漫游：handleTick 每帧入口拆解 + 停站朝向失效改自算方向（VelocityOrientationProperty 坑）"
description: "trainRoam.js 落地后的两处关键实现知识：① VelocityOrientationProperty 在停站（前后位置相同）时返回 undefined 导致车头扭向正东，改为按采样自算行进方向 + rotationMatrixFromPositionVelocity；② handleTick 五段职责、为何挂 clock.onTick、offset 折返、位置需 clone 后才可外传、以及\"到站无逻辑只见采样表\"的分工；附带变量重命名漏改（Vite 编译期不报）的教训与当前调参值。"
status: "active"
created_at: "2026-10-17T12:59:55.685Z"
updated_at: "2026-10-17T12:59:55.685Z"
content_hash: "85555ec6e6a8845e7173ea676cd98109346622c7d73acf3c8e50dcad49a14b2a"
source_paths:
  - "Translation/src/cesiumTools/lineAndpoints/train/trainRoam.js"
  - "Translation/src/cesiumTools/lineAndpoints/train/trainSchedule.js"
  - "Translation/src/components/bottom/RealtimePanel/RealtimePanel.vue"
session_ids:
  - "083c2a72-1b42-4f8a-bda3-978d3b89c8f5"
memory_body_ids:
  []
---

补充 `6ec9d498`（addSample 时间按引用）、`7f1a6f08`（RoamTool 内核与"不保存派生状态"纪律）、`295948a0`（调参地图）三篇的落地实现层知识。

源文件：`Translation/src/cesiumTools/lineAndpoints/train/trainRoam.js`、`trainSchedule.js`、`components/bottom/RealtimePanel/RealtimePanel.vue`

## 1. 朝向不能用 `VelocityOrientationProperty`

**症状**：列车到站瞬间车头扭一下（转向正东），出站又扭回来。

**根因**（Cesium 1.97 `VelocityVectorProperty.js:184`）：它取 `time ± 0.5s` 两个位置做差求速度方向；两点相等时**直接 `return undefined`**。而停站那段的采样位置本来就完全相同（站点处 arrive/leave 两个同位置采样，见 `6ec9d498`），于是该时刻 `entity.orientation` 为 `undefined`，`ModelVisualizer` 退回默认 ENU 朝向 —— 正东。

**解法**（`trainRoam.js` :153-232 附近，注释里保留了上述根因）：
1. 按采样点预先算每个区间的行进方向向量；**停站区间继承进站方向**（`let carry = null` 向后传递），保证方向永远非零；
2. 用 `Cesium.Transforms.rotationMatrixFromPositionVelocity(position, direction, ellipsoid, result)` 换成四元数；
3. 整体做成 `new Cesium.CallbackProperty((time, result) => {...})`，`position = sampledProperty.getValue(time, this._orientationPos)`，`direction = this.directionAt(time)`，任一为空返回 `undefined`。

**`directionAt(time)`**：`secondsDifference(time, this.startTime)` 得到相对秒数，在 `_sampleTimes` 上二分找最后一个 `<= t` 的区间取 `dirs[lo]`。
关键容差 `+1e-3`：JulianDate 来回换算秒数有 1e-9 级误差，正好落在采样时刻时会被判成"上一段"，到站那一帧就会多转几度。二分比较写成 `times[mid] <= t + 1e-3`。

跑动观感与 `VelocityOrientationProperty` 完全一致，只是停站期间稳稳保持进站朝向。

## 2. `handleTick`：唯一的每帧入口，27 行分五段

```js
handleTick() {
  const clock = this.viewer.clock;
  ① if (this.intent === 'paused' && clock.shouldAnimate) clock.shouldAnimate = false;
  ② if (!this.schedule || !this.entity) return;
  ③ const t = Cesium.JulianDate.secondsDifference(clock.currentTime, this.startTime);
     const offset = ((t % this.schedule.total) + this.schedule.total) % this.schedule.total;
  ④ const position = this.entity.position.getValue(clock.currentTime, this._position);
     if (position) {
       if (this.followMode === 'follow') this.applyFollow(position);
       else if (this.followMode === 'third') this.applyThirdPerson(position, clock.currentTime);
     }
  ⑤ this.onUpdate?.({ t: offset, raw: t, ...locate(this.schedule, offset),
                       position: position ? Cesium.Cartesian3.clone(position) : null });
}
```

**① 顶住强制续播**：`intent='paused'` 由面板按钮设置，但复制版 `timeline.js:800-802` 的 `createMouseUpCallback` 会无条件 `shouldAnimate = true`。不改那份复制源码，而是每帧压回去，否则表现为"点暂停 → 随手拖时间轴 → 松手继续跑"。

**② 空值保护**：`destroy()` 之后、下次 `load()` 之前、线路数据未到时 `onTick` 仍可能触发。

**③ offset 折返**：`clockRange = LOOP_STOP`，到终点时钟直接跳回起点，`t` 会从 2320 突变为 0；拖到 `startTime` 之前 `t` 为负，JS 的 `%` 也返回负。外层 `+total` 再取模才落到 `[0, total)`。`raw` 原值一并给面板，便于看"第几圈"。

**④ 查位置 + 摆相机**：`SampledPositionProperty.getValue` 本质是二分 + 线性插值 —— 位置本来就是时间的函数，拖时间轴自动正确。第三参 `this._position` 是构造时 new 一次的复用容器，避免 60 次/秒分配。因为每帧都 `lookAt`，所以必须同时关掉 Cesium 自带相机交互，否则拖一下下一帧被覆盖（"拖一下弹回去"）。

**⑤ 回报面板**：`locate()` 在 `stationTimes` 上二分返回 `{index, inStation, progress, stationName}`；`position` **必须 clone**，因为 `_position` 每帧复用，直接外传会让面板存下的引用下一帧被改写，气泡跟着抖。

**为什么挂 `clock.onTick` 而不是 `scene.postRender`**：要的就是 `clock.currentTime`；且 `Core/Clock.js` 里 `Clock.tick` 的 `onTick.raiseEvent` 是**无条件执行**的，暂停时也每帧触发 —— 所以拖时间轴那一刻（`shouldAnimate=false`）面板高亮照样跟手，不会"拖时不动、松手才跳"。

**关键分工**：`handleTick` 里没有任何到站判断、没有 `setTimeout` —— 停站已烘焙进采样表（同顶点 arrive/leave 两采样）。因此拖动、反向、循环都不需要额外代码，它们只是从不同位置查同一张表。

**每帧代价**：1 次时间差 + 1 次取模 + 1 次采样查表（二分）+ 1 次 `lookAt` + 1 次 `locate` 二分 + 1 次 clone，全 O(log n)，60 FPS 无感。

## 3. 修过的一个真实故障：变量重命名漏改

把 `sampled` 改名为 `sampledProperty` 却只改了声明，三处引用未跟上：`sampled.getValue(...)`、`position: sampled`、`this.sampled = sampled`。
后果：`load()` 一执行就 `ReferenceError`，整段挂掉（列车不出现、面板不动）。
**难点**：读未定义变量在 JS 里是运行时错误、语法合法，**Vite 编译期不报、编辑器不标红、build 通过**，只有真进到栏目里才暴露。查这类问题要全文 grep 旧变量名，别只信编译器。

## 4. 当前采用的采样写法（已定稿）

```js
const sampledProperty = new Cesium.SampledPositionProperty();
schedule.samples.forEach((sample) => {
  const JulianTime = Cesium.JulianDate.addSeconds(startTime, sample.t, new Cesium.JulianDate());
  sampledProperty.addSample(JulianTime, cartesians[sample.vi]);
});
```

每轮新建一只 JulianDate，绕开"复用草稿 + clone"的坑（原因见 `6ec9d498` §4），可读性更好。循环里补了注释说明**为什么必须每轮新建**，防止后人当"多余分配"优化掉 —— 那种改动不报错，只会让 360 个采样落在同一时刻、列车静止或消失。
坐标不用 clone：`addSample` 内部 `innerType.pack` 把 `Cartesian3` 拆成 x/y/z 按值存。

## 5. 调参值（本次实测快照，供对照）

| 项 | 位置 | 值 | 说明 |
|---|---|---|---|
| `TRAIN_SPEED` | `trainSchedule.js:44` | 16.7 | 仿真 m/s，站点匹配与到发时刻用它 |
| `TRAIN_DWELL` | `trainSchedule.js:46` | 4 | **仿真秒**，墙钟 = `dwell / multiplier`（换算见 `6ec9d498` §2）；面板 `RealtimePanel.vue:199` 调 `load()` 未传 `dwell`，故生效值即该常量 |
| `WALL_SECONDS` | `trainRoam.js:47` | 290 | 全线跑完的墙钟秒数，唯一速度开关 |
| `TRAIL_METERS` | `trainRoam.js:50` | 3000 | 尾巴长度，按米换算 `trailTime` |
| `scale` | 实体 `model.scale` | 5 | 该 glb 节点自带 0.01 缩放；刻意不设 `minimumPixelSize/maximumScale`（包围球就绪前会算出极端倍数） |

自洽校验：28 站 → 运行 2212.68s + 27×4s 停站 = **2320.68s 总时长**，`multiplier = max(1, total / WALL_SECONDS)`；1 号线 337 顶点 → **360 采样**；页面实体 419（418 基线 + 1 列车），`pageerrors` 为空。

## 6. 遗留小项

- `trainSchedule.js:182` 有调试草稿注释 `//[340s,(111,22)]`，可删；
- `this.sampled` 只赋值与 `destroy` 里置 null，无人读取，留作防 GC 亦可。
