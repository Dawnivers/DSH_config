---
id: "06177dd0-801f-488a-9ec4-6a1e0cefb741"
title: "Translation 智慧地铁：线路级整行开关与「行状态不可由共享站点反推」——lineStationOn 线路开关的由来与残留取舍"
description: "2026-10-10 承接 b193f736 的「写 show」模型后的迭代：点整行线路=整条站点亮/灭，行高亮先从 every 改 some 修连坐变灭、又引出全灭下点 1号线时换乘站反推导致其它线路跟着变亮，最终新增 stationState.js 的 lineStationOn 线路级开关，含实测数据与「共站只有一份开关、最后点的线路说了算」的残留取舍。"
status: "active"
created_at: "2026-10-10T11:10:16.729Z"
updated_at: "2026-10-10T11:10:16.729Z"
content_hash: "abfcd3dc12c03d32098190e13b05fda11f7e83195b0cbe32ae7427b2ca014a16"
source_paths:
  - "Translation/src/stores/stationState.js"
  - "Translation/src/components/screenUI/StationPanel.vue"
  - "Translation/src/components/screenUI/Toolbar.vue"
  - "Translation/src/cesiumTools/lineAndpoints/points/setpoints.js"
  - "Translation/src/cesiumTools/lineAndpoints/line/setlines.js"
session_ids:
  - "15772b60-48dd-4646-912c-a07581fc729b"
memory_body_ids:
  []
---

# Translation 智慧地铁：线路级整行开关与「行状态不可由共享站点反推」

日期：2026-10-10。本文承接 `b193f736-9678-4340-b1f0-5e763faf3a7e`（站点显隐改为「照抄线路的写 show」模型：新增 `hideStationByName`，删掉 owners / 隐藏集合 / computed 同步）之后的迭代，因此那套写 show 模型、`markRaw` 必要性、`stationObjs` 结构均不再重复，直接沿用。

相关文档：
- `b193f736-9678-4340-b1f0-5e763faf3a7e` —— 前置重构（写 show 模型、删 owners）
- `3a0ce399-303d-4a00-95ef-e3c3d0db18af` —— StationPanel / stationState 的落地与两个响应式 bug
- `8d3c4c05-ec6a-4bb9-98de-8a40750572a5` —— 光锥/光圈渲染链路与性能实测（本文不改渲染链路）

## 1. 用户需求与本轮范围

用户在写 show 模型落地后提了两条：

1. 「优化显隐逻辑：点击右侧面板的线路时，左侧站点应全部亮起/熄灭，**无所谓换乘站**」——即线路级操作不做换乘站特判。
2. 随后报了一个回归：「在所有线路都没被选中的场景下，点击面板中的 1号线，有共同站点的其他线路也跟着亮起来了，这是不对的，只需要 1号线亮起」。
3. 用户对开关函数落点的既有约束（同样适用于本轮）：**仿照线路数据的开关定义，把隐藏站点的函数定义在 `setpoints.js` 里，不要搞得那么复杂**。

“无所谓换乘站”是明确的项目级取舍：换乘站只有一份开关，跟着哪条线点就听谁的，不引入归属集合去判断“是否还有别的线亮着”。

## 2. 改动一：线路行从「小勾选框」改成整行按钮

症状是“点了没生效”，其实只有 12×12 的勾选框可点，点线路名只切换右栏焦点。

```html
<!-- 改前：一行两个按钮，只有方块是开关 -->
<div class="sp-line">
  <button class="sp-check" @click.stop="toggleLine(line)"></button>
  <button class="sp-line-name" @click="focusedLine = line.name">3号线</button>
</div>

<!-- 改后：整行一个按钮 -->
<button class="sp-line" :class="{ 'is-on': lineLit(line) }" @click="toggleLine(line)">
  <span class="sp-check"></span><i class="sp-chip"></i><span>3号线</span>
</button>
```

`toggleLine` 同时做三件事：切右栏焦点、写站点 `checked`、调 `hideStationByName` 落到三维；整条熄灭时该行名字与色块一起压暗。

## 3. 改动二（核心结论）：行状态不能由共享站点的标志位反推

这是本轮最重要的教训，**两个方向都会错**：

| 行判定写法 | 出现的假象 | 原因 |
|---|---|---|
| `every`：名下站点全部亮才算亮 | 点灭 3号线后，左栏 18 行里 **13 行**跟着变灭（实测 `灭灭灭灭亮亮灭灭灭灭灭灭灭灭灭亮亮灭`） | 3号线与 1/2/4/7/9…号线共用的换乘站被一起关掉，那些线不再满足“全部亮” |
| `some`：名下至少一个站亮就算亮 | 全灭状态下点 1号线，**其它线路行也跟着变亮** | 1号线 28 站里有 12 个换乘站（人民广场、上海火车站、徐家汇…）同属 2/3/4/7/8…号线，那些线“还有亮着的站”成立 |

根因一句话：**换乘站只有一份开关，行状态若从共享标志位反推，必然连坐**——`every` 连坐变灭，`some` 连坐变亮。

修法：给每条线路一份自己的开关，行状态只认它。

```js
// stationState.js —— 新增
const lineStationOn = reactive({});   // 线路名 → 该线路的站点是否亮着

// StationPanel.vue
const lineLit = (line) => lineStationOn[line.name] !== false;  // 只读自己的开关

const toggleLine = (line) => {
  const next = !lineLit(line);
  lineStationOn[line.name] = next;                 // 线路开关 → 决定行的显示与点击行为
  const names = lineStationNames(line);            // 过滤成“确实有三维对象”的站名
  names.forEach((name) => { const t = stationByName.value.get(name); if (t) t.checked = next; });
  hideStationByName(stationObjs, names, next);     // 落到三维
};
```

职责划分：**线路开关**决定行的高亮与“点一下会发生什么”，**站点开关**负责单站精细开关。两者自洽——亮着的点一下整条熄灭，灭的点一下整条亮起。“全部显示/隐藏”同步写两份开关。

## 4. 实测证据（0 报错）

整行开关 + `some` 判定阶段：

| 操作 | 可见光锥 | 右栏 | 左栏 18 行 |
|---|---|---|---|
| 进入 /nodes | 400 | 1号线 28/28 | 全部亮 |
| 点「3号线」整行（点名字上） | 371 | 3号线 0/29 | 只有第 3 行灭 |
| 再点同一行 | 400 | 3号线 29/29 | 全部亮 |
| 单关「石龙路」 | 399 | 3号线 28/29 | 压暗 1 |
| 点该行（仍亮） | 371 | 3号线 0/29 | 3号线变灭 |
| 再点该行（已灭） | 400 | 3号线 29/29 | 恢复亮 |

`lineStationOn` 修复后（用户报的场景）：

| 操作 | 可见光锥 | 左栏 18 行 |
|---|---|---|
| 进入 /nodes | 400 | 全亮 |
| 全部隐藏 | 0 | 全灭 |
| **全灭下点「1号线」** | **28**（正好 1 号线站数） | `亮灭灭灭灭灭灭灭灭灭灭灭灭灭灭灭灭灭` |
| 再点「3号线」 | 55 | `亮灭亮灭灭…` |
| 再点「1号线」关掉 | 27 | 只剩第 3 行为亮 |
| 全部显示 | 400 | 全亮 |

交叉校验：1号线 28 站 + 3号线 29 站 = 57，实测可见 **55**，差的 2 个正是两线共用换乘站（只渲染一次，不重复计数），说明计数与三维一致。

其它已核对的行为：勾选状态跨栏目留存（关掉「富锦路」→ 切 /strategy → 切回 /nodes 仍为关闭态、可见 399）；齿轮「线路图层」全不选时折线 18→0 且站点不受影响（前一阶段数据）。

## 5. 已知残留与取舍（未改，需知悉）

共站只有一份开关，**最后点它的线路说了算**：关掉 1号线后可见 27，而 3号线的 2 个共站（宜山路、上海火车站）也跟着灭了，尽管 3号线的行仍亮着——界面表现为 3号线那 2 个站点块压暗但行是亮的。

两个方向各有取舍，当前有意选后者：

- **保持现状（写标志位）**：简单、可预期、与线路侧行为一致；代价是上述残留现象。
- **引入“站点归属线路集合”**（还有任一所属性线路亮着就保持显示）：残留消失，但关掉 1号线时它的 12 个共站不会灭（约 384 可见），且 owners 那套复杂度回来了。

另有一个由 `some` 判定带来的选择：一条线被单独关掉几个站（如 3号线 28/29 亮着）时仍显示为“亮”，此时点它会把剩下 28 个**一起清空**而非补全成 29；改成 `every` 可变成“补全”，但连坐变灭的假象会回来。当前选清空。

## 6. 改动文件

| 文件 | 改动 |
|---|---|
| `Translation/src/stores/stationState.js` | 新增 `lineStationOn` 线路级开关 |
| `Translation/src/components/screenUI/StationPanel.vue` | `lineLit` 改读线路开关（不再反推站点标志位）；`toggleLine` 同时写两份开关并切右栏焦点；线路行改为整行按钮 + 熄灭压暗样式；全部显示/隐藏同步线路开关 |
| `Translation/src/cesiumTools/lineAndpoints/points/setpoints.js` | 沿用上一轮的 `hideStationByName`，本轮未改 |
