---
id: "12340240-a8ef-496b-95da-0f2921ad20ea"
title: "NVIDIA 录屏 Alt+F9 一闪即停：被 UU远程 的 WDA_EXCLUDEFROMCAPTURE 覆盖窗触发「受保护内容」"
description: "诊断结论与复现证据：Alt+F9 录制启动 0.65s 后被 NVIDIA 以 Protected Content 销毁会话，根因是网易UU远程被控端 GameViewerServer 的 2400×1536 铺屏覆盖窗带 WDA_EXCLUDEFROMCAPTURE(0x11)；含窗口标志枚举排查法、跨进程修改被拒(错误码5)的边界、修复步骤与备选方案。"
status: "active"
created_at: "2026-10-22T05:42:21.569Z"
updated_at: "2026-10-22T05:42:21.569Z"
content_hash: "4aa0020b668334657bfaafaec04fda8796913eed28817f5bd7b20781e4b66658"
source_paths:
  []
session_ids:
  - "90ab7416-8421-4966-b468-c390794cc4ee"
memory_body_ids:
  []
---

# NVIDIA 录屏 Alt+F9 一闪即停 —— 根因：UU远程 的防截屏覆盖层

诊断日期 2026-10-22，机器为 Windows 桌面（主屏 2400×1536 逻辑坐标，125% 缩放 = 3000×1920）。结论：**不是显卡、驱动或编码器问题**，是网易UU远程被控端在屏幕上盖了一层声明「禁止截取」的窗口，NVIDIA 桌面采集据此判定「受保护内容」并销毁录制会话。

## 1. 复现与日志证据链

现场按一次 Alt+F9 复现，`NVIDIA Overlay\CxNative_NVIDIA Overlay.log`（NVIDIA 覆盖层日志目录，另有 `.1.log` 轮转卷）每次都呈现完全一致的时序：

```
13:38:54.716  AddSessionReference: Creating a record session of type: Type=record Refs=[]
13:38:55.256  CaptureState: 1, Mode: 0            ← 录制真的启动了
13:38:55.256  CaptureStateChange Notification Message
13:38:55.960  Received Protected Content running notification
13:38:56.461  CaptureState: 0, Mode: 0
13:38:56.461  DestroyCaptureSession session[0000000000620930]
```

即录制启动约 **0.65–0.7 秒**后驱动报告受保护内容，NVIDIA 立刻销毁会话；用户观感就是「按 Alt+F9 一闪就没 + 弹窗提示有程序阻止」。该日志中 Protected Content 首次出现在当天 13:34:18，与后续 13:34:22 / 13:34:50 / 13:38:55 多次失败一致；`.1.log` 轮转卷中 0 命中，说明问题只在当天这一段出现。

## 2. 定位「是哪个程序」：枚举 GetWindowDisplayAffinity

逐个窗口查询 `GetWindowDisplayAffinity`（返回 `WDA_EXCLUDEFROMCAPTURE` = 0x11），全系统仅 9 个窗口带该标志，真正够格的只有两个：

| 窗口类 | 进程 | 可见性 | 尺寸 | 标志 |
|---|---|---|---|---|
| `GameViewerPrivateWindowClass` | **GameViewerServer（网易UU远程 被控端）PID 7848** | visible=True，置顶+分层 | 2400×1536（×125% = 3000×1920，正好铺满主屏） | **0x11** |
| `AMDDVROVERLAYWINDOWCLASS` | amdow（AMD DVR 覆盖层） | hidden | 13×13 | 其中仅 1 个窗口为 0x11，其余 0x0 |

其余 7 个 0x11 窗口均来自 `windows-mcp`（python，`WindowsMCPControl_*`，标题 `windows-mcp-flash`），是工具自身的闪光提示，尺寸极小且 hidden，与此无关。

关键判断：UU远程 那个窗口是 **满屏 + 可见 + 明确要求别录**，不是在绘制界面，而是被控端刻意固定的屏蔽图层。

## 3. 绕过尝试全部失败（边界明确）

- `SetWindowDisplayAffinity(hwnd, 0)` → 返回 False，`GetLastError=5`（拒绝访问），affinity 仍是 0x11。
- `ShowWindow(hwnd, SW_HIDE)` → 返回 False，窗口随即被 UU远程 自己恢复为可见。
- `SetWindowPos` 移出屏外 → 返回 False，err=5，rect 不变。
- `Stop-Process` 杀 GameViewerServer → 无管理员权限，进程仍存活（由 `GameViewerService` 启动）。

结论：**跨进程无法修改或隐藏这个受保护图层，普通权限也无法结束它**；解决只能从 UU远程 客户端/服务层下手。

## 4. 加重因素：超级屏改了分辨率，时间线吻合

`C:\Program Files\Netease\GameViewer\config\server\aeawovduneacrfh6.ini` 内容：

```ini
[super_screen]
open=1
width=3000
height=1920
resolution_type=2
dpi_3000_1920=125
```

该文件写入时间 **13:10:16**（当天有新设备连入记录），而 13:34 第一次录屏失败 —— 时间线对得上。它把主屏虚拟成非原生 3000×1920，与那个 2400×1536（逻辑）覆盖窗尺寸互为印证。

## 5. 确认「当时无人远程控制」的方法

`.slog` 日志（`log\server\log\*_controlled_*.slog`）是加密的，直接读只有乱码，**不要浪费时间**。改用两项可读信号：

- **进程 CPU 增量**：`GameViewerServer` pid 7848 的 `cpu_delta_5s = 0.00s`、`GameViewer` pid 2972 为 0.03s → 当时没有真实串流在跑，因此停止被控端做对照实验是安全的。
- 网络连接列表：只有 Listen/Bound 与到网易服务器的 CloseWait/Established，无活跃被控会话。

注意该机器 `quser` 不在 PATH（PowerShell 报「术语无法识别」），查会话列表要换别的命令。

## 6. 修复步骤（按顺序）

1. 托盘右键 UU远程 → **完全退出**（不是关窗口/最小化），服务级 `GameViewerServer` 随之退出，防截屏覆盖窗消失。
2. 再按 Alt+F9，录制应能持续进行。
3. 长期方案：
   - 关掉开机自启 `HKCU\Software\Microsoft\Windows\CurrentVersion\Run` 中的 `GameViewer`（值 `"C:\Program Files\Netease\GameViewer\GameViewer.exe" --auto-run`）；启动文件夹里没有它的快捷方式，也无计划任务。
   - 在 UU远程 设置里关掉「超级屏」，分辨率恢复 2560×1600 原生。
4. 若必须「一边远程一边录」：NVIDIA 桌面采集与此天然冲突，应改用 OBS 的窗口/游戏采集，或直接用 UU远程 自带的录制。

关服务/改自启需要管理员权限，会弹一次 UAC。

## 7. 可复用的排查套路

遇到「NVIDIA 或其他录屏工具一闪即停、提示受保护内容」时：

1. 先在覆盖层日志里确认 `Received Protected Content running notification` 与 `DestroyCaptureSession` 的间隔（本例 0.7s），排除编码/磁盘问题。
2. 枚举全部顶层窗口的 `GetWindowDisplayAffinity`，筛 `0x11` 且 **visible + 面积接近满屏** 的候选——隐藏的小窗口基本可排除。
3. 对候选尝试改标志/隐藏/移动：若统一返回错误码 5，说明是对端用系统保护固定的图层，转去查该软件的配置与自启项。
4. 停用前先用 CPU 增量与连接状态确认无人在线使用，避免误断远程会话。

## 8. 相关文件路径

- `C:\Program Files\Netease\GameViewer\config\server\aeawovduneacrfh6.ini`（超级屏开关与分辨率，当天 13:10 写入）
- `C:\Program Files\Netease\GameViewer\log\server\log\` 下 `log_*.slog` / `streamer_log_controlled_*.slog` / `connection_log_controlled_*.slog`（**加密，不可读**）
- NVIDIA 覆盖层日志目录中 `CxNative_NVIDIA Overlay.log` / `.1.log` / `console.log` / `debug.log`
- `C:\Program Files\Netease\GameViewer\GameViewerService.exe --service`（服务名 `GameViewerService`，Auto 启动，Running）
