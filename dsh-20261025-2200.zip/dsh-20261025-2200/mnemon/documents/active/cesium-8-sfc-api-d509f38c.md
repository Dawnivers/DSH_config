---
id: "d509f38c-0930-4920-b7c1-7c0b441b5277"
title: "语雀课程《Cesium_智慧地铁》第 8 章「发展历程」完整存档（功能说明 / 编码设计 / 五步实现 / 合并版 SFC / 依赖 API）"
description: "新中地课程文档《发展历程》全文要点与全部代码：线路建成动画 + 里程碑播放的实现方案，含 renderAll 新增 isCache 外部缓存参数、CallbackProperty 驱动 polyline 生长、raf 播放与 marks/currentTime 监听、退出还原图层控制，另附完整 CSS、依赖的既有 API 清单、两个登录受限附件，以及与本项目（上海数据、1920×1080 HUD）的落地差异。"
status: "active"
created_at: "2026-10-12T07:48:54.498Z"
updated_at: "2026-10-12T07:48:54.498Z"
content_hash: "e0f1414d465ffa812aa454a50500ca85a12927f3b59068a3ee5b2f9222fa7017"
source_paths:
  - "参考资料/发展历程-语雀课程/发展历程（语雀课程原文）.md"
session_ids:
  - "session-d6cbf69c-ac7f-4b6b-a2a9-8468919b087a"
memory_body_ids:
  []
---

# 语雀课程《Cesium_智慧地铁》第 8 章「发展历程」

来源：<https://www.yuque.com/xzd/fgdede/bfs4mxyi0vfgagn4>（访问密码 `yzg4`）
知识库：新中地-课程研发中心 / `Cesium_智慧地铁`；`book.slug=fgdede`、`book_id=42389323`、`doc_id=169741104`、`doc.slug=bfs4mxyi0vfgagn4`
作者：诗杨；首次发布 2024-09-13；4577 字；1 赞
本地留档（原文 markdown，正文 962 行）：`参考资料/发展历程-语雀课程/发展历程（语雀课程原文）.md`

> 取全文的方法：匿名会话在页面里 `fetch('/api/docs/bfs4mxyi0vfgagn4?book_id=42389323&mode=markdown&plain=true&linebreak=true')`，正文在 `data.sourcecode`。
> 页面渲染时 CSS 代码块被作者折叠成 `#subLine-controller {…}`，**markdown 源里 CSS 是完整的**；只看网页会误以为 CSS 缺失。

## 0. 该文档在课程中的位置

知识库目录（13 章）：智慧地铁项目课程介绍 / 项目环境部署 / 项目大屏功能 / 地铁线路管理 / Cesium实现自定义气泡框 / Cesium自定义材质 / 重保活动 / **发展历程** / 实时轨迹 / 站点管理 / 项目打包上线 / docker使用指南。

对应本项目的前端路由是 `/strategy`（见记忆库文档 `1056d83b-fc4b-4598-834b-404ed7f42702`）。

## 1. 功能说明

动态展示地铁线路的建成情况，以及里程碑。

## 2. 编码设计（原文 5 条）

1. 进入功能页面，需要把**全局图层控制功能禁用**；做法是重构代码，把图层控制收进 pinia。
2. 离开功能时要**还原图层控制**，并清除里程碑展示的**地图副作用**。
3. 点击右侧站线展示地铁线路——因为需求特殊，原本封装好的逻辑不满足，所以**在组件内部单独处理道路实体**；UI 用 antd 的 `slider` 展示进度。
4. 播放功能：用定时器/raf 在最终的站线坐标数组里**拼接**当前渲染的坐标数组。
5. 里程碑展示：监听进度 → 找下标 → 用下标找里程碑信息。

## 3. 功能开发

### 3.1 准备：需要的数据

| 数据 | 来源 |
|---|---|
| `subLineData` 渲染数据 | 直接从 pinia 仓库取 |
| `marks` 播放控件数据 | 点击站线时计算出来 |
| `currentTime` | 当前播放到的时间 |
| `message` | 当前播放展示的里程碑数据 |

组件结构（原文代码，含完整 CSS）：

```html
<!-- 发展历程,该功能进入的时候需要将所有的地铁路线都清除，离开的时候再添加回来，使用该功能的时候无法使用图层管理控件 -->
<template>
    <div id="subLine-controller">
        <div class="item-wrapper">
            <div class="item" v-for="item in subLineData" @click.stop="handleItemClick(item)">
                <div class="box" :style="{ borderColor: item.color, backgroundColor: item.color }"></div>
                <span :style="{ color: '#34c5cf' }">{{ item.name.slice(-3) }}</span>
            </div>
        </div>
    </div>
    <div class="active-panel">
        <div class="header">
            <strong>发展历程</strong>
            <div class="controler">
                <i class="iconfont metro-pause" @click="pause"></i>
                <i class="iconfont metro-play" @click="play"></i>
                <i class="iconfont metro-icon-replay-copy" @click="replay"></i>
            </div>
        </div>
        <div class="content">
            <a-slider style="width: 500px" v-if="resPaths.length !== 0" v-model:value="currentTime" :marks="marks"
                :step="0.5" :min="0" :max="max" :disabled="true">
            </a-slider>
        </div>
        <div class="message" v-if="message.length">
            {{ message }}
        </div>
    </div>
</template>
```

```css
<style scoped>
#subLine-controller {
    position: absolute; bottom: 0; left: 32%; transform: translateX(-50%);
    width: 7.625vw; height: 7.292vw;
    background-color: rgba(0, 0, 0, 0.3); border: 1px solid #664a16;
    padding: 4px; display: flex; flex-direction: column;
}
.box { width: 10px; height: 10px; border-width: 1px; border-style: solid; background: transparent; user-select: all; cursor: pointer; }
.item {
    width: 3.385vw; height: 1.042vw; display: flex; align-items: center; justify-content: space-between;
    padding: 0 0.156vw; background-color: rgba(255, 255, 255, 0.2); border: 1px solid #885f12;
    color: #fff; font-size: 0.521vw; pointer-events: all; cursor: pointer;
}
.item:hover { border: 1px solid #d8961a; }
.item>span { line-height: 0.469vw; }
.item>input { outline: none; border: none; transition: all 0.3s ease; }
.item-wrapper { display: flex; justify-content: space-between; align-content: space-around; flex-wrap: wrap; flex: 1; }
.active-panel {
    width: 580px; height: 170px; border: 1px solid #ab7818; background-color: rgba(0, 0, 0, 0.3);
    position: absolute; left: 37%; bottom: 0; color: #fff; overflow: hidden; display: flex; flex-direction: column;
}
.active-panel>.header { height: 1.563vw; padding: 0.208vw; margin-bottom: -0.521vw; font-family: "等线Bold"; display: flex; align-items: center; justify-content: space-between; }
.active-panel>.header>strong {
    background: rgb(255, 255, 255);
    background-image: linear-gradient(180deg, rgba(255, 255, 255, 1) 9%, rgba(211, 156, 50, 1) 57%);
    background-clip: text; -webkit-background-clip: text; -webkit-text-fill-color: transparent;
}
.controler { width: 100px; display: flex; align-items: center; justify-content: space-around; }
.controler>i { cursor: pointer; pointer-events: all; font-size: 20px; }
.controler>i:hover {
    background: rgb(255, 255, 255);
    background-image: linear-gradient(180deg, rgba(255, 255, 255, 1) 9%, rgba(211, 156, 50, 1) 57%);
    background-clip: text; -webkit-background-clip: text; -webkit-text-fill-color: transparent;
}
.active-panel>.header>strong { font-weight: normal; margin-right: 0.521vw; }
.active-panel>.header>span { font-size: 0.625vw; }
.content { flex: 1; padding: 0 30px; margin-top: 30px; }
.message {
    position: absolute; bottom: 26px; left: 50%; transform: translateX(-50%);
    background-color: rgba(0, 0, 0, 0.3); color: #fff; text-align: center;
}
</style>
```

### 3.2 页面加载逻辑

```js
// 进入的时候隐藏所有地铁线路,并跳转到默认点
onMounted(() => {
    viewer = lineDataStore.Viewer
    subLineData.value = lineDataStore.allData
    // 将站点站线全部隐藏
    const lineNames = lineDataStore.allData.map(item => item.name)
    lineDataStore.displayLine(lineNames, false)
    // 暂时禁用全局管理，unMount的时候打开
    lineDataStore.disableController(true)
})
```

在 `useLineData` 里新增 `displayLine` 与 `disableController`：

```js
import { displayByName } from "@/cesiumTools/effectController";

actions: {
    // 全局管理路线显隐
    displayLine(lineNames, isShow) {
      if (Array.isArray(lineNames) && this.lineData.length && !this.disable) {
        const stationNames = [];
        // 控制state数据
        this.lineData.forEach((item) => {
          const { stationsList, name } = item;
          if (lineNames.includes(name)) {
            item.checked = isShow;
            stationsList.forEach((station) => {
              stationNames.push(station.name);
            });
          }
        });
        // 控制地图元素
        displayByName(lineNames, stationNames, isShow);
      }
    },
    // 设置是否开启全局管理
    disableController(val) {
      this.disable = val;
    }
}
```

在 toolbar 组件里拿 `disable` 信息并禁用图层管理：

```js
lineDataStore.$onAction(({ name, store, args, after, onError }) => {
  if (name === 'disableController') {
    after((res) => {
      disabled.value = lineDataStore.isDisable;
    });
  }
})
```

`LineController.vue` 重构为直接调 pinia：

```vue
<script setup>
import { onMounted, ref } from 'vue'
import { useLineData } from '@/store'

const subLineData = ref([])
const showAll = ref(true)
const lineDataStore = useLineData()

// 全选，控制所有站点，站线
const controlAll = (e) => {
    const checked = e.target.checked
    const lineNames = subLineData.value.map(item => item.name)
    lineDataStore.displayLine(lineNames, checked)
}

// 单独控制站线
const chooseLine = (item) => {
    const names = [item.name]
    lineDataStore.displayLine(names, !item.checked)
}

onMounted(async () => {
    subLineData.value = lineDataStore.allData
})
</script>
```

### 3.3 点击站线逻辑

**里程碑 mock 数据**（原文给了完整 8 条线，此处只记结构——数据是**武汉地铁 1–8 号线**的真实建设时间线，字段 `name / id / history[{timePoint, message}]`）：

```js
// 地铁历史
export const line_history = [ { name: "一号线", id: 1, history: [ { timePoint: "2000-12", message: "武汉地铁1号线一期开工" }, /* ... */ ] }, /* 二~八号线 ... */ ];
```

**点击逻辑**：重用之前渲染站点站线的逻辑，但**不走缓存**，增删由组件自己控制。

```js
// 渲染站点站线,不走内部缓存,要获取返回值，在外部进行管理
dataEnts = renderAll(viewer, [item], false)
```

「我修改了 renderAll 函数，添加了 isCache 参数用于不走缓存的逻辑，并且将所有的数据抛出来进行管理」（即 `renderAll` 新增第三参 `isCache`，返回 `{ lineEnts, stationEnts, billboards }`）。

构造 marks（进度条）：

```js
// 渲染时间slider
const { history } = target;
max.value = (history.length - 1) * 10;
let res = {};
history.forEach((item, index) => {
    res[index * 10] = {
        style: { color: "#fff", fontSize: 10 },
        label: item.timePoint,
        message: item.message,
    };
});
// 给播放控件赋值，并给路径数据赋值
marks.value = res;
```

给 `lineEnts` 坐标重新赋值，用 `CallbackProperty` 做动画：

```js
resPaths = positions;
curPaths = positions.slice(0, 2);
// 飞行到默认点
flyToDefaultView(viewer)
// 找到路线的实体，并给其坐标重新赋值
const entity = dataEnts.lineEnts[0]
// 给播放控件赋值，并给路径数据赋值
entity.polyline.positions = new Cesium.CallbackProperty(() => Cesium.Cartesian3.fromDegreesArray(curPaths), false)
```

`handleItemClick` 完整逻辑：

```js
import { line_history } from '@/store/staticData'

// 点击对应线路，视角跳转，并重新渲染该线路，id要不一样，路线坐标使用callbackProperty
// dataEnts类型 { lineEnts:[], stationEnts:[], billboards:[] }
let dataEnts = {}
const handleItemClick = (item) => {
    const { id, paths } = item;
    const positions = flattenPositions(paths)
    pause()
    removeCurrentEnts()
    const target = line_history.find((n) => n.id === id);
    if (target) {
        pause()
        currentTime.value = 0;
        dataEnts = renderAll(viewer, [item], false)
        const { history } = target;
        max.value = (history.length - 1) * 10;
        let res = {};
        history.forEach((item, index) => {
            res[index * 10] = { style: { color: "#fff", fontSize: 10 }, label: item.timePoint, message: item.message };
        });
        marks.value = res;
        resPaths = positions;
        curPaths = positions.slice(0, 2);
        flyToDefaultView(viewer)
        const entity = dataEnts.lineEnts[0]
        entity.polyline.positions = new Cesium.CallbackProperty(() => Cesium.Cartesian3.fromDegreesArray(curPaths), false)
    }
}
```

### 3.4 播放动画逻辑

要点：算当前时间占整段的比重 → 由比重求坐标数组下标 → 由下标算 `curPaths` 渲染道路 → raf 递归 → **注意用 `cancelAnimationFrame` 清除 raf 的影响**。

```js
let myRequestID = null;
const play = () => {
    cancelAnimationFrame(myRequestID)
    const animate = () => {
        if (isAnimate) {
            currentTime.value += 0.1;
            const rate = currentTime.value / max.value;
            let index = Math.ceil(rate * resPaths.length);
            // 我们的坐标两个为一组，不为双数的话，就加一
            if (index % 2 !== 0) { index = index + 1; }
            // 如果是最后一个坐标，就返回
            if (index >= resPaths.length - 1) {
                curPaths = resPaths;
                isAnimate = false
                return;
            }
            curPaths = resPaths.slice(0, index);
            requestAnimationFrame(animate)
            myRequestID = requestAnimationFrame(animate)   // 原文这里写了两遍，第二行才是保留 id 的那次
        }
    }
    isAnimate = true
    animate()
}
```

监听进度改里程碑：

```js
// 监听当前进度 1.找到当前进度在marks当中的下标 2.通过下标,找message
watch(currentTime, (val) => {
    let targetIndex = null;
    const markKeys = Object.keys(marks.value).map((n) => Number(n));
    const markValues = Object.values(marks.value);
    markKeys.forEach((m, index) => {
        if (index > 0 && val <= m && val > markKeys[index - 1]) { targetIndex = index; }
        if (val <= m && index === 0) { targetIndex = index; }
    });
    if (targetIndex) {
        message.value = markValues[targetIndex].message;
    } else {
        message.value = "";
    }
});
```

### 3.5 退出清除

```js
onBeforeUnmount(() => {
    pause()
    // 清除已经有的数据以及实体
    removeByCacheData(viewer, dataEnts)
    dataEnts = null
    // 全局管理恢复，路线展示恢复
    lineDataStore.disableController(false)
    // 将站点站线全部展示
    const lineNames = lineDataStore.allData.map(item => item.name)
    lineDataStore.displayLine(lineNames, true)
})
```

## 4. 「功能完整实现」——合并版 SFC

```vue
<script setup>
import * as Cesium from 'cesium'
import { onMounted, ref, onBeforeUnmount, watch } from 'vue'
import { useLineData } from '@/store'
import { flattenPositions } from '@/cesiumTools/core'
import { flyToDefaultView, renderAll, removeByCacheData } from '@/cesiumTools/effectController'
import { line_history } from '@/store/staticData'

const currentTime = ref(0);
const marks = ref({});
const max = ref(100);
const message = ref("");
const lineDataStore = useLineData()
const subLineData = ref([])
// 地铁线的路径数组
let curPaths = [];
let resPaths = [];
let isAnimate = false
let viewer

onMounted(() => {
    viewer = lineDataStore.Viewer
    subLineData.value = lineDataStore.allData
    const lineNames = lineDataStore.allData.map(item => item.name)
    lineDataStore.displayLine(lineNames, false)
    lineDataStore.disableController(true)
})

onBeforeUnmount(() => {
    pause()
    removeByCacheData(viewer, dataEnts)
    dataEnts = null
    lineDataStore.disableController(false)
    const lineNames = lineDataStore.allData.map(item => item.name)
    lineDataStore.displayLine(lineNames, true)
})

const removeCurrentEnts = () => {
    removeByCacheData(viewer, dataEnts)
    dataEnts = {}
}

let dataEnts = {}
const handleItemClick = (item) => { /* 见 3.3 */ }

const pause = () => { isAnimate = false };

const play = () => { /* 见 3.4 */ }

const replay = () => {
    pause();
    currentTime.value = 0;
    curPaths = resPaths.slice(0, 2);
    play();
}

watch(currentTime, (val) => { /* 见 3.4 */ });
</script>

<style scoped>
....样式略
</style>
```

## 5. 这篇文档依赖 / 要求改动的既有 API

| API | 出处 | 文档要求 |
|---|---|---|
| `renderAll(viewer, data, isCache)` | `@/cesiumTools/effectController` | **新增第三参**：`false` = 不走内部缓存，并把渲染出的实体（`lineEnts/stationEnts/billboards`）返回给外部管理 |
| `removeByCacheData(viewer, dataEnts)` | `@/cesiumTools/effectController` | 清除本轮渲染造成的实体 |
| `flyToDefaultView(viewer)` | `@/cesiumTools/effectController` | 飞到默认视角 |
| `displayByName(lineNames, stationNames, isShow)` | `@/cesiumTools/effectController` | 被 store 的 `displayLine` 调用 |
| `flattenPositions(paths)` | `@/cesiumTools/core` | 线路 path → 扁平坐标数组 |
| `useLineData()` store | `@/store` | 新增 `displayLine(lineNames,isShow)`、`disableController(val)`，并暴露 `disable` / `isDisable` / `allData` / `Viewer` / `lineData` |
| `line_history` | `@/store/staticData` | 里程碑 mock 数据 |
| `LineController.vue` / `toolbar.vue` | 组件 | 前者改为直接调 pinia；后者用 `$onAction` 监听 `disableController` 同步 `disabled` |

## 6. 附件（**匿名会话下载不到**，会返回语雀登录页 HTML）

「功能完整实现」小节里挂了两个文件卡片：

- `effectController.js` (18 KB) —— 「修改之后的 effectController，新增是否要走外部缓存的逻辑」
  <https://www.yuque.com/attachments/yuque/0/2024/js/8435413/1726198896553-7b44274d-0b85-454a-916e-472c321e7dfd.js>
- `core.js` (2 KB)
  <https://www.yuque.com/attachments/yuque/0/2024/js/8435413/1726190393091-91263fc6-4744-467d-8b2e-0d118063729e.js>

实测：带密码会话 `fetch` 这两个 URL 返回 `200 text/html` 且长度相同（约 32 KB）——是登录/校验页，不是 JS。**需要登录语雀账号才能真正下载**。文档正文里的代码已覆盖这两个文件的关键改动点。

## 7. 与本项目（Translation / 智慧地铁）的差异与落地提醒

1. **数据是武汉的**：`line_history` 通篇「武汉地铁 N 号线」，本项目 400 个站点/18 条线是**上海**数据 → 里程碑文案必须整份替换，不能照搬。
2. **UI 技术栈不同**：文档进度条用 antd `a-slider`（`:disabled="true"`，只做展示）；本项目是自绘 HUD（1920×1080 设计 px + `transform: scale`），没有 antd 依赖。
3. **单位不同**：文档 CSS 用 `vw`；本项目 HUD 用固定设计 px，混用会出现两套缩放。
4. **本项目的对应路由是 `/strategy`**（`1056d83b-fc4b-4598-834b-404ed7f42702` 记录），不是文档里的组件名。
5. **图层控制状态量语义不同**：文档靠 store 的 `disable` 布尔量「禁用/恢复全局管理」；本项目站点显隐是 `checked + lineStationOn + forced` 三开关模型（`StationPanel.vue`），接这个功能时要先对齐语义，别直接搬 `displayLine`。
6. 文档 `play()` 里 `requestAnimationFrame(animate)` 被**写了两遍**（原文笔误），只有第二行把 id 存进 `myRequestID`；照抄会一次递归出两条 raf 链。以 `let myRequestID` + `cancelAnimationFrame(myRequestID)` 的意图为准，只保留一行。
