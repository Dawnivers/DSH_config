---
id: "065c7b95-72ee-4323-96c0-2a5b179e432e"
title: "Chisa 角色 rig 清单与外部动捕重定向要点（Blender 5.2 / trainAndChisa.blend）"
description: "Chisa rig 的骨骼命名体系、坐标变换陷阱、辅助骨清单、蒙皮与动画现状，以及外部动捕重定向和 Cesium 导出的要点。用于后续任何针对该模型的脚本化操作。"
status: "active"
created_at: "2026-10-16T14:08:03.072Z"
updated_at: "2026-10-16T14:08:03.072Z"
content_hash: "fec0127200e414a6c948cc311a4896936ec44eeea4ec414068c4eed38c362948"
source_paths:
  - "blender-bridge/recon_chisa.py"
session_ids:
  - "session-2594f463-42b5-4576-9c52-bc9a3289909a"
memory_body_ids:
  []
---

## 场景
- Blender **5.2.0 LTS**，scene "Scene"，帧范围 **1–250 @ 24fps**，unit_scale 1.0
- 物体：1 Camera / 1 Light / 4 Empty（`RootNode`、`Sketchfab_model`、`Chisa.fbx`…）/ **8 Mesh** / **1 Armature**（名字叫 `Object_3`）；另有一个无关的 `棱角球`（42 顶点、无骨架、无材质）
- 来源印记：`Sketchfab_model` + `Chisa.fbx` → Sketchfab 下载的 FBX

## 骨架：376 骨，3ds Max Biped 命名（不是 Mixamo）
- 层级深度 **16**，唯一根 **`_rootJoint`**；**无 mixamorig 前缀**，humanoid 名字直接匹配为 0 —— 因为它是 **Biped** 体系：
  - `Bip001Pelvis_0115`、`Bip001Spine_0223`、`Bip001LUpperArm_068`、`Bip001RUpperArm_0120`、`Bip001LThigh_0278`、`Bip001LCalf_0280`、`Bip001LFoot_0281`、`Bip001LToe0_0282`、`Bip001RThigh_0293`、`Bip001RCalf_0294`、`Bip001RFoot_0295`、`Bip001RToe0_0296` …
  - 命名模式：`Bip001` + 左右 + 部位 + `_NNNN`（后缀是导入时的节点号）
- **约 300 根是辅助/布料骨，重定向时不要驱动**：
  - `Bone_Skirt###_L/R`（裙摆）、`Bone_Piao###_L/R`（飘/发丝）
  - twist/knee 辅助：`Bip001_L_Knee_F/B`、`Bip001_L_Calf`、`Bip001_L_CalfTwist`、`Bip001LThighTwist`、`Bip001LThighTwist1`
  - 实测 `tiny_bones=4`、`bones_at_origin=7`（有骨头长度极短/头在世界原点 —— 正是"绕它转等于绕地面转"的那类）
- **真正要驱动的身体骨约 35 根**（Pelvis / Spine / Spine1 / Neck / Head / Clavicle×2 / UpperArm×2 / Forearm×2 / Hand×2 / 手指 / Thigh×2 / Calf×2 / Foot×2 / Toe0×2）

## 坐标陷阱（实测数字，必须做变换）
armature 的 `matrix_world.to_3x3()` 三列：
```
X → [ 0.01,  0.00,  0.00]
Y → [ 0.00,  0.00, -0.01]
Z → [ 0.00,  0.01,  0.00]
```
→ **整体缩放 0.01（厘米单位）＋ 绕 X 轴 −90°**（骨架 Y 对应世界 −Z，骨架 Z 对应世界 +Y）。
外部动捕（BVH/SMPL 关节）套进来前必须先做：`scale(100)` + 轴交换（Y↔Z 带符号），否则动作整体歪掉。

## 蒙皮与材质
- 8 个 mesh **全部 376 个 vertex group + ARMATURE 修改器**，父级都是 `Object_3`
- 顶点数：Object_9=23903、Object_10=23068、Object_7=8795、Object_8=3137、Object_6=3130、Object_11=2087、Object_12=470
- 材质前缀 `MI_R2T1QianXiaMd10011*`，分部：Up / Down / Alpha / Face / Eye / Bangs / Hair
- **无形态键（shape keys = 0）** → 没有表情/口型可用，只能动骨骼

## 动画现状
- **`action_count = 0`，无 NLA，无约束** → 干净起点，没有已有动作需要保留
- 但实测 **`posed = 63`**（63 根 pose bone 当前不在静置位）—— 待确认是有意摆姿还是 FBX 导入噪声

## 网页导出（老坑）
Cesium 1.97 **渲染不了 376 关节蒙皮**：376×4 = 1504 个 vec4 顶点 uniform 超 WebGL 上限 → 顶点着色器编译失败 → 蒙皮图元被**静默丢弃**（判别特征：带 skin 的全不显示、不带 skin 的正常）。要上网页必须先减关节/分段。

## 工具
- 侦察脚本：`blender-bridge\recon_chisa.py`（只读、一次 dump 全量、可重复运行）
- 桥接：`blender-bridge\bl.ps1 -Ping | -Code | -File`，走 TCP 9876，请求 `{"type":"execute_code","params":{"code":"…"}}`
- 插件自动起服务：`blendermcp_auto_start_server` 默认 True，开 Blender 后 9876 自动监听
