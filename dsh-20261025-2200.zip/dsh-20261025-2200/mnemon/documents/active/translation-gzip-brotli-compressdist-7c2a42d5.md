---
id: "7c2a42d5-45a2-49fe-88c5-11b21ed7b3ca"
title: "Translation 构建产物 gzip/brotli 预压缩实现：自写 compressDist 插件（零新增依赖）+ 验证与部署前提"
description: "Translation（Vite + vite-plugin-cesium）落地构建产物预压缩的实现手记：为何不装 vite-plugin-compression（pnpm store v10/v11 不兼容）、compressDist 插件设计（apply:build、closeBundle、排在 cesium() 之后、只压文本、<1KB 跳过、纯新增副本）、174 文件压缩实测与 sha256 校验、dev 无影响证据、nginx gzip_static/brotli_static 部署前提与 brotli q11 的 +15s 取舍。"
status: "active"
created_at: "2026-10-20T01:01:27.715Z"
updated_at: "2026-10-20T01:01:27.715Z"
content_hash: "48976ac50a17e73b3b5387c425b9f044586e0f401d6528188cec71918b63a2ce"
source_paths:
  - "Translation/vite.config.js"
  - "Translation/README.md"
session_ids:
  - "fbf5b637-f598-426f-9e29-c38055e7eb6a"
memory_body_ids:
  []
---

# Translation：构建产物 gzip/brotli 预压缩实现（2026-10-20）

项目：`D:\WebGIS\web三维开发\智慧地铁项目\Translation`（Vite 8.2.2 / Vue 3.5 / cesium 1.97 / `vite-plugin-cesium` 1.2.23）。

背景与「为什么只有压缩值得做」的实测依据见前置文档 `e5a2c008-2ce6-446c-bb70-81dc323f7317`（参考项目四件套 ①②③ 本项目已由 `vite-plugin-cesium` 等价具备，唯独缺 ④ 压缩）。本文只记录用户拍板「进行 4 压缩」之后的**实现、验证数据与生效边界**。

## 1. 关键决策：不装 `vite-plugin-compression`，改用 `node:zlib` 自写

本项目的 `node_modules` 由 pnpm 10.33 安装（store `D:\.pnpm-store\v10`），而 DSH 自带的 pnpm 是 11（store v11，格式不兼容）。此时安装任何新包都可能被判「必须重建 node_modules」而整个联网重装——为一个小功能不值得。

结论：**零新增依赖**，用 `node:zlib` 写一个本地 `compressDist()` 插件（约 60 行）。

## 2. 插件设计（`Translation/vite.config.js`）

| 决策 | 取值 | 原因 |
|---|---|---|
| 生效范围 | `apply: 'build'` | dev 不参与，`pnpm dev` 行为完全不变 |
| 挂载钩子 | `closeBundle` | 产物已全部落盘 |
| 插件顺序 | 排在 `cesium()` **之后** | 才能连带压缩插件拷进 `dist/cesium/` 的 371 个文件 |
| 压缩对象 | `.js .mjs .css .html .json .svg .txt .xml .wasm` | 只压文本类 |
| 跳过 | `.jpg/.png/.glb`（本身已压缩）、小于 1KB（避免产物全是碎片） | 省时间、少噪音 |
| 输出方式 | 纯新增副本（`.gz` / `.br`） | 原文件一个字节不动，回退只需删副本 |

## 3. 实测结果（完整构建）

```
✓ built in 804ms
[compress-dist] 174 个文件 · 8.03MB → gzip 2.64MB (33%) · brotli 2.10MB (26%) · 15.4s
```

| 文件 | 原始 | `.gz` | `.br` |
|---|---|---|---|
| `cesium/Cesium.js` | 3,406,969 B | 918,181（27%） | 703,186（21%） |
| `assets/index-*.js` | 511,631 B | 174,119（34%） | 131,832（26%） |
| **首屏合计** | **3.74MB** | **1.05MB** | **0.80MB** |

产物：`.gz` 174 个 / 2.64MB，`.br` 174 个 / 2.10MB。

## 4. 验证清单（都实跑过）

| 检查 | 结果 |
|---|---|
| 解压后字节一致（不是「能压」而是「压对了」） | `Cesium.js`、`assets/index-*.js` 的 sha256：raw = gunzip = brotliDecompress，全一致 |
| 不该压的没压 | `.jpg.gz` / `.glb.gz` / `.png.gz` 共 0 个 |
| dev 不受影响 | 起 dev 实测 `GET /` 200、`GET /cesium/Cesium.js` 200（7.85MB unminified，符合 dev 走 CesiumUnminified 的预期）；冒烟用 dev 已关闭，5173 端口已交还 |
| dist 状态 | 重新打了完整产物（旧 `dist` 是 10-10 的，早于 10-15 新增的列车 glb） |

## 5. 生效边界（最容易踩）

- `.gz/.br` **只在真部署时有用**：nginx 需 `gzip_static on;`；brotli 还需 `ngx_brotli` 的 `brotli_static on;`。没有这两句，预压缩文件只是躺在目录里的普通文件。
- `vite preview` **不会**使用预生成的 `.gz/.br`，本地预览测不出收益；日常 dev（localhost）更是完全无感。
- 该前提已写入 `Translation/README.md` 的部署说明。

## 6. 已知取舍

- 构建变慢约 **15s**，几乎全花在 brotli q11（比 gzip 慢一个量级），换来 2.10 vs 2.64MB。
- 若嫌慢：把 `BROTLI_PARAM_QUALITY` 从 11 调到 9，可降到 2~3s，体积只差约 3%。这是单点改动，尚未执行（默认保留 q11）。
