---
id: "727cfe91-252c-4513-be57-710ddaf03945"
title: "DSH 定时能力三种载体对比与本机外壳补丁自检的定时方案设计（2026-10-10，desktop profile）"
description: "对比本机可用三种定时载体（Windows 任务计划程序 / dsh-schedule 的 schedule_create / 任务板 cron 卡）的能力边界与硬约束，并记录「外壳补丁自检」为何必须以 OS 层为主力的三层设计（OS 指纹触发 + 宿主机内 live 检查 + registry 依赖更新检测）。承接 ab5164f9、3b725cac、502b4a5c。"
status: "active"
created_at: "2026-10-10T03:49:34.821Z"
updated_at: "2026-10-10T03:49:34.821Z"
content_hash: "d12081253f07cec74ff86ce21df3fb8af1b307e3cb6b99f53e64e1b2783bcc3b"
source_paths:
  []
session_ids:
  - "0c299a67-fe16-4535-a533-5dc15e6eb22f"
memory_body_ids:
  []
---

# DSH 定时能力三种载体对比与外壳补丁自检方案设计

日期：2026-10-10（本机 desktop profile）。承接文档：
- `ab5164f9-c8fb-4ebb-befe-305e70609cb7`（框架版本来源 / 插件门控结论；其中记录「外壳补丁无自检」为运维缺口，本文是该缺口在「谁来定时」层面的展开）
- `3b725cac-20bd-4a06-b1d1-eae5d2348c6b`（dsh-plugin-gating-hub 调研）
- `502b4a5c-16a2-4ea4-953c-b861592308b7`（dsh-browser 安装实录）

## 0. 结论先行

要防的最坏时刻是「桌面更新抹掉外壳补丁」和「更新后 DSH 根本起不来」——**这两种情形下 DSH 侧的两个调度器都不可用**。因此定时自检的主力必须是 **Windows 任务计划程序（OS 层）**；`schedule_create` 与任务板 cron 卡只承担「需要活宿主」的那半场。三者不冲突，可叠加，但职责必须分清。

## 1. 三种载体对比（本机可用）

| 载体 | 谁在跑 | 宿主要活 | 烧 token | 错过怎么办 | 适合哪半场 |
|---|---|---|---|---|---|
| **Windows 任务计划程序**（`Register-ScheduledTask` → `pwsh -File verify.ps1`） | OS 直接执行 | ❌ 不需要 | ❌ 0 | 可设 StartWhenAvailable「错过就尽快补跑」 | 静态自检 + 依赖更新检测 + 自动修复 |
| **`schedule_create`**（框架包 `@deepseek-ai/dsh-schedule`，宿主级持久提醒） | 宿主定时器，到期把提醒投回**原会话** | ✅ 需要 | 极低（仅一条 user 消息） | 只补最近一次 | 「提醒我去看报告」 |
| **任务板 cron 卡**（`task_board_create` 带 `schedule` + 任务板自身调度线） | 宿主调度，**每次起一个真实会话** | ✅ 需要 | ✅ 真消耗配额 | 错过的发生点直接跳过，不补跑 | 「真的去跑 live 检查并汇报」 |

## 2. `dsh-schedule` 的硬约束与证据

来源（工作区外只读路径，便于复查）：`D:\DSH\dsh_data\DSH Desktop\resources\app\node_modules\@deepseek-ai\dsh-schedule\README.zh.md`，以及包内 `lib/index.js`、`lib/types/*`。

- **宿主必须运行才能投递**（README.zh.md:153「已知限制」首条）。恢复、入队或持久化失败时保留任务并记警告，**没有自动重试定时器**；且入队与任务写入不具原子性，崩溃恢复不保证恰好一次（README.zh.md:154）。
- **提醒绑定调用 Agent 的会话**；**归档仍有活动提醒的会话会被拒绝**，直到这些提醒停止，且取消归档不会把提醒带回来（README.zh.md:49）。⇒ 长期定时提醒不要挂在会被归档的会话上。
- **投递 ≠ 执行**：回执只确认消息进了会话收件箱，「不表示模型执行」（README.zh.md:65）。⇒「提醒我发了」不等于「检查真的跑了」；凡需真执行，走任务板卡或 OS 脚本。
- 六个选择器必须**恰选其一**：`after_seconds`（正安全整数秒）、`at`（严格未来绝对时点）、`every_seconds`（≥60 秒固定间隔）、`daily` / `weekly`（显式 IANA 时区的本地钟表时间，weekly 另带 ISO 星期集合）、`cron`（五字段 Vixie 方言，故最小间隔一分钟，不接受 `L`/`W`/`#`/名称/`@daily`/六字段）。每次创建必须给 `title`（去空白后非空且 ≤120 字符）。见 README.zh.md:28-45。
- 重复任务**只补最近一次错过的发生点**；夏令时不存在的时间被跳过、重复时间取较早时点。见 README.zh.md:12、:153-160。
- **随发行版的 Web 组合不含 `schedule` 行**；需在插件管理页「官方」分组启用可选实验性 bundle `@deepseek-ai/dsh-experimental-schedule-bundle`，或列进 profile 的 `dsh.profile.bundles`。它无法在 headless / 仅 SDK 组合中单独挂载（投递依赖 Host 的 Web Session controller 与 Session 持久化后端）。见 README.zh.md:26。
- 本机观察：本次会话中 `schedule_*` 工具**实际已可用**，说明桌面组合已挂上该服务，尽管它不在 `dsh.profile.bundles` 的显式列表里。任务板的 cron 是任务板自己的调度线（自行维护 next-run 与 `schedulerError`），与该实验性 bundle 不是同一个东西——bundle 被关掉，任务板卡仍应照跑。

## 3. 推荐设计：三层 + 指纹触发

**Layer 1 · OS 层（主力，零 token）**— `verify-shell-patch.ps1`。
关键设计是**指纹触发**而非「每天盲跑」：基线指纹 = `resources/app/package.json` 的 version + `electron-runtime-*.js` / `preload.cjs` / `lib/dsh-builtin-browser-shell.js` 的 SHA256 + `cordis.patch.yml` 中 `builtin-browser` 的 `controlPort` + 8 个 `link:` 目录的存在性与 `package.json` mtime。先比指纹，**变了才做全量校验**，未变则秒退；这样「桌面更新」这个事件会被自动抓住，不依赖恰好选对检查时刻。

触发器建议：登录时（延迟 30s，`-LogonType Interactive`——**不能用 S4U**，S4U 取不到网络会让依赖更新检测失效）；每日 09:30 兜底；勾 **StartWhenAvailable**；`-RunLevel Limited`（账户为 UAC 过滤态，静态检查无需提权）。输出：JSON 报告写固定路径，失败时写 `NEEDS_REPAIR` 标记；可选 `-Fix` 重放 `apply-shell-patch.mjs`（幂等，能力已具备）。

**Layer 2 · DSH 层（只跑需要活宿主的那半场）**：live 检查（`http://127.0.0.1:44721/browser/command?op=diag` 的 `webviewCount/iframeCount`、`op=ping`、43120 端口是否在监听）交给**任务板 cron 卡**，建议 `cron: "35 9 * * *"`、`Asia/Shanghai`、`permission: read-only`、`goalRun: false`（避免 /goal 把一轮变多轮）、`skipVerification: true`（验收闸门对体检任务只会添乱）、模型钉便宜的。结果通知直接复用 profile 里 `desktop-notifications` 已开的 `notifyOnScheduleCompletion/Failure`，无需另做。

**Layer 3 · 依赖更新检测（0 插件方案）**：读 `profiles/desktop/package.json` 的 15 个第三方依赖，对 npm 包查 `dist-tags.latest` 比对，8 个 `link:` 条目跳过。纯 registry HTTP，不需要 DSH，因此并入 Layer 1 脚本，不花 token。

## 4. 未决与待验证

- 截至本记录，`verify-shell-patch.ps1` **尚未编写**，schtasks 任务与任务板卡也**均未注册**；方案已向用户提出，等待其选择「直接开写脚本」还是「先列全 Layer 1 检查清单（哪些文件、哪些断言）」。
- 依赖更新检测依赖登录时能取到网络（故排除 S4U）；离线或代理受限环境需另行处理，未验证。
- 上述端口（44721 / 43120）与文件清单来自本次调查时的本机状态，外壳更新后需以指纹为准重新确认。
