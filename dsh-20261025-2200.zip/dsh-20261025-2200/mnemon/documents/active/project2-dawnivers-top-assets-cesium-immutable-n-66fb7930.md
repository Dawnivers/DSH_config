---
id: "66fb7930-d99f-4e90-af36-5b9689fb11b5"
title: "project2.dawnivers.top 前端静态资源缓存分层定案：/assets 与 /cesium immutable、入口 no-cache、瓦片 immutable 透传"
description: "project2 站点三档缓存分层（哈希产物与瓦片 immutable、入口 no-cache）、^~ 与 add_header 继承两个坑、666 与反代联动、验收 curl 与 PRELOAD_TRAIN 取舍。"
status: "active"
created_at: "2026-10-21T13:25:27.069Z"
updated_at: "2026-10-21T13:25:27.069Z"
content_hash: "88f5bd5fef683c22cbae736379cb3841b65593df0cac9e970e4ef041c052717a"
source_paths:
  - "src/views/cesiumView.vue"
  - "dist/index.html"
session_ids:
  - "e6aa613f-addf-4591-b69d-8d1ef753f899"
memory_body_ids:
  []
---

# 结论先行

前后端缓存是**三条互不依赖的链**，可以分开做、分开验：

| 链 | 依赖 | 目标头 | 状态（2026-10-21 实测） |
|---|---|---|---|
| 瓦片 `/nginx/Translation/...` | 666 server + 反代 | `public, max-age=31536000, immutable` | ✅ 已生效（公网已确认为 immutable） |
| 前端产物 `/assets/*`、`/cesium/*` | 站点 conf | 同上 immutable | ⬜ 已给完整配置，待落地验收 |
| 入口 `/` 与 SPA 回退 | 站点 conf | `no-cache` | ⬜ 同上 |
| 后端 API `/getLine` 等 | translationbe 反代 | `proxy_cache` + `X-Cache-Status` | ⬜ 可选，见 `7d3ba5c3-9ce9-4b7c-8105-0346b8cbba3d` |

关键事实：**缓存是纯服务器行为，前端代码一个字节都不用改**；反之改前端也不需要动 nginx。任何把「改 nginx」和「重传 dist」绑在一起的待办清单都是错的（本轮曾误并列，已作废）。

相关文档：反代定案 `664f423a-80ba-4ada-9bb2-37806b63ec04`；公网诊断 `933d3b7b-396a-4f92-a8ff-62bd719670a8`；后端 API 缓存 SOP `7d3ba5c3-9ce9-4b7c-8105-0346b8cbba3d`。

# 1. 站点与产物事实

- 站点 conf：`/www/server/panel/vhost/nginx/project2.dawnivers.top.conf`
- root：`/www/wwwroot/Translation/Project/dist`（dist 的**内部**直接铺在这一层）
- 瓦片落点：`/www/wwwroot/nginx_assets/Translation/{shangHaiBuilds_new_toPlane,EastProject}`，由 666 server 的 `location /nginx` 托管，再经 `/www/server/panel/vhost/nginx/proxy/project2.dawnivers.top/*.conf` 反代到 `127.0.0.1:666`
- 当前线上入口：`index-BVZzi3wr.js`（约 513KB）；构建时间 20:58 晚于源码最后修改 20:56 → 线上即最新源码版本
- 已有 `location / { try_files $uri $uri/ /index.html; }` 生效：`/realtime`、`/nodes` 均 200（SPA 刷新不再 404）
- 列车模型 `trainAndChisa_static-*.glb` 约 8.62MB；dist 内含约 348 个预压 `.gz`/`.br`

# 2. 三档缓存策略（为什么这么分）

按「URL 是否随内容变化」分档，而不是按文件类型：

1. **带内容哈希的产物** `/assets/*`、`/cesium/*` → `immutable` 一年。文件名变即新 URL，不存在「缓存了旧代码」。
2. **入口与 SPA 回退** `/` → `no-cache`。`index.html` 文件名不带哈希，必须每次校验，否则发版后老用户永远停在旧入口。
3. **瓦片** `/nginx/...` → `immutable` 一年。内容按目录版本静态化，且体积最大（单个 glb 数 MB），收益最高。

# 3. 站点 conf 的落地写法（只动三处）

插入点：`include /www/server/panel/vhost/nginx/proxy/project2.dawnivers.top/*.conf;` **之后**。

```nginx
# ① 哈希产物：一年 immutable；^~ 用来盖过宝塔自带的 location ~ .*\.(js|css)$
location ^~ /assets/ {
    try_files $uri =404;
    add_header Cache-Control "public, max-age=31536000, immutable" always;
    access_log off;
}

location ^~ /cesium/ {
    try_files $uri =404;
    add_header Cache-Control "public, max-age=31536000, immutable" always;
    access_log off;
}

# ② 入口 + SPA 回退：必须每次校验；同时补回 server 层被顶掉的 HSTS / Alt-Svc
location / {
    try_files $uri $uri/ /index.html;
    add_header Cache-Control "no-cache" always;
    add_header Strict-Transport-Security "max-age=31536000" always;
    add_header Alt-Svc 'quic=":443"; h3=":443"; h3-29=":443" always';
}
```

## 三个必须知道的 trap

- **`^~` 不是随意加的**：宝塔站点 conf 常自带 `location ~ .*\.(js|css)?$ { expires 12h; }`（正则）。正则优先级高于普通前缀，`/assets/index-BVZzi3wr.js` 会被它抢走套 12h。`^~` 的语义是「前缀命中后不再看正则」，正好盖住。
- **location 内只要写任一 `add_header`，就不再继承 server 层的 `add_header`**。原 server 层有 HSTS 与 Alt-Svc，一旦在 `location /` 加 Cache-Control，这两个头对主文档就消失（影响 Chrome HSTS 记录与 HTTP/3 协商）。所以要在该 location 内显式补回；`/assets/`、`/cesium/` 子资源可不补。
- **别同时用 `expires`**：`expires 30d` 会自动生成 `Cache-Control: max-age=2592000`，与 `add_header` 那条并存 → 浏览器取更短的那个。只保留一种写法。

## 可选：启用预压文件

dist 里 348 个 `.gz`/`.br` 目前没被用上（nginx 每次动态 gzip，`Cesium.js` 3.4MB → 约 800KB）：

```nginx
gzip_static on;   # 放 server 层，如 #ERROR-PAGE-END 之后
```

先跑 `nginx -t`；若报 `unknown directive "gzip_static"` 说明该 nginx 未编译此模块，删掉即可。

# 4. 瓦片链：666 server 与反代的联动

666 server（`server_name 101.43.119.248`，`alias /www/wwwroot/nginx_assets`）里改：

```nginx
autoindex off;          # 替换 autoindex on + autoindex_localtime on
add_header Cache-Control "public, max-age=31536000, immutable" always;
access_log off;
```

理由：`autoindex on` 时目录索引请求 1.4MB / 耗时约 30s，无意义且拖慢；`alias` 路径下文件名即版本，可以 immutable。

反代文件必须**同时去掉 no-cache**，否则 666 的头会被覆盖：

```nginx
#PROXY-START/nginx/
location ^~ /nginx/
{
    proxy_pass http://127.0.0.1:666;
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_http_version 1.1;
    proxy_set_header Connection "";
    proxy_buffering on;
    proxy_read_timeout 120s;
}
#PROXY-END/nginx/
```

注意：宝塔面板点「编辑→确定」会按模板重写该文件，`proxy_pass` 尾斜杠问题可能复现，见 `664f423a-80ba-4ada-9bb2-37806b63ec04`。

# 5. 应用与验收

```bash
CONF=/www/server/panel/vhost/nginx/project2.dawnivers.top.conf
cp -a "$CONF" "$CONF.bak-$(date +%Y%m%d-%H%M%S)"
# 覆盖后：
nginx -t && nginx -s reload
```

四条 curl（期望值即判据）：

```bash
curl -sI https://project2.dawnivers.top/assets/index-BVZzi3wr.js | grep -i cache-control
# public, max-age=31536000, immutable
curl -sI https://project2.dawnivers.top/cesium/Cesium.js | grep -i cache-control
# public, max-age=31536000, immutable
curl -sI https://project2.dawnivers.top/ | grep -iE 'cache-control|strict-transport'
# no-cache + HSTS 都在
curl -sI https://project2.dawnivers.top/realtime | grep -i cache-control
# no-cache（SPA 回退内容同为 index.html，不能缓存）
curl -sI https://project2.dawnivers.top/nginx/Translation/shangHaiBuilds_new_toPlane/10_529_599_512.glb | grep -i cache-control
# public, max-age=31536000, immutable（已通过）
```

诊断期的常见现象：`/assets/*.js` 与 `/` 只返回 `Last-Modified` + `ETag`、**完全没有 `Cache-Control`** → 说明两处 location 尚未落地，不是配置写错。

# 6. 附：开屏等待的取舍（PRELOAD_TRAIN）

`src/views/cesiumView.vue` 的 `const PRELOAD_TRAIN = true` 会让开屏等到列车 glb **真正解析完**：

| 设置 | 首次打开 | 进「线路轨迹」 |
|---|---|---|
| `true`（当前） | 3Mbps 下多等约 25s | 立即显示 |
| `false` | 2~4s | 首次进入需等模型 |

建议保持 `true`：演示前自己先打开一次预热（首次慢，之后走缓存），比现场点开发现模型不出稳。改为 `false` 需重新构建。
