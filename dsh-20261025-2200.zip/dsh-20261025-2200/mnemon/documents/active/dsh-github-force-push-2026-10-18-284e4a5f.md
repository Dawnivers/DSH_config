---
id: "284e4a5f-9725-4a26-bd8c-7ad334658199"
title: "DSH 配置周备份到 GitHub：单提交 force push 策略、代理探测与定时卡（2026-10-18 实测）"
description: "在既有 export/restore 迁移三件套之上，新增 publish-dsh.ps1 把每周迁移包（去附件、去密钥）压成约 69 MB zip 推到 Dawnivers/DSH_config，含单提交改写历史控体积的理由、GitHub 直连被 reset 必须走 127.0.0.1:7897 的实测、token 文件门闸、任务看板 cron 卡配置与验收/失败处理细则。"
status: "active"
created_at: "2026-10-18T02:30:37.375Z"
updated_at: "2026-10-18T02:30:37.375Z"
content_hash: "188ced95080cc8f509fb9ada8d8ad2b981a9254860ddca5b3f46adf3bf48dc05"
source_paths:
  - "dsh-migration/publish-dsh.ps1"
  - "dsh-migration/export-dsh.ps1"
  - "dsh-migration/RESTORE.md"
session_ids:
  - "e25fcc49-e0ac-443e-86a8-36338d4c4989"
memory_body_ids:
  []
---

# DSH 配置周备份到 GitHub（2026-10-18 实测）

承接文档 `07e71f80-40ef-4238-99b3-8ad8d4d37bc0`（DSH 整机迁移与备份方案：状态清单、export/restore 脚本与四个坑）。本文只记录**在此基础上新增的远端发布链路**：把每周导出包推到 GitHub 私有/公开仓库，并以任务看板定时卡自动执行。

相关卡片：任务看板 id `ead69e05-d364-4703-bce7-90dda8467e4e`（标题「DSH 配置周备份：打包并推送 GitHub」，`skipVerification: true`、`goalRun: false`，与既有「DSH 外壳补丁 live 体检」卡同形）。

## 1. 产物与调用链

工作区 `dsh-migration/`：

| 文件 | 职责 |
|---|---|
| `export-dsh.ps1` | 生成迁移包（home / mnemon / plugin-sources / profiles + `manifest.json`），本次改造为支持去附件、并能被发布脚本以 `-SkipAttachments` 等开关调用 |
| `restore-dsh.ps1` | 新机文件归位（见既有文档） |
| `publish-dsh.ps1` | **新增**：导出 → zip → 组装单提交 → force push → 写 `publish-state.json` |
| `RESTORE.md` | 人工验收清单，已补入远端备份章节 |

发布流水线：`pwsh -NoProfile -File .\publish-dsh.ps1` 一条命令完成，产物落 `D:\dsh-migration\<包名>.zip` 与 `D:\dsh-migration\publish-state.json`。

实测规模：去附件包 **1278–1279 文件 / 108.3 MB**，`bsdtar` 压缩后 **约 68.6 MB**，压缩耗时约 18 s。

## 2. 三个设计取舍（各自的理由）

### 2.1 单提交 + force push，而不是每周一个提交

每周 69 MB 正常提交，仓库一年会涨到 3 GB+。改写历史只保留最近 **2 份**包（本周 + 上周）+ `LATEST.json`（含 `sha256`、大小、生成时间）+ `README.md`，仓库体积恒定，备份可用性不受影响。远端分支从空仓库起步时 `git fetch refs/heads/main` 会失败（`couldn't find remote ref refs/heads/main`），脚本按「空仓库」处理而非报错。

### 2.2 硬闸排除附件与密钥

- 附件（`~/.dsh/attachments`，实测 345 个 / 180 MB）会把 zip 顶到约 250 MB，**超过 GitHub 单文件 100 MB 硬限**，故发布链路默认 `-SkipAttachments`。
- `.credentials.yaml` / `.env` 为明文密钥（见既有文档 §4.3），仓库曾按用户选择保持 **public**，因此脚本设硬闸：发现这两个文件出现在包内即拒绝发布。独立复核方式：检查包内 `home\` 下不存在二者，且 `.dsh` 中 `credentials present / env present` 均为 False、包根有 `withheld note` 说明。
- 副作用：包里有 `MEMORY.md` / `USER.md`（项目路径、习惯、踩坑史），public 仓库意味着这些内容对所有人可见。曾向用户明确指出，用户选择保持 public；若改 private 只需改仓库可见性，脚本不变。

### 2.3 自动探测本机代理

实测本机**直连 GitHub 不通**：`git ls-remote` 返回 `Recv failure: Connection was reset`（exit 128），`curl` 直连 12 s 超时但 `https_code=200`。`127.0.0.1:7897` 上有代理在听：经它 `curl` 用时 2.03 s、`git ls-remote` exit=0。

因此脚本按端口序列（7897 / 7890 / 10809 …）探测可用代理并注入 `http_proxy`/`https_proxy` 与 git 配置，**不要手工改全局代理配置**；脚本自身也只重试一次代理探测。

## 3. 认证：token 文件门闸（GCM 不可用）

- 本机**没有 `gh` CLI**（`gh: 术语 'gh' 不会被识别为…`）；Git Credential Manager 版本 `2.0.886+ea93cb5158`，只有 `manager` helper，`credential.https://gitee.com.provider=generic`，**GitHub 账号未登录**。
- 非交互环境下无法弹窗：`fill failed: Cannot prompt because user interactivity has been disabled` / `could not read Username for 'https://github.com'`。
- 方案：用户把**一行** Fine-grained PAT 写入 `%USERPROFILE%\.dsh-config-publish\token`（目录已建、ACL 收为仅本人可读，内含 `README.txt` 写创建步骤：Repository access 选该仓库，Permissions 仅 **Contents: Read and write**）。脚本读文件、不读环境变量，`GITHUB_TOKEN` 形式的既有配置条目当时为未配置状态。
- 已知状态：建卡时 `token file exists: False`，即首次定时执行前需用户补 token，否则当晚 22:00 首跑会失败（失败记录留在卡上，不损坏任何东西）。

## 4. 定时卡配置与执行契约

- 调度：cron `0 22 * * 0`（每周日 22:00，Asia/Shanghai），标签「备份」，todo 列，权限走会话默认（danger-full-access）。
- 卡内 prompt 固定了「验收必须逐条核对，不许只看脚本退出码」：`publish-state.json` 的 `result` 必须为 `pushed` 且 `sizeMB` 与 zip 一致；用 `curl.exe -x http://127.0.0.1:7897` 查 `api.github.com/repos/<owner>/<repo>/contents?ref=main` 确认出现新 zip 与 `LATEST.json`，且 `LATEST.json` 的 sha256 与本地 `Get-FileHash` 一致；包内 `home\` 不得含密钥文件；远端 zip 数量应为 2，多于 2 说明保留策略失效需在结论中指出。
- 失败处理：token 401/403 立即停止、只报「token 需要更新」并给文件绝对路径，不重试多轮；网络失败把 git stderr 原文抄进结论；**任何情况下不删 `D:\dsh-migration` 下既有 zip**——推送失败时那是唯一副本。

## 5. 复跑与清理注意

- Dry-run 与探针曾把包生成到单独根（`_probe` / `_scratch`）验证全链路，验证后删除；发布用的临时 git 工作目录在 `%TEMP%\dsh-config-publish-*`，每次跑完清理，不在工作区留痕。
- 只保留最近两三个本地包即可（单个约 69–290 MB）。**含密钥与附件的完整包（如 288 MB 的 `dsh-20261018-1014`）只留在本机或移动硬盘，绝不上传**。
