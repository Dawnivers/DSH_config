---
id: "e2a4925e-c390-44f3-bd15-8bf165e70b28"
title: "GeoServer 发布武汉 admin_area：数据库实为 Spatial、工作区/Store/图层三步与常驻启动方案（2026-10-23 实测）"
description: "承接 GeoServer 安装实录之后的一天：本机业务库实际叫 Spatial（大写、大小写敏感）而非原计划的 gis_demo；库内 admin_area 已灌入武汉 13 区并核对坐标系/几何/字段；记录 GeoServer 里 workspace → PostGIS Store → 发布图层的精确填写项与验收方式，以及用 VBS 脱离后台任务常驻启动的办法和 DSH 后台任务会连坐杀死子进程的坑。"
status: "active"
created_at: "2026-10-23T10:51:19.692Z"
updated_at: "2026-10-23T10:51:19.692Z"
content_hash: "496f7b5c18647f967b37060c0cd70162015670143b14dc785482f6bf9bc94a7c"
source_paths:
  - "gis-prep/geoserver-first-map.png"
session_ids:
  - "9209da7f-76b7-455e-98d8-124523a4b80d"
memory_body_ids:
  []
---

# GeoServer 发布武汉 admin_area 实录（2026-10-23 续）

前情：安装与验真见 `e2e0d83d-62f3-4208-a3c8-fffc9439376f`（该文末的遗留项「gis_demo 不存在」已由本文修正）；数据入库的 ogr2ogr 坑见 `bd491158-552e-4d9e-b899-a8fff4453827`；上层项目设计与里程碑见 `266aea70-7a25-4d94-8359-39555b8b651f`。本文只记这两件事：**这台机器上数据库的实际情况**，以及**把一张表发布成图层并验收的完整动作**。

## 1. 环境事实修正（重要）

| 项 | 实际情况 |
|---|---|
| 业务库名 | **`Spatial`**，大写 S。由用户自行创建并已灌好数据 |
| 原计划库名 | `gis_demo` —— 用户跳过了那一步，改为自建 `Spatial`；Day 1 的建库命令作废 |
| PostgreSQL | 18.4，`psql` 在 `D:\PostgreSQL18.4\data\18\bin\psql.exe`（非 PATH） |
| PostGIS | **3.6.2**（`postgis` + `plpgsql` 两个扩展已装，`USE_GEOS=1 USE_PROJ=1 USE_STATS=1`） |
| 同实例其它库 | `postgres`、`db1`、`student_db`、`exam`、`fencengfenhu`、`Translation`、`Spatial` |
| JDBC 驱动 | `postgresql-42.7.13.jar` 已放进 `D:\geoserver\webapps\geoserver\WEB-INF\lib\`，因此不会出现 `No suitable driver` |

**库名大小写敏感是这台机器上的首要坑**：`-d spatial` 或 `-d "Spatial"`（多一层引号）都会报「数据库不存在」。psql 与 GeoServer 的 database 字段都必须写 `Spatial`。

## 2. 库里的数据是合格的（发布前先验）

表 `admin_area`：

- 13 条记录 = 武汉 13 个区
- 坐标系 `EPSG:4326`，几何类型 `MULTIPOLYGON` ✓
- 名称字段 `name`，中文正常（江岸区 / 江汉区 / 硚口区 …）
- 额外可用字段：`center`、`centroid`、`adcode`、`acroutes` —— 后续做热力图、分级统计、按 adcode 关联都能直接用，不必再补数据

结论：数据层不需要返工，问题只剩「发布」。

## 3. GeoServer 发布三步（UI 路径与填写项）

入口 `http://localhost:8080/geoserver`，出厂账号密码未改。

**① Workspace（命名空间）**：Workspaces → Add new workspace
- Name `wuhan`，Namespace URI `http://wuhan.local`
- 作用：决定图层全名为 `wuhan:admin_area`，而不是裸 `admin_area`；多项目隔离靠它

**② Store（PostGIS 数据源）**：Stores → Add new store → PostGIS
- Workspace `wuhan`，Data Source Name `spatial_db`
- host `localhost`，port `5432`，database **`Spatial`**，schema `public`，user `postgres`
- Save 后会直接跳到 New Layer 列表

**③ Layer（发布）**：勾选 `admin_area` → Publish
- Name `admin_area`，Title `武汉行政区`
- Declared SRS `EPSG:4326`
- Native Bounding Box 点 **Compute from data**；Lat/Lon Bounding Box 点 **Compute from native bounds**

## 4. 验收标准（两层，别只看一层）

1. **UI 层**：Layer Preview → `wuhan:admin_area` → OpenLayers，看到 13 个区轮廓。
2. **服务层**：另用 WMS 接口（`GetMap` 直接请求）验一次。

两层不是一回事：预览页能显示不代表服务本身可被前端/后端调用。这与装 GeoServer 时的验真思路一致——端口通不算装好，`GetMap` 返回 PNG 才算。

## 5. 常见故障对照

| 现象 | 原因 |
|---|---|
| Save 报 `Connection refused` | host/端口写错，或 PostgreSQL 没在跑 |
| 表列表为空 | database 填了小写 `spatial`，或 schema 不是 `public` |
| 能发布但预览黑屏 | Bounding Box 没 Compute，被手填成 0 |
| `No suitable driver` | 不该出现（驱动 jar 已确认在位） |

## 6. 让 GeoServer 常驻的正确做法

**DSH 后台任务不适合跑长期进程**：任务结束时会终止整个进程树，GeoServer 的 Java 子进程被连带杀掉，8080 立即无响应（实测表现为 `curl` 返回 000）。

现行方案（`D:\geoserver\` 下）：

| 文件 | 作用 |
|---|---|
| `启动GeoServer.vbs` | 双击启动，无黑窗口，后台拉起并弹 5 秒提示 |
| `停止GeoServer.bat` | 走 Jetty 停止端口 8079 正常关闭（`-DSTOP.PORT=8079 -DSTOP.KEY=geoserver`） |
| `start-geoserver.bat` | 实际启动脚本，JVM 参数写在这里（含 marlin 渲染器 patch 与一批 `--add-opens`） |

实测状态：由 `cmd /c "cd /d D:\geoserver\bin && startup.bat"` 拉起的 Java 进程在父 cmd 退出后成为孤儿进程，**反而更稳**（不再挂在任何任务/会话下，不会被回收）。启动约 3 s 到 HTTP 302（热启动），冷启动约 21.5 s。

开机流程：双击 `启动GeoServer.vbs` → 等 25 s → 打开 `http://localhost:8080/geoserver`。数据在 `data_dir`，重启不丢。

## 7. 可选捷径

同样的三步也可以走 GeoServer REST API 一次建完（更快），但会失去「UI 里每个字段对应什么」的认知。学习阶段建议先手动走一遍，再用 REST 批量复制。
