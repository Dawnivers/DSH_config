---
id: "ac6baad9-9666-4ff6-99ff-d67b6334c628"
title: "pnpm 11 (DSH 自带) 与 pnpm 10 安装的 node_modules 不兼容导致 pnpm dev 中止：诊断链与 pnpm-workspace.yaml 修复（Translation，2026-10-11）"
description: "Translation 跑 pnpm dev 报 ERR_PNPM_ABORTED_REMOVE_MODULES_DIR_NO_TTY 的完整根因链（store v10/v11 格式不兼容 + verify-deps-before-run 默认改 \"install\"）、报错提示 CI=true 的危险性、以及「pnpm 11 不读项目级 .npmrc、必须写 pnpm-workspace.yaml」的实测结论与修复验证矩阵。"
status: "active"
created_at: "2026-10-11T03:00:32.808Z"
updated_at: "2026-10-11T03:00:32.808Z"
content_hash: "b95c232f394a7c44e604f218dace1687ee0df40270d65c692d6fc9472c7b4d19"
source_paths:
  - "Translation/pnpm-workspace.yaml"
  - "Translation/package.json"
  - "Translation/pnpm-lock.yaml"
session_ids:
  - "9326c057-ef85-4c1e-876f-0d105d23ce46"
memory_body_ids:
  []
---

# pnpm 11 与 pnpm 10 装的 node_modules 不兼容：`pnpm dev` 被中止

排查日期：2026-10-11。项目：`D:\WebGIS\web三维开发\智慧地铁项目\Translation`。
现象：`pnpm dev` 抛 `ERR_PNPM_ABORTED_REMOVE_MODULES_DIR_NO_TTY`，提示要清理 `node_modules`，但等待 TTY 确认后中止。

相关文档：
- `46077717-b034-4315-a3c1-f04be09fed52`（Translation Cesium KeepAlive 改造，§4 记录了「从会话起 vite 会继承 NODE_ENV=production」这一同宿主环境陷阱）
- `bc1691b2-c8c1-41ad-a301-37cac4c79602`（pnpm store 误删事故；本文与其是两个不同的 store 问题，方向相反：那边是 store 被删，这边是 store 版本错位）

## 1. 根因链（每一环均有源码行号或实测支撑）

**① store 路径错位（v10 vs v11）**
- 现在生效的是 DSH 自带的 pnpm 11.8.0，真身在 `D:\DSH\dsh_data\DSH Desktop\resources\app\node_modules\pnpm\dist\pnpm.mjs`（单文件打包，行号可直接引用）。
- `node_modules/.modules.yaml` 记录 `packageManager: pnpm@10.33.0`、`storeDir: D:\.pnpm-store\v10`；而当前 pnpm 解析出的 store 是 `D:\.pnpm-store\v11`（该目录在排查当天 10:53 才被创建）。
- v10 的 store 用散装 `index` 文件，v11 用 `index.db`，**格式互不兼容**，故 pnpm 判定 `node_modules` 必须重建。

**② `pnpm dev` 会先偷偷跑一次 `install`**
- pnpm 11 把 `verify-deps-before-run` 的默认值改成了 `"install"`（`pnpm.mjs:145996`），并在配置类型表中登记（`pnpm.mjs:145692`）。
- 复现堆栈直接点名：
  `at runDepsStatusCheck (pnpm.mjs:248213:7)` → `[ERROR] Command failed: … pnpm.mjs install`。
- 该 switch（`pnpm.mjs:248211`–`248247`）**没有 `default` 分支**，因此任何非 `install` 的值（包括字符串 `"false"`）都等价于「什么都不做」。

**③ 判定重建 + 无 TTY → 中止**
- store 不符 → 在 install 流程里被转成「推倒重建」；随后发现没有 TTY，直接抛出用户看到的那条错（相关判定与抛错位于 `pnpm.mjs:188553` / `188645`–`188650` 一带）。
- 实测确认：该次报错 **没有删除任何文件**，`node_modules` 完好（`lastValidatedTimestamp` 与三个关键文件 mtime 均未变）。

## 2. ⚠ 报错自带的建议是陷阱，绝不要照做

报错提示「设 `CI=true`」。源码 `pnpm.mjs:189470`：

```js
confirmModulesPurge: opts3.confirmModulesPurge && !opts3.ci
```

`CI=true` 会让该开关变 `false` → 跳过确认 → **真的执行 `removeContentsOfDir` 删掉 `node_modules` 并联网重装**。`confirm-modules-purge=false` 同理。本机不是 CI 环境，照做等于白丢一整套依赖。

## 3. 修复（已实施并验证）

新增 `Translation/pnpm-workspace.yaml`：

```yaml
verifyDepsBeforeRun: false
```

要点：
- **键名必须是 camelCase**（`verifyDepsBeforeRun`），不是 `.npmrc` 风格的 kebab-case。
- 附带的 YAML 注释若含中文，需确认文件按 UTF-8 读取，否则注释会变乱码（本次出现过该现象，不影响配置解析）。

## 4. 关键坑：pnpm 11 不读项目级 .npmrc 里的 pnpm 专属设置

- 先写的 `.npmrc`（含 `verify-deps-before-run=false`）**完全无效**，报错一字不差；`pnpm config get verify-deps-before-run` 返回 `undefined`。
- 用 `store-dir` 探针隔离验证：在项目 `.npmrc` 里加 `store-dir` 后执行 `pnpm store path`，输出仍是 `D:\.pnpm-store\v11`，**纹丝不动** → 文件根本没被加载（排除「键写错」这一可能）。该 `.npmrc` 已删除。
- 源码印证方向：`pnpm.mjs:146057` 的警告文案写着 `Move them to a project-level pnpm-workspace.yaml`。
- 边界：**用户级 `~/.npmrc` 仍然生效**（本项目的 registry 即来自那里）；项目级 pnpm 专属设置一律走 `pnpm-workspace.yaml`。

## 5. 验证矩阵（均实测）

| 场景 | 条件 | 结果 |
|---|---|---|
| 修复前 | `pnpm dev` | ❌ 报 NO_TTY，堆栈落在 `pnpm.mjs:248213` |
| 方案 A | 项目 `.npmrc` | ❌ 依旧报错（配置未被读取） |
| Test A | 环境变量 `pnpm_config_verify_deps_before_run=false` | ✅ Vite ready |
| Test B | 仅 `pnpm-workspace.yaml` | ✅ Vite ready |
| **最终** | **删掉 `.npmrc` 后干净启动，零绕行变量（仅 `NODE_ENV=development`）** | ✅ `VITE v8.3.0 ready in 711 ms` |

最终态服务（2026-10-11）：5173 前端 Vite、8092 后端（`/getLine` 返回 56770 字节，注意正确路径是 `/getLine` 而非 `/api/getLine`）、666 nginx 瓦片；`/`、`/src/main.js`、`/src/App.vue`（31918 B，SFC 编译正常）均 HTTP 200。

临时绕行手段（不推荐长期使用）：`node node_modules/vite/bin/vite.js`；环境变量 `pnpm_config_verify_deps_before_run=false`（pnpm 会读 `pnpm_config_*` 形式的环境变量）。

## 6. 未实施的可选项：彻底对齐 store

若要让 store 真正匹配（而不是绕开自检）：删掉配置行，在**带真实 TTY 的终端**里执行 `pnpm install` 并手动确认，会联网重装一轮依赖。当前 `node_modules` 完整可用，判断是不值得为「消除一处自检」重装依赖。

## 7. 可复用的通用教训

1. DSH 自带 pnpm 升级（10 → 11）会让旧项目 `node_modules` 的 store 版本失配，症状是 `pnpm dev` 莫名中止而非安装失败——先查 `.modules.yaml` 的 `storeDir` / `packageManager` 与 `pnpm store path` 是否同版本。
2. pnpm 11 起「项目级 pnpm 专属配置」只认 `pnpm-workspace.yaml`；`.npmrc` 只用于 registry/auth 这类 npm 兼容项。
3. 排查第三方 CLI 行为时，直接读其打包单文件源码并用行号定位分支，比猜配置优先级更快；DSH 自带工具的源码就在 `resources\app\node_modules\` 下。
4. 对「会删目录」的提示，先读源码确认在无 TTY 时是否会真的执行，再决定是否复现——必要时先用探针做只读验证。
