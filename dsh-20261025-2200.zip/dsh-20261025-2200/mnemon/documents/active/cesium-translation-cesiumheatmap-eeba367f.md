---
id: "eeba367f-a6db-44b9-a14c-a185f6d329bd"
title: "Cesium 热力图实现机制调研与移植 Translation 的落点差异（cesiumHeatMap 源码精读）"
description: "2026-10-18 精读参考项目 smart-subway-warehouse 的 cesiumHeatMap.js / effectController.js / StationManage.vue，梳理「heatmap.js 离屏 canvas → PNG → SingleTileImageryProvider 贴地」四步流水线、bbox 与半径随相机高度这两个决定效果的参数、destory 拼写等坑，并列出移植到 Translation 的四处差异（无落点组件、Cesium 取法不同、bbox 需换上海并现算、坐标字段为 xy_coords 字符串）。"
status: "active"
created_at: "2026-10-18T10:39:28.399Z"
updated_at: "2026-10-18T10:39:28.399Z"
content_hash: "618b7fb397c78cbba0830e0b52cc3f79437307c076149847773185bdf4144d88"
source_paths:
  - "综合项目：智慧地铁/smart-subway-warehouse/src/cesiumTools/cesiumHeatMap.js"
  - "综合项目：智慧地铁/smart-subway-warehouse/src/cesiumTools/effectController.js"
  - "综合项目：智慧地铁/smart-subway-warehouse/src/views/StationManage.vue"
  - "Translation/package.json"
  - "Translation/src/cesiumTools/DayorNigjt/DayorNight.js"
  - "Translation/src/cesiumTools/sceneManager.js"
session_ids:
  - "62b7348c-bb66-444d-a251-2252f1707f52"
memory_body_ids:
  []
---

# Cesium 热力图实现机制与移植到 Translation 的差异

日期：2026-10-18。目标项目：`D:\WebGIS\web三维开发\智慧地铁项目\Translation`；参考实现：`综合项目：智慧地铁\smart-subway-warehouse`。
来源：语雀「站点拥挤度」一节的代码全在截图里无法提取，改为直接精读参考项目源码。

相关文档：`3a0ce399-303d-4a00-95ef-e3c3d0db18af`（StationPanel 实现）、`1056d83b-fc4b-4598-834b-404ed7f42702`（路由驱动，热力图挂载路由时需遵守其分层约定）。

## 1. 原理一句话

热力图不是 Cesium 实体，而是 **heatmap.js 在离屏 canvas 上画一张 PNG，再当作 `SingleTileImageryProvider` 影像层铺在地面上**。所谓「适配 Cesium」核心只有约 20 行。

## 2. 四步流水线

| 步 | 做什么 | 位置 |
|---|---|---|
| ① 建画布 | 按 bbox 比例反推 canvas 尺寸，挂进离屏 div | `cesiumHeatMap.js` L39–78 |
| ② 经纬度→像素 | 线性等距映射，y 轴翻转 | L215–223 |
| ③ 出图 | `heat.getDataURL()` | L179 |
| ④ 贴地 | `imageryLayers.addImageryProvider(…)` + `Cesium.Rectangle.fromDegrees(…bbox)` | L172–183 |

换算（注意 y 是反的）：

```
px = (lng - left)  / width  * canvasW
py = (top - lat)   / height * canvasH
```

**故意不用 Cesium 投影**：贴图最终被线性拉伸到 `Rectangle` 上，两边都用同一种等距映射才能像素级对齐。

## 3. 三个决定效果的参数

**① bbox 决定清晰度，比总像素重要。** canvas 尺寸不手填，按面积反推：`h = √(height × totalArea)`、`w = h × width / height`（L45–46）。参考项目 `totalArea = 1036800`、bbox 为武汉 `[114.03, 30.2, 114.45, 30.9]`（0.42°×0.7°），算出仅 **510×851**。小图能清楚是因为 0.42° 只覆盖一座城；同样像素套全球 bbox 就会像注释写的「拉近后巨模糊」。

**② 半径随相机高度变化**（L152–166）：`h = camera.getMagnitude()`（地心距 6375000~10000000），`radius = minR + (maxR-minR)·(h-min)/(max-min)`，`minR = 10 / maxR = 40`。触发点 `camera.moveEnd`，200ms throttle trailing（L23）。这是「拉近点变集中、拉远晕成一片」的手感来源。

**③ 每次更新是「删层再建层」，不是改 canvas**（L173–176）。dataURL 是快照，改完 canvas 已加入的 provider 不会跟着变。因此**绝不能挂到 `postRender` 里更新**——源码那行注册是被注释掉的，留着会每帧重建影像层把帧率打死。

## 4. 数据与生命周期

- 数据格式 `{x: lng, y: lat, value}`；`autoMaxMin: true` 由数据推导 max/min（L99–112）。参考项目本身是假数据 `Math.ceil(Math.random()*1000)`（`StationManage.vue` L209）。
- `renderHeat(viewer, dataSource)` 返回**销毁闭包**（`effectController.js` L560–580），视图侧存为 `removeHeat`；切查询模式时先 `recoverEffect()` 再 `handleEffect()`，`onBeforeUnmount` 也 recover（`StationManage.vue` L126–155）。
- 销毁方法名拼成 **`destory`** 而非 `destroy`（L228）——照抄时按原拼写调用，否则 `removeHeat()` 静默不生效，影像层删不掉。
- canvas 挂载在 body 下两个 **0×0 / `z-index:-100` 的离屏 div**（L62–75），从不展示；不要塞进 `viewer.container`。

## 5. 移植到 Translation 的差异点

依赖已齐：`Translation/package.json` 已有 `cesium-heatmap-es6@0.8`、`heatmap.js-fixed@2.0.2`、`lodash`（L17–21），`node_modules` 也在，无需新装。

需要处理的四处：

1. **没有落点组件**：Translation 无 `StationManage.vue` / `effectController.js`；站点体系是 `StationPanel` + `stationState` 四量状态 + `popup.js`。热力图应挂到站点管理相关面板的「查询模式」分支，而不是复制参考项目页面结构。
2. **Cesium 取法不同**：参考项目用工厂注入 `export default (Cesium) => class` + `getCesiumHeat(Cesium)`；Translation 全项目 `import * as Cesium from 'cesium'`，移植时改掉这层。
3. **bbox 必须换成上海且现算**：硬编码武汉 bbox 会把热力图贴到武汉去。用 18 条线全部站点的 min/max lng/lat 现算，正好一个城市框。
4. **坐标字段不同**：参考项目读 `station.position.lng/lat`；Translation 的 `station.xy_coords` 是 `"lng,lat"` 字符串，需先 `split(',')`。

## 6. 一个已占到的便宜

`DayorNight.js` 只对 `imageryLayers.get(0)` 调亮度（L83–86），所以热力图作为第 1 层既不会被底板切换删掉，也不会在夜间被压暗——不会重演此前「点实时轨迹突然变夜景」那类事故。

## 7. 待办

用户尚未确认是否落地。若要实施：新建 `Translation/src/cesiumTools/cesiumHeatMap.js` + 站点管理的拥挤度查询分支 + 假数据接口。
