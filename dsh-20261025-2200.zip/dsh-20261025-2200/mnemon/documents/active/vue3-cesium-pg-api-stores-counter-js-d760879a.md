---
id: "d760879a-f677-4859-9ad7-ddbdc04a93f3"
title: "分层分户项目（Vue3 + Cesium + pg-api）：本机三服务启动链路与缺失 stores/counter.js 修复"
description: "分层分户项目（D:\\WebGIS\\web三维开发\\分层分户项目）本机启动手册：前端 5174、后端 8090、瓦片 nginx 666 三服务端口与启停命令，依赖安装与 pnpm 忽略构建的退出码含义，src/stores 整体缺失导致六个文件 import 失败的根因与从「上线版」复制 counter.js 的修法，附版本分叉提醒与实测证据。"
status: "active"
created_at: "2026-10-21T15:03:54.690Z"
updated_at: "2026-10-21T15:03:54.690Z"
content_hash: "27491616f33128002bf252d54f2a03e9ad2b0ad6d1e12fdc278225812c37782f"
source_paths:
  []
session_ids:
  - "d6ebdb60-e267-4909-ba33-4bcaccb6d565"
memory_body_ids:
  []
---

# 分层分户项目：本机三服务启动链路与缺失 store 修复

项目根：`D:\WebGIS\web三维开发\分层分户项目`，下含 `Project`（Vue 3 + Cesium 前端）与 `pg-api`（Express 5 + pg 后端）。
同族参考文档：`d6dc91dd-bff2-4971-897a-5b2fe5bf1580`（Translation 智慧地铁的启动与联调，pnpm 自检绕过思路同源）；`1056d83b-fc4b-4598-834b-404ed7f42702` 曾引用本项目 `App.vue` 作为「三维组件与 RouterView 平级」的范本。

## 1. 三服务与端口

| 服务 | 地址 | 说明 |
|---|---|---|
| 前端 Vite dev | `http://localhost:5174/` | 开发服务器；5173 已被「智慧地铁」占用，故顺延到 5174 |
| 后端 API | `http://127.0.0.1:8090` | `pg-api/app.js`，Express 5 + pg；实测 `/api/v1/getBuild` 返回 200 + 真实楼栋数据 |
| 三维瓦片 | `http://localhost:666` | 既有 nginx，非本项目启动；`/model` 下地形（`PengJiang_Terrian`，`layer.json` + `*.terrain?v=1.1.0`）与倾斜模型（`model/tileset.json` + `Tile_+00x_+00y`） |
| 数据库 | `127.0.0.1:5432` | PostgreSQL 18，库 `fencengfenhu`，含 building / household / unit + PostGIS |

## 2. 依赖安装

```powershell
# 后端
cd D:\WebGIS\web三维开发\分层分户项目\pg-api
npm install          # 101 包，缓存指向 D:\npm-cache

# 前端
cd D:\WebGIS\web三维开发\分层分户项目\Project
pnpm install         # 419 包，store 在 D:\.pnpm-store\v11，缓存指向 D:\pnpm-cache
```

前端实际装到的版本：vue 3.5.41 / vite 8.2.2（rolldown 打包）/ cesium 1.99.0 / pinia 4.0.3 / vue-router 5.2.0 / ant-design-vue 4.2.6 / @turf/turf 6.5.0 / axios 1.19.0 / vue-request 2.0.4 / vite-plugin-cesium 1.2.23 / lodash 4.18.1。

**pnpm 退出码 1 不等于失败**：报 `ERR_PNPM_IGNORED_BUILDS`（`core-js@3.50.0`、`protobufjs@7.6.5`、`vue-demi@0.14.10` 的 postinstall 被跳过）时包已全部就位、页面能跑。只有真出现 vue-demi 相关报错才需要 `pnpm rebuild vue-demi`（或 `pnpm approve-builds`）。

## 3. 关键故障：整个 `src/stores/` 目录缺失

现象（Vite 8 / rolldown）：

```
[UNLOADABLE_DEPENDENCY] Could not load src/stores/counter.js
Pre-transform error: Failed to resolve import "@/stores/counter" from "src/views/CesiumView.vue"
Pre-transform error: Failed to resolve import "@/stores/counter" from "src/components/edit.vue"
```

页面能起、静态壳子能渲染，但 `pre-bundling` 扫描直接失败（`Failed to run dependency scan`），随后各组件逐个 pre-transform 报错。

排查结论：`Project/src` 里**没有 `stores` 目录**，而六个文件都在 import 它——`App.vue`、`edit.vue`、`ScanInfo.vue`、`CesiumView.vue`（`@/stores/counter`）与 `SetBuild.vue`、`SetInfo.vue`（`../stores/counter`）。

修法：从同项目的上线版复制缺失文件

```
源：D:\WebGIS\web三维开发\分层分户项目 - 上线版\Project\src\stores\counter.js  (1.72 KB)
目标：D:\WebGIS\web三维开发\分层分户项目\Project\src\stores\counter.js
```

`counter.js` 内容为 pinia 的 `useMapData`（store id `lineData`）：state 持有 `viewer / tileset / showEdit / rowdata`，getters `Viewer / Tile / ShowEdit / RowData`，actions `setViewer / setTileset / openShowEdit / closeShowEdit / updateRowData`（其中 `setViewer`、`setTileset` 返回 Promise）。复制后 Vite 热重载（日志 `page reload src/stores/counter.js`）即恢复，依赖预打包正常完成。

## 4. 版本分叉提醒（重要）

两目录 `src` 文件清单对比只差 `stores\counter.js` 这一个文件，但**同名文件大小有差异**，说明并非纯副本：

- `api/baseApi.js` 1.20 KB vs 上线版 1.30 KB
- `ScanInfo.vue` 12.10 vs 11.90
- `SetBuild.vue` 28.60 vs 30.10
- `SetInfo.vue` 26.40 vs 26.10

因此只补了缺失的 store，**没有覆盖当前项目的任何已有文件**。若后续某功能行为对不上，优先怀疑这几处版本分叉，逐个比对而不是整体覆盖。

## 5. 启停命令

```powershell
# 停后端 (8090)
Get-NetTCPConnection -LocalPort 8090 -State Listen | % { Stop-Process -Id $_.OwningProcess -Force }
# 停前端 (5174)
Get-NetTCPConnection -LocalPort 5174 -State Listen | % { Stop-Process -Id $_.OwningProcess -Force }
```

```powershell
# 重开：后端先起
cd D:\WebGIS\web三维开发\分层分户项目\pg-api
node app.js

cd D:\WebGIS\web三维开发\分层分户项目\Project
$env:NODE_ENV='development'   # 必须；否则 Vue 开发语义（热更新/警告）全部失效
node node_modules\vite\bin\vite.js --port 5174
```

## 6. 实测验证证据

- 浏览器打开 `http://localhost:5174/`：标题 `Vite App`，顶部三个入口均可点 —— 楼房分户 `/setBuild`、房户信息 `/setInfo`、信息查看 `/scanInfo`；三维场景加载出彭江片区实景倾斜模型。
- `/setBuild` 正常渲染三步流程：1 区域绘制 / 2 户型切分 / 3 楼房分层，含「绘制户型 / 绘制图形 / 分户坐标·地址前缀·单位·操作 / 下一步」表格。
- 资源请求：对 `localhost:666` 的请求累计 191 条（`model/PengJiang_Terrian/layer.json`、`model/model/tileset.json`、各级 `Tile_+003_+00x` 均 200）。
- 无 `/api` 失败请求（`{"api":[],"total666":191}`）。
- 截图里页面底部黑边是**无头浏览器取景高度差**（innerHeight 805 vs 视口 900；`innerH/bodyH 805`、`canvasH 712`、`viewerH 719`），不是布局 bug。

## 7. 遗留小事

- `index.html` 的 `<title>` 仍是模板默认的 `Vite App`，未改。
- 前端未配置 server.proxy，前端直连后端绝对地址（与 Translation 项目一致）。
