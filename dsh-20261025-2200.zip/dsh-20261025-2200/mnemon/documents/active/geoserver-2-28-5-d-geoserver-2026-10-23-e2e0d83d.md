---
id: "e2e0d83d-62f3-4208-a3c8-fffc9439376f"
title: "GeoServer 2.28.5 本地部署实录：装到 D:\\geoserver 并验证真能出图（2026-10-23）"
description: "GeoServer 2.28.5 在本机落地的运维记录：实际安装位置与目录结构、启动/停止命令与环境变量现状、为什么把 D 盘根目录的散装文件归位（含哪些 D:\\ 目录属于别的软件不能动）、用 WMS GetCapabilities + GetMap 验真的方法、无害告警清单、以及仍未建 gis_demo 库的遗留项。"
status: "active"
created_at: "2026-10-23T08:55:08.790Z"
updated_at: "2026-10-23T08:55:08.790Z"
content_hash: "8d6dead8214512a726846775316ac1b1fa71ed894c0ae0e35df24eae63b9c328"
source_paths:
  - "gis-prep/geoserver-first-map.png"
session_ids:
  - "96e2be3c-80c4-4a4a-9e81-c530a83af7df"
memory_body_ids:
  []
---

# GeoServer 2.28.5 本地部署实录（2026-10-23）

配套的上层项目方案（为什么装、要发布武汉哪些图层、18 天里程碑）见文档 `266aea70-7a25-4d94-8359-39555b8b651f`。本文只记录**这台机器上实际落了什么、怎么起停、怎么验真、哪些坑付过代价**。

## 1. 落地结果

| 项 | 值 |
|---|---|
| 版本 | GeoServer **2.28.5**（GeoTools 34.5 / GeoWebCache 1.28.5，build 14-Aug-2026） |
| 安装目录 | `D:\geoserver`（`bin` / `etc` / `lib` / `modules` / `webapps` / `data_dir` / `start.jar` / `start.ini` / `VERSION.txt`） |
| 数据目录 | `D:\geoserver\data_dir`（自带示例：8 工作区 / 24 图层 / 27 样式 / 4 图层组） |
| 访问 | `http://localhost:8080/geoserver`，监听 `0.0.0.0:8080`；管理员为出厂默认账号，密码**未修改** |
| Java | `D:\java`（JDK 17.0.10）；`JAVA_HOME` 已设到 **User 级** |
| 首次启动 | 约 **21.5 s** 到 `Started Server@…{STARTING}`（Jetty 10.0.25），读 catalog 1.145 s |

## 2. 「解压铺到 D 盘根目录」的意外与归位

这个 zip **没有顶层包装目录**（顶层是 `bin/`、`webapps/`、`data_dir/`…）。8 月 14 日曾用 `-C D:\` 解压，于是散在 D 盘根上；本次重新解压又复现一次。

处理：把 `bin etc lib licenses modules webapps data_dir license` + `start.jar start.ini README.html RUNNING.html LICENSE.html VERSION.txt` 全部移进 `D:\geoserver`，根目录已清空。

**刻意没动** `D:\logs`、`D:\resources`：查过内容（`resources/app/app_launcher`、`app-update.yml`、`app/versions`）是某个 Electron 桌面应用的目录，只是名字与 GeoServer 的条目撞车。移动它们会弄坏别的软件。

教训：**拿到没有顶层文件夹的 zip，先解压到一个专属目录（`D:\xxx`）再看结构，别直接 `-C D:\`。** 本次与 8 月那次是同一个坑。

## 3. 起停与环境变量

```powershell
& 'D:\geoserver\bin\startup.bat'    # 起
& 'D:\geoserver\bin\shutdown.bat'   # 停（别直接关窗口，会留僵尸进程）
```

- `GEOSERVER_HOME` / `GEOSERVER_DATA_DIR` **没有永久设置**；`startup.bat` 会临时推断出来（分别是 `D:\geoserver` 与 `D:\geoserver\data_dir`），日志里会明说 "not defined / temporarily setting"。所以通过 `.bat` 启动是安全的，手工 `java -jar start.jar` 才需要自己给。
- 本次进程挂在后台任务里，**会话结束可能被回收**；次日若 8080 连不上，重跑 `startup.bat` 即可，数据都在 `data_dir` 不会丢。

## 4. 怎么算"装好了"——验真链路

端口通不算成功。实际用两步证明「HTTP → Jetty → 渲染引擎 → 图像编码」整链通：

| 检查 | 结果 |
|---|---|
| `GET /geoserver/web/` | HTTP **302**（正常，跳登录页） |
| WMS `GetCapabilities` | HTTP **200**，279,811 bytes |
| WMS `GetMap`（示例图层 `topp:states`） | HTTP **200**，9,483 bytes PNG，600×300 |

出图截图：`gis-prep/geoserver-first-map.png`（美国各州）——这张图是"能出图"的唯一硬证据。

## 5. 启动日志里的告警：哪些可以无视

- `SLF4J(W): multiple providers` / 之后一条 `SLF4J(E) JettyLoggingServiceProvider not found`：Jetty 与 GeoServer 各自的日志实现争抢，**不影响运行**。
- `NO JSP Support for /geoserver`：未装 JSP 支持；GeoServer 自带 Wicket 界面不依赖 JSP。
- `GWC configuration validation error: cvc-elt.1.a … 'gwcConfiguration'`：首次从模板 jar 生成 `data_dir/gwc/geowebcache.xml` 时的既知噪音，随后照常使用。
- `DiskQuota configuration is not readable`：未配磁盘配额，全局配额默认 500MB / 28 图层。
- 中文日志出现乱码（`10��`）：控制台编码问题，仅显示层面。

## 6. 遗留项（Day 1 未完成）

- **`gis_demo` 数据库不存在**、PostGIS 扩展未创建 → GeoServer 现在跑得起来但连不上业务数据。
- 待执行（密码需用户提供，勿写入本文）：
  ```powershell
  $env:PGPASSWORD='…'
  $psql='D:\PostgreSQL18.4\data\18\bin\psql.exe'
  & $psql -U postgres -h localhost -c "CREATE DATABASE gis_demo;"
  & $psql -U postgres -h localhost -d gis_demo -c "CREATE EXTENSION IF NOT EXISTS postgis;"
  ```
- 建库之后才轮到：武汉 GeoJSON 下载 → `ogr2ogr` 入库 → GeoServer 发布图层 → 前端叠图。

## 7. 安全提示

服务绑在 `0.0.0.0:8080` 且用的是出厂默认管理员密码，**同局域网内任何人都能登录改配置**。仅本机练习时用防火墙挡一下，或装完立刻改密码；将来上服务器必须改。
