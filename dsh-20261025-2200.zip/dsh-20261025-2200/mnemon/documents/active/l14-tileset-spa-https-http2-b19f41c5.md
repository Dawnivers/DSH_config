---
id: "b19f41c5-ad92-4a44-b144-984d68cf63ea"
title: "智慧地铁 L14 tileset 上线验收：站点部署矩阵、SPA 回退脚本与 HTTPS/HTTP2 判定真相"
description: "project2.dawnivers.top 部署 L14 裁剪瓦片后的公网实测矩阵（dist/L14/懒加载 chunk/API 全 200）、两处上传落点、nginx SPA try_files 与旧入口清理脚本要点、证书 CN 与 ALPN=h2 的正确判定法（Windows curl 无 HTTP2 导致误判）、未开强制 HTTPS 的混合内容审计结论。"
status: "active"
created_at: "2026-10-21T11:52:37.093Z"
updated_at: "2026-10-21T11:52:37.093Z"
content_hash: "ec4966ecd59a48cface4425eb678f85d02536c8f505dfe724c1cf9383746f9bd"
source_paths:
  - "src/views/cesiumView.vue"
  - "src/cesiumTools/sceneManager.js"
  - "scripts/gen-lod-tileset.mjs"
  - "vite.config.js"
session_ids:
  - "381f22ff-dcd0-4186-a6ce-23ad627b80be"
memory_body_ids:
  []
---

# L14 裁剪线上线验收与 HTTPS/HTTP2 判定

日期：2026-10-21。项目：`智慧地铁_上线版/Project`（Translation），线上 `https://project2.dawnivers.top`。
上游文档（只记各自的账，此处不重复）：`cf0fbafd-3d5e-4f89-b00b-0db4e02bcf70`（LOD 裁剪算法、层级分布、`?lod/?sse/?mem` 旋钮）、`933d3b7b-396a-4f92-a8ff-62bd719670a8`（早期 `proxy_pass` 剥 `/nginx` 前缀的诊断）。

## 1. 上线形态：两处落点，不能混

| 内容 | 落点 |
|---|---|
| 前端构建产物（`index.html` / `assets/` / `cesium/`） | `/www/wwwroot/Translation/Project/dist/` |
| `tileset-L14.json`（数据） | `/www/wwwroot/nginx_assets/Translation/shangHaiBuilds_new_toPlane/`，**必须与 `.glb` 同目录** |

理由：`tileset-LN.json` 内部是**相对 URI** 引用 `14_xxx.glb`，放错目录会整份 404，代码随即回退到完整 `tileset.json`，现象酷似「LOD 没生效」。文件名大小写敏感（Linux），必须 `tileset-L14.json`。

## 2. 用户实际采用的引用方式：直接改死默认值

产物反编译可见 `cesiumView.vue` 侧被改成：

```js
String(new URLSearchParams(location.search).get('lod') ?? '14' ?? '').trim()
// → url: a ? `${dg}/tileset-L${a}.json` : `${dg}/tileset.json`，fallback 恒为完整版
```

即**默认走 L14，`?lod=N` 覆盖，文件缺失自动回退**。三种切换方式的取舍：改 `.env.local` 的 `VITE_TILE_LOD`（推荐，URL 干净）> URL 参数（须配套新 dist）> 写死代码（丢回退）。末尾 `?? ''` 是死代码。

## 3. 公网验收矩阵（全部通过）

入口 `index-CUHv1H_i.js`（本次构建），旧产物 `index-DI0X5o-Z.js` 仍在服务器上返回 200。

| 请求 | 结果 |
|---|---|
| `/` | 200 · 679 B |
| `/assets/index-CUHv1H_i.js` | 200 · 516,190 B |
| 9 个懒加载 chunk（`StationPanel`/`RealtimePanel`/`queryTemplate`/`rolldown-runtime` 等） | 全部 200 |
| `index-CqUZV7Wh.css` / `/cesium/Cesium.js` / `favicon.ico` | 全部 200 |
| `tileset-L14.json`（站点路径与 `:666` 直连） | 200 · 274,093 B · `application/json` · `generatetool: lod-cut` |
| L14 随机 3 片叶子 `14_8462_9606_8192.glb` 等 | 200 · 166 KB / 35 KB / 114 KB |
| L10 粗层 `10_529_599_512.glb` / `EastProject/tileset.json` | 200 |
| 站点图片（丹阳路/陆家嘴/waterNormals） | 全部 200 |
| 后端 `/getLine` / `/getWeather?city=310000` | 200，CORS `*` |

结构核对：顶层 `geometricError 156543.03`、`refine REPLACE`、`children 12`、739 个叶子、`L14` 处 geometricError 38.2。
体量估算：L14 叶子抽样 25 块平均 950 KB，全量 739 块 ≈ **685 MB 上限**，但单视野只加载数十块。

**仍未解决**：`/realtime` `/nodes` `/strategy` 直链或刷新 → 404（缺 SPA 回退）；`?lod=15|16` 因服务器上没有对应文件会回退完整版。

## 4. SPA 回退与旧入口清理（可直接粘贴的服务器脚本要点）

配置：`/www/server/panel/vhost/nginx/project2.dawnivers.top.conf`。脚本顺序 = 备份 → 插入 → `nginx -t` → reload → 清理 → 自检，要点：

- **插入**：在 `include enable-php-00.conf;` 之前用 awk 注入
  `location / { try_files $uri $uri/ /index.html; }`；不覆盖已有的 `location /`，找不到锚点则明确报「请手动加」。顺序上不影响 `location ^~ /nginx/`（更具体的 `^~` 前缀优先，反代照旧）。
- **清理旧产物**：只用 `grep -oE '/assets/index-[A-Za-z0-9_-]+\.js' index.html` 取当前入口，删除 `assets/index-*.js` 中非入口者及其 `.gz/.br`。懒加载 chunk 不以 `index-` 开头，`index-*.css` 不会被误伤。
- **回滚**：`ls -t $CONF.bak-* | head -1 | xargs cp -a {}` + `nginx -t && nginx -s reload`。
- **自检**：`curl -H "Host: project2.dawnivers.top" http://127.0.0.1{/,/realtime,/nodes,/strategy}` 期望四项 200。
- 面板 UI 保存配置会把 `proxy_pass` 末尾斜杠加回来（复现 `/nginx` 前缀被剥），改反代文件别走 UI。

## 5. 证书与 HTTP/2：一次误判的更正

**我的两次错误判断**：曾用 `101.43.119.248:443` 探测，命中默认站 `CN=dawnivers.top`，据此说「证书不匹配 / 只能 HTTP/1.1」。

**实测真相**：

- 带 SNI 探测得到 `SUBJECT: CN=project2.dawnivers.top`，`ISSUER: LiteSSL RSA CA 2025 (TrustAsia)`，到期 **2027-01-19**。
- ALPN 协商结果 **`h2`**，TLS **1.3** → 服务端 HTTP/2 本来就是开的。
- 误判根因：本机 `curl 8.21.0 (Windows) ... Schannel`，`Features:` 里**没有 HTTP2**，所以 curl 永远谈 1.1。**判协议要信 ALPN，别信 Windows 自带 curl 的响应行。**

**真实缺口**：`http://project2.dawnivers.top/` 返回 200 而非 301 → **没开强制 HTTPS**，走 http 的访客拿到的是明文 + HTTP/1.1，证书与 h2 全部闲置。开法：宝塔「网站 → 设置 → SSL → 强制HTTPS」（写入 `$server_port !~ 443` 的 rewrite）。

**切 https 前的混合内容审计**：同源 Cesium/瓦片/站点资源自动跟随；ArcGIS `https://`；后端 `https://translationbe.dawnivers.top`；腾讯影像用**协议相对** `//p{s}.map.gtimg.com/...`，实测 `https://p0.map.gtimg.com/sateTiles/1/0/0/0_0.jpg` → 200 / 41881 B，图真实存在；产物内 `http://` 仅 `localhost` 与 XML 命名空间。结论：切 https 不会白屏或缺底图。
副作用：开强制 HTTPS 后 IP 直访会被跳 `https://IP` 而证书只签域名，会告警——统一用域名。

## 6. 观感取舍（给后续选择）

| 文件 | 节点 | 大小 | 观感 |
|---|---|---|---|
| L14 | 1,117 | 268 KB | 俯瞰够用，拉近明显糊（几何误差 38 m 级） |
| L15 | 3,396 | 822 KB | 平衡 |
| L16 | 10,529 | 2.5 MB | 近看可接受，主城区推荐 |

浏览器桥接未连、桌面被占（`USER_CONTROL`）导致**渲染效果始终未经视觉确认**，只做到网络层/资源层核验；控制台预期打印 `[tiles] 城市模型 LOD 上限 = L14` 与 `maximumScreenSpaceError=16 maximumMemoryUsage=1024MB`。
