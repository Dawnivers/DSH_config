---
id: "e1eb0655-b2dc-49d6-87c6-d01b2bbffc98"
title: "FE（Vue 版）升为唯一主线 + 仓库初始化与首次推 GitHub 的流程与检查点（2026-10-24 D3 收尾）"
description: "2026-10-24 D3 收尾时确定的「FE 为唯一主线、Project 冻结」范围决策，以及 FE 仓库 git init→安全校验→首推 GitHub（ServiceAvailable，main，2 commits/16 文件）的完整五步流程、代理与 ls-remote 判读要点、作者邮箱与明文 tk 等未清风险。"
status: "active"
created_at: "2026-10-24T13:33:07.062Z"
updated_at: "2026-10-24T13:33:07.062Z"
content_hash: "e368354b9c3fd8eaf62b55f9081ab5d2bce630f6cfaa4c6845273a9af6979d02"
source_paths:
  - "FE/.gitignore"
  - "FE/package.json"
  - "FE/vite.config.js"
session_ids:
  - "f3b3fa1c-042c-4bec-a253-7dfc5131a45f"
memory_body_ids:
  []
---

# FE 升为唯一主线 + 仓库初始化/首推 GitHub（2026-10-24 · D3 收尾）

项目 `D:\WebGIS\web二维开发\openlayers服务平台开发` 有两个前端：`FE`（Vue 3 版，主线，端口 5175）与 `Project`（vanilla + OL，端口 5173/5174，冻结对照）。本文记**这一天定下的范围决策**与**实跑通过的仓库初始化→推送流程**，不重复已另有文档的根因机理。

相关文档：`90391f9a-6af3-43b5-bf4d-7fe334b99d59`（21 天计划 v3，本文的路径与日表以此为准，但「目标项目」一节是 v3 写法）、`30b1760a-48fb-46fb-8b0d-7ffd1b282605`（FE D3 在 5175 的出图验收）、`b636cf73-bf3d-47ce-92c0-47b39ced9e62`（Vue 版空白地图双根因）、`97db8d2a-53b7-408d-ad80-c2c20dee73f0`（姊妹项目：密钥外置 + git 不读系统代理的实测）、`266aea70-7a25-4d94-8359-39555b8b651f`（总体设计）。

## 1. 本日确定的范围（计划文档已升到 v4）

| 决定 | 含义 |
|---|---|
| **`FE` = 唯一主线** | 学习/交付的全部新功能都写在 `FE`：Vue 3.5.42 + Vite 8 + `ol@10.11.0` + Pinia 4 + vue-router 5，dev 端口 5175，磁盘原文 `gis-prep\学习计划.md`（v4，533 行） |
| **`Project` 冻结** | vanilla 实现不再加功能，只作「原生实现 + 踩坑证据」对照保留（5173/5174） |
| 用户自建的 `Project-vue` 已删 | 前端只有一个 Vue 版，避免第三套并行 |
| 敏感配置只走 `.env` | `FE/.gitignore` 已含 `node_modules` / `dist` / `.env`；vanilla 版 `Project\src\main.js` 里的天地图 tk 仍是明文，属未清的历史包袱 |
| D4 之前不碰前端功能 | 先补 POI 数据（D12 弹窗、D18 热力图的前提），否则前端改动无验收对象 |

## 2. 仓库结果（已实测，非推测）

- 远端：`https://github.com/Dawnivers/ServiceAvailable`，默认分支 `main`，`origin/main` 与本地 `HEAD` 同为 `2acf369`。
- 首个 push：**2 个 commit**（`5aa3832 00项目初始化`、`2acf369 00_1项目初始化`），索引 **16 个文件**。
- 安全检查：`git ls-files | Select-String 'node_modules|\.env$'` **零输出** → `.env`（天地图 key）与依赖目录未入库。
- 本机基线：git 2.39.2.windows.1，`user.name = dawnivers`，默认分支未设（故建仓时显式 `-b main`），`core.autocrlf` / `core.quotepath` 当时也未设。

## 3. 初始化→首推的可复用流程（含两个检查点）

```powershell
cd D:\WebGIS\web二维开发\openlayers服务平台开发\FE
git config --global core.quotepath false   # 中文路径不再显示成 \346\226\207
git config --global core.autocrlf true     # 检出 CRLF、入库 LF
git init -b main                            # 不指定就是 master
git status                                  # ★检查点一：不能看到 node_modules/ dist/ .env
git add .
git status --short                          # ★检查点二：十几行才对；几百行=忽略名单漏了
git commit -m "chore: 项目初始化（Vue3 + Vite + OpenLayers + 天地图 WMS）"
git log --oneline
git ls-files | Select-String -Pattern 'node_modules|\.env$'   # ★必须无输出
```

- 万一真的把 `node_modules` 加进去了：`git rm -r --cached .` 撤销暂存（文件不丢）→ 补 `.gitignore` → 重新 `add`，**不要**先 commit。
- **两个前端各自 `init`**，不要在 `openlayers服务平台开发` 根目录建仓库（会把 `data/`、两个前端、`_check/` 塞进同一个库，`.gitignore` 无法分治）。
- 建议补 `.env.example`（占位符版、可提交）：`.env` 被忽略后，换机/换人不知道该填什么；「敏感配置不进库 + 提供 example」是面试可讲的细节。

## 4. 推送期的判读要点（当天真踩到的）

1. **`Failed to connect` / `Recv failure: Connection was reset`** 是网络层被 RST，与仓库名、认证无关。本机 Clash Verge 在跑、`verge-mihomo` 监听 **127.0.0.1:7897**、Windows `ProxyEnable=1`，但 **git（libcurl）不读 Windows 系统代理**，必须显式：
   ```powershell
   git config --global http.https://github.com.proxy http://127.0.0.1:7897
   ```
   该配置只作用于 `https://github.com`，不影响 gitee / npm / 内网；撤销用 `--unset`。机理与另一项目一致，见 `97db8d2a`。
2. **push 前先 `git ls-remote https://github.com/<user>/<repo>.git`**：空输出 = 仓库存在但无 commit（干净起点，直接 push）；有 ref = 远程已有历史，需先 `git pull --rebase`，否则 `! [rejected] ... (fetch first)`。
3. 网页建仓时 **README / .gitignore / license 全部不要勾**，否则远程多一个初始 commit。
4. 判读「没数据」与「请求失败」是两件事：**零 WMS 请求 = 图层没挂上**（实例化时机/高度链问题），请求 404 或白图才是服务端/参数问题。机理见 `b636cf73` 与 `30b1760a`。

## 5. 未完成事项与风险（按代价排序）

- **作者邮箱仍是 gitee 的 noreply**（`…@user.noreply.gitee.com`）：推 GitHub 时提交不归属 `Dawnivers` 账号（头像、贡献图都不算）。当时只有 2 个 commit 且未推送，改写最便宜；现已推送，改动要 `git rebase -r --root --exec "git commit --amend --no-edit --reset-author"` 后 **force push**。
- `Project\src\main.js` 天地图 tk 明文：该仓库将来若要 `init`，必须先把 key 搬进 `.env` 再建库。
- 5173 / 5174 两个旧 dev server 仍在跑（`Project` 的两个实例），可关掉省内存。
- `FE` 端清尾四项：`router` 空表死配置、`src/stores/counter.js` 模板残留、`<mapView>` → `<MapView />`、`target:'map'` 全局 id 建议改模板 ref（D12 加面板时一起做）。

## 6. 当日产物路径

| 产物 | 路径 |
|---|---|
| 计划（v4） | `gis-prep\学习计划.md`（533 行；第 191 行起链接到下面的复盘） |
| Day3 复盘（本项目） | `gis-prep\Day3-记录-FE.md`（157 行 / 9.9 KB：五个坑「现象—根因—修法」、git 五步、思考题、面试三分钟讲法） |
| 出图证据 | `gis-prep\fe-d3-5175.png`（1280×800，天地图 + 13 区对齐） |
| 易混文件 | `gis-prep\Day3-记录.md` 是旧 `gis-access` 参考答案的记录，勿与上表混用 |
