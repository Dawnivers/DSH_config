---
id: "497acdb0-e3ab-4f1c-9679-e606ccb49406"
title: "Translation 智慧地铁站控措施（StationPanel）：线路开关语义反转为「缺省灭」、点站即飞行弹卡、详情卡单例约束与相机居中几何修正"
description: "2026-10-12 StationPanel（站控措施）迭代：lineStationOn 语义反转为缺省灭（三处判断须 === true）、点站飞行弹卡与 forced 绕过、全部显示先收卡、popup.js 详卡单例 activeQueryOwner、相机须沿反方向后退 d=高度/tan(俯角) 才能让目标居中、FPS 掉帧排查与 Playwright 验证方法。"
status: "active"
created_at: "2026-10-12T06:07:51.035Z"
updated_at: "2026-10-12T06:07:51.035Z"
content_hash: "e84fe27405e109e4368c0b3f7cc03b07768b599e0bf57ec9690cf476c190098f"
source_paths:
  - "Translation/src/components/bottom/StationPanel/StationPanel.vue"
  - "Translation/src/stores/stationState.js"
  - "Translation/src/cesiumTools/lineAndpoints/popup/popup.js"
  - "Translation/src/views/cesiumView.vue"
session_ids:
  - "6e22f40b-5f36-4178-b43d-b79e447f5490"
memory_body_ids:
  []
---

# 站控措施（StationPanel）2026-10-12 迭代：默认全灭 + 点站飞行弹卡 + 详情卡单例 + 相机居中修正

日期：2026-10-12。三项用户需求 + 一处验证抓出的真 bug，12 项断言全通过。

相关文档（均为前置，本文不推翻其主体结论）：
- `f120df6f-8480-4127-9793-8df0e970da36` —— 线路开关与站点开关分离、`stationOwners` 归属集合、线路行点击目标拆分。本文沿用其可见性组合模型，只改默认值语义
- `3a0ce399-303d-4a00-95ef-e3c3d0db18af` —— StationPanel 落地、Teleport/布局、响应式代理 bug
- `1056d83b-fc4b-4598-834b-404ed7f42702` —— 路由驱动（`/nodes`）

## 0. 术语澄清

`站控措施` 是**用户口语**，代码里搜不到这个词。对应实现为「NODE 站点管理」面板：`Translation/src/components/bottom/StationPanel/StationPanel.vue`，路由 `/nodes`。识别依据是 `全部显示/全部隐藏` 两个按钮只存在于该文件。

## 1. 需求①：进入栏目默认不显示任何站点——靠改语义，不靠一次性隐藏

**关键设计取舍**：没有用「进页面时执行一次隐藏」，因为线路数据可能晚到，数据到位前执行会失效。

改的是 `Translation/src/stores/stationState.js` 中 `lineStationOn` 的**默认语义**：

```js
// 改前：键不存在视为亮
owners.some((n) => lineStationOn[n] !== false)
// 改后：只有显式 true 才算亮
owners.some((n) => lineStationOn[n] === true)
```

**三处判断必须同步改成 `=== true`**，漏一处就产生不一致：`isVisible`、`lineLit`、`anyOwnedLineOn`。`stationState.js` 的注释已改写为「缺省视为灭」，并写明判断必须用 `=== true`。

`StationPanel.vue` 的 `onMounted` 再兜一次底：线路总闸全置 false、所有站点 `forced = false`、`syncAll()`。因此**离开再进入也回到全灭**（已验证）。若将来要求「保留上次选中」，只需去掉 `onMounted` 里的重置，保留「缺省灭」语义。

## 2. 需求②：点右栏站点 = 点亮它一个 + 相机飞过去 + 弹出它的详情卡

`toggleStation` 点亮站点后补两步：`flyToStation(target)` 与 `target.popup?.showQueryPopup?.()`。
站点坐标直接复用标记上已有的世界坐标（`target.popup.position`，即 `SimpleLabel` 的 position），不必再查经纬度。再点一次则熄灭并 `removeQueryPopup()` 收卡（否则卡片悬在空地上）。

线路全灭时点击站点**不能**顺手点亮整条线：那样站点 `checked` 全为 true，会「点一个站亮一条线」。正确做法是只给该站打 `forced = true` 绕开线路开关。

## 3. 需求③：「全部显示」只给站点 + 基础气泡，不弹详情卡

`onShowAll` **先遍历收掉所有已打开的详情卡**再全亮——否则 400 个站的 `queryTemplate` 会一起涌出。

`onHideAll` 只关线路开关、**不动站点 `checked`**（`checked` 是用户个人意图），但必须清 `forced`，否则被单独点亮过的站藏不干净。

配套在 `Translation/src/cesiumTools/lineAndpoints/popup/popup.js` 增加 module 级 `activeQueryOwner`：同一时刻只允许存在一张详情卡，点 3D 标签与点面板走同一条路径，连点多个站也不叠卡。

## 4. 🔴 验证抓出的真 bug：相机放在站点正上方 → 站点落在视野外

第一版 `flyToStation` 把相机放在目标**正上方**（水平距离 0 m）。数据全绿——面板 `1/28 显示`、详情卡 1 张、相机坐标精确落在站点上——**但三维里一个站点标签都看不到**（标签被 postRender 判为出屏隐藏）。

**原因**：`pitch: -50°` 时视线与天底方向夹角为 `90-50=40°`，超过 Cesium 默认垂直半视角 30°，目标落在视野下边缘之外。

**正确做法**：沿 heading 反方向后退 `d = 高度 / tan(|pitch|)`，在目标的 ENU 坐标系内摆相机：

```js
const d = FLY_TO_STATION.height / Math.tan(Math.abs(Cesium.Math.toRadians(FLY_TO_STATION.pitch)));
// eastNorthUpToFixedFrame(地面点) 得到矩阵，local offset 取
// (-d * sin(heading), -d * cos(heading), 高度)，orientation 沿用同一 heading/pitch
```

实测 2200 m 高度 / -50° 时后退量 1846 m，站点正好居中，标签数由 0 变 1 且正是被点的那个。

**可复用教训**：Cesium 里「飞到地面目标并让它居中」与「相机精确落在目标上」是两回事，位置断言通过不代表视觉正确——断言必须验证「目标是否真的出现在视野里」。

## 5. 验证方法与结果

验证脚本（临时，位于系统临时目录）用 Playwright 驱动页面，经 `globalThis.__cesiumViewer` 读相机（仅 DEV 挂载，见 `Translation/src/views/cesiumView.vue:39`），并同时比对面板计数、三维中可见标签集合、详情卡数量。

12 项断言全通过，关键几项实测值：

| 断言 | 实测 |
|---|---|
| 进入时默认不显示站点 / 面板计数 0 | 0 个；`1号线 · 0/28 显示` |
| 点站点后只亮 1 个且正是被点的站 | 富锦路 |
| 点站点后弹出 1 张详情卡且标题匹配 | 富锦路 |
| 相机后退距离 = 高度/tan(俯角) | 1846 m vs 期望 1846 m |
| 相机高度 | 2200.3 m（配置 2200） |
| 全部显示后站点全亮、0 张详情卡 | `28/28`、18/18 行；0 张 |
| 全部隐藏后 0 个站点 | 0 个 |
| 重新进入回到默认不显示 | 0 个 |

页面错误 0。

## 6. 帧率不是性能回归

截图右上角 HUD 显示 8 FPS 属**瞬时**现象，逐秒采样：

```
点击后 2s : 9 FPS   tilesLoaded=false  ← 瓦片在加载
        4s : 36 FPS
        6s : 51 FPS  tilesLoaded=true
     8~20s : 48~58 FPS
```

同一轮默认视角仅 25~38 FPS——近景反而更快（视野内对象少）。截图恰好抓在飞行途中。**教训**：看到 FPS 掉落先看 `tilesLoaded`，再等几秒复测，别直接认定回归。

## 7. 改动文件

| 文件 | 改动 |
|---|---|
| `Translation/src/components/bottom/StationPanel/StationPanel.vue` | 三处判断改 `=== true`；`flyToStation` 后退式摆位 + ENU 实现；点击站点飞行与弹卡；全部显示/隐藏收卡；`onMounted` 重置；`FLY_TO_STATION = { height: 2200, pitch: -50, duration: 1.6 }` |
| `Translation/src/cesiumTools/lineAndpoints/popup/popup.js` | 新增 module 级 `activeQueryOwner`（详情卡单例）；顺手修正一处过时注释（称站点标签默认关闭，实际 Toolbar 已显式传 `clickable: true`） |
| `Translation/src/stores/stationState.js` | 注释改为「缺省视为灭」并写明判断必须用 `=== true` |

注意：详情卡 `offset` 由用户本人从 `[150, -20]` 改为 `[150, 150]`，本轮改动未触碰该行。
