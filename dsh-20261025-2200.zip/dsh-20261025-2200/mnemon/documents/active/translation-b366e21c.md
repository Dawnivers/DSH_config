---
id: "b366e21c-881e-4624-8050-c8e9e97ec779"
title: "Translation 发展历程：入场相机飞行取景 + 进度条实时连续 + 生长线亮度补回（含实测数据）"
description: "2026-10-12 智慧地铁 Translation 发展历程面板三项优化落地：生长线补亮（glowPower 1.2 / taperPower 0.5）、进入/切线路时按整条折线包围球与 bearing+90° heading 飞行取景、节点式进度条改为 --progress 连续填充；含相机高度与填充条对齐实测，以及「飞到当前画面」两种理解的待确认点。"
status: "active"
created_at: "2026-10-12T10:53:34.608Z"
updated_at: "2026-10-12T10:53:34.608Z"
content_hash: "8c14e103aa6116fd97b0cc5f1d5276179a0187a7c02127c61e8193f827a2b68d"
source_paths:
  - "Translation/src/components/bottom/HistoryPanel/historyPanel.vue"
  - "Translation/src/cesiumTools/lineAndpoints/line/PolylineFlowMaterialProperty.js"
  - "Translation/src/cesiumTools/lineAndpoints/line/polyGlowflow.glsl"
  - "Translation/src/cesiumTools/lineAndpoints/line/setlines.js"
session_ids:
  - "a04d4a44-e01d-48fc-9485-fe7f64be2768"
memory_body_ids:
  []
---

# 发展历程：入场取景飞行、连续进度条与生长线补亮

日期：2026-10-12。项目：`D:\WebGIS\web三维开发\智慧地铁项目\Translation`。
需求原话：「当点击进入到发展历程时，视角飞到我现在这个画面。建设历程面板进度条从间断跳跃改为实时连续」（用户随后以「可以」批准补亮改动）。

本轮**只动了一个文件**：`Translation/src/components/bottom/HistoryPanel/historyPanel.vue`。

前置文档（本文不重复其内容）：生长线关流线落地 `e4980b77-d459-420c-811f-8bd0cee77a36`；
流线溯源诊断 `a1513ccf-8374-4c20-9a66-3ecb52505879`；生长动画本体 `bed0b7b7-e1e3-491b-80bd-51ffa66f4956`。
本文落地了 `e4980b77` 第 3 节标注「用户尚未答复」的补亮项，以及 `bed0b7b7` 标注「未做」的相机飞到线路项。

## 1. 生长线补亮（承接 e4980b77 的未决项）

```js
growthEntity = renderLines(viewer, {
  positions: line.positions,
  color: line.color,
  name: line.name,
  flowLength: 0,     // 关流线：唯一正确关闭点（见 e4980b77 第 2 节）
  glowPower: 1.2,    // 0.5  → 1.2  横截面中心亮带亮度
  taperPower: 0.5,   // 0.05 → 0.5  沿长度两端锥形淡出，0.05 会让中段以外几乎全透明
});
```

运行时读材质实测：`{ flowLength: 0, glowPower: 1.2, taperPower: 0.5 }`。
同一取景下截图逐像素 A/B（只比中间 3D 区域）：变化 1.5%，其中变亮 1.12%、变暗 0.38%。
变亮像素是变暗的三倍且集中在线上；少量变暗来自 `taperPower` 改变后两端淡出边界移位，属正常。

## 2. 进入 / 切线路时相机飞行

关键设计：**用整条折线的包围球取景，而不是当前只画了一小截的生长实体** —— 一进来就看到这条线最终会铺满的范围，线在里面一点点长出来。

```js
const sphere  = Cesium.BoundingSphere.fromPoints(geom.cart);          // geom.cart = 整条折线
const bearing = Math.atan2((lngN - lng0) * Math.cos(midLat), latN - lat0);
const heading = bearing + Math.PI / 2;                                // 线路横在屏幕上，不顺着视线缩成一点
const range   = (sphere.radius / Math.sin(fovy / 2)) * 1.05;          // 包围球正好落进垂直视角
viewer.camera.flyToBoundingSphere(sphere, {
  duration: 1.6,
  offset: new Cesium.HeadingPitchRange(heading, Cesium.Math.toRadians(-65), range),
});
```

`bearing + π/2` 这一笔是「线路在画面里横着铺开」的关键，否则线会沿视线方向被压缩成一点。
取景松紧集中在两个常量，后续调参只改这里：

```js
const ENTRY_VIEW = { pitch: -65, margin: 1.05, duration: 1.6 };
```

实测相机高度（取景距离随线路尺度走，**高度不一致是正确行为**）：

| 时刻 | 相机高度 | 经纬度 |
|---|---|---|
| 首页（默认视角） | 4 822 m | 31.2705, 121.4582 |
| 进入发展历程（1 号线，37.7 km） | 49 138 m | 31.2275, 121.6356 |
| 切到 11 号线（74.3 km） | 88 246 m | 31.5713, 121.5115 |

## 3. 进度条：从「按节点类名上色」改为连续填充

原实现靠每个节点的 `is-done` / `is-current` 类上色，因此只能一段一段跳。现改为独立连续填充条，每帧跟 `currentTime` 走：

```css
.hp-track-fill {
  left: calc(50% / var(--n));                                 /* 对齐第一个圆点圆心 */
  width: calc((100% - 100% / var(--n)) * var(--progress));    /* 跟着进度铺 */
  z-index: 2;                                                 /* 压住灰轨道、低于圆点 */
}
```

节点自带的半段连线**退化为纯灰底轨**，只负责给出精确对齐；上色全部交给连续条，两者不再互相打架。
另加 `transition: width 0.08s linear`，帧率掉到 5 FPS 时也不会一顿一顿。

实测：

| 检查 | 结果 |
|---|---|
| 采样 14 次填充宽度 | 18.47 → 45.72 → 72.39 → … → 356.13 |
| 不同取值个数 | **14 / 14**（每帧都变，确认是连续而非跳变） |
| 左端对齐 | 833.14 vs 首个圆点圆心 833.14（完全相等） |
| 播完右端对齐 | 1418.23 vs 末个圆点圆心 1418.23（完全相等） |
| 文案仍是段头翻 | 采样到 `1993-05 / 1995-04 / 1996-12 / 1997-07`（连续化没带跑偏文案） |

## 4. 冒烟回归（确认只改了材质数字与播放/UI 逻辑）

| 检查 | 结果 |
|---|---|
| 生长中顶点 | 98 → 120 ✓ 在长 |
| 切 11 号线 | 动态实体 1 条、顶点 386、文案 `2010-03-29` ✓ |
| 离开栏目 | 动态实体 0 条、18 条全局线路全部还原显示 ✓ |
| 相机 | 切线路时 49 138 m → 88 246 m，确实飞过去了 ✓ |
| 控制台 | 无新增报错（仅有若干 400 Bad Request，属既有本地资源问题） |

## 5. 待确认 / 可继续的点

- **「飞到我现在这个画面」有两种理解**，本轮按 **① 飞到整条线的整体框架** 实现。
  ②「贴线特写」（相机只后退约 1.5 km）未采纳，因为 1 号线 37.7 km，贴到 1.5 km 只能看到一小段，
  生长会变成「从画面外冲进来」，反而看不出在整条线上生长。**用户尚未答复**是否要 ②。
  若用户指的是「他自己浏览器里当前那个视角」，需要他报相机参数（或给一行 DevTools 代码打印）。
- 调参入口就是 `ENTRY_VIEW`：`margin` 调小 = 更贴近（线更大、留白更少）；`pitch` 调大（如 -45）= 更像平视、更有立体感但线路会被压扁。
- `renderLines` 的 `width` 仍写死 3（见 `a1513ccf` 第 4 节方案 C），若要靠粗细区分生长线需先给该函数加选项。
