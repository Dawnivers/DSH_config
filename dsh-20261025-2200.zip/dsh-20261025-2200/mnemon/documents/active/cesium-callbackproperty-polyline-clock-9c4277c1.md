---
id: "9c4277c1-2ddd-42de-8a73-fff02d7651cc"
title: "列车漫游与 Cesium 时钟彻底解耦：CallbackProperty 自推进时间、自绘拖尾 polyline、clock 零写入（含渲染卡死坑）"
description: "trainRoam.js 从「SampledPositionProperty + 配 clock + path 拖尾」改为「CallbackProperty 自算位置 + performance.now 推进 elapsed + 自绘 polyline 拖尾」，clock 一行不碰；含改动映射表、Cartesian3.lerp 缺 result 导致 Rendering has stopped 的坑与兜底、解耦前后实测对照，以及被本改动作废的旧结论。"
status: "active"
created_at: "2026-10-17T15:32:45.874Z"
updated_at: "2026-10-17T15:32:45.874Z"
content_hash: "695b27b016aaf1b0dc190cbc70899e06621433fd4559bf75f0fcc0f4b7abfe49"
source_paths:
  - "Translation/src/cesiumTools/lineAndpoints/train/trainRoam.js"
  - "Translation/src/components/bottom/RealtimePanel/RealtimePanel.vue"
  - "Translation/src/cesiumTools/lineAndpoints/train/trainSchedule.js"
session_ids:
  - "15cb236f-0b46-4194-abbe-e32b6e1f3b5c"
memory_body_ids:
  []
---

源文件：`Translation/src/cesiumTools/lineAndpoints/train/trainRoam.js`、`Translation/src/components/bottom/RealtimePanel/RealtimePanel.vue`（`trainSchedule.js` 未改，仍是纯采样表）

本改动作废/改写 `3fe1947f`、`6ec9d498`、`7f1a6f08` 中的一部分结论，见第 5 节。

## 1. 目标与用户决策

用户明确要求「**彻底解耦 + 自己画拖尾**」：`/realtime` 栏目里的列车漫游**不能碰 Cesium 的 `viewer.clock`**。原因不是洁癖——栏目把 `clock.startTime/stopTime/multiplier/clockRange` 改成几十秒的演示窗口后，顶栏/HUD 那条时间轴与昼夜光照会一起坏掉，退出时还得靠 `resetTimeLine(viewer)` 兜回去。

新分工：**列车的时间轴 = 面板上那条进度条**；**Cesium 的时间轴 = 昼夜 / 场景时间**，两者互不影响。

## 2. 改动映射

| 位置 | 旧 | 新 |
|---|---|---|
| 位置求值 | `SampledPositionProperty`（引擎按 `clock.currentTime` 求值） | **`CallbackProperty`**，按 `this.elapsed` 自己查表 + `Cartesian3.lerp` 插值 |
| 时间推进 | 依赖 `clock.onTick` 给出的时间 | `handleTick` 用 `performance.now()` 帧间隔累加 `elapsed`，不读时钟 |
| clock 配置 | 设 `startTime / stopTime / multiplier / clockRange=LOOP_STOP / shouldAnimate` | **一行都不写**；也不 `timelineSelf.zoomTo()` |
| 可用性 | 实体带 `availability`（按时钟窗口判可见） | **删掉** `availability`——脱离时钟后它会让实体静默消失 |
| 拖尾 | 引擎 `path` 图元（`leadTime/trailTime` 按时钟裁剪） | **自绘 `polyline`**，只在「走过的顶点范围」变化时重建（≈1 次/秒，非每帧） |
| 播放/暂停 | 改 `clock.shouldAnimate` | 只改 `this.intent` |
| 退出清理 | 调 `resetTimeLine(viewer)` 还原时钟 | 不调用（本栏目没改过时钟，无可还原） |

插值方式刻意与旧实现一致：`Cartesian3.lerp` 正是 `SampledPositionProperty` 对 `Cartesian3` 的默认插值（`LinearApproximation`），所以观感不变。`jumpTo(t)` / `seek(t)` 仍然保留「挪起点 vs 只挪当前时刻」的旧区分，只是目标从 `clock.startTime/currentTime` 变成内部 `startOffset/elapsed`。

## 3. 必须记住的坑：渲染会整条停掉

第一次跑直接爆：

```
DeveloperError: Expected result to be typeof object, actual typeof was undefined
  at Cartesian3.lerp
→ "An error occurred while rendering. Rendering has stopped."
```

两个成因同时存在：

1. `Cesium.Cartesian3.lerp` 的第四个参数 `result` **必须传**（不像很多 Cesium 函数会自己 new）；
2. `CallbackProperty` 在某些调用路径下**不传 `result`** 给回调，而自绘拖尾的重建路径也是手写的。

后果不是「这帧位置错」，而是**整个渲染循环抛错停止**：画面卡死、面板全空、`entities` 数还在但 `pos` 为 `null`。排查时容易被 `hasTrain:true` 误导。

兜底写法：位置求值里 `result ?? new Cesium.Cartesian3()`。

## 4. 实测（自动化脚本取值，零 pageerror）

| 项 | 首页 | 栏目内 | 拖到 70% | 回首页 |
|---|---|---|---|---|
| 路由 | `/` | `/realtime` | `/realtime` | `/` |
| `clock.multiplier` | 1 | **1** | **1** | 1 |
| `clock.clockRange` | 0 (UNBOUNDED) | **0** | **0** | 0 |
| `clock.start/stop` | 2 天跨度 | **未变** | 未变 | 未变 |
| `shouldAnimate` | true | true | true | true |
| 实体数 | 418 | **420**（+列车+拖尾） | 420 | **418** |
| 拖尾点数 | — | 25 | 42 | — |
| 列车坐标 | — | 在动（2.5 s 后变化） | 徐家汇附近，进度 70.91% | — |

即：时间条的范围、倍速、循环模式、暂停状态**全未被触碰**，拖它只影响昼夜/场景时间。实体数回落到 418 说明 `destroy` 干净。退出后 `resetTimeLine` 不再需要。

## 5. 被本改动作废的旧结论

- `7f1a6f08`：「`clockRange` 必须显式设为 `LOOP_STOP`」「轨迹交给 `PathVisualizer` 的 `path.leadTime/trailTime`」——**对 `/realtime` 已不适用**（那仍是参考项目 RoamTool 的做法，移植后又被推翻）。循环改由 `elapsed % schedule.total` 自己取模，拖尾改自绘。
- `6ec9d498`：「`addSample` 时间按引用故必须 clone」——采样表本身还在，但**不再喂给 `SampledPositionProperty`**，这条只对采样表的其他消费者有效。
- `3fe1947f`：「朝向不能靠 `VelocityOrientationProperty`，改自算方向 + `rotationMatrixFromPositionVelocity`」——**仍然成立**，且在新架构下更没有替代品（不再有时钟驱动的速度可算）。

## 6. 自绘拖尾与 `path` 图元的两个细微差别

1. 端点做了去重：站点处 arrive/leave 是同一点（见 `6ec9d498`），不会重复插点；
2. 拖尾末端补一个「列车当前位置」，因此始终精确贴车，不领先/落后一个顶点。

宽度、发光材质、`taperPower` 沿用原参数，肉眼无差别。

## 7. 顺带的事实

底栏按钮文案已从「实时轨迹」改为「**线路轨迹**」（页面文本 `REALTIME线路轨迹`）。按旧文案写的自动化脚本会找不到元素——那是脚本没跟上，不是功能坏了。

## 8. 相关文档

- `3fe1947f-509c-4def-b914-757bbb86722b` —— handleTick 每帧入口拆解、停站朝向自算（仍有效）
- `6ec9d498-16c2-4821-b81b-e680ce4da503` —— 停站时长单位换算、`addSample` 时间按引用、buildSchedule 六步
- `7f1a6f08-9d0f-4d25-adfe-c436ac157c88` —— 参考项目 RoamTool 内核剖析（第 5 节标注了哪些结论已被推翻）
