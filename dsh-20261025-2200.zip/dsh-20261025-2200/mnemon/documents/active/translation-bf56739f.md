---
id: "bf56739f-8abd-4325-b4b9-bb55421a5d19"
title: "Translation 智慧地铁：路径规划起终点气泡改用「起/终」徽标覆盖（同一颗气泡，取代额外角色气泡方案）"
description: "2026-10-19 用户否掉「额外叠一颗起点/终点气泡」后，改为给 MarkerTemplate 加 badge 覆盖位：起终点同一颗名字气泡把「换」换成「起/终」并取消红色接管，popup.js 透传 options.badge，renderRoute 只在两端传徽标，中间换乘站仍是「换」+红底。含默认行为不变、attr.isChange 仍为真实值、徽标底色为何用深底、三组 DOM 文本验证与未验证项。本方案取代 fbb4e9e8。"
status: "active"
created_at: "2026-10-19T05:46:00.422Z"
updated_at: "2026-10-19T05:46:00.422Z"
content_hash: "bad97d9611eed0e5c3193f5aefe5eacbbfa128da8f78bbded49d8cac1a1931bc"
source_paths:
  - "Translation/src/components/bottom/StationPanel/MarkerTemplate.vue"
  - "Translation/src/cesiumTools/lineAndpoints/popup/popup.js"
  - "Translation/src/components/bottom/StationPanel/QueryModePanel/guideload/renderRoute.js"
session_ids:
  - "53e1b8af-fa52-409a-980f-43cd703097ea"
memory_body_ids:
  []
---

# 路径规划起终点气泡：「起 / 终」徽标覆盖（最终方案）

日期：2026-10-19。入口：`/nodes` → 站点面板「路径规划」。

**本文取代** `fbb4e9e8-65be-4d52-bbbf-d3213ae79e03`：那份文档记录的「在上方额外叠一颗不可点的『起点/终点』角色气泡」（`addRoleChip` / `ROLE_OFFSET = [0,158]`）**已被用户否掉并整段删除**，不要再按它改。前置背景仍见 `bfc4bd84-5376-4b42-9aee-82361f557fa3`（`isChange` 透传、`showQueryPopup()` → `queryTemplate` 链路、`disposed` 清理）与 `44fe1831-c29a-4d4c-aed8-334dfb8fa556`（guideload 四层结构）。

## 1. 用户要的是什么（两次纠正）

- 第一版理解（错）：「起终点是换乘站时补一个角色提示」，于是加了**第二颗**气泡 → 用户截图场景里出现「终点」和「换 世纪大道」两颗。
- 用户原话纠正：「我要所有起点和终点的气泡都变成『起 大连』这种，而不是额外加一个气泡」。
  即：**同一颗气泡**，徽标位从「换」换成「起 / 终」，文案形态是 `起五角场` / `终世纪大道`。

## 2. 改动（三处，缺一不可）

### ① `MarkerTemplate.vue` — 加 `badge` 覆盖位

```js
// props 增加 badge: { type: String, default: '' }
const badgeText = computed(() => props.badge || (props.isChange ? '换' : ''));
const resColor = computed(() => (props.isChange && !props.badge ? 'rgba(255,0,0,.4)' : hex(color)));
```

规则：

| 状态 | 结果 |
|---|---|
| 不传 `badge` | 行为与改动前**完全一致**；换乘站仍是红底「换」，站点管理那 400 个标签不受影响 |
| 传了 `badge` | 徽标文字被覆盖；**底色不再被换乘红色接管**，改回本线色（起点青 / 终点金） |

底色为什么必须让位：如果保留 `rgba(255,0,0,.4)`，金色终点仍是红底，就看不出「这是终点，不是又一个换乘点」。

徽标自身配色：深底 `#0a1c30` + 本线色字。**不能用本线色做底**——气泡本身就是该色 80% 透明，会糊成一片。

### ② `popup.js` — 透传

构造函数收 `options.badge`，`createVNode` 时随其他 props 一起传给模板。popup 层不认识「起/终」语义，只做搬运。

### ③ `renderRoute.js` — 只在两端传徽标

```js
addLabel(… first.from …, { badge: '起' });   // 起点
addLabel(… last.to    …, { badge: '终' });   // 终点
// 中间 transfers.forEach 不传 → 仍是「换」+ 红底
```

同时删除上一版的 `addRoleChip`、`ROLE_OFFSET` 及其两处 `if` 调用。

## 3. 一个容易踩的坑：`attr.isChange` 与徽标是两条线

徽标覆盖**只影响气泡外观**。详情卡「是否换乘站」一栏读的是 `attr.isChange`（真实值），不受 `badge` 影响。

所以「终 世纪大道」点开卡片，该栏仍显示「是」。改这块时不要把外观字段和业务字段合并。

## 4. 验证（浏览器桥，读 DOM 文本）

| 气泡 | 抓到的文本 |
|---|---|
| 起点（五角场，非换乘，青色） | `起五角场` |
| 终点（世纪大道，换乘站，金色） | `终世纪大道` |
| 中间换乘站（海伦路） | `换海伦路` |

三条链路同时成立：起终点用角色徽标、中间换乘保留「换」、无徽标的默认行为未被改动。

**未验证**：真点一下气泡弹详情卡。气泡是纯 `div`，不在浏览器桥的可访问元素树里（快照拿不到 index），当时 Chrome 窗口又最小化，桌面点击也够不到 —— 需人工手点。此遗留项与 `bfc4bd84` 相同。
