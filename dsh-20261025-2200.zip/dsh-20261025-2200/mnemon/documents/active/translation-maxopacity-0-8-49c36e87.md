---
id: "49c36e87-8cf9-4863-bf43-4722e3abb524"
title: "Translation 热力图「近地满屏红」根因与改法：半径改为地面真实米数（视角无关），maxOpacity 0.8"
description: "修正 eeba367f 中「半径随相机高度」的移植决定：实测近地红色占比暴涨 6.9 倍源于半径随视高插值，现改为按 bbox 换算的固定地面半径（RADIUS_METERS=1000 → 13.7px），并记录像素↔米换算、调参表、maxOpacity 与已删的 moveEnd 重画链路、剩余贴图分辨率限制。"
status: "active"
created_at: "2026-10-18T10:54:01.956Z"
updated_at: "2026-10-18T10:54:01.956Z"
content_hash: "5f3a4e1f632ef7a8ae68bba0a7838034af5d811ab7eadcccdef7e08fe6ef45a5"
source_paths:
  - "Translation/src/components/bottom/StationPanel/heatmap/cesiumHeatMap.js"
  - "Translation/src/components/bottom/StationPanel/StationPanel.vue"
session_ids:
  - "6e1f0ada-1b06-40be-a138-c38e7ff05d61"
memory_body_ids:
  []
---

# 热力图近地「满屏红」：根因与修正

日期：2026-10-18。文件：`Translation/src/components/bottom/StationPanel/heatmap/cesiumHeatMap.js`（约 250 行）。
背景与流水线原理见 `eeba367f-a6db-44b9-a14c-a185f6d329bd`（四步流水线、bbox 决定清晰度、`SingleTileImageryProvider` 快照语义、`destory` 拼写坑），面板挂载见 `3a0ce399-303d-4a00-95ef-e3c3d0db18af`。
本文**修正** `eeba367f` §3②「半径随相机高度是手感来源」这一移植决定：在 Translation 里它是缺陷，不是特性。

## 1. 现象与根因

用户观察：相机越贴近地面，热力图红色占比越多。

根因是旧实现照搬参考项目的 `RADIUS = { nearHeight:500, farHeight:60000, min:9, max:46 }`：半径按**相机高度对数插值**，并挂 `camera.moveEnd` + 200ms trailing throttle 重画 PNG 换影像层。热团覆盖面积 ∝ 半径²，于是**同一份客流数据在不同视高画出不同热区**：

| 视高 | 旧半径(px) | 热区面积(以固定 1000m 半径=1) |
|---|---|---|
| 500 m | 46.0 | 11.3× |
| 1 km | 40.6 | 8.8× |
| 2 km | 35.3 | 6.6× |
| 5 km | 28.2 | 4.2× |
| 20 km | 17.5 | 1.6× |

500m 与 20km 的热区面积比 **(46/17.5)² ≈ 6.9 倍**。拥挤度变成了「取决于相机」的量——语义错误。

次因（真实限制，不是 bug）：热力图是**一张贴地图片**，1px 且仅 ≈73m 地面（bbox 94.3km × 58.3km → canvas 1293×800）。视高 500m 时屏幕只覆盖约 1.2km × 0.6km，而热团直径约 2km，相机实际位于单个热点核心圆内部，alpha 拉满，自然满屏红。

## 2. 改法

1. **半径改成地面真实尺度**：`RADIUS_METERS = 1000`（构造参数 `radiusMeters` 可覆盖），构造时按 bbox 换算成像素后锁死，**不再读相机**。
   - 换算：`midLat = (bottom+top)/2`；`groundWidthMeters = width° × 111320 × cos(midLat)`；`metersPerPixel = groundWidthMeters / canvasWidth`；`radiusPx = radiusMeters / metersPerPixel`，夹在 `RADIUS_PX_RANGE = [4, 64]`。
   - 因此 `moveEnd` 监听、200ms 节流、每次停稳重编码 PNG + 重换影像层整条链路**全部删除**（省掉一次编码与一次换层，且同数据任意视角出同一张图）。
2. **`maxOpacity` 默认 1 → 0.8**：原来热点中心完全不透明，密集区叠成死红色块；0.8 保留层次并透出底图。
3. canvas 长宽比按**地面**长宽比分配，而不是直接用度数比：`groundAspect = (width° × cos(midLat)) / height°`，`h = √(CANVAS_TOTAL_AREA / groundAspect)`、`w = h × groundAspect`。上海 cos(31°)≈0.857，忽略它会让每个热团横向被压扁约 1.17 倍。

## 3. 调参表（当前 bbox：1px ≈ 73m）

| RADIUS_METERS | 半径(px) | 地面直径 |
|---|---|---|
| 600 | 8.2 | ≈1.2 km |
| 800 | 11.0 | ≈1.6 km |
| 1000（默认） | 13.7 | ≈2.0 km |
| 1200 | 16.5 | ≈2.4 km |
| 1500 | 20.6 | ≈3.0 km |

偏淡就上 1500；`heatmapConfig.maxOpacity` 可再压到 0.5–0.7 让底图更透。

## 4. 验证

- grep 确认代码中已无 `moveEnd` / `getMagnitude`（仅剩注释）。
- 页面重载后热力层正常挂载，面板无报错（`400 站 · 客流 50–991`）。
- 视觉对比未截图取证：桌面连续返回 `USER_CONTROL`（用户占用桌面），需人工拖相机目视确认。

## 5. 仍未解决的问题：近距离模糊（LOD）

贴图分辨率固定（1px ≈ 73m），贴地看必然模糊。若要「拉近仍清晰」，需做 LOD：相机停稳后按当前视野重算一张**只画视野内站点、地面分辨率更高**的小图。当前行为在语义上已正确（视角无关、热点位置准确），近距离只糊不偏。
