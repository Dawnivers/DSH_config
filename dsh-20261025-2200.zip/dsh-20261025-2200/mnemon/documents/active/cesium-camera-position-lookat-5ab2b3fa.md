---
id: "5ab2b3fa-9039-4ad5-b516-bee3d9597184"
title: "Cesium 跟车视角下的两个隐蔽坑：停站时朝向退回正东、camera.position 在 lookAt 局部坐标系里让昼夜判定翻转（含实测）"
description: "Translation 项目 trainRoam 跟车视角排查记录：VelocityVectorProperty 零速度返回 undefined 导致停站朝向跳正东（改自算四元数，27 处归零）；camera.lookAt 后 camera.position 变成局部坐标，令 DayorNight/popup 的距离与太阳点乘失真，改用 positionWC 修复，并记录日落临界与 HUD 双标准问题。"
status: "active"
created_at: "2026-10-17T09:04:41.182Z"
updated_at: "2026-10-17T09:04:41.182Z"
content_hash: "37e78e1f9d660ca5a8d7784093edbad235b4deafe65a5ae67dd94c9c6c256493"
source_paths:
  - "Translation/src/cesiumTools/lineAndpoints/train/trainRoam.js"
  - "Translation/src/cesiumTools/DayorNigjt/DayorNight.js"
  - "Translation/src/cesiumTools/lineAndpoints/popup/popup.js"
  - "Translation/src/cesiumTools/lineAndpoints/popup/popupManager.js"
  - "Translation/src/components/screenUI/head.vue"
session_ids:
  - "884ea8e0-c27f-4076-90fd-07cc834d57e3"
memory_body_ids:
  []
---

# Cesium 跟车视角的两个隐蔽坑（2026-10-17 实测）

工作区：`D:\WebGIS\web三维开发\智慧地铁项目`，Cesium 1.97。两条问题都只在「相机被 `camera.lookAt` 绑进以列车为原点的局部坐标系」后出现，首页视角完全正常，所以排查时很容易误判成 shader/模型配置问题。

相关落地文档：`72915457-a50b-4583-bad7-a771aab9d999`（/realtime 实时轨迹方案，含 `camera.lookAt` 90m 跟车与 `trackedEntity` 失败记录）。

## 1. 到站停顿会让车头「扭一下」——其实是被退回正东

### 根因（不是停站逻辑的错）

`entity.orientation` 原先用 `Cesium.VelocityOrientationProperty`。它内部是 `VelocityVectorProperty`，取 `time ± 0.5s` 两个位置相减求速度方向，而在
`Translation/node_modules/cesium/Source/DataSources/VelocityVectorProperty.js:184`：

```js
if (Cartesian3.equals(position1, position2)) {
  return this._normalize ? undefined : ...;
}
```

停站区间的两个采样点本来就落在**同一个折线顶点**上，速度为零 → 返回 `undefined` → `entity.orientation` 为 `undefined` → `ModelVisualizer` 无朝向可用，退回默认 ENU，即**正东**。表现不是「小角度抖动」，而是停站瞬间车头朝东，出站再转回来。

### 改法（自己供给方向，不用引擎反推速度）

- `trainRoam.js:146` 预计算每个采样区间的行进方向；**停站区间继承进站方向**（这就是「停站不改变朝向」的实现），出站落到下一个跑动区间自然换向。
- `trainRoam.js:168` 用 `Cesium.CallbackProperty` + `Transforms.rotationMatrixFromPositionVelocity` + `Quaternion.fromRotationMatrix` 自算四元数——复用 Cesium 内部同一换算函数，跑动时观感与原来一致。
- `trainRoam.js:332` `directionAt()` 二分查区间。
- 边界修正：JulianDate 秒差有 1e-9 级误差，采样时刻正好落在边界会被判为「上一段」，到站那帧多转几度；`trainRoam.js:347` 加 `1e-3` 秒容差。

### 实测（1 号线全部 360 个采样点逐个求朝向）

| 指标 | 修复前 | 修复后 |
|---|---|---|
| 朝向返回 `undefined` | 27 处（正好等于 27 个停站对） | **0** |
| 朝向含 NaN | — | **0** |
| 停站期间朝向变化 | 跳到正东（~90°+） | **0°**（保持进站方向） |

27 个停站采样对在停站窗口内朝向完全不变；离站那一帧最多 6.5°，对应轨道在站内本来的弯，属合理。

**已知残留（非 bug）**：折线急弯处仍有 2 处约 22° 的瞬时转向。位置是分段直线插值，方向在顶点处必然跳变，原 `VelocityOrientationProperty` 同样存在（`p95` 约 8.9°）。若要消除，需在方向数组上做几帧平滑。

## 2. 点开实时轨迹后白天 shader 变夜景——`camera.position` 不是世界坐标

### 根因

`DayorNight.js` 判定昼夜用的是 `Cesium.Cartesian3.normalize(viewer.camera.position)` 与太阳方向点乘。但 `camera.position` 是**当前参考系下**的坐标：首页 `camera.transform` 为单位矩阵时恰好等于世界坐标；一旦跟车视角每帧 `camera.lookAt(列车, HeadingPitchRange)`，Cesium 把相机绑到以列车为原点的局部系，`camera.position` 退化成「长度等于视距的小向量」，方向随偏航随机，点乘结果当然为负 → 开 bloom、建筑切夜景自发光。

实测三组对照（2026-10-17 17:03）：

| 时刻 | `camera.position` 长度 | 用 `position` 点乘太阳 | 用 `positionWC` 点乘 |
|---|---|---|---|
| 首页 | 6 377 232（地球半径量级） | 0.05 → 白天 | 0.05 → 白天 |
| 进栏目后 | **90**（正是跟车视距） | **−0.944 → 被判夜间** | 0.042 → 白天 |
| 再等 5s | 90 | −0.944 | 0.039 → 白天 |

### 改动（同一个坑三处）

| 文件 | 改动 |
|---|---|
| `DayorNight.js:57` | `camera.position` → **`camera.positionWC`**（昼夜判定） |
| `popup.js:273` | 同上（气泡按距离分级，跟车时距离被算成 6371km，站点标签全被剔除） |
| `popupManager.js:146` | 同上 |

后两处只在跟车视角暴露，不一起修会让人误以为是标签逻辑坏了。

### 提醒：两套昼夜标准本来就会打架

`DayorNight.js` 按**太阳方向**判定，而 HUD（`head.vue:73`）按「18:00 后入夜、6:00 天亮」判定，日落前后必然不一致：修完后 `dotWC` 只有 0.04，太阳已压到分界线（上海当日日落约 17:20），过了这个点无论是否点实时轨迹三维都会自然入夜——属正常行为。

可选方向（尚未选定）：① 保持真实太阳判定；② 固定白天（把 `angle` 当正数）；③ 让 shader 跟随 HUD 的 18:00/6:00 规则，两边统一。

## 3. 可复用的排查经验

- 用 `camera.lookAt` / `lookAtTransform` 改参考系后，任何读 `camera.position`、`camera.positionCartographic.height` 的**世界尺度**逻辑都要改成 `positionWC` / `positionCartographic`（后者由 `_positionWC` 投影而来，不受局部系影响）。
- 把 Cesium 的「速度/朝向」交给 `VelocityOrientationProperty` 前，先确认轨迹里是否存在零速度区间（停站、悬停等）；零速度时它给 `undefined` 而非保持上一帧。
- 排查脚本注意：`page.evaluate` 里访问 `v.camera.transform.slice` 之类会因对象形状不符直接抛 `TypeError`，这类失败是脚本自身问题，不代表页面逻辑异常。
- 验证手法：对全部采样点离线求朝向（`undefined` 计数、NaN 计数、相邻帧角差 `p95`/max），比肉眼看模型转动可靠。
