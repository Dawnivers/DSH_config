---
id: "e6cc24af-e2d1-4e85-a1d3-11595bbcda4c"
title: "智慧地铁上线版：多站点实测定案（project1 反代已通、两个站点跑的都是「分层分户」而非本项目）"
description: "接续 933d3b7b 的公网诊断：用 Host 头探测 + 响应指纹（138/146 字节 body、有无 CORS 头）+ bundle 指纹，定位出反代实际挂在哪个 server block、以及线上部署的产物根本不是智慧地铁 dist；含宝塔面板排查命令与判定表。"
status: "active"
created_at: "2026-10-21T10:49:20.946Z"
updated_at: "2026-10-21T10:49:20.946Z"
content_hash: "683863ddcb5b552fbd36667086fd099129cd14faedf79507d333704663dd18e2"
source_paths:
  - "src/api/request.js"
  - "vite.config.js"
  - "src/cesiumTools/sceneManager.js"
session_ids:
  - "dc276572-f5a1-4a83-a3d2-911715adeaec"
memory_body_ids:
  []
---

# 结论先行

反代写法本身**没有错**，`location ^~ /nginx/` + `proxy_pass http://127.0.0.1:666`（不带 URI）+ `Host $host` 这套在 `project1.dawnivers.top` 上已实测跑通。真正卡住的是两件与"写法"无关的事：

1. **反代挂错站点**：面板里保存的那段落在了 `project2.dawnivers.top` 上，而它没指向 666（指纹显示打到了 `127.0.0.1:80` 且前缀被剥掉）。
2. **线上根本不是我方产物**：`project1`、`project2` 两个站点服务的是同一个 `index-BKbkpnn6.js`（1,551,535B）——**「分层分户」项目**，不是智慧地铁 `dist`（`assets/index-DI0X5o-Z.js`，515,109B）。

前置文档：`933d3b7b-396a-4f92-a8ff-62bd719670a8`（公网实测诊断、`proxy_pass` 带 URI 剥前缀原理、dist 必须根部署）、`70090dce-2a73-410b-ad55-cb3d040aaaa0`（后端反代分段验证法）。

# 1. 关键实测矩阵（决定性证据）

| 请求 | project1 | project2 | 101.43.119.248（IP 站） |
|---|---|---|---|
| `/` | 200 / 625B（真 index.html） | 200 / 625B（同款 index.html） | 200 / **138B**（body 就是个 nginx 404 页） |
| `/nginx/` | 200 / 382B，666 目录索引，**带 `Access-Control-Allow-Origin: *`** | 200 / **138B**，body 是 404 页，**无 CORS 头** | 200 / 138B |
| `/nginx/Translation/shangHaiBuilds_new_toPlane/tileset.json` | **200 application/json 3425B** ✅ | **404 / 146B** | 404 / 146B |
| `/assets/index-DI0X5o-Z.js` | 404 | 404 | 404 |
| `/cesium/Cesium.js` | 200 / 3,480,250B | 200 / 3,480,250B | — |
| `/nginx/Translation/EastProject/tileset.json` | 200 | — | — |

`project1` 与 `project2` 的 `index.html` 逐字节一致，CSS 均为 14821B、`MD5=B4FB3593BAFE0438B8DD6D00936B82F0` → **两个站点是同一份产物**（多层拷贝 deployment）。

# 2. 可复用的判定指纹法

不登服务器也能判定"哪个 server block 答的、转发到了哪"：

- **响应体长度指纹**：`138B` = IP 站点根占位页（body 是 `<h1>404 Not Found</h1>` 的 nginx 自动页，却以 200 + `Content-Length: 138` 返回）；`146B` = 该站点的真实 404。
- **CORS 头有无**：666 的 `location` 里挂了 `add_header Access-Control-Allow-Origin * always`，所以**只要请求真到了 666 就必有该头**。`/nginx/` 返回 200 却无 CORS 头 ⇒ 请求**根本没到 666**。
- 组合判据：`/nginx/` = 200 + 138B + 无 CORS ⇒ 目标端口是 80（不是 666）**且** `proxy_pass` 带 `/` 剥掉了 `/nginx` 前缀（打到了 `http://127.0.0.1:80/` → 命中 IP 站首页）。
- **Host 头探测**：对 `:80` 用 12 个候选域名逐个打 `Host:`，`dawnivers.top` 301、其余（`www/translation/metro/subway/3d/webgis/project/app/gis/shmetro/api.dawnivers.top` 及裸 IP）全部 200 / 138B —— 说明这些名字全落到同一个占位 server，反代所在站点不在其中。
- **bundle 指纹认项目**：抓线上首页 → 取出入口 JS 名 → `curl` 下来 grep 业务字面量。线上 bundle 里 `fencengfenhu` 出现、`Translation` / `stationImg` / `智慧` / `地铁` 出现 **0 次**，唯一 tileset 字面量是 `/nginx/fencengfenhu/model/tileset.json` ⇒ 线上是分层分户项目。

# 3. 宝塔（BT-Panel）侧定位命令

```bash
# 生效配置里 proxy_pass 的归属（看 listen/server_name/root/location 上下文）
nginx -T 2>/dev/null | grep -n "proxy_pass" -B 30 \
  | grep -E "^\s*[0-9]+[-:](server_name|listen|root|location|proxy_pass)"

# 面板把反代文件放在哪、被谁 include
grep -rn "include.*proxy" /www/server/panel/vhost/nginx/*.conf
ls -l /www/server/panel/vhost/nginx/proxy/*/

# 看那个反代文件里 proxy_pass 到底写了什么（本例是 771 字节的 project2 文件）
cat /www/server/panel/vhost/nginx/proxy/project2.dawnivers.top/*.conf
```

实测输出形态：`include .../proxy/<站点>/​*.conf` 出现在 `101.43.119.248.conf:61`、`project1.dawnivers.top.conf:53`、`project2.dawnivers.top.conf:49`；`proxy/` 下三个目录各一个文件。**文件 mtime 是最好用的证据**——`95cff02f..._project2...conf` 的 `Oct 21 17:42` 正好对上"刚在面板保存"的那次，从而确定反代被建在了 project2 而非正在访问的站点。

# 4. 修复路径

1. 把 `dist` 的**内容**（`index.html` / `assets/` / `cesium/` / `favicon.ico`）放到站点 root 一层，不要套 `dist/`。
2. 站点 conf 里 `location ^~ /nginx/ { proxy_pass http://127.0.0.1:666; ... }`（无结尾斜杠、无路径），`location / { try_files $uri $uri/ /index.html; }`。
3. `nginx -t && nginx -s reload`。面板保存成功 ≠ 生效：`nginx -t` 失败时面板照样显示新值，线上还是旧配置，这是"面板看着对、线上 404"的典型原因。
4. 验收四条：`html` / `js`（`/assets/index-DI0X5o-Z.js`）/ `cesium` / `tiles` 全 200。可以在服务器上用 `curl -H "Host: <站点域名>" http://127.0.0.1/...` 绕开 DNS 验证。

# 5. 终端粘贴坑（本轮新形态）

CentOS/BT 终端里把带 `\` 续行的多行 curl 粘进去，会被拆成两次提交：第一段只发出 `curl ... -H "Host: 101.43.119.248" \` 就执行，报 `curl: no URL specified!`；第二段 `http://127.0.0.1/...` 被 bash 当命令，报 `No such file or directory`。**粘之前先写成单行**，或先 `cat > /tmp/t.sh` 再 `bash /tmp/t.sh`。

# 6. 代码层遗留隐患

`sceneManager.js` 的 `loadTilesets` 用 `await Promise.all(tilesets)`：任一 tileset reject 则 `loadCb` 永不执行，`handleshpModelEffect`、水体、外滩模型、昼夜切换全部不注册 → UI 正常、地球正常、没有建筑。可改 `Promise.allSettled` 降级出图，但注意 `cesiumView.vue` 里 `tilesets[1]` 是硬编码索引，过滤后索引会错位，需同步调整。
