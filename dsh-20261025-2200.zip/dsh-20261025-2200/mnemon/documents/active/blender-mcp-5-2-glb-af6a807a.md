---
id: "af6a807a-d3fc-4b58-ab45-9eb0de5319f6"
title: "Blender MCP 实时桥接（本机 5.2）与离线 GLB 分析链路：可用配置 + 三条硬坑"
description: "本机 Blender 5.2 通过 addons\\blender_mcp.py 开 localhost:9876 裸 TCP，可从 DSH 直接 exec Python 操控用户正在编辑的实时场景。含桥接协议字段、bl.ps1/探针脚本清单、PowerShell 中文注释与「临时相机不还原导致 F12 渲染失败」两类事故的成因与修复证据，以及离线 GLB 副本分析路径。"
status: "active"
created_at: "2026-10-15T02:08:23.344Z"
updated_at: "2026-10-15T02:08:23.344Z"
content_hash: "8a415bcd7d7ef442e607443e9d684c7bb2390264e86bd568c5019e0eb2dc86ac"
source_paths:
  - "blender-bridge/bl.ps1"
  - "blender-bridge/live_probe.py"
  - "blender-bridge/fix_render_settings.py"
session_ids:
  - "5e351870-3e10-4c91-9e1d-d13ab6eb45e4"
memory_body_ids:
  []
---

# Blender MCP 实时桥接链路（本机环境，2026-10-15 实测）

目的：不依赖任何 MCP 客户端，从 DSH 直接对**用户正在运行的 Blender 会话**执行 Python，做只读探测、渲染取证和场景修改；并把「改动用户的实时场景」这件事的风险边界固定下来。

## 1. 结论：这是「裸 TCP socket」，不是标准 MCP 协议

- 插件文件：`C:\Users\林先语\AppData\Roaming\Blender Foundation\Blender\5.2\scripts\addons\blender_mcp.py`（264.5 KB，`sha256:eb0facf6…`）。
- 安装方式：用户手动刷新插件列表并勾选 **`界面：MCP for Blender`**，然后在 3D 视口 `N` 侧边栏点 **`Start MCP Server`**。装好后目录里与 `BlenderGIS-master` 并列。
- 服务端：`localhost:9876`，报文形如 `{"type":"execute_code","params":{"code":"..."}}`，成功回 `{"status":"success","result":{...}}`。**无需 MCP 客户端**，任何能发 TCP 的进程都能用。
- 活体证据：`{"status":"success","result":{"pong":true}}`。
- 端口未就绪时表现为「9876 还没监听」，脚本应把它当**待命状态**而不是错误——用户点一下就能起。

## 2. 工作区文件（`default-workspace\blender-bridge\`）

| 文件 | 作用 |
|---|---|
| `bl.ps1` | 桥接脚本，`-Ping` / `-Code` / `-File` 三种入口，把 Python 源码发给 9876 |
| `live_probe.py` | 只读扫描：对象树、父子、顶点/面/材质/尺寸、帧范围，并抓视口截图 |
| `fix_render_settings.py` | 还原被脚本改坏的渲染设置 + 清理孤儿相机数据块 |
| `verify_render.py` | 真实渲染一次以证明修复有效（产出 46 KB PNG） |
| `inspect_glb.py` / `probe_render.py` | 离线：无 GUI（`--background --factory-startup`）导入 GLB、统计松散块、多角度渲染 |
| `models\`、`renders\` | 源文件副本与全部渲染产物 |

Python 侧要点：桥接执行体常要自己拼 `import bpy`，且**长任务要放后台**（45 MB GLB 导入 + 渲染会超过 2 分钟，前台会被挪成后台 job）。

## 3. 三条硬坑（都踩过，都有证据）

### 3.1 `.ps1` 必须是纯 ASCII（无 BOM 时按 GBK 读）
`.ps1` 里写中文注释会被 PowerShell 按 GBK 解码成 `杩斿洖閿欒` 之类的乱码，直接破坏语法，报一堆「意外的标记 / 字符串缺少终止符 / Try 缺少 Catch」，看起来像逻辑错误，实际是编码问题。**修复方式：脚本正文全 ASCII，中文只放在给用户看的说明里。**

### 3.2 临时新建相机渲染后必须复位 `scene.camera`
为出多视角图，脚本每渲一个角度就临时建相机、渲完删除，但没把 `scene.camera` 指回场景原有的 `Camera`，于是活动相机变成**悬空引用（等价于「场景里没有相机」）**——用户按 `F12` 就报渲染失败。同一次还顺手改了 `scene.render.engine`（→ Workbench）、分辨率（→1600×900）、`filepath`、`display.shading.color_type`。

修复前后对照（`fix_render_settings.py` 输出）：

```
BEFORE_camera None / engine BLENDER_WORKBENCH / res 1600x900 / color_type OBJECT
AVAILABLE_ENGINES ["BLENDER_EEVEE"]
SET_CAMERA Camera / SET_ENGINE BLENDER_EEVEE / SET_RES 1920x1080 / SET_FILEPATH C:\tmp\
REMOVED_ORPHAN_CAMERAS ["c", "c.001", "c.002"]
```

验证：`RENDER_OK True size=46976`，且 `CAMERA 'Camera'`、`ENGINE BLENDER_EEVEE`、`RESTORED filepath='C:\tmp\' res=1920x1080`。

**规约**：任何会临时建/删相机或改渲染设置的脚本，一律 `try/finally` 还原；动手前先用 `save_as_mainfile(copy=True)` 存副本（只写副本、不改用户当前文件路径，用户仍保持「未保存」状态）。

### 3.3 只读探测同样有坑：别用绝对坐标当几何特征
第一版"凸出量"探针用 `max(|坐标|)` 判凸出，但模型整体悬在原点上方（z≈9~14），算出来的是绝对高度不是离中线距离，102 个"可疑碎片"全是噪声。**正确做法：先算世界包围盒定轴**——本例 `X ∈ [-3.281, 3.281]` 对称 → X 是车宽轴，Y 是车长（38.0），Z 是高度。

## 4. 离线分析为什么必需：源文件副本
- 源模型：`D:\WebGIS\web三维开发\Cesium\assets\gltf\train.glb`（5.0 MB）与 `train2.glb`（44.7 MB）。
- 处置：**只读只复制**到 `blender-bridge\models\`，绝不动 `D:\WebGIS` 下的项目原文件。
- 价值：可以在副本上反复试探、渲染、统计松散块，完全不碰用户正在编辑的会话。用户编辑中的场景因此只需要承担最后一步精确操作。

## 5. 与用户实时场景的关系（上下文，非通用结论）
用户会话里的对象树是 `Sketchfab_model > Root > Plane.016(空物体) > Plane.016_1 / Plane.016_2`，共 7 个对象，`bpy.data.filepath` 为空（**从未存盘**）。据源文件对比，用户自行删掉了 `Plane.016_0`（桥墩/高架轨道）与 `Plane.016_3`。源 `train.glb` 由约 14,000 个互不相连的碎片组成（`Plane.016_1` 一个网格就有 10,140 个松散块），因此"选一扇门"要按位置/尺寸而非手工框选。会话内其他设计细节以会话上下文为准，不在此固化。
