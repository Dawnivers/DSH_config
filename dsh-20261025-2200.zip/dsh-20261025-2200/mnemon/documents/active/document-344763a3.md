---
id: "344763a3-50d6-417f-be43-4ad6235513be"
title: "列车模型改造续记：受电弓删除、误删车顶结构面的还原与最终状态"
description: "延续文档 b1f438e9 的后续：按 z>10.40 两窄带定位并删除两具受电弓（90 面/138 顶点）、删除前备份、误删 12 个车顶结构面后按面坐标还原的错误复盘、剩余「门顶探出 0.18」缺陷与最终面数/回退路径。"
status: "active"
created_at: "2026-10-15T03:46:59.193Z"
updated_at: "2026-10-15T03:46:59.193Z"
content_hash: "5486aaa2d420dcc7bd78cc154d535b9124d438e12f617a950d216b6f77507148"
source_paths:
  - "blender-bridge/delete_pantograph.py"
  - "blender-bridge/clean_debris.py"
  - "blender-bridge/dump_debris.py"
  - "blender-bridge/restore_debris.py"
  - "blender-bridge/debris_faces.json"
  - "blender-bridge/backup_before_deleting_pantograph.blend"
  - "blender-bridge/renders/nopanto_side_full.png"
  - "blender-bridge/renders/nopanto_3qA.png"
  - "blender-bridge/renders/clean_side_full.png"
session_ids:
  - "1f11c224-c6ea-42b0-b8b9-03ecf04d3648"
memory_body_ids:
  []
---

# 列车模型改造续记：受电弓删除与最终状态（2026-10-15）

本文是文档 `b1f438e9-3f39-4f3e-80f8-28a9042cf270`（列车「关门」几何改造：铰链解算、横跨三角形误伤、顶点级回滚）的后续。**该文档中「受电弓应保持直立、只有末端轻微位移」的描述已被本文取代**：用户在关门完成后选择删除受电弓。桥接链路与渲染设置硬坑见 `af6a807a-d3fc-4b58-ab45-9eb0de5319f6`。

## 1. 用户诉求与做法转变

- 用户在门闭合后主动问「能删除受电弓吗」——删除受电弓顺带消除了关门时「拖动受电弓 8 个面」的副作用，因为那些面本来就在删除范围内。
- 因此本阶段结论：**不需要再回到 v2/v3 的取舍上纠结**，v2 关门 + 删除受电弓即同时满足两个目标。

## 2. 受电弓定位与删除（判据干净）

门关上后，车顶 z>10.40 以上的几何只剩两处窄带，中间大段空隙：

```
Y ∈ [-6.85,-6.65]   41 面   z[10.41,11.43]   ← 受电弓 A
Y ∈ [ 3.15, 3.35]   38 面   z[10.62,11.23]   ← 受电弓 B
共 79 面；空隙 -6.7 .. +3.2，说明车顶无其他结构
```

删除结果（脚本 `delete_pantograph.py`）：

```
Plane.016_1  删面 74   28128 → 28054   顶点 47910 → 47804
Plane.016_2  删面 16    1032 → 1016    顶点  2068 →  2036
孤立顶点 0     REMAIN_ABOVE_10.40 = 0
```

删除前副本：`blender-bridge/backup_before_deleting_pantograph.blend`（3,857,223 B）。

## 3. 错误复盘：误删 12 个车顶结构面并还原

- 删除后渲染发现门洞旁车顶仍有一小块深色板状物；脚本 `clean_debris.py` 以「z>10.30 且 |x|<1.6」为判据删掉 12 个面（28054 → 28042），但对照 `nopanto_roofA.png` 与 `clean_roofA.png` **碎片依旧存在**。
- 由此判定删错对象：那 12 个面是**车顶通风器一类的结构小面**（12 个三角形，左右对称，x=±1.31~±1.55，z≈10.30~10.39，Y≈-5.2/-5.8 与 4.2/4.8），不是碎屑。
- 还原方式：从删除前备份导出这 12 个面的几何（`dump_debris.py` → `debris_faces.json`，含面中心与顶点数），再由 `restore_debris.py` 重新加回当前网格，面数 28042 → 28054。
- **教训（下次删面前先做）**：① 删除是不可逆的，**顶点索引回滚只能撤销位移，救不了已删的面**——删面前必须另存 .blend 副本；② 判据必须数值化，且要用「删后渲染是否真的变化」反证判据是否命中了目标，而不是凭「看起来像垃圾」下手。

## 4. 最终状态与遗留缺陷

| 项目 | 结果 |
|---|---|
| 车门 | 已闭合（4 块门板，2 门洞 × 左右侧），与相邻车窗齐平 |
| 受电弓 | 已删除（74 + 16 = 90 面，138 顶点） |
| 车顶 z>10.40 以上几何 | 0 |
| 面数 | Plane.016_1 28,054 + Plane.016_2 1,016 = **29,070** |
| 误删面 | 已从备份精确还原 |

- **遗留小瑕疵**：门板组件顶边略微探出车顶线，约 **0.18 单位高**（门板纵向占 z 8.36→10.58，车顶在 10.40），近距特写可见、正常视距基本无感。彻底消除的办法是**下调铰链高度（再微调旋转参数）**，属参数级改动。
- 场景改动**只在运行中的 Blender 内存里、未落盘**，用户可自行 `Ctrl+S`。

## 5. 本阶段回退路径

| 目标状态 | 路径 |
|---|---|
| 门开 + 受电弓在（原始） | `D:\Blender\assets\train.blend` 或重新导入 `D:\WebGIS\...\Cesium\assets\gltf\train.glb`（源文件从未改动） |
| 门已关 + 受电弓在 | `blender-bridge/backup_before_deleting_pantograph.blend` |
| 门未动 + 受电弓在 | `blender-bridge/backup_before_closing_doors.blend` |
| 只回滚顶点位移 | `blender-bridge/origdata/Plane_016_1.bin`、`Plane_016_2.bin`（不能恢复已删面） |
