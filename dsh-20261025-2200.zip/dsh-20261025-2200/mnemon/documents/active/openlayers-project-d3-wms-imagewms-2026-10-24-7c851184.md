---
id: "7c851184-26c4-45e2-827d-aad6bc4f375a"
title: "OpenLayers 服务平台 Project（二维开发）D3 复盘：WMS 手工验证、轴序/长宽比坑与 ImageWMS 骨架（2026-10-24）"
description: "用户在 D:\\WebGIS\\web二维开发\\openlayers服务平台开发\\Project 自建 pnpm+Vite+ol 项目接入 GeoServer WMS 的过程记录：项目路径与端口边界（参考答案项目 gis-access 不该常驻 5173）、WMS 1.1.1/1.3.0 轴序白图实测与按字节数判读、bbox 与 width/height 长宽比导致“图不完整”的误判、srs/crs 差异、View 选 3857 的决定与 WMS/WFS 分工、以及四文件骨架与 A/B/C 分级验收。"
status: "active"
created_at: "2026-10-24T05:54:14.109Z"
updated_at: "2026-10-24T05:54:14.109Z"
content_hash: "92b904260d3b4a397f5531daf19e4ec09168f22b05229b2573e07b7f1706cccb"
source_paths:
  - "gis-prep/wms-111.png"
  - "gis-prep/wms-130.png"
  - "gis-prep/cmp-a.png"
session_ids:
  - "46a6c285-c3e0-4701-a5e6-059523736faf"
memory_body_ids:
  []
---

> 承接设计 `266aea70-7a25-4d94-8359-39555b8b651f`、GeoServer 发布 `e2a4925e-c390-44f3-bd15-8bf165e70b28`、参考答案项目 D3 复盘 `87ef824d-134d-45ca-8303-d0278b2f3c7c`。本文只记 2026-10-24 这一步“用户自己的项目”上真正发生的事，与 87ef824d 中 npm/GBK/OSM 那几个坑互补。

## 1. 项目定位纠正（重要）

- 用户实际项目：`D:\WebGIS\web二维开发\openlayers服务平台开发\Project`；同期数据在 `...\openlayers服务平台开发\data\wuhan.json`（137.7 KB，武汉 13 区）。
- 早前的参考答案项目 `gis-access` 建在 `D:\WebGIS\web三维开发\gis-access`，是助手为了方便排期选的路径，**不符合用户自己的分类习惯**。结论：二维归 `web二维开发`、三维（Cesium）归 `web三维开发`，以用户目录结构为准。
- 为避免混淆：`gis-access` 仅在对答案时临时启动，**不该常驻占用 5173**；用户项目跑在 5174（PID 31584）也完全可用。停 5173 前要用“命令行 + 启动时间 + 进程工作目录”三重确认，别只按端口号杀进程（曾按 PID 误判过一次）。

## 2. 环境基线（本次实测）

| 项 | 值 |
|---|---|
| 包管理器 | **pnpm**（`pnpm create vite` + 交互式 “Install and start now? → Yes”，一步装好依赖并起 dev server） |
| 模板 | Vanilla + JavaScript（不套 Vue/React，官方示例可直接照抄） |
| ol | `ol@10.11.0`（`pnpm add ol`） |
| vite | 8.3.5 |
| GeoServer | `http://localhost:8080`，workspace `wuhan`，图层 `wuhan:admin_area` |

**规则**：本项目已是 pnpm 项目，后续统一 `pnpm add/dev`；混用 npm 会生成两套锁文件（`package-lock.json` + `pnpm-lock.yaml`），出现“装了却找不到”。这与 87ef824d 里 `npm install --include=dev` 的结论不冲突——那是 npm 项目时期的坑，本项目走 pnpm 后不再复现。

## 3. 用户既有 OpenLayers 基础（决定讲多深）

`D:\WebGIS\web二维开发\openlayers地图框架\ol-study\src\main.js`（2026-03，110 行）已覆盖：`Map/View/Layer/Source` 四层、天地图 XYZ + 注记、DataV GeoJSON 矢量面、手写 `Feature`+`Point` 打点、`Style/Fill`、`Heatmap`、`controls: defaults({...})`、`ImageStatic`。
→ 所以不必从“什么是 Map/View/Layer”讲起，真正的缺口只有三样：`ImageWMS` 图层、Vite proxy 绕 CORS、WMS 版本与轴序。用户自评“很早学的、差不多忘了，但文件夹里有能跑通的示例代码”，并要求**先读现有示例代码再下结论，以减少代码幻觉**。

旧代码里两处值得顺手纠正：
- `View` 写了 `projection: 'EPSG:4326'`，却加载 `vec_w`（Web Mercator 瓦片），会拉伸变形；且 4326 下 1° ≠ 1 米，后续缓冲区/覆盖率分析数值全错。
- 天地图 `tk` 明文写死在源码里：本地练习无妨，**上 GitHub 前挪进 `.env`**（不在任何文档中留存该 key 值）。

## 4. WMS 手工验证实验（服务端先行，分层验证）

在 UI 里走 GeoServer → Layer Preview → `wuhan:admin_area` → 格式下拉（2.28 已把一堆链接折叠成下拉）**选 `PNG`**（不是 `OpenLayers`，后者 `format=application/openlayers`，不是 GetMap 请求），地址栏即为标准 GetMap URL，参数全对，是前端要模仿的模板。

实测数据（800×600 一组，同一 bbox `113.68,29.96,114.64,31.36`）：

| 请求 | 结果 |
|---|---|
| 1.1.1 + `srs`（lon,lat） | HTTP 200，**55759 bytes**，正常出图 |
| 1.3.0 + 同序 bbox | HTTP 200，**7658 bytes**，**全白** |
| 1.3.0 + bbox 改纬经序 | HTTP 200，44163 bytes（768×440），图正常但被拉宽 |
| 1.3.0 + `crs` 替代 `srs` | 44163 bytes，与上一条逐字节一致 |

结论：
- **1.3.0 在 EPSG:4326 下 bbox 轴序是 lat,lon**；按 1.1.1 的顺序传，纬度收到 113.68 → 非法范围，GeoServer **不报错，只出白图**（静默失败）。
- **版本差异共三处**：`version`、`bbox` 轴序、`srs` → `crs`（GeoServer 容错，别的 WMS 服务不容错）。
- 前端只要写 `VERSION: '1.1.1'` 就绕开全部三个坑。

**排错手感**：图片类接口先看**字节数**——白图压缩率高、明显偏小（7 KB vs 55 KB），比翻控制台快。

## 5. “改完还不能完整显示”的真相：长宽比，不是轴序

用户把 bbox 改成 `29.96,113.68,31.36,114.64` 后仍觉得怪。实测三种写法字节数完全一致，说明参数已对。真正原因是**形状被拉伸**：
bbox 地理范围 经度 0.96° × 纬度 1.4°（比 0.69，竖长），图片 768×440（比 1.75，横长）→ GeoServer 按 bbox 铺满整张图，横向被拉伸约 2.5 倍；武汉一个区都没少。

**工程结论**：手拼 WMS URL 时 bbox 宽高比必须匹配 width/height 像素比，否则一定变形。而这正是 OpenLayers 代劳的部分——`ImageWMS` 只给 `url` + `params.LAYERS` + `params.VERSION`，bbox/width/height 随视野实时算。手拼 URL 是“看”，前端调用是“用”。

## 6. 本次定下的技术决策

1. **View 用 3857（默认）**，用户已确认（原话“选 3857”）。理由：后续可达性分析要 800 m 缓冲、覆盖率，必须米制；代价是坐标入口要 `fromLonLat()`。旧代码的 4326 写法本次不沿用。
2. **WMS 与 WFS 分工**：WMS 返 PNG（显示，省流量，但前端拿不到要素，点不出属性）；WFS 返 GeoJSON（交互、查询、统计）。“点击区划弹信息”必须 WFS。
3. 为什么绕 GeoServer 而不直吃 `wuhan.json`（用户答对一半，补齐三点）：① 与数据库联动、改数据即反映到图；② 渲染在服务端完成，几万要素只回几十 KB；③ 行业应用的分层职责。

## 7. 前端骨架与分级验收（用户自己写代码，只给结构）

四个文件、按顺序写：`vite.config.js`（proxy `/geoserver` → `http://localhost:8080`，`changeOrigin: true`）→ `index.html`（`<div id="map">`）→ `src/main.js`（import / CONFIG 常量区 / 高德 XYZ 底图 / `ImageLayer+ImageWMS` / `Map`+`View`+`fromLonLat` / `target`）→ `src/style.css`（`html,body{height:100%;margin:0}`，`#map` 铺满，否则高度 0 白屏）。

**验收顺序（A 不过不写 B，一次只引入一个变量）**：A 只有底图能拖动 → B 加 WMS 看到 13 区 → C 拖到别的城市区划跟随（验坐标系）。

提问方式也定了规矩：不要“ImageWMS 怎么写”，而是贴出自己的 params + Network 里的状态码 + 自己的猜测，助手只回答对/不对。

## 8. 下一步（未完成）

用户当前进度：依赖装好、服务端 GetMap 已能看懂，**尚未写 `vite.config.js`**；留给用户的两个问题：proxy 的键写什么、`changeOrigin: true` 到底改了什么（Host 头）。
