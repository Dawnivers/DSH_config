---
id: "97877f64-b8d0-4662-8c7b-4b7a0af34d23"
title: "Translation 智慧地铁 站控措施改造：数据写死 + 措施方框内嵌站点气泡（measureStore）+ Cesium 像素坐标系修正与气泡全隐藏阻塞"
description: "2026-10-19 站控措施第二轮改造：mockMeasures→冻结静态 stationMeasures.js（339站/495条、单字代码压缩）、删 useStationControl/StationMeasureTemplate 与 popup stationMeasure 路由、措施小方框改画进站点气泡（MarkerTemplate + reactive measureStore，省掉 pinia）、canvas.clientHeight 与 canvas.height 单位不一致导致气泡偏移/误判出屏的根因修正，以及结束时仍未解决的「所有 .LabelPlot-container display:none」阻塞与已排除项。"
status: "active"
created_at: "2026-10-19T13:07:14.673Z"
updated_at: "2026-10-19T13:07:14.673Z"
content_hash: "7e463580846838557e1e086697430ad50be23fcf91e86ca4d78b16a454ade221"
source_paths:
  - "Translation/src/components/bottom/StationPanel/QueryModePanel/stationcontrol/stationMeasures.js"
  - "Translation/src/components/bottom/StationPanel/QueryModePanel/stationcontrol/measureStore.js"
  - "Translation/src/components/bottom/StationPanel/QueryModePanel/stationcontrol/StationControl.vue"
  - "Translation/src/components/bottom/StationPanel/MarkerTemplate.vue"
  - "Translation/src/cesiumTools/lineAndpoints/popup/popup.js"
  - "Translation/src/cesiumTools/lineAndpoints/popup/popupManager.js"
session_ids:
  - "15a578db-0e66-462c-a598-e72f2387ab43"
memory_body_ids:
  []
---

# 站控措施第二轮改造（2026-10-19）：数据冻结 + 方框进气泡 + 像素坐标修正

入口：`/nodes` → 站点面板 → 查询模式「站控措施」。

## 0. 与前一版文档的关系

`f32fb104-6ca4-4a69-bf9d-c06564676cb2` 记录的是**第一版**：`mockMeasures.js` 模拟后端、`StationMeasureTemplate.vue` 独立气泡、`useStationControl.js` 建/清气泡、`popup.js` 新增 `stationMeasure` 模板路由、400 站出 46 个气泡。

本轮把这套**整体替换**掉了：模拟数据退役为冻结静态数据，措施不再自己开气泡而是画进站点气泡内部。第一版的 `useStationSnapshot`（清场/快照还原公共件）与「一模式一组件 + 单一 owner」外壳契约**继续有效**，未改动。

## 1. 数据写死

- 删除 `stationcontrol/mockMeasures.js`（FNV 种子随机 + `randomize()`），新增冻结静态文件 `stationcontrol/stationMeasures.js`。
- 形态：`MEASURE_META = { 封: { title: '封站', color: '#ff4d4f' }, … }` + `STATION_MEASURES = { '富锦路': ['售'], '宝安公路': ['封'], … }`，**单字代码压体积**，颜色/全名查表。
- 规模与分布（面板实测）：**339 站 / 495 条**；安检 94、分批放行乘客 72、设立导流围栏 68、关闭部分进站闸机 64、重保 56、引导乘客分流 53、减缓售票速度 38、封站 25、改变电梯运行方向 25。
- 面板上的「重新模拟」按钮与「模拟数据」字样一并删除，只剩「339 站 · 495 条」与图例。放弃可重滚随机是刻意的：静态数据才能让视觉回归与浏览器断言可复现。

## 2. 关键设计取舍：措施画进站点自己的气泡

不再给措施开第二类气泡，而是在 `MarkerTemplate.vue` 的气泡里加一排 `.measure-tile`（绝对定位 `bottom:100%` 悬在气泡上方，20×20、描边取措施色、内容为单字）。

**收益**：需求里的「站点隐藏时方框一并隐藏」变成**结构性成立**——站点不显示 → 气泡不渲染 → 方框不存在，不需要任何显隐联动代码，也不会出现两套 DOM 各自维护状态时的漏关。

**状态传递**：`stationcontrol/measureStore.js` 是一个模块级 `reactive({ byName })`，进模式灌数据、退模式清空；`MarkerTemplate` 用 `computed` 订阅它。因此**已经建好的气泡实例**会自己长出/收起方框——这正是第一版靠 pinia + 发布订阅才解决的问题，这里用一个 20 行的 store 省掉了。

`StationControl.vue` 只做三件事：灌数据、把有措施的站点点亮、退出还原。另加一次**自动取景**——默认全局视角太远，气泡会被 150 km 可见阈值整批剔除，方框随之不可见。

已删除：`useStationControl.js`、`StationMeasureTemplate.vue`，以及 `popup.js` 里 `stationMeasure` 模板路由与 `measures` 透传。

## 3. 🔴 根因修正：CSS 像素 vs 缓冲区像素

`popupManager.js` 的 `postRender` 原先用 `scene.canvas.height / width` 做屏幕边界判定，已改为 `scene.canvas.clientHeight / clientWidth`。

- `wgs84ToWindowCoordinates` 返回的是 **CSS 像素**坐标（Cesium 内部按 `canvas.clientWidth/Height` 换算）；
- `canvas.height` 是绘制缓冲区尺寸 = CSS 尺寸 × devicePixelRatio × resolutionScale；
- 单位不一致会让气泡整体偏移「(1 − resolutionScale) × 画布高度」——实测 resolutionScale 0.75 时**下移 225 px**，右下角气泡还会被出屏判定误杀而隐藏。

**可复用教训**：低画质档与 HiDPI 都会踩这个坑，且症状是「气泡错位/莫名消失」而不是报错，只能靠单位对齐解释。凡是拿 `canvas.*` 做坐标换算，先确认要的是 CSS 尺寸还是缓冲区尺寸。

## 4. 未解决阻塞：站点气泡在本机全不可见

改造后验证发现：**所有 `.LabelPlot-container` 的 `style.display` 都是 `none`**，相机飞到站点 2.2 km 高度亦然。

已排除：
- 管理器未注册/未监听 → 探针 `n=400 listen=true viewer=true sc=true`；
- `postRender` 抛异常 → 加了 try/catch 把错误写进标题，加载后标题无 `ERR`；
- `postRender` 未执行 → 有 `display:` 落到 style 上，说明确实在跑。

因此卡在「`isDisplay` 或屏幕坐标判定」这一层。**浏览器桥看不到 console**，无法自行定位；已请用户开 DevTools 复核两件事：标签是否出现、有无首条红色报错（含 `[Vue warn]`）。
待查方向：某气泡在 postRender 内抛错被 Cesium 吞掉；或 `isDisplay` 被面板状态机覆盖。

## 5. 验证状态

- `vite build` 通过（708 ms，仅有既存的 chunk > 500 kB 警告）。
- `measureStore`、方框模板、取景三处的**运行时可见性未经证实**，本轮不宣称功能通过。
