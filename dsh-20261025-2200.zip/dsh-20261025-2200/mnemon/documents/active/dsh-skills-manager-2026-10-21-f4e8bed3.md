---
id: "f4e8bed3-21f4-4947-915a-10d14a3dbdcf"
title: "DSH 技能目录发现规则与 skills-manager 可视化面板排障（2026-10-21 本机实测）"
description: "skill 装到 ~/.dsh/skills 后 GUI 看不到的原因排查：DSH 原生 loader 不递归、skills-manager 可递归到深度 6、入口在「设置 → 技能」而非左侧导航、skills/list 快照在 pre-step 才刷新；含发现规则源码证据与拍平嵌套的修复建议。"
status: "active"
created_at: "2026-10-21T01:34:53.620Z"
updated_at: "2026-10-21T01:34:53.620Z"
content_hash: "fa08bea4faee7f897802575f2bcfb82f33ef8eeb682fac4006fff8538adb4a0a"
source_paths:
  []
session_ids:
  - "6cdae9cb-ed61-4d6c-98dd-4d89ced73154"
memory_body_ids:
  []
---

# DSH 技能目录的发现规则与「装了却看不到」排障

日期：2026-10-21 · 环境：Windows，DSH Desktop（`desktop` profile）· 触发场景：从第三方克隆安装两个 skill（`procedural-3d-modeling`、`verifier-first-3d-modeling`）后，用户问「为什么不能可视化看到这个 skill 被安装」。

## 1. 结论速览

1. **DSH GUI 没有「技能列表」页**。左侧导航只有 插件 / 自动化任务 / 上下文洞察 / 任务看板 / 记忆系统，没有「技能」。
2. 真正的可视化入口是第三方插件 **`@michengai/dsh-skills-manager`**：`设置 → 技能`。DSH 自带的 `@deepseek-ai/dsh-client-ui-skill` **不提供管理面板**，只做两件事——输入框打 `/` 弹建议、调用后显示一张 Instructions 卡片，数据来自宿主 `skills/list`，**不直接读磁盘**。
3. **DSH 原生 skill loader 刻意不递归** `**/SKILL.md`，只扫 skill 根目录顶层；因此把 skill 放进分类子目录（如 `creative/foo`）会导致原生 loader 可能扫不到。**skill 应平铺在根目录**。
4. skills-manager 的发现器**是递归的**（见 §2），所以会出现「管理器能看到、宿主未必注册」的分歧。
5. 安装 skill **没有任何 UI 反馈**：装完就是磁盘上多两个文件夹，属产品设计而非 bug。

## 2. 发现规则源码证据（skills-manager）

文件：`C:\Users\林先语\.dsh\profiles\desktop\node_modules\@michengai\dsh-skills-manager\lib\readonly-discovery.js`

- `MAX_DEPTH = 6`，`MAX_DIRECTORIES = 2000`，`MAX_ENTRIES = 20000`，超限置 `truncated`。
- 任意深度子目录内存在 **非符号链接的 `SKILL.md`** 即登记为一个 `bundle`，条目名 = 相对根的 `/` 路径（例 `creative/procedural-3d-modeling`）。
- 根目录下的 `*.md`（且不叫 `skill.md`）登记为 `flat`，条目名去扩展名；同名时 flat 不覆盖 bundle。
- 跳过 `node_modules`；`validDiscoveryName` 拒绝以 `.` 开头的段、Windows 非法字符（`\ : * ? " < > |`）、以 `.` 或空格结尾、保留设备名（con/prn/aux/nul/com1-9/lpt1-9）。
- 用 `realpath` + ancestors 集合防符号链接环。
- 相关：`lib/core.js` 的报错文案「目录下未找到任何 skill 条目（需含 SKILL.md 的子目录或 .md 文件）」，与上述规则一致。

## 3. 本机实测（2026-10-21）

按同一发现逻辑对 `C:\Users\林先语\.dsh\skills` 跑一遍模拟：`exists=true`、`truncated=false`、**11 条**，其中

```
[bundle] creative/procedural-3d-modeling
[bundle] creative/verifier-first-3d-modeling
```

证明嵌套那层**会被 skills-manager 发现**。安装前已对源码做过安全扫描：无 `subprocess`、无网络请求、无 `rmtree`；`eval` 全部是 SDF 距离函数，`open(...,'w')` 只写自己产出的 JSON/报告。

安装后从安装位置（而非临时克隆目录）重跑测试，5 个测试文件全部通过：

```
test_mesher.py 8/8 · test_assembly.py · test_assembly_contracts.py · test_verify_model.py · test_silhouette.py
```

落地体量：`procedural-3d-modeling` 约 18–21 文件 / 170–221 KB，`verifier-first-3d-modeling` 约 11–13 文件 / 113–143 KB（不同统计口径含 `__pycache__` 前/后）。确认无 `__pycache__` 残留，临时克隆 `D:\tmp_yaogan\blender-modeling-skills` 已删除。

## 4. 缓存与刷新时机

- 面板数据走宿主 Remote **`skills/list`**，读的是宿主缓存的目录快照。
- watcher 刷新发生在**下一个模型步骤（pre-step）**，所以在会话中途安装时，当前会话的目录快照不含新 skill；GUI 里手动刷新/重开才能看到。

## 5. 修复建议（当时给用户的两个选项）

- **A（推荐）平铺**：`C:\Users\林先语\.dsh\skills\procedural-3d-modeling\`、`...\verifier-first-3d-modeling\`，与 `dask`/`polars` 等并列——两套 loader 都能扫到。
- **B 保留 `creative/`**：分类整齐、skills-manager 认，但 DSH 原生目录可能看不见。

## 6. 环境限制（记录）

- 浏览器桥当时未连接（`no browser extension is connected to the bridge`），无法用 browser_snapshot 指路。
- 桌面控制中途掉线：点击后截图/快照返回 `{"code":"CONTROL_UNAVAILABLE","state":"unavailable","generation":7}`，只能以文字描述界面路径。

## 7. 可复用教训

- 判断「skill 是否生效」不要只看 GUI 面板，要分清三层：**磁盘文件 → 管理器发现 → 宿主 skills/list 注册**，三者刷新时机和规则都不同。
- 第三方 README 推荐的分层目录结构不一定兼容宿主原生 loader；安装 skill 时优先平铺。
- 安装类操作要有「从安装位置重跑测试」这一步，才能排除搬运损坏。
