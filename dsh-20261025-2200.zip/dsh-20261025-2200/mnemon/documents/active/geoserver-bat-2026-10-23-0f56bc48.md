---
id: "0f56bc48-134c-47d0-8881-8f32190f65aa"
title: "GeoServer 日常启停运维：桌面快捷方式、三段环境变量与中文 .bat 编码坑（2026-10-23 实测）"
description: "本机 GeoServer 从「后台任务里跑」升级为「独立进程 + 桌面双击启停」的落地记录：永久设置 JAVA_HOME/GEOSERVER_HOME/GEOSERVER_DATA_DIR 的三个层级差异、startup.bat 与 shutdown.bat 对 GEOSERVER_HOME 的不对称行为、写中文 .bat 必须 GBK+chcp 936 的编码坑、8080 与 Spring Boot 8090 的端口约定、data_dir 备份与是否装 Windows 服务的取舍。部署与出图验真见 e2e0d83d。"
status: "active"
created_at: "2026-10-23T10:39:07.870Z"
updated_at: "2026-10-23T10:39:07.870Z"
content_hash: "0ef946a2baeec3230b0c2e94fc27a7f49987af79cbf1e37b89f6190bcd2a864b"
source_paths:
  - "gis-prep/学习计划.md"
session_ids:
  - "66e98961-b88c-481e-b191-9528e412822d"
memory_body_ids:
  []
---

# GeoServer 日常启停运维（2026-10-23）

承接：
- `e2e0d83d-62f3-4208-a3c8-fffc9439376f` —— 部署实录（装到 `D:\geoserver`、散装文件归位、WMS GetMap 出图验真、无害告警清单）。本文不重复那部分，只记录**装好之后怎么每天起停**。
- `266aea70-7a25-4d94-8359-39555b8b651f` —— 上层项目方案与里程碑。

触发问题：用户问「这个 geoserver 我平时应该如何跑起来」。随后暴露了两个真实报错，构成本文的全部价值。

## 1. 最终形态：独立进程 + 桌面双击

| 项 | 值 |
|---|---|
| 启动 | 桌面 `启动 GeoServer.lnk`（底层 `D:\geoserver\启动GeoServer.bat`，920 bytes，GBK） |
| 停止 | 桌面 `停止 GeoServer.lnk`（同上，调 `bin\shutdown.bat`） |
| 端口 | `http://localhost:8080/geoserver`，实测启动到返回 302 约 **28 s** |
| 进程独立性 | 启动后**杀掉启动它的会话/后台任务，java 进程仍活、8080 仍 302** —— 这是与「挂在后台任务里」的关键区别，后者会随会话被回收 |

日常三句话：开机双击「启动 GeoServer」（就绪后自动开浏览器）→ 用完双击「停止」或放着（不占 CPU，常驻约 540 MB）→ 重启电脑后需再双击一次，**没有开机自启**。

## 2. 环境变量：三个变量、User 级、永久

```powershell
[Environment]::SetEnvironmentVariable('JAVA_HOME','D:\java','User')
[Environment]::SetEnvironmentVariable('GEOSERVER_HOME','D:\geoserver','User')
[Environment]::SetEnvironmentVariable('GEOSERVER_DATA_DIR','D:\geoserver\data_dir','User')
```

- `JAVA_HOME` 原本是**空的**，`java` 走的是 Oracle javapath，虽能跑 Java 17，但 Maven 与 GeoServer 可能找不到它。
- **User 级变量对已打开的 cmd 窗口不生效**，设完必须重开终端。
- 修改后核对：`GEOSERVER_HOME = D:\geoserver`、`GEOSERVER_DATA_DIR = D:\geoserver\data_dir`。

## 3. 坑一：startup.bat 与 shutdown.bat 行为不对称

用户双击后拿到的报错是：

```
The GEOSERVER_HOME environment variable is not defined.
Startup of GeoServer was unsuccessful.
```

原因：**`startup.bat` 发现没有 `GEOSERVER_HOME` 会自己临时推断并继续（日志里写 "Temporarily setting GEOSERVER_HOME …"）；`shutdown.bat` 不做这件事，直接检查并报错退出。** 所以「启动能行、停止报错」并非脚本损坏。两处都被 §2 的永久变量覆盖后，问题消失。

## 4. 坑二：写中文 .bat 必须 GBK + chcp 936

第一版启动脚本用 UTF-8 写入，cmd 解析崩溃，输出一堆碎片：

```
'evel' is not recognized ... 'eady' is not recognized ... 'UL' is not recognized ...
```

即 UTF-8 字节被按 GBK 逐字符切碎，`@echo off`、`set`、`echo` 之类关键行都被破坏。修法：**脚本内容用 GBK 编码保存，并在首行 `chcp 936 >nul`**，同时 `title`/`echo` 中文才正常。同理适用于任何要双击运行的中文批处理。

## 5. 端口约定：Spring Boot 用 8090

端口被占时 `startup.bat` 之前的黑窗口会报 `Address already in use`。GeoServer 固定占 8080，因此**本机 Spring Boot 后端一律用 8090**，否则两者撞车。

## 6. 运维注意

- 标题为 `GeoServer` 的黑窗口**不能关**（关 = 杀服务），最小化可以。它不是系统服务，是前台进程——这是初次使用者最迷惑的点。
- `D:\geoserver\data_dir` 是命根子：所有工作区/图层/样式配置都在里面。升级或重装只换程序目录，此文件夹保留或定期拷贝。
- 是否注册 Windows 服务（`bin\installService.bat`）：需要管理员权限、常驻 500 MB+、改配置后要重启服务。**学习阶段建议先不装**（会频繁重启试配置），等要长期挂给面试官看再装。
- 完整启停回归实测（本次）：停止 → java 进程归零、8080 无响应；启动 → 28 s 后 302；杀会话后仍存活。

## 7. 遗留

`gis_demo` 库与 PostGIS 扩展仍未创建，GeoServer 能跑但连不上业务数据（同 e2e0d83d §6）。
