---
id: "80e553d9-d671-4832-87c3-3757f03875f1"
title: "Translation 热力图连续重绘与双缓冲防闪：postRender 逐帧判定 + readyPromise 换层"
description: "2026-10-18：把「moveEnd 停稳才重绘」改为 scene.postRender 逐帧 watchCamera（静止判定 + 170ms 节流 + 相对上次重绘的缩放阈值）+ 运动中 380k/停稳 1M 双分辨率；并修复换层闪烁——SingleTileImageryProvider 的 dataURL 解码是异步的，改双缓冲（新层 alpha=0 → readyPromise → 下一帧同帧 alpha=1 并删旧层），视野无站点改贴全透明图而非删层。含各常量取值理由与调参顺序。"
status: "active"
created_at: "2026-10-18T11:47:09.677Z"
updated_at: "2026-10-18T11:47:09.677Z"
content_hash: "99010b146e5f8c8043f41ec4cc925c7852b2749f23d0ea880ebbf9f275479597"
source_paths:
  - "Translation/src/components/bottom/StationPanel/QueryModePanel/heatmap/cesiumHeatMap.js"
session_ids:
  - "4d1f84f9-97ba-4e27-970a-00cd75e76649"
memory_body_ids:
  []
---

# 热力图连续重绘（运动中跟手）与双缓冲防闪

日期：2026-10-18。主文件 `Translation/src/components/bottom/StationPanel/QueryModePanel/heatmap/cesiumHeatMap.js`（约 560 行）。
前置与本文修正对象：`0ce9c65f-6c6b-48c8-872b-d98bc80502a1`（视口 LOD + 三段式半径的最终形态，**重绘时机仍是 `camera.moveEnd` + 220ms 防抖**）；机制原理见 `eeba367f-a6db-44b9-a14c-a185f6d329bd`（四步流水线、bbox 决定清晰度、`SingleTileImageryProvider` 快照语义、`destory` 拼写坑）。

本文记录两件事，都**推翻/补足**了前文结论：

1. `eeba367f` §3③ 的告诫「**绝不能挂到 `postRender` 里更新**——会每帧重建影像层把帧率打死」已被解除：加了节流 + 双分辨率后，运动中连续重绘实测仍是 60 FPS。
2. 换层闪烁的根因与修法（双缓冲），此前各文档只记了「删层再建层」，没记这一层的异步性。

## 1. 重绘时机：`scene.postRender` 逐帧 `watchCamera()`

不再挂 `camera.moveEnd`（停稳才动，运动中热力是僵的）。改为在 `scene.postRender` 里逐帧检查，三层过滤，任一层拦下就几乎零成本 return：

| 层 | 条件 | 目的 |
|---|---|---|
| ① 静止判定 | 与**上一帧**比：高度变化 < 0.05%、经纬 < 1e-7°、heading/pitch < 1e-5 | 静止时不调 `computeViewRectangle`，纯比较数字 |
| ② 节流 | 距上次重绘 < `MIN_INTERVAL`（170ms） | 上限约 6 次/秒，不会每帧编码 PNG |
| ③ 真需要重绘 | 高度相对**上次重绘**变化 > `ZOOM_EPS`（3%），或视野已跑出 `coveredRect` | 只在真的变了才画 |

**最容易写错的一点**：③ 的缩放阈值必须跟「上次重绘时的高度」比，不能跟「上一帧」比。缓慢的连续滚轮每帧只变千分之几，逐帧比较会被永久跳过，表现为「缩放时热力卡住不动」。

`coveredRect` 为上次贴图覆盖的矩形，判定时外扩 18%（含 1% 余量），一旦当前视野超出就立即重绘。

## 2. 双分辨率：为什么运动中敢连续重绘

| 场景 | 画布面积预算 | 常量 |
|---|---|---|
| 运动中 | 38 万像素 | `AREA_MOVING` |
| 停手后补清 | 100 万像素 | `AREA_REST`，延迟 `REST_DELAY` = 260ms |

运动中用小图换编码速度，手停后自动补一张高清版。观感是「滚轮一边转、热力一边跟着变（略糊但跟手），手一停立刻变清晰」。

调参入口全在同一文件顶部常量区（约 `:57-74`）：

| 常量 | 现值 | 更跟手 | 更省 |
|---|---|---|---|
| `MIN_INTERVAL` | 170 ms | 100 | 240 |
| `ZOOM_EPS` | 0.03 | 0.015 | 0.06 |
| `AREA_MOVING` | 380k | 600k | 220k |

## 3. 闪烁根因：`SingleTileImageryProvider` 的 dataURL 是异步解码的

原写法 `dropLayer() → addImageryProvider(新层)` 之间，新层的图片还没解码完，于是**有 1~2 帧场上没有任何热力层**——肉眼即闪烁。

证据：`node_modules/cesium/Source/Scene/SingleTileImageryProvider.js` 构造时 `this._readyPromise = doRequest()`（L197），`readyPromise` getter 返回它（L398-400）。即图层已加入 `imageryLayers` 但纹理未就绪。

## 4. 修法：双缓冲换层

`syncLayer(rect)` 改为：

1. 新层 `addImageryProvider` 后先置 **`alpha = 0`** —— 期间不可见，也不会与旧图叠加变深（`alpha=1` 叠加会让热区颜色变浓，是另一种"闪"）；
2. 等 `provider.readyPromise`（图片真正解码完），再等一帧 `requestAnimationFrame` 给 Cesium 上传纹理；
3. **同一帧**内：新层 `alpha = 1`，并移除 `staleLayers` 中的旧层 —— 任何一帧都有热力图在场；
4. 若这期间又画了更新的一张，正在等待的这张直接丢弃（由更新的一张接管），避免图层堆积；
5. **1 秒超时兜底**：`readyPromise` 不回来也强制显形，防止旧图被永久压住。

显隐用 `setVisible(show)` 只切 `layer.show`，不重建。

## 5. 第二种闪：视野内无站点时不要删层

原逻辑「视野里没有站点就直接 `dropLayer()` 省一次 PNG 编码」，导致拖到数据 bbox 边缘时"啪"地清空再出现。改为**换一张全透明贴图**，走同一套双缓冲，视觉上是平滑淡出。

## 6. 实测与残余风险

| 项 | 结果 |
|---|---|
| 静止（热力开） | 60.0 FPS |
| `flyTo` 飞行中（1.6s，连续触发多次双缓冲交换） | 60.0 FPS |
| 面板报错 | 无 |
| 离屏 canvas / 图层 | 正常，旧层全部回收 |

未做视觉截图（桌面被 `USER_CONTROL` 占用），闪烁是否彻底消失需人工拖滚轮确认。

若仍有残闪，按场景定位：

1. **只有拖动时闪、停下不闪** → 重绘频率过高挤压单帧耗时：`AREA_MOVING` 380k → 220k，或 `MIN_INTERVAL` 170 → 240ms。
2. **切换查询模式时闪** → 那是 `destroy`/`mount`，属预期，需要时加淡入淡出。
3. **缩放跨越数据边界时闪** → 已被全透明贴图兜住；仍明显则改为「裁剪时保留空白边距」而不是贴边裁。

## 7. 可复用的两条通用经验

- Cesium 里任何「PNG/URL 贴图换层」都会经历异步解码空窗，**"先删后加"必然闪**；正确姿势是双缓冲 + `readyPromise` + 同帧切换，外加超时兜底。
- 逐帧钩子（`postRender`）想安全使用，必须做「静止判定 + 时间节流 + 变化量阈值」三件套，且变化量阈值要对着**上次执行**而不是上一帧。
