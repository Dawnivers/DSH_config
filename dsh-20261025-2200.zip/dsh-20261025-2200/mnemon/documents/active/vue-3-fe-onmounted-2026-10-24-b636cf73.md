---
id: "b636cf73-bf3d-47ce-92c0-47b39ced9e62"
title: "Vue 3 版地图工程（FE）实建与「地图空白」双根因：onMounted 时机 + 高度链（2026-10-24）"
description: "openlayers服务平台开发 的 Vue 版前端从蓝图落地为 FE 目录后的实测记录：vue 3.5.44/vite 8.3.5/pinia 4.1.0/router 5.4.0/ol 10.11.0 版本矩阵、FE 文件职责、FE 首屏地图全空的两个根因（setup 顶层 new Map 时 #map 尚未入 DOM，OL 静默 return；index.html 的 #app 缺高度导致 #map 100% 退化为 0）、onMounted+ref 修法与「零请求/404/白图」三分类排障法、遗留待办。"
status: "active"
created_at: "2026-10-24T11:27:27.146Z"
updated_at: "2026-10-24T11:27:27.146Z"
content_hash: "a067f5f3eaee5ed04d67cfca24dee975234d3ae6c5ecbd881d38bd5fb6f79b07"
source_paths:
  - "FE/src/view/mapView.vue"
  - "FE/src/App.vue"
  - "FE/src/main.js"
  - "FE/src/style.css"
  - "FE/src/router/index.js"
  - "FE/vite.config.js"
  - "FE/package.json"
  - "FE/index.html"
  - "FE/node_modules/ol/Map.js"
  - "gis-prep/学习计划.md"
session_ids:
  - "c2ff9a21-ead5-48c7-9611-c4b8dbf1b7c4"
memory_body_ids:
  []
---

# Vue 3 版地图工程（FE）实建与空白地图排障（2026-10-24）

承接 Vue 版蓝图 `09e80ef3-d680-4d1f-839e-4f82554f7247`（当时还是「待拍板」的方案，目录名写作 `Project-vue`），本文记录**用户拍板并亲手实现之后**的真实状态。vanilla 侧的 D3 验收见 `bbb7fcbf-0682-468d-b7e0-54be35852fee`，日程见 `90391f9a-6af3-43b5-bf4d-7fe334b99d59`。

## 1. 决策与落点（蓝图 → 实际的差异）

- 用户明确「我想重新写一个 Vue 的项目」→「现在开始 Vue3 项目的构建」。**保留 vanilla `Project` 不动**，另起平行前端。
- agent 先用 `pnpm create vite Project-vue --template vue` 生成脚手架（5173/5174 已被占用，探到 5175 空闲）。**用户随后删掉 `Project-vue`，自己用 `create-vue` 建了 `FE`**，并把 pinia、vue-router、vite-plugin-vue-devtools 全部装上。以后以 `D:\WebGIS\web二维开发\openlayers服务平台开发\FE` 为准，`Project-vue` 已不存在。
- 教训：这类「搭什么脚手架」的建议不必提前定太细（`--template vue` vs `create-vue` 的分歧在真实选择面前无意义），用户会按自己的习惯落地；agent 应尽快改为读实际目录。

## 2. 版本矩阵（`FE/package.json` 实测，2026-10-24）

| 包 | 版本 |
|---|---|
| vue | ^3.5.42（本机解析 3.5.44） |
| vite | ^8.2.2（实际 8.3.5） |
| ol | ^10.11.0（与 vanilla 版同版本） |
| pinia | ^4.0.3（新主版本；本机 4.1.0） |
| vue-router | ^5.3.1（本机 5.4.0） |
| @vitejs/plugin-vue | ^6.0.8 |
| vite-plugin-vue-devtools | ^8.2.1 |

本机 Node v24.16.0 + pnpm 11.8.0。pinia 4 / router 5 的 changelog 网页当时抓取失败（`web fetch failed`，两次），破坏性变更**尚未逐条核实**，接 store（计划里 D12）前需补。已知线索：router v4→v5 在不用 unplugin 文件路由时基本零破坏性变更（见蓝图文档所引官方迁移文档）。

## 3. FE 文件职责（读过的实际内容）

| 文件 | 现状 |
|---|---|
| `FE/index.html` | 仅 `<div id="app">` + `/src/main.js`；**`#app` 无高度** |
| `FE/src/main.js` | `createApp` + `createPinia` + router + `./style.css` |
| `FE/src/App.vue` | 直接渲染 `mapView` |
| `FE/src/view/mapView.vue` | 核心 70 行：`CONFIG`（`wuhan:admin_area`、`/geoserver/wuhan/wms`、中心 [114.30,30.55]、zoom 9）、天地图 `img_w`+`cva_w` 两个 XYZ、`ImageLayer`+`ImageWMS`（`VERSION:'1.1.1'`、`serverType:'geoserver'`、`ratio:1.5`、opacity 0.7）、`View`（默认 3857 + `fromLonLat`）、`new Map({ target:'map' })` 在**顶层**执行 |
| `FE/src/style.css` | `html,body{height:100%;overflow:hidden}`、`#map{width/height:100%}` |
| `FE/vite.config.js` | `vue()` + devtools + `@` alias + proxy `/geoserver → http://localhost:8080`（`changeOrigin:true`）；含无用 `import { Server } from 'node:http'` |
| `FE/src/router/index.js` | `routes: []` 空表 |

## 4. 首屏「有页面没地图、控制台零报错」的两个根因

**根因 A（致命，时序）：建图时 `#map` 还不存在。**
`<script setup>` 在组件挂载前跑完，此时模板里的 `<div id="map">` 只是虚拟节点，`document.getElementById('map')` 返回 `null`。OL 对 null target 的处理是**静默跳过**：`FE/node_modules/ol/Map.js` 中 `const targetElement = typeof target === 'string' ? document.getElementById(target) : target;` 之后 `if (!targetElement) { …清定时器、dispose renderer… return }` —— 不 throw、不 warning，于是得到一个「没家的孤儿」Map 实例。

**根因 B（即使挂上也白）：高度链断在 `#app`。**
`html,body{height:100%}` + `#map{height:100%}` 之间少了 `#app`；`#app` 是 `height:auto`，百分比按规范退化为 auto → 内容为空 → 0px。vanilla 版没暴露此问题，因为 `#map` 直接挂在 body 下（且 `<script type="module">` 在 body 末尾，解析到它时 DOM 已在）。

**通用结论**：同一个 `target:'map'`，vanilla 能跑、Vue 不能，差别只在**代码执行时机**——`setup → 模板渲染 → 插入 DOM → mounted`。这是「Vue 的 onMounted 为什么必须包地图初始化」的标准答案。

## 5. 修法（按序）

1. 模板改元素引用：`<div ref="mapEl" class="map-root">`；`const mapEl = ref(null)`。
2. 把 `new Map(...)`、`map.addLayer(...)` 搬进 `onMounted`，`target: mapEl.value`，随后 `map.updateSize()` 兜首帧。
3. `onBeforeUnmount` 里 `map?.setTarget(undefined)` 并置 null（官方释放方式）。
4. OL 实例**不要放进 ref**（不进响应式；必要时 `shallowRef`/`markRaw`），用普通变量 `let map = null`。
5. 补高度链：`html, body, #app { margin:0; height:100%; overflow:hidden }` + `.map-root{width:100%;height:100%}`。组件化项目用 class 而非全局 `#map`，避免多组件 id 冲突。

## 6. 三分类排障法（本次最有复用价值的一条）

看 **Network 里有没有 WMS 请求**，而不是先看报错：

| 现象 | 判定 |
|---|---|
| 一个 `wms` 请求都不发 | **前端挂载问题**（target 为 null / 容器 0 高度），去查 onMounted 与高度链 |
| 有请求但 404 / 500 | 服务端或参数问题（proxy、图层名、VERSION、bbox） |
| 有请求、200、画面仍白 | 样式/透明度/绘制顺序问题（opacity、zIndex、view 范围） |

浏览器 30 秒自证：`document.getElementById('map')` 为 null → 根因 A；`document.querySelector('#map')?.clientHeight === 0` → 根因 B。

## 7. 遗留待办

- 天地图 tk 仍硬编码在 `mapView.vue`（`img_w`、`cva_w` 两处），应搬进 `.env` 的 `VITE_TDT_KEY`；**Vite 模板默认只忽略 `*.local`，`.env` 会被提交**，需补 `.gitignore`。
- 删掉 `vite.config.js` 里无用的 `import { Server } from 'node:http'`。
- 组件命名建议 `MapView.vue` + `<MapView />`（小写开头易被误认原生标签；现有写法靠 Vue camelize 兜住，能跑）。
- 磁盘计划 `gis-prep\学习计划.md` 与文档 `90391f9a` 仍写 `Project` / `Project-vue`，需统一为 `FE` 并注明「Vue 骨架已搭（create-vue + pinia 4 + router 5）」。agent 已在会话末尾向用户提出此改动，**用户尚未答复**。
- 计划三处排期硬伤待定：D12 被写了两遍（4h + 3h = 7h）、D8–D9 只有总表无正文、D12 验收依赖 D4 的 POI 数据（数据源卡点会一路传导到 D12）。
