---
id: "cdaa0177-267d-4849-814e-19a5b4961664"
title: "Translation 智慧地铁后端上服务器：上传边界、Node 版本门槛、自定义格式 dump 的三个坑（含实测恢复结果）与前端硬编码清单"
description: "Translation_BE 从本地搬到服务器时的可复用部署记录：哪些文件上传/不传、服务器上现建 .env 与 chmod 600、systemd 不落盘注入、Node≥20.12（process.loadEnvFile）、pg_dump 自定义格式（PGDMP/gzip/dump version 1.16，需 pg_restore≥18、psql -f 必失败）、不要带 -C（Windows locale 'Chinese (Simplified)_China.936' 在 Linux invalid）、文件名单词少 t、createdb + pg_restore --no-owner 实测 line=18/station=510、以及前端 baseApi 127.0.0.1:8092 与 localhost:666 五处模型地址必须先改为可配置。"
status: "active"
created_at: "2026-10-20T09:20:14.306Z"
updated_at: "2026-10-20T09:20:14.306Z"
content_hash: "554490102c732b2fe063794f9db0e402cf3c1c1b9f6537cadf460ccbda60323e"
source_paths:
  - "Translation_BE/index.js"
  - "Translation_BE/config.js"
  - "Translation_BE/.env.example"
  - "Translation_BE/.gitignore"
  - "Translation/src/api/baseApi.js"
  - "Translation/src/api/request.js"
  - "Translation/src/cesiumTools/sceneManager.js"
  - "Translation/src/views/cesiumView.vue"
session_ids:
  - "337c4dde-a1a4-4432-bdf2-54217cf44cb9"
memory_body_ids:
  []
---

# Translation_BE 上服务器：上传边界 / 数据库迁移 / 前端硬编码（2026-10-20）

日期：2026-10-20。项目根 `D:\WebGIS\web三维开发\智慧地铁项目`，后端 `Translation_BE`（Express 5 + pg，Node v24.16，无静态目录、无 `fs`）。
密钥外置那一段（三处 key 怎么挪进 env、`process.loadEnvFile` 免 dotenv、Vite 把 `VITE_` 内联进 dist 的实证）已记在文档 `60592d56-a0fc-4a32-bd93-1bf0fcabea37`，本文只补**部署与数据迁移**这一层。

触发问题是：「如果我要将后端上传服务器，是把整个后端项目文件夹包括 .env 也一起上传吗」——答案是**不要**，`.env` 是「这台机器的配置」，不是源代码。

## 1. 上传边界

| 传 | 不传 |
|---|---|
| `index.js`、`config.js` | `.env`（服务器上现建） |
| `package.json`、`package-lock.json` | `node_modules/`（服务器 `npm ci` 重装，别跨平台搬） |
| `.env.example`、`.gitignore` | `PROMPT.md`（内部实现说明，不必上公网） |

后端**不读任何本地文件**（已确认无 `fs` / `express.static` / `sendFile`），只做两件事：连 PostgreSQL、调高德 Web 服务。所以除上表外没有别的资源要传。

## 2. 服务器上建 .env（而不是把本地 .env 传上去）

```bash
git clone <repo> && cd Translation_BE   # .gitignore 已挡 .env
npm ci
cp .env.example .env
nano .env            # AMAP_KEY / PGPASSWORD / PGHOST …
chmod 600 .env
```

不想要文件就让进程直接吃环境变量（systemd `Environment=` 或 Docker `-e`）：`config.js` 里 `process.loadEnvFile` 是 `try/catch` 的，没有 `.env` 也不会崩。

**泄漏面的账**（这是「为什么要在服务器上建」的正确解释，`.env` 本身不提供保密能力）：

| 放法 | 副本落在哪 | 泄漏面 |
|---|---|---|
| 硬编码在源码 | 源码 + git 历史 + 每个 clone/zip/聊天附件 | 谁拿到代码谁就有 |
| 随上传包一起传 | 本地 + 网盘/微信中转 + 服务器 | 中转环节全有副本 |
| **服务器上现建** | 只有这一台机的一个文件（chmod 600 → 1 个副本） | 能登服务器/能读备份的人 |
| 平台面板注入 | 不落盘 | 同上，面板里还是掩码 |

`.env` 挡不住：服务器被攻破、自动备份/快照打包、`COPY . .` 时忘了 `.dockerignore`（`.gitignore` 管不到 Docker）、日志/错误栈打印配置、同用户读 `/proc/<pid>/environ`。所以真正的加固顺序是：① `.env`+gitignore；② 平台注入；③ **平台侧白名单**（高德 key 设「Web服务」+ IP 白名单；ion 设 Allowed URLs）；④ 定期轮换，出过事的 key 删了重建。轮换成本也是 .env 的附带好处：改一个文件重启即可，不动代码。
已核对：`index.js` 只在启动时打印端口，不会把 key 打出来（`AMAP_KEY` 只用于 `url.searchParams.set('key', …)`）。

## 3. 前置条件一：Node 版本

`package.json` 没有 `engines`，但 `config.js` 用了 `process.loadEnvFile` → 需 **Node ≥ 20.12**（21.7+ 更稳）。服务器 `node -v` 先确认；旧版就得改 systemd `Environment=`/`EnvironmentFile=` 注入，否则 `config.js` 只能用 `?? ''` 兜底跑，key 会静默缺失。

## 4. 前置条件二：数据库（本项目的真正工作量）

后端只查两张表：

```sql
SELECT id, name, "basicPrice", length, xs, ys FROM line ORDER BY id
SELECT name, name_2, lon, lat, ischange, sort FROM station ORDER BY name_2, sort
SELECT name_2, ischange FROM station WHERE name = $1
```

服务器没这个库就是 `ECONNREFUSED 127.0.0.1:5432`。本地导出 → 服务器导入。

### 4.1 用户手上那份 dump 的体检结论（实测，不是猜测）

文件 20,472 B / 195 行，前 3 字节 `50 47 44` = `PGDMP`。`pg_restore -l` 头：

```
Format: CUSTOM      Compression: gzip      Dump Version: 1.16-0
Dumped from / by pg_dump version: 18.4      TOC Entries: 30
```

三个会让导入失败的坑（都不是内容问题，是「怎么用」的问题）：

1. **扩展名骗人，是二进制自定义格式，不是 SQL 文本。** `psql -f Translaion.sql` 一定报一堆语法错，必须 `pg_restore`。且 **归档版本 1.16 只有 PG 18 才写**，服务器上 `pg_restore` 必须 ≥ 18；PG 16/17 会直接 `unsupported version (1.16) in file header`。
2. **不要加 `-C`，会撞 Windows 专属 locale。** 归档头里埋着
   `CREATE DATABASE "Translation" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Chinese (Simplified)_China.936';`
   **注意：即使导出时不带 `-C`，这条建库语句仍会进二进制元数据**——本项目做过对照实验：新导一份不带 `-C` 的 dump，`CREATE DATABASE` 与 `Chinese (Simplified)` 各仍出现 1 次，与原件一致。所以在 Linux 上让 `pg_restore -C` 自己建库 → `invalid locale name`。正确做法：库自己建，恢复不带 `-C`。
3. **文件名 `Translaion` 少一个 t**（库名在文件里是正写的 `Translation`）。部署脚本若写 `psql -f Translation.sql` 会 `No such file`。

### 4.2 服务器上的正确恢复流程

```bash
# 1) 自己建库（跟着服务器默认 locale 走）
createdb -U postgres -E UTF8 -T template0 Translation
# 2) 恢复：--no-owner 跳过属主
pg_restore -U postgres -d Translation --no-owner --no-privileges Translaion.sql
```

### 4.3 实测验证（换机器导入模拟）

- 本机 PostgreSQL 18.4（`D:\PostgreSQL18.4\data\18\bin`，另有 PG10 目录但无 `pg_restore`）。
- 建临时库 `translation_verify_tmp` → `pg_restore` **零错误输出** → 恢复后 `line=18`、`station=510`，列 `id,name,basicPrice,length,xs,ys` 对得上；序列 + `DEFAULT nextval` + `setval`、列注释、主键与 `line_name_key` 唯一约束都在；无 GRANT、无扩展依赖（所以 `--no-owner` 就够）。验证完临时库已 DROP。
- 内容清单：`line` 18 行、`station` 510 行（前端去重后显示 ~400 站，按线路存的 510 条是正常的）。

### 4.4 想要「能直接 psql 导入」的版本

```bash
pg_dump -U postgres -d Translation -Fp --no-owner --no-privileges -f Translation.sql
```

纯文本约 45 KB（781 行，`COPY … FROM stdin` 块），任何版本的 psql 都能导，代价是体积翻倍，且纯文本**不含** `CREATE DATABASE`（对照：`-Fc` 二进制里才有），所以不用再管 locale 坑。

## 5. 前端硬编码：不改就等于没部署

| 位置 | 现在 | 后果 |
|---|---|---|
| `Translation/src/api/baseApi.js:3` | `baseURL: 'http://127.0.0.1:8092'` | 打的是**访客自己电脑**的 8092 |
| `sceneManager.js:39` / `:49` / `:123` / `:134`、`cesiumView.vue:111` / `:115` | `http://localhost:666/model/...`（白膜地形/影像、两处 `tileset.json`、`shangHaiBuilds_new_toPlane`、`EastProject`） | 白膜瓦片全 404，场景只剩空地球 |

`baseApi.js` 应改为 `import.meta.env.VITE_API_BASE`（本地 `http://127.0.0.1:8092`，服务器 `https://域名/api`），并写进 `.env.example`。`localhost:666` 那 5 处得先定 `666` 静态服务怎么部署（搬服务器 or 换在线地图）才能改。

## 6. 运维细节

- `app.listen(PORT)` 默认监听 `0.0.0.0`：放行安全组 8092，或用 nginx 反代到 80/443（更好，顺带解决 HTTPS 与压缩）。
- `app.use(cors())` 全开：演示够用，给人用建议收窄成具体域名。
