---
id: "a20938c7-4625-4107-9544-f9b0633eb334"
title: "PostGIS 面积报数口径实测：3857 面积放大 1.35 倍，geography 才准（gis_demo.admin_area 武汉 13 区）"
description: "武汉 admin_area 表的面积/距离计算口径实测：3857 放大 1.35 倍成因与证据、geography 为准的 5 条项目规矩、double precision 与 round、ogr2ogr 误判几何列等附带坑。"
status: "active"
created_at: "2026-10-23T04:37:04.390Z"
updated_at: "2026-10-23T04:37:04.390Z"
content_hash: "a65763638eee617648bad03846704902206fafbe0ee0103722522b0dfe7a1698"
source_paths:
  []
session_ids:
  - "2ac4668f-d10a-48bf-837c-a2a21b5829a9"
memory_body_ids:
  []
---

# PostGIS 面积/距离报数口径实测（武汉 gis_demo.admin_area，2026-10-23）

承接导入链路的既有文档 `bd491158-552e-4d9e-b899-a8fff4453827`（ogr2ogr / PROJ_DATA / 建库顺序）。本篇只记**入库之后**验证出来的计算口径问题，数据表为 `gis_demo.admin_area`（阿里 DataV 武汉区划，13 区，`geometry(MultiPolygon,4326)`，`geom` 列 + GiST 索引）。

## 1. 结论（可直接当项目规矩）

```
① 存储：geometry(geom, 4326)
② 渲染/瓦片/格网：ST_Transform(geom, 3857)
③ 距离判断：ST_DWithin(geom::geography, ...) 或先转 3857，单位是米
④ 面积/长度报数：geom::geography（椭球面积）
⑤ 永远不要：ST_Area(ST_Transform(geom, 3857)) —— 武汉纬度会系统性放大 ~35%，且不报错
```

规则⑤最值得记：它不抛异常，只会把一个错数安静地报出去。

## 2. 实测证据：3857 面积在 30.5°N 放大 1.35 倍

按区统计 `SUM(ST_Area(ST_Transform(geom,3857)))/1e6` 得 11613.82 km²，官方武汉市域 8569.15 km²，偏大 35.5%。

排查顺序与结论：
- 先怀疑区界重叠 → 用 `ST_Union(geom)` 合并后再算，结果**仍是 11613.82**，与按区求和完全一致 ⇒ 13 个区之间基本无重叠，排除该假设。
- 再逐区对比官方面积 → **每个区都稳定偏大 ~35%**（比值 1.354–1.365），不是个别区的几何毛病。
- 改用椭球面积 `ST_Area(geom::geography)` → 与官方面积吻合到 ±1%–4%（黄陂 2246.61 vs 2261；江夏 2009.61 vs 2014；洪山 514.22 vs 509；江汉 28.51 vs 28）。

理论解释：Web 墨卡托面积放大倍数为 `1/cos²(纬度)`，武汉 30.5°N ⇒ `1/cos²(30.5°) ≈ 1.35`，与实测比值一致。这也是「格陵兰在网页地图上看着和非洲一样大」的同一原因。

推论：`ST_SquareGrid(500, geom)` 在 3857 下**边长 500 m 是准的**，但格网**面积**在世界坐标系里要乘 1.35；涉及面积汇总时要留意这一层。

## 3. 附带查出的数据类型坑

- `round(double precision, int)` 在 PostgreSQL 中**不存在**（只有 `round(numeric,int)` 与 `round(double precision)`）。`ST_Area`/`ST_Length` 返回 `double precision`，要取小数必须把**整个结果**转类型：
  `round((SUM(ST_Area(ST_Transform(geom,3857)))/1000000)::numeric, 2)`。报错形态为 SQLSTATE `42883 function ... does not exist`，先查参数类型而非函数名。
- ogr2ogr 导入时把 GeoJSON 里数组形状的 `center`、`centroid` 也**猜成了几何列**，于是表里有三个几何列。后果：查询回传多份 EWKB、QGIS 出现多个图层类型。用 `center` 做 POI 表时别急着删。
- 江夏区 `centroid` 为空（MultiPolygon 退化），需要时 `UPDATE ... SET centroid = ST_Centroid(geom) WHERE centroid IS NULL`，或改 `ST_PointOnSurface(geom)` 避免质心落在面外。
- EWKB 头 `0106000020 E6100000` 解读：`01` 小端、`06` = MultiPolygon、`0xE6100000` = 4326。

## 4. 面试可用的一段完整表述

> 我用 3857 算武汉各区面积，比官方大 35%。查下来是 Web 墨卡托在高纬度放大面积，倍数是 1/cos²(纬度)，武汉 30.5°N 正好 1.35。改用 `geometry::geography` 走椭球计算后，13 个区全部和官方数据吻合到 1% 以内。所以项目里的规矩是：**渲染用 3857，报数用 geography**。

## 5. 未决/后续

- 仍需用 QGIS 把 `admin_area` 与 OSM 底图叠加，确认市界压在长江两岸，以排除源数据实为 GCJ-02 的可能（面积吻合不能证明无整体偏移）。
- 尚未落盘的待办：把本次五道坑（PowerShell 引号 → GDAL 驱动 → PROJ_DATA → 先建库 → numeric 类型/3857 面积）写进项目 `docs/踩坑记录.md` 与 `docs/sql-conventions.md`。
