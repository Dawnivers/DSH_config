---
id: "cf0fbafd-3d5e-4f89-b00b-0db4e02bcf70"
title: "Translation 三维瓦片按层裁剪（LOD 硬截断）：150 万文件里砍掉 91% 的深层请求"
description: "上海城市白膜 3D Tiles（约 150 万文件）按层硬截断的实测层级分布、tileset-L14/15/16 裁剪产物、场景加载 ?lod/?sse/?mem 旋钮与回退机制、部署步骤与观感取舍。"
status: "active"
created_at: "2026-10-21T11:18:27.680Z"
updated_at: "2026-10-21T11:18:27.680Z"
content_hash: "4deac24e5c8aaa3e2a46f6f27e5ab6c996f63bd51665f380179add96df935ba5"
source_paths:
  - "scripts/gen-lod-tileset.mjs"
  - "src/cesiumTools/sceneManager.js"
  - "src/views/cesiumView.vue"
  - ".env.example"
  - "src/components/screenUI/perfGuard.vue"
session_ids:
  - "ec3f449d-0352-42c4-aac2-949f3580f3d7"
memory_body_ids:
  []
---

# 三维瓦片按层裁剪（LOD 硬截断）与加载耗时优化

日期：2026-10-21。项目：`智慧地铁_上线版/Project`（Translation），线上 `project2.dawnivers.top`。
涉及文件：`scripts/gen-lod-tileset.mjs`、`src/cesiumTools/sceneManager.js`、`src/views/cesiumView.vue`、`.env.example`。
数据目录（仓库外，与线上 nginx 资产同构）：`F:\public\shangHaiBuilds_new_toPlane`。

相关文档（只记各自的账，不重复）：`e5a2c008-2ce6-446c-bb70-81dc323f7317`（产物构成/gzip/首屏体积）、`91f97ed8-2a88-4141-8fbf-2c6cb97cecfa`（~6 FPS 的真根因是集显，非 LOD）、`75da7559-5010-47fe-b292-58bd88afa63f`（帧预算拆账与 DOM 直写）。

## 1. 用户诉求与关键前提

诉求：「能不能只加载到第 15 级，这样加载会快一点」。

关键前提（决定了方案形态）：**3D Tiles 没有「第几级」这个开关**。Cesium 按屏幕空间误差（SSE）决定是否继续细化，所以要"只到第 N 级"必须在**数据层把 tileset 树剪断**，只靠代码阈值做不到硬限制。

有利条件：这份数据的**每个节点都自带同名 `.glb`**（`10_xxx.json` 的 `root.content.uri` 就是 `10_xxx.glb`），因此在任意一层剪断都不会出现空洞——父级自己的几何体顶上。

## 2. 数据体检（1,509,600 个文件，枚举耗时 56.3s）

顶层 `geometricError = 156543.03392804228`，`root.children = 12`。

| 层级 | geometricError | 节点数 | 文件数 | 累计占比 | 平均单文件 |
|---|---|---|---|---|---|
| L10 | 611.5 | 12 | 23 | 0% | 1.0 MB |
| L11 | 305.7 | 31 | 60 | 0% | 3.8 MB |
| L12 | 152.9 | 86 | 86 | 0% | 7.4 MB |
| L13 | 76.4 | 248 | 495 | 0.1% | 240 KB |
| L14 | 38.2 | 739 | 739 | 0.1% | 175 KB |
| L15 | 19.1 | 2,279 | 4,558 | 0.4% | 47 KB |
| L16 | 9.6 | ~3.5k | 7,133 | 0.9% | 36 KB |
| L17 | 4.8 | ~22k | 45,494 | 3.9% | 8.7 KB |
| L18 | 2.4 | ~36k | 73,432 | 8.7% | 9.5 KB |
| L19 | 1.2 | ~245k | **490,010** | 41.2% | 3.4 KB |
| L20 | 0.6 | ~443k | **887,568** | 100% | 4.8 KB |

结论：**L19 + L20 占 91% 的文件**，正是"想砍又最有用"的末端两层；L10–L12 单个文件反而很大（1–7 MB），深层瓦片是"多而碎"，请求数而非带宽是主要成本。节点总数（未裁剪全树）约 75 万。

## 3. 已在数据层生成的裁剪版

脚本 `scripts/gen-lod-tileset.mjs` 只读遍历原 `tileset.json`，在目标层把 `children` 剪掉，输出到**与原 glb 同目录**（内部是相对 URI，不能搬走）：

| 文件 | 保留节点 | 剪掉分支 | JSON 大小 |
|---|---|---|---|
| `tileset-L14.json` | 1,117 | 739 | 268 KB |
| `tileset-L15.json` | 3,396 | 2,279 | 822 KB |
| `tileset-L16.json` | 10,529 | 7,133 | 2,556 KB |

校验结果：三份都**引用 glb 全部存在、无缺失、无残留 json 引用**（L14 1113 个 glb 引用、L15 3392、L16 10525，均缺失 0）。

## 4. 代码侧：运行期可切的三个旋钮

`sceneManager.js` 新增 `tileTuning()`，从 URL 读参数（构建期默认值走 `.env.local` 的 `VITE_TILE_*`）：

| 参数 | 默认 | 作用 |
|---|---|---|
| `?lod=N` | 空（完整版） | 用 `tileset-LN.json`，**数据上**不加载更深层 |
| `?sse=N` | 16 | 屏幕空间误差，越大越粗、请求越少 |
| `?mem=N` | 1024（原写死 2048） | 瓦片内存上限 MB |

示例：`?lod=15`、`?lod=15&sse=32`、`?sse=64`（不剪树只防过深细化）。
长期默认固化：`.env.local` 写 `VITE_TILE_LOD=16`、`VITE_TILE_MAX_SSE=24` 后重新 `npm run build`。
`.env.example` 同步补了 `VITE_TILE_*` 说明，并重申"前端没有真正的秘密"（VITE_ 变量会被内联进产物）。

## 5. 顺手修掉的两个既有 bug（都在本次改动范围内）

1. `cesiumView.vue` 的 `modelUrls` 写的是 `option: {}`，而 `loadTilesets` 读 `options` → 自定义参数一直被**静默忽略**。
2. 原来 `Promise.all` 里任一个 tileset 404 就让整个回调不执行（白屏无提示）。现改为**逐个加载 + 失败 `remove` 后返回 `null`**，`loadCb` 一定执行；支持可选的 `fallback`（如 `tileset-L15.json` 没上传时自动退回完整版，只在控制台 warn 一行，不白屏）。

`loadTilesets` 里的调参顺序：`defaultOpts` → `tuning`（sse/mem）→ 单个 tileset 的 `options` 覆盖，后者优先级最高。

## 6. 构建与部署

- 重新构建通过：入口 **`index-DeUCn6KX.js`（516.19 kB / gzip 178.76 kB）**，`dist` 1,140 个文件，`[compress-dist] 174 个文件 · 8.04MB → gzip 2.64MB(33%) / brotli 2.10MB(26%) · 38.1s`。产物里确认含 `tileset-L` 逻辑。
- 部署三步：① 把 `tileset-L1*.json` 传到 `/www/wwwroot/nginx_assets/Translation/shangHaiBuilds_new_toPlane/`（必须与 glb 同级、不改名）；② `dist/` 覆盖 `/www/wwwroot/Translation/Project/dist/`；③ 用 `?lod=16` / `?lod=15` 对比，Network 过滤 `shangHaiBuilds` 看请求是否停在 `15_*.glb`、`16_*.glb`。
- 服务端两个额外杠杆：给 `/nginx/` 加 `expires 30d` + `immutable`（二次进入几乎不下载）；给站点签证书走 https + HTTP/2（现在是纯 http，浏览器只能 HTTP/1.1、单域 6 并发，几十个瓦片请求排队）。

## 7. 效果预期与取舍

- `?lod=15`：最多 3,396 个瓦片可请求，L16–L20 那 91% 的文件永远不会被请求；代价是近看楼体边缘变钝——L15 的几何误差是 19 米级，适合 5–10 公里俯瞰。
- 贴地看楼至少 L17–L18，那时请求量收益已经不大。
- 推荐平衡点：**演示用 `?lod=16`**（比完整版少 ~96% 的深层请求，近景观感损失有限）。
- **`?sse=` 对首屏更有效**：默认 SSE 16 时，4.8 公里高度会把整城细化到 L13–L14，这一波是首屏慢的主因；`?sse=32` 能把首屏请求砍一半以上，远景 SSE 大时本来就分辨不出差别。
- 注意：以上是"加载量/首屏请求"的优化，**不是帧率**优化；帧率的真根因见 `91f97ed8`（集显）。

## 8. 可选的下一步（未实施，待用户选择）

- 把 `tileset-L16.json`（2.5 MB）再拆成「目录结构版」（root json + 十几个小文件），避免首屏下载整个 2.5 MB。
- 按相机高度动态切 lod：远景用 L15、贴近切完整版（两个 tileset 实例 + `show` 切换），观感与速度兼顾。
