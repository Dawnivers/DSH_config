---
id: "ba3a2263-3b2e-4fea-b1c5-f202fe57a8c5"
title: "GeoServer ExternalGraphic 全是灰方块的真正原因：URL Checks 默认拒绝 + 窄规则放行实录（2026-10-25）"
description: "推翻「环境级限制」结论：URL Checks 开着但规则列表为空 → 默认拒绝一切外部 URL，故所有图标画成灰方块且日志静默；给出 Test URL 取证、窄放行规则、验证、poi_icons 样式恢复与 ?v= 失败缓存技巧。"
status: "active"
created_at: "2026-10-25T06:13:21.217Z"
updated_at: "2026-10-25T06:13:21.217Z"
content_hash: "58db4f457b766c46d6678bec23e627bd91be13bdf61f4e27182b8ba88f18db24"
source_paths:
  - "styles/poi_icons.sld"
  - "styles/poi_badge.sld"
  - "styles/poi_by_category.sld"
  - "styles/png"
session_ids:
  - "806e3bfd-0aaf-40c1-a596-0d4b94d549fc"
memory_body_ids:
  []
---

# URL Checks 是 ExternalGraphic 全部失败的真正原因

> **本文修正前一篇的结论。** 前篇 `69d45ed3-6355-4e25-8855-993c74bb1706` 第 4 节判定「这台 GeoServer 加载不了任何 ExternalGraphic，属环境级限制」。该判定**错误**：限制来自一项可配置的安全策略，加一条窄规则后 SVG 图钉正常渲染。前篇其余内容（样式文件存放/命名规则、三层真相、一致性三连）仍然有效，照用。

相关：REST 上传 SLD 与 UI 等价、幂等写法 `be91eaef-f93d-4d77-803d-b34651d1dfd1`；`wuhan` 工作区与 `poi` 图层发布 `e2a4925e-c390-44f3-bd15-8bf165e70b28`。

## 1. 症状指纹（重新解读）

四种取图方式（`http://localhost:8080/geoserver/www/icons/*.png`、局域网 IP、`file:///`、classpath）与 GeoServer 自带的 `grass_fill.png` **全部画成灰方块，日志一句不报**。当时把「连自带图都失败」读成环境级缺陷，实际它恰好是**策略层统一拒绝**的指纹：拒绝发生在取图之前，所以既不报 404 也不报 IO 异常。

像素统计做对照是这个阶段的有效手段：正常上图会出现分类色的蓝/红像素，失败时只有灰像素。

## 2. 取证：用页面自带的 Test URL 一句话定案

安全 → **URL Checks**（`.../security/web/url/URLChecksPage`）页底部有 `Test URL`。把图标地址贴进去点测试，返回：

```
No URL check matched the URL, it won't be allowed
```

即 **URL Checks 已启用、规则列表为空 → 默认拒绝一切外部 URL**。无需求助日志，这一句就是判据。以后遇到「外部资源静默不加载」，先来这里测一次，比翻日志快。

## 3. 放行：一条窄规则，别写 `.*`

`Add a new URL check` 四项：

| 字段 | 值 |
|---|---|
| Name | `local-icons` |
| Description | 本机图标目录（GeoServer www） |
| Regular Expression | `http://localhost:8080/geoserver/www/.*` |
| Enabled | 勾选 |

保存后回本页再测同一 URL，期望变成：

```
URL is allowed, was matched by this check: local-icons
```

**为什么必须窄**：URL Checks 本是防 SSRF 的护栏（防止某个 SLD 引用内网地址）。写成 `.*` 等于关掉防护；限制到单个 `www` 目录既能用图标又保留护栏。该设置**全局生效**，影响所有工作空间与样式；也不要为图省事直接取消勾 `URL checks are enabled`。

## 4. 放行后恢复图标样式（实测可用）

图标文件在 `D:\geoserver\data_dir\www\icons\{school,hospital,mall,park}.{svg,png}`，经 `/geoserver/www/icons/...` 访问——**图标属于 GeoServer 资源，不在前端项目里**，换机器/重置 `data_dir` 要一起搬。

- 上传 `wuhan:poi_icons` → `201`，出图像素统计出现蓝 690 / 红 2890 / 灰 5008 → 图片确实加载了。
- 图钉尺寸从 26px 调到 36px（公园 38）更醒目，`PUT` 后 `200`。

当前工作空间保留三套可选样式：

| 样式 | 形态 | 定位 |
|---|---|---|
| `wuhan:poi_icons` | SVG 图钉 36px + 白字标签 + 全市小点 | 推荐 |
| `wuhan:poi_badge` | 纯矢量徽章（白环彩底 + 内嵌字形） | 不依赖 URL 的兜底 |
| `wuhan:poi_by_category` | 简单四色圆点 | 对照/教学 |

挂默认：图层 → `wuhan:poi` → 发布 → WMS 设置 → 默认样式 → 保存。

## 5. `?v=N` 不是装饰：绕开失败缓存

GeoTools 会缓存「取图失败」的结果，改样式而不改 URL 不会重试。给 `OnlineResource` 的 href 加查询串（如 `...school.svg?v=4`）等于换了个新 URL，绕开失败缓存。**改图标文件后把 `?v=` 数字 +1** 即可，无需重启 GeoServer。

## 6. 更新样式的固定命令

```powershell
curl.exe -u <user>:<pass> -X PUT -H "Content-Type: application/vnd.ogc.sld+xml" `
  --data-binary "@styles\poi_icons.sld" `
  "http://localhost:8080/geoserver/rest/workspaces/wuhan/styles/poi_icons"
```

REST 删除样式后再清理：删磁盘上的 `.sld`+`.xml` 对文件 + `POST /rest/reload`；若 GUI 仍显示旧样式，是 Wicket 页面没刷新（Ctrl+F5），不是 catalog 残留——用「磁盘 / REST 列表 / 全库 grep 引用」三处对照确认。

## 7. 可调与后续

- 缩放分级：不同 `MaxScaleDenominator` 段配不同 `Size`（现行：5 万以内出图钉，1.2 万以内出名称）。
- 密集区聚合：内置 `vec:PointStacker`（进阶）。
- 下一步主线：WMS `GetFeatureInfo` 支撑前端点击弹详情。
