---
id: "72feafbd-2625-4f82-ac10-0e47afc7a94d"
title: "B 路线（GVHMR 世界坐标动捕）实施规格：WSL2 硬约束、SMPL 许可、hf-mirror 权重清单"
description: "GVHMR 方案从选型转入可执行部署的实施规格：为何必须 WSL2+Ubuntu（pytorch3d 仅 Linux 轮子）、SMPL/SMPL-X 注册为非审批且限非商业、用 HF 仓库 ryanrudes/gvhmr 经 hf-mirror 取全套 5.56GB 权重替代 Google Drive、本机环境体检数字、待执行的六步计划与重定向手写层风险。AD 路线选型与既有 MediaPipe 管线见关联文档。"
status: "active"
created_at: "2026-10-16T15:08:01.056Z"
updated_at: "2026-10-16T15:08:01.056Z"
content_hash: "5ebc78c16a23057ea1bb931fec2526d6020621e30e0c8686a920dfedf6a0be1a"
source_paths:
  - "mocap/retarget_compute.py"
session_ids:
  - "314d5461-69c3-4039-8907-2f1bba97374c"
memory_body_ids:
  []
---

# B 路线（GVHMR 世界坐标动捕）实施规格

> 定位：把「舞蹈视频 → 3D 动捕 → Chisa 骨骼动画」从**选型**推进到**可执行部署**时所核实的事实与规格。
> 选型背景、GVHMR/WHAM/TRAM 对比与分阶段成本计划见既有文档 `16979651-4dbf-4432-8bc0-29541f6fc50f`（本方案是该文 §7 选项③ 的展开）。
> 既有 MediaPipe（A 路线）实测与六项缺陷见 `76ada9d6-3534-48c4-9bda-72faeb3e1573`；Chisa rig 坐标陷阱见 `065c7b95-72ee-4323-96c0-2a5b179e432e`。
> **状态：方案定型，尚未执行**（本文不含任何"已完成"的成果）。

## 1. 为什么选 B（相对 A 路线的根因归因）

A 路线（MediaPipe）被用户判定「严重不符」，根因不是平滑不够，而是 **MediaPipe 逐帧从 2D 抬升深度**：无时序一致性、无身体模型约束、无根位移（世界地标以胯为原点）——表现为左右手交叉时认反、脚部滑动、角色只能原地跳（实测证据见 `76ada9d6`）。

GVHMR 修的是**输入层**：基于 SMPL 身体模型先验 + 重力-视角坐标，输出**世界坐标**运动（含全局轨迹）。这一条对应上文中"看着不像在跳那支舞"的核心症状。

**但必须提前说清的边界**：重定向层**仍是本项目自己的代码**（`retarget_compute.py` 的"方向匹配 + 平滑 + 限速"框架），它只匹配方向、不控 twist/roll、无脚部 IK。所以 B 不保证一次通过，预期还要 1–2 轮迭代。

## 2. 硬约束一：**必须 WSL2 + Ubuntu**（决定整条部署路径）

GVHMR 官方 `requirements.txt`（main 分支，已拉取核实）中有一条**只有 Linux 轮子**的依赖：

```
pytorch3d @ https://dl.fbaipublicfiles.com/pytorch3d/packaging/wheels/
            py310_cu121_pyt230/pytorch3d-0.7.6-cp310-cp310-linux_x86_64.whl
                                                          ^^^^^^^^^^^ linux only, cp310
```

配套还有 `cython_bbox`（需 C 编译器）与 `chumpy`（老旧，Windows 上易失败）。**结论：原生 Windows 装这条链是一场依赖苦战；Linux 下这些全是预编译包，零编译。**

→ 部署形态固定为：**WSL2 + Ubuntu，发行版 vhdx 装到 D 盘**（`wsl --import`）。

### 本机环境体检（实测数字）

| 项 | 结果 | 判读 |
|---|---|---|
| 显卡 | RTX 4070 Laptop，**8188 MiB**，驱动 596.36（CUDA 13.2） | GVHMR 推理够用 |
| WSL | `wsl.exe` 存在，**未安装任何发行版** | 需装 Ubuntu |
| 虚拟化 | `HypervisorPresent = True` | WSL2 可用 |
| 编译器 | 无 MSVC（`cl`）、无 gcc | 原生 Windows 编译类依赖不可行 |
| conda / mamba | 均无 | 用 venv，或 miniconda 装到 D 盘 |
| 磁盘 | C: 59.6 GB 可用 / **D: 236.3 GB 可用** | 11 选 D: |

### 依赖版本钉死（`requirements.txt` 关键项）

- `torch==2.3.0+cu121`、`torchvision==0.18.0+cu121`（`--extra-index-url https://download.pytorch.org/whl/cu121`）
- `lightning==2.3.0`、`hydra-core==1.3`、`hydra-zen`、`hydra_colorlog`
- `numpy==1.23.5`（注意较旧）、`imageio==2.34.1`、`av==13.0.0`、`timm==0.9.12`（HMR2.0a 特征提取用）
- `ultralytics==8.2.42`（YOLO）、`cython_bbox`、`lapx`、`pycolmap`、`wis3d`、`trimesh`、`smplx`
- 注释掉的 diffusion 段（`diffusers`/`transformers`）**不需要装**

## 3. 硬约束二：SMPL / SMPL-X 许可（必须用户本人注册）

**注册 ≠ 审批**：填邮箱密码 + 勾选 "Accept license" 后**立即开通 Downloads**，无人工审核、无等待期。唯一约束是许可原文 `"only for noncommercial research purposes"`。

需要注册**两个站**：

| 站点 | 注册地址 | 需要的文件 | 放置路径（相对 GVHMR 根） |
|---|---|---|---|
| SMPL | `https://smpl.is.tue.mpg.de/register.php` | `SMPL_NEUTRAL.pkl` | `inputs/checkpoints/body_models/smpl/` |
| SMPL-X | `https://smpl-x.is.tue.mpg.de/` | `SMPLX_NEUTRAL.npz` | `inputs/checkpoints/body_models/smplx/` |

两文件合计约 140 MB，MPI 站点国内可直连（不需代理）。

**商用红线**：本许可仅限非商业研究。若成果要交付给需要商用的项目（例如智慧地铁类），必须另走商业授权（`smpl@max-planck-innovation.de` / Meshcapade）或改用 Rokoko 等商业服务。

## 4. 权重要真实获取路径：**绕开 Google Drive**

GVHMR 官方 `INSTALL.md` 指示权重从 Google Drive 下载；本机代理实测仅 ~45 kB/s，而这批权重合计 5.56 GB → **约 40 小时，实际不可行**。

**替代路径（已核实）**：HuggingFace 仓库 **`ryanrudes/gvhmr`** 一次给齐全部所需权重，`gated: false`（无需申请访问），`usedStorage = 5558945137`：

```
gvhmr/gvhmr_siga24_release.ckpt
hmr2/epoch=10-step=25000.ckpt
vitpose/vitpose-h-multi-coco.pth      # ViTPose-H，约 2.5 GB
yolo/yolov8x.pt
```

- 备用/交叉源：`camenduru/GVHMR`（另含 `vitpose/vitpose-h-multi-coco.pth`）、`wendell0218/gvhmr_ckp`、`ryanrudes/gvhmr` HF Space 与 `tigretibu/gvhmr-demo`。
- **国内加速**：`export HF_ENDPOINT=https://hf-mirror.com`（公益镜像，兼容 `huggingface_hub` / `hf` CLI / `transformers`）。
- **DPVO 跳过**：它是可选件且需要编译；本项目机位固定，静态场景够用。

## 5. 便宜探针（可选，先试再装）

`ryanrudes/gvhmr-demo` 是已部署的 Gradio HF Space：`stage = RUNNING`，host `https://ryanrudes-gvhmr-demo.hf.space`，`gated: false`。

**限制**：硬件为 `cpu-basic`（非 GPU），458 帧在纯 CPU 上可能极慢甚至超时。因此只能当"顺手一试"，**不能作为主路径**。

## 6. 待执行的六步计划（尚未开始）

```
① WSL2 + Ubuntu（vhdx 落 D 盘）                 ~20–40 分钟
② Ubuntu 内：venv + pip install -r requirements.txt + pip install -e .
   （torch 2.3.0+cu121 走国内镜像）               ~30 分钟
③ 权重 5.56 GB 从 hf-mirror 下到 D:\mocap\gvhmr\ ~20–60 分钟（取决于镜像速度）
④ 跑 GVHMR 出世界坐标 SMPL 运动                  ~5–20 分钟
⑤ 改重定向：MediaPipe 33 地标 → SMPL 24 关节 + 加根位移
   （沿用 retarget_compute.py 的方向匹配/平滑/限速框架） ~2–3 轮
⑥ 应用 + 渲 3 张小图验收（沿用既有的三图纪律）
```

**复用要点**：`D:\mocap\retarget_compute.py` 的框架可直接搬，只需换输入（33 地标 → SMPL 24 关节）并补根位移。

**验收时仍需牢记的 rig 陷阱**（详见 `065c7b95`）：376 骨 Biped、rest 本身是屈膝坐姿（绝对角度不是正确判据，要看逐帧最大跳变）、骨架 0.01 缩放 + Y↔Z 轴交换、Cesium 上 376 关节蒙皮会被静默丢弃。

## 7. 成本与执行方式建议

该会话上下文已很大且 B 是数小时的长活，**在新会话中执行 B 可显著降低单轮成本**；本规格即为此准备的交接件。

**卡在用户侧的第一步**：SMPL / SMPL-X 注册（约 5 分钟）绕不过去——没有 body models，GVHMR 跑不起来。
