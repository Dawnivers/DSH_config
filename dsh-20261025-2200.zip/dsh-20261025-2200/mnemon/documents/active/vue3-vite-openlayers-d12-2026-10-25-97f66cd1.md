---
id: "97f66cd1-9d3f-4f0e-bd72-027541aeba14"
title: "Vue3 + Vite + OpenLayers 白屏/幽灵报错排障流程（D12 接线期实测，2026-10-25）"
description: "openlayers服务平台开发 FE 项目迁 Vue3 后连续白屏的可复用判读流程：先分清「磁盘代码错 / dev server 返回旧代码 / 浏览器缓存旧弹层」三源，再按 <script setup> 顶层 ReferenceError 模式逐项定位；含 EBUSY 致 HMR 失效、无头浏览器全新 profile 与 DOM 长度判别、GeoServer 日志确认 getMap 的取证手法。"
status: "active"
created_at: "2026-10-25T12:15:27.596Z"
updated_at: "2026-10-25T12:15:27.596Z"
content_hash: "a650a96945b80f0c4b1639d85e689c41f466124ffd2ba5287056243c42ec9686"
source_paths:
  - "FE/src/App.vue"
  - "FE/src/view/mapView.vue"
  - "FE/src/map/wms.js"
  - "FE/src/stores/layers.js"
  - "FE/src/map/layers.js"
session_ids:
  - "a1d1be8e-562c-4706-8e64-de78eb1c09e9"
memory_body_ids:
  []
---

# Vue3 + Vite + OpenLayers 白屏 / 幽灵报错排障流程

> 承接 `563ae7f5-4d89-40d3-af0b-fc24c1f473cc`（WMS 接入约定与组件路线）与 `74b0dea8-c01f-4df9-b499-4b3fc3b0ae0a`（vanilla 架构与 D12 迁 Vue 检查单）。那两篇讲**该怎么写**，本篇只讲**白屏之后怎么判**——2026-10-25 晚在 `FE/src` 连续三轮白屏中实测归纳，可直接复用到任何 Vite + 框架 + 命令式库（OL / Cesium）组合。

## 1. 第一原则：先分清报错来自哪一层

同一屏「红字弹层」有三种来源，处理动作完全不同。**不先分辨就改代码，会越改越乱**（本轮曾三次对着已经修好的文件找错）。

| 来源 | 特征 | 判别手段 |
|---|---|---|
| A. 磁盘代码真的错 | 文件 `LastWriteTime` 与报错内容一致 | 读磁盘文件对应行；`grep` 报错里的那个片段 |
| B. dev server 返回旧/半成品模块 | 报错内容是**打字中途的半成品**（如 `import.meta.-`、`const poiLayer createPOILayer` 少等号） | 直接抓 dev server 实际返回的模块，`grep` 坏片段 |
| C. 浏览器缓存旧错误弹层 | 截图里有弹层，但无头浏览器全新 profile 是**纯白** | 全新 `user-data-dir` 重截；比对 PNG 字节数 |

B 的根因通常是**文件监听失效**：终端里出现 `EBUSY: resource busy or locked` 后 HMR 就不再推送，页面停留在某个中间状态。判定后直接重启 dev server（记下新 pid），比反复保存文件有效。

抓 B 的证据：对 `vite` 的模块 URL（`http://localhost:<port>/src/view/mapView.vue`）取源码，检查里面是否**同时**存在「期望的正确片段」与「报错里的坏片段」。正确片段在、坏片段不在 ⇒ 磁盘与服务器都已好，剩下的白屏是运行时问题，不是编译问题。

## 2. 白屏的运行时主因：`<script setup>` 顶层抛一个 ReferenceError 就整页不渲染

Vue3 `<script setup>` 的顶层代码等于 `setup()` 函数体，**任何一行 `ReferenceError` 都会让根组件挂载失败**，页面表现为干净白屏、Console 一条错、DOM 为空。迁移期最常见的是**残留的接线语句**：

```js
// 删掉数据源后忘了删的 watch：watch / store / poiLayer 三者可能都没定义
watch(() => store.visible.poi, v => poiLayer.setVisible(v), { immediate: true })
```

排查姿势（按成本从低到高）：

1. 读根组件，逐行问「这个名字在本文件里定义了吗 / import 了吗」——`watch`、`useLayerStore`、layer 实例是最常漏的三个。
2. 检查 `layers: [...]` 这类**构造期数组**是否还引用着已被注释掉的变量（把 WMS 图层改成工厂函数 `map.addLayer` 后，数组里那项必须同步删掉）。这类错在 `onMounted` 里抛，症状是「面板有、地图空白」而不是全白。
3. 判「是编译错还是运行错」：无头浏览器全新 profile 截图 + 取 `document.body.innerHTML.length`（0 = 根组件没挂上）。

## 3. 出图之后 NEXT 判据：GeoServer 日志优先于肉眼

图「看着像没出来」时，先看服务端有没有收到请求，再看前端：

- 日志出现 `Request: getMap` 且 `RawKvp` 里带 `SRS=EPSG:3857`、`LAYERS=...`、`STYLES=wuhan:poi_icons` ⇒ WMS 链路通，问题只可能在前端图层顺序 / opacity / `TRANSPARENT`。
- zoom 9 时 16,016 个 POI 会按比例尺收成 3px 小点（不是没渲染，是样式自身分级），截图字节数从 ~7.9 KB（纯白）跳到 ~300–700 KB 就是「真有内容」的量化标志。

## 4. 面板与地图「各自能跑但连不上」的固定症状

本轮出图后剩下的唯一功能性缺陷，形状值得记住：

```
LayerPanel --emit--> App.vue 的本地 reactive 数组        （没人读）
mapView   --watch--> Pinia store                          （没人写）
```

两侧都「实现正确」，中间缺一环 ⇒ 勾选会打勾、地图一动不动。**判据：看 `App.vue` 的 import 里有没有 `useLayerStore`**；没有就说明 store 从没被写入过。修法（单一数据源）见 `563ae7f5` 的注册表 + `watch immediate: true` 章节；分工原则一句话：**谁拥有 map 实例，谁就放 `watch`；根组件只持 store 与面板事件**。

## 5. 顺序纪律

先让页面**出图**（只改 1–2 行、只删不加），确认能渲染，再接线交互。一次改完多层，「白屏 / 空白 / 图层不动」三种症状会叠加，无法二分定位——本轮每次卡住都是因为一次性改动跨了三层。
