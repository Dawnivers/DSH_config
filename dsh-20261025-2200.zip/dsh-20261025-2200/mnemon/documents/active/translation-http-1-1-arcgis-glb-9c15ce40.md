---
id: "9c15ce40-c2f9-4c44-afe6-ede26e6cb8d3"
title: "Translation 三维站点加载慢与 HTTP/1.1 溯源：ArcGIS 底图、服务器出口带宽、瓦片缓存与列车 glb 贴图压缩"
description: "智慧地铁 Translation 项目（project2.dawnivers.top）上线后排查「Network 里出现 http/1.1」与「城市模型/列车模型加载慢」的完整证据链与已实施修复：唯一 h2 例外是 server.arcgisonline.com（已用 imageryProvider:false 摘掉）、服务器出口实测仅 ~3Mbps、宝塔反代模板给出 Cache-Control:no-cache、城市瓦片纯几何无贴图可压、列车 glb 从 23.55MB 压到 8.62MB 的方法与回滚路径。"
status: "active"
created_at: "2026-10-21T12:15:03.294Z"
updated_at: "2026-10-21T12:15:03.294Z"
content_hash: "f167f50a80ab18de889f5aa7407e5f4d27e708e5290aa5fd4635777609768432"
source_paths:
  - "src/cesiumTools/sceneManager.js"
  - "src/views/cesiumView.vue"
  - "src/cesiumTools/lineAndpoints/train/trainRoam.js"
  - "scripts/compress-glb-textures.py"
  - "src/assets/trainAndChisa_static.glb"
session_ids:
  - "c1a1645b-ba71-4f4f-b372-7c774c48463f"
memory_body_ids:
  []
---

# Translation 上线站点：HTTP/1.1 溯源 + 加载慢的真实瓶颈（2026-10-21）

对象：`D:\WebGIS\web三维开发\智慧地铁_上线版\Project`（Vite + Vue3 + Cesium，源站 101.43.119.248，前端 `project2.dawnivers.top`，后端 `translationbe.dawnivers.top`）。

触发：用户问「前后端都开了强制 HTTPS，为什么 Network 里还有 http/1.1」；随后问「城市模型一部分先出来一部分没有、列车模型也很慢」。

关联文档：构建包体与 gzip 收益见 `e5a2c008-2ce6-446c-bb70-81dc323f7317`（其中统计的 23.56MB 列车 glb 已被本文的 8.62MB 版本取代）。

---

## 1. 结论一：http/1.1 只有一个来源，不是 nginx

对页面会碰到的每个域名做真实 TLS ALPN 握手（不是猜）：

| 域名 | 协商结果 | 归属 |
|---|---|---|
| project2.dawnivers.top | **h2** TLS1.3 | 前端 ✅ |
| translationbe.dawnivers.top | **h2** TLS1.3 | 后端 ✅ |
| p0.map.gtimg.com | h2 | 腾讯影像 ✅ |
| gac-geo.googlecnapps.cn | h2 | 备用底图 ✅ |
| **server.arcgisonline.com** | **http/1.1** | ← 唯一例外 |

同时验证强制跳转：`http://project2...` → 301 https、`http://translationbe.../getLine` → 301 https，均正常。**强制 HTTPS 一直是生效的；特例来自 ArcGIS 服务端自身不支持 h2，客户端无法改变。**

### 修复：摘掉被完全遮住的 ArcGIS 默认底图

`src/cesiumTools/sceneManager.js` 的 `initViewer` 原本把 ArcGIS World_Imagery 设为默认底图，而 `src/views/cesiumView.vue` 紧接着调 `addTecenMap(viewer)` 把腾讯影像叠在最上层 —— ArcGIS 整层被盖住却仍在逐块下载，等于请求翻倍、还全走海外单域 h1.1（浏览器单域 6 并发）。

改为：

```js
imageryProvider: false,   // 官方语义：不添加任何默认底图，由腾讯图层顶上
```

合法性依据（Cesium 源码，逐行核对）：`node_modules/cesium/Source/Widgets/CesiumWidget/CesiumWidget.js` 第 126 行 JSDoc 写明 `ImageryProvider | false` → "no imagery provider will be added"；第 350 行 `if (imageryProvider !== false)` 才真正 `imageryLayers.addImageryProvider`。注意第 346–347 行是 `!defined()` 判空才回落到 `createWorldImagery()`，传 `false` 不会偷偷去请求 ion。

产物校验：新入口 `index-BK-lbVRc.js`（516,052 B）中 `arcgisonline` / `World_Imagery` 出现 0 次，`gtimg` 仍为 2 次，`VITE_TILE_LOD=14` 仍内联未丢。

**已知代价**：原本 ArcGIS 是兜底底图，摘掉后若腾讯图层加载失败会没有底图。需要保险时可在腾讯 `readyPromise` reject 时动态加回 ArcGIS。

---

## 2. 结论二：慢的根因是服务器出口带宽，不是 LOD

实测（本机 → 源站，非估算）：

| 测量 | 结果 |
|---|---|
| 单流下载瓦片 | 315–390 KB/s（≈3 Mbps） |
| 4 条并发下载瓦片 | 364k+147k+144k+151k = **0.77 MB/s**，几乎不叠加 → 出口被限速 |
| Cloudflare 基线（判本机线路） | 598 KB/s |
| 直连 666 端口（绕过反代） | 389 KB/s（与走反代同量级，排除 nginx 瓶颈） |
| 4.4MB 的 L10 瓦片 | 11–14 s |
| 24.7MB 列车模型 | ≈84 s |

推论：L14 城市模型全量 685MB 在此带宽下不可能快；「有些先出来有些没有」只是 Cesium 按视锥/SSE 优先级逐块请求、被低带宽放大的正常表现。**先升带宽或挂 CDN（静态瓦片最适合 CDN，源站只回源一次），再谈 Draco / 降 LOD。**

---

## 3. 结论三：两个附带发现的真问题

### ① 瓦片响应头是 `Cache-Control: no-cache`

瓦片响应：`Content-Type: application/octet-stream`、有 ETag/Last-Modified、但 `Cache-Control: no-cache`；前端 js 更彻底，连 `Cache-Control` 都没有。来源是**宝塔反代配置模板**默认写的 `if ($static_file... = 0) { add_header Cache-Control no-cache; }`（位形如 `/www/server/panel/vhost/nginx/proxy/<站点>/<hash>_<站点>.conf`）。后果：每次打开都要逐块回源校验，739 个瓦片就是 739 次往返。

处置（需在服务器上执行，改前先 `cp -a` 备份同名 `.bak`）：

```bash
sed -i 's#add_header Cache-Control no-cache;#add_header Cache-Control "public, max-age=31536000, immutable";#' "$CONF"
nginx -t && nginx -s reload
# 站点 conf 另加静态资源长缓存
location ~* \.(js|css|wasm|glb|jpg|png)$ { expires 30d; add_header Cache-Control "public, immutable"; }
```

⚠️ `immutable` 只对带内容哈希的文件名安全（本项目 `index-<hash>.js`、`trainAndChisa_static-<hash>.glb` 满足）；无哈希的 `tileset.json` 若长期 immutable，替换 tileset 后客户端不会更新。

### ② 城市瓦片是纯几何，贴图压缩对它无效

抽查 L10/L12/L14 三块瓦片 glb：`extensionsRequired: ['EXT_mesh_features','EXT_structural_metadata']`、`images: 0`、属性只有 `NORMAL/POSITION/TEXCOORD_0/_FEATURE_ID_0`。

| 瓦片 | 体积 | 三角形 |
|---|---|---|
| 10_529_600_512.glb | 4.22 MB | 61,267 |
| 12_2116_2399_2048.glb | 0.55 MB | 7,199 |
| 14_8462_9606_8192.glb | 0.16 MB | 1,946 |

即 4.2MB 全是未压缩 Float32 顶点 → 想再压只有 Draco（5–10×，需编码器 + Cesium 解码器配置，有兼容风险）或降 LOD / 调 SSE。

---

## 4. 列车模型：23.55MB → 8.62MB（已实施）

用法与工具链：`scripts/compress-glb-textures.py`（Pillow 12.3 可用，`D:\python\python.exe`），直接改写 glb 内嵌 PNG 的 `bufferView`，不动 JSON 结构。支持 `--dry` 只打表。

解剖结论：`bufferViews` 合计 23.55MB 中 **17.65MB 是 8 张 2048²（另 1 张 4096²）PNG**，几何只有 5.89MB / 12 万三角形 / 9 primitives。

两种档位实测：

| 方案 | 结果 |
|---|---|
| 保持 2048，PNG→JPEG q85 | 23.55 → **8.60MB**（贴图 17.65 → 1.7MB，≈10×） |
| 降到 1024（另测） | 23.55 → 6.65MB，但清晰度损失更大 |

采用 2048 档，逐张贴图压缩比 4×–15×（最大一张 3989KB → 505KB）。

校验方式（结构级，不靠肉眼）：解析 json 与 bin，确认 65 个 bufferView 全部在 `buffer.byteLength` 界内、8 张贴图 magic 与尺寸可解码、nodes/meshes 数不变（12/9）。

回滚与产物：

| 用途 | 路径 | 大小 | MD5 |
|---|---|---|---|
| 源文件（已替换） | `src/assets/trainAndChisa_static.glb` | 8.62MB | B7F88A1B0E1A329AF83C4987D3E38F0B |
| 构建产物（要上传） | `dist/assets/trainAndChisa_static-Wyqy541i.glb` | 8.62MB | 同上（一致） |
| 原始备份 | `scripts/out/trainAndChisa_static.orig.glb` | 23.56MB | 7E90B6B5616F634F671C120679911B72 |
| 中间产物（可删） | `scripts/out/train.opt.glb` | 8.62MB | — |

引用点：`src/cesiumTools/lineAndpoints/train/trainRoam.js:40` → `'../../../assets/trainAndChisa_static.glb'`（另有 `.bak-20261019` 同引用，勿混淆）。

**部署注意（踩坑点）**：产物文件名带内容哈希，新入口 `index-B7n75y0u.js` 引用的就是 `-Wyqy541i`。只传 glb 不传 js 等于没改，必须整套覆盖：

```bash
scp -r dist/* root@101.43.119.248:/www/wwwroot/Translation/Project/dist/
rm -f /www/wwwroot/Translation/Project/dist/assets/trainAndChisa_static-CU8atkpj.glb
```

验证：`curl -sI .../assets/trainAndChisa_static-Wyqy541i.glb` 应 200 且 `Content-Length: 9035880`，旧 `-CU8atkpj` 应 404；F12 Network 搜 `trainAndChisa` 应只剩 8.62MB 那条。

---

## 5. 自查与后续顺序

定位「哪条请求是 1.1」：F12 → Network → 右键表头勾 **Protocol** → 按该列排序；点开请求 Headers 底部同样有 `Protocol:`。零星 1.1 只剩两种来源：页面用 `http://` 打开（已被 301 排除）、或别的第三方域。

按收益排序的处置：① 开长缓存（5 分钟，回访几乎零下载）→ ② 传新 dist → ③ 升带宽/上 CDN → 最后才考虑 Draco 或 SSE=32。缓存 + 带宽到位后，L14 首屏体验通常已可接受。
