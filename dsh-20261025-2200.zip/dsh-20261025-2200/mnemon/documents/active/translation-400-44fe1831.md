---
id: "44fe1831-c29a-4d4c-aed8-334dfb8fa556"
title: "Translation 智慧地铁：站点面板「路径规划」模式（400 站起终点、接口换乘方案、三维逐段高亮）"
description: "2026-10-19 在 StationPanel 新增 guideload 模式：planModel/renderRoute/useRoutePlan/RouteDesign 四文件 + QueryModePanel 一行接入；含下拉改 datalist、几何走本地折线切片而非接口 polyline 的取舍，以及 3 组真接口站序核对与 425 实体不累加的验证证据。"
status: "active"
created_at: "2026-10-19T03:25:59.119Z"
updated_at: "2026-10-19T03:25:59.119Z"
content_hash: "46dfd78e93851f9d7104ce6e4f33fe7fc44ced32bc3b63fe2da8f979c0c07b9e"
source_paths:
  - "Translation/src/components/bottom/StationPanel/QueryModePanel/guideload/planModel.js"
  - "Translation/src/components/bottom/StationPanel/QueryModePanel/guideload/renderRoute.js"
  - "Translation/src/components/bottom/StationPanel/QueryModePanel/guideload/useRoutePlan.js"
  - "Translation/src/components/bottom/StationPanel/QueryModePanel/guideload/RouteDesign.vue"
  - "Translation/src/components/bottom/StationPanel/QueryModePanel/QueryModePanel.vue"
session_ids:
  - "a9bf221f-3e4d-4ebb-8b5a-a0677e05ebb8"
memory_body_ids:
  []
---

# Translation 智慧地铁：路径规划模式（站点面板 guideload）

日期：2026-10-19。入口：`/nodes` 站点面板切到「路径规划」。输入起点/终点（400 站），调接口拿到换乘方案，面板显示概况 + 分段列表，三维里逐段高亮线路并标出起/终/换乘点。

相关文档：
- `1056d83b-fc4b-4598-834b-404ed7f42702`（vue-router 驱动的面板与 Cesium 不重建）
- `f120df6f-8480-4127-9793-8df0e970da36`（线路/站点开关分离、stationOwners 归属集合）
- `06177dd0-801f-488a-9ec4-6a1e0cefb741`（lineStationOn 线路级开关）

## 1. 文件与职责

| 文件 | 行数 | 职责 |
|---|---|---|
| `Translation/src/components/bottom/StationPanel/QueryModePanel/guideload/planModel.js` | 236 | 纯函数：400 站去重、线路号匹配、本地折线切片、接口响应归一化。零 import，可直接 node 跑 |
| `.../guideload/renderRoute.js` | 148 | 逐段高亮线 + 起点/终点/换乘标记 + 相机取景；全部私有实体，不碰 18 条全局线 |
| `.../guideload/useRoutePlan.js` | 195 | 请求、状态、进入/退出模式（进入时隐藏、退出时还原 18 条全局线） |
| `.../guideload/RouteDesign.vue` | 401 | 面板 UI：起终点输入、概况、分段列表 |
| `.../QueryModePanel/QueryModePanel.vue` | +3 | `<RouteDesign v-if="active === 'guideload'" />`；外壳 QueryModePanel 仍是约 30 行逻辑 |

把数据/几何/状态/UI 四层拆开的直接收益：`planModel.js` 无 import，所以接口正确性可以先在 node 里用手写脚本核对，不必开浏览器。

## 2. 两个偏离初版方案的决定（附理由）

**① 下拉框改为 `<input list>` + `datalist`。**
400 个站放进原生 `<select>` 既难翻也难自动化：系统弹层在浏览器桥里点不开，无法做端到端验证。改成输入框后边输边筛，也能被桥驱动验证。站名不在 18 条线路里时给红字提示，不发出「坐标为空串」的请求（曾出现「火星站不在 18 条线路的站点里」的提示路径）。

**② 几何用本地折线切片，不用接口返回的 `polyline`。**
实测接口的 `polyline` 是**对象** `{ polyline: "lng,lat;..." }`（不是空串，最初是取字段写法错了），长度 5000–13000 字符，是真实走行线。但它与高德自己数字化对齐，和三维场景里既有的 18 条线会错开几十米，看起来像「画歪了」。
因此优先用站名在 `line.positions` 里找顶点、切出这一段——与既有线路严丝合缝；只有当站名匹配不到本地线路（磁浮之类）时才回退到接口 `polyline`。

## 3. 接口方案与核对数据

后端请求返回单一最优方案（`AlternativeRoute=1` 时只要一条）。三组真接口结果：

```
莘庄 → 五角场 : 5元 84分 28.9km 换乘1次 步行723m
  #1 1号线 莘庄→陕西南路   11站 26min geom=134pts
  #2 10号线 陕西南路→五角场 13站 29min geom=140pts
富锦路 → 滴水湖 : 12元 154分 89.9km 换乘2次 步行695m
  #1 1号线 16站 / #2 2号线 8站 / #3 16号线 14站(58.8km) geom=448pts
徐家汇 → 人民广场 : 4元 38分 8.4km（走 11号线→2号线，江苏路换乘）
```

站数逐个对照真实站序核实过：1号线富锦路→人民广场 16 站、2号线人民广场→龙阳路 8 站、16号线龙阳路→滴水湖 14 站。

## 4. 验证方式与证据

- **数据层**：`node` 直接 import `planModel.js` + 真接口，跑上面三组，逐段核对站数、时长、票价、几何点数。
- **三维层**：临时用 `document.title` 打探针 `DBG seg=N geom=N ents=N prims=N`（验证后删除）。最终一轮读到 `seg=3 geom=3 ents=425 prims=408`。
  425 = 418（18 条线路 + 400 个站点底圈）+ 3 条路径线 + 4 个标记底圈 → 三段线全部画出、4 个标记（起、终、2 个换乘）全部落场景。
- **清理**：退出模式再进再查一次，`ents` 仍是 425，没有累加 → 退出时私有实体全部销毁、无泄漏。
- **回归**：切回「站点拥挤度」正常出图（`400 站 · 客流 51–998`）；全程无 Vite 错误浮层。

## 5. 有意的功能边界

- 分段列表点击不跳转，整条路径一次取景；
- 步行段不在三维里画，只在面板显示距离；
- 反向乘车没有箭头，靠面板文字表达方向；
- 无备选方案（后端只给一条）；
- 换乘站按「站名与本地站点重合」判定，站内长通道（人民广场 1↔2 约 300 m）在几何上表现为一个点。

若要继续做「点分段飞过去 + 该段加亮」，需新增分段级选中状态并操作相机——属于下一步，不影响本版结构。
