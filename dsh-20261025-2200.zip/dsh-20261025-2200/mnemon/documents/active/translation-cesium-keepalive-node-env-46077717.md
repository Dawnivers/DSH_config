---
id: "46077717-b034-4315-a3c1-f04be09fed52"
title: "Translation 智慧地铁：Cesium 场景 KeepAlive 缓存改造（含 NODE_ENV 开发模式陷阱）"
description: "cesiumView 三维场景改用 KeepAlive 缓存的改造方案、代码落点、playwright 实测证据、DEV 调试句柄，以及「从会话里起 vite 会继承 NODE_ENV=production」的环境陷阱与遗留问题（无 onBeforeUnmount 清理、腾讯地图瓦片 400）。"
status: "active"
created_at: "2026-10-07T12:24:58.233Z"
updated_at: "2026-10-07T12:24:58.233Z"
content_hash: "48da6d511379d61d19184cacb85e23baa027acb075b67bcb237f2a10304676bf"
source_paths:
  - "Translation/src/App.vue"
  - "Translation/src/stores/sceneState.js"
  - "Translation/src/views/cesiumView.vue"
  - "Translation/vite.config.js"
session_ids:
  - "46317c48-d132-4db1-b3c1-585888fed1d4"
memory_body_ids:
  []
---

# Translation 智慧地铁：Cesium 场景 KeepAlive 缓存改造

改造日期：2026-10-07。目标：让三维场景在被切走时不销毁、切回时无缝续用（相机位姿、已加载 tileset 全部保留），同时**不让看不见的场景继续烧 GPU**。

相关文档：`d6dc91dd-bff2-4971-897a-5b2fe5bf1580`（Translation 项目启动与接口联调）。

## 1. 改动清单（3 个文件）

| 文件 | 改动 |
|---|---|
| `Translation/src/App.vue` | `<KeepAlive><component :is="sceneComponent" v-if="sceneVisible" /></KeepAlive>` |
| `Translation/src/stores/sceneState.js`（新建） | 提供 `sceneComponent / sceneVisible / showScene / hideScene / toggleScene` |
| `Translation/src/views/cesiumView.vue` | 新增 `onDeactivated`（停渲染循环 + 停时钟）、`onActivated`（`resize()` + 恢复），以及一行 DEV 调试句柄；`onMounted` 主体未动 |

## 2. 两个非显然的设计点（原因记录）

1. **必须是动态组件。** `KeepAlive` 只对「会被切走的动态组件」生效。若写成 `<CesiumView />`，它永不 deactivate，等于没包。因此场景改由 `sceneState.js` 暴露组件句柄，`v-if` 控制显隐。组件用 `shallowRef` 存（配合 `cesiumView.vue` 已有的 `markRaw`），避免无意义的响应式代理开销。
2. **必须自己停渲染。** 缓存期间 DOM 被移出文档，但实例仍活着；Cesium 的 `useDefaultRenderLoop` 是常驻帧循环，不管可见与否都会每帧重画、时钟继续推进。本项目昼夜切换与「外滩流光」全部挂在 `viewer.scene.postRender` 上、**没有 `setInterval`**，所以停掉渲染循环 + 停时钟即可真正全停。

```js
// cesiumView.vue
onDeactivated(() => {
  viewer.clock.shouldAnimate = false;      // 时间轴/动画不再推进
  viewer.useDefaultRenderLoop = false;     // 停掉帧循环
});
onActivated(() => {                        // 首次挂载也会走这里（mounted → activated）
  viewer.resize();                         // 期间窗口尺寸可能变过
  viewer.useDefaultRenderLoop = true;
  viewer.clock.shouldAnimate = true;
});
```

职责划分：`sceneState.js` + `App.vue` 管「何时藏/显示」；`cesiumView.vue` 管「藏时熄火、显示时点火」。未来接路由或 HUD 切换时，只需在切换处调 `hideScene()/showScene()`，不必再改 `cesiumView.vue`。

## 3. 实测证据（playwright 驱动本机真实 Chrome 打开 http://localhost:5173/）

| 阶段 | 观测值 | 含义 |
|---|---|---|
| 运行中 | 0.7 s 渲染 5 帧 | 正常 |
| `hideScene()` | `#cesium-viewer` 在文档中 = false | DOM 被 KeepAlive 移走 |
| 同上 | `useDefaultRenderLoop=false`、`shouldAnimate=false` | 循环与时钟都停 |
| 隐藏 0.9 s | 渲染 **0 帧** | 真的不干活 |
| `showScene()` | DOM 回归，`sameCanvasInstance = true` | ★ 同一 canvas 元素（测试打的 `dataset` 标记仍在）→ **实例复用，未重建** |
| 恢复后 | 循环/时钟 = true，0.9 s 8 帧 | 无缝续跑 |

`sameCanvasInstance` 是决定性证据：组件若被销毁重建，会是全新 canvas，标记不可能保留。

## 4. 环境陷阱：从会话里启动 vite 会退化成生产语义

DSH 宿主进程本身带 `NODE_ENV=production`，会话里直接起 vite 会继承之，服务端注入
`import.meta.env = {"DEV": false, "PROD": true, "MODE": "development"}`。
后果：Vue 开发警告、Vue DevTools、**所有 `import.meta.env.DEV` 分支**（含本次的调试句柄）统统失效——首轮验证失败即由此而来。

- 规避：启动前显式 `$env:NODE_ENV='development'` 再 `node node_modules/vite/bin/vite.js`。
- 验证：抓取服务端吐出的模块产物，确认 `DEV:true` / `PROD:false`。
- 根治（未实施，可选）：在 `vite.config.js` 里按 `command === 'serve'` 强制一次。
- 用户从自己终端跑 `pnpm dev` 不受影响。

## 5. 遗留问题与注意事项

- **`cesiumView.vue` 至今没有 `onBeforeUnmount` 清理（`viewer.destroy()`）。** 有了 KeepAlive 后组件基本不会被销毁，平时不暴露；但一旦被淘汰（如加 `:max`）或移出 KeepAlive，就会泄漏一个 WebGL 上下文。修复待用户确认。
- **腾讯地图底图整层 400**：`addTecenMap()` 里的 `TencentImageryProvider({ style: 4 })` 请求
  `rt0/rt1/rt2.map.gtimg.com/tile?...&styleid=4&scene=0&version=347`（z=0/1/2，共 7 片）全部 400，该层实际是空的；底图现由 `initViewer` 里的 ArcGIS `World_Imagery` 撑着。provider 参数（`style`/版本）待核对。
- **当前没有任何按钮或路由触发隐藏**，功能已就位但默认常显，页面表现与改造前无差别；只能用 DEV 句柄手工验证。
- DEV 调试句柄（生产构建不挂载，不需要可删两处 `if (import.meta.env.DEV)`）：
  ```js
  __scene.toggleScene()   // / hideScene() / showScene()
  __cesiumViewer          // 直接拿 Viewer
  ```
- 验证套路可复用：用内置浏览器/Chrome 控制端点 + playwright 脚本，在真实页面里读 `#cesium-viewer` 是否在文档中、帧计数、`useDefaultRenderLoop`、以及 canvas 上的自定义 `dataset` 标记。
