---
id: "aa89a18c-d8b3-40f6-a526-cb72194162eb"
title: "Dawnivers 个人站「小区分层分户」详情页定稿：真机截图管线、PostGIS 真数与 mediaAspect 字段"
description: "承接 5f0698d1（详情页骨架、community 原为占位）与 d760879a（分层分户项目三服务）：community 详情页正文定稿、五张真机截图的操作式采集与隐私打码、底边裁切与压缩参数、数字概览的真实查询口径、project-data.js 新增 mediaAspect 字段、视频 demo.mp4 自动接入与遗留黑边问题。"
status: "active"
created_at: "2026-10-21T15:14:46.074Z"
updated_at: "2026-10-21T15:14:46.074Z"
content_hash: "d765f8c5b920def58de90ba68fb1ca7315112012e3fed2011e4aabc68e577e6f"
source_paths:
  - "src/project-data.js"
  - "src/project.js"
  - "public/projects/community/overview.jpg"
  - "public/projects/community/build.jpg"
  - "public/projects/community/info.jpg"
  - "public/projects/community/editor.jpg"
  - "public/projects/community/scan.jpg"
session_ids:
  - "b7b89fe6-2226-400a-8033-436a0ff37ffe"
memory_body_ids:
  []
---

# 小区分层分户详情页：内容定稿与素材管线

承接 `5f0698d1-06fe-47fc-8382-060face9e80c`（详情页工程骨架、`project-data.js` 字段契约、`demo.mp4` 自动探测；该文档记录 community 当时只有结构、正文占位）。被介绍的项目本体与三服务启动见 `d760879a-f677-4859-9ad7-ddbdc04a93f3`。
页面：`http://localhost:8091/project.html?id=community`（Express 托管 `dist/`；5173 归智慧地铁，本站用 8091）。在线 Demo：`https://project1.dawnivers.top/`。

## 1. 截图不是示意图：脚本操作真机后截

目标应用实时运行在 `http://localhost:5174/`（分层分户项目）。用无头 Chrome + CDP 写脚本 `%TEMP%\operate\operate.mjs`：点楼栋下拉 → 选「xxx小区xxx楼栋」→ 等数据加载 → `Page.captureScreenshot`。五张对应五个界面：

| 输出图 | 场景 | 操作要点 |
|---|---|---|
| `overview.jpg` | 三维实景底座 | 首页默认视角，倾斜摄影 + 顶部三个入口 |
| `build.jpg` | 楼房分户三步 | `/setBuild`：区域绘制 → 户型切分 → 楼房分层 |
| `info.jpg` | 房户台账 | `/setInfo` 选楼栋后，楼体红色高亮轮廓 + 门牌号/单元/楼层分页表 |
| `editor.jpg` | 业主信息编辑 | `/setInfo` 点首行「编辑信息」，弹出表单 + 头像上传 |
| `scan.jpg` | 三维点选查看 | `/scanInfo` 选楼栋后整栋户型按单元铺彩块（红/绿/紫/黄），点中那户变白 + 信息气泡 |

排查要点：先探针量视口，`{innerH:805, viewer:{h:719}, canvas:{h:712}}` —— Cesium 画布比视口矮。直接按 810 高截图会在底部留黑边，**必须按内容底部 y=719 裁切**。

## 2. 隐私处理（硬要求）

`editor` 弹窗里是库里真实的测试数据（姓名、身份证前六位、手机号）。截图前用脚本把 `input.value` 改写成示例值（`赵示例 / 3501**********1234 / 138****0000`），**不写回数据库、不触发保存**。任何对外截图都不得出现真实证件或号码。

## 3. 压缩与放置

裁掉黑边后统一压到 **1440×720 JPEG（quality 82）**，单张 113–308 KB，放 `public/projects/community/`，页面里写 `/projects/community/<name>.jpg`。

## 4. 新增字段 `mediaAspect`

小区这五张是 2:1（画布比视口矮），16:9 卡片会裁掉顶部工具条。`src/project-data.js` 增加可选字段：

```js
mediaAspect: '2 / 1',   // 截图卡片按该比例渲染；缺省仍是 16:9
```

只作用于声明了的页面，智慧地铁那页保持 16:9。改内容仍然只碰 `project-data.js`、`project.js` 两个文件，渲染逻辑无需分叉。

## 5. 数字概览取真数（PostGIS，勿估）

`buildings = 2`、`units = 18`、`households = 501`，单栋最高 33 层，另计 5 组后端接口 → 页面展示「501 户 / 18 个单元 / 33 层 / 5 组接口」。

踩坑：`building` 表的层数字段是 **`floors_num`**，不是 `floor_num`（后者会报 `字段 "floor_num" 不存在`，HINT 直接提示 `building.floors_num`）。`household` 表关键列：`unit_id / floor_num / min_height / max_height / owner_name / id_card / phone_num / owner_sex / native_place / owner_img / house_type / built_area / orientation / property_type / house_img / house_address`。

## 6. 正文取材于代码，不写套话

- **项目目的**：从"表格说不清 3 栋 1801 在楼的哪一面"切入，三个论点：三维即台账 / 用切分代替手工建模 / 数据落库可查可定位。
- **技术栈**四组，均来自 `package.json` 与源码：Cesium 1.99 + 3D Tiles + ExtrudedPolygon；自研 `DrawTool / polygonCut / SimpleLabel / CameraLimited`；Vue 3.5 + Vite 8 + Pinia + Vue Router；Express 5 + node-postgres + multer + PostgreSQL/PostGIS。
- **五个功能**与上表截图一一对应。核心机制：`SetInfo` 按行 `minHeight + maxHeight` 取中点做高亮/相机定位；`ScanInfo` 用 `viewer.scene.pick` + `getGeometryInstanceAttributes` 改色并在 `pickPosition` 弹 `SimpleLabel`，靠 `lastPick` 复位上一次颜色（不重置会因引用失效抛异常）。

## 7. 视频位与遗留

- 视频仍是 `VIDEO · COMING SOON` 占位；把录屏命名 `demo.mp4` 丢进 `public/projects/community/` 即自动换成播放器，无需改代码。建议录 20–30 秒：圈楼 → 切层 → 点选查户。
- **遗留黑边**：应用 `#cesium-viewer` 高度约 720px 撑不满视口（窗口 810px）。一行 CSS `height: 100vh` 可修，属改动被介绍项目的源码，需另行确认后再动；当前仅在截图侧裁切规避。

## 8. 验证

`node --check` + `npm run build` 通过，`dist/projects/community/` 五张图产出；实测首屏、技术栈、五张功能卡（含弹窗图）、视频位、页脚 CTA 排版正常，2:1 图不再被裁。
