---
id: "94fbdaf2-92cd-4413-97b7-b6d6fee5405e"
title: "智慧地铁上线版：HTTP/1.1 唯一来源定位（ArcGIS 底图）与 imageryProvider:false 改法、强制 HTTPS/ALPN 复核"
description: "逐域名 ALPN 探测结论：project2/translationbe/gtimg/googlecnapps 均 h2+TLS1.3，唯一 http/1.1 来自 server.arcgisonline.com（上游不支持 h2）；据源码 CesiumWidget.js 合法改为 imageryProvider:false 并重新构建（入口 index-BK-lbVRc.js）后的指纹校验；同时更正旧结论（证书 CN=project2.dawnivers.top 有效至 2027-01-19、ALPN=h2、前后端强制 HTTPS 已生效返回 301）。"
status: "active"
created_at: "2026-10-21T12:00:37.126Z"
updated_at: "2026-10-21T12:00:37.126Z"
content_hash: "8ed9cf252672542c6ae0617d90981fe1549528986f7828b53abd2b1ea0248700"
source_paths:
  - "src/cesiumTools/sceneManager.js"
  - "src/views/cesiumView.vue"
  - ".env.local"
  - "node_modules/cesium/Source/Widgets/CesiumWidget/CesiumWidget.js"
session_ids:
  - "74ebaaf0-3acd-40db-9ab6-cde5d3b3559b"
memory_body_ids:
  []
---

# 智慧地铁上线版：HTTP/1.1 来源定位与 ArcGIS 底图移除

承接文档 `b19f41c5-ad92-4a44-b144-984d68cf63ea`（L14 上线验收 / SPA 回退 / HTTPS 判定法）与 `664f423a-80ba-4ada-9bb2-37806b63ec04`（反代剥前缀定案）。本文只补 2026-10-21 这次「前后端都开了强制 HTTPS 为何仍见 http/1.1」的实测结论与修复，不重复两文已有矩阵。

## 1. 结论：唯一 1.1 来源是第三方底图，与 nginx 无关

逐域名真实 TLS 握手（ALPN 协商，而非看 curl 的 `HTTP/1.1` 字样）：

| 域名 | 协商 | 说明 |
|---|---|---|
| `project2.dawnivers.top` | **h2** · TLS1.3 | 前端站点 |
| `translationbe.dawnivers.top` | **h2** · TLS1.3 | 后端 |
| `dawnivers.top` | h2 | 主站 |
| `p0.map.gtimg.com` | h2 | 腾讯影像 |
| `gac-geo.googlecnapps.cn` | h2 | 备用底图 |
| **`server.arcgisonline.com`** | **http/1.1** · TLS1.3 | ← 唯一来源，上游服务端不支持 h2，改不了 |

强制 HTTPS 生效证据：`http://project2…/ → 301 https://project2.dawnivers.top/`，`http://translationbe…/getLine → 301`。

**旧结论更正**（`664f423a` 第 5 节“证书不覆盖子域”、`b19f41c5` “未开强制 HTTPS”）：
带 SNI 打 `project2.dawnivers.top:443` 拿到的是 `CN=project2.dawnivers.top`（LiteSSL / TrustAsia，2027-01-19 到期），此前用 IP 探测命中的是默认站证书 `CN=dawnivers.top`，属误判；ALPN 直接返回 `h2`。

## 2. 陷阱：Windows 自带 curl 的 `HTTP/1.1` 不代表服务端

`curl 8.21.0 (Windows) … Schannel`，`Features:` 行里**没有 HTTP2**，所以它永远只谈 1.1。判断服务端能力必须用 ALPN 协商结果或浏览器 DevTools 的 Protocol 列，不能用本机 curl 的协议行。

## 3. 具体发请求的文件与改法

`src/cesiumTools/sceneManager.js`（`initViewer` 的默认底图）：

```js
// 改前
imageryProvider: new Cesium.UrlTemplateImageryProvider({
  url: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
}),
// 改后
imageryProvider: false,   // 官方支持：不添加任何默认底图，由腾讯图层顶上
```

合法性依据在依赖源码 `node_modules/cesium/Source/Widgets/CesiumWidget/CesiumWidget.js`：类型注释 `ImageryProvider | false`，第 126 行写明传 `false` 则 “no imagery provider will be added”，第 350 行 `if (imageryProvider !== false)` 才 addImageryProvider —— 因此不会偷偷回落到 Cesium Ion。

动机：`cesiumView.vue` 随后调用 `addTecenMap(viewer)` 把腾讯影像压在最上层，ArcGIS 整层不可见却仍逐块下载 → 底图请求翻倍，且一半是海外 h1.1（单域 6 并发），拖慢首屏。

## 4. 重新构建后的产物指纹（判断改没改到位）

- 新入口：`dist/index.html → index-BK-lbVRc.js`（516,052 B），构建 2.02s，`compress-dist` 174 文件 8.04MB → gzip 2.64MB / brotli 2.10MB。
- bundle 计数：`arcgisonline` **0**、`World_Imagery` **0**、`gtimg` **2**（腾讯图层仍在）、`tileset-L` 1。
- LOD 默认值仍在：`…get(\`lod\`)??\`14\`??\`\`` —— `.env.local` 的 `VITE_TILE_LOD=14` 已内联，重新构建不会丢。

**取舍代价**：失去 ArcGIS 兜底，腾讯图层加载失败即无底图。需要保险时可在其 `readyPromise` reject 时动态加回 ArcGIS。

## 5. 复验方法（可复用）

1. DevTools → Network → 右键表头勾 **Protocol** → 按列排序：项目资源/瓦片/接口/gtimg 应全为 `h2`，`server.arcgisonline.com` 行应整体消失。
2. 单条请求 → Headers 底部 `Protocol:` 亦可见。
3. 服务端能力判定统一用 ALPN 探测，不要用 Windows curl 的协议行；证书问题必须带 SNI 打站点域名而非裸 IP。
