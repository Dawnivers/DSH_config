---
id: "922f11cb-d052-4645-b9c0-e15409fa38f6"
title: "Dawnivers 个人主页通读：数据驱动结构、构建/留言链路与 9 个待修问题"
description: "dawnvers-portfolio（dawnivers.top 根站）的架构地图：Vite + 手写 HTML/原生 JS + Express 留言板，内容集中在 script.js 数组；附首屏激活态冲突、dist 资源路径错位、文档筛选/下载占位、Tailwind CDN 等 9 项已核实问题与修复优先级。"
status: "active"
created_at: "2026-10-21T13:56:40.722Z"
updated_at: "2026-10-21T13:56:40.722Z"
content_hash: "841157c639e46f599018629f7a6cdf9a9a858e0e621016893cd4d7b8e515a666"
source_paths:
  - "index.html"
  - "src/script.js"
  - "src/style.css"
  - "server.js"
  - "vite.config.js"
  - "package.json"
  - ".gitignore"
session_ids:
  - "12a548b6-3ec3-4fd3-9077-b59b8f3a9608"
memory_body_ids:
  []
---

# Dawnivers 个人主页（dawnvers-portfolio）代码通读

排查对象：`D:\WebGIS\web三维开发\个人网站`；线上根站 `https://dawnivers.top/`。
本轮**只读**，未改动任何文件。站点是「手写 HTML + 原生 JS 的数据驱动单页」，不是框架应用；Vite 仅打包，Express 仅提供留言板。

相关文档：`933d3b7b-396a-4f92-a8ff-62bd719670a8`（dawnivers.top 根站即本个人主页，其域名/服务器拓扑见该文）。

## 1. 技术栈与运行方式

| 部分 | 实现 |
|---|---|
| 页面 | `index.html` 单文件 1332 行；Tailwind 走 CDN `cdn.tailwindcss.com`，另有自定义 `frost` 色板 |
| 交互 | `src/script.js` 1004 行，纯 IIFE + DOM，无框架 |
| 样式 | `src/style.css` 810 行：`clip-path` 斜切、毛玻璃、13 段 `@keyframes`、移动端重排 |
| 打包 | Vite 5：`npm run dev` / `build` / `preview` |
| 后端 | `server.js` Express 8091：`GET/POST /api/messages`，写 `messages.json`，并托管 `dist/` |
| 代理 | `vite.config.js` 把 `/api` 转发到 `http://localhost:8091` |

## 2. 文件与内容组织

```
个人网站/
├─ index.html       顶栏+留言板 / 5 个斜切标签 / 5 个 tab-pane / 备案页脚
├─ src/script.js    ①粒子网格画布(~360行) ②标签切换+三角旋转 ③留言板 ④三组数据渲染
├─ src/style.css    视觉系统
├─ public/          Dawnivers.png 头像、transport/fenceng/amap 项目图、公安备案图标
├─ server.js        8091 留言 API
├─ vite.config.js   /api → 8091
├─ messages.json    运行时留言存储（已 gitignore）
└─ dist/            构建产物
```

内容集中在 `script.js` 末尾的数组，改文案不必碰 HTML：

- `projects`（3 条）：`title / description / badge / tags / accent(sky|indigo|teal) / icon / img / url`
- `docs`（4 条）：`version / category / fileSize / updated / title / description / download / href`
- `education`（1 条）
- 技能气泡是**写死在 HTML 的 13 个 `.skill-bubble`**（Cesium、WebGL、Vue、OpenLayers、PostGIS、QGIS、Nginx、Linux 等），新增技能需复制 DOM，未数据化。

`.gitignore` 忽略 `node_modules/`、`dist/`、`messages.json`、`*.log`、`.DS_Store`。

## 3. 已核实问题（按影响排序）

1. **首屏激活态自相矛盾（明确源码 bug）**：HTML 中 `#view-gallery` 为 `block`、04 标签带 `glass-tab-active`；JS 中 `currentActiveId = 'skills'`、三角旋转为 144°(skills)。结果首屏显示文档页，而点「核心技能」因 `targetId === currentActiveId` 直接 return——必须先点别的标签才能进技能页。
2. **本地源码与线上不同步**：线上首屏是 projects（非 docs），说明部署产物不是当前源码构建。任何「改完即上线」的判断都要先对齐版本。
3. **`dist` 资源路径错位**：`dist/index.html` 引用 `/assets/index--tfLPA2T.js`，但 `index--tfLPA2T.js` 与 `index-B7ZDjJnL.css` 实际位于 `dist/` 根目录；直接 serve 会 404。需重建并核对产物布局。
4. **文档页统计与筛选失真**：右上「已归档 4 部白皮书」、筛选按钮「全部文档 (5)」、实际仅 4 条；筛选按钮未绑定逻辑，点击无反应。
5. **文档下载全是占位**：`href="#"` + `download` 指向不存在的文件，点击后 URL 变为 `/`，等于把访客踢回首页。
6. **项目 3（高德地图）`url: '#'`**：线上实测链接目标为 `/`，同样回首页。
7. **邮箱文案与链接不一致**：页面显示 QQ 邮箱，`href` 却是 `mailto:hello@dawnvers.design`（联系转化会丢信）。
8. **Tailwind 走 CDN + 自定义尺寸类风险**：生产首屏依赖 CDN 脚本解析，断网/被墙即样式全失；且 `w-18/22/25/26/30/34/38` 不在 Tailwind v3 默认 spacing 表，技能气泡尺寸疑似未生效。**未验证**：截图时浏览器被用户接管（USER_CONTROL），需补一次截图确认。
9. **工程与运行环境**：有 `.gitignore` 但无 `.git`，改动无法回滚；本机 5173 被「智慧地铁」项目占用，本站 dev 需 `--port 5174`；留言接口无长度/频率限制。

## 4. 建议修复顺序

1. 统一首屏激活态（HTML 的 `block`/`glass-tab-active` 与 JS 的 `currentActiveId`/三角角度取同一来源）。
2. 重新干净 build，修正 `dist` 资源路径并验证；对齐线上版本后再谈发布。
3. 清理占位链接：文档 `href`/`download`、项目 3 的 `url`、邮箱 `mailto`。
4. 文档数量文案改为从 `docs.length` 计算；筛选要么接逻辑，要么先移除。
5. 工程化：Tailwind 从 CDN 换本地构建、初始化 `.git`、技能气泡抽成数组。
6. 留言接口补长度上限与简单限流。

## 5. 后续可选方向

- 加项目/文档：按现有卡片字段补数据，并顺手修占位链接；
- 修 bug：首屏状态 → 重建 dist → 文档筛选；
- 重构：Tailwind 本地化、气泡数据化、git 初始化。
