---
id: "78405cec-fa03-4c43-9945-7371aa3f5bee"
title: "列车漫游撤销「彻底解耦」：回退到 viewer.clock + path 拖尾版本（含从 zstd 会话日志回放恢复旧代码的手法）"
description: "/realtime 列车漫游由 CallbackProperty 自推进版本回退为 clock 驱动的 SampledPositionProperty + Entity.path 拖尾；记录回退范围（面板沿用新版、只补 resetTimeLine）、scale 不回退的取舍、通过 zstandard 解压 session.v4.jsonl.zstd 重放 write/edit 找回旧代码的两处残缺点、验证矩阵、残留抖动与 GLB 重载代价，并声明本文作废 9c4277c1 的「当前实现」结论。"
status: "active"
created_at: "2026-10-19T02:45:20.165Z"
updated_at: "2026-10-19T02:45:20.165Z"
content_hash: "93180acd2980fa745052ee6aa391d82120fef6b15dc08f7cd87424a9fc29a919"
source_paths:
  - "Translation/src/cesiumTools/lineAndpoints/train/trainRoam.js"
  - "Translation/src/components/bottom/RealtimePanel/RealtimePanel.vue"
  - "Translation/src/main.js"
session_ids:
  - "aeb8e9f9-d2ec-4817-918c-05800f571619"
memory_body_ids:
  []
---

# 列车漫游回退（2026-10-19）

源文件：`Translation/src/cesiumTools/lineAndpoints/train/trainRoam.js`（671 行）、
`Translation/src/components/bottom/RealtimePanel/RealtimePanel.vue`、`Translation/src/main.js`（仅临时排障钩子，已还原）。

本动作把 `/realtime` 的列车漫游从「**彻底解耦**」版本退回到解耦之前的实现。
**`9c4277c1` 描述的是被撤掉的那一版**，读它时必须先看本文——它已不是当前实现。

## 1. 现在的实现（回退目标）

| 维度 | 回退后的写法 | 对应代码位置 |
|---|---|---|
| 位置 | `SampledPositionProperty.getValue(clock.currentTime)`，用 `clone()` 后外传 | `trainRoam.js` 位置求值段 |
| 拖尾 | `Entity.path`：`leadTime: 0`、`trailTime = TRAIL_METERS / speed` | 实体配置 |
| 时间推进 | 配 `clock`：`multiplier = total / WALL_SECONDS` + `ClockRange.LOOP_STOP`，`clock.onTick` 里 `handleTick` | — |
| 播放/暂停 | `clock.shouldAnimate = true / false`，并记 `this.intent` | `play()` / `pause()` |
| 重播 | `restart()` = `intent='playing'` + `jumpTo(startOffset)` + 开表 | — |
| 拖进度条 | `seek(t)` 只改 `clock.currentTime`；`beginScrub()` 停表、`endScrub()` 按 `intent` 决定是否续播 | 详见下文「两种挪时间」 |
| 点站点换起跑点 | `jumpTo(t)` 同时挪 `clock.startTime` 与 `this.startOffset`，`this.startTime` **保持不动** | — |

`seek` 与 `jumpTo` 的区分被刻意保留并在注释里写明：
`jumpTo` 改「从哪开始跑」（连带挪 `clock.startTime`，于是循环回到新起点）；
`seek` 只是「看时间表第 t 秒」（循环区间不动）。
两者都不重建实体，所以拖动是零成本的；`this.startTime` 不能跟着挪，否则 `handleTick` 里 `t = currentTime − startTime` 丢掉偏移、高亮会跳回第一站。

## 2. 面板沿用新版，只补一处

`RealtimePanel.vue` **没有跟着回退**：新旧两版对外接口逐一都能对上
（`load / seek / beginScrub / endScrub / jumpTo / restart / play / pause / destroy / onUpdate / schedule / startTime`），
所以面板保留当时最新的版本，只补了一行：

```js
// onBeforeUnmount
resetTimeLine(viewer);
```

原因：漫游又把时间轴窗口改成「几十秒跑完本线」，退出栏目不还原的话其它栏目的昼夜光照 / 时间条会停住。
这是**回退版本必须配套**的一步——解耦版因为不写 clock，当时反而删掉了它。

## 3. 没有回退的部分

- 热力图、站点管理、`QueryModePanel` 等解耦之后才做的功能，全部原样保留。
- `scale` 保留当前值 **5**（旧快照是 1）：那属于视觉调参，形式上在旧文件里、实质上不该跟着回退。
- `trainSchedule.js` 未动（一直是纯采样表）。

## 4. 旧代码是「从会话日志里回放」出来的

项目**没有 git**，所以旧代码不是 checkout 出来的，而是从 DSH 会话记录重建：

1. `~/.dsh/sessions/*/session.v4.jsonl.zstd`；
2. 用 Python `zstandard` 解压，逐行 parse；
3. 按时间顺序重放所有对 `trainRoam.js` 的 `write` / `edit` 操作；
4. 取「首次出现 `this.positionAt(this.elapsed`（解耦标志）」**之前**的那份快照（672 行），
   再验证它同时含有 `SampledPositionProperty` 与 `path.leadTime/trailTime`。

**这类重建天然不完整**，实际踩到两处，都已按记录原文补齐：

| 症状 | 成因 |
|---|---|
| `VUE-ERR watcher callback: startTime is not defined` | 回放丢了 `const startTime = Cesium.JulianDate.fromDate(new Date());` |
| `sampledProperty is not defined` | 历史上「`sampled` 改名 `sampledProperty`」只改了一半的残留被合并进来；改成声明与 `addSample` 统一 |

教训：**再遇到「缺变量 / 未定义」优先怀疑是回放残缺，而不是逻辑错误**；
定位手段是临时在 `main.js` 挂 Vue 错误钩子把 `VUE-ERR` 写进 `document.title`（浏览器里立刻可见），排完必须还原 `main.js`。

## 5. 验证结果（浏览器脚本实测）

| 场景 | 结果 |
|---|---|
| 进入 `/realtime` | 面板正常，`1号线 · 3/28 · 正向`，进度在走 |
| 反向 `⇄` | 站点序列翻转为 `莘庄 → 富锦路`，标签显示「反向」 |
| 暂停 `❚❚` | 停在 `2/28` 不再前进，按钮变 `▶` |
| 重播 `↺` | 回到播放态并推进 |
| 切到首页再回来 | 无报错（`resetTimeLine` 生效），再次进入能正常重挂 |
| 进度条**拖动** | ❌ 无法用脚本模拟（需按住拖），留给人工确认 |

## 6. 代价与残留问题（别误判为回退引入的新 bug）

- 帧率仍约 **24 FPS**，顿挫感与解耦前一致：瓶颈是侧栏 + 站点标签 + 模型渲染负担，与本次回退无关。
  缓解方向是「`/realtime` 收起侧栏」（此前讨论的 A 方案），尚未实施。
- 解耦版当初是为了让「列车时间轴 = 面板进度条，Cesium 时间轴 = 昼夜」互不干扰；回退后这个诉求重新存在，
  只能靠 `resetTimeLine(viewer)` 兜住退出路径。若要再解耦一次，`9c4277c1` 第 3 节记录的
  `Cartesian3.lerp` 缺 `result` 会**整条停掉渲染循环**的坑仍然成立。
- 备份留在源码旁：`trainRoam.js.bak-20261019`、`RealtimePanel.vue.bak-20261019`（想换回解耦版直接用它们）。

## 7. 相关文档

- `9c4277c1-2ddd-42de-8a73-fff02d7651cc` —— 被本文撤掉的「彻底解耦」实现；其 `Cartesian3.lerp` 坑与解耦前后对照仍有参考价值，但「当前实现」结论作废。
- `7f1a6f08-9d0f-4d25-adfe-c436ac157c88` —— `path.leadTime/trailTime`、`clockRange` 必显式设、`destroy` 顺序；回退后重新成为现行依据。
- `3fe1947f-509c-4def-b914-757bbb86722b` —— `handleTick` 五段职责、朝向不能用 `VelocityOrientationProperty`；回退后仍然有效。
