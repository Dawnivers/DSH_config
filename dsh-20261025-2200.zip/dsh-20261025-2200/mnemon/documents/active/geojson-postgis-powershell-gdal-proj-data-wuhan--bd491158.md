---
id: "bd491158-552e-4d9e-b899-a8fff4453827"
title: "GeoJSON 导入 PostGIS 实测链路：PowerShell 引号、精简版 GDAL、PROJ_DATA 与建库顺序（武汉 wuhan.json）"
description: "2026-10-23 实测：用 ogr2ogr 把武汉区划 GeoJSON 导入本机 PostGIS(gis_demo.admin_area) 连续踩的四个坑与修法，及 EPSG:4326/3857 取舍结论；补充 21 天计划的 Day 1 实操。"
status: "active"
created_at: "2026-10-23T03:24:59.765Z"
updated_at: "2026-10-23T03:24:59.765Z"
content_hash: "9f85dc3db8ac4ba6f7f547502da38378e197a790dce6661b4184aace353e6367"
source_paths:
  - "gis-prep/学习计划.md"
session_ids:
  - "0f1e652d-23ec-4620-aed1-06cecb17163b"
memory_body_ids:
  []
---

# GeoJSON → PostGIS 实测链路（本机环境，2026-10-23）

本机（Windows + PowerShell 7.6.7）把 `wuhan.json`（武汉区划 GeoJSON，期望 13 个区）灌进 `gis_demo.admin_area` 的实操记录。是 21 天计划 W0/Day 1 的第一步，计划本体见 doc `90391f9a-6af3-43b5-bf4d-7fe334b99d59`。

数据文件（工作区外）：
`D:\WebGIS\web二维开发\openlayers服务平台开发\data\wuhan.json`
（注意本机同时存在 `web二维开发` 与 `web三维开发` 两个目录，别走错。）

## 1. 按顺序踩到的四个坑

| # | 报错 | 真实原因 | 修法 |
|---|---|---|---|
| 1 | `ERROR 1: Unable to open datasource `'` + 一大串驱动列表 | PowerShell 里路径被写成 `""D:\...\wuhan.json""`（两层双引号），外部程序收到的是**带引号字符的路径**，并把它打印成孤零零一个 `'` | 无空格路径裸写，或只套一层**单引号**；或先 `Set-Location` 到 data 目录用相对路径 |
| 2 | `ERROR 1: Unable to find driver 'PostgreSQL'` | `D:\PostgreSQL18.4\data\18\bin\ogr2ogr.exe` 是 PostGIS 附带的**精简 GDAL**，驱动列表中根本没有 PostgreSQL/PostGIS（只有 Shapefile/GeoJSON/GPKG 等） | 改用 `D:\QGIS\bin\ogr2ogr.exe` |
| 3 | `PROJ: proj_create: no database context specified` + `Cannot parse CRS http://...`（成对刷屏，但驱动列表仍能打印出 `PostgreSQL -vector- (rw+u)`） | QGIS 的 ogr2ogr 单跑时找不到 `proj.db`（实际在 `D:\QGIS\share\proj\proj.db`） | `$env:PROJ_DATA='D:\QGIS\share\proj'`；永久生效用 `[Environment]::SetEnvironmentVariable('PROJ_DATA','D:\QGIS\share\proj','User')` 并重开终端 |
| 4 | `PQconnectdb failed ... 数据库 "gis_demo" 不存在` + `PostgreSQL driver doesn't currently support database creation` | ogr2ogr **不会建库**，只往已存在的库写 | 先 `psql -c "CREATE DATABASE gis_demo;"`，再 `psql -d gis_demo -c "CREATE EXTENSION IF NOT EXISTS postgis;"`，最后才 ogr2ogr |

判读要点：坑 3 那堆 PROJ 噪音**不代表驱动缺失**，只要输出里有 `PostgreSQL -vector- (rw+u)` 就说明可读可写可更新。坑 4 能拿到中文数据库报错本身就是证据——连接链路已通。

## 2. 可用的完整命令链

```powershell
$env:PGPASSWORD='<postgres 密码>'          # 建议放 .env，别写死在命令/聊天里
$psql='D:\PostgreSQL18.4\data\18\bin\psql.exe'
$ogr ='D:\QGIS\bin\ogr2ogr.exe'
$json='D:\WebGIS\web二维开发\openlayers服务平台开发\data\wuhan.json'
$env:PROJ_DATA='D:\QGIS\share\proj'

& $psql -U postgres -h localhost -c "CREATE DATABASE gis_demo;"
& $psql -U postgres -h localhost -d gis_demo -c "CREATE EXTENSION IF NOT EXISTS postgis;"
& $ogr -f PostgreSQL "PG:host=localhost port=5432 dbname=gis_demo user=postgres password=$env:PGPASSWORD" `
  $json -nln admin_area -nlt PROMOTE_TO_MULTI `
  -lco GEOMETRY_NAME=geom -lco FID=gid -lco PRECISION=NO

& $psql -U postgres -h localhost -d gis_demo `
  -c "SELECT count(*) AS 区数, ST_SRID(geom) AS srid FROM admin_area GROUP BY 2;"
```

- 顺序不可乱：**建库 → 装扩展 → 导数据 → 验数**。缺扩展会报 `type "geometry" does not exist`。
- psql/createdb 都要带 `-h localhost`，强制走密码认证；省略会尝试 Windows/peer 认证并失败。
- `-nlt PROMOTE_TO_MULTI`：源数据里 Polygon 与 MultiPolygon 混排，不统一类型会导入失败。
- 预期验收：返回 `13 | 4326`，并在 QGIS 里与 OSM 底图叠加确认市界压在长江两岸。
- 表已存在时报 `already exists`：`DROP TABLE IF EXISTS admin_area;` 或加 `-overwrite`；中文乱码则试 `-oo ENCODING=UTF-8`（GBK 源则 GBK）。

## 3. 备选方案（放弃 GDAL 时）

Python + `psycopg2`：`json.load(..., encoding='utf-8-sig')` 读，逐 feature `INSERT ... ST_Multi(ST_GeomFromGeoJSON(%s))` 到 `geom geometry(MultiPolygon,4326)`，最后建 `USING GIST (geom)` 索引。完全绕开 GDAL/PROJ 环境问题，且练到的 `ST_GeomFromGeoJSON`/`ST_Multi`/类型声明对面试更值钱。
注意 doc `c80af886-b5d3-4d9b-94b2-473cab3df58a` 记录过：本机另一套 conda geo 环境的 GDAL 也**无 PostgreSQL 驱动**，那条路同样需要 psycopg2。

## 4. EPSG:4326 与 3857 的取舍（Day 1 的问答结论）

- `4326` = WGS84 经纬度，单位**度**；`3857` = Web 墨卡托，单位**米**（网页地图）；`4490` CGCS2000 国内法定。
- `ST_SRID` 只是几何**自称**的坐标系，PostGIS 不校验数值。米制坐标塞进 4326 字段不会报错，但 `ST_DWithin(geom, pt, 1000)` 会被理解为「1000 度」，返回整张表。
- 武汉纬度约 30.5：1° 经度 ≈ 96 km、1° 纬度 ≈ 111 km——**同一度在不同方向不等长**，这是不能拿 4326 算距离的根本原因。
- 项目约定：**存 4326，算距离/格网 3857（或 geography 类型），导出给前端 4326**；OpenLayers `View` 是 3857，传 4326 会自动转换。
- 隐患：若源数据实为高德 GCJ-02，导入后仍会标成 4326——「声明是 4326 不等于真的是 4326」，用 QGIS 叠底图验证。

## 5. 顺带的环境事实

- 本机 `JAVA_HOME` 为空，`java` 走 Oracle javapath；装 GeoServer/Maven 前设 `JAVA_HOME=D:\java`。
- 用户明确偏好：**软件一律装 D 盘**。
- 用户在聊天中明文贴出过 PostgreSQL 密码；应迁到 `.env` 并用变量引用，项目若上 GitHub 先改密码。
