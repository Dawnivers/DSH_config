---
id: "b0f8d53f-e3a8-411f-8529-74a6b562ee81"
title: "首页复位相机（flyToHome + 路由 watch）与可拖动进度条（seek/scrub）：两个易踩的时序与样式坑"
description: "点击底部「首页」把相机飞回项目默认视角（复用 DEFAULT_VIEW，含解绑 lookAtTransform 与 flush:'post' 的必要性），以及 /realtime 进度条改为可点可拖（seek 只挪 currentTime、beginScrub/endScrub、3px 外观不变的隐形命中区）；含实测数据。"
status: "active"
created_at: "2026-10-17T15:21:17.524Z"
updated_at: "2026-10-17T15:21:17.524Z"
content_hash: "4bdc42f25c4500c4c6ec668ac7a245828915524f0465bc4b6a56662a13c6e739"
source_paths:
  - "Translation/src/cesiumTools/sceneManager.js"
  - "Translation/src/views/cesiumView.vue"
  - "Translation/src/cesiumTools/lineAndpoints/train/trainRoam.js"
  - "Translation/src/components/bottom/RealtimePanel/RealtimePanel.vue"
  - "Translation/src/components/screenUI/foot.vue"
session_ids:
  - "151fa69f-0089-4dec-8118-6b57759e0fca"
memory_body_ids:
  []
---

# 首页复位相机 + 可拖动进度条

实现日期：2026-10-17。项目根 `D:\WebGIS\web三维开发\智慧地铁项目`，前端目录 `Translation/`。

需求（用户原话）：
1. 「点击首页时，相机跳转到首次进入项目时候的位置和姿态」
2. 「将地铁站点这个进度条也改成可以拖动的时间条，但是样式不要变化」

前置文档（本文不重复其内容）：
- `da3984e4-773d-4e58-a590-a5c7ac0ade40`：`DEFAULT_VIEW` / `applyDefaultView` 的固化来历与参数。
- `8de40912-656f-46d4-adae-7a63db262ae3`：点站点起跑的 `jumpTo` / `startOffset` 语义。

## 1. 首页复位：不新造视角，复用 DEFAULT_VIEW

`Translation/src/cesiumTools/sceneManager.js` 里新增 `flyToHome(viewer, duration = 1.2)`，并把 `applyDefaultView` 与它共用的参数拼装抽成 `defaultViewOptions()`，两者读同一份 `DEFAULT_VIEW`——**进项目和回首页永远是同一个姿态**，改数字两处一起变。

```js
export const flyToHome = (viewer, duration = 1.2) => {
  viewer.trackedEntity = undefined;
  viewer.camera.lookAtTransform(Cesium.Matrix4.IDENTITY); // ← 关键，先解绑
  const options = defaultViewOptions();
  duration > 0
    ? viewer.camera.flyTo({ ...options, duration })
    : viewer.camera.setView(options);   // duration=0 即瞬移
};
```

调用方是 viewer 的属主 `Translation/src/views/cesiumView.vue`：

```js
watch(() => route.path, (path, previous) => {
  if (path === '/' && previous !== '/') flyToHome(viewer, 1.2);
}, { flush: 'post' });
```

（底部按钮本身在 `components/screenUI/foot.vue`，它只负责 `router.push('/')`，不碰相机。）

### 两个必须处理的坑

1. **相机被 `lookAtTransform` 绑在局部坐标系里。**
   实时轨迹的跟车视角进入后，`camera.position` 只有 71 m 量级（局部坐标，不是地心坐标）。不解绑直接 flyTo，落点会算到错误位置。顺序是 `trackedEntity = undefined` → `lookAtTransform(Matrix4.IDENTITY)` → `flyTo`。
2. **watch 必须 `flush: 'post'`。**
   旧栏目的 `onBeforeUnmount` 会调 `roam.destroy()`，而 destroy 里同样执行 `lookAtTransform(IDENTITY)`；**`lookAtTransform` 会取消正在进行的相机飞行**。若 watch 在卸载之前触发，飞行刚开始就被打断。`post` 保证它跑在整个 patch 之后。
   另加 `previous !== '/'`：首次进项目不重复飞（`applyDefaultView` 已摆好，再飞会在确认弹窗后面白闪一下）。

### 实测（从 `/realtime` 跟车视角点「首页 CORE」）

| 时刻 | 经度 | 纬度 | 高度 | heading | pitch |
|---|---|---|---|---|---|
| 栏目内 | 121.422216 | 31.381627 | 71.2 | 35.0° | −22.0° |
| 点击后 0.6 s（飞行中） | 121.425473 | 31.371500 | 4553.5 | 43.38° | −24.03° |
| 飞行结束 | 121.458201 | 31.270543 | 4821.8 | 131.1964° | −45.3461° |

落地值与 `DEFAULT_VIEW` 逐位一致，零 pageerror。可调项只有 `flyToHome(viewer, 1.2)` 的时长（改 0 = 瞬移）。

注意：`sceneManager.js` 里另有一个更老的 `flyToDefaultView`（113.95, 30.19, 34000 的占位俯瞰视角），回首页**不要**用它。

## 2. 进度条可拖动：seek 只挪 currentTime

`Translation/src/cesiumTools/lineAndpoints/train/trainRoam.js` 新增三个方法：

```js
seek(t) {                    // 拖进度条：只挪 currentTime
  clock.currentTime = startTime + clamp(t, 0, total);
}
beginScrub() { clock.shouldAnimate = false; }               // 拖动时先停表
endScrub()   { clock.shouldAnimate = intent !== 'paused'; } // 松手按原播放意图恢复
```

与 `8de40912` 的 `jumpTo` 是两种语义，**不要混用**：

| | 改什么 | 影响 |
|---|---|---|
| 点站点 `jumpTo(t)` | `clock.startTime` + `currentTime` | 改了**起跑点**，循环回到这里 |
| 拖进度条 `seek(t)` | 只改 `currentTime` | 只是**看某一时刻**，循环区间不变 |

因此「先点第 20 站起跑、再往回拖」松手后循环仍回到第 20 站那个折点，而不是首站。
拖动时先停表是必须的：时钟每帧都在推进 `currentTime`，不停表会和拖动抢。

### 面板侧换算

`Translation/src/components/bottom/RealtimePanel/RealtimePanel.vue`：

```js
const rect = progressRef.value.getBoundingClientRect();
ratio = (event.clientX - rect.left) / rect.width;   // 夹到 0~1
roam.seek(ratio * roam.schedule.total);
```

HUD 整层被 CSS 缩放过，但 `clientX` 与 `getBoundingClientRect` 都是屏幕像素，相除不受缩放影响，无需关心 hud 的 scale。

### 3px 外观不变，靠隐形命中区

`.rp-progress` 可见高度仍是 3px，但鼠标命中区上下各撑 5px：

```css
.rp-progress { height: 3px; cursor: ew-resize; }
.rp-progress::after { top: -5px; bottom: -5px; }
.rp-progress-clip { position: absolute; inset: 0; overflow: hidden; }
```

原来 `overflow: hidden` 挂在 `.rp-progress` 上，会把扩出来的命中区一起裁掉；把裁切搬到内层 `.rp-progress-clip` 后，bar 的渐变与 `box-shadow` 发光仍被裁在 3px 内，**观感与改动前逐像素一致**，外层才能撑到 13px 命中高度。

### 实测

| 时刻 | 进度条宽度 | 当前站 | 已过站 | shouldAnimate |
|---|---|---|---|---|
| 拖动前 | 2.83% | 1 富锦路 | 0 | true |
| 拖到 60% | 59.98% | 17 一大会址·黄陂南路 | 16 | false（拖动中停表） |
| 松手 0.4 s | 60.11%（继续走） | 17 一大会址·黄陂南路 | 16 | true（自动续播） |
| 先暂停再拖到 35% | 34.96% | 10 上海马戏城 | 9 | false（保持暂停） |

元素高度全程 3.0px，零 pageerror。列车的三维位置、站名高亮、已过站数、气泡都是 `clock.currentTime` 的纯函数，拖动时自动跟随，无需额外同步代码。

## 3. 待用户确认的语义分歧

点第 20 站（衡山路）时高亮落在第 19 站（常熟路）、已过站 18：车在「常熟路—衡山路」中间，尚未到衡山路。若要求「点哪站高亮哪站」，需改为从该站**到站时刻**起跑（车停在站上）——见 `8de40912` 第 6 节。
