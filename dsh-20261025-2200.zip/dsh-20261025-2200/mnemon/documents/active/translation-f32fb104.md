---
id: "f32fb104-6ca4-4a69-bf9d-c06564676cb2"
title: "Translation 智慧地铁：站点面板「站控措施」模式（模拟后端、措施气泡、共用站点快照）"
description: "2026-10-19 在 StationPanel/QueryModePanel 接入 stationcontrol 模式：mockMeasures 模拟后端、StationMeasureTemplate 气泡、useStationControl 建/清气泡、StationControl.vue 统计面板；同时抽出 useStationSnapshot 供路径规划与站控措施共用清场与快照还原，popup.js 新增 stationMeasure 路由；含确定性模拟规则（400 站→46 气泡）、浏览器实测与接真接口的唯一改动点。"
status: "active"
created_at: "2026-10-19T12:25:54.898Z"
updated_at: "2026-10-19T12:25:54.898Z"
content_hash: "8c022a677f78814a1563f08f3613b7fe584d2efa93269124c6766f4ac693c151"
source_paths:
  - "Translation/src/components/bottom/StationPanel/QueryModePanel/stationcontrol/mockMeasures.js"
  - "Translation/src/components/bottom/StationPanel/QueryModePanel/stationcontrol/StationMeasureTemplate.vue"
  - "Translation/src/components/bottom/StationPanel/QueryModePanel/stationcontrol/useStationControl.js"
  - "Translation/src/components/bottom/StationPanel/QueryModePanel/stationcontrol/StationControl.vue"
  - "Translation/src/components/bottom/StationPanel/QueryModePanel/useStationSnapshot.js"
  - "Translation/src/components/bottom/StationPanel/QueryModePanel/QueryModePanel.vue"
  - "Translation/src/components/bottom/StationPanel/QueryModePanel/guideload/useRoutePlan.js"
  - "Translation/src/cesiumTools/lineAndpoints/popup/popup.js"
session_ids:
  - "e2a3ddf3-a8c7-4cbe-8aaa-a6bfa31bae1b"
memory_body_ids:
  []
---

# 站点面板「站控措施」模式（stationcontrol）

日期：2026-10-19。入口：`/nodes` → 站点面板 → 查询模式「站控措施」。

前置/相关文档：
- `e9f4897b-6e1f-4ef0-934e-126d80b77906` — 查询模式外壳的声明式生命周期（一模式一组件、单一 owner）。本文是该契约下的**第二个**模式落地案例，`stationcontrol` 从 `component: null` 占位变成真组件。
- `771251b3-3cd0-40fd-9317-f7f609285a72` — 路径规划的「开始规划前清场」与逐条快照还原。本次把其中内联的那套逻辑抽成了公共件。
- `44fe1831-c29a-4d4c-aed8-334dfb8fa556` — 路径规划模式的四层结构，本文沿用同一分层口味。

## 1. 需求与证据限制

需求（用户口述）：读后端站点状态 → 在对应站点上渲染「当前执行中的措施」（封站、加强安检等）。

**语雀文档没读到**：`https://www.yuque.com/xzd/fgdede/urla5x3d2rxpdg22`（`#onjzh` 章节）当时是密码页，浏览器标题为 `输入密码 · 语雀`，正文不可达。因此实现依据只有两条：用户描述 + 参考项目里的措施清单（`station_solutions` 的 9 项）。字段名与状态枚举**未经文档核对**，这是本模式最明确的已知风险。

## 2. 措施清单（9 项）

封站 / 安检 / 重保 / 分批放行乘客 / 设立导流围栏 / 关闭部分进站闸机 / 减缓售票速度 / 改变电梯运行方向 / 引导乘客分流。

项目没有 iconfont，所以不用图标表达严重程度，改用**颜色**区分（措施名 → 颜色在做 `MEASURES` 查表）。若后端能直接给 `severity` / `color`，替换该表即可。

## 3. 文件与职责

| 文件 | 职责 |
|---|---|
| `stationcontrol/mockMeasures.js`（新增） | 模拟后端：`requestStationMeasures(names, seed)` → `[{ name, measures: [{ title, color }] }]` |
| `stationcontrol/StationMeasureTemplate.vue`（新增） | 气泡模板：站名 + 措施文字胶囊 |
| `stationcontrol/useStationControl.js`（新增） | 站名→本地坐标/线路色、建气泡、进出模式、`summary` 统计、`randomize()` |
| `stationcontrol/StationControl.vue`（新增） | 模式面板：46 站、各措施计数、「重新模拟」 |
| `QueryModePanel/useStationSnapshot.js`（新增） | 公共件：全局站点（光锥/底圈/站名气泡）的清场与快照还原 |
| `QueryModePanel/QueryModePanel.vue` | `MODES` 里 `stationcontrol` 的 `component` 由 `null` 改为 `StationControl`，`note` 同步 |
| `QueryModePanel/guideload/useRoutePlan.js` | 删掉内联的 `hideAllStations` / `restoreAllStations`，改用 `useStationSnapshot`（259 → 227 行） |
| `cesiumTools/lineAndpoints/popup/popup.js` | 新增 `stationMeasure` 模板路由 + `measures` 透传（与之前的 `badge` 同级，约 3 行） |

外壳一行生命周期代码都没加——这正是 `e9f4897b` 那条契约（组件在则效果在、卸载自己收拾）带来的直接收益：新增模式的成本是「新建目录 + `MODES` 加一行」。

## 4. 数据契约：坐标由前端补

模拟接口**只返回站名 + 措施**，不返回坐标，因为真后端多半也只管运营状态；`useStationControl` 负责把站名映射到本地站点对象（坐标 + 线路色），再建气泡。

这个划分同时决定了接真接口的改动面：只替换 `load()` 里的一行。

```js
// useStationControl.js 的 load()
raw.value = await getStationStatus();   // 期望 { name, measures: [{ title }] }[]
```

## 5. 模拟数据的规则（为什么城市视距下不糊屏）

- **确定性**：站名 + 种子做 FNV 哈希，同站永远同结果。切走再回来不会「变脸」；只有点「重新模拟」换种子才重滚。
- **比例**：约 90% 的站正常（0 项，不画气泡），6% 1 项、3% 2 项、1% 3 项 → 400 站出 **46 个气泡**。
- **措施按权重抽**：安检 7；分批放行乘客 / 设立导流围栏 5；重保 / 关闭部分进站闸机 / 引导乘客分流 4；减缓售票速度 3；封站 / 改变电梯运行方向 2。

确定性是刻意的：随机每次渲染都变会让「这是不是真数据」无法判断，也让浏览器验证没法复现。

## 6. 生命周期与清场（复用同一份快照）

进入模式：藏 18 条全局线路；站点先不动（用户还没点操作时仍按 StationPanel 的开关组合显示）。点查询后整片清场（`useStationSnapshot` 的 `hideAllStations`）。

退出 / 切模式：`clearRoute` 式清理 → 还原快照 → 恢复全局线路，全部在 `onBeforeUnmount`。

**去重的理由**：路径规划与站控措施都要「清场 + 按快照还原」同一批对象（光锥 Primitive / 底圈 Entity / 名字气泡 DOM，三者显隐 API 不同，走 `setpoints.js` 的 `hideStationByName` 兜差异）。两处各写一遍，快照字段迟早走样，所以抽成 `useStationSnapshot`，两边共用。

晚渲染补丁同样共用套路：`watch(() => stationObjs.length, …)`，实体比面板晚到且已有结果时补清一次，否则新冒出来的那批还是亮的。

## 7. 验证（浏览器实测，2026-10-19）

| 步骤 | 现象 |
|---|---|
| 点「站控措施」 | 面板显示 `站控措施 46 站`，计数：15 安检 · 10 分批放行乘客 · 9 设立导流围栏 · 8 重保 · 7 封站 · 7 引导乘客分流 · 6 关闭部分进站闸机 · 6 减缓售票速度 · 6 改变电梯运行方向 |
| 点「重新模拟」 | 计数变化（10 关闭部分进站闸机 / 10 安检 / … / 2 改变电梯运行方向）→ 种子生效 |
| 读 `.measure-popup` DOM | `一大会址·黄陂南路 引导乘客分流`，且处于显示态（没被距离剔除） |
| 再点「站控措施」退出 | `.measure-popup` → `no element matched`，气泡全清、站点按快照还原 |
| 直接切「路径规划」 | 气泡不残留，规划面板正常出现 |
| `vite build` | 通过（714 ms），仅既有 chunk > 500 kB 提示 |

气泡是 DOM，可当探针；光锥/底圈是 Cesium 图元，DOM 看不到——与 `771251b3` 的验证手法一致。

## 8. 改这块时的约束

- 接真接口只改 `load()` 里的请求，**不要**把坐标映射挪进后端：站名 → 本地站点的映射属于前端职责。
- 颜色表与措施集合目前是前端自定义的；拿到语雀 `#onjzh` 正文后，应先对齐字段名/状态枚举，再谈视觉。
- 不要在站控措施里再写一份清场/还原逻辑，一律走 `useStationSnapshot`；改快照字段只改一处。
- `popup.js` 的模板路由是懒加载映射，新增气泡类型在那里加一行即可，但 `measures` 之类的新 props 必须在 `createVNode` 处显式透传，否则模板拿到空数据（查询气泡曾踩过这个坑：`fields` / `values` 不透传就是空卡）。
