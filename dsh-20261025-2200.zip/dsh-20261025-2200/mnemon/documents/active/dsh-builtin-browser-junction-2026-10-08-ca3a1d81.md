---
id: "ca3a1d81-f11d-4876-bdef-fdb32c7b9c83"
title: "dsh-builtin-browser 卸载残留清理：Junction 陷阱、外壳半活补丁与验证（2026-10-08 本机）"
description: "清理已卸载的 dsh-builtin-browser 在 desktop profile 的残留：残留的三层来源、node_modules Junction 用 Remove-Item -Recurse 会连带删掉工作区源码的陷阱与安全做法、外壳侧补丁为何刻意保留、host 日志验证警告消失、与 Chrome 侧 dsh-browser 扩展零耦合的证据、重装需回填 controlPort 补丁行。"
status: "active"
created_at: "2026-10-08T01:49:29.340Z"
updated_at: "2026-10-08T01:49:29.340Z"
content_hash: "1d6e7b77f174a58ddbac64fdf8d955faa5a24bdc23ceddb6a38f43dfcdb9ad7b"
source_paths:
  - "dsh-builtin-browser/LOCAL-NOTES.md"
  - "dsh-builtin-browser/desktop/apply-shell-patch.mjs"
  - "dsh-builtin-browser/desktop/shell/dsh-builtin-browser-shell.js"
session_ids:
  - "0d986f02-77fa-4cf0-ab33-98b572f72f49"
memory_body_ids:
  []
---

# dsh-builtin-browser 卸载残留清理（2026-10-08 本机，desktop profile）

**背景**：用户认出左侧栏底部「内置浏览器」入口来自**更早安装、后来已自行卸载**的第三方插件 `dsh-builtin-browser`（clone 自 `github.com/EnZzzzzz/dsh-builtin-browser`，其停靠/补丁历史见文档 `e8f75bd1-e9be-4c78-905a-1b26d413d40d`），并问它是否与 **2026-10-07 新装的 Chrome 侧栏扩展 dsh-browser**（见文档 `502b4a5c-16a2-4ea4-953c-b861592308b7`）是同一个东西；要求「如果是残留文件就删除」。排查后确认为**两个独立的东西**，并清掉了残留。

## 1. 残留分三层，来源不同（这是本次最关键的结构认识）

| 层 | 位置 | 性质 | 处置 |
|---|---|---|---|
| ① profile patch 行 | `C:\Users\林先语\.dsh\profiles\desktop\cordis.patch.yml` 里的 `- id: builtin-browser / name: dsh-builtin-browser`（`controlPort: 44721`、`hideForPresets: [minimal]`） | 插件配置；**插件本体已不在**，`cordis.yml` 是空的 `[]` | ✅ 已删（**这是 host 警告的唯一来源**） |
| ② profile 包的安装痕迹 | `...\profiles\desktop\node_modules\dsh-builtin-browser` | `link:` 装法留下的**孤儿 Junction**（profile `package.json` / `pnpm-lock.yaml` 里都已无引用） | ✅ 已安全断链（见第 2 节） |
| ③ 外壳打包产物补丁 | `D:\DSH\dsh_data\DSH Desktop\resources\app\lib\`：`dsh-builtin-browser-shell.js`（loopback 控制端点 44721）、被 patch 的 `electron-runtime-*.js`（`webviewTag: true` + `globalThis.__dshBuiltinBrowserContent`）、`preload.cjs`（`window.desktopBridge.browserPort`） | **DSH Desktop 外壳**的一部分，不是 profile 残留 | ⚠️ **刻意保留**（见第 4 节） |

其他扫到的 `builtin` 字样只剩 `.plugin-manager\logs\operation-*\pnpm.log`（当初卸载时的历史操作日志，非活跃配置）——留着即可。

## 2. Junction 陷阱：`Remove-Item -Recurse` 会连源码一起删

② 那个目录**不是普通目录，是 Junction（reparse point）**：

```
LinkType : Junction
Target   : D:\Users\林先语\Documents\deepseek-harness\default-workspace\dsh-builtin-browser
```

它指向工作区里的**插件源码仓库**（94 项，含 `.git` 与用户手写的 `LOCAL-NOTES.md`）。在 PowerShell 5.1（`Remove-Item -Recurse -Force` 对于 reparse point 会跟随链接递归）下删它，会顺链路删掉工作区源码。

**安全做法**（本次采用）：用 `cmd /c rmdir <路径>`（**不带 `/s`**）只断开链接本身，并**删后核对**：链接消失、工作区 94 个文件与 `LOCAL-NOTES.md` 全部完好。

**通则**：清理任何 `node_modules\` 下由 `link:` 安装产生的条目之前，先 `Get-Item | Select-Object Attributes, LinkType, Target` 辨明是否 Junction/Symlink；是链接就只断链，别递归删。

## 3. patch 行删除后的实证（不是「应该好了」）

- 删前：host 日志 `C:\Users\林先语\AppData\Roaming\DSH Desktop\logs\host\dsh-2026-10-08.log` 每次重载必报 `patch: entry "builtin-browser" not found`（当天 09:41:15 / 09:43:47 / 09:43:58）。
- 删后：host 在 `09:47:47` 自动重载，**该警告不再出现**，YAML 正常解析。
- `cordis.patch.yml` 由 48 行变 38 行，其余 5 个 patch 项（`desktop-shell` / `desktop-notifications` / `cost-meter` / `dsh-context7` / `web-ui-usage`）原样保留、结构完整。
- profile 插件清单复核：15 个包，无 `builtin-browser`。

## 4. 为什么外壳侧补丁（③）建议保留

清理时端点还活着（`http://127.0.0.1:44721/browser/command?op=ping` → `{"ok":true,"port":44721,"page":true}`），但**它服务的客户端已随插件消失**（`hasController` / `window.__dshBrowser` 不再挂载），因此是**断链**：端点活着但干不了实事，唯一代价是占一个 loopback 端口。

清理它要改外壳**打包产物**（`electron-runtime-*.js` / `preload.cjs` / `main.js`），风险收益不成比例。兜底与重放资源都在：

- 原始文件备份：`resources\app-lib-backup-20261006`（脚本还会自动备份到 `app-lib-backup-<日期>`）；
- 补丁重放：`node desktop\apply-shell-patch.mjs`（幂等）；
- 改动清单与端口发现顺序：`dsh-builtin-browser\LOCAL-NOTES.md`。

若日后真要清：`op=diag` / `op=ping` 仍可作为确认外壳补丁是否已被更新覆盖的探针。

## 5. 与 Chrome 侧 dsh-browser 的耦合检查（零耦合）

对外壳侧与扩展侧交叉 grep `44721` / `dshBuiltinBrowserContent` / `builtin-browser` → **零匹配**，两套系统完全独立（前者是外壳 `<webview>` + 插件客户端；后者是 Chrome MV3 扩展 + 桥插件 `@yuxianglin/dsh-bridge-browser`）。所以清 builtin 残留**不会伤到** Chrome 扩展。

## 6. 重装须知（本次删除留下的唯一后手）

patch 行已删，**若将来重装 `dsh-builtin-browser`，必须把 patch 行加回去**，否则 `controlPort` 失配、客户端会降级成 iframe 回退：

```yaml
- id: builtin-browser
  name: dsh-builtin-browser
  config:
    enabled: true
    controlPort: 44721     # 必须与 desktop/shell/dsh-builtin-browser-shell.js 的 PORT 一致
    hideForPresets: [minimal]
```

## 7. 顺带发现（未处理，待查）

清理当次 host  Web 端口实际跑在 **46398**，而 `cordis.patch.yml` 里为 Chrome 扩展钉的是 **43120**（`%USERPROFILE%\.dsh\dsh-bridge-port-shim.mjs` 用于兜住 43120 被占用/当前会话的情况）。扩展只探测固定端口列表，46398 不在其中——**扩展报「未连接」可能源于此**，尚未验证。
