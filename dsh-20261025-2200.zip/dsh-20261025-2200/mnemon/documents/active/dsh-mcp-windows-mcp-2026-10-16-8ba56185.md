---
id: "8ba56185-2c41-4c6d-8b5a-903a6ba284ea"
title: "为 DSH 补「看见并操作原生窗口」的 MCP 选型调研：Windows-MCP 为首选（截至 2026-10-16 未安装）"
description: "为 DSH 补齐「看见并操作原生窗口」能力缺口的 MCP 选型调研：Windows-MCP（UI Automation 文本控件树）为首选、PowerShell.MCP 为何重复、postgres-mcp 待定，含本机 uv/Python 前提、三条风险与拟加 profile 片段；截至 2026-10-16 未安装。"
status: "active"
created_at: "2026-10-16T11:21:15.434Z"
updated_at: "2026-10-16T11:21:15.434Z"
content_hash: "f3b467a997ce75c6c1db52f70611be22580de0987b7da190f0a2b8a61bd09059"
source_paths:
  []
session_ids:
  - "2f9557d8-7e4d-4008-82ee-4fa01ac838c0"
memory_body_ids:
  []
---

# 为 DSH 补「看见并操作原生窗口」的 MCP 选型调研

日期：2026-10-16。起因：用户提出「怕你权限不够」，要求搜索 PowerShell 相关 MCP，找有没有更契合 DSH 的高质量项目。
状态：**仅调研与建议，未安装、未改 profile**。用户尚未答复是否动手。

## 0. 先纠正的前提：瓶颈不是权限，是能力形状

- 权限侧：`danger-full-access` + 审批提示已禁用，唯一的真限制是**非管理员**（`IsInRole(Administrator)` = False），需要 UAC 的机器级安装要人工点一次。
- 能力侧才是真缺口：

| 缺什么 | 现状 |
|---|---|
| 看不见屏幕 / 原生窗口 | 无任何截图工具；modlens 只能读**已经拿到**的图片 |
| 进不去交互式提示 | shell 是 `powershell.exe -NonInteractive`，`Read-Host` / UAC / git 凭据问不到 |
| 状态不常驻 | 每条命令新进程（profile 里另有 `persistent-pwsh` 工具，未细究） |

## 1. 硬前提：DSH 本来就支持挂 MCP，且已在用

DSH 侧已有通用 MCP 桥，**这不是新能力，是既有通道**（接线字段见 `dsh-vs-mcp-4b7d494f-5c4b-4c71-8ea5-80f19359a2cb`，本文不重复）：

- profile 中已存在的条目：`mcp-anysearch` → `name: '@deepseek-ai/dsh-mcp-client'`、`url: https://api.anysearch.com/mcp`；另有 `mcp-resources` → `@deepseek-ai/dsh-mcp-resources`。
- 猜测路径 `@local/dsh-mcp-anysearch` 亦出现于 dump；`@deepseek-ai` 下与 mcp 相关的包为 `dsh-mcp-client`、`dsh-mcp-resources`。
- 因此**任何 MCP 服务器都能接**，代价是往 profile 的 `cordis.patch.yml` 加一段；该文件改动已被验证为**热生效，无需重启**。

本机运行 MCP server 的前提（实测）：

| 需要 | 现状 |
|---|---|
| `uv` / `uvx` | **未安装**（`pip install uv` 即可；`D:\python\Scripts` 已在 PATH） |
| Python | `D:\python\python.exe` = **3.10.10**；`py` = `C:\Windows\py.exe` |
| node / git | `E:\node.exe`、`C:\Program Files\Git\cmd\git.exe` |

## 2. 候选对比与处置

| 项目 | 是什么 | 处置 | 理由 / 坑 |
|---|---|---|---|
| [CursorTouch/Windows-MCP](https://github.com/CursorTouch/Windows-MCP) | Windows 桌面 / UI 自动化 MCP | **✅ 首选** | MIT、774 commits、进 MCP Registry、有完整安全模型；默认开 PostHog 匿名遥测；需 Python 3.14+ |
| [crystaldba/postgres-mcp](https://github.com/crystaldba/postgres-mcp) | Postgres MCP Pro | ⚠️ 待定 | 本机有 PostgreSQL 18.4，但**不清楚用户项目是否用 PG**，缺证据不下结论 |
| [yotsuda/PowerShell.MCP](https://github.com/yotsuda/PowerShell.MCP) | 共享控制台 PowerShell（AI 与人同一窗口） | **❌ 价值有限** | 102★；DSH 已有 `pwsh` 工具 + `persistent-pwsh`，属重复；它独有的「可见控制台 / 交互式提示 / 会话常驻」三点未与 DSH 现状对价 |
| [mcp-windows-screenshot](https://mcpservers.org/servers/sarfraznawaz2005/mcp-windows-screenshot) | 只会截图 | ⚠️ 低风险极简 | 未核实质量；只给视觉，不给操作 |

补充：PowerShell.MCP 要求 PowerShell 7.4+，而本机在此之前只有 5.1（当日刚装 PS7）——即「装 PS7 之前它根本起不来」。其姊妹项目 [ripple](https://github.com/yotsuda/ripple) 把同一「共享控制台」思路推广到 bash/cmd/zsh、语言 REPL、SQL 控制台与调试器。

## 3. 为什么 Windows-MCP 最契合（关键论点）

**决定性差异不是「能截图」，而是 `Snapshot` 返回 UI Automation 的文本控件树，而非图片**：

```
窗口: 记事本
├─ 菜单栏 [MenuBar]
├─ 文档编辑区 [Edit] "当前内容..."
└─ 状态栏 [StatusBar]
```

文本模型可直接读这棵树、按元素名定位点击，无需绕 modlens 图片桥。配合 `Click / Type / App / Shortcut / WaitFor / DisplayInventory` 即可操作原生窗口——Blender 对话框、系统弹窗、DSH Desktop 自身、浏览器桥覆盖不到的地方。

**它自带的 `PowerShell` / `Registry` / `FileSystem` 工具对本机是纯重复**（已有满权限 pwsh），应通过 `--tools` 白名单砍掉，缩小暴露面。

## 4. 三条必须前置说明的风险

1. **等于把鼠标键盘交出去**。作者提供的「桌面所有权」门禁默认 `relaxed`：需桌面空闲 10 秒才允许直接输入，用户动鼠标即被感知并让位。**建议保持开启，不要用 `--no-control`。**
2. **默认开匿名遥测（PostHog）**，安装时应设 `ANONYMIZED_TELEMETRY=false`。
3. 装成后**能看见整块屏幕**（截图 / Snapshot 覆盖全桌面，不限某个应用），这是需要用户先接受的预期。

## 5. 若实施：拟加的 profile 片段（草稿，待核实真实路径）

```yaml
- id: mcp-windows
  name: '@deepseek-ai/dsh-mcp-client'
  config:
    serverName: windows
    transport: stdio
    command: 'D:\python\Scripts\uvx.exe'      # 装完 uv 后核实真实路径
    args: ['windows-mcp', 'serve', '--tools',
           'Screenshot,Snapshot,Click,Type,Scroll,Move,Shortcut,App,Wait,WaitFor,DisplayInventory']
    env:
      ANONYMIZED_TELEMETRY: 'false'
    toolCallTimeoutMs: 120000
```

拟实施步骤：`pip install uv` → `uvx windows-mcp serve` 连通性探测（确认能拉下托管的 Python 3.14、工具列表正常）→ 写入 profile → `dump-config` 验证。

## 6. 证据来源（均在 DSH 安装目录 / 用户 profile，不在本工作区内）

- `D:\DSH\dsh_data\DSH Desktop\resources\app\node_modules\@deepseek-ai\dsh-mcp-client\lib\index.js`（实现主体，约 35 KB）
- `@deepseek-ai\dsh-mcp-client` 的 `README.zh.md`（配置目录、工具命名、启动/重连策略）
- 用户 profile `cordis.patch.yml` 现有 `mcp-*` 条目；本机工具探测输出（uv / uvx / python / node / git）
- 外部检索：goodwin 类目录与 GitHub 仓库页（Windows-MCP、PowerShell.MCP、postgres-mcp）

## 7. 相关文档

- `dsh-vs-mcp-4b7d494f-5c4b-4c71-8ea5-80f19359a2cb`：MCP 桥接的接线字段与「接 MCP 要付 token 税、原生插件优先」的依据（本文的前提与反方约束）。
- `af6a807a-d3fc-4b58-ab45-9eb0de5319f6`：同类「跨进程操控本机应用」的先例（Blender 实时桥接），其编码与还原类坑对任何新的本机操控通道同样适用。
