---
id: "5f0698d1-06fe-47fc-8382-060face9e80c"
title: "Dawnivers 个人站「项目详情页」实现：多页构建、project-data 数据模型、截图与视频占位接入"
description: "个人网站新增 project.html 详情页的实现交接：Vite 多页配置、src/project-data.js 字段契约与新增项目流程、真实截图压缩管线、demo.mp4 自动探测、无头 Chrome CDP 审版与已知坑。承接 922f11cb 的站点通读。"
status: "active"
created_at: "2026-10-21T14:27:52.252Z"
updated_at: "2026-10-21T14:27:52.252Z"
content_hash: "e308216af70f553bbddf89da6096b3323421220559293b512853809fc8c9b407"
source_paths:
  - "project.html"
  - "src/project.js"
  - "src/project.css"
  - "src/project-data.js"
  - "src/particle-bg.js"
  - "src/script.js"
  - "vite.config.js"
  - "server.js"
  - "public/projects/metro"
session_ids:
  - "ab9057d0-c3ea-4b03-9b5f-2f7248e4022f"
memory_body_ids:
  []
---

# 项目详情页（project.html）：实现与扩展手册

日期：2026-10-21。落点：`D:\WebGIS\web三维开发\个人网站`。承接 `922f11cb-d052-4645-b9c0-e15409fa38f6`（站点通读与 9 项问题清单），本记录只描述**详情页这一层新加的东西**与其后的扩展方式。

## 1. 产品决策：卡片不再直跳线上 Demo

改造前：首页「我的项目」卡片 `url` 直接是线上 Demo（`project2.dawnivers.top`），访客第一次接触项目就撞上三维瓦片慢加载。
改造后：卡片 → `project.html?id=<key>`（先看目的、技术栈、真实截图）→ 页面内「打开在线 Demo」再跳线上。线上地址不变；`projects` 数组里旧字段 `url` 保留为 Demo 地址，卡片渲染改读 `id` 拼详情页。

两个项目已接：`metro`（智慧地铁，内容完整）、`community`（小区分层分户，结构就位、正文占位）。高德地图卡仍是「案例整理中」，不可点（`DIV` 而非 `A`，无 `href`）。

## 2. 工程改动

| 文件 | 作用 |
|---|---|
| `project.html` | 详情页独立入口（首屏 / 01 目的 / 02 技术 / 03 功能截图 / 04 演示 / 收尾 CTA） |
| `src/project.js` | 读 `?id=` → 查 `projectDetails` → 渲染；含图片灯箱、锚点滚动、`demo.mp4` 自动探测 |
| `src/project.css` | 详情页样式，沿用主页雪峰蓝 + 冰霜玻璃（玻璃外框 + 高光扫过 + hover 微转） |
| `src/project-data.js` | 全部页面文案与图片路径（**改内容只碰这个文件**） |
| `src/particle-bg.js` | 从 `src/script.js` 抽出的共享粒子背景模块，主页与详情页共用 |
| `vite.config.js` | 改成**多页构建**（index + project 两个 entry），否则 `dist/` 里没有 `project.html` |

构建产物（实测）：`dist/index.html`、`dist/project.html`、`dist/assets/{main,project,particle-bg}-*.js|css`，`npm run build` 约 300ms。

## 3. 数据契约：`src/project-data.js`

`export const projectDetails = { <key>: { ... } }`，`key` 即地址栏 `?id=`，与 `src/script.js` 里 `projects` 数组条目的 `id` 对应。文件头自带字段注释：

- `name` / `fullName` / `badge` / `tags[]` / `tagline` — 首屏
- `demoUrl` — 在线 Demo；**留空则按钮自动隐藏**
- `heroImage { src, alt }` — 首屏大图
- `stats [{ value, unit, label }]` — 数字概览（如 `18 条 / 510 座 / 1993 年 / 60FPS`）
- `purpose { intro, points[{title,text}] }` — 01 项目目的
- `stack [{ group, note, items[] }]` — 02 技术栈分组
- `features [{ no, title, desc, tags[], image }]` — 03 功能卡 + 截图
- `video { src, poster, title, note }` — 04 演示；**`src` 留空显示「整理中」占位卡**

## 4. 新增一个项目详情页的标准流程

1. 在 `src/project-data.js` 复制一段 `metro`，改 `key`（如 `amap`）。
2. 首页 `src/script.js` 的 `projects` 条目补 `id: '<key>'`，卡片即指向 `project.html?id=<key>`。
3. 截图放 `public/projects/<key>/`，`features[].image` 与 `heroImage.src` 写 `/projects/<key>/xxx.jpg`。
4. `npm run build` → 打开 `http://localhost:8091/project.html?id=<key>` 核对。

## 5. 截图不是示意：真实素材压缩管线

素材来源：智慧地铁项目的 `.review` 联调图（1920×1080 实拍）。用 System.Drawing 统一压到 **1440 宽 JPEG quality 82**，单张 170–360KB，六张：`overview / realtime / stations / history / active / query`。放 `public/projects/metro/`。
未使用素材：`fenceng.png` 被复用为视频占位卡封面。

## 6. 视频位：零改代码的自动接入

设计上拒绝用截图伪造录屏，当前是 `VIDEO · COMING SOON` 占位卡（封面 + 播放按钮 + 「先看界面截图 / 直接打开 Demo」两个出口）。
接入方式：把录好的文件命名 `demo.mp4` 放到 `public\projects\metro\`，刷新即被探测并换成带控件的 `<video>`；要换文件名就写 `video.src`。

## 7. 验证配方（可复用）

- 构建：`npm run build`，确认 `dist/project.html` 存在、无报错。
- 页面：`http://localhost:8091/project.html?id=metro`（Express 托管 `dist/`；5173 被智慧地铁项目占用，故本站用 8091）。
- 截图审版：`%TEMP%\page-shot\capture.mjs` —— 无头 Chrome + CDP，按 `hero / features / video / mobile(390×844) / 整页` 出图（本机已验证：桌面排版、手机 390px 下标签换行、数字 2×2、主图不溢出）。
- 结构化探针：`%TEMP%\probe\probe.mjs` —— 跑页面取 `{cards, tabs, hasCanvas}` 与 `{zoomables, sections, imgs[]}`，确认卡片 `href` 为 `project.html?id=metro|community`、高德卡无 `href`、灯箱可开可关、`videoStillPlaceholder: true`。

## 8. 踩过的坑

- **编辑冲突**：`src/script.js` 报 `file changed since it was read` — 必须重新读取再写，不能凭旧快照盲改。
- **数字行塌陷**：`stats` 里 `value+unit+label` 混排会挤成一行，需在 `src/project.js` 里分行处理（已修）。
- **视频文案重复**：`video.note` 与下方引导文案同时渲染会出现同一句话两遍（已改为只在占位卡出现一次）。
- 页面内容未做真实数据的自证：技术栈全部取自智慧地铁项目 `package.json` 与后端 `Translation_BE` 路由，不要凭印象写版本号。

## 9. 状态与下一步

- 已完成：metro 详情页全量内容、community 页面骨架、双页构建、交互与移动端核对，控制台无报错。
- 未完成：community 的 `purpose/stats/features` 仍是占位（`.review` 素材够用）；`demo.mp4` 未录；高德卡仍是不可点案例。
- 已知遗留（非本页引入）：技能气泡 `w-18/22/25/26/30/34/38` 不在 Tailwind v3 默认间距表，桌面端疑似塌陷；无 `.git` 仓库，改动不可回滚。
