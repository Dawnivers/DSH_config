---
id: "e8d0b5ea-bf31-4a81-a9d9-23306865e995"
title: "GVHMR 部署执行实测：WSL/Ubuntu22 落地、MPI 限速绕法、hf-mirror 权重下载与剩余 SMPL-X 缺口"
description: "B 路线（GVHMR）从方案转为已执行状态的实测记录：D:\\WSL\\Ubuntu22 导入与 GPU 直通验证、download.is.tue.mpg.de 单连接 14.8KB/s 限速用 16 路 Range 并行提到 171KB/s、hf-mirror 直连 9.7MB/s 远优于系统代理、WSL rootfs 可用真源与真文件名、SMPL 1.1.0/neutral 下载项判定与 6890/24/300 校验、SMPL 与 SMPL-X 账号不通用导致 SMPLX_NEUTRAL.npz 仍缺。方案与许可背景见关联文档 72feafbd。"
status: "active"
created_at: "2026-10-17T02:00:18.046Z"
updated_at: "2026-10-17T02:00:18.046Z"
content_hash: "a360f21e3b542f0f01f055ac00aab05bd20264f1a91c129323e20376cf0b6e84"
source_paths:
  []
session_ids:
  - "55818612-3a9c-48f5-9d3b-4b111ed76df6"
memory_body_ids:
  []
---

# GVHMR 部署执行实测（承接 B 路线实施规格）

前置方案、依赖钉版本、许可红线见文档 `72feafbd-2625-4f82-ac10-0e47afc7a94d`（B 路线实施规格）。本文只记**已执行落地的事实与踩坑结论**，避免下次重测。

## 1. 国内网络下的下载：三个可复用结论

### ① MPI 官方站点（`download.is.tue.mpg.de`）是**单连接限速**，不是"连不上"

- 表象极具误导性：10 分钟内 `SMPL_NEUTRAL.npz` 稳定 **0 字节、零增长**，但 python 进程仍活着 → 容易被误判为"卡死/代理不通"。
- 实测链路正常：直连和走代理都能 **1.6–1.7 秒**拿到首 8 KB，`Content-Length = 44815514`（42.7 MB），文件名正确。
- 真实瓶颈：**单连接持续速率仅 14.8 KB/s**（42.7 MB 要 49 分钟）。
- **解法**：服务器返回 `Accept-Ranges: bytes`（Range 请求回 206）→ **16 条连接并行分块拉取再合并**，合计 **171 KB/s**，256 秒下完，`errors: 0`，尺寸与远端一致。
- 结论：MPI 站点上遇到"有进程但零增长"，先测 sustained 速率 + Range 支持，别急着杀进程或换代理。

### ② `hf-mirror.com` 必须**直连**，绕系统代理更快

| 路径 | 实测 |
|---|---|
| `hf-mirror.com` **直连** | **≈ 9.7–16 MB/s**（实际拉取时单文件峰值 15.9 MB/s） |
| `hf-mirror.com` **走系统代理**（`127.0.0.1:7897`） | ≈ 1.37 MB/s |
| `huggingface.co` 直连 / 走代理 | ❌ `WinError 10061` 连接被拒 |

- 机理：urllib 不读系统代理设置（`HTTP_PROXY`/`HTTPS_PROXY` 环境变量为 `None`，只有注册表 `ProxyEnable=1`），所以打 huggingface.co 一律被拒；**镜像才是唯一通路**，且镜像直连最快。
- 5.26 GB 四个权重经 hf-mirror 直连 8 线程分块：**359 秒**（yolo 7.0 MB/s、vitpose 15.4 MB/s、hmr2 15.9 MB/s、gvhmr 13.4 MB/s）。

### ③ 权重来源仍是 `ryanrudes/gvhmr`（gated: false）

`gvhmr/gvhmr_siga24_release.ckpt`、`hmr2/epoch=10-step=25000.ckpt`、`vitpose/vitpose-h-multi-coco.pth`、`yolo/yolov8x.pt` —— 单仓库齐备，共 5.26 GB，已落到 `D:\mocap\gvhmr\inputs\checkpoints\`。Google Drive 路径依旧放弃（代理 ~45 KB/s）。

## 2. WSL / Ubuntu 22.04 落地（vhd 在 D 盘）

- 本机 WSL 2.6.3.0 / 内核 6.6.87 / 默认版本 2，初始无发行版。
- **rootfs 真名与真源**（自猜的 URL 全是 404，浪费过一轮）：
  - 可用：`https://cloud-images.ubuntu.com/wsl/jammy/current/ubuntu-jammy-wsl-amd64-ubuntu22.04lts.rootfs.tar.gz`（8.4 MB/s，325.3 MB）
  - ⚠️ 清华 / USTC 的 `/ubuntu-cloud-images/wsl/...` 路径 **404**（不提供该镜像子树）
  - 关键是文件名里的 `-ubuntu22.04lts` 后缀，`ubuntu-jammy-wsl-amd64-wsl.rootfs.tar.gz` 这类猜测名不存在。
- 落地方式：`wsl --import` 到 **`D:\WSL\Ubuntu22`**（不占 C 盘），发行版名 `Ubuntu22`。
- 发行版内验证：`Ubuntu 22.04.5 LTS`、**Python 3.10.12**（正好匹配 pytorch3d 的 `py310_cu121_pyt230` 预编译轮子）；**GPU 直通成功**，`nvidia-smi` 直接看到 `RTX 4070 Laptop GPU`，UUID `GPU-3c4e24c6-...`。
- 依赖栈（apt 换清华源、pip 换清华源、torch 2.3.0+cu121、编译 `cython_bbox`）走后台任务执行，日志 `D:\mocap\gvhmr\provision.log`；`cython_bbox` / `chumpy` 是最可能炸的两项，失败先看该日志。

## 3. SMPL 模型下载项判定（页面清单已实测确认）

登录 `smpl.is.tue.mpg.de` 后的 Downloads 页（**必须登录才能看到清单**，未登录只返回页脚）：

| 下载项 | 判定 |
|---|---|
| **`SMPL_python_v.1.1.0.zip`** | ✅ 含 **neutral**（`1.0.0` 只有 female/male）—— INSTALL.md 要的格式 |
| **`julia/SMPL_NEUTRAL.npz`（43 MB）** | ✅ 文件名正合要求，纯 numpy 格式、无需 chumpy，实际选用 |
| SMPL for Maya / Unity / FBX 示例 / UV map / DMPL | ❌ 与推理无关 |

- 许可原文实测为 **"non-commercial research, education, and artistic purposes"** —— 比方案文档里记的多了 `artistic purposes`，个人动画/艺术用途被覆盖；商用联系 `sales@meshcapade.com`。
- 校验通过的落盘（`D:\mocap\gvhmr\inputs\checkpoints\body_models\smpl\`，`.npz` + 转换出的 `.pkl` 双份）：`v_template (6890,3)`、`J_regressor (24,6890)`、`kintree_table (2,24)`、`shapedirs (6890,3,300)`、`posedirs`、`f (13776,3)`。

## 4. 唯一剩余缺口：SMPL-X（账号不通用）

- 用 SMPL 站点那套账号登录 `smpl-x.is.tue.mpg.de` **不成立**（仍停在登录页）—— 两个站点**各自独立注册**。
- GVHMR 预测的是 SMPLX 参数，所以 `inputs/checkpoints/body_models/smplx/SMPLX_NEUTRAL.npz` 是**跑通必要条件**，不能靠 SMPL 替代。
- 待办：单独注册 SMPL-X → 下载 `SMPLX_NEUTRAL.npz`（约 100 MB，格式要 `.npz` 现代格式，不要旧 chumpy `.pkl`）→ 落到上述 smplx 目录 → 用 keys 是否含表情/手部项（如 `hands_components`）做校验。

## 5. 下一步（不依赖 SMPL-X 即可并行）

SMPL 24 关节 → Biped 的重定向映射可先写；重定向层仍是本项目自有代码（`mocap/retarget_compute.py` 的方向匹配 + 平滑 + 限速），GVHMR 只替换输入层，预期仍需 1–2 轮迭代。数据/管线背景见 `c16da0c6-1c61-4678-a995-db2ed3fc734e`（MediaPipe 管线与噪声诊断）与 `16979651-4dbf-4432-8bc0-29541f6fc50f`（方案可行性）。

> 注：本次过程中用户曾提供 MPI 站点登录凭据用于代下载；凭据不入档、不复述，事后应改密。
