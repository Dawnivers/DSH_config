---
id: "664f423a-80ba-4ada-9bb2-37806b63ec04"
title: "智慧地铁上线版：project2.dawnivers.top 反代修复定案（宝塔自动补尾斜杠 → sed 修复后全链路实测全绿）"
description: "2026-10-21 实测定案：project2 反代失效的最终成因是宝塔生成配置时把 proxy_pass 自动补成 http://127.0.0.1:666/（剥掉 /nginx 前缀）；含 sed 修复命令、修复后逐项 200/MD5 验收真值、panel 重写回退坑、以及遗留的 SPA 刷新 404 与 HTTPS 证书不覆盖子域两项待办。"
status: "active"
created_at: "2026-10-21T10:58:25.203Z"
updated_at: "2026-10-21T10:58:25.203Z"
content_hash: "d08f8372ce63fd6d0051fd0001f645bb5e5b6dc537a9cbd86edd0dafd84393ba"
source_paths:
  - "vite.config.js"
  - "src/router/index.js"
  - "src/cesiumTools/sceneManager.js"
session_ids:
  - "a5d365f1-a51c-43e6-8e96-819465f3099b"
memory_body_ids:
  []
---

# 结论先行

`project2.dawnivers.top` 的 `/nginx/` 反代已修复并公网验收通过。最终成因不是手写语法错，而是**宝塔面板生成反代文件时给 `proxy_pass` 自动补了一根结尾 `/`**（面板界面显示 `http://127.0.0.1:666`，落盘为 `http://127.0.0.1:666/`）。按 nginx 规则，`proxy_pass` 只要带 URI（哪怕一根 `/`）就会把 location 前缀替换掉 → `/nginx/Translation/...` 到上游变成 `/Translation/...` → 上游只有 `location /nginx` → 404。

前置诊断链：`e6cc24af-e2d1-4e85-a1d3-11595bbcda4c`（多站点指纹定位）、`933d3b7b-396a-4f92-a8ff-62bd719670a8`（`proxy_pass` 带 URI 剥前缀原理 + dist 必须根部署）、`70090dce-2a73-410b-ad55-cb3d040aaaa0`（后端反代分段验证法）。

# 1. 决定性证据（改前 vs 改后同一请求）

| 请求 | 改前 | 改后 |
|---|---|---|
| `/nginx/` | 200 / **138B**，body 是 nginx 404 页，**无 CORS 头** | 200 / **382B**，666 的真实目录索引，**带 CORS** |
| `/nginx/Translation/.../tileset.json` | 404 / 146B | **200 / 3425B** `application/json` |
| `/assets/index-DI0X5o-Z.js` | 404 | **200 / 515109B** |

138B 无 CORS + 146B 404 这一对指纹，等价于「代理打到 `127.0.0.1:80`（IP 站点）且前缀被吃」；对照 `project1.dawnivers.top` 同配置无尾斜杠时 `/nginx/` 直接是 382B 目录索引，可作为判定基准。

# 2. 修复操作（面板里点「编辑→确定」不可靠）

```bash
sed -i 's#proxy_pass http://127.0.0.1:666/;#proxy_pass http://127.0.0.1:666;#' \
  /www/server/panel/vhost/nginx/proxy/project2.dawnivers.top/95cff02f70fe380d138de84e93c15f33_project2.dawnivers.top.conf
nginx -t && nginx -s reload
```

- 反代文件位置规律：`/www/server/panel/vhost/nginx/proxy/<站点>/<32位哈希>_<站点>.conf`，由站点 conf 里的 `include /www/server/panel/vhost/nginx/proxy/<站点>/*.conf;` 引入。
- **坑**：再在面板点该反代的「编辑→确定」会按模板重写，尾斜杠可能回来 → 故障复现。要改就继续 sed，或把该 location 直接写进站点 conf（同样有被面板重写的风险）。
- 另一种面板侧绕法：代理目录从 `/nginx/` 改成 `/nginx`，部分版本不再补 `/`，但不如改文件稳。

# 3. 站点与产物的真实位置

```
/www/server/panel/vhost/nginx/project2.dawnivers.top.conf
  server_name project2.dawnivers.top;
  root /www/wwwroot/Translation/Project/dist;   ← dist 的「内部」直接铺在这一层
/www/wwwroot/ 下：default, fencengfenhu, HomePage, nginx_assets,
  project1be.dawnivers.top, Translation, translationbe.dawnivers.top
```

改前站点跑的是 `index-BKbkpnn6.js`（1,551,535B，「分层分户」项目产物）；重传正确 dist 后入口变为 `index-DI0X5o-Z.js`（515,109B / 磁盘 5,052,260B），旧 bundle 自然 404，可作为「传对没传对」的一秒判据。

# 4. 修复后公网验收真值（Host: project2.dawnivers.top）

| 路径 | 结果 |
|---|---|
| `/nginx/Translation/shangHaiBuilds_new_toPlane/tileset.json` | 200 · 3425B · `application/json` · CORS `*` |
| `.../12_2116_2399_2048.glb` | 200 · 580384B · glTF 魔数正确 · CORS `*` |
| `/nginx/Translation/EastProject/tileset.json` | 200 · 1771B |
| 嵌套子瓦片 `10_529_599_512.json` / `11_1058_1199_1024.json` | 200 · 1163B / 1646B |
| `/nginx/` | 200 · 382B（666 目录索引） |
| `/` | 200 · **679B**（本项目 index.html；旧版是 625B，带 favicon 行） |
| `/assets/index-DI0X5o-Z.js` | 200 · 515109B |
| `/cesium/Cesium.js` | 200 · 3406969B |
| `/assets/trainAndChisa_static-CU8atkpj.glb` | 200 · 24706712B |
| `rolldown-runtime-*.js` / `_plugin-vue_export-helper-*.js` / `index-CqUZV7Wh.css` / favicon / 图片 | 全 200 |

完整性用 MD5 逐一对上，可证明线上与本地 `dist` 是同一份产物：
`index-DI0X5o-Z.js` = `912E302CF4C60438815F12379303E180`；`trainAndChisa_static-CU8atkpj.glb` = `7E90B6B5616F634F671C120679911B72`（24,706,712B）。

产物自检指纹（判断是否为本项目 dist）：bundle 内 `/nginx/Translation` 出现 2 次、`translationbe.dawnivers.top` 1 次、`localhost:666` 0 次；若只见 `/nginx/fencengfenhu/model/tileset.json` 则是「分层分户」。

# 5. 遗留两项（当时未做）

1. **SPA 子路由刷新 404**：`/realtime`、`/nodes`、`/strategy` → 404/146B（站内跳转正常，F5 变 404）。在站点 conf 的 `server{}` 内加 `location / { try_files $uri $uri/ /index.html; }`；`location ^~ /nginx/` 带 `^~` 优先级更高，不会被抢。可选加固 `location ^~ /assets/ { try_files $uri =404; }`，避免资源 404 被 SPA 兜底成 HTML 让 Cesium 解析报怪错。
2. **HTTPS 证书不覆盖子域**：`https://project2.dawnivers.top/` 加 `-k` 才通；证书只签了 `dawnivers.top`。需在宝塔为该站点签 Let's Encrypt 或挂 `*.dawnivers.top` 泛域名证书。因瓦片走同源 `/nginx/`，切 https 不用改前端地址，不会踩混合内容。

# 6. 可复用的排查顺序

1. `curl -o /dev/null -w '%{http_code} %{size_download}'` 打 `/`、`/assets/<入口js>`、`/nginx/`、`/nginx/.../tileset.json` 四条；
2. 用 **body 长度 + 有无 CORS 头** 给响应打指纹，判断请求落到哪个 server block / 哪个端口；
3. 读站点 conf 的 `server_name`/`root`/`include`，再 `cat` 被 include 的反代文件看 `proxy_pass` **落盘原文**（不要信面板界面显示）；
4. `nginx -t && nginx -s reload` 后再探一次，用 `/nginx/` 的 382B vs 138B 区分「真打到 666」还是「打到 80 且剥了前缀」。
