---
id: "8a2ce03b-0dd7-4b4c-9492-354d34a889f2"
title: "Translation 本地项目「科技风开屏加载动画」实现：真实加载时序接入、三重兜底与 HUD 配色对齐"
description: "在本地 Translation 项目（localhost:5173）实现的智慧地铁开屏动画：新增 SciFiLoader.vue + loadingState.js，按 initViewer/影像/两 tileset ready/特效/首屏瓦片真实事件上报进度，1.8s 最短展示 + 1.2s 缓存免触发 + 25s/40s 兜底，z-index 9900 压过 HUD 9600，配色沿用 #11efe3/#e2ba64/#040c18。含工作区未动的边界与验证方法。"
status: "active"
created_at: "2026-10-21T12:24:51.442Z"
updated_at: "2026-10-21T12:24:51.442Z"
content_hash: "c0f2f2743e37cc3cce6e6497aff1411980d25b4743a9c333cea4562dc50fe3af"
source_paths:
  - "Translation/src/components/loading/SciFiLoader.vue"
  - "Translation/src/stores/loadingState.js"
  - "Translation/src/App.vue"
  - "Translation/src/views/cesiumView.vue"
  - "Translation/index.html"
session_ids:
  - "d1af9a4e-f42f-438a-940b-c70fee170156"
memory_body_ids:
  []
---

# 智慧地铁本地项目：开屏加载动画（SciFiLoader）

日期：2026-10-21。落点：**本地** `D:\WebGIS\web三维开发\智慧地铁项目\Translation`（dev server `http://localhost:5173/`，PID 39904 的 vite）。
用户明确要求：「先在本地实验，**先不要加到这个工作空间下的项目**（`智慧地铁_上线版/Project`）」。本记录只覆盖这套动画的设计与接入，LOD 裁剪算法/层级分布见 `cf0fbafd-3d5e-4f89-b00b-0db4e02bcf70`，线上验收见 `b19f41c5-ad92-4a44-b144-984d68cf63ea`。

## 1. 前置事实（定位与依赖）

- `localhost:5173` 对应 `D:\WebGIS\web三维开发\智慧地铁项目\Translation`（用进程命令行确认 vite 来自该目录，不要凭端口猜项目）。
- 该本地项目与上线版是**同一套代码**，此时尚未带上 LOD 改动；其 `cesiumView.vue` 的 `modelUrls` 用的是 `http://localhost:666/model/shangHaiBuilds_new_toPlane/tileset-L11.json` + `EastProject/tileset.json`。
- 现有 HUD 最高 `z-index` 为 9600，因此加载层取 **9900** 才能盖住全屏 HUD；配色沿用 HUD 的 `#11efe3` 青 / `#e2ba64` 金 / `#040c18` 深底，避免与栏目面板视觉打架。

## 2. 改动的文件

| 文件 | 作用 |
|---|---|
| `Translation/src/components/loading/SciFiLoader.vue` | 全屏开屏动画（新增，z-index 9900） |
| `Translation/src/stores/loadingState.js` | 加载进度状态机 + `LOAD_STEPS` 阶段名（新增） |
| `Translation/src/App.vue` | 挂载 `<SciFiLoader />`，与 `.scene-layer`/`Panel` 并列 |
| `Translation/src/views/cesiumView.vue` | 在每个真实加载节点上报进度 |
| `Translation/index.html` | 加静态底 `boot-splash`，消除 JS 下载前的白闪 |

## 3. 视觉构成（纯 CSS，无额外依赖）

- 背景：深钴蓝径向渐变 + 缓慢漂移的透视网格 + 暗角 + 4.2s 一圈扫描光带。
- 中央徽记：三层同心环反向旋转（虚线环 / 金弧环 / 细点环），中心呼吸的青色六边形（`M` 作地铁标识）。
- 文案：「智慧地铁」渐变标题 + `SMART METRO · OPERATION CENTER` 副标。
- 进度条：4px 细线，填充带扫光，头部菱形光标，10 个刻度；右下角大号百分比带惯性追赶（不跳数）。
- 阶段清单五行：进行中亮起、完成打勾变青；底部 `SYS.BOOT // 3D-TILES PIPELINE` + 实时瓦片计数。

## 4. 进度挂在真实事件上（不是假动画）

| 阶段 | 触发点 | 进度 |
|---|---|---|
| 初始化三维引擎 | `initViewer()` 返回 | 12% |
| 载入城市底图 | 腾讯影像图层挂上 | 20% |
| 解析城市三维模型 | 两个 tileset 的 `readyPromise` 均 resolve | 48% |
| 合成光照与水体特效 | 水体/流光/昼夜 shader 挂完 | 60% |
| 等待首屏瓦片 | 进入瓦片阶段 | 70% |
| 每加载一块瓦片 | `tileset.tileLoad` 事件 | 70→97% 饱和曲线 |

真正的「可以见人」信号是 `initialTilesLoaded`（首屏视角所需瓦片全部到位）才淡出。

## 5. 三重兜底（关键设计，避免把用户锁死）

- 缓存命中时 `initialTilesLoaded` 可能不触发 → 1.2s 后若已无待加载瓦片直接放行。
- 25s 首屏瓦片等待硬超时（写在 `cesiumView.vue`）；40s 看门狗（`SciFiLoader.vue` 的 `WATCHDOG_MS`）。
- `loadTilesets` 抛错时 `fail()` 兜底；`MIN_SHOW_MS = 1800` 保证本地秒开也不会闪一下。

## 6. 可调旋钮与验证方法

- `loadingState.js`：`MIN_SHOW_MS`（最短停留）、`LOAD_STEPS`（阶段文案）。
- `cesiumView.vue`：`setTimeout(done, 25000)`（首屏瓦片等待上限）。
- `SciFiLoader.vue`：`WATCHDOG_MS`；标题/副标在 `<h1 class="boot-title">`、`.boot-sub`。
- 不依赖浏览器也能做编译校验：直接请求 Vite 转换接口，编译错误会以 500 返回 ——
  `http://localhost:5173/src/App.vue`、`/src/views/cesiumView.vue`、`/src/components/loading/SciFiLoader.vue`、`/src/stores/loadingState.js` 全 200 即通过；再核对 `index.html` 中含 `boot-splash`。
- 浏览器桥接当时不可用（`no browser extension is connected`，操作被 `USER_CONTROL` 拦下），**视觉效果未由助手确认**，需用户硬刷（Ctrl+Shift+R）目视验收。

## 7. 未决/待用户定稿项

节奏快慢、是否改成「加载完成 → 点击进入」、六边形内换线路 SVG、加数字雨/粒子流等第二层动效、标题文案是否改为「上海轨道交通 · 智慧运营中心」。定稿后才会把整套搬到工作区 `智慧地铁_上线版/Project` 并一起打包。

## 8. 附带测得的白膜 LOD 体量（决策依据）

同一时段按块统计的 glb 体量（0.35MB/s 上传估时）：L10 12 块 23.1MB（约 66s）、L11 41 块 244.3MB、L12 127 块 826.9MB、L13 374 块 1,521.0MB、L14 1113 块 2,221.9MB、L15 3392 块 2,916.6MB、L16 10525 块 3,660.2MB。
结论：用户城市全是**白膜**，不需要深层几何体，直接用 L10 即可（23.1MB 量级、分钟级上传）。
