---
id: "34066e27-5ad4-41df-8448-8029411158f8"
title: "Translation 智慧地铁：发展历程栏目（/strategy → historyPanel.vue）纯外观版 + 上海地铁 1–18 号线建设历程数据集与采集管线"
description: "2026-10-12 新建发展历程面板（左线路/右时间轴，含播放暂停重播三按钮），与站点管理同壳但**不收起左右侧栏**（原因：stationPanelOpen 由路由推导，只对 /nodes 为 true）；含时间轴「每节点自带半段连线」的画法、18 条线建设历程数据的双源交叉核对采集管线（china-emu.cn 线路页 + Wikidata Q462201/P1619）、剔除停运与改名的规则、各线节点数与实机验证数据。"
status: "active"
created_at: "2026-10-12T09:30:21.142Z"
updated_at: "2026-10-12T09:30:21.142Z"
content_hash: "45505a1e29027248c4daed01e10eade66c1fb97aa5ec3211df08a425c7befd6b"
source_paths:
  - "Translation/src/components/bottom/HistoryPanel/historyPanel.vue"
  - "Translation/src/config/shmetroHistory.js"
  - "Translation/src/router/index.js"
session_ids:
  - "session-d6cbf69c-ac7f-4b6b-a2a9-8468919b087a"
memory_body_ids:
  []
---

# 发展历程栏目（纯外观版）+ 上海地铁建设历程数据集

日期：2026-10-12。项目：`D:\WebGIS\web三维开发\智慧地铁项目\Translation`。
需求：「先帮我构建纯外观，没用功能的组件。在 historyPanel.vue 中编写点击发展历程的组件，构造和站点管理现在的构造类似，不过不用隐藏大屏组件 left 和 right 系列。左侧仍然是地铁线路，不过右侧变成了各地铁的历史发展进程……需要收集上海地铁 1-18 号线的建设历程，不用太多，要求不出现拉动条，能全部装下，同时文档中有的播放、暂停、刷新按钮也加上。」

## 1. 交付物与改动文件

| 文件 | 状态 | 说明 |
|---|---|---|
| `Translation/src/components/bottom/HistoryPanel/historyPanel.vue` | 新增 | 面板本体（约 500 行，含 scoped 样式） |
| `Translation/src/config/shmetroHistory.js` | 新增 | 上海地铁 1–18 号线建设历程数据 + `lineNumberOf` / `historyOfLine` 两个取值助手 |
| `Translation/src/router/index.js` | 改 | `/strategy` 由 `EmptyView` 改为懒加载 `historyPanel.vue` |

## 2. 「不收起左右侧栏」是怎么来的（不需要改任何代码）

`panel.vue:63` 与 `panel.vue:69` 给左右两组侧栏写的是 `v-show="!stationPanelOpen"`，
而 `stationPanelOpen` 在 `stores/stationState.js:20` 是**由路由推导**的：

```js
const stationPanelOpen = computed(() => router.currentRoute.value.path === '/nodes');
```

它只对 `/nodes` 为 `true`，所以 `/strategy` 天然保持左右侧栏可见 —— 本轮**一行都没动 panel.vue**。
实测（同一浏览器会话）：`/nodes` 时 `sideLeft/sideRight` 的 computed `display` 都是 `none`；
点底部导航「发展历程」跳到 `/strategy` 后两者都变回 `grid`，同时 `.station-panel` 卸载、`.history-panel` 挂载。

**注意反过来也成立**：如果以后想让某个新栏目也收起侧栏，不要去改 panel.vue 的模板，而是改 `stationPanelOpen` 的推导条件（单一路由判断），否则会出现两处真相。

## 3. 与站点管理（StationPanel.vue）一致与不一致的地方

沿用：Teleport 到 `.hud-canvas`（`defer`）、`Transition` 出入场、左右双栏外壳、同样的设计令牌与
`clip-path` 切角、同样的几何（`left:50%; bottom:145px; width:1040px; height:232px; gap:9px`）。
实测新面板矩形 `x=440 y=703 w=1040 h=232`，与 StationPanel 完全重合，两栏目互切面板不跳；
左右侧栏各占 422.4px（x 0–422.4 / 1497.6–1920），1040 宽居中正好落在中间可用带里，**不遮挡侧栏**。

有意不一致：
1. **左栏去掉了方形显隐勾选框**。发展历程不控制三维显隐，留一个点不动的方框只会让人以为它坏了；整行都是「切换右栏」的点击目标。
2. **右栏是时间轴而不是站点网格**。

## 4. 时间轴的画法（可复用的小技巧）

没有用「一条通栏绝对定位的轨道 + 一条按百分比填充的进度条」——那种写法要用 `calc(50% / n)` 才能让轨道两端对齐到首尾圆点的圆心，`n` 一变就得重算。

改成**每个节点自带左右两个半段连线**：

```css
.hp-mark::before { left: 0;  right: 50%; }   /* 与上一个圆点之间的那半段 */
.hp-mark::after  { left: 50%; right: 0;   }  /* 与下一个圆点之间的那半段 */
.hp-mark:first-child::before,
.hp-mark:last-child::after { display: none; } /* 首尾各去掉半段，轨道正好首尾齐平 */
```

相邻节点的两个半段接起来就是一整节轨道，**节点数量随便变，首尾永远对齐**。三态只用背景色区分：

- `is-done`（下标 < 当前）→ 两侧半段都亮成线路色；
- `is-current` → **只亮左侧半段**，右侧留给「还没走到」；
- `is-pending` → 两侧都不亮（灰）。

节点本身 `.hp-dot` 是 12px 圆点（`background:#061020` 盖住轨道 + 2px 边框）；
当前节点放大到 14px + 外发光 + 呼吸动画，是整条轴上的视觉焦点。
线路色通过根元素上的 `--line-color` 传下来（取 `LINE_COLORS[index % 12]`，与三维光锥同源）。

## 5. 上海地铁 1–18 号线建设历程数据

### 5.1 采集管线（双源交叉核对）

| 步骤 | 做法 |
|---|---|
| ① 主源 | `china-emu.cn` 每线路页的「发展历程」表。URL 规律：`https://www.china-emu.cn/UrbanRails/Line/3100<两位线号>/`（`310001`=1号线 … `310018`=18号线）。用 Playwright 抓 18 页，取 `innerText` 里 `发展历程` → `线路制式` 之间的片段，按「日期/描述」成对切分（原文每对重复一次，需去重） |
| ② 校验源 | Wikidata。**上海地铁系统条目是 `wd:Q462201`**（注意：`P361 part-of` 查不出全部线路，只有 5 条挂了这层关系，不可靠）。改为逐线用 `wbsearchentities` 取 Q-id（搜「上海轨道交通N号线」），再用 `VALUES` 一次性查 `P1619`（正式开通日期）/`P571` |
| ③ 核对结果 | 18 条里 **16 条首通日期完全一致**；2 条口径不同，保留主源的分段口径：**2 号线**（本站 1999-09-20 通车 / Wikidata P1619 记 2000-06-11，其 P571 正是 1999-09-20）、**13 号线**（本站首条 2010-04-20 世博专线段 / Wikidata P1619 记 2012-12-30 金运路至金沙江路） |

### 5.2 清洗规则

**剔除**：临时「停运 / 恢复运营」（世纪大道、海伦路、人民广场、张江高科等改造停运共 10 余条）与
「站名更改」（如「虹梅路改名锦江乐园开通」）——它们不属于线路建设里程碑。
留着的话 2 号线会变成 13 条、3 号线变成 10 条，其中一半是「停运/恢复」这种同日往返的噪声。

### 5.3 各线节点数（清洗后）

| 线 | 节点 | 区间 | 线 | 节点 | 区间 |
|---|---|---|---|---|---|
| 1 | 7 | 1993-05 → 2007-12 | 10 | 3 | 2010-04 → 2020-12 |
| 2 | 8 | 1999-09 → 2025-11 | 11 | 8 | 2009-12 → 2020-08 |
| 3 | 2 | 2000-12 → 2006-12 | 12 | 3 | 2013-12 → 2015-12 |
| 4 | 3 | 2005-12 → 2007-12 | 13 | 7 | 2010-04 → 2018-12 |
| 5 | 2 | 2003-11 → 2018-12 | 14 | **1** | 2021-12 |
| 6 | 2 | 2007-12 → 2011-04 | 15 | **1** | 2021-01 |
| 7 | 5 | 2009-12 → 2014-07 | 16 | 2 | 2013-12 → 2014-12 |
| 8 | 4 | 2007-12 → 2012-09 | 17 | 2 | 2017-12 → 2024-11 |
| 9 | 6 | 2007-12 → 2017-12 | 18 | 3 | 2020-12 → 2025-12 |

**最多 8 个节点**（2 号线、11 号线），这是「不出现拉动条」的关键数字。
14/15 号线只有 1 条不是漏抓：这两条线 2021 年一次性开通，没有分段延伸。

数据字段：`{ time: '1993-05', date: '1993-05-28', text: '锦江乐园至徐家汇开通' }`
—— `time` 给时间轴刻度用，`date` 给完整日期展示与 title 提示用。

## 6. 实机验证（1920×1080 真实 Chrome，`/strategy`）

| 检查项 | 结果 |
|---|---|
| 面板矩形 | `x=440 y=703 w=1040 h=232`（与 StationPanel 完全一致） |
| 左右侧栏 | `sideLeftVisible: true`、`sideRightVisible: true`（`display: grid`） |
| 无滚动条 | `.hp-body-lines` 与 `.hp-body-history` 均为 `scrollHeight 195 == clientHeight 195`（1 号线 7 节点与 11 号线 8 节点两种情况都测了） |
| 左栏线路 | 18 条，文本 `1号线 … 18号线`，色块与 `LINE_COLORS` 前 6 位实测一致（`rgb(58,160,255)` 等） |
| 1 号线时间轴 | 7 个刻度、3 个已走完 + 1 个当前（1997-07）+ 3 个未到，当前点 `14px` |
| 里程碑文案 | `1997-07-01 莘庄~上海火车站贯通，原锦江乐园废弃开通` |
| 播放控件 | 3 个按钮，`title` 依次为「暂停 / 播放 / 重新播放」，`elementFromPoint` 命中的是按钮内部的 `path`（即真的可点，没被别的层盖住） |
| 切换线路 | 点「5号线」→ 2 个刻度 `2003-11 / 2018-12`、文案与聚焦行同步切换；点「11号线」→ 8 个刻度无滚动条 |
| 路由切换 | `/nodes`（侧栏 `none`、`.station-panel` 在）→ 点导航「发展历程」→ `/strategy`（侧栏 `grid`、`.history-panel` 在、`.station-panel` 已卸载） |
| 控制台 | 无新增报错；仅剩既有的腾讯底图瓦片 400（`rt*.map.gtimg.com/tile?z=`） |

截图：`.review/history-panel-clean.png`、`.review/history-panel-line11.png`。

## 7. 本轮**有意没接**的东西（下一步再做）

1. **三个按钮是纯外观**：只有 hover / active 反馈，没有绑定任何点击逻辑。
2. **「当前节点」是固定下标** `max(0, floor((len-1)/2))`（取正中间），只用来把「已走完 / 当前 / 未到」三种状态一次性展示出来。接播放逻辑后它会由 `currentTime` 推出来。
3. **完全不碰三维**：不隐藏线路、不飞行相机、不驱动线路生长。要接生长动画，
   参考项目 `综合项目：智慧地铁/smart-subway-warehouse/src/views/Progress.vue` 的做法是
   `entity.polyline.positions = new Cesium.CallbackProperty(() => Cesium.Cartesian3.fromDegreesArray(curPaths), false)`
   （第二个参数 `isConstant=false` 是关键）——**但它依赖参考项目的 `renderAll(viewer, item, false)` /
   `removeByCacheData` / `flattenPositions`，这三个函数在本项目 `Translation` 里都不存在**，
   本项目对应的建线代码是 `src/cesiumTools/lineAndpoints/line/setlines.js`（同样是 `viewer.entities.add({ polyline })` + 扁平 `[lng,lat,…]`，
   差异在材质是 `PolylineFlowMaterialProperty`，且 `setlines.js:16` 有 `positions.length < 4` 的守卫，
   所以要在**建完实体之后**替换 `positions`，不能拿 2 个点去建）。
