---
id: "f3e88214-9bd9-4a3f-bfb7-4d1bd0125017"
title: "DSH 多智能体委派机制：是否存在「工程量大就自动编排」（2026-10-10，本机 desktop profile 实测）"
description: "在 DSH 安装目录内逐项核实后确认：DSH 没有「复杂度→自动升级多智能体」的规则，委派只由显式工具调用或 preset 决定；记录 subagent/workflow/ralph/Agent Team 的门禁措辞、唯一的两处自动行为、设置旋钮实为预算、以及想固定流程时的正确落点（preset）。含关键源码路径，承接文档 ab5164f9。"
status: "active"
created_at: "2026-10-10T09:09:35.442Z"
updated_at: "2026-10-10T09:09:35.442Z"
content_hash: "2d7012699b088263ff5e2e936066b5858348e7358886d515fd1ceec8f872fd91"
source_paths:
  - "node_modules/@deepseek-ai/dsh-tool-workflow/README.zh.md"
  - "node_modules/@deepseek-ai/dsh-tool-ralph/README.zh.md"
  - "node_modules/@deepseek-ai/dsh-experimental-agent-team/README.zh.md"
  - "node_modules/@deepseek-ai/dsh-client-ui-settings-subagent/README.zh.md"
  - "node_modules/@deepseek-ai/dsh-subagent/README.zh.md"
  - "node_modules/@deepseek-ai/dsh-goal-round-driver/README.zh.md"
  - "node_modules/@deepseek-ai/dsh-agent-preset-registry/README.zh.md"
  - "desktop/cordis.patch.yml"
session_ids:
  - "d137e465-9fe2-4c6c-b418-2f59b33540ba"
memory_body_ids:
  []
---

# DSH 多智能体委派机制：会「工程量大就自动编排」吗

**结论：不会。** 在 DSH 安装树里核实后，没有任何「任务复杂度 → 自动升级为多智能体编排」的规则或阈值。是否走「大纲 / 架构 / worker 三层编排」只取决于两件事：**谁显式调用了委派工具**，以及**当前 preset 是否把编排写进了提示词与工具面**。

调查时间：2026-10-10，环境：本机 desktop profile（框架包由 Electron 外壳打包，路径来源与布局见文档 `ab5164f9-c8fb-4ebb-befe-305e70609cb7`）。用户原始疑问来自网上「一个 AI 做大纲、一个 AI 做架构、下面不同 AI 干活」的说法，以及「DSH 跑这套逻辑是否需要指定触发」的追问。

## 1. 没有自动触发器，只有显式工具

| 工具 | 触发方式 | 官方 README 措辞 |
|---|---|---|
| `subagent` / `subagent_fork` | 模型自己调用 | 纯工具，无阈值 |
| `workflow` | **必须用户明确要求** | 「仅当用户明确要求工作流或大型多 agent 编排时使用；一两项委派应优先使用普通 subagent 调用」 |
| `ralph` | **必须直接用户明确要求** | 「仅当直接用户明确要求 Ralph 式全新 agent 迭代时使用；普通的长期工作请使用 goal 工具」 |
| Agent Team（`teamRun` / 任务板卡） | 建卡时勾选 | 需部署支持 Agent Teams 服务，否则直接拒绝 |

- `workflow` 是模型编写的 JavaScript 编排脚本，扇出 subagent 并返回最终 JSON；前台运行会阻塞到全部结束，支持 `run_in_background`。
- `ralph` 是固定前台循环：每 Round 一个全新子 agent，只传不可变目标 + 上一份有界结构化报告，父级对话绝不作为种子；终态 `complete` / `blocked` / `budget-limited`。
- 这两条门禁措辞写在包 README 里，是可核对的硬约束，不是推断。

源码路径：
- `node_modules/@deepseek-ai/dsh-tool-workflow/README.zh.md`
- `node_modules/@deepseek-ai/dsh-tool-ralph/README.zh.md`

## 2. 真正的「自动」只有两处，都不是编排

1. **goal 续轮**：`dsh-goal-round-driver` 在 goal 为 active 且整个 agent 进入 idle 时自动开下一轮——但仍是**同一个 agent 继续干**，不会派生下位 agent（其 README 通篇无 subagent 参与调度的描述）。轮次因 max tokens 结束、持久化写失败、取消、插件卸载或 Round 上限耗尽都会自行停止。
2. **后台任务 / 提醒的完成通知**：纯通知，不生成 agent。

源码路径：`node_modules/@deepseek-ai/dsh-goal-round-driver/README.zh.md`。

## 3. 设置里的旋钮是「预算」，不是「触发器」

插件 → 子智能体页面（`dsh-client-ui-settings-subagent`）只有三类字段：

- **最大递归深度** `maxDepth`：Host `subagent` 设置默认 `1`（只允许直接子代理，子 agent 默认**无法**继续向下派）；`0` 禁止委派。工具显式指定的深度（含 `provider-managed`）优先于该设置；修改在下一次委派时生效。
- **子智能体并行数量上限**：统计同一主 Agent 下所有层级存活子智能体，主 Agent 不计入。
- **子 agent 可用模型路由**：`subagent-model-selection` 命名空间。

这些决定「能派多广多深」，不决定「要不要派」。要做出「架构层再往下派」必须先调 `maxDepth = 2`，否则第二层委派会被拒绝。

源码路径：`node_modules/@deepseek-ai/dsh-client-ui-settings-subagent/README.zh.md`、`node_modules/@deepseek-ai/dsh-subagent/README.zh.md`。

## 4. 环境里唯一的「推力」是提示词，不是规则

subagent 工具可见时，系统提示词会多一句「Start independent subagent delegations together in one assistant message and continue useful work while they run.」。这是建议，不是门禁。所以现实中「它自己派活了」多半是**模型自己的判断**——真实存在，但不可靠，也不由 DSH 保证。

## 5. 想让某套流程成为默认：唯一正路是 preset

DSH 的分层是 **Agent preset 决定这个会话挂哪些工具、吃什么提示词、带哪些技能**（`dsh-agent-preset-registry` 自述即此；注册表不扫描目录、不接受 preset 路径，新建或覆盖内置 preset 都是 bundle 补丁 + `plugin_manager` 安装到 profile）。因此：

- **默认情况**：preset 只给通用工具 → 编不编排取决于模型判断与用户措辞。
- **要「默认」**：写一个自己的 preset，在提示词里写死「多步任务先出大纲 → 再出架构与接口契约 → 再派 worker → 最后合并验收」，并把委派深度调到 2。此后该 preset 下所有会话默认走这套流程——但这是用户规定的，不是 DSH 自带。

源码路径：`node_modules/@deepseek-ai/dsh-agent-preset-registry/README.zh.md`。

## 6. Agent Team 是真实实现，但实验性且需显式挂载

`dsh-experimental-agent-team` 提供 Lead + 具名 teammate + 持久 mailbox + 共享任务板 + DAG 依赖 + CAS 认领，消息与任务状态能挺过崩溃与 reload。关键约束：

- 本身不带工具，必须与兄弟包 `dsh-experimental-tool-agent-team` 一起挂载。
- 需要持久会话存储才能激活；最小增量为 `dsh-session-persistence-jsonl` + 上面两个包。
- 上限：`maxMembers` 16、`maxTasks` 256、`maxPendingMessagesPerMember` 64、`maxMessageBytes` 65536、`disposalTimeoutMs` 5000。
- 单进程内协作，保证是重试 + 去重，不是跨进程共识；不支持独立工作目录、多进程共管同一团队、任务 owner 自动释放。

**本机 desktop profile 未挂载该包**（2026-10-10 激活清单见文档 `ab5164f9-c8fb-4ebb-befe-305e70609cb7`），该会话中不存在 teammate 工具。

源码路径：`node_modules/@deepseek-ai/dsh-experimental-agent-team/README.zh.md`。

## 7. 实操结论

1. **轻量**：干大活时开头一句话说明要「大纲 → 架构 → 并行 worker → 合并」。
2. **硬核**：做自己的编排 preset，或挂 Agent Team 包，从会话层面固定为团队。
3. **注意深度**：`maxDepth` 默认 1，要第二层委派必须先调到 2。
4. **何时值得升级**：子任务互不依赖、各自需要大量**互不重叠**的上下文（例如读不同目录）、单件产出能独立验证 → 值得。任务是串行链路、都改同一文件、总共十几步 → 自己干更快。

## 相关文档

- `ab5164f9-c8fb-4ebb-befe-305e70609cb7`：本机 DSH 框架版本来源、desktop profile 激活清单与外壳补丁运维缺口（本机包布局与插件挂载状态的依据）。
