---
id: "0c3bdc53-a34d-44be-9686-bbdf4f950e01"
title: "站点光锥「缺乏动感」成因分析与动效改造方案（cone.glsl st 语义 / 加色混合正确接法 / 五档改法排序）"
description: "Translation 站点光锥观感偏\"死\"的三层成因：帧驱动 12Hz 方波呼吸、CylinderGeometry st 导致 alpha 线性衰减（上 2/3 不可见）、ALPHA_BLEND 而非加色混合；给出 h=1-dis*2 高度提取、覆盖 Appearance.getRenderState 换 ADDITIVE_BLEND 的可复制写法，以及加色/呼吸/竖直流光带/地面涟漪/换乘站差异化的性价比排序。"
status: "active"
created_at: "2026-10-20T01:20:35.409Z"
updated_at: "2026-10-20T01:20:35.409Z"
content_hash: "5bbb5e1c1fa3e40f752b5b8a8495731b7f8ba1662f5b372be98a921282271131"
source_paths:
  - "Translation/src/cesiumTools/lineAndpoints/points/circleAndcone/cone.glsl"
  - "Translation/src/cesiumTools/lineAndpoints/points/circleAndcone/setcone.js"
  - "Translation/src/cesiumTools/lineAndpoints/points/circleAndcone/circleglow.glsl"
  - "Translation/src/cesiumTools/lineAndpoints/points/setpoints.js"
  - "Translation/src/components/bottom/Toolbar.vue"
  - "Translation/src/components/bottom/ActivePanel/ActivePanel.vue"
  - "Translation/node_modules/cesium/Source/Core/CylinderGeometry.js"
  - "Translation/node_modules/cesium/Source/Scene/Appearance.js"
  - "Translation/node_modules/cesium/Source/Scene/BlendingState.js"
session_ids:
  - "8f993742-df9e-4617-afe3-6ce14899cc43"
memory_body_ids:
  []
---

# 站点光锥「缺乏动感」：成因分析与改造方案

2026-10-20 通读 `circleAndcone` 全目录（cone.glsl / circleglow.glsl / 两个 MaterialProperty / setcone / setcircle / setpoints）后的设计复盘。用户诉求是「光锥缺乏动感、对现有着色器样式不满意」，本文只讲观感层，**尚未改代码**。性能与批处理背景见 `8d3c4c05-ec6a-4bb9-98de-8a40750572a5`（400 Primitive、帧驱动坑、光圈比锥底大 2.9 倍）；材质泛光调参见 `4d8d290c-8c3c-4257-910a-f5951dee59dc`。

## 1. 三层成因

### ① "闪烁"是 12Hz 方波，不是动画
[cone.glsl](Translation/src/cesiumTools/lineAndpoints/points/circleAndcone/cone.glsl) 用 `fract(czm_frameNumber / 10.0)` + `step(0.5, t)` 在两个亮度系数（约 2.0 / 1.5，仅差 25%）间每 5 帧翻转。60fps 下约 12Hz——人眼读不出节拍，只觉得"轻微抖动"，于是"静止的锥子在抖"。

注意：旧文档 `8d3c4c05` 按"10 帧一周、6Hz"记录过，本次按 `step(0.5)` 中点翻转读作 12Hz。**落实修改时以文件实际内容为准重新数一遍**，但结论不变：`czm_frameNumber` 是帧序号、不是秒，和同目录 [lightcolumn.glsl](Translation/src/cesiumTools/lineAndpoints/points/circleAndcone/lightcolumn.glsl) 的 `/60.0` 不一致。项目内正确做法是 `u_time`（秒），见 `DayorNight.js` 的 `syncShaderTime()`。

### ② 竖向无结构：alpha 其实是"到锥尖的距离"线性映射
`dis = distance(st, vec2(0.5))` 看似把 UV 当平面用错了，实为几何副产品：[CylinderGeometry.js:376-384](Translation/node_modules/cesium/Source/Core/CylinderGeometry.js#L376) 对所有顶点按 XY 平面投影归一化

```js
st = ((x + rad) / (2*rad), (y + rad) / (2*rad))   // rad = max(topRadius, bottomRadius)
```

`topRadius = 0` → 锥尖全落在 (0.5, 0.5)，锥底一圈落在半径 0.5 的圆上。故 `dis` = 锥底 0.5、锥尖 0，`alpha = dis * 2.0` 就是"底全亮 → 顶全透明"的**线性**衰减：上 2/3 几乎看不见，视觉重心挤在锥底。

好处是**不用改几何就能拿到归一化高度**：

```glsl
float h = 1.0 - dis * 2.0;   // 0 = 锥底, 1 = 锥尖
```

竖向动画（流动光带 `fract(h - t)`）全靠它。注意首尾 alpha 要衔接，否则出现横向接缝。

### ③ 用 ALPHA_BLEND 而非加色混合
[setcone.js:42](Translation/src/cesiumTools/lineAndpoints/points/circleAndcone/setcone.js) 只传 `translucent: true`，走标准 alpha 混合：叠加处互相压暗，"光"感大幅丢失。

关键坑：[Appearance.js:164-172](Translation/node_modules/cesium/Source/Scene/Appearance.js#L164) 中只要 `translucent: true` 就**强制**覆盖 blending：

```js
if (translucent) { rs.depthMask = false; rs.blending = BlendingState.ALPHA_BLEND; }
```

所以构造时传 `renderState: { blending: ADDITIVE_BLEND }` **无效**；改 `translucent: false` 又会被强制 `depthMask = true`，锥体变实心遮挡。正确做法是实例上盖掉方法：

```js
const appearance = new Cesium.MaterialAppearance({ material, translucent: true, closed: true });
appearance.getRenderState = () => ({
  depthTest: { enabled: true },
  depthMask: false,
  blending: Cesium.BlendingState.ADDITIVE_BLEND,
});
```

好消息：Cesium 1.97 的 `ADDITIVE_BLEND` 是 `(SRC_ALPHA, ONE)`（[BlendingState.js](Translation/node_modules/cesium/Source/Scene/BlendingState.js)），shader 输出的 `alpha` 仍当强度用，现有 GLSL 不必把 alpha 乘进 `diffuse`。

## 2. 改法排序（性价比）

| # | 改法 | 观感收益 | 改动量 | 风险 |
|---|---|---|---|---|
| ① | 换加色混合（上面的 getRenderState 覆盖） | 最直接，"半透明贴纸"→"光" | setcone 3~5 行 | 需覆盖实例方法，别改 translucent |
| ② | 12Hz 方波 → 0.6~1.2Hz 连续呼吸 | "抖"变"呼吸" | cone.glsl 5 行 | 无 |
| ③ | 竖向流动光带（`h` 驱动，可循环） | 动感主来源 | cone.glsl ~10 行 | 接缝 |
| ④ | 地面光圈也动（外扩涟漪 + 旋转扫描） | 锥动圈死会违和 | circleglow.glsl 重写 ~25 行 | 现贴图外缘 alpha=1 有硬边，需改 0 或纯 shader 画 |
| ⑤ | 换乘站差异化（反相/双脉冲/更快） | 400 站不同频，有层次与业务含义 | 材质加 1 uniform | 多传参数 |

推荐先 ①②③（只动 `cone.glsl` + `setcone.js` 三行），确认"活了"再上 ④，⑤ 最后。

## 3. 暂不动的两项

- **fresnel 边缘光**：现用 `MaterialSupport.ALL`? 否——`setcone.js:29` 用 `TEXTURED` vertexFormat，不带法线，`normalEC` 取不到。要边缘光必须换 `ALL`，属于第二轮质感打磨。
- **合并 400 个 Primitive**：站点显隐是逐站切 `show`（[setpoints.js:79](Translation/src/cesiumTools/lineAndpoints/points/setpoints.js#L79)），合并后需改成顶点属性；且本方案全在 fragment 层，不增加 draw call。

## 4. 待用户拍板

1. 气质取向：**科幻脉冲型**（竖带向上跑 + 顶端呼吸）还是**数据感型**（缓慢呼吸 + 偶发心跳爆发，监控大屏式克制）。
2. 换乘站是否更"躁"（更亮/更快/双脉冲），以便在 400 站中一眼识别。

## 5. 验证限制

GLSL 观感改动无法在本机截图验证（系统截图受限），只能保证"实体生成 + 无 Vite 报错"，**颜色/动态观感必须交人工复核**，不要声称已验证视觉效果。
