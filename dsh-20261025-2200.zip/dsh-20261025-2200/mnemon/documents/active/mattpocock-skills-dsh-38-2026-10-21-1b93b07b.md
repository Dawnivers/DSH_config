---
id: "1b93b07b-9e69-49ca-a289-336e4dcc1ded"
title: "mattpocock/skills 仓库对 DSH 的兼容性实测与选用评估（38 技能，2026-10-21）"
description: "第三方 agent skill 仓库 mattpocock/skills 接入 DSH 前评估：38/38 frontmatter 原生兼容（含调用控制字段名）、必须拍平并整目录拷贝、技能间硬依赖图、每轮 5402 字符描述常驻成本、本机 gh/bash 环境缺口，以及精选 12 个候选清单与当时未决的安装口径。"
status: "active"
created_at: "2026-10-21T01:49:47.862Z"
updated_at: "2026-10-21T01:49:47.862Z"
content_hash: "698edb4fc7d8d4e9b55e0aba28a3190802003ac32c3ad67fc378801da03e548b"
source_paths:
  []
session_ids:
  - "dc9cc377-a780-4fa3-83f7-4d07eea4e15d"
memory_body_ids:
  []
---

# mattpocock/skills 对 DSH 的兼容性实测与选用评估

日期：2026-10-21 · 环境：Windows，DSH Desktop（`desktop` profile）· 克隆点：`D:\tmp_skillcheck\src\mattpocock-skills-5beb35b`（38 个 SKILL.md）

相关文档：`f4e8bed3-21f4-4947-915a-10d14a3dbdcf`（DSH 技能目录发现规则 / skills-manager 递归深度 6 / 原生 loader 不递归）——本文的「拍平」结论直接复用该文档的源码证据，不重复论证。

## 1. 仓库定位

- 上游：[mattpocock/skills](https://github.com/mattpocock/skills)，MIT，`marketplace.json` + `plugin.json` 声明为 **Claude Code 插件**（name `mattpocock-skills`，category engineering）。
- 内容是「把工程纪律写成 Markdown」的流程库，明确反对 GSD / BMAD / Spec-Kit 式全流程接管，主张小而可改、可组合。
- 目录分 4 组：engineering 20、productivity 7、misc 4、in-progress 7（in-progress 作者自标未定稿）。
- 按可调用方分两类：用户调用型（frontmatter `disable-model-invocation: true`，只做 `/` 编排入口，如 `ask-matt`、`to-spec`、`to-tickets`、`implement`、`implement-spec`、`wayfinder`、`retro`）与模型调用型（可复用原语，如 `grilling`、`tdd`、`code-review`、`diagnosing-bugs`、`codebase-design`、`domain-modeling`、`writing-for-agents`）。

## 2. 格式兼容性：38/38 通过，无需改写

对照本机 `node_modules/@deepseek-ai/dsh-skill-filesystem/lib/index.js`（`discoverRoot` / `parseSkillFile` / `parseInvocationPolicy`，约 578–707 行）逐项核对：

| DSH 要求 | 仓库实际情况 |
|---|---|
| frontmatter 必须有 `name` + `description`，缺失即 ignore 并 warn | 38/38 齐备（描述总长 5402 字符，正文总长 169,123 字符） |
| `SKILL_NAME = /^[a-z0-9]+(?:-[a-z0-9]+)*$/` | 38 个名字全部 kebab-case 合法 |
| 调用控制字段 canonical 名 `disable-model-invocation` / `user-invocable`；旧名 `disableModelInvocation`/`modelInvocable`/`userInvocable` 会被 `rejectLegacyInvocationKey` 直接抛错 | 仓库用的正是 canonical 名，与 DSH 同一套约定 |
| 布尔容错：`true/1/"1"/yes/on` 与 `false/0/"0"/no/off` | 无越界写法 |
| 可选字段 `whenToUse`、`metadata` | 未使用，不冲突 |

结论：**格式原生兼容，不需要为 DSH 改任何一行 frontmatter**。

## 3. 两个落地前提（不满足就等于装了残件）

1. **必须拍平**：仓库结构是 `skills/<category>/<name>/SKILL.md`，而 DSH 原生 loader 只扫 skill 根目录顶层（`root/<dir>/SKILL.md` 或 `root/<file>.md`），嵌套层完全不可见 → 需摊到 `...\.dsh\skills\<name>\`。skills-manager 虽能递归到 6 层看见，但宿主注册是另一回事（见 `f4e8bed3`）。
2. **必须整目录拷贝**，不能只拷 SKILL.md：正文直接链接配套文件，例如 `tdd` 的 `tests.md`/`mocking.md`、`domain-modeling` 的 `ADR-FORMAT.md`、`setup-matt-pocock-skills` 6 个文件、`teach` 5 个文件。

## 4. 技能间硬依赖（拆开装 = 装断链）

- `grill-me`（157 B）、`grill-with-docs`（247 B）、`loop-me`、`writing-fragments`、`writing-shape` 都是路由壳，真正干活的底层原语是 **`grilling`**（被 6 个技能复用）。
- `implement` → `tdd` + `code-review`；`implement-spec` → `code-review`/`implement`/`pr`/`research`/`tdd`/`to-spec`/`to-tickets`；`triage`/`wayfinder`/`to-tickets` → `setup-matt-pocock-skills`（内含 GitHub / GitLab / 本地文件三种追踪器选择）。
- `ask-matt` 是总路由器，引用 26 个技能——单装它没有意义。

## 5. 两个有分量的技能（评估时点名）

- **`code-review`**：把 diff 拆成双轴——Standards（仓库文档规范 + Fowler 12 项坏味道基线；仓库规范恒高于基线，基线恒为「判断项」）与 Spec（对照原始 issue/spec），两轴各起一个 sub-agent 并行、互不污染上下文，最后**禁止合并或跨轴排序**，因为一条变更可以过一轴挂另一轴。
- **`writing-for-agents`**：讲 description 的措辞如何决定 agent 何时「够得到」这个 skill，基本是写 skill 本身的方法论。

## 6. 成本与本机环境缺口

- **常驻成本**：38 个全装 = 5402 字符描述进入每轮 system prompt（约 1.5–2k tokens），与是否触发无关。
- `gh` **未安装** → `triage`/`wayfinder`/`to-tickets` 的 GitHub 追踪器模式不可用（选「本地文件」追踪器可绕开）。
- `bash` 解析到 `C:\WINDOWS\system32\bash.exe`（WSL），而 `/wizard` 产出的向导脚本是 bash 脚本 → 真要用需指向 Git Bash。`git`、`node`、`npx` 均在。
- `misc/` 的 `scaffold-exercises`、`migrate-to-shoehorn`、`setup-ts-deep-modules` 面向 React/TS 课程项目，与用户主场景（Vue 智慧地铁、遥感、DSH 基建）基本无关。

## 7. 当时给出的方案与状态

- 观察：不安装也能用——skill 本质是 Markdown，可直接读文件按流程执行；安装的增量只有「出现在 设置 → 技能 面板」与「模型可自动触发」（`grilling`/`tdd`/`diagnosing-bugs` 这类自动触发价值最大）。
- 三个选项：全装 38 / 精选 12 / 只在当前项目 `.dsh/skills` 试水（项目级、不污染全局）。
- 精选 12 候选：`grilling`、`grill-me`、`grill-with-docs`、`tdd`、`diagnosing-bugs`、`code-review`、`pr`、`to-spec`、`to-tickets`、`implement`、`retro`、`writing-for-agents`。
- **状态：未决**。评估结束时把选择权交回用户，检查点内没有用户答复，因此没有实际安装动作、也没有选定目录层级。
