---
id: "09e80ef3-d680-4d1f-839e-4f82554f7247"
title: "OpenLayers 服务平台 Vue 版平行项目蓝图（Project-vue：版本定版、目录契约与验收，待用户拍板）"
description: "openlayers服务平台开发 在 D3 vanilla 闭环之后提出的「另建平行 Vue 项目」方案：不改造现有 Project 的理由、2026-10 实测版本矩阵（vue 3.5.44 / vite 8.3.5 / ol 10.11.0 / plugin-vue 6.0.10，router 5 与 pinia 4 暂不装）、scaffold 与 proxy 搬迁、src 目录职责、useMap composable 契约、四条铁律、vanilla→Vue 文件对应表、验收标准（含卸载证实）。方案提出时用户尚未选定放哪/谁动手。"
status: "active"
created_at: "2026-10-24T11:10:25.920Z"
updated_at: "2026-10-24T11:10:25.920Z"
content_hash: "f58b904952bc921c6f974bc86ce3fde77ed8df3bb9b6284d1118a24ae868f5b4"
source_paths:
  - "Project/src/main.js"
  - "Project/index.html"
  - "Project/vite.config.js"
session_ids:
  - "35cc0553-79c2-4be0-8fb7-0fd080cb95c2"
memory_body_ids:
  []
---

# Vue 版平行项目蓝图（Project-vue）

> 承接 vanilla 架构文档 `74b0dea8-c01f-4df9-b499-4b3fc3b0ae0a`（UI 三种来源、图层注册表、D12 迁 Vue 检查单）与项目设计文档 `266aea70-7a25-4d94-8359-39555b8b651f`（18 天里程碑、版本基线）。本文只记录**新增的一层决策**：在 D3 vanilla 闭环验收之后，是否/如何另起一个 Vue 版项目，以及它的版本、目录与契约。
> **状态：方案已提出，用户尚未拍板**（放哪：平行 `Project-vue` / 改造 `Project` / 先只搭空壳验证 `markRaw`；谁动手：助手搭壳 + 用户写 `src`，或全部用户自己敲）。

## 1. 为什么是「平行项目」而不是「改造现有 Project」

- 时间账：完整重写约 2–4 小时（有 Vue3 + Cesium 经验，换的只是地图库）；直接改 `Project` 会出现「改到一半两天不能跑」，且既有踩坑记录与代码对不上。
- 拖到 D12 再迁的代价：要同时学框架 + 学 OL 交互，两件事挤在一起。
- 关键判断：**前端框架不影响投递**。目标是 Java 后端岗，D5 Spring Boot / D6 MyBatis 才决定成败，所以 Vue 版必须压缩在 2 小时内、只等价重写 D3 已验收部分。
- vanilla 版冻结，作为踩坑证据与面试对照材料；D12 交互、D13 热力图直接长在 Vue 版上，不再迁第二次。

## 2. 版本定版（2026-10 本机 registry 实测）

| 包 | 版本 | 决策 |
|---|---|---|
| `vue` | 3.5.44 | 装 |
| `vite` | 8.3.5 | 装；与 vanilla 版同版本，proxy 配置可原样搬 |
| `@vitejs/plugin-vue` | 6.0.10 | 装（SFC 编译） |
| `ol` | 10.11.0 | 装；与 vanilla 版同版本 |
| `vue-router` | 5.4.0 | **暂不装**（单页大屏用不上）。若将来要用：[官方迁移文档](https://router.vuejs.org/guide/migration/v4-to-v5) 明确「不用 unplugin-vue-router 文件路由则 v4→v5 零破坏性变更」，唯一例外是 iife 构建不再含 `@vue/devtools-api` |
| `pinia` | 4.1.0 | **暂不装**；它是新主版本，等真要接 store（D12）再逐条核 changelog，现在装只是负担 |

环境：Node 24.16 + pnpm 11.8（Vite 8 要求 Node ≥ 20.19，满足）。

## 3. 脚手架

```powershell
cd D:\WebGIS\web二维开发\openlayers服务平台开发
pnpm create vite Project-vue --template vue
cd Project-vue
pnpm install
pnpm add ol
```

用 `--template vue` 而非 `create-vue`：后者会连问 TS/JSX/Router/Pinia/Vitest/E2E/ESLint/Prettier 八项，当下八项全该选 No，不如直接拿只有 `vue` 一个依赖的干净模板。

数据侧零改动：同一个 GeoServer、同一份 `wuhan.json`、同一个 `/geoserver` proxy（`vite.config.js` 里那 7 行原样搬），`plugins` 里加 `vue()`。

## 4. 目录职责（为 D12 铺路，不是玩具骨架）

```
Project-vue/
├── index.html              只剩 <div id="app"> + 入口 script
├── vite.config.js          plugin-vue + /geoserver proxy
├── .env                    VITE_TDT_KEY=xxx        ← 天地图 key 走这里
└── src/
    ├── main.js             createApp(App).mount('#app')
    ├── App.vue             全屏容器 → <MapView />
    ├── styles/main.css     reset + #app{height:100%} 链；hud.css 到 D12 再写
    ├── map/
    │   ├── useMap.js       ★ 核心 composable：建图/销毁
    │   ├── layers.js       ★ LAYERS 注册表（纯数据，不放组件）
    │   ├── basemaps.js     天地图 URL 工厂（tk 从 env 读）
    │   └── wms.js          ImageWMS 工厂（LAYERS/VERSION 常量）
    └── components/MapView.vue  只负责「给一个 div，挂上地图」
```

与 vanilla 目录一一对应，差别只是「工厂函数 + destroy」换成「composable + onBeforeUnmount」。

## 5. 四条铁律（Vue 版相对 vanilla 的唯一实质差别）

| 铁律 | 不遵守的症状 |
|---|---|
| `shallowRef` + `markRaw` 包 OL 实例 | 地图能出但拖不动/缩放失灵（Proxy 破坏对象身份） |
| 地图必须在 `onMounted` 之后创建 | `target` 是空 ref，`new Map` 后一片空白 |
| `onBeforeUnmount`：`map.setTarget(undefined)` + 摘监听 + `ro.disconnect()` | 切页/热更新后旧地图后台继续跑，内存翻倍 |
| 天地图 `tk` 走 `.env`（`VITE_TDT_KEY`） | 旧代码硬编码的 key 一上 GitHub 就泄露 |

## 6. `useMap.js` 契约（结构约定，非抄写模板）

```js
export function useMap({ target, layers, center, zoom }) {
  const mapRef = shallowRef(null)   // 装 Map 实例：shallowRef + markRaw
  let resizeObserver = null

  function init() {                 // 1 new View（默认 3857，fromLonLat 传经纬度）
                                    // 2 new Map({ target: target.value, layers, view, controls })
                                    // 3 mapRef.value = markRaw(map)
                                    // 4 map.updateSize()（首帧保险）
                                    // 5 ResizeObserver → map.updateSize()
  }
  function destroy() {              // 1 ro.disconnect() 2 map.setTarget(undefined) 3 mapRef.value = null
  }
  onMounted(init); onBeforeUnmount(destroy)
  return { mapRef }                 // 只暴露实例引用，不逐层导出 View/Layer
}
```

返回值取舍：只返回 `mapRef`，要用图层就 `mapRef.value.getLayers()` 反查或用 `layers` 注册表——保证「地图的唯一真源」只有一个，避免「手里有个 layer 变量，但 map 里是另一个」。

`MapView.vue` 薄成一层皮：`const el = ref(null)`，`useMap({ target: el, ... })`，模板里 `<div ref="el" class="map-root">`。**`target` 传 ref 元素而不是字符串 id**——这是 Vue 版比 vanilla 干净处：DOM 由框架给，不再靠 `getElementById` 猜先后。

## 7. vanilla → Vue 对应关系

| vanilla（现有 `Project`） | Vue 版 |
|---|---|
| `index.html` 的 `<div id="map">` | `App.vue` 的 `<MapView />`，id 消失 |
| `main.js` 第 3–11 行 import | `MapView.vue` + `useMap.js` 各取所需 |
| `main.js` 第 15–20 行 CONFIG | `map/wms.js` 常量 + `.env` 的 tk |
| `main.js` 第 23–33 行 天地图两层 | `map/basemaps.js` 工厂（传 kind 返回 TileLayer） |
| `main.js` 第 36–47 行 WMS 图层 | `map/wms.js` 的 `createAdminLayer()` |
| `main.js` 第 50–61 行 View / Map | `useMap.js` 的 `init()` |
| `main.js` 第 62–64 行 addLayer | `layers` 一次性传入，或 `layers.js` 注册表 `forEach` |
| `vite.config.js` | 原样搬，`plugins` 加 `vue()` |
| `src/style.css` | `styles/main.css`，`#map` → `.map-root` |

`VERSION: '1.1.1'`、`serverType: 'geoserver'`、`ratio: 1.5`、`opacity: 0.7` 等参数与框架无关，一个字不用改——「先学 vanilla 再上框架」的收益。

## 8. 验收标准

| 判据 | 通过标准 |
|---|---|
| 起服务 | `pnpm dev` 起在 5175（5173/5174 已被占） |
| 全屏无白块 | `html,body,#app,.map-root` 全链 `height:100%` |
| 底图 + 区划 | 天地图影像 + 注记 + 13 区叠加，与 vanilla 版肉眼一致 |
| 拖动跟随 | 拖到隔壁城市再拖回，区划跟着走（与 D3 同一判据） |
| 控制台 | 无 Vue 警告、无 OL 警告 |
| **卸载干净** | `v-if` 切掉 `<MapView />` 再切回：不报错、不重复建图、内存不涨 |
| 证据 | 截图 + `pnpm build` 能过 |

「卸载干净」是 Vue 版特有项，也是面试官问「怎么保证组件销毁时地图释放了」的唯一实证。
