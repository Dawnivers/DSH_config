---
id: "8d3c4c05-ec6a-4bb9-98de-8a40750572a5"
title: "Translation 智慧地铁站点特效（光锥/光圈）实现链路与实测复盘：线路开关脱节、帧率驱动着色器、400 个未批处理 Primitive"
description: "2026-10-10 对 Toolbar.vue 新增站点渲染功能的代码+实机复查：渲染链路（renderStationMarkers→coneWithLight 光锥 Primitive / bottomCircle 光圈 Entity）、站名去重与换乘站数据正确性、draw call 589→1416 与真实窗口 A/B 实测 −5.7 FPS（−20%），以及 7 项问题（线路开关管不到站点、cone.glsl 与 polyGlowflow.glsl 退回 czm_frameNumber 帧驱动、未按颜色批处理、光圈比光锥底大 2.9 倍、isConstant 逻辑写反）与 P0–P3 修法排序。"
status: "active"
created_at: "2026-10-10T09:30:13.699Z"
updated_at: "2026-10-10T09:30:13.699Z"
content_hash: "85d470373369e11b4d696519485eef17c0d2ee65f918e966cfa367c3e1709aee"
source_paths:
  - "Translation/src/components/screenUI/Toolbar.vue"
  - "Translation/src/components/screenUI/foot.vue"
  - "Translation/src/cesiumTools/lineAndpoints/points/setpoints.js"
  - "Translation/src/cesiumTools/lineAndpoints/points/setcone.js"
  - "Translation/src/cesiumTools/lineAndpoints/points/setcircle.js"
  - "Translation/src/cesiumTools/lineAndpoints/points/circleAndcone/cone.glsl"
  - "Translation/src/cesiumTools/lineAndpoints/line/polyGlowflow.glsl"
  - "Translation/src/cesiumTools/lineAndpoints/line/PolylineFlowMaterialProperty.js"
  - "Translation/src/cesiumTools/lineAndpoints/line/setlines.js"
  - "Translation/src/cesiumTools/sceneManager.js"
  - "Translation/src/cesiumTools/DayorNigjt/DayorNight.js"
  - ".review/站点特效-默认视角.png"
  - ".review/站点特效-线路全关后.png"
session_ids:
  - "eefc6d70-fedc-42de-82be-c37adf2e7ebb"
memory_body_ids:
  []
---

# 站点特效（光锥 + 底部光圈）实现链路与实测复盘

日期：2026-10-10。起因：用户「读取我的 Toolbar.vue，查看我新增的站点渲染功能」。
本文是**代码走查 + 真实窗口实测**的结论，不是看代码猜的（除外标注的静态推断外，每条都有实测数据）。

相关文档：
- `176a2197-fd01-482e-94ae-f8eda62baced` — perfGuard 渲染环境检查卡（本项目的 FPS 采样/判定约定、低画质开关；本文沿用同一套 rAF 采样口径）
- `75da7559-5010-47fe-b292-58bd88afa63f` — 帧预算拆账与 rAF/DOM 直写优化（draw call 589 基线即出自此线的测量口径）

## 1. 实现链路（用户搭的结构）

```
left1.vue /getLine → 合并 line1to18_2.json 完整坐标 → dataStore.Lines
   ↓ watch（只触发一次）
Toolbar.vue: renderLineEntities() + renderStationMarkers()
   ↓ 按站名 Map 去重（同名合并，isChange 取或）
renderStation()
   ├─ coneWithLight() = Primitive(Cylinder 上半径 0 / 下半径 bottomRadius×0.7 + VtxfShader1)
   └─ bottomCircle() = Entity.ellipse + ConeGlowBottomCircle 材质（512² canvas 径向渐变贴图）
```

- `Toolbar.vue` 约 865 行，齿轮工具箱 + 线路图层面板已从 `foot.vue` 拆出（`foot.vue` 只保留 `<Toolbar @fullscreen="enterImmersive" />`，双向共享 `useToolbarState()`）。
- **两处清理必须分开**：光锥在 `scene.primitives`、光圈在 `viewer.entities`，`clearStationMarkers()` 分别移除，无残留。

### 1.1 做对的两个设计点（勿改坏）

1. **按站名合并去重**：510 条线路站点记录 → **400 个站点**，没有一条线画重。
2. **数据正确性已核验**：89 个多线路同名站，后端 `isChange` **全部标为换乘站，零假阳性**（特意查过「浦电路」这类同名但非换乘的坑）。站台间距最大的两个是国家会展中心 793 m、浦东南路 656 m，都是长通道真换乘站。

## 2. 性能实测

| 指标 | 无站点 | 有站点 | 变化 |
|---|---|---|---|
| 场景对象 | — | 400 光锥 Primitive + 400 光圈 Entity | — |
| **每帧 draw call** | **589** | **1416** | **+827（2.4×）** |
| 真实窗口 FPS（前台 4+4 次交替采样） | 24.7 / 30.6 / 26.4 / 30.9（均 28.1） | 21.9 / 20.8 / 23.4 / 23.5（均 22.4） | **−5.7 FPS（−20%）** |

**方法学（复用时照抄，否则会测出噪声）**：
- 用**真实非无头窗口**，加抗节流参数并**把窗口提到前台**。第一次测在后台跑，开/关两组区间完全重叠（18–30 随机跳），噪声盖过信号；提前台后两组**完全不重叠**（关的下限 24.7 > 开的上限 23.5），差值才可信。
- **交替采样**（开↔关轮流）抵消漂移；`viewer.scene.debugShowFramesPerSecond = true` 打开的是 Cesium 自带 `PerformanceDisplay`（DOM 元素 `cesium-performanceDisplay-ms` / `-fps`），可直接从 DOM 抓读数，无需自己插桩；同时用 rAF 自采一组交叉验证。
- 用 **`show` 开关**做无损 A/B；远程 `entities.remove` / 重建会抛 `DeveloperError`，不要走那条路。
- 注意：测量时用户自己的 Chrome 也在渲染同一场景，两个 WebGL 抢 GPU，**绝对 FPS 偏低，可信的是相对差值与 draw call 数**。

## 3. 发现的问题（按严重度）

### 🔴 1. 线路开关管不到站点（已实机复现）
用真实 UI 走一遍（齿轮 → 线路图层 → 点「全选」取消全部）：

```
操作前                : polyline 18/18, ring 400/400, cone 400/400
点「全选」全部取消后  : polyline  0/18, ring 400/400, cone 400/400   ← 站点一个没少
```

原因：`toggleLine` / `toggleAllLines` 只调 `hideLineByName(linesEnts, ...)`（它仅改 `line.show`，见 `setlines.js`），而站点特效**只在 `dataStore.Lines` 的 watcher 里渲染一次**，之后再没被任何开关碰过；面板上**也没有控站点的入口**，400 个光锥等于永远强制开启。
证据截图：`.review/站点特效-线路全关后.png`（面板 18 条全取消、折线全没，400 个光锥仍悬在城市上空）、`.review/站点特效-默认视角.png`。

### 🟠 2. 光锥闪烁是帧率驱动——修过的坑又回来了
`cone.glsl:8`：`float time = fract(czm_frameNumber / 10.0 * flickerSpeed);`
`czm_frameNumber` 是**帧序号**不是时间：周期 10 帧 → 60 FPS 下 **0.167 s 闪一次（6 Hz，刺眼）**，6 FPS 机器上 1.7 s 一次。
这与白模扫描带、外滩流光、水面波纹是**同一个坑**，那三处都已改 `u_time`（秒，见 `DayorNigjt/shaders/*.glsl`、`DayorNight.js`），这个新着色器又写回去了。

### 🟠 3. 线路流光也是帧率驱动
`polyGlowflow.glsl:37`：`float iTime = czm_frameNumber / 300. * flowSpeed + flowOffset;`
300 帧一个周期 → 60 FPS 下 5 s，20 FPS 下 15 s。用户机器上的流光速度是测试环境的 3 倍。

### 🟡 4. 400 个独立 Primitive，没做批处理
每站点一个 `Primitive`（仅 1 个 `GeometryInstance`）。Cesium 的正确做法是**多个 GeometryInstance 塞进一个 Primitive**；颜色只有 12 种线路色 + 1 种洋红 → 按颜色分组可把 **400 个 draw call 压到 13 个**，画面完全一致。400 个 ellipse Entity 同理。

### 🟡 5. 底部光圈比光锥底部大 2.9 倍
`setcone.js`: `CylinderGeometry({ bottomRadius: bottomRadius * 0.7 })`
`setcircle.js`: `ellipse({ semiMajorAxis: bottomRadius * 2 })`
而 `Toolbar.vue` 注释写的是 `bottomRadius` 同时作「光锥底半径 / 底圈半径」。有意做外圈光晕则无妨，若是笔误需对齐。

### 🟡 6. `PolylineFlowMaterialProperty.isConstant` 逻辑写反
`||` 应为 `&&`——现写法只要**任一**参数是常量就返回 `true`。当前全为普通数字，结果碰巧正确；一旦颜色换成动态 `Property`，Cesium 会误判为常量并缓存旧材质，动画直接失效。暂不发作但埋着。

### ⚪ 7. 小项
- 换乘站坐标取「第一条提到它的线路」（如国家会展中心画在 2 号线站台，离 17 号线 793 m）——可接受，知悉即可。
- `MaterialAppearance` 的 `closed: true` 会裁背面，相机钻进光锥内部时光锥消失。
- `czm_frameNumber` 无限增长，跑 40+ 小时后 `fract()` 会因浮点精度抖动。

## 4. 建议修法（性价比排序）

| 优先级 | 修什么 | 怎么做 |
|---|---|---|
| P0 | 线路开关联动站点 | 在 `toggleLine` / `toggleAllLines` 里顺带设对应 `cone.show` / `ring.show`；站点对象按线路名归组 |
| P1 | 两个着色器改时间驱动 | 照抄 `DayorNight.js` 的 `syncShaderTime()`：每帧写 `u_time`（秒）；`cone.glsl`、`polyGlowflow.glsl` 改用 `u_time`；`PolylineFlowMaterialProperty` 需新增 `u_time` uniform |
| P2 | 按颜色批处理 | 按 `color` 分组，每组一个 `Primitive` + `GeometryInstance[]`，400 → 13 |
| P3 | 距离剔除 | 只保留相机 N 公里内的站点，远的只留光圈或直接不画 |

P0+P1 是明确 bug，P2 能把新增的 827 个 draw call 砍掉约 97%。截至本文写作**尚未动手修改**，等待用户选择范围。

## 5. 附带确认

渲染环境已无问题：perfGuard 自报「渲染环境正常 / NVIDIA RTX 4070 Laptop GPU / 24 FPS」，独显判定工作正常（与 `176a2197` 的结论一致）。
