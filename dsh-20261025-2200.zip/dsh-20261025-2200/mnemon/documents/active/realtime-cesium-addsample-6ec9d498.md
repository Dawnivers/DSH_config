---
id: "6ec9d498-16c2-4821-b81b-e680ce4da503"
title: "/realtime 列车漫游细化：中键双轴相机、停站时长单位换算、Cesium addSample 时间按引用保存（含实测与源码定位）"
description: "补充 72915457 的落地细节：相机左键/中键分工与灵敏度基准、TRAIN_DWELL 实为仿真秒（墙钟 = TRAIN_DWELL/multiplier）的换算表、buildSchedule 采样为何在站点放 arrive/leave 两个点、SampledProperty.addSample 时间按引用而坐标按值保存故必须 clone 的源码证据。"
status: "active"
created_at: "2026-10-17T12:47:49.150Z"
updated_at: "2026-10-17T12:47:49.150Z"
content_hash: "de15e5cc9e0ac8db5099697aee4f788493b20994d54e83d56a140b8f687ac493"
source_paths:
  - "Translation/src/cesiumTools/lineAndpoints/train/trainRoam.js"
  - "Translation/src/cesiumTools/lineAndpoints/train/trainSchedule.js"
  - "Translation/src/components/bottom/RealtimePanel/RealtimePanel.vue"
session_ids:
  - "cb3f8951-c00d-45d6-ac3f-0ecf6f8b5919"
memory_body_ids:
  []
---

# /realtime 列车漫游细化（第二次交接）

主体实现见 `72915457-a50b-4583-bad7-a771aab9d999`（文件划分、站点→顶点前扫、lookAt 跟车、onTick 驱动）。
课程归档与差距见 `18fb181e-e047-4909-a1b8-fd9d1a1bd9e8`；内核理论见 `7f1a6f08-9d0f-4d25-adfe-c436ac157c88`。
本文只补三件后加/易误解的事：相机双轴分工、停站时长的单位、`addSample` 的引用语义。

## 1. 相机：左键单轴，中键双轴

| 操作 | heading | pitch | 视距 |
|---|---|---|---|
| 左键拖 | ✅ | ❌ | — |
| 中键拖 | ✅ | ✅（同一手势同时改） | — |
| 滚轮 | ❌ | ❌ | ✅ `range × 1.12`，夹在 22~1420m |

- 灵敏度：横向 **0.35°/px**，纵向 **0.28°/px**。
- 实现在 `Translation/src/cesiumTools/lineAndpoints/train/trainRoam.js` 的 `handlePointerDown` / `handlePointerMove`（:375）/ `handleWheel`。
- 默认跟车视角：距车 **190m**、俯角 −22°、偏航 35°；轨迹 `path.leadTime:0 / trailTime:3000m`（`TRAIL_METERS`，trainRoam.js:50）。
- **关键前提**：两个轴都从 pointerdown 那一刻的基准角（`_drag.heading` / `_drag.pitch`）算总增量，**不能**在「当前角」上逐帧累加——否则同一手势内每帧以已转过的角为起点，会加速失控，松手后还继续漂。

实测（逐像素对得上，pageerrors 无）：

```
初始    : heading 35,  pitch -22
左键横拖200px: 325, -22     ← pitch 不动
中键斜拖(+100x,+50y): 290, -36
中键反斜(-100x,-100y): 325, -8
左键纵拖100px: 325, -8      ← 两者都不动
```

## 2. 停站时长：`TRAIN_DWELL` 是仿真秒，不是墙钟秒

- 常量：`Translation/src/cesiumTools/lineAndpoints/train/trainSchedule.js:46` `TRAIN_DWELL = 2`；速度 `TRAIN_SPEED = 16.7`。
- 面板 `RealtimePanel.vue:199` 调 `roam.load()` 时**没传 `dwell`**，所以生效值就是该常量；单线路可 `roam.load({ dwell: 12 })` 覆盖（`trainRoam.js:128 dwell: dwell ?? TRAIN_DWELL`）。
- 实际墙钟停站 = `TRAIN_DWELL / clock.multiplier`，而 `multiplier = max(1, schedule.total / WALL_SECONDS)`（`trainRoam.js:246`），`WALL_SECONDS = 290`（:47）。

| 线路 | 站数 | multiplier | `TRAIN_DWELL=2` 实际停 |
|---|---|---|---|
| 1 号线 | 28 | ≈7.8 | ≈0.26 s |
| 11 号线 | 37 | ≈15.7 | ≈0.13 s |

**坑**：同一个数值在不同线路上表现不同，且调 `WALL_SECONDS` 后停站时长跟着变，需重新标定；停站越长总时长越大、multiplier 越大，存在上限（1 号线约 `290/27 ≈ 10.7 s`）。标定式：`TRAIN_DWELL ≈ 目标墙钟秒 × multiplier`（1 号线 1s≈8、2s≈19）。

若想彻底解耦，把 `load()` 里 multiplier 的算法改成「总时长 = 运行时长 + 各站固定停靠」即可，`TRAIN_DWELL` 变为真墙钟秒（副作用：全线总时长 290 → 290+27×dwell）。

## 3. `buildSchedule` 六步与「站点放两个采样点」

输入折线顶点 + 站点 + 速度，输出 `(时间 → 顶点下标)` 表：

1. 经纬度 → 地心直角坐标（自写，等价 `Cartesian3.fromDegrees`，为的是模块 **不 import cesium**、可在 node 跑断言）；
2. 累加弧长，得到「走了多少米」的尺子；
3. 站点 → 顶点：首站全表最近点，之后从上一命中顶点的下一个开始**严格单调前扫**；
4. 以首站顶点为弧长 0 基准，裁掉首站之前 / 末站之后的冗余顶点（否则 t=0 时车停在首站之前，进度条 0% 对不上）；
5. 逐站算到发时刻：`arrive = 上站 leave + 区间距离/速度`，`leave = arrive + dwell`；首站 arrive=leave=0（进栏目即发车）；
6. 生成采样：站间每个顶点一个采样；**站点处生成 arrive / leave 两个位置相同的采样**——Cesium 只在采样点之间线性插值，单点会让车匀速掠过不停站，两点同位置才「原地不动」，这就是停站。这两个时刻同时是面板判断 `arrive ≤ t ≤ leave` 的依据，一份数据两用。

1 号线实测：337 顶点 + 28 站 → **360 采样**（首站只 1 个）→ 总时长 **2266.68 s** → multiplier ≈7.8。

## 4. `SampledProperty.addSample`：时间按引用，坐标按值

源码（`SampledProperty.js:581`）：

```js
const data = [];
data.push(time);                        // 时间对象本身入数组（引用）
innerType.pack(value, data, data.length); // Cartesian3 拆成 x/y/z 数字
mergeNewSamples(undefined, this._times, this._values, data, this._packedLength);
```

`mergeNewSamples`（同文件 :57）里 `currentTime = convertDate(newData[...], epoch)` 对已是 JulianDate 的输入原样返回，随后 `timesSpliceArgs[..] = currentTime; arrayInsert(times, ...)` —— 所以 `this._times` 存的就是**传进去的那个对象**。

因此循环里复用同一个 `time` 做 result 必须 `Cesium.JulianDate.clone(time)`：

```js
const time = new Cesium.JulianDate();
Cesium.JulianDate.addSeconds(startTime, sample.t, time);        // 结果写入 time（返回同一引用）
sampled.addSample(Cesium.JulianDate.clone(time), cartesians[sample.vi]);
```

- `addSeconds(startTime, t, time)` 的第三参是输出参数，返回值 === `time`；它负责把「相对首站的第 t 秒」换算成绝对朱利安时间。
- 不 clone 的后果：`this._times` 变成 360 个指向同一对象的元素，其值 = 最后一个采样时刻 → 采样全塌到同一时刻，车静止或消失，**Cesium 不报错**。
- 坐标不需要 clone：`innerType.pack` 把 Cartesian3 拆成三个数字按值拷贝。**时间按引用 / 坐标按值的不对称**就是只对时间 clone 的原因。
- `clone` 并不比 `new JulianDate()` 省分配，只省一行；更稳妥的写法是每轮 `new Cesium.JulianDate()` 作为 result，让正确性一眼可见（360 次分配只在建实体时一次）。
