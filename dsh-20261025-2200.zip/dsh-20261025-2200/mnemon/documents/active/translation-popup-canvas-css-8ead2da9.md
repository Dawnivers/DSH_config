---
id: "8ead2da9-2e1f-470b-9048-6d5da40f3bac"
title: "Translation 智慧地铁气泡框（popup）定位偏移根因与修复：canvas 绘制缓冲尺寸 ≠ CSS 尺寸"
description: "2026-10-10 定位并修复低画质（resolutionScale 0.75）下站点气泡框整体下掉 225px、可见气泡数 49→31 的问题。根因是 HTML 覆盖层定位误用 canvas.height/width（绘制缓冲区）而非 clientHeight/clientWidth（CSS 布局尺寸），与 wgs84ToWindowCoordinates 返回的 CSS 像素单位不一致；含实测数据、全项目同类写法排查结论与遗留项（devicePixelRatio 触发面、u_resolution 静态值）。"
status: "active"
created_at: "2026-10-10T12:13:13.422Z"
updated_at: "2026-10-10T12:13:13.422Z"
content_hash: "14e703a93efb3da19c12c5ede45e86136b3f8eb88975eea2555370f4b3c3c915"
source_paths:
  - "Translation/src/cesiumTools/lineAndpoints/popup/popup.js"
  - "Translation/src/cesiumTools/lineAndpoints/popup/popupManager.js"
  - "Translation/src/components/screenUI/perfGuard.vue"
  - "Translation/src/cesiumTools/sceneManager.js"
  - "Translation/src/cesiumTools/DayorNigjt/ModelShaders.js"
session_ids:
  - "14196299-e30a-482d-b6bf-207cf6942df0"
memory_body_ids:
  []
---

# 智慧地铁：气泡框定位偏移（低画质）根因与修复

日期：2026-10-10。触发问题：用户报告「启动低画质时，站点气泡框会偏离原来的位置」。

## 1. 症状与量化复现

低画质 = `perfGuard.vue` 把 `viewer.resolutionScale` 设为 `LOW_RESOLUTION_SCALE = 0.75`（绘制缓冲区缩到 75%，CSS 显示尺寸不变）。

实测（1600×900 视口，同一相机视角）：

| resolutionScale | canvas 绘制缓冲 | canvas 显示尺寸 | 塘桥 bottom | 源深体育中心 bottom | 可见气泡数 |
|---|---|---|---|---|---|
| 1（正常） | 1600×900 | 1600×900 | 945.676px | 899.11px | 49 |
| 0.75（低画质） | **1200×675** | 1600×900 | **720.676px** | **674.11px** | **31** |

- 纵向位移 = 945.676 − 720.676 = **225px = 900 × 25%**，多个气泡完全一致 → 均匀下移，与纬度/站点无关。
- `left` 一像素未变 → X 方向没有用到 canvas 尺寸，只有纵向受影响。
- 附带第二个 bug：可见气泡 49 → 31，低画质下**屏幕右侧 1/4、下侧 1/4 的气泡被误判出屏而隐藏**。

## 2. 根因：单位不一致

`Cesium.SceneTransforms.wgs84ToWindowCoordinates()` 返回的是 **CSS 像素**坐标——Cesium 源码内部就是按 CSS 尺寸换算的（`SceneTransforms.js:133-134` 取 `canvas.clientWidth/clientHeight`，`:263` 做 `clientHeight - y` 翻转）。

而气泡定位把**绘制缓冲区尺寸**当成了 CSS 尺寸：

```js
// 改前（popup.js 与 popupManager.js 同一写法）
const canvasHeight = this.viewer.scene.canvas.height;   // 绘制缓冲区 = CSS × pixelRatio × resolutionScale
...
el.style.bottom = canvasHeight - windowPosition.y + offset[1] + 'px';
```

正常时 `canvas.height == clientHeight == 900`，两者相等看不出问题；`resolutionScale = 0.75` 后 `canvas.height = 675` 而 CSS 高度仍是 900，`bottom` 就少了 **900 × 25% = 225px**。

同一处变量还用于出屏剔除（`windowPosition.y > canvasHeight` / `windowPosition.x > canvas.width`），因此把右下角气泡误剔除。

## 3. 修法

两文件、4 处改为 CSS 布局尺寸，并在注释里写明「为什么不能用绘制缓冲区」：

| 文件 | 改动 |
|---|---|
| `Translation/src/cesiumTools/lineAndpoints/popup/popup.js` | 第 182、183 行 `canvas.height/width` → `clientHeight/clientWidth`；第 226 行剔除判断同步 |
| `Translation/src/cesiumTools/lineAndpoints/popup/popupManager.js` | 第 96、97 行同上 |

验证结果（逐个站名比对 49 个气泡）：

| | 绘制缓冲 | 显示尺寸 | 可见气泡 | 最大纵向偏差 |
|---|---|---|---|---|
| 修复前 0.75 | 1200×675 | 1600×900 | 31 | **225px** |
| 修复后 1.0 | 1600×900 | 1600×900 | 49 | — |
| 修复后 0.75 | 1200×675 | 1600×900 | **49** | **0px** ✅ |

`errors: 0`。

## 4. 复用结论（HTML 覆盖层定位的通用规则）

1. **HTML 覆盖层（popup / label / MarkerTemplate）用屏幕坐标定位时，坐标系基准必须取 `canvas.clientWidth/clientHeight`**，不能用 `canvas.width/height`。后者 = CSS 尺寸 × devicePixelRatio × resolutionScale，是 WebGL 绘制缓冲区尺寸。
2. **只要分辨率倍率 ≠ 1，这个坑就会露出来**：`Translation/src/cesiumTools/sceneManager.js:68` 有 `viewer.resolutionScale = window.devicePixelRatio;`，所以设备 DPR ≠ 1（笔记本常见 1.25/1.5/2）时**不开低画质也会偏**。本次修复同时覆盖了 HiDPI 场景。该行本身也值得商榷：Cesium 默认 `useBrowserRecommendedResolution = true`（内部 pixelRatio 已按 1 处理），再乘一遍 DPR 会让绘制缓冲区变成 DPR 倍，2K 屏上是约 4 倍像素量的渲染开销。
3. 判断某处 `canvas.width/height` 用得对不对，只需问：**这个尺寸是给 DOM 定位用的，还是给 GPU 像素空间用的？** 前者要 CSS 尺寸。
4. 定位偏差先算「位移 ÷ 视口高度」——正好等于 `1 − resolutionScale` 就基本锁定是这个问题，不必逐站排查。

## 5. 全项目同类写法排查结论

| 位置 | 结论 |
|---|---|
| `popup.js` / `popupManager.js` | ❌ 用错，已改为 CSS 尺寸 |
| `DayorNigjt/ModelShaders.js:143` `u_resolution` | ✅ **这里是对的**：要与 `gl_FragCoord` 的设备像素空间对齐，必须用绘制缓冲尺寸 |
| `screenUI/right3.vue:70-79` | ✅ 自己那块 2D canvas，用 `parentElement.clientWidth` 后赋给 `canvas.width`，自洽 |
| `points/circleAndcone/circleBottomGlowMaterialProperty.js:16-17` | ✅ 512×512 贴图生成，与视口无关 |

**遗留项**：`ModelShaders.js:143` 的 `u_resolution` 只在创建时取一次值，切换 `resolutionScale` 后不会更新，低画质下外滩流光的缩放与正常画质不一致；需要在 DayorNight 的逐帧更新里同步该 uniform（尚未实施）。

## 6. 相关背景

- 低画质开关的完整参数集（`resolutionScale 0.75` + tileset `maximumScreenSpaceError 16→32` + `maximumMemoryUsage 512`）与 perfGuard 的设计取舍见文档 `176a2197-fd01-482e-94ae-f8eda62baced`。
- 这次调查同时还观察到场景中有约 400 个站点名称 HTML 标签、draw call 首页 570 / 站点管理 1415、rAF 26.7 FPS；这批标签来自 `MarkerTemplate.vue`/`popup` 的 HTML 覆盖层方案（不是 Cesium 实体），性能未深挖，属于 400 Primitive 那条线的关联问题，见文档 `8d3c4c05-ec6a-4bb9-98de-8a40750572a5`。
- 同一批次改动：站点管理模式下用 `v-show="!stationPanelOpen"` 收起 `panel.vue` 的左右侧栏（head/foot 保留，`v-show` 而非 `v-if`，因为六块侧栏各自挂着定时器与逐帧写 DOM），并撤掉了面板内为「没退路」临时加的 ✕ 与 ESC 监听。
