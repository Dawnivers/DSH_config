---
id: "e9f4897b-6e1f-4ef0-934e-126d80b77906"
title: "Translation 智慧地铁：查询模式外壳的声明式生命周期（一模式一组件、单一 owner）"
description: "2026-10-19 重构 QueryModePanel：MODES 携带 component、`<component :is>` 统一渲染，新增 heatmap/HeatMode.vue，useHeatmap 去掉 isActive 与内部卸载钩子；确立「组件在则效果在、组件卸载自己清理」的单一 owner 约定，含改动清单、迁移成本与未完成的运行时验证。"
status: "active"
created_at: "2026-10-19T10:31:11.236Z"
updated_at: "2026-10-19T10:31:11.236Z"
content_hash: "3f6f82bc6f40b4d46bc20981ae8e19525009c6c6108b957e35ad1dad03392dfd"
source_paths:
  - "Translation/src/components/bottom/StationPanel/QueryModePanel/QueryModePanel.vue"
  - "Translation/src/components/bottom/StationPanel/QueryModePanel/heatmap/HeatMode.vue"
  - "Translation/src/components/bottom/StationPanel/QueryModePanel/heatmap/useHeatmap.js"
  - "Translation/src/components/bottom/StationPanel/QueryModePanel/guideload/RouteDesign.vue"
session_ids:
  - "faad1387-3fc8-44be-9a4e-aef6720ddae4"
memory_body_ids:
  []
---

# 查询模式外壳：声明式生命周期（一模式一组件，单一 owner）

日期：2026-10-19。范围：`Translation/src/components/bottom/StationPanel/QueryModePanel/`。

相关文档：
- `44fe1831-c29a-4d4c-aed8-334dfb8fa556` — 路径规划模式的四层拆分（planModel / renderRoute / useRoutePlan / RouteDesign）。
- `771251b3-3cd0-40fd-9317-f7f609285a72` — 规划前清场与逐条快照还原。
- `0ce9c65f-6c6b-48c8-872b-d98bc80502a1` — 热力图最终形态（视口 LOD）。

## 1. 触发：两套进出机制并存

上一版里 `QueryModePanel.vue` 的 `choose()` 名义上是「切模式 = 撤旧挂新」，实际只对热力图生效：它调用 `heat.mount()` / `heat.destroy()`；而路径规划靠模板 `<RouteDesign v-if="active === 'guideload'" />` 的 `onMounted` / `onBeforeUnmount` 自己进出。

结果是同一职责有两个 owner：外壳负责关、组件卸载也可能关。重复调用会重复初始化或提前销毁，漏写 `destroy()` 又是静默的（效果残留）。用户指出这不规范后，选择先补架构再继续加功能。

## 2. 最终结构

外壳只保留两件事：画模式按钮、记 `active`。

```js
const MODES = [
  { id: 'heat', label: '站点拥挤度', note: '按站点客流生成热力图', component: HeatMode },
  { id: 'guideload', label: '路径规划', note: '选择起终点查询换乘方案', component: RouteDesign },
  { id: 'stationcontrol', label: '站控措施', note: '封站 / 加强安检（待接入）', component: null },
];
const active  = ref('');
const current = computed(() => MODES.find((m) => m.id === active.value) ?? null);
const choose  = (mode) => { active.value = active.value === mode.id ? '' : mode.id; };
```

```html
<component :is="current.component" v-if="current?.component" />
```

生命周期契约：**组件在，效果就在；组件没了，效果必须自己收拾干净。**

- 挂载 = 进入模式：藏 18 条全局线、清场站点、锁相机、画私有实体，都在组件/其 composable 的生命周期里。
- 卸载 = 退出模式：`onBeforeUnmount` 里销毁实例、恢复相机、还原线路与站点快照。
- `choose()` 不再承担任何效果启停，只是模式选择本身。

## 3. 改动清单

| 文件 | 变化 |
|---|---|
| `heatmap/HeatMode.vue`（新增） | 热力图的模式组件：`useHeatmap()` + 自有状态卡（摘要/报错），与 `RouteDesign.vue` 对称 |
| `heatmap/useHeatmap.js` | 去掉 `isActive` 参数与内部的 `onBeforeUnmount`；`watch(..., { immediate: true })` 负责进入时挂载，退出由使用它的组件调 `destroy()` |
| `QueryModePanel.vue` | `MODES` 增加 `component` 字段；`<component :is>` 统一渲染；`choose` 缩为一行；删掉 `heat` / `footer` / `RouteDesign` 特例引入及 `.qm-foot.is-error` 样式 |
| `guideload/RouteDesign.vue` | 保持原有自包含生命周期，不改逻辑 |
| `stationcontrol/` | 仍为空占位，`MODES` 里 `component: null` |

## 4. 为什么不让外壳调 mount()/destroy()

被否决的写法就是「外壳持有一个 `heat` 句柄，在 `choose()` 里 mount/destroy」。问题不在代码量，而在职责归属：

- 外壳必须知道每个模式的进入/退出细节，新增模式要改外壳；
- 组件卸载与外壳调用可能同时发生，顺序靠人工约定；
- 漏写是静默失败，没有编译期或结构性的提醒。

改用 `<component :is>` 后，Vue 的挂载/卸载时机就是唯一生命周期信号，效果与组件的存续一一对应。代价是每个模式必须自己写清理逻辑——但那是 Vue 本来就在管的事。

新增模式的成本：新建目录 + 在 `MODES` 加一行 `component`，外壳一行不改。

## 5. 一处可见变化

热力图的「400 站 · 客流 51–998」与「初始化失败」提示，从外壳底部的小字挪进 `HeatMode.vue` 自己的卡片（位置与路径规划面板一致：左 222、顶 112）。理由：所有模式用同一个槽位展示自己的状态，外壳不再有「哪个模式的状态要特殊显示」的分支。

## 6. 验证状态

- **编译**：`vite build` 通过（1.44 s），三个 SFC 均正常解析打包；仅有既有的 chunk > 500 kB 提示。
- **运行时：未验证**。浏览器桥断开（`no browser extension is connected to the bridge`），端口 5173 / 8092 仍在监听、Chrome 进程仍在，但可控制标签页已丢失。待人工刷新后确认三点：
  1. 点「站点拥挤度」→ 出现 `站点拥挤度 / 400 站 · 客流 51–998`，相机俯视锁定；
  2. 切「路径规划」→ 热力卡消失、相机解锁、换成规划面板；
  3. 再点当前模式 → 面板消失，18 条线与站点回到进入前的显隐。

若第 3 点有残留，优先排查 `clearRoute` / `restoreAllStations` 的快照是否成对。

## 7. 改这块时的约束

- 不要在外壳里重新引入具体模式的 ref 或 `mount()/destroy()` 调用；外壳只认 `component`。
- 新模式的状态展示放进自己的组件，不要再往外壳加 `footer` 分支。
- 每个模式组件的 `onBeforeUnmount` 必须能在「从未成功挂载」的情况下安全执行（幂等清理）。
