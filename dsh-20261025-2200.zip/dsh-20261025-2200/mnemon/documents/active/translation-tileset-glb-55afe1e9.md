---
id: "55afe1e9-54f3-43e2-83f1-9f367614bad6"
title: "智慧地铁 Translation：开屏加载的逐资源校验（双 tileset + 列车 glb）与加权进度合成"
description: "在本地 Translation 项目补齐「城市 tileset / 外滩 tileset / 列车 glb」三项独立校验：每项 pending/loading/ok/fail 四态、initialTilesLoaded + tileLoad 计数 + 缓存与超时兜底、列车 fetch 流式字节进度、PRELOAD_TRAIN 开关，以及把「取最大区间」改为 0.55/0.20/0.25 加权平均以消除卡 90% 的体验问题。"
status: "active"
created_at: "2026-10-21T12:30:03.742Z"
updated_at: "2026-10-21T12:30:03.742Z"
content_hash: "5a85040563fc1257c582987cd2c2b55239316d7d7d22887e310edf90d1ee4638"
source_paths:
  - "Translation/src/views/cesiumView.vue"
  - "Translation/src/stores/loadingState.js"
  - "Translation/src/components/loading/SciFiLoader.vue"
session_ids:
  - "782ecb5e-db2c-4087-912f-451611d150c9"
memory_body_ids:
  []
---

# 开屏加载：逐资源校验 + 加权进度（2026-10-21）

对象：本地实验项目 `D:\WebGIS\web三维开发\智慧地铁项目\Translation`（dev server `http://localhost:5173/`）。工作区上线版未改动。
触发：用户追问「有做各 3dtiles 和列车模型加载的检验吗」——此前只校验了城市模型首屏瓦片，外滩只等到根 tileset.json，列车模型完全没检查。

关联：
- 开屏动画本体、视觉构成与初版时序见 `8a2ce03b-0dd7-4b4c-9492-354d34a889f2`；
- 列车 glb 23.55MB→8.62MB 贴图压缩与线上 ~3Mbps 出口带宽见 `9c15ce40-c2f9-4c44-afe6-ede26e6cb8d3`；
- LOD 层级裁剪见 `cf0fbafd-3d5e-4f89-b00b-0db4e02bcf70`。

## 1. 此前的校验缺口

| 资源 | 旧做法 | 问题 |
|---|---|---|
| 城市 tileset | `initialTilesLoaded` + `tileLoad` 计数 | 基本可用，但只覆盖一项 |
| 外滩 tileset | 仅等 `readyPromise` | 根 json 200 不代表瓦片到位 |
| 列车 glb | `RealtimePanel` 懒加载时才取 | 开屏阶段完全无校验 |

## 2. 双 tileset：按资源独立跟踪

`cesiumView.vue` 用 `trackTileset(key, target)` 对 `tilesets[0]`（城市）与 `tilesets[1]`（外滩）各挂一套：

```js
target.tileLoad.addEventListener(() => loading.addTile(key, 1));
target.initialTilesLoaded.addEventListener(() => done());
setTimeout(() => { if (target.tilesLoaded) done(); }, 1200); // 缓存命中可能不触发事件
setTimeout(() => done('超时放行'), 20000);                   // 单项硬超时
```

判定标准是「初始视角所需瓦片全部到位」，清单上显示真实的「37 块瓦片」这类计数。

## 3. 列车 glb：fetch 流式预载，字节级进度

不依赖 Entity 是否被创建，开屏阶段直接读一遍 glb：

```js
const res = await fetch(TRAIN_MODEL_URL);
const total = Number(res.headers.get('content-length')); // 24,706,712 B ≈ 23.5MB
// ReadableStream 分块读取，累计 received / total，
loading.progressAsset('train', received / total, `12.3 / 23.6 MB`);
```

- 能读到 EOF 即证明文件完整（非 404、非截断），完成后标记「23.6 MB 已缓存」；
- 观众点进「实时轨迹」时浏览器缓存已有该文件，避免二次等待；
- 预载失败只把该行标红（`loading.failAsset('train', '预载失败')`），**不阻塞场景**。
- 开关：`cesiumView.vue:83` 的 `PRELOAD_TRAIN = true`。设为 `false` 时改为「按需加载」，开屏更快但首次进实时轨迹要等；
  本地局域网建议 `true`；线上 3Mbps 出口建议先 `false`（列车已瘦身到 8.6MB，按需加载可接受）。

## 4. 进度合成：从「取最大」改为加权平均

初版按区间取最大值，存在体验坑：外滩体量小、往往最先完成，进度会早早钉在 **90% 静止**，看起来像卡死。

改为：

```js
percent = base(0~0.6) + 0.4 × (0.55×城市 + 0.20×外滩 + 0.25×列车)
```

权重和为 1，进度平滑推进，不跳数也不长时间停住。基础段仍对应 引擎 0.12 / 底图 0.20 / 模型解析 0.50 / 特效 0.60。

## 5. 失败与放行策略（不锁死用户）

- 单项失败 → 该行标红，其余照常；
- 场景初始化抛错（tileset 404、网络断）→ 全部标红 `三维场景加载失败`，随后放行；
- `SciFiLoader.vue` 的 40s 看门狗 → 任何环节卡死都强制放行；
- 最短展示 1.8s，避免本地秒开时闪一下。

## 6. 验证方法

- 编译校验（无需浏览器）：向 Vite 转换接口请求，编译错误返回 500。
  `/src/views/cesiumView.vue`、`/src/components/loading/SciFiLoader.vue`、`/src/stores/loadingState.js`、`/` 均 200 通过。
- 资源可达性：列车模型 URL 返回 `206 Partial Content`，`Content-Range: bytes 0-24706711/24706712`。
- 浏览器桥接当时不可用，**视觉效果未由助手确认**；需用户 `Ctrl+Shift+R` 硬刷后目视验收清单每一行状态。
