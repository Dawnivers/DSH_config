---
id: "36e69a5c-e174-4212-a097-191463584022"
title: "DSH 0.2.1 升级影响面评估：17 插件兼容闸门与破坏性变更命中（2026-10-22，desktop profile）"
description: "把本机 desktop profile 从 DSH Desktop 2.0.18 内核 0.2.0-rc.2 升到 0.2.1-rc.2 的影响面量化：17 个插件的 semver 闸门判定（4 硬撞/6 软撞/7 无声明）、各插件现版本与最新版是否声明支持、7 项破坏性变更在本机的 grep 命中情况、两条升级路线与不可逆风险。承接文档 ab5164f9。"
status: "active"
created_at: "2026-10-22T14:02:52.154Z"
updated_at: "2026-10-22T14:02:52.154Z"
content_hash: "47e983237597789b992b2a9d8028ff5611e33be3940f753ae6a26ffc74ee345f"
source_paths:
  []
session_ids:
  - "595b6a54-c4b7-4038-b95f-b0fecf550ec1"
memory_body_ids:
  []
---

# DSH 0.2.1 升级影响面评估（desktop profile）

日期：2026-10-22。目标版本：内核 `@deepseek-ai/dsh@0.2.1-rc.2`；当前桌面端 2.0.18（内核 `0.2.0-rc.2`）。
承接文档：`ab5164f9-c8fb-4ebb-befe-305e70609cb7`（框架包由 Electron 外壳打包，非 pnpm 布局；17 条依赖/8 条 link、`cordis.patch.yml` 6 条补丁）——本文不重复该结论，只做升级影响面。

复查用路径（工作区外，只读记录）：
- `C:\Users\林先语\.dsh\profiles\desktop\package.json`、同目录 `node_modules\semver`
- `D:\DSH\dsh_data\DSH Desktop\resources\app\node_modules\@deepseek-ai\`
- 桌面端更新接口 `https://www.dshdesktop.cn/api/desktop/version`（当前返回 `2.0.18 / stable`）；下载端点 `.../api/downloads/windows|mac`。站点无 `/changelog`、`/releases`（均 404）。

## 1. 前置结论：内核不能单独升

桌面端把内核打包在 `resources\app`，没有"只换内核"入口。两条路线：

- **A. 换桌面端整包**（2.0.18 或等打包 0.2.1 的版本）。**2.0.18 究竟打包哪个内核官方未公开**，是整个评估唯一的未知量；可下载安装包解 `app.asar` 内 `package.json` 核实。
- **B. 隔离试水**：D 盘装 CLI 版 `@deepseek-ai/dsh@0.2.1-rc.2`，新建独立 profile（`dsh --profile <name> --from-default-profile web`，换端口），不碰桌面端。

## 2. 兼容闸门：17 个插件逐个算过（目标 `0.2.1-rc.2`）

宿主装载时按插件声明的 DSH 版本范围校验（0.2.1-alpha.4 起优先看 `engines.dsh`），不通过需 `allow-version` 精确豁免。用 profile 内 `semver` 实算：

| 判定 | 数量 | 插件 |
|---|---|---|
| **硬不通过**（含预览版语义也不满足） | 4 | `@deepseek-harness-tui/dsh-tui` 0.13.0、`dsh-code-index` 0.9.0、`@michengai/dsh-skills-manager` 1.1.23、`@yuxianglin/dsh-bridge-browser` 0.0.7（本地 link） |
| **软不通过**（`^0.2.0-rc.1` / `>=0.2.0-rc.2` 这类范围，严格 semver 认为 `0.2.1-rc.2` 是 0.2.1 的预览版而不落区间） | 6 | `@linxin666/dsh-web-all`、`dsh-better-sidebar`、`dsh-context`、`dsh-context7`（本地）、`dsh-cost-meter`、`dsh-mnemon` |
| **无声明**（不拦也不保证） | 7 | `@liustack/modlens` + 6 个本地插件（agnes ×3、mcp-anysearch、archify、academic-research-skills） |

⚠ `skills-manager 1.1.23` 的范围只到 `0.2.1-alpha.3` → **升内核就必须同时升到 1.2.x**，不是可选项。

## 3. 要动的清单（含最新版是否声明支持 0.2.1）

| 插件 | 现版本 | 最新版 | 最新版声明支持 0.2.1？ |
|---|---|---|---|
| tui | 0.13.0 | 0.16.1 | ✅ 枚举含 `0.2.1-rc.2` |
| code-index | 0.9.0 | 0.11.0 | ✅ `0.2.0-rc.2 \|\| 0.2.1-rc.2` |
| skills-manager | 1.1.23 | 1.2.11 | ✅（但 `lib/client.js` 补丁会被覆盖） |
| web-all | 0.4.5 | 0.4.8 | ✅ |
| better-sidebar | 0.24.1 | 0.28.0 | ✅ `^0.2.1-rc.1` |
| context | 0.64.0 | 0.74.0 | 无上限声明（`>=0.1.7-rc.2`，天然覆盖） |
| mnemon | 0.5.24 | 0.5.34 | 部分 |
| cost-meter | 1.8.15 | 1.9.26 | 无 dsh 声明 → 不过闸门 |
| modlens | 3.26.6 | 3.27.1 | 无声明 |
| context7（本地） | 0.2.0 | — | `>=0.1.0-rc.7 <2`，软通过，可改可不管 |
| bridge-browser（本地） | 0.0.7 | — | 写死 `0.2.0-rc.2`，**必须改 peer 范围并重新构建** |

量化：**7 个 npm 包升级 + 2 个本地插件改版本声明（bridge-browser 还需重构建）+ 6 个本地插件冒烟 + 1 条 bundles 自动漂移 + 1 个前端补丁重打**，半天以内（含验证），不涉及业务逻辑改写。

## 4. 破坏性变更 × 本机 grep 命中

| 变更 | 命中 |
|---|---|
| 自动化任务改 Web 内置，旧 schedule 实验组合包自动清理 | **1 处**：`dsh.profile.bundles` 里的 `@deepseek-ai/dsh-experimental-schedule-bundle` 被自动清掉（已有任务保留），自动漂移，无需手改 |
| 移除运行时 invariant 插件与各包 `./invariant` 导出 | **0**（bridge-browser 的 `/invariant` 是其自身子路径，复核确认误报） |
| 移除工具展示 `both` 混合模式 | 0 |
| 输入区统计拆成 `activity` / `usage` 两个 ID | 0（本地插件无；cost-meter 靠升级解决） |
| `azure-openai-responses` 改名 `azure` | 0（配置里没有） |
| API Key 优先级：桌面/Web 优先已保存凭据，**headless 只读环境变量与 .env** | 潜在：headless 定时/工作流/子代理需补 `DEEPSEEK_API_KEY` |
| 子路径插件不再读独立 `package.json` | 0 |

代码级破坏性变更几乎全打空，实打实只剩"bundles 自动清理"和"headless 凭据优先级"。

## 5. 自留改动与风险

- `lib/client.js` 默认展开补丁：桌面端整包替换必然抹掉；升 1.2.x 会换 UI 组件、锚点大概率失效 → 需重找锚点（约 30 分钟）。
- `~/.dsh/skills-manager/state.json` 的 5 个分类：不受影响。
- 真正风险不在改动量，而在 **① 2.0.18 是否真带 0.2.1 未知；② 升级是单向门**——回滚只能重装旧版，而 `~/.dsh` 里 profile 新旧共用，插件一旦按 0.2.1 升上去，回滚内核还得再降一遍。

建议路径：先走 B，在 D 盘装 CLI 0.2.1-rc.2 + 独立 profile 试装 4 个硬撞插件，把"破坏性变更是否命中"从推测变实测（约一小时），桌面端一行不动。
