---
id: "09f61d57-f7d0-4419-93c2-819d24da477c"
title: "高德 Web 服务 POI 取数方案：官方入口、200 条/查询硬限制的网格切分、raw JSON+manifest 断点续跑，以及 etl/ 与应用的契约边界（2026-10-25）"
description: "D4「补 POI 数据」开工前的取数层设计与调研结论：高德开放平台官方入口与接口文档清单、v3/v5 搜索接口地址、同请求参数最多 200 条与月配额模型的区别、以 count 为判据的递归网格切分算法与终止条件、manifest 断点续跑 + ON CONFLICT 幂等入库 + raw JSON 重放、etl/ 离线脚本与 FE/GeoServer 应用的「流程独立、契约锁定」边界，含合规与请求量估算。坐标系偏移参见文档 a1c65b87。"
status: "active"
created_at: "2026-10-25T01:58:25.383Z"
updated_at: "2026-10-25T01:58:25.383Z"
content_hash: "357b3a5296159e1333423af5be1af027fef7988596514ba5143cb31bf46b1e2c"
source_paths:
  []
session_ids:
  - "dfed9a37-fa84-4bf1-8f72-4e9027a966b5"
memory_body_ids:
  []
---

# 高德 Web 服务 POI 取数方案（D4 取数层设计）

本轮结论针对 `openlayers服务平台开发` 的 D4「补 POI 数据」：高德数据不是可下载的数据包，而是**注册开发者 → 建应用拿 Key → 调 Web 服务 API 在线查询**。以下条目均为实际抓取确认可访问的官方页面。

## 1. 官方入口清单

| 用途 | 地址 |
|---|---|
| 创建应用与 Key 文档 | https://lbs.amap.com/api/webservice/create-project-and-key |
| 控制台 → 应用管理（建 Key） | https://console.amap.com/dev/key/app |
| 实名认证 / 开发者类型 | https://console.amap.com/dev/id/select |
| Web 服务 API 总览 | https://lbs.amap.com/api/webservice/summary |
| 搜索 POI 2.0（推荐，`/v5/place/text`） | https://lbs.amap.com/api/webservice/guide/api-advanced/newpoisearch |
| 搜索 POI 旧版（`/v3/place/text`） | https://lbs.amap.com/api/webservice/guide/api-advanced/search |
| 行政区域查询（取 13 区 adcode） | https://lbs.amap.com/api/webservice/guide/api/district |
| 坐标转换（GCJ-02 ↔ WGS84 官方） | https://lbs.amap.com/api/webservice/guide/api/convert |
| 地理/逆地理编码 | https://lbs.amap.com/api/webservice/guide/api/georegeo |
| POI 分类编码表下载（types 用码不用汉字） | https://lbs.amap.com/api/webservice/download |
| 错误码说明 | https://lbs.amap.com/api/webservice/guide/tools/info |
| 坐标拾取器（验纠偏） | https://lbs.amap.com/tools/picker |
| 配额查看 | https://console.amap.com/dev/flow/manage |

取 Key 的三条硬要求（做错必报错）：

1. 先实名认证（个人认证额度更低，企业更高）。
2. 应用里添加 Key 时服务平台必须选 **Web服务**；选 JS API / Android 调 restapi 会报平台不匹配类错误。
3. Key 只放 `.env`，不进代码、不进仓库。

## 2. 两条硬限制（官方原文口径）

**a) 拿不到全量。** 搜索 POI 2.0 文档原文：「目前搜索是不支持返回全量数据的，同请求参数翻页查询最多支持获取 200 条数据」。限定词是「**同请求参数**」——同一组 city/types/keywords/bbox/polygon 最多 200 条，翻页也翻不出第 201 条；但请求次数本身不受此限制（只受配额限制）。所以 200 是**每次查询的容量上限，不是总量上限**。

**b) 配额是月配额 + 超限付费。** 流量限制页已指向定价页 https://lbs.amap.com/upgrade#price（2025-05-20 起改模型）。具体数字随认证类型/是否付费差异很大，必须在自己的控制台 `dev/flow/manage` 里看，不猜。

## 3. 网格切分：绕开 200 的做法

原理是集合并集：全市集合 = 各区 ∪，各区 = 各网格 ∪。只要每个子集真实数量 ≤ 200 就能完整取出，合并后自然超过 200。

**判据必须用响应里的 `count`，不能看「返回是不是正好 200 条」**（真实数量可能恰好 200 或 199）：

```
count <= 200  → 该格取全，停止
count >  200  → 被截断，继续往下切
```

终止条件有两条：`count ≤ 200`，或网格已到 MIN_SIZE（如 500 m，承认取不全并**记日志**——这决定热力图可信度，也是数据边界证据）。

递归形状（伪代码，实现自写）：

```python
def fetch_all(area, category):
    resp = call_api(area, category)
    if int(resp["count"]) <= 200:
        return resp["pois"]
    if area.size < MIN_SIZE:
        return resp["pois"]          # 记录该格不完整
    return sum((fetch_all(sub, category) for sub in area.split(2)), [])
```

节奏是**先粗后细，每次只推进一层**：

- 第 1 轮：13 个区 × 4 类（学校/医院/商场/公园）≈ 52 次请求，看哪些 (区,类) 被截断。
- 第 2 轮：只对被截断的组合切 2 km 网格，每格每类 1 次，并记录已覆盖 bbox。
- 第 3 轮：仍截断的再细分 `types` 子码（如 医院 → 综合/专科/诊所）。

追不到全量的两类情况要提前接受：密度极高的类（餐饮、便利店）在 500 m 仍 >200，只能靠更细 typecode 叶子节点继续分；聚合类 typecode 同理。因此本方法的天花板是「分辨率足够」，不是「绝对全量」。

请求量与成本估算：13 区 × 4 类 = 52 次起步；触顶细分后约 **300–800 次**；每请求 100–300 ms，800 次约 10–20 分钟；连续打会触发 QPS 限流错误码，代码里 `time.sleep(0.2)` 是最省事的保险。

关键判断：可达性分析要求的是「空间分布不能有洞」，不是「一条不漏」。这 4 类走一轮粗查（估计 200–400 次）就够；高密度类本不该进可达性模型。**先只跑中心城区 3–4 个区（江岸/江汉/武昌/洪山）做小样本**（约 20 次请求），10 分钟内就能判断配额是否够全域、2 km 网格是否够、字段与纠偏是否正确。

## 4. 采集是一次性成本，raw JSON 是真相层

数据最终固化在 PostGIS 的 `poi` 表里，不在源码里：前端展示/统计/热力图只查库，换筛选口径是纯 SQL，**0 次 API 请求**。

「想加东西」分五种，只有三种要重新请求：

| 需求 | 要打 API 吗 | 做法 |
|---|---|---|
| 加新类别（如地铁站） | 要 | 只跑该类，旧数据不动 |
| 加区/城市 | 要 | 只跑那个 bbox |
| 同范围刷新（新开/关店） | 要 | 按月重跑，`ON CONFLICT` 更新 |
| 换分类映射 | **不要** | 从 raw JSON 重放 normalize 层 |
| 改表结构（加字段/精度/索引） | **不要** | 从 raw JSON 重放入库层 |

因此 `raw/` 不是中间产物而是真相层：留有 raw 就能离线重算，没有就得再烧 300–800 次请求。

断点续跑必须靠磁盘 manifest，不靠记忆：

```jsonc
// data/raw/amap/manifest.json
{
  "fetched_at": "2026-10-25T09:00:00+08:00",
  "tasks": {
    "420100|南湖街道|education|2km#3": { "count": 87, "got": 87, "done": true },
    "420100|…|medical|2km#7":           { "count": 214, "got": 200, "done": false, "subdivided": true }
  }
}
```

启动先读它，`done: true` 的格子直接跳过；再配 `{area_id, category} → count` 的切分结果缓存，下次先读缓存省请求。

入库幂等（重跑不产生重复、不炸）——对 `src_id` 建唯一索引：

```sql
INSERT INTO poi (src_id, name, category, geom, fetched_at)
VALUES (…, ST_SetSRID(ST_MakePoint(%s, %s), 4326), now())
ON CONFLICT (src_id) DO UPDATE
  SET name = EXCLUDED.name, geom = EXCLUDED.geom, fetched_at = now();
```

表里必须有 `fetched_at`：POI 有生命周期（搬迁、改名、倒闭），前端标注「数据截至 2026-10」是专业度，也是面试时主动交代时效边界的抓手。

## 5. etl/ 与应用的边界：流程独立、契约锁定

取数脚本属于数据工程，不属于应用系统，跑完即退出，不参与任何页面请求：

```
【离线，手动跑】 etl/(Python) sources/amap.py → raw JSON → normalize.py → load.py → PostGIS Spatial.poi
【在线，常驻】   GeoServer :8080 只读发布 poi 图层 → FE(Vue) 只跟 GeoServer/后端说话；Spring Boot 也只读库
```

Python 脚本与 FE / Java 后端之间**没有任何调用关系**，唯一交集是库里那张表。

独立性五维：依赖（Python vs Node/Java）、生命周期（跑完即止 vs 常驻监听）、触发时机（终端手动 vs 用户开页面）、部署（本机 vs 将来对外）、敏感信息（高德 key vs 天地图 tk）。

但三份契约是硬绑定，定错会连环出问题：

| 契约 | 错后果 |
|---|---|
| 表名 `poi` + 几何列 `geom` + `geometry(Point,4326)` | GeoServer 图层发不出，或发出但坐标全偏 |
| `category` 取值域（education/medical/mall/park） | 前端图例显示 4 类但图上只出 2 类颜色 |
| SRID 4326 | 与 `admin_area` 叠图错开（即 GCJ-02 坑） |

注：高德返回 GCJ-02，入库前须 `transform.py` 转 WGS84，武汉实测偏移 587 m，详见文档 `a1c65b87-9f7b-4f61-a154-9b52872efa6a`（z16 窄地物验证法）。

建议目录（与 `FE`、`Project`、`data` 平级）：

```
openlayers服务平台开发\
├── data\        原始数据（wuhan.json、raw JSON）
├── FE\          前端（Vue，已上 GitHub）
├── Project\     vanilla 版（冻结）
└── etl\         采集脚本
    ├── config.py        库连接、key、bbox、分类映射
    ├── sources\{amap.py, osm.py}
    ├── normalize.py / load.py / main.py / requirements.txt
    ├── .env             AMAP_KEY / PG 密码（.gitignore）
    └── .gitignore       排除 .env、data/raw/、*.sql
```

三条隔离纪律：独立 venv（`etl/.venv` 进 .gitignore）；独立 `.env`；`data/raw/` 与 `*.sql` 不进仓库。

**不过度设计**：它不是微服务、不是常驻进程，不需要 Docker / REST 包装 / 并发 / 守护进程。单入口 `python main.py --source amap --category education` 就够。唯一的工程感要求是三条：能断点续跑（manifest）、能重放（raw JSON）、能幂等（`ON CONFLICT`）——这是脚本与玩具代码的分界线。

## 6. 合规

高德服务协议（https://lbs.amap.com/home/terms/）对数据缓存与再分发有约束：`poi.sql` / `poi.csv` / `raw/` 一律 `.gitignore`，README 写「POI 数据仅用于本地学习演示，来源高德开放平台，不随代码分发」；备份放本地不进仓库。反复网格切分抓取虽技术上可行，但意图与平台「不支持返回全量」的设计相悖，学习/个人/量小/不商用/不二次分发可接受，**不要做成公开通用采集工具，也不要在简历里夸大数据量**。

对比：OSM 是 ODbL，可存可再分发（署名 © OpenStreetMap contributors），若项目需完全公开可复现，OSM 是安全选项（实测 1084 + 348 条，半小时可跑通管道），高德是「数字好看但只能自己看」。建议先跑通 OSM 把「取数 → 中间格式 → 入库 → 发布 → QGIS 验收」立住，再手测两个高德请求确认字段与偏移后写 `amap.py`。
