---
id: "9b55863a-1c10-4f00-baa0-479ddaed58ab"
title: "Translation 智慧地铁：站点详情浮窗（queryTemplate.vue）HUD 化改造 + 「科幻字体从未生效」字体实测结论 + 详情卡自动换边"
description: "2026-10-11 把点击站点后的详情浮窗从普通描边卡改为 HUD 风格并放大（620×286、图片区 300×210），同期用画布量宽探针推翻了「项目科幻字体 Rajdhani 在生效」的判断（实际加载的是 Chakra Petch / JetBrains Mono / Noto Sans SC），并为加宽后的详情卡新增贴右缘自动镜像换边；含实测尺寸、验证方法与遗留的图层遮挡项。"
status: "active"
created_at: "2026-10-11T10:38:41.796Z"
updated_at: "2026-10-11T10:38:41.796Z"
content_hash: "a896518819a547c6c35f3df73a157bc241f9539661f049d1a3cc2fb91da20b32"
source_paths:
  - "Translation/src/components/bottom/StationPanel/queryTemplate.vue"
  - "Translation/src/cesiumTools/lineAndpoints/popup/popup.js"
  - "Translation/src/components/screenUI/left1.vue"
session_ids:
  - "e141b4bd-fec3-459b-8ec6-c654905ec29d"
memory_body_ids:
  []
---

# 站点详情浮窗 HUD 化改造（Translation / 智慧地铁）

日期：2026-10-11。项目：`D:\WebGIS\web三维开发\智慧地铁项目\Translation`。
用户诉求：「将点击后的浮窗样式变更炫酷，图片区域增大，整体也可以增大」。

相关文档：
- `8ead2da9-2e1f-470b-9048-6d5da40f3bac` —— 同项目 popup 定位根因（canvas 绘制缓冲尺寸 ≠ CSS 尺寸），本次换边逻辑位于同一 popup 链路。
- `f120df6f-8480-4127-9793-8df0e970da36` —— popup 模块拆分的由来（screenUI → bottom、StationPanel 拆目录、新增 popup 模块）。

## 1. 尺寸与实测（默认俯瞰视角 scale 0.926）

| 项 | 改前 | 改后 |
|---|---|---|
| 图片区 | 150 × 104 | 300 × 210（面积约 4 倍） |
| 卡片设计尺寸 | 380 × ~160 | 620 × 286 |
| 实测渲染尺寸 | — | 537 × 258（图片区渲染 260 × 182） |

## 2. 加入的视觉元素（均纯 CSS/现有依赖，不新增网络依赖）

- HUD 四角括号 + 18px 斜切角，青色发光
- 扫描光带：4.6s 循环自上而下掠过；**只动 `transform`**，走合成层、不触发布局
- 旋转菱形徽标（6s/圈）+ ONLINE 状态灯（脉冲呼吸）
- 标题：Chakra Petch 700 / 22px / 0.12em 字距 + 青色双层辉光
- 字段名：菱形青色小点做项目符号，等宽字体读数感
- 线路色块：按线路色描边 + 内发光，颜色与左侧线路面板同源
- 图片框：网格底纹、双角标、纯 CSS 画的图片图标、「slot: image」虚线标签
- 背景：左上青光晕 + 右下金光晕 + 深蓝底三层叠加
- 信息列竖直铺开（`space-between`），避免左下角留白
- 关闭按钮：橙色斜切角，hover 反白发光

验证脚本实测到的装饰计数：`corners:4 / scan:1 / badge:1 / status:ONLINE / mediaCornerTicks:true`，动画 `qp-scan` / `qp-badge`（spin）/ `qp-dot`（pulse）均在跑。

## 3. 关键结论：全项目的「科幻字体」一直没生效（推翻了最初判断）

最初 grep 只看到 `src/components/baseUI/*.html` 里的 Google Fonts `<link>`，据此误判「字体没被引用、一直在回退」；实测数据推翻了它。

来源：`Translation/src/components/screenUI/left1.vue:382` 有一条 `@import url('https://fonts.googleapis.com/css2?family=Chakra+Petch...&family=JetBrains+Mono...&family=Noto+Sans+SC...')`；而 `baseUI/*.html`（foot.html / left1.html / right1.html）**没有被任何组件引用**。

`document.fonts` 实测：

| 字体 | 脸数 | 结论 |
|---|---|---|
| Chakra Petch | 12 | ✅ 已加载（字重 500/600/700） |
| JetBrains Mono | 24 | ✅ 已加载 |
| Noto Sans SC | 404 | ✅ 已加载 |
| **Rajdhani** | **0** | ❌ 从未加载 |

`--font-scifi` 里排第一的 **Rajdhani 只在未被引用的 `baseUI/foot.html` 中出现**，所以它一直静默回退成系统字体——项目「本来想要的科幻字体」从未真正生效。本次改用已加载的 Chakra Petch + JetBrains Mono 直接做出目标效果。

### 判断字体是否真命中：不能信 `document.fonts.check()`

`document.fonts.check()` 对**根本不存在的字体也返回 `true`**（因为没有待加载项），本次据此得出过一次假阳性。可靠的判定是**画布量宽对比**（同字符串在目标字体与 `sans-serif` 基准下的宽度）：

| 探针 | 量宽 | sans-serif 基准 | 是否命中 |
|---|---|---|---|
| Chakra Petch 700 | 232.2 | 246.68 | ✅ |
| Chakra Petch 400 | 225.8 | 234.57 | ✅（曾误以为写 400 会掉回退，已更正） |
| JetBrains Mono 600 | 240.0 | 246.68 | ✅ |
| Rajdhani 700 | 246.68 | 246.68 | ❌ 与基准完全相同＝纯回退 |

（注：`document.fonts.check` 的假阳性与 `@import` 里 Chakra Petch 只声明了 500/600/700 但 400 也能命中的现象，都说明**以实测渲染为准，不以声明或 API 布尔值为准**。）

## 4. 详情卡自动换边（卡片加宽的配套改动）

620px 的卡片配原固定偏移 `[150, -20]`，靠近屏幕右缘的站点会把卡片顶出视口。改动在 `Translation/src/cesiumTools/lineAndpoints/popup/popup.js`（约 L194）：`popupType === 'queryPopup'` 时，若右侧放不下则把卡片中心镜像到站点左侧；站名标签的居中行为未改动。

实测（点击最右侧换乘站「一大会址·黄陂南路」，站点 x=1479）：

```
不换边：中心 = 1479+150 = 1629 → 卡片 1360..1897（大半在屏外）
实际：  中心 = 1290（镜像到左侧）→ rect 1021..1559
        fullyInsideViewport: true / closeHit: BUTTON.qp-close / bodyFallsThrough: CANVAS
```

同时复验了「南京东路」「陆家浜路」等站点：卡片完整在视口内、关闭按钮可点、`bodyFallsThrough: CANVAS` 表示地图仍可拖拽。

> 踩坑：验证脚本里 `sideVsStation` 一开始拿卡片**左边缘**和站点坐标比，而卡片实际以「站点 + 150px」为**中心**定位，导致误报「左侧」。判定必须用 `cardCenterX`。

## 5. 改动文件

| 文件 | 改动 |
|---|---|
| `Translation/src/components/bottom/StationPanel/queryTemplate.vue` | 整体重做样式与尺寸；改用真加载的 Chakra Petch / JetBrains Mono |
| `Translation/src/cesiumTools/lineAndpoints/popup/popup.js`（约 L194） | 详情卡右侧放不下时镜像到站点左侧 |

## 6. 遗留项（尚未处理，待用户决定）

卡片渲染在 HUD 图层之下：弹窗挂在 `viewer.cesiumWidget.container`，HUD 面板在其之上，截图时「渲染环境正常」提示框曾盖住卡片左侧。影响是站点贴近屏幕底部时「站点管理」面板可能压住卡片一部分。若要把详情卡层级提到 HUD 之上，需在 `App.vue` 的层叠关系上调整，并回归验证不影响到其他面板。

## 7. 复现用验证环境（临时脚本，可能已不存在）

Playwright 脚本位于 `%TEMP%\verify-query-v2.mjs`（含点击换乘站、dump 卡片信息、截图到 `.review/queryTemplate-v2-full.png` 与 `queryTemplate-v2-crop.png`）、字体探测脚本 `%TEMP%\check-fonts.mjs`。脚本内的 `page.evaluate` 不能直接引用 Node 侧变量，需作为参数传入，否则报 `ReferenceError`。页面持续存在 1 条无关的 `400 (Bad Request)` 资源错误。
