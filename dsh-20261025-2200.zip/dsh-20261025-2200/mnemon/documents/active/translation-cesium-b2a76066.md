---
id: "b2a76066-1655-4138-8713-e442ebffed6e"
title: "Translation 跟车相机键位修正：左键只转水平、中键（按住滚轮）同管水平+俯仰——Cesium 原生映射源码证据、双轴基准取点、中键自动滚动拦截"
description: "trainRoam.js 跟车相机鼠标键位在用户纠正后的最终版：左键拖=只改 heading；中键拖=同时改 heading 与 pitch（两轴都从 pointerdown 那一刻的基准角算起，不累加）；滚轮=只改 range。含 Cesium ScreenSpaceCameraController 原生映射源码行号（rotateEventTypes/tiltEventTypes/zoomEventTypes）、Chrome 中键自动滚动必须拦 mousedown 而非 pointerdown、逐像素实测数据，并说明文档 33cfa818 中的旧键位表已被本文取代。"
status: "active"
created_at: "2026-10-17T11:54:45.800Z"
updated_at: "2026-10-17T11:54:45.800Z"
content_hash: "28d0edb490bde35d13f286e514f53753eb42247c30a38ca7e5dcd424a64a6b4c"
source_paths:
  - "Translation/src/cesiumTools/lineAndpoints/train/trainRoam.js"
session_ids:
  - "4b797dde-1d5b-4b35-9793-b327471fa0ed"
memory_body_ids:
  []
---

# 跟车相机键位：最终分工与踩坑记录

改动文件只有一个：`Translation/src/cesiumTools/lineAndpoints/train/trainRoam.js`。

> **对既有文档的取代关系**：`33cfa818` 记录的是前一版实现——左键同时接管 heading 与 pitch（两轴都放在 `handlePointerDown/Move` 的同一个左键分支里）。那一版被用户否掉，键位表以本文为准；`33cfa818` 中「为何必须自己接管相机/输入」「锁 `screenSpaceCameraController` 并快照还原」「range 22~1420m」「灵敏度 0.35 / 0.28 度每像素」「pitch −82°~−4°」等结论仍然有效，只有**按键归属**变了。

## 1. 最终键位（用户两次纠正后确定）

| 操作 | heading（水平） | pitch（俯仰） | range（视距） |
|---|---|---|---|
| 左键拖 | ✅ | ❌ | ❌ |
| **中键拖**（按住滚轮拖动） | ✅ | ✅ | ❌ |
| 滚轮 | ❌ | ❌ | ✅ |

需求演进：
1. 初版：左键同时管两轴 → 用户否掉：「按住左键只是相机平移！」
2. 第二版：左键只改 heading，中键只改 pitch → 用户追问「能中键同时控制水平和俯仰吗」
3. 最终：中键同时管两轴。实现上只是把 heading 那行也放进中键分支。

## 2. Cesium 原生映射（源码证据，用于对齐直觉）

`Source/Scene/ScreenSpaceCameraController.js`：

```
:176  rotateEventTypes = LEFT_DRAG                        // 左键 = 转（orbit）
:193  tiltEventTypes   = [MIDDLE_DRAG, PINCH, {LEFT_DRAG+CTRL}, {RIGHT_DRAG+CTRL}]
                                                          // 中键 = 俯仰倾斜
:161  zoomEventTypes   = [RIGHT_DRAG, WHEEL, PINCH]        // 滚轮 = 缩放
```

要点：**Cesium 默认左键本来就是转向、滚轮本来就是缩放**，中键才是倾斜。所以不存在「把转向从左键改到滚轮」这回事；上一版的错误在于让左键吞掉了中键的倾斜语义。用户对原生映射的记忆是准确的，遇到这类分歧应先查 `ScreenSpaceCameraController` 源码再改代码。

## 3. 双轴的基准取点（关键实现约束）

两个轴都必须从 **`pointerdown` 那一刻的基准角**算起：

```js
this._drag = { x, y, heading: this.viewHeading, pitch: this.viewPitch };   // 按下时快照

this.viewHeading = this._drag.heading - dx * 0.35 * DEG;                  // 都用快照做基准
this.viewPitch   = Cesium.Math.clamp(
  this._drag.pitch - dy * 0.28 * DEG, this.minPitch, this.maxPitch);
```

若改成在当前角度上累加（`this.viewHeading -= dx * k`），同一次拖动里每一帧都以「已经转过的角度」为起点，斜拖会迅速失控，松手后仍继续漂移。左右键分支共用同一份 `_drag` 快照，因此中键斜拖等于两个互相独立的线性变换，不互相累积误差。

## 4. Chrome 中键自动滚动必须拦 `mousedown`

按住滚轮拖动时 Chrome 会弹出自动滚动光标（上下双箭头）。**只在 `pointerdown` 里 `preventDefault()` 拦不住**——自动滚动由 `mousedown` 触发，而 `pointerdown` 早于它、取消不了后续事件。因此额外在 canvas 上挂 `handleMouseDownCapture`，仅当 `button === 1` 时 `preventDefault()`。

## 5. 实测（2026-10-17，/realtime，零 pageerror）

| 操作 | heading | pitch |
|---|---|---|
| 初始 | 35° | −22° |
| 左键横拖 200px | **325°（−70°）** | −22°（不变 ✓） |
| 左键纵拖 100px | 325°（不变 ✓） | −22°（不变 ✓） |
| 中键下拖 100px | 325°（不变 ✓） | **−50°（−28°）** |
| 中键上拖 120px | 325° | **−16.4°**（抬高，受 `maxPitch` −4° 夹取） |
| 中键斜拖（右 100 / 下 50） | **290°（−35°）** | **−36°（−14°）** |
| 中键反斜拖（左 100 / 上 100） | **325°（+35°）** | **−8°（+28°）** |

退出栏目后 `enableRotate / enableZoom` 回到 `true`、实体数回到 418，列车删干净——这条回归点与 `33cfa818` 一致，不能省。

## 6. 可调参数（仍在 trainRoam.js）

| 想改什么 | 位置 | 当前值 |
|---|---|---|
| 横向灵敏度 | `handlePointerMove` 的 `0.35 * DEG` | 0.35°/px |
| 纵向灵敏度 | 同处 `0.28 * DEG` | 0.28°/px |
| 俯仰上下限 | 构造函数 `minPitch / maxPitch` | −82° / −4° |
| 初始朝向 | 构造函数 `viewHeading / viewPitch` | 35° / −22° |
| 视距 | 构造函数 `range / minRange / maxRange` | 190 / 22 / 1420 m |

## 7. 可复用经验

- 接管 Cesium 相机输入前，先读 `ScreenSpaceCameraController` 的 `rotateEventTypes / tiltEventTypes / zoomEventTypes / translateEventTypes / lookEventTypes` 默认值，按原生语义分配按键，别自创一套；用户对「哪个键干什么」的直觉基本就是原生映射。
- 拖动改角度一律用「按下时快照 + 绝对位移」，不要在状态上增量累加，否则多轴同拖会失控。
- 每个鼠标键单独一个分支、单一职责；后续加轴（如 `lateralOffset` 真平移、Ctrl+左键倾斜别名）都是在这个结构上加分支，不必重写。
- Chrome 的中键自动滚动、右键上下文菜单这类浏览器默认行为属 `mousedown`/`contextmenu` 层面，`pointerdown` 的 `preventDefault` 不生效。
- 验证键位改动用「逐项改一个轴、断言另一个轴不动」的表格式实测最有效（见 §5），比肉眼观察可靠。
