---
id: "da3984e4-773d-4e58-a590-a5c7ac0ade40"
title: "Translation 智慧地铁：项目默认相机视角固化（DEFAULT_VIEW + applyDefaultView）"
description: "2026-10-07 把用户浏览器里手调的俯瞰视角固化为项目进入时的默认相机（sceneManager.js 的 DEFAULT_VIEW/applyDefaultView），替代 viewer.zoomTo(tilesets[1]) 的包围球自动视角；含实测参数、调用时序理由与从浏览器无刷新采样相机参数的探针手法。"
status: "active"
created_at: "2026-10-07T15:05:21.417Z"
updated_at: "2026-10-07T15:05:21.417Z"
content_hash: "a66ecfdfa74d6d6098fa9d8cbcbb0f0f230e4fe0fa23e1e5d4c06736cf522b45"
source_paths:
  - "Translation/src/cesiumTools/sceneManager.js"
  - "Translation/src/views/cesiumView.vue"
  - "Translation/src/components/screenUI/foot.vue"
session_ids:
  - "5f635284-6285-4d26-8460-935735a92c6e"
memory_body_ids:
  []
---

# Translation 智慧地铁：项目默认相机视角固化

实现日期：2026-10-07。项目根 `D:\WebGIS\web三维开发\智慧地铁项目`，前端目录 `Translation/`。

**需求（用户原话）**：「这个项目，每次进入时，相机的视角设置为浏览器现在的画面样子。」即把用户手调好的视角固化为每次进场的统一默认视角，而不是让相机自己算。

相关文档：`176a2197-fd01-482e-94ae-f8eda62baced`（同批 HUD 维护：perfGuard 检查卡 + left1 面板重叠修复、HUD 设计像素量测法）。

## 1. 改前行为：`zoomTo` 的包围球自动视角

`Translation/src/views/cesiumView.vue` 的 `onMounted` 里，瓦片加载完成回调的最后一行是 `viewer.zoomTo(tilesets[1])` —— 让 Cesium 按外滩模型（`EastProject/tileset.json`）的包围球自己算一个视角。

实测该自动视角落在：`lon 121.501184, lat 31.218778, height 1166.19 m, heading 0°, pitch -28.6619°`。

注意它是在**瓦片加载完成后**执行的，所以任何在此之前设置的相机都会被它重新框一遍——这正是必须删掉它的原因。

## 2. 改后实现

| 文件 | 改动 |
|---|---|
| `Translation/src/cesiumTools/sceneManager.js` | 新增 `DEFAULT_VIEW` 常量 + `applyDefaultView(viewer)`（内部用 `camera.setView`，**无飞行动画**，进场即定格） |
| `Translation/src/views/cesiumView.vue` | 在 `initViewer` / `addTecenMap` 之后**立即**调用 `applyDefaultView(viewer)`；**删除** `viewer.zoomTo(tilesets[1])` |

固化下来的视角常量（从用户浏览器实测采样，非估算）：

```js
longitude: 121.458201,
latitude:  31.270543,
height:    4821.76,   // 米
heading:   131.1964,  // 度
pitch:     -45.3461,  // 度
roll:      0.0108,
```

`applyDefaultView` 内用 `Cesium.Math.toRadians()` 换算 heading/pitch/roll 后交给 `camera.setView`。

### 两个必须遵守的时序约束

1. **放在瓦片加载之前调用**（`initViewer` / `addTecenMap` 之后立即调用，而不是等 `loadTilesets` 回调）：这样瓦片 LOD 从第一帧就按这个视角选，进场不会先卡在错误细节再跳变。
2. **必须删掉 `zoomTo`**：它跑在瓦片加载完成之后，会把相机重新框一遍，正好覆盖默认视角。

## 3. 验证结果

探针在加载后连续采样，页面报错为空：

```
加载  3s : {"lon":121.458201,"lat":31.270543,"height":4821.76,"heading":131.1964,"pitch":-45.3461,"roll":0.0108}
加载 23s : {"lon":121.458201,"lat":31.270543,"height":4821.76,"heading":131.1964,"pitch":-45.3461,"roll":0.0108}
```

第二行是关键判据：瓦片全部加载完、昼夜/流光/水面特效挂载之后视角**未被任何后续逻辑改动**。探针用完已清理，验证脚本确认无残留。

## 4. 可复用手法：从用户浏览器无刷新读出真实相机参数

浏览器控制通道只能读文本、不能执行 JS；且直接刷新页面会重置掉用户手调的相机。做法是**往一个 HMR 安全的组件里临时插一段探针代码**：

- 选 `Translation/src/components/screenUI/foot.vue`（该文件的 HMR 不会重挂 CesiumView，且里面已有 `dataStore.viewer`）；
- 每秒把 `viewer.camera.positionCartographic` 与 heading/pitch/roll（弧度转度）写进一个 `position: fixed; left: -99999px` 的隐藏元素（如 `#camera-probe`）；
- 再用浏览器读文本通道把该元素文本读出来 —— 不需要用户手动开控制台，页面不用刷新，相机不会被重置；
- 读完把探针删干净并复查无残留。

## 5. 以后要换默认视角

开发期已挂调试句柄（`if (import.meta.env.DEV) globalThis.__cesiumViewer = viewer`，生产构建不挂载）。在浏览器里把视角调到满意，F12 粘这段取参数：

```js
(() => { const c = __cesiumViewer.camera; const p = c.positionCartographic; const d = 180/Math.PI;
  return { lon:+(p.longitude*d).toFixed(6), lat:+(p.latitude*d).toFixed(6), height:+p.height.toFixed(2),
           heading:+(c.heading*d).toFixed(4), pitch:+(c.pitch*d).toFixed(4), roll:+(c.roll*d).toFixed(4) }; })()
```

把结果填进 `sceneManager.js` 的 `DEFAULT_VIEW` 即可（代码注释里也附了这段）。

**未采用的替代方案**：把视角存进 localStorage「刷新即记住上次视角」。代价是每个打开者看到各自的视角，失去统一进场画面，与本次需求（统一默认视角）冲突，故未做。
