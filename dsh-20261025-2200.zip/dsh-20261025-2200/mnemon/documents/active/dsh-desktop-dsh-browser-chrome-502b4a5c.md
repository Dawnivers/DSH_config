---
id: "502b4a5c-16a2-4ea4-953c-b861592308b7"
title: "DSH Desktop 安装 dsh-browser（Chrome 侧栏扩展 + 桥插件）实录"
description: "本机 2026-10-07 给 DSH Desktop（desktop profile）安装 omdsh-dev/dsh-browser 的完整步骤、踩过的坑与复装/升级要点；下次升级或排障直接看这里。"
status: "active"
created_at: "2026-10-07T01:44:25.253Z"
updated_at: "2026-10-07T01:44:25.253Z"
content_hash: "7e18a0d8d1b01fc54eb5982a54d3c76dbed528381fda64de50e55bff5bcd2c2d"
source_paths:
  - "dsh-browser/README.zh.md"
  - "dsh-browser/scripts/install.ps1"
  - "dsh-browser/packages/browser/bridge-browser/cordis.patch.yml"
  - "dsh-browser/extensions/dsh-browser/src/background/index.ts"
session_ids:
  - "session-8b1651e5-e564-43b0-8984-f55266dadcd5"
memory_body_ids:
  []
---

# DSH Desktop 安装 dsh-browser 实录（2026-10-07 本机）

上游：https://github.com/omdsh-dev/dsh-browser （README 里脚本仍写作 Lum1104/dsh-browser，同一仓库）。
它 = 桥插件 `@yuxianglin/dsh-bridge-browser` + Chrome MV3 侧栏扩展，**不是**本机已有的 `dsh-builtin-browser`。

## 落地位置

| 东西 | 路径 |
|---|---|
| 源码（浅克隆） | `D:\Users\林先语\Documents\deepseek-harness\default-workspace\dsh-browser` |
| 桥插件产物 | 同目录 `packages\browser\bridge-browser\lib\`（index.js / protocol.js / invariant.js / client.js） |
| 扩展产物 staging | `C:\Users\林先语\.dsh\browser-extension`（Chrome「加载已解压的扩展程序」指向它） |
| profile 注册项 | `C:\Users\林先语\.dsh\profiles\desktop\package.json` → `"@yuxianglin/dsh-bridge-browser": "link:D:/.../dsh-browser/packages/browser/bridge-browser"`，且 `dsh.profile.bundles` 已追加同名条目 |
| 桥 token | `C:\Users\林先语\.dsh\ext-bridge-token`（回环连接无需手填） |
| 备份 | `default-workspace\backup-desktop-profile-20261007-093128\`（package.json / pnpm-lock.yaml / cordis.patch.yml / cordis.yml / pnpm-workspace.yaml） |

## 装法（可复现）

1. clone 仓库（浅克隆够）。
2. `pnpm install --frozen-lockfile --pm-on-fail=ignore`
3. 构建桥插件：`node node_modules\typescript\bin\tsc -b --pretty false` → `node node_modules\tsdown\dist\run.mjs` → 再 `Copy-Item src\client.js lib\client.js`（等价于 `pnpm --filter @yuxianglin/dsh-bridge-browser run build`）。
4. 构建扩展：在 `extensions\dsh-browser` 里把 `node_modules\.bin` 加进 PATH，再 `node .\scripts\build.mjs`（脚本用 shell 调 `vite`，PATH 里没有会报 `'vite' 不是内部或外部命令`）。
5. 注册（**关键**）：用外壳自己的 CLI 入口，不能用 dsh 的 bin.js：
   `%APPDATA%\DSH Desktop\host-commands\desktop\generations\<hash>\bin\dsh.cmd plugin add "link:<绝对路径，正斜杠>" --pm-on-fail=ignore`
6. 扩展：Chrome → `chrome://extensions` → 开发者模式 → 加载已解压的扩展程序 → 选 staging 目录。

## 本机特有的坑

- **pnpm 会自己切版本然后挂掉**：仓库 `package.json` 声明 `packageManager: pnpm@11.7.0`，而外壳自带 pnpm 是 11.8.0，pnpm 会去 store 里找 11.7.0 的链接，路径是坏的 → `Cannot find module 'D:\.pnpm-store\v11\links\@\pnpm\11.7.0\...\pnpm.mjs'`。**每次 pnpm 调用都要带 `--pm-on-fail=ignore`**（`install` / `run` / `plugin add` 都一样）。
- PATH 里的裸 `pnpm` 可能解析到那个坏 shim；要用运行时 pnpm：`%APPDATA%\DSH Desktop\runtime-commands\generations\<hash>\bin\pnpm.cmd`。
- **desktop profile 的插件只能由外壳管理**：`node resources\app\node_modules\@deepseek-ai\dsh\lib\bin.js plugin --profile desktop ...` 直接报 `profile "desktop" is managed exclusively by the Electron application`。正路是 `"DSH Desktop.exe" --expose-internals "<...>\resources\app\lib\desktop-cli.js" plugin ...`，或用上面那个 `dsh.cmd` 启动器。
- **端口发现**：扩展只自动探测 `[3080, 3081, 3090, 14389, 43189]`，而本机 Desktop Web 端口是从 43120 起回退分配、这次落在 **10655**。我已改 `extensions\dsh-browser\src\background\index.ts` 的 `DISCOVERY_PORTS`，追加 `10655, 43120–43124` 并重建（改完要重构 + 在 Chrome 点「重新加载」）。不补丁也能用：侧栏设置里手填 `ws://127.0.0.1:10655`。
- **扩展只在侧栏打开时连桥**（`startBridge()` 里 `panelPorts.size === 0` 直接 return）。侧栏没开时 `browser_*` 会报 `no browser extension is connected to the bridge`，这不是装坏了。
- 验证端点：`http://127.0.0.1:10655/ext/bridge-config` 返回 `{"wsUrl":"ws://127.0.0.1:10655/ext/bridge"}` 即桥已挂。
- 注册是热挂载：这次没有重启外壳，`browser_*` 工具当场出现在会话里。

## 升级 / 重装

`dsh-browser` 仓库拉新 → 重跑上面 2–4 步 → 重新在 profile 里 `dsh.cmd plugin add` 同一个 link 路径 → Chrome 里点扩展的「重新加载」。DSH Desktop 自身升级会覆盖 `resources\app`，但本插件在 profile 与独立仓库里，不受影响。

## 安全提醒

- 桥路径 `/ext/bridge` 在 `/api` 信任栅栏之外，自带 bearer token；**不要**把 `dsh web --host 0.0.0.0` 暴露在不可信网络。
- 权限模型：点击/输入/按键/导航默认要用户在侧栏批准，「允许模型完全控制浏览器」是显式全局开关。但 `browser_close_tab` 这类标签页级操作不在批准闸门内——2026-10-07 实测我按 tabId 关标签页时**没有**弹批准，且我因为两次 `browser_list_tabs` 之间开过新页导致 tabId 错位，误关了用户的 `chrome://settings/` 标签。教训：关标签前必须先 `browser_list_tabs` 复核 tabId，且不要跨操作复用旧 id。
