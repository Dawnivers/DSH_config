---
id: "933d3b7b-396a-4f92-a8ff-62bd719670a8"
title: "智慧地铁_上线版：公网实测诊断（站点未部署 / 反代剥 /nginx 前缀 / dist 必须根部署）"
description: "101.43.119.248 与 dawnivers.top 的公网实测矩阵：瓦片与后端接口均正常，但站点根无 index.html、/nginx 反代剥前缀导致 3D Tiles 404、dist 绝对路径只能根部署；含验收 curl 清单与代码层遗留坑（option/options、Promise.all）。"
status: "active"
created_at: "2026-10-21T10:37:57.377Z"
updated_at: "2026-10-21T10:37:57.377Z"
content_hash: "d9965aeb163162735879ba1a3d20d2e4dd092be084f2f1253a25cb9870a1e1f2"
source_paths:
  - "src/router/index.js"
  - "src/api/request.js"
  - "src/cesiumTools/sceneManager.js"
  - "src/views/cesiumView.vue"
  - "vite.config.js"
session_ids:
  - "4b582788-08f2-4191-bc23-30164eae55f0"
memory_body_ids:
  []
---

# 智慧地铁_上线版：公网实测诊断

排查对象：`D:\WebGIS\web三维开发\智慧地铁_上线版\Project`（前端目录名仍为 `Project`，产物 `dist/`）。
结论一句话：**数据与服务都是好的，白屏/无建筑全部出在「上线这一步」**——站点根本没有被部署到 Web 根，且 `/nginx` 反代把路径前缀吃掉了。

相关文档：
- `696a9dcd-f643-4962-8452-b2296776993e`（瓦片 tar 上传 + `/model/` 静态托管方案、glb 进 dist 的打包事实）
- `cdaa0177-267d-4849-814e-19a5b4961664`（后端上服务器、pg_restore 坑、前端硬编码清单）

## 1. 环境事实（实测）

| 项 | 值 |
|---|---|
| 服务器 IP | `101.43.119.248` |
| 主域名 | `dawnivers.top` → 同一 IP；**当前根站是该用户的个人主页**（`<title>Dawnivers | 个人主页 · Pastel Blue & Frost Glassmorphism Portfolio</title>`，入口 `/assets/index-B0Z89mFl.js`），与本项目无关 |
| 后端域名 | `translationbe.dawnivers.top` → 同 IP，CORS `*` |
| `translation.dawnivers.top` | DNS 不存在（NXDOMAIN），别用 |
| 端口 | 80/443/666 开；888/8092/5173 关 |
| 证书 | `CN=dawnivers.top`，LiteSSL RSA CA 2025（TrustAsia），SAN 仅 `dawnivers.top` |
| 瓦片落点 | `/www/wwwroot/nginx_assets/Translation/{shangHaiBuilds_new_toPlane,EastProject}`（经 `:666/nginx/` 目录索引可见） |

## 2. 实测矩阵（判定依据）

| 请求 | 结果 | 判定 |
|---|---|---|
| `http://101.43.119.248/` | 200 但 body 是 138B 的 nginx `404 Not Found` 页 | ❌ 80 端口是 root 指向空目录的默认 server |
| `/index.html`、`/dist/`、`/dist/index.html`、`/assets/index-DI0X5o-Z.js`、`/cesium/Cesium.js` | 全 404（`/project/ /web/ /app/ /subway/ /metro/ /build/ /html/ /site/ /Translation/ /translation/ /assets/ /cesium/ /tileset.json` 亦逐个试探，全 404） | ❌ dist 没被任何站点服务 |
| `https://dawnivers.top/` | 200、60176B、引用 `/assets/index-B0Z89mFl.js` | ❌ 个人主页，不是本项目 |
| `:666/nginx/Translation/shangHaiBuilds_new_toPlane/tileset.json` | **200** `application/json` 3425B | ✅ 瓦片在 |
| 逐层下钻 `10_529_599_512.json` → `11_1058_1199_1024.json` → `12_2116_2399_2048.glb` | 200、580384B、magic `glTF`、`Last-Modified` 正常 | ✅ 数据完整可渲染 |
| `:666/nginx/Translation/EastProject/tileset.json` | **200** `application/json` 1771B | ✅ |
| `:666/Translation/...`（**去掉 `/nginx` 前缀**） | **404** | ⬅️ 反代故障指纹 |
| `http://101.43.119.248/nginx/...`（走 80 反代） | **404**（138B nginx 页） | ❌ 反代链路断了 |
| `:666/nginx/Translation/shangHaiBuilds_new_toPlane/`（目录本身） | 200 但 `text/html` 1.4MB、耗时 **30s** | ⚠️ `autoindex on` 且目录巨大 |
| `:666` `/getLine` | 200 `application/json` 60518B | ✅ |
| `/getWeather?extensions=base&city=310000` | 200、278B | ✅ |
| `/getStationInfo?name=人民广场` | **400** 空 body | ⚠️ 参数/查询侧问题，待查 |

产物侧事实：`dist/` 60.7MB、`cesium/` 683 个文件 13.8MB、`gz/br` 预压缩 348 个；`assets/index-DI0X5o-Z.js` 5,052,260B，其中 `CESIUM_BASE_URL` 出现 2 次，`localhost:666` / `/cesium` / `/model/` 硬编码出现 0 次（`/nginx/Translation` 出现 2 次、`translationbe.dawnivers.top` 1 次）。

## 3. 根因一：`proxy_pass` 带 URI 会剥掉 location 前缀

nginx 规则：`proxy_pass` 后面**只要带了 URI（哪怕只有一个 `/`）**，就会用该 URI 替换掉 location 匹配的那段。

```nginx
# ❌ 现状推测
location /nginx/ { proxy_pass http://127.0.0.1:666/; }   # 多这一根斜杠，/nginx 被剥掉
```
于是 `/nginx/Translation/...` → 666 收到 `/Translation/...` → 666 里只有 `/nginx` 无 `/Translation` → 404。这与实测「`:666/Translation/` 404、`:666/nginx/Translation/` 200」严丝合缝。

**为什么导致三维全黑**：`sceneManager.js` 的 `loadTilesets` 用 `await Promise.all(tilesets)`，任一 tileset reject 则 `loadCb` 永不执行，`handleshpModelEffect`、水体、外滩模型、昼夜切换统统不注册 → UI 正常、地球正常、就是没有建筑。

## 4. 根因二：dist 是绝对路径产物，只能部署在「站点根」

`dist/index.html` 与代码都是根相对路径：`/cesium/Cesium.js`、`/assets/index-*.js`、`url: '/nginx/Translation/...'`；`vite.config.js` 未设 `base`（默认 `/`），路由 `createWebHistory('/')`（`src/router/index.js:60`）。
因此放到 `/dist/`、`/web/` 等子目录：HTML 能开，JS/CSS/Cesium 全 404 → 纯白页。

最常见传错方式：

```
❌ /www/wwwroot/站点/dist/index.html   → 访问 / 是 404，访问 /dist/ 是白屏
✅ /www/wwwroot/站点/{index.html,assets/,cesium/,favicon.ico}
```

## 5. 推荐修复：同源直出，不要 666 反代

瓦片与站点在同一台 nginx 上，绕一层反代只会多一个坏点（还多一次跨域）。

```nginx
server {
    listen 80;
    server_name 101.43.119.248;          # 或已解析到本机的域名
    root /www/wwwroot/站点目录/dist;       # 指向 dist 的「内部」，不是 dist 本身
    index index.html;
    charset utf-8;

    location /nginx/ {                    # 3D Tiles 同源直出
        alias /www/wwwroot/nginx_assets/; # 结尾斜杠必须与 location 成对
        autoindex off;                    # 关掉：原目录列表 1.4MB / 30s
        add_header Access-Control-Allow-Origin * always;
        add_header Cross-Origin-Resource-Policy cross-origin always;
        expires 7d;
    }

    location / { try_files $uri $uri/ /index.html; }   # SPA 回退，/realtime /nodes 刷新才不 404
    gzip_static on;                                    # 产物已带 348 个 .gz/.br
    location ~* \.(glb|bin|jpg|jpeg|png|webp|b3dm|pnts|gltf)$ {
        expires 30d; add_header Cache-Control "public, max-age=2592000";
    }
}
```

若坚持反代（瓦片将来要挪机器），只改一个字符：`proxy_pass http://127.0.0.1:666;`——**结尾不许有斜杠、不许带 URI**。

## 6. 验收清单（改完在服务器或本机跑）

```bash
curl -s -o /dev/null -w '%{http_code}\n' http://站点/                         # 期望 200 且 body 是真 HTML
curl -s -o /dev/null -w '%{http_code} %{size_download}\n' http://站点/assets/index-*.js   # 200
curl -s -o /dev/null -w '%{http_code} %{size_download}\n' http://站点/cesium/Cesium.js    # 200 ≈3.4MB
curl -s -D - -o /dev/null http://站点/nginx/Translation/shangHaiBuilds_new_toPlane/tileset.json  # 200 application/json
curl -s -o /dev/null -w '%{http_code} %{size_download}\n' \
  http://站点/nginx/Translation/shangHaiBuilds_new_toPlane/12_2116_2399_2048.glb    # 200 580384
```
另：`http://ip/...` 对 `/xxx` 一律 301 → `https://dawnivers.top/xxx`，说明 80 与 443 共用同一 server block，改配置时别只改其中一个。

## 7. 代码层遗留坑（非当前故障，但迟早爆）

1. `sceneManager.js` 仍留着被注释的 `http://localhost:666/model/...`——线上若被取消注释，请求的是访客自己的 localhost。
2. `cesiumView.vue` 的 `modelUrls` 写 `option: {}`，而 `loadTilesets` 读的是 `options`：自定义参数一直静默被忽略。
3. `loadTilesets` 的 `Promise.all` 建议换 `Promise.allSettled`：单块瓦片挂掉至少场地还能出。
4. 666 静态服务 `autoindex on` 暴露目录结构（大目录列表 30 秒）。
5. 产物路径应集中成 `VITE_TILE_BASE`（或同类环境变量），别在构建产物里散落 `/nginx/Translation`。

## 8. 待确认 / 待办

- [ ] 用户**实际访问的是哪个地址**（IP 根 / 某端口 / 某子域名）——已测的 IP:80 与 dawnivers.top 都不是本项目，确定后才能精确对齐那个 server block。
- [ ] 站点根是否已上传 `index.html + assets/ + cesium/ + favicon.ico`。
- [ ] `/nginx/` location 是否已去掉 `proxy_pass` 的结尾斜杠，或改为 `alias` 直出。
- [ ] `/getStationInfo?name=人民广场` 400 的原因（后端参数校验 / 路由）。
