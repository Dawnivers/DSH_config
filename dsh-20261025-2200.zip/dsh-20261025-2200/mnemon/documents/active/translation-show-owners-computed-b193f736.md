---
id: "b193f736-9678-4340-b1f0-5e763faf3a7e"
title: "Translation 智慧地铁：站点显隐改为「照抄线路的写 show」模型——删掉 owners/隐藏集合/computed 同步"
description: "2026-10-10 按用户要求把站点显隐重构成与线路完全对称的写法：新增 setpoints.js 的 hideStationByName，stationState.js 缩到 26 行只剩 stationObjs 开关列表，删除 hiddenLines/hiddenStations 两个 reactive Set、owners 归属、applyStationVisibility 与 watch、面板重复的 stationVisible 规则；含 markRaw 的必要性、换乘站「取消线路即一刀切」的行为变化与实测（400/372/399/398）证据。"
status: "active"
created_at: "2026-10-10T10:47:52.741Z"
updated_at: "2026-10-10T10:47:52.741Z"
content_hash: "b8b4b1d8359786ab49f89ee3be437131598aefa7f76172cb8d4221336584d615"
source_paths:
  - "Translation/src/cesiumTools/lineAndpoints/points/setpoints.js"
  - "Translation/src/cesiumTools/lineAndpoints/line/setlines.js"
  - "Translation/src/stores/stationState.js"
  - "Translation/src/components/screenUI/StationPanel.vue"
  - "Translation/src/components/screenUI/Toolbar.vue"
session_ids:
  - "fd66567b-cb57-4f59-936f-c81adde9d264"
memory_body_ids:
  []
---

# 站点显隐重构：与线路完全对称的「写 show」模型

日期：2026-10-10。触发原因：用户明确要求「仿照线路数据的开关定义，将隐藏站点的函数定义在 setpoints 里面，不要你现在搞的那么复杂」。重构后站点的显隐写法与线路逐条对称，项目里不再有任何地方「计算」可见性。

相关文档：
- `3a0ce399-303d-4a00-95ef-e3c3d0db18af`（StationPanel 实现与两个真 bug；本文取代其第 5.1 节「换乘站归属规则」的做法）
- `1056d83b-fc4b-4598-834b-404ed7f42702`（站点管理改用 vue-router 驱动、Cesium 不重建；本文不改该结论）
- `8d3c4c05-ec6a-4bb9-98de-8a40750572a5`（光锥/光圈渲染链路；本文只改开关落点，不改渲染链路）

## 1. 结论：对照写法

```js
// setlines.js（原有）
export const hideLineByName = (entities, names, isShow) => {
  entities.forEach((line) => { if (names.includes(line.name)) line.show = isShow; });
};

// setpoints.js（本次新增，与上面对称）
export const hideStationByName = (stations, names, isShow) => {
  stations.forEach((station) => {
    if (!names.includes(station.name)) return;
    if (station.conePrimitve) station.conePrimitve.show = isShow;            // 光锥（Primitive）
    if (station.bottomCircleEntity) station.bottomCircleEntity.show = isShow; // 底圈（Entity）
  });
};
```

调用侧也是同一套：改响应式 `checked` → 立刻把结果写进三维对象。

```js
// StationPanel.vue
const toggleStation = (station) => { target.checked = !target.checked;
  hideStationByName(stationObjs, [station.name], target.checked); };
// Toolbar.vue 末尾：栏目没开就全灭
```

唯一不对称之处：一个站点由「光锥 + 底圈」两部分组成（分别挂在 `scene.primitives` 与 `viewer.entities`），所以函数内要切两个 `show`。

## 2. 改动文件

| 文件 | 改动 |
|---|---|
| `Translation/src/cesiumTools/lineAndpoints/points/setpoints.js` | 新增 `hideStationByName`（约 78 行，实码 41） |
| `Translation/src/stores/stationState.js` | 重写为 26 行（实码 9）：只剩 `stationPanelOpen` + `stationObjs` |
| `Translation/src/components/screenUI/StationPanel.vue` | 点击直接调 `hideStationByName`；`onMounted` 套状态、`onBeforeUnmount` 全隐藏 |
| `Translation/src/components/screenUI/Toolbar.vue` | 只负责「造对象 + 登记到 stationObjs」，不再同步可见性 |

最终 `stationState.js` 只有两样东西：

```js
const stationPanelOpen = computed(() => router.currentRoute.value.path === '/nodes'); // 栏目开合，由路由推导
const stationObjs = reactive([]);  // 开关列表：{ name, checked, conePrimitve, bottomCircleEntity }
```

## 3. 删掉的复杂度（以及为什么能删）

| 删除项 | 原职责 |
|---|---|
| `hiddenLines` / `hiddenStations`（两个 `reactive(Set)`） | 记录被关掉的线路/站点，再反推可见性 |
| `showAll()` / `hideAll()` | 仓库级批量操作 |
| `owners` 归属数组 + `stationOwners` computed | 判断换乘站是否还有别的线路开着 |
| `applyStationVisibility()` + `watch([stationPanelOpen, hiddenLines, hiddenStations], ...)` | 把上面三样算成可见性再写 `.show` |
| StationPanel 内重复的 `stationVisible()` | 面板自己再算一遍，只用于计数与压暗样式 |
| `focusedLine` 移出仓库 | 改为面板本地状态（副作用：重进栏目时右栏回到「1号线」，不再记住上次查看的线路） |

删除的依据：显隐规则不再需要「算」。只改 `.show`、不创建也不销毁，关掉栏目后对象仍留在场景里，再次打开是瞬时的（不重编译着色器、不重建几何体）；400 个对象的属性赋值开销可忽略。

## 4. 保留的实现细节：`reactive([])` 里必须 `markRaw`

`stationObjs` 用 `reactive([])`，因为面板勾选框要跟着每项的 `checked` 重渲染；但数组里装的 Cesium 对象都做了 `markRaw`：

```js
conePrimitve: markRaw(res.conePrimitve),
bottomCircleEntity: markRaw(res.bottomCircleEntity),
```

否则会被包成响应式代理，Cesium `remove()` 按引用 `indexOf` 查不到、静默返回 `false`（详见 `3a0ce399` 第 2 节的实测：`removeProxyReturns: false` / 原始对象 `true`）。即：数组响应式 + 元素原对象，两头都要满足。

## 5. ⚠️ 行为变化：换乘站现在跟着线路一刀切

| 取消「1号线」后 | 可见站点 | 右栏 1号线 |
|---|---|---|
| 改前（owners 规则：换乘站被 2/3/8 号线带亮） | 384 | 12/28 |
| 改后（直接写标志位） | 372（400 − 28，全灭） | 0/28 |

这是「直接写标志位」模型的必然结果，也正是线路侧 `toggleAllLines` 的既有行为。优点是面板计数与三维严格一致，不会出现「面板说 0、三维里还亮着 12 个」。若日后产品要求「换乘站只要还有别的线路开着就保留」，需重新引入归属映射并同步改 Toolbar，届时会重新出现「面板算一遍、三维算一遍」的不一致风险。

## 6. 实测证据（真实 Chrome，0 控制台报错）

| 操作 | 光锥 / 光圈 | 右栏 |
|---|---|---|
| 加载后（未进栏目） | 400 总 / 0 显 | — |
| 进 `/nodes` | 400 / 400 | 28/28 |
| 取消 1号线 | 400 / 372 | 0/28 |
| 恢复 1号线 | 400 / 400 | 28/28 |
| 单关「富锦路」 | 400 / 399 | 27/28 |
| 单关换乘「呼兰路」 | 400 / 398 | 26/28（压暗 2 块） |
| 全部隐藏 / 全部显示 | 0 ↔ 400 | 压暗 28 / 0 |
| 收起栏目（回 `/`） | 0 | — |
| 重新展开 | 400 | 28/28 |

状态留存：关掉「富锦路」→ 切到 `/strategy`（可见 0）→ 切回 `/nodes`（可见 399，且「富锦路」仍是关闭态 ✓）。无回归：齿轮工具箱「线路图层」全不选 → 折线 18 → 0 ✓，站点不受影响（仍 399）✓。

早前的路由验证同样通过：进入 `/nodes` 可见 400，面板几何 x 440 / y 703 / 1040×232、命中 `button.sp-station`，路由往返不重建 Cesium（沿用 `1056d83b` 的标记法）。

## 7. 维护提醒

- 新增「按名称批量开关」的能力时，一律放进对应的 `cesiumTools` 模块（线路→`setlines.js`，站点→`setpoints.js`），不要在 store 里另起一套状态推导。
- 其余三个 foot 导航按钮（REALTIME / EXP.TRIAL / STRATEGY）应复用同一个 `<RouterView>` 槽位，并保持三维组件与 `RouterView` 平级（结论见 `1056d83b`）。
- 遗留观察点：`linesEnts` 仍在 `Toolbar.vue` 本地、`stationObjs` 在 store 里，只是因为控制它们的界面分属不同组件；若要统一，需先确认面板侧不再依赖 store 导出的 `stationObjs`。
