---
id: "1f15e7d4-0d2b-4c51-84a3-23c019ed1792"
title: "POI 详情语义与展示契约：负缓存判据、ID 查询的字段边界、固定列 vs 动态列（etl/spec.md §3.3 与 §14）"
description: "D4 收尾的两块设计定稿：①按 amap_id 查详情的「查过没有」判据（detail_fetched_at 负缓存、失败不写缓存、UPDATE 而非 INSERT）；②ID 查询能给/不能给的字段边界（entrance/biz_ext/children 是增量，空间关系拿不到）；③前端展示契约（要对比→列固定，要阅读→缺就藏；DTO 键永远在、缺值 null、附 detail_fetched 布尔；三级降级；六条反例）。取数算法见 09f61d57，成本模型与配额见 2ec44b4f。"
status: "active"
created_at: "2026-10-25T03:12:34.909Z"
updated_at: "2026-10-25T03:12:34.909Z"
content_hash: "1825fe303a994457e9db6cdce0c00236b66570190c5f5767dbf02f7d5fc44367"
source_paths:
  - "etl/spec.md"
  - "gis-prep/学习计划.md"
session_ids:
  - "d8b76f61-75e7-458e-8be5-4e782d4bf3c8"
memory_body_ids:
  []
---

# POI 详情语义与展示契约（etl/spec.md §3.3、§14）

落稿位置：`etl/spec.md`（509 行；§3.3 第 82 行起，§14 第 400 行起），并挂进 `gis-prep/学习计划.md` 的 D4。
前置文档：取数算法与 200 条切分见 `09f61d57-f7d0-4419-93c2-819d24da477c`；详情成本模型、实测配额、WMS 容量见 `2ec44b4f-ce9b-4705-b5e0-8c1aea0c4cef`。本文只记这两次新增的语义与前端契约，不重复采集算法。

## 1. 补详情是 cache-aside，不是"有点就查"

- 成本单位是**首次被访问的不同 `amap_id` 个数**，不是点击次数；存 id 本身 0 请求。
- 那一行 POI 采集时已存在，补详情是 `UPDATE poi SET detail=..., detail_fetched_at=now() WHERE amap_id=...`；只有库里没有该 id（外部链接传入）才 INSERT。
- **判据必须是 `detail_fetched_at IS NULL`，不能用 `detail IS NULL`**：详情接口常返回空（`biz_ext`/`photos` 都没有），用内容判空会让"查过但为空"的点每次重查，反复扣配额。
- 负缓存：查到但为空 → `detail = '{}'::jsonb` + `detail_fetched_at = now()`，明确"查过了，确实没有"。
- 失败不写缓存：网络错误/超时不写 `detail_fetched_at`，本次降级返回，下次仍可重试。
- 并发去重：同一 `amap_id` 同时只允许一个在飞请求（单机用进程内 in-flight 集合足够）。
- 不做 hover 预取（成本从点击数变成划过数）；缓存不能只放内存/前端变量（刷新即失效）。
- 后端不要整包透传高德原始 JSON，返回固定形状 DTO。

## 2. ID 查询的字段边界（用一条真实响应校准，勿照文档写死）

相对列表搜索的**增量**：`biz_ext`（rating/cost/open_time/parking_type）、更全的 `photos`、`entrance`（入口坐标）、`alias`、`biz_type`、`children`/`parent`、`navi_poiid`、`poiweight`、部分 `groupbuys`/`discount`；`extensions=all` 会显著影响 tel/photos/biz_ext 的返回。

对本项目的实际价值只有五项：`name`/`typecode`（面板标题与图标）、`address`、**`entrance`**（比中心点更能验证 GCJ-02→WGS84 纠偏是否落在正确建筑上）、`biz_ext.open_time`（多数为空，不可当必有）、`children`/`parent`（去重线索：连锁店与商场内店铺易重复）。`rating`/`cost`/`photos` 对空间可达性无分析价值，不值得花配额。

**明确拿不到**：实时营业状态、楼层/室内定位、客流热度、评价文本；以及一切空间关系——周边 800 m 有哪些设施、到最近地铁站多远、某区有几所学校，都只能自己 `ST_DWithin`/`GROUP BY`。「高德给点，点之间的关系是本项目自己算的」正是可达性分析的立论点。

字段名以 `.env` 之外的第一条真实响应为准：先 curl 一条存 `data/raw/amap/sample_detail.json`（列表响应同样存一份对比），再敲定字段表——v3/v5 返回体不同且会变。

`--enrich` 默认关闭，须显式 `--enrich-ids ids.txt`（一行一个，≤200）并受 `--max-requests` 约束；结果必须落库，否则每次点开重复扣费。对求职项目最划算的形态是**面试前预抓 Top 20–50 落库、详情页永远只查库**：不写缓存逻辑、不处理并发、不会超时；等真要"任意 POI 看详情"再上 lazy fill——那时已知 `detail_fetched_at` 这个坑。

## 3. 展示契约：要对比→列固定，要阅读→缺就藏

| UI 类型 | 正确做法 | 理由 |
|---|---|---|
| 多行表格（列表/统计） | **列固定**（前端常量白名单 + `empty: '—'` 占位） | 对齐是表格的全部价值；高德 `tel` 空率过半，按有无显隐列会得到锯齿行、列漂移、CLS 抖动、UI 测试无法定位 |
| 单点详情面板 | **缺失字段整行不渲染** | 阅读型 UI，少一行不造成理解困难，反而更干净 |
| 真·动态列 | 仅当列集合由数据/用户决定（多源 schema 不同、指标可配置、透视） | 即便此时也要"扫全量取并集 + 人工白名单固化"，不能每行自决 |

本项目只有 amap/osm 两源、字段集合固定，**不需要动态列**：表格固定 5 列（名称/地址/类别/所属区/电话），详情面板固定骨架 + 可选区块（照片/评分/营业时间有才渲染）。

核心分工一句话：**数据库按需稀疏（raw/detail 存 JSON），接口返回固定形状（键永远在、缺值 `null`），UI 按固定骨架渲染、缺值降级。**

三级降级：①单元格级 `—`/`暂无`；②区块级整块不渲染（照片墙、评分、营业时间）；③行级——无坐标的 POI 在数据层就过滤，不让它进库。

DTO 里带 **`detail_fetched: boolean`**：`false` = 还没查过，可显示「查看详情」按钮；`true` + `biz_ext: null` = 查过了确实没有，什么都不显示。缺这个布尔值，前端只能猜"是没查还是查了没结果"，而两种情况的交互完全不同。

反例清单（明确不做）：`v-if` 控制表格列显隐、把 raw/detail 平铺成 20+ 列、整包透传原始 JSON、hover 预取、用内容判空决定是否补抓、缓存只放前端变量。

## 4. 落地路线（时间账）

今天是 D4（10/25），D5（10/26）起 Spring Boot。建议 D4 只做到「OSM 跑通入库 + 高德中心城区 4 区补量」：OSM 0 配额约半小时能出图，可先把 §4 DDL 与 §7 幂等验证一遍；高德补量不阻塞任何后续环节——GeoServer 发布、Java 查询、前端叠加都只认那张 `poi` 表，不管数据从哪来。

仍待用户确认的三项（不阻塞今日）：①范围 13 区 / 中心城区 4 区；②字段是否删减（现 14 列含 raw/detail/detail_fetched_at）；③`transform.py` 自写还是代写（建议自写，偏移随位置变化、必须迭代、不能常数平移，是 D11 测试验证与面试"你怎么保证坐标系没错"的现成素材）。
