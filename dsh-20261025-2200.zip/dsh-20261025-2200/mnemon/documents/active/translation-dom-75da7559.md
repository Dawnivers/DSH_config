---
id: "75da7559-5010-47fe-b292-58bd88afa63f"
title: "Translation 大屏鼠标皮肤「卡、不跟手」归因：三维场景帧率瓶颈与 DOM 直写优化"
description: "用户报「自定义鼠标很卡」的排查与优化交接：跟随精度 0px 证明逻辑无误，真 GPU 对照实验把帧预算拆成皮肤（≈0 开销）与三维场景（6.6 vs 124.8 FPS）两笔账，给出降分辨率无效→主线程受限、tileset 与底图瓦片各占一半帧预算的证据、foot.vue 的响应式改 DOM 直写改动，以及待用户选择的三条优化路线 A/B/C。"
status: "active"
created_at: "2026-10-07T13:26:22.351Z"
updated_at: "2026-10-07T13:26:22.351Z"
content_hash: "2923568d6470495b8b8e7f195ba3591b07f9008415157f928b907db9115b72d4"
source_paths:
  - "Translation/src/components/screenUI/foot.vue"
session_ids:
  - "50c14007-ec53-4cf2-be56-742005cb8053"
memory_body_ids:
  []
---

# Translation 大屏鼠标皮肤「卡、不跟手」归因与优化

日期：2026-10-07。源文件：`Translation/src/components/screenUI/foot.vue`（约 2300 行，含底栏 HUD、18 条线路列表、导轨 SVG、罗盘等）。

相关文档：`715e6684-4186-4c51-82f8-1db889099650`（HUD 鼠标皮肤的设计与交互规则、两个 Vue 过渡坑、实测证据——本文只记性能部分，不重复）、`46077717-b034-4315-a3c1-f04be09fed52`（Cesium 场景 KeepAlive 改造，三维减负的上下文）。

## 1. 结论先行

用户提问：「鼠标怎么那么卡，不跟手，是每帧都要显示实时经纬度的原因吗？」

答案：**不是经纬度，也不再是皮肤的锅；是三维场景把整页压到约 6.5 FPS**，DOM 皮肤最快只能按这个节奏更新（≈100ms 一次），手感就是"黏"。

## 2. 已落地的优化（foot.vue）

| 改动 | 原因 |
|---|---|
| 坐标 / 经纬度**退出响应式**，改为 rAF 里直接写 DOM | 原先每次 `mousemove` 都写 Vue 响应式 state → **整个 foot.vue 每帧全量重渲染**（1000+ 行组件的最大开销） |
| 用 ref 句柄直写：`cursorRef`（`transform`）、`cursorXyRef` / `cursorGeoRef`（`textContent`） | 绕开 Vue 渲染管线，零重渲染 |
| 经纬度换算降到 **10Hz**（屏幕坐标仍每帧） | 读数不需要每帧精度 |
| `getBoundingClientRect()` 结果**缓存** | 每帧调用会强制同步布局 |
| 去掉每帧 `drop-shadow` 滤镜重绘 | 每帧滤镜重绘 |
| （此前已有）监听只在开启时挂载、`passive: true`、指针移出窗口先隐身 | 不给隐藏状态留开销 |

验证：编译产物 HTTP 200（232581 bytes）；脚本确认 `cursorX/cursorY/cursorInside/cursorGeo` 四个响应式绑定已移除，`cursorRef/cursorXyRef/cursorGeoRef/flushCursor` 直写句柄存在。

跟随精度实测：指针 (1372, 420) → 皮肤 `transform` (1372, 420)，**偏差 0px**（慢的是刷新节奏，不是定位逻辑）。

## 3. 证据：帧率拆账（真 GPU 对照实验）

环境：AMD Radeon 集显（ANGLE / Direct3D11）、1600×900、DPR 1、canvas 1600×900。

| 实验 | 帧率 | 结论 |
|---|---|---|
| 皮肤开 + 三维在 | **6.6 FPS** | 现状基线 |
| 皮肤关 + 三维在 | **6.2 FPS** | **皮肤开销 ≈ 0**（噪声内），优化到位 |
| 皮肤开 + 三维隐藏 | **124.8 FPS** | HUD + 皮肤本身能跑 ~125 FPS |
| `resolutionScale = 0.75` / `0.5` | 8.3 / 11 FPS | 降分辨率几乎没用 → **不是填充率/GPU 问题，是主线程受限** |
| `targetFrameRate = 30` | 7 FPS | targetFrameRate 不解决该瓶颈 |
| 关掉 2 个 3D Tiles 模型 | **12.8 FPS** | 模型约占一半帧预算 |
| 再关掉地球影像 | **31.8 FPS** | 底图瓦片占另一半 |

场景清单：`primitives: 3`、`tilesets: 2`、`postProcessStages: 0`。

对应现象：用户 Chrome 右上角 `95.63 MS / 10 FPS` 读数是同一事实。

实验方法（脚本建在系统临时目录，非仓库内，需要时重建）：Playwright 驱动有 GPU 的 Chrome，测 `requestAnimationFrame` 间隔（p50/p95/max），并通过 `viewer.scene.globe.show`、tileset `.show`、`resolutionScale`、`targetFrameRate` 逐项开关做对照。注意本机 DSH 内置浏览器面板当时**未挂载客户端插件**（`hasController: false`、`webviewCount: 0`），所以走 Playwright 而非面板。

## 4. 用户提出但未采用的方案

用户建议：「如果是经纬度的原因，就把经纬度显示移到整个屏幕最右下角」。归因证明经纬度不是原因（且已降到 10Hz），因此**未做该改动**；它作为选项 A 的一部分仍然有效（读数与指针解耦后，右下角常驻显示更合理）。

## 5. 待用户决策

- **A. 指针换原生图片光标**（`cursor: url(准星.png) 32 32, crosshair`）：由浏览器/系统合成器绘制，**不受页面帧率影响，永远跟手**；读数移到屏幕右下角。代价：失去旋转环/脉冲动画（静态图可做精致）。
- **B. 保留现有动画皮肤**：已零额外开销，接受跟随页面帧率。
- **C. 先给三维减负**：tileset 的 `maximumScreenSpaceError` / 显存与解码、底图瓦片策略（腾讯 + ArcGIS 在线瓦片，网络与解码吃主线程）、`requestRenderMode` 按需渲染；收益是整个大屏变流畅，工作量最大。

当时给出的建议：**A + C**（A 立竿见影，C 是大屏的长期收益）。
