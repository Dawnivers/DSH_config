---
id: "33cfa818-3d9f-4a69-a685-bb2e6794a9c7"
title: "Translation 跟车视角相机输入接管：左键拖动改朝向 + 滚轮调距、锁死 screenSpaceCameraController 并在退出时快照还原（含实测灵敏度）"
description: "trainRoam.js 跟车相机交互实现交接：为何必须接管输入（每帧 lookAt 会覆盖 Cesium 默认控制器）、viewHeading/viewPitch 实例状态与 0.35/0.28 度每像素灵敏度、pitch −82°~−4° 夹取、range 22~1420m、锁禁 enableRotate/Zoom/Tilt/Look/Translate 并快照还原、实测数据与被放弃的 B 方案/trackedEntity 取舍。"
status: "active"
created_at: "2026-10-17T11:47:07.224Z"
updated_at: "2026-10-17T11:47:07.224Z"
content_hash: "95eaffb86b6e768a8fe5c500a8078a9e0497babd8d1fd5b36c0656091ef81110"
source_paths:
  - "Translation/src/cesiumTools/lineAndpoints/train/trainRoam.js"
  - "Translation/src/cesiumTools/DayorNigjt/DayorNight.js"
  - "Translation/src/components/bottom/RealtimePanel/RealtimePanel.vue"
session_ids:
  - "9a68916b-9b02-483e-9e58-96713c728319"
memory_body_ids:
  []
---

# 跟车视角的相机输入接管（/realtime）

涉及文件：`Translation/src/cesiumTools/lineAndpoints/train/trainRoam.js`。
前置背景见 `5ab2b3fa-9039-4ad5-b516-bee3d9597184`（`camera.position` 在 `lookAt` 局部系里失效）与 `72915457-a50b-4583-bad7-a771aab9d999`（为何放弃 `trackedEntity`、改用每帧 `camera.lookAt`）。

## 1. 需求与前提澄清

用户问：「为什么实时轨迹的相机移动要切换到鼠标左键而不是按照 Cesium 默认的滚轮移动」。

前提本身要纠正：**Cesium 默认映射里左键拖本来就是转向（rotate/orbit）、滚轮本来就是缩放（zoom）**，右键/中键拖是推拉与倾斜。没有把「转向」从左键改到滚轮。本实现保留这套映射，改的只是**由谁执行**。

## 2. 为什么必须自己接管

跟车时相机位姿每帧重算：

```js
camera.lookAt(trainPos, new Cesium.HeadingPitchRange(viewHeading, viewPitch, range));
```

这句有最终决定权。Cesium 自带控制器改完 `camera`，下一帧就被覆盖，用户看到的是「拖一下弹回去」。两条路：

- **A（采用）**：关掉自带控制器，自己记角度，每帧用记下的角度重摆机位。
- **B（否决）**：不关控制器，每帧从 `camera.heading / camera.pitch / camera.position` 读回来再喂 `lookAt`。看似优雅，但 `lookAt` 后相机处于以车为原点的**局部坐标系**，`camera.position` 是个小向量（昼夜被误判成夜景就是这个坑），反复读写会累积漂移，边界情况（拖到天上/地平线以下）还会和 `lookAt` 的钳制打架。

结论：**既然完全拥有相机，就必须完全拥有输入。**

滚轮同理：现在调的是 `this.range`，并 `preventDefault` 掉 Cesium 自己的缩放，否则两套缩放叠加会「抖一下再回弹」。

## 3. 实现要点

| 项 | 做法 |
|---|---|
| 状态 | 实例字段 `viewHeading / viewPitch`（切线路、点反向都保持，不重置） |
| 拖动 | `handlePointerDown/Move/Up` + `setPointerCapture`（拖出画布继续跟随，松手不会卡在「拖动中」） |
| 缩放 | `handleWheel` 改 `this.range`，`preventDefault` |
| 控制器 | 跟车时 `lockCameraControls` 把 `enableRotate / enableTranslate / enableZoom / enableTilt / enableLook` 全关；`restoreCameraControls` 按**快照**原样还原 |
| 默认机位 | 偏航 35°、俯角 −22°、距离 190m（`range`，构造时初始化） |

参数与手感：

| 想改什么 | 位置 | 当前值 |
|---|---|---|
| 横向灵敏度 | `handlePointerMove` 的 `0.35 * DEG` | 0.35°/px |
| 纵向灵敏度 | 同处 `0.28 * DEG` | 0.28°/px |
| 俯角上下限 | 构造函数 `minPitch / maxPitch` | −82° / −4° |
| 视距范围 | 构造函数 `minRange / maxRange` | 22 / 1420 m |
| 初始方向 | `viewHeading / viewPitch` | 35° / −22° |

方向语义按「抓住场景转」定：往右拖场景跟着往右走；往下拖相机抬高、俯视更陡。

## 4. 实测（2026-10-17，/realtime）

| 操作 | heading | pitch | 距离 |
|---|---|---|---|
| 初始 | 35° | −22° | 190 m |
| 右拖 200px + 下拖 80px | **325°（−70°）** | **−44.4°（−22.4°）** | 190 m（不变） |
| 再左拖 150px | **17.5°（回 +52.5°）** | −44.4° | 190 m |
| 滚轮上滚 4 格 | 17.5°（不变） | −44.4°（不变） | **121 m** |
| 离开栏目 | — | — | `enableRotate: true`、`enableZoom: true`、实体数 **418**、列车已删、零 pageerror |

最后一行是关键回归点：**不还原控制器，从实时轨迹回首页后鼠标就再也拖不动地球。**

## 5. 已知代价（接管输入必然丢掉的）

- 惯性滑动：松手立刻停，无缓动；
- 地形/建筑碰撞检测：相机可能钻进楼里或地面以下（默认控制器会挡）；
- 右键/中键推拉、`enableTilt/enableLook`：跟车模式下不可用；
- 触摸双指缩放组合语义：只剩单指拖动。

若要把它们找回来，可选项：① 在 `handlePointerMove` 留一帧速度做缓出（加惯性，约 2 行）；② 拖动/缩放时夹相机高度不低于地形 +2m；③ 重走 `trackedEntity` 路线拿回全套原生交互，但需重做跟车距离校准（`trackedEntityOffset.range` 实测不生效，见 `72915457-...`）。

## 6. 可复用经验

- 只要存在「每帧重摆相机」的跟随逻辑，就必须显式处理输入归属：要么锁控制器自己算，要么从相机状态读回——两者不能混。
- 改参考系的 API（`lookAt` / `lookAtTransform`）会让 `camera.position`、`camera.positionCartographic.height` 失去世界尺度含义，世界尺度逻辑一律用 `positionWC`。
- 锁全局开关（如 `screenSpaceCameraController` 的 enable* 标志）时，进出都用同一份快照读/写，并把「离开后标志位与实体数」写进验收清单，否则极易留下不可逆的输入失效。
