---
id: "72915457-a50b-4583-bad7-a771aab9d999"
title: "Translation /realtime 实时轨迹落地：站点↔折线顶点严格前扫匹配、每帧 lookAt 相机跟随、onTick 驱动 DOM 高亮与 playIntent 兜底（含实测值）"
description: "Translation 项目 /realtime 栏目的完整实现交接：文件划分、18 条线站点到折线顶点的匹配算法与误差、时间表生成与断言、Cesium trackedEntity/trackedEntityOffset 与 minimumPixelSize 的实测失败、camera.lookAt 90m 跟车、clock.onTick 二分推站、timeline 松手续播与 playIntent 压回、反向按钮、实体数基线 419 与验证脚本。"
status: "active"
created_at: "2026-10-17T08:38:27.123Z"
updated_at: "2026-10-17T08:38:27.123Z"
content_hash: "c7f5632601f7fb8ee603d9253f295935b5f62d8c150ae3804166b9bd45efbbb5"
source_paths:
  - "Translation/src/cesiumTools/lineAndpoints/train/trainRoam.js"
  - "Translation/src/cesiumTools/lineAndpoints/train/trainSchedule.js"
  - "Translation/src/components/bottom/RealtimePanel/RealtimePanel.vue"
  - "Translation/src/components/bottom/RealtimePanel/CarPopup.vue"
  - "Translation/src/router/index.js"
  - "Translation/src/stores/stationState.js"
  - "Translation/src/cesiumTools/lineAndpoints/popup/popup.js"
  - "Translation/src/components/bottom/Toolbar.vue"
  - "Translation/src/assets/trainAndChisa_static.glb"
session_ids:
  - "662e9531-71b9-4661-a5e9-05b9ba525d33"
memory_body_ids:
  []
---

# Translation `/realtime` 实时轨迹：从 EmptyView 到真栏目的落地记录

工作区：`D:\WebGIS\web三维开发\智慧地铁项目`（vite + Cesium 1.97 + Vue 3）。日期：2026-10-17。
`/realtime` 原先指向 `EmptyView`（只表示「无面板」），本项目把它换成真栏目。目标：一条选定线路的列车按时刻表在折线顶点上运行，左下时间轴可拖，左栏站点列表按到站状态高亮，右上角可反向。

本文是**落地交接**，只记实现与实测。理论与参考实现在
`7f1a6f08-9d0f-4d25-adfe-c436ac157c88`（RoamTool 内核剖析：时间即真值、leadTime/trailTime、clockRange、scrub 行为）与
`18fb181e-e047-4909-a1b8-fd9d1a1bd9e8`（语雀课程归档 + 落地差距对照）。本文把其中「拟移植目标」「未落地」的部分变成已实现结果，并**修正了两条此前的假设**（见 §4.1、§5）。

## 1. 文件划分（新增 4 / 改动 5）

| 文件 | 职责 | 关键约束 |
|---|---|---|
| `Translation/src/cesiumTools/lineAndpoints/train/trainSchedule.js` | 时间表：站点→顶点匹配、区间运行时间、正反向采样时刻 | **纯计算，不 import cesium**，可在 node 里直接跑断言 |
| `Translation/src/cesiumTools/lineAndpoints/train/trainRoam.js` | 漫游内核：实体、clock、相机、气泡、清理 | 唯一持有 viewer 的一层 |
| `Translation/src/components/bottom/RealtimePanel/RealtimePanel.vue` | 栏目面板（1040×232，与另两个栏目同规格） | 只吃 ref，不直接碰 viewer |
| `Translation/src/components/bottom/RealtimePanel/CarPopup.vue` | 列车气泡 | 与 `CarPopup` 同构于既有 `marker`/`queryPopup` 模板 |

改动：`popup.js:63` 加 `carPopup` 路由键；`stationState.js:44` 加第 5 个 mode 值 `'line'`；`Toolbar.vue:326` 加 `'line'` 分支（**不复用 `'all'`**，因为 `'all'` 会把活动站减掉）；`router/index.js:23` 指向新面板；`trainRoam.js` 多轮修订。

## 2. 站点 → 折线顶点：严格单调前扫

结论（实测）：**18/18 条线的 `xy_coords` 就是 `line1to18_2.json` 的折线顶点本身**，站点 `sort` 升序 == 折线顶点顺序（`historyPanel.vue:73` 那句注释是准确的）。因此不需要最近邻/投影，只需要确定性地把第 i 站绑到第 j 个顶点。

算法：**严格单调前扫**——第 2 站起从 `prev + 1` 开始向后找首个距离最小者，防止「两站抢同一顶点」或「索引回退」。

误差：17 条线偏差 0m；**14 号线 122m、16 号线 95m**（这两条的数据源本身不一致，站点坐标与折线顶点有偏移）。

时间表：把顶点间距按区间运行时间分配成采样时刻。离线断言（node，18 条线全跑）：

- 采样时刻严格递增 ✅
- 正反向总时长相等 ✅
- 区间运行时间镜像（正向第 k 段 == 反向第 k 段）✅
- 唯一例外：**14 号线反向镜像差 7.3s**，因为那个离折线 122m 的站从两端匹配到了相邻顶点。误差 0.3%，视觉不可辨。

## 3. 相机跟随

### 3.1 每帧 `camera.lookAt`（最终方案）

```js
viewer.camera.lookAt(pos, new Cesium.HeadingPitchRange(
  Cesium.Math.toRadians(35),   // heading
  Cesium.Math.toRadians(-22),  // pitch
  90.0                          // range，米
));
```

实测：相机与车距离 **90m 整**，相机高度 33.7m（≈ 90·sin22°）。每帧在 `onTick` 里调用，先 `lookAtTransform(Matrix4.IDENTITY)` 解除上一帧的锁定段再重设。

### 3.2 `trackedEntity` + `trackedEntityOffset` 实测不生效（修正假设）

按 5174 参考项目的做法试过 `viewer.trackedEntity = trainEntity` + `trackedEntityOffset.range = 90`：

- 相机仍**贴在车身上**，实测距车仅 **3m**；
- 且它依赖 `viewer._dataSourceDisplay.getBoundingSphere()`（`Viewer.js` 的 `updateTrackedEntity`）：`BoundingSphereState.PENDING` 时直接 return，**23MB 模型加载完成前相机完全不动**；
- 源码定位：`Viewer.js` 命中行 849 / 1428 / 1448 / 2352 / 2405，`updateTrackedEntity` 在 2352 附近，靠 `_needTrackedEntityUpdate` 标志位在包围球就绪后一次性建 `EntityView`。

结论：本项目不使用 `trackedEntity`，改用每帧 `lookAt`。

### 3.3 `minimumPixelSize` / `maximumScale` 是陷阱

`model.minimumPixelSize` + `maximumScale` 这对参数会在模型包围球就绪前算出极端缩放：实测把一辆 30m 的车放大到**几十公里**，镜头「钻进车厢」（第一张截图就是这个现象）；反向也会变成完全看不见。**相机固定跟随时两者都不要设，只留 `scale`。**

模型标定：`src/assets/trainAndChisa_static.glb`（23.56MB）**节点自带 0.01 缩放**，所以 Entity `scale: 1` 就是真实尺寸。90m 视距下车长约 30m、屏宽约 600px、包围球半径 19m。

glb 结构参考：9 个 mesh、节点 `Object_6_BAKED`…`Object_12_BAKED` 均 `scale=0.01`，`Sketchfab_model → Root → Plane.016 → Plane.016_1/_2`。若某次误按文件原始单位换算，会得到「scale 应为 1.58e-1」这种错误结论——**必须以节点自带 scale 为准**。

## 4. 到站高亮：由 `currentTime` 二分推出，不存索引

`viewer.clock.onTick`（每帧，**无条件**触发）里拿 `clock.currentTime` 在 `stationTimes` 上二分，得到 `{ index, inStation, progress }`：

- `index` 变了才写 ref —— 一帧最多一次 Vue patch，37 个节点 diff；
- `inStation` 变了才写 —— 决定当前站是否挂「到站」徽标 + 呼吸动画；
- 进度条**不走 ref**，直接 `barRef.style.width = ...` —— 避免每帧 patch（沿用项目里 DOM 直写习惯，见 `898c7711-8359-4297-8e5c-4fd4ef2b9a07`）。

选 `onTick` 而非 `postRender` 的依据：`Clock.tick` 里 `onTick.raiseEvent` 是**无条件**的，暂停时照样每帧触发。所以拖时间轴（此时 `shouldAnimate` 已被置 false）高亮仍然跟手。**这条否掉了「shouldAnimate=false 时 onTick 不再触发」的旧说法。**

### 4.1 时钟参数

- `clock.clockRange = ClockRange.LOOP_STOP`：车不会在终点消失（`UNBOUNDED` 下 `availability` 到期会让实体隐藏）。
- `clock.multiplier = total / 42`：整条线约 **42 秒**跑完（真实 1 号线要 38 分钟）。

## 5. 时间轴拖动：项目版 timeline 松手会强制续播

实测 `Translation/src/cesiumTools/Time/timeline.js`：

| 场景 | 实测 `shouldAnimate` |
|---|---|
| 拖动中 | `false`（Cesium 行为） |
| 松手 +0.4s | **`true`，车继续走**（`timeline.js:800` 的 mouseup 回调） |
| 主动暂停 | `false` |
| 暂停后又拖一下 | **`false`，保持暂停** ← 新加的 `playIntent` 每帧压回 |

`playIntent` 是唯一新增逻辑：每帧把用户意图（播放/暂停）压回 `shouldAnimate`。不加这个兜底，用户点了暂停、随手拖一下时间轴，松手就会被强制播起来。

拖拽整段实测（拖到 50% 位置，四个量同时正确）：

```
拖动中    → 第15站 新闸路    进度 50.5%   相机仍 90m   实体 419
松手+0.4s → 第15站 新闸路    进度 51.5%   shouldAnimate=true
松手+2.4s → 第16站 人民广场  进度 56.3%
暂停      → 第17站 一大会址·黄陂南路  进度 57.1%  shouldAnimate=false
暂停后拖  → 第18站 陕西南路  进度 62.7%  shouldAnimate=false（playIntent 生效）
```

## 6. 反向按钮 ⇄

位置：站点栏目右上角，与暂停、重播同一组。反向态整体转 180°（`transform: matrix(-1,0,0,-1,0,0)`）。

- 列表文本整体倒序：1 号线 `1 富锦路 → 28 莘庄` ⇄ `1 莘庄 → 28 富锦路`；
- 立刻从新起点发车（实测反向从「外环路」起算）；
- 相机不换位：`destroy({ keepCamera: true })`，不闪帧；
- **`station.sort` 一个字节都没动**——显示编号用列表下标算，`sort` 只负责「几何上谁在前」。

## 7. 清理与实体数基线

- 基线实体数 **418**；进入 `/realtime` 后 **419**（+1 列车，含气泡/标记总账不动）；离开或 `destroy` 后回到 418，无泄漏。验证方式见 `898c7711-8359-4297-8e5c-4fd4ef2b9a07` 的实体数基线纪律。
- `destroy()` 顺序：解除相机锁定（`lookAtTransform(Matrix4.IDENTITY)`）→ 移除 `onTick` 监听 → 停 clock → 移除实体 + 气泡。`keepCamera` 只跳过第一步。

## 8. 验证方法（可复用）

Playwright headless + `__cesiumViewer`（`cesiumView.vue:39`，仅 DEV 挂载）读取运行时状态：

```js
// 面板状态、线路、站点、进度
{ panel, lines, focusLine, stations, firstStation, lastStation, active, done, badge, bar, tag }
// 场景状态
{ entityCount, train:{lng,lat,h}, cam:{lng,lat,h}, camToTrain, modelScale, radius, simTime, multiplier, clockRange, shouldAnimate, tracked }
```

- 页面在 `localhost:5173`（`Translation`），`6392`/`8092` 为数据服务；探活用 `5173 HTTP 200` + `8092 HTTP 200`。
- 截图存 `.review/realtime-*.png`（enter / scale / follow / final / late / fixed）。
- 先验证「有没有暴露 viewer」再写探针：`grep __cesiumViewer` → `sceneManager.js:206`（文档注释）、`cesiumView.vue:39`（DEV 赋值）。

## 9. 环境噪音（不是本次功能的 bug）

headless Chrome 里腾讯地图瓦片全 **400**（`rt0-2.map.gtimg.com/tile?...&styleid=4`），`localhost:666` 的城市白模 tileset 大量 `requestfailed`（`model/shangHaiBuilds_new_toPlane/*.glb|json`）。截图背景因而是空的/青品红天空。本机 Chrome 有底图。

副作用：列车贴地跑时会被那几块巨大的白模板子挡住。若实际观感不好，可整体抬高 8~15m 或加底部光圈——属单点调参，不影响结构。

## 10. 待调项（均为单点参数，不涉结构）

- 车大小（`scale`）、跟车视角（heading 35° / pitch −22° / range 90m）、站点栏在 11 号线（37 站，最长）下的四列布局是否撑住。
- 14 号线、16 号线的站点数据源偏移（122m / 95m）若要消掉，需修数据而非改代码。

## 11. 相关文档

- `7f1a6f08-9d0f-4d25-adfe-c436ac157c88` —— RoamTool 内核剖析（时间即真值纪律、`destroy` 顺序、scrub 行为）
- `18fb181e-e047-4909-a1b8-fd9d1a1bd9e8` —— 语雀课程归档与落地前差距对照（本文是其落地结果）
- `7ef18a4e-8175-45fa-a008-a62bf4b59cb4` —— `trainAndChisa_static.glb` 的来源与 376 关节蒙皮/烘焙流程（模型单位与静态度量背景）
- `898c7711-8359-4297-8e5c-4fd4ef2b9a07` —— `cesiumTools` 工具封装惯例、清理接口、实体数基线
