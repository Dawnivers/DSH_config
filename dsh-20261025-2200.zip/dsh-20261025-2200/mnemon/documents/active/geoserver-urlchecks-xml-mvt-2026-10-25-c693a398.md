---
id: "c693a398-0925-4054-925c-3e7113eb3131"
title: "GeoServer 图标样式：换服务器迁移清单（urlchecks.xml）与 MVT 演进的三条前置条件（2026-10-25）"
description: "接续 URL Checks 根因那篇：记录「新装 GeoServer 是否仍需放行 URL」的答案与可脚本化迁移清单（www/icons + *.sld + security/urlchecks.xml + /rest/reload + 字节数验收）；路 A(ExternalGraphic) 与路 B(Mark 徽章) 的取舍；以及在 2.28.5 上上 MVT 必须先满足的三条（vectortiles 插件同版本、filter-only 样式、符号化搬到前端）与分阶段采用建议。"
status: "active"
created_at: "2026-10-25T06:28:00.853Z"
updated_at: "2026-10-25T06:28:00.853Z"
content_hash: "de358d664246ae15251cecd059bb9a1523717802d440deeac84b49ce223ffea0"
source_paths:
  - "styles/poi_icons.sld"
  - "styles/poi_badge.sld"
  - "styles/poi_by_category.sld"
  - "docs/geoserver-notes.md"
session_ids:
  - "bbcf136a-5752-4a28-8ecc-ce4877ffd061"
memory_body_ids:
  []
---

# 图标样式上生产：迁移什么、选哪条路、MVT 之前必须先做什么

前置：URL Checks 默认全拒的根因与取证 `ba3a2263-3b2e-4fea-b1c5-f202fe57a8c5`；样式文件即配置的存放/命名规则与 ExternalGraphic 失效实证 `69d45ed3-6355-4e25-8855-993c74bb1706`；REST 脚本化与生产部署要点 `be91eaef-f93d-4d77-803d-b34651d1dfd1`。

本文回答三个「换机器/上生产」才会暴露的问题：**新装的 GeoServer 还要不要配那条放行规则、该选图片还是矢量、想上 MVT 之前缺什么**。

## 1. 新服务器同样要放行——规则落在 `security/urlchecks.xml`

URL Checks 是 GeoServer 自带的安全模块，**新装默认「总开关开启 + 规则列表为空 = 拒绝一切外部 URL」**。与机器、操作系统、安装方式无关；不用 ExternalGraphic 就无事，一旦样式中出现 `ExternalGraphic` 就会重演灰方块，且日志不报错。

规则不藏在数据库里，就是一个 9 行文件 `data_dir/security/urlchecks.xml`：

```xml
<checks>
  <regex>
    <name>local-icons</name>
    <description>本机图标目录（GeoServer www）</description>
    <enabled>true</enabled>
    <regex>http://localhost:8080/geoserver/www/.*</regex>
  </regex>
  <enabled>true</enabled>
</checks>
```

外层 `<enabled>true</enabled>` 是「URL Checks 总开关」，内层是这条规则自身的开关。**直接放文件而不是 GUI 手点**，才能进部署脚本、可复现，改完重启生效。

### 关键认知：抓图的是 GeoServer 自己，不是浏览器

```
浏览器 ──GetMap──> GeoServer ──HTTP──> http://localhost:8080/geoserver/www/icons/school.png
                        ↑ 由服务端进程自己 fetch
```

因此 SLD 里的 `localhost:8080` 放到公网服务器上**照样成立**（本机环回），与域名、HTTPS、备案无关。只有三种情况需要改 URL：改了端口、改了 context path（不再是 `/geoserver`）。在 Docker 里 `localhost` 指容器自身——容器内监听 8080 时仍然可用 ✅。

### 新机部署顺序（照抄即可）

1. 建 PostGIS store → 发布 `admin_area`、`poi`
2. 拷 `data_dir/www/icons/`（4 个 svg + png）
3. 拷 `data_dir/workspaces/wuhan/styles/*.sld`（`poi_icons` / `poi_badge` / `poi_by_category`）
4. 拷 `data_dir/security/urlchecks.xml`（或 GUI 里加同一条规则）
5. `POST /rest/reload`
6. `GetMap ... &styles=wuhan:poi_icons` 验一张图，**看字节数**：几十 KB = 成功；几 KB = 又是灰方块
7. 灰方块 → 先去 URL Checks 页用 Test URL 试，九成是规则没生效

### 两条生产纪律

- **规则写窄**：`http://localhost:8080/geoserver/www/.*` 可以；`.*` / `http://.*` 等于关掉 SSRF 防护，公网机器上被注入的样式可以借此探测内网。该设置**全局生效**，影响所有工作空间与样式。
- **`data_dir/www/` 是公开可读目录**：任何人访问 `/geoserver/www/xxx` 都能拿到。图标可以放，导出的数据文件（如 `poi.sql`）绝对不行。

## 2. 路 A（图片）vs 路 B（矢量图元）：本质是"贴图片"还是"画图形"

| | 路 A `poi_icons` | 路 B `poi_badge` |
|---|---|---|
| 符号来源 | `ExternalGraphic` + `OnlineResource href` 外部图片 | `<Mark><WellKnownName>circle</WellKnownName>` 几何图元 |
| 是否需要 URL 放行 / 图标文件 | 都要 | 都不要 |
| 换机器 | 搬文件 + 配规则 | 只搬 SLD |
| 失败模式 | **静默变灰方块**（无异常、无日志） | 不会失败；SLD 有错上传即被拒 |
| 改图标 | 换文件 + `?v=N` 绕失败缓存 | PUT 新 SLD 立刻生效 |
| 表达力 | 任意插画/品牌图标 | 仅内置图元（circle/square/triangle/cross/star…） |

取舍结论：**A 主用，B 兜底**。演示/截图挂 A；一旦"图突然全灰"，30 秒切 B 应急，不必当场排查；进容器/换机器时先挂 B 保证能看，再配 A。公网长期演示若不想承担配置风险，直接用 B（零外部依赖）。

## 3. 想上 MVT：三条前置条件（否则会白排查）

一个常见误判是「上了 MVT 就完全不用管服务端样式和 URL 放行」。方向对，但有三处必须补：

**① GeoServer 上仍要有一个样式，但它只当"过滤器"用。**
输出矢量瓦片时，GeoServer 会用图层默认样式判断**哪些要素在这个缩放级别出现**（`Min/MaxScaleDenominator` 与 Rule filter 生效），**但忽略一切符号化参数**（颜色/大小/图标）。后果很具体：若把 `poi_icons`（带 `MaxScaleDenominator=50000`）设为默认样式，低缩放级别的 MVT 会**一个点都不返回**，前端拿到空瓦片还以为自己写错了。正确做法：为 MVT 单做一个 **filter-only 样式**——只有 Rule + Filter + 缩放范围，不含任何 Symbolizer。

**② 需要 `vectortiles` 插件，且版本必须与 GeoServer 严格一致（本机 2.28.5）。**
从 `.../GeoServer/2.28.5/extensions/geoserver-2.28.5-vectortiles-plugin.zip` 取，解压后将 jar 放进 `webapps/geoserver/WEB-INF/lib/` 再重启。装错版本会导致重启失败，是 GeoServer 插件最常见的坑。

**③「不用放行」只针对前端图标。**
若 MVT 用的 filter-only 样式里还残留 `ExternalGraphic`，服务端解析该样式时仍有被 URL Checks 拦的可能。保险做法：该样式里不出现任何 `ExternalGraphic`。

### 三种出图方式的真实取舍

| | WMS `ImageWMS` | `TileWMS` + GWC | MVT |
|---|---|---|---|
| 服务端传 | 一张已画好的 PNG | 一张张 PNG 瓦片 | 二进制矢量（几何+属性） |
| 样式在哪 | SLD（服务端） | SLD | **前端 JS** |
| hover/选中/动画 | ❌ | ❌ | ✅ |
| 服务端 CPU | 高（每次重绘） | 低（缓存后≈0） | 极低（查库+编码） |
| 前端 CPU | 低 | 低 | **高**（16k 点由浏览器画） |
| 需插件 | 否 | 否（GWC 内置） | **是** |
| 数据量敏感度 | 不敏感 | 不敏感 | **很敏感** |

MVT 的代价要一起记：16,016 个点若低缩放也全返回，单瓦片可塞数百点、几十片就是前端解析数万要素——必须靠服务端缩放裁剪、前端 `minZoom/maxZoom`、或聚合（`PointStacker` / 前端聚类）来兜。样式从 XML 变成 JS `Style` 函数（能写逻辑，但要自己管缓存与性能）；调试链路从"图不对=SLD 不对"变成"瓦片没数据？style 写错？CORS？"三段排查。

### 分阶段采用建议

| 阶段 | 用什么 | 理由 |
|---|---|---|
| 现在 | `ImageWMS` + `poi_icons` | 30 秒出图，验证数据正确 |
| D12 点击查询/图层开关 | 仍是 WMS + `GetFeatureInfo` | 弹窗取属性不需要 MVT |
| D13–D18 格网/热力图 | `TileWMS` + GWC | 出图量大，缓存优先 |
| D19+ 打磨 | 可选 MVT | 想展示前端符号化能力时再上 |

**一句话**：MVT 之后 GeoServer 只管"数据在哪"、前端管"长什么样"；换来的是前端自由度，付出的是前端性能责任与插件/样式配置成本。它不是必须的升级，是另一种取舍。
