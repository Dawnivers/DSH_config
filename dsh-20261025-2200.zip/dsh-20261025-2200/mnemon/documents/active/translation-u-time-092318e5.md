---
id: "092318e5-5772-4f96-bc7d-3b1b4abfee81"
title: "Translation 智慧地铁：特效动画「按帧驱动」的帧率耦合坑与 u_time 修法（白模扫描光带 / 流光 / 水面）"
description: "2026-10-07 修复：三个 Cesium 着色器把 czm_frameNumber（帧序号）当时间用，换到 RTX 4070 后白模扫描光带快约 9 倍。含根因、5 个改动文件、u_time 的三种 uniforms 接入方式、可调周期 u_sweepPeriod/u_stripePeriod 与实测验证方法。"
status: "active"
created_at: "2026-10-07T14:23:24.167Z"
updated_at: "2026-10-07T14:23:24.167Z"
content_hash: "9539896e3f2fe2a7cba5c90293b5dbd4d935d91337c51c1228d02253990f2a78"
source_paths:
  - "Translation/src/cesiumTools/DayorNigjt/shaders/shpShader.glsl"
  - "Translation/src/cesiumTools/DayorNigjt/shaders/flowShader.glsl"
  - "Translation/src/cesiumTools/DayorNigjt/shaders/waterShader.glsl"
  - "Translation/src/cesiumTools/DayorNigjt/ModelShaders.js"
  - "Translation/src/cesiumTools/DayorNigjt/DayorNight.js"
session_ids:
  - "7fd1c6d8-cd36-422b-8980-d6a92267c4e4"
memory_body_ids:
  []
---

# Translation 智慧地铁：特效动画「按帧驱动」的帧率耦合坑与 u_time 修法

日期：2026-10-07（晚） · 项目根 `D:\WebGIS\web三维开发\智慧地铁项目`，前端目录 `Translation/` · 状态：已改完并经运行时实测验证。

相关文档：
- `91f97ed8-2a88-4141-8fbf-2c6cb97cecfa` —— 前一环：同样的页面在集显 / RTX 4070 上的 6.3 → 56.8 FPS 实测。**本次问题正是那次「换显卡」暴露出来的**：帧率一变，动画速度跟着变，才把「按帧驱动」这个隐藏缺陷照出来。
- `979eb2d7-7e66-4046-944a-52cd4f5c884c` —— 同期前端 UI 侧改造（鼠标皮肤 / 全屏沉浸），与本文无实现耦合。

## 症状与触发条件

用户反馈：**启用独显后，白模特效的扫描光带速度变得好快**。

这不是「特效坏了」，而是同一个特效在两种帧率下呈现两种速度：

| 运行方式 | 帧率 | 扫描光带一趟耗时 |
|---|---|---|
| 默认（AMD 集显） | 6.3 FPS | ≈ 40 秒（慢到几乎看不出在动） |
| 强制高性能（RTX 4070） | 56.8 FPS | ≈ 4.2 秒（快得突兀） |

也就是说，之前长期看到的「缓慢扫光」其实是帧率伪影；节点上的 4 秒才是原作者按 60 FPS 折算的设定值。用户仍嫌快，因此顺手整体放慢。

## 根因

`czm_frameNumber` 是**帧计数器**，不是时钟。三个着色器都把它当秒表用，等价于把动画速度绑死在帧率上：

```glsl
// shpShader.glsl（白模特效）—— 修复前
float iTime   = czm_frameNumber / 120.;                  // 条纹滚动
float sweepT  = 1.0 - fract(czm_frameNumber / 240.0);    // 扫描光带（用户抱怨的那条）
// getColorStripe() 里还有一处 iTime = czm_frameNumber / 120.

// flowShader.glsl（外滩流光）—— 修复前
float t = czm_frameNumber / 60.0;

// waterShader.glsl（水面）—— 修复前
float time = czm_frameNumber * animationSpeed;           // 波纹
float time = czm_frameNumber * animationSpeed * 0.1 + 23.0;  // 夜间分形水花
```

帧率从 6 → 57，这些量就同步快约 9 倍。**结论：同类问题不止白模一处**——只修白模的话，流光和水面波纹在高帧率下同样会快 9 倍，属于同一批必须一起修的缺陷。

## 改法：新增秒级 `u_time` uniform，由 JS 每帧写入

统一的接线点是 `DayorNight.js` 里**already 存在的** `viewer.scene.postRender` 钩子（原本用于同步昼夜 `u_isDark`），新增 `syncShaderTime()`：基于 `performance.now()` 计算秒数并写入所有材质。

```js
// DayorNight.js 关键约定
// syncShaderTime() 必须写在「昼夜角度未变化就 return」的早退之前，
// 否则相机不动时 u_time 会停止推进，动画在静止视角下直接冻住。
```

三套材质各自的 uniforms 接入方式不同，值得记住：

| 载体 | 声明处 | 写入方式 |
|---|---|---|
| CustomShader（白模 shpShader、外滩 flowShader） | `ModelShaders.js` 的 `uniforms` 对象 | `tileset.customShader.uniforms.u_time.value = seconds` |
| Cesium.Material（水面 waterShader） | fabric 的 `uniforms` 里声明 `u_time: 0` | `waterPrimitive.appearance.material.uniforms.u_time = seconds` |

注意：`Material` 会把 `uniform xxx;` 声明自动前置到 fabric `source` 最前面，所以 **source 里不用（也不能在首行）再写预处理指令**；而 CustomShader 的 GLSL 则需正常声明 `uniform float u_time;`。

## 速度旋钮（用户可自行调）

在 `ModelShaders.js` 的白模材质里，速度就是两个常量：

```js
u_sweepPeriod:  { value: 12.0 },  // 扫描光带走完一趟的秒数（原按 60FPS 折算约 4 秒 → 慢 3 倍）
u_stripePeriod: { value: 6.0 },   // 条纹滚动一个周期的秒数（原约 2 秒 → 慢 3 倍）
```

嫌快调大、嫌慢调小（20 = 20 秒一趟）。流光与水面**刻意保留原作者节奏**（未额外放慢），因为用户只抱怨了白模扫描光带——要调再单独说。

## 改动的文件（5 个）

| 文件 | 改动 |
|---|---|
| `Translation/src/cesiumTools/DayorNigjt/shaders/shpShader.glsl` | 扫描光带 `sweepT`、条纹 `iTime` → `u_time / u_sweepPeriod`、`u_time / u_stripePeriod` |
| `Translation/src/cesiumTools/DayorNigjt/shaders/flowShader.glsl` | `czm_frameNumber / 60.0` → `u_time` |
| `Translation/src/cesiumTools/DayorNigjt/shaders/waterShader.glsl` | 两处（波纹 + 夜间分形水花）→ `u_time` |
| `Translation/src/cesiumTools/DayorNigjt/ModelShaders.js` | 三套材质新增 `u_time`；白模另加 `u_sweepPeriod` / `u_stripePeriod` |
| `Translation/src/cesiumTools/DayorNigjt/DayorNight.js` | `postRender` 钩子内新增 `syncShaderTime()`，用 `performance.now()` 写秒 |

## 验证方式（可复用）

用 CDP 连页面读取 uniforms 快照 + 前后截图比对：

1. **时间按秒推进**：间隔 3 秒两次读 uniforms → `u_time` 从 13.956 → 16.984（+3.03）✅，水面材质同样 +3.03 ✅。
2. **参数真的接进去了**：`u_sweepPeriod = 12`、`u_stripePeriod = 6` 可见且生效 ✅（第二个 tileset 无这两个 uniform 属预期，它没用到白模条纹）。
3. **无着色器编译错误**：5 个源文件均 HTTP 200 且页面日志无 shader 编译报错 ✅。日志里另有若干底图瓦片 400 拉取失败，属 tile 请求问题，与着色器无关。
4. **画面没冻住/没花屏**：相隔 2.5 秒两张截图采样 20000 点，变化 4521 点 → 变化率 22.6%（接近 0% 才说明特效停了）✅。
5. **残留检查**：全仓 grep `czm_frameNumber`，此刻只剩注释里对旧写法的说明，无实际使用 ✅。

## 可复用的教训

- **Cesium 里做动画一律用时间 uniform（秒），绝不用 `czm_frameNumber`。** 帧序号驱动会把速度绑死在帧率上，一旦换显卡 / 场景复杂度变化 / 窗口变小 / 开 `requestRenderMode`，同一份代码的速度就变。
- 「特效速度莫名其妙变了」优先怀疑帧率耦合，而不是怀疑参数被人动过；对照两种帧率下的耗时能直接自证。
- 逐帧驱动一个全局时间 uniform 时，注意早退分支：写在 `if (angle === _angle) return false;` 之后，视角静止时动画就会冻住。
- 修「按帧当时间」要**全仓扫一遍同类写法**再动手——本次三处着色器是同一根因，只修被抱怨的那处等于埋雷。
