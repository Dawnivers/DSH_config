---
id: "bf38b495-eb86-4f47-a9bb-2c658bf53ada"
title: "ppt-master skill v6.7.2 在 DSH Desktop 的安装实录：Release 下载卡点、D 盘 venv 隔离与路径硬规则"
description: "2026-10-21 在 DSH Desktop 安装 ppt-master v6.7.2 的完整实录：扁平安装路径与体量、D 盘 venv 隔离与「必须用 venv python」硬规则、GitHub Release CDN 下载卡点及 302+HttpWebRequest 绕过、代理 7897 未监听、robocopy 与 attribution_guard 验收、skills-manager 发现接口签名坑、使用注意事项与升级注意。"
status: "active"
created_at: "2026-10-21T07:11:45.511Z"
updated_at: "2026-10-21T07:11:45.511Z"
content_hash: "cede61f55a1b7fd2c1be898b0b2377b76fa7ad900f68acc6b01c0fa9f6e95f56"
source_paths:
  []
session_ids:
  - "0f58c525-5779-45cb-863a-c2e2ea6326fc"
memory_body_ids:
  []
---

# ppt-master skill v6.7.2 在 DSH Desktop 的安装实录

日期：2026-10-21 · 环境：Windows 宿主，DSH Desktop（`desktop` profile），Python 3.10.10。

安装后实测结论：技能已被 DSH 原生 loader 与 skills-manager **双发现**（技能总数 29），条目类型为 `bundle`。目录发现规则与「必须拍平、整目录拷贝」的源码依据见 `f4e8bed3-21f4-4947-915a-10d14a3dbdcf`，同类第三方技能落地经验见 `1b93b07b-9e69-49ca-a289-336e4dcc1ded`（mattpocock/skills）。

## 1. 最终落位

| 项 | 路径 | 说明 |
|---|---|---|
| 技能本体 | `C:\Users\林先语\.dsh\skills\ppt-master` | **扁平**安装，不建分类子目录；37.2 MB / 13018 文件，含 81 个 `scripts/*.py` |
| Python 环境 | `D:\venvs\pptmaster` | 由 `D:\python\python.exe` 创建，依赖全部落在 D 盘 |
| pip 缓存 | `D:\pip-cache` | 345.8 MB（C 盘另有一个 15.3 MB 旧缓存，非本次产生，未动） |
| 原件 / ZIP / 更新源 | `D:\tools\ppt-master` | ZIP 21.52 MB，SHA256 `B93C5EF3A52AE1F0D1412AA9B85AAE6706B769ED3E8CF5B1682DEC1CBBF2860F` |
| 适配说明 | `C:\Users\林先语\.dsh\skills\ppt-master\DSH-ENV.md` | 自写的环境约定，升级时会被覆盖，需重写 |
| 上游 | https://github.com/hugohe3/ppt-master | MIT，`metadata.version: 6.7.2` |

## 2. 关键硬规则：脚本必须用 venv 的 python 执行

SKILL.md 正文写的是 `python3 xxx.py`，在本机有两个坑：

- Windows 上没有 `python3` 命令；
- PATH 上的 `python` 是 `D:\python\python.exe`（基础环境），**没有** `pptx` / `PyYAML` / `skia-pathops` / `uharfbuzz` / `PyMuPDF` / `XlsxWriter`，照抄即 `ModuleNotFoundError`。

→ 一律用 **`D:\venvs\pptmaster\Scripts\python.exe`**（`Activate.ps1` 也在 `Scripts\` 下）。核验方式：import 六个关键包并打印 `__file__`，确认都在 `D:\venvs\pptmaster\lib\site-packages`。

注意 `import fitz` 会报 deprecated 警告，改用 `import pymupdf`。

## 3. GitHub Release 下载卡点与绕过

现象：`https://github.com` 网页 200、DNS 正常，但 Release 资产下载长时间无响应（`Invoke-WebRequest` 直接挂在后台 120s 以上）。根因是资产会 302 到 `release-assets.githubusercontent.com`（旧名 `objects.githubusercontent.com`），该 CDN 域名在 `Invoke-WebRequest` 下极慢。

有效做法：

1. 先只请求 Release 的**重定向头**（15s 超时）拿到 `location` 里的签名 URL；
2. 对该 CDN URL 用 .NET `HttpWebRequest` **直接流式读**再落盘 → 21.52 MB 耗时 130.8 s。

其它观测：

- 本机系统代理登记为 `127.0.0.1:7897` 但**端口实际未监听**（代理软件未运行），直连反而可用；
- 镜像 `gh-proxy.com`、`ghfast.top` 返回 200 可作备选；`ghproxy.net` 8s 超时失败；
- 直连下载在后台运行时**会占住目标文件**，并行再下同一路径会得到 `The process cannot access the file ... because it is being used by another process`——先 `job_kill` 旧任务再重下。

## 4. 安装与验收步骤（可复现顺序）

1. 解压 ZIP（约 34 秒，13k 条目录项），确认顶层为 `ppt-master/skills/ppt-master/`；
2. `robocopy /E` 把 `skills/ppt-master` 下**全部内容**拍平拷到 `.dsh\skills\ppt-master`（exit code 1 表示「有文件被复制」属正常，≥8 才是错误）；**不能只拷 SKILL.md**，`attribution_guard.py` 校验整包，缺文件即失败；
3. `pip install -r requirements.txt` 进 `D:\venvs\pptmaster`（约 70+ 包：python-pptx 1.0.2、PyMuPDF 1.28.2、PyYAML 6.0.3、XlsxWriter 3.2.9、skia-pathops、uharfbuzz、numpy、google-genai、edge-tts、nbconvert 等）；
4. 运行 `scripts\attribution_guard.py`：**退出码 0 且无输出**即通过；
5. 把 SKILL.md 的 `description` 改成中文（沿用本机 28 个技能全中文描述的惯例，保留标题/路由关键词）；
6. 冒烟测试：脚本数 81、`svg_to_pptx.py` / `register_template.py` / `image_gen.py` / `image_search.py` / `finalize_svg.py` 存在、核心 import 全通。

集成验证的一个小坑：skills-manager 的 `discoverReadonlyEntries(root)` 是 **async 且返回对象**（含 entries 字段）而非数组，直接 `.filter` 会 `TypeError`；另外 `.mjs` 文件里混用 `require` 与顶层 `await` 会触发 `ERR_AMBIGUOUS_MODULE_SYNTAX`。正确读法是 `const r = await discoverReadonlyEntries(root)` 再取其中的数组字段。

## 5. 使用注意

- **Image to PPTX 路由别走**：上游硬绑 Codex，其它宿主不保证。
- 宿主自带 `agnes_image_generate` 可充当其 AI 出图后端，无需配 `IMAGE_BACKEND` / API key。
- `.env.example` 13.8 KB，实际用不到的环境变量可留空。
- 默认流程会先追问设计规格（模板/比例/页数）；要跳过需在指令里写明「快速生成，不用确认」。
- 串行出页，10–15 页约 10–20 分钟，token 消耗不小。
- 工作目录：`projects/`、`exports/` 建在启动 agent 的当前目录，**不要**在技能目录内运行，建议另开输出目录。
- 升级会覆盖 `SKILL.md` 的中文 description 与自写的 `DSH-ENV.md`，需重做这两步。
