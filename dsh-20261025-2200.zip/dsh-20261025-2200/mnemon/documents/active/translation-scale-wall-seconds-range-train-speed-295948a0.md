---
id: "295948a0-3e7a-4c79-a4c4-4a360516666a"
title: "Translation 列车漫游调参地图：scale / WALL_SECONDS / range 与滚轮缩放、气泡跟随视距避让（含 TRAIN_SPEED、TRAIN_DWELL 两个误区）"
description: "/realtime 列车漫游落地后的可调参数清单（文件:行号、当前值、观感影响），滚轮调视距的实现要点与 preventDefault 必要性，列车气泡上抬量随视距自适应公式及三种视距的实测间距，以及「改 TRAIN_SPEED 不会改变观感速度」「TRAIN_DWELL 单位是仿真秒」两个常见误改点。属于 72915457 的增量补充。"
status: "active"
created_at: "2026-10-17T08:46:18.677Z"
updated_at: "2026-10-17T08:46:18.677Z"
content_hash: "56071c65d7b63dbaee2668e157e50aa8112ceed28cc6fdf31d864288df0b910e"
source_paths:
  - "Translation/src/cesiumTools/lineAndpoints/train/trainRoam.js"
  - "Translation/src/cesiumTools/lineAndpoints/train/trainSchedule.js"
  - "Translation/src/components/bottom/RealtimePanel/RealtimePanel.vue"
session_ids:
  - "5f69ada2-71e4-4d1a-a08d-16e75a4dc700"
memory_body_ids:
  []
---

# Translation 列车漫游调参地图（/realtime 第二版）

本文是 `72915457-a50b-4583-bad7-a771aab9d999`（/realtime 落地交接）的**增量补充**：只记录落地之后新增的「可缩放视距」「气泡避让」「可调参数地图」这一层，落地过程与站点匹配、相机跟车原理不重复。

## 1. 调参速查（文件:行号 → 当前值 → 影响）

| 想改什么 | 位置 | 当前值 | 说明 |
|---|---|---|---|
| 列车大小 | `Translation/src/cesiumTools/lineAndpoints/train/trainRoam.js:150` | `scale: 1` | 模型节点自带 0.01 缩放，`scale: 1` 即真实尺寸（90m 视距下车长≈30m、屏宽≈600px、包围球半径 19m） |
| 演示速度 | `trainRoam.js:47` | `WALL_SECONDS = 90` | **整条线跑完的墙钟秒数**，调小=更快、调大=更慢；这是唯一的速度开关（第一版 42s 被反馈太快） |
| 默认视距 | `trainRoam.js:74` | `this.range = 90` | 进栏目时的相机到车距离（米）。"车看起来多大"应改这里而不是 `scale` |
| 缩放上下限 | `trainRoam.js:75-76` | `minRange = 22` / `maxRange = 420` | 滚轮可达范围 |
| 轨迹尾巴长度 | `trainRoam.js:50` | `TRAIL_METERS = 3000` | 按米定义，代码换算成 `trailTime`；与速度解耦 |
| 停站时长 | `trainSchedule.js:46` | `TRAIN_DWELL = 2` | 单位是**仿真秒**，建议 30~40 才肉眼可见 |
| 气泡上抬量 | `RealtimePanel.vue:166` / `:134-135` | 初值 `offset: [0, 115]`；公式 `clamp(115*90/range, 70, 240)` | 随视距自适应 |

派生量（由上式自动算出，一般不用手改）：`clock.multiplier = clamp(total / WALL_SECONDS)`（`trainRoam.js:180`），1 号线 2267 仿真秒 ÷ 90 ≈ 25.2（第一版 42s 时为 53.97）。

## 2. 两个易误改点

1. **`TRAIN_SPEED = 16.7`（`trainSchedule.js:44`）不是调速开关。** 它表示物理速度，只影响两件事：气泡里显示的 km/h、以及时间表总时长；因为 `multiplier = total / WALL_SECONDS` 会自动补偿，**改它不改变观感速度**（全程恒为 90 秒），只会改变站间运行与停站的时间比例。
2. **`TRAIN_DWELL` 单位是仿真秒。** 当前倍速约 25 倍，停 2 仿真秒 ≈ 0.08 墙钟秒，"到站"徽标一闪而过、看起来像没停。想真的停住要调到 30~40（每站约 1 秒，全程会多出 15~20 秒）。

另外沿用 `72915457` §3.3 的结论：**不要给模型加 `minimumPixelSize` / `maximumScale`**，包围球就绪前会算出极端缩放（车被放大到几十公里或完全消失）。

## 3. 滚轮调视距

做法极小：上一版已经放弃 `trackedEntity`、改成每帧 `camera.lookAt(pos, new HeadingPitchRange(35°, -22°, this.range))`，所以缩放只需改 `this.range` 一个数，下一帧生效（`trainRoam.js:249-252` 里做 clamp）。

必须处理的点：**要 `preventDefault`**。不拦的话 Cesium 默认滚轮缩放会同时作用于地球，而下一帧 `lookAt` 又把机位拉回车上，表现为"画面抖一下再回弹"。拦掉之后滚轮只改 `this.range`。

视距在切线路、点反向按钮时**不重置**，用户调好的距离一直保持。

## 4. 气泡不再压住列车

两处改动：
1. 初始上抬量 `26px → 115px`；
2. 上抬量跟着视距走：`lift = clamp(115 * 90 / range, 70, 240)` —— 拉近时车在屏幕上变大，固定偏移迟早被车顶到，所以要随视距放大偏移。

实测气泡底边与列车屏幕投影点的间距（1920×1080）：

| 视距 | 间距 |
|---|---|
| 90m（默认） | 115px |
| 51m（滚轮向上 5 格） | 203px（自动让开） |
| 250m（向下 14 格） | 70px（自动收回） |

三种情况下均不重叠，指针尾巴仍指向列车。

## 5. 注意事项

- 改 `WALL_SECONDS` 或 `TRAIN_DWELL` 后建议 **F5 整页刷新**而不是只靠 Vite 热更新——时间表在组件挂载时生成。
- 用户明确表示要自己动手调这些参数，改完只需描述"再慢一倍"或给具体秒数即可，不必改代码替其决定。

## 6. 相关文档

- `72915457-a50b-4583-bad7-a771aab9d999` —— /realtime 完整落地交接（站点↔顶点匹配、每帧 lookAt、onTick 高亮、playIntent、实体数基线 419）
- `7f1a6f08-9d0f-4d25-adfe-c436ac157c88` —— 参考项目 RoamTool 漫游内核剖析与时间轴 scrub 行为对照
- `18fb181e-e047-4909-a1b8-fd9d1a1bd9e8` —— 语雀实时轨迹课程归档与落地差距
