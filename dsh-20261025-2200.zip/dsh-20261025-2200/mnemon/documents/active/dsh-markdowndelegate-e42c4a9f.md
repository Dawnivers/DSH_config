---
id: "e42c4a9f-741d-4123-9a9b-3b74ed33dcc3"
title: "DSH 聊天文件链接失效的根因与正确写法（MarkdownDelegate 路径解析实测）"
description: "排查\"回复里的本地文件链接有时点不开\"：本地链接实为交给 openFile 的路径声明，四类失效原因（文件已不存在、相对路径基准是会话工作区、?/#/反斜杠被当 URL 语法、流式消息未落定）、易误判点（#L 只到起始行、右侧栏只读预览），以及本项目约定的写法。证据取自 DSH 安装目录内的 README 与 client 实现。"
status: "active"
created_at: "2026-10-18T11:20:26.036Z"
updated_at: "2026-10-18T11:20:26.036Z"
content_hash: "0237d242a7d39d4108fdb853a9cc1904ae01494a9fb375550f3b49f12d82cd48"
source_paths:
  []
session_ids:
  - "66016376-31a7-413b-9a89-97fdf5f8ba85"
memory_body_ids:
  []
---

# DSH 聊天里的文件链接：为什么会失效，以及该怎么写

## 0. 一句话结论

回复中的本地文件链接**不是普通超链接**，而是交给 `MarkdownDelegateProvider.openFile` 的一条**路径声明**。解析不通过就**静默丢弃**（点了没反应），解析通过但文件不存在就进**预览错误态**——两种故障表现不同，但都表现为"链接坏了"。

## 1. 四类失效原因（按本项目实际出现概率排序）

1. **目标文件已不存在（最主要）**
   文档原文：`文件缺失时显示预览错误状态`。本项目高峰期踩满：早前引用 `StationPanel/heatmap/cesiumHeatMap.js`、`StationPanel/heatmap/useHeatmap.js`，随后目录重排为 `StationPanel/QueryModePanel/heatmap/`，并曾误删过一次；旧链接未同步即全部失效。
2. **相对路径的解析基准是「当前查看的 Session 工作区」，不是生成消息时的 cwd**
   因此换工作区、从侧栏另开会话、恢复旧会话后，同一条相对链接会解析到别处。绝对路径走同一会话的文件系统访问，不受工作区影响。
3. **路径字符被当成 URL 语法，整条链接根本不会传给打开器**
   `URL 协议、查询串、不支持的片段及格式错误的目标不会传给文件打开器`；`文件名中的字面 ? 和 # 必须百分号编码`。于是：文件名含 `?` / `#` → 被当 query/fragment → 丢弃；用 Windows 反斜杠 `D:\...\a.js` → 不被识别为分隔符。第 3 类的表现是**点击完全无反应**；第 1 类是**打开后报错**——可据此区分。
4. **消息仍在流式生成时点击**
   链接在**消息落定后**才可于右侧栏打开。

## 2. 容易误判的两点

- `#L24-L30` 只**定位到起始行**，不做 24–30 的高亮选区。
- 点开是**右侧栏只读预览**，不是编辑器跳转。

## 3. 本项目约定写法（agent 自用）

1. 只用**工作区相对路径 + 正斜杠**，不写 `D:\` 绝对路径；
2. 移动 / 重命名后旧链接一律作废，**同一轮里重新给出新路径**，不与旧路径混用；
3. **不存在的文件不给链接**（讲历史实现时用代码块写纯文本路径）；
4. 写 `#L` 行号前先确认行号仍落在目标行（文件被编辑过行号会漂）。
5. 工作区之外的目标（如 DSH 安装目录下的 README）本就不适合做链接，一律用代码块写路径。

## 4. 证据来源（DSH Desktop 安装目录内）

- `...\node_modules\@deepseek-ai\dsh-client-ui-deliverables\lib\index.js:257` —— `FILE_REFERENCE_PROMPT` 原文（尖括号包裹、`#L24`/`#L24-L30` 锚点、present 卡片的使用边界）。
- `...\node_modules\@deepseek-ai\dsh-client-ui-primitives\README.zh.md:93` —— `openFile` 回调、百分号转义、字面 `?`/`#` 必须编码、不支持片段被过滤、回调收到解码后路径与可选行号。
- `...\node_modules\@deepseek-ai\dsh-client-ui-chat\README.zh.md:36` —— 相对路径基于当前 Session 工作区解析；`#L24` 定位起始行；文件缺失显示预览错误；**消息落定后**方可打开。
- `...\node_modules\@deepseek-ai\dsh-client-ui-primitives\lib\index.js:11809` —— 实现侧对 `#L24` / `#L24-L30` 目标的处理（范围以首行开区间）。
