---
id: "bda3f457-c9ce-46b9-bca8-e239586f7f52"
title: "用 WPS COM（KWPS.Application）自动化生成实验报告 docx 的实操流程"
description: "本机通过 WPS COM 接口现场排版生成 21 页实验报告 docx 的可复用流程：ProgID KWPS.Application 实测兼容 Word 自动化模型、纯 ASCII 脚本 + UTF-8 JSON 中文内容分离的原因、三层验收（WPS 目视截图 / COM 计数 / OOXML 解包校验）、重出文档方式与已知限制。实验数值与 ENVI 偏差见 9a6d1e61。"
status: "active"
created_at: "2026-10-13T08:37:40.864Z"
updated_at: "2026-10-13T08:37:40.864Z"
content_hash: "c73650fffcbfa1c8c072bb7ab4ad4a1b8eeb3d7f839e6ba19b994417e01d002d"
source_paths:
  []
session_ids:
  - "a9ea9275-55ae-4b8e-9a51-200bd9095995"
memory_body_ids:
  []
---

# 用 WPS COM 生成 docx 报告：可复用流程

配套实验的结果、数值与偏差记录见 `9a6d1e61-5598-45f2-afa8-2bbe2df41884`（东湖 NDWI vs MNDWI）。本文档只记录**把既有 Markdown/素材排版成 Word 文档**这条链路的做法与验收证据。

## 1. 接口结论（实测）

- 本机 WPS Office 12.1.0.28505，COM ProgID 探测：`KWPS.Application` = registered，`kwps.Application` = registered，而 `WPS.Application` = **未注册**；`Word.Application` 也 registered。
- 用 `New-Object -ComObject KWPS.Application` 建实例后 `Name` 返回 **"Microsoft Word 12.0"**，说明 WPS 完整兼容 Word 自动化对象模型：`Documents.Add` / `Selection.TypeText` / `Tables.Add` / `InlineShapes.AddPicture` / `SaveAs2(..., 16)` 一路可用，落盘为标准 docx，用户可在 WPS 中直接编辑。
- 因此**不需要**拼装 OOXML，也不需要依赖 Microsoft Office。

## 2. 脚本拆分模式（关键）

- `scripts\doc_content.json` —— 全部中文内容：章节标题、段落、表格数据、图注。
- `scripts\build_docx.ps1` —— 排版引擎，源码**纯 ASCII**，运行时从 UTF-8 的 JSON 读入中文。

原因：Windows PowerShell 5.1 读取 `.ps1` 按 ANSI 解析，脚本内含中文时会把行尾一起吞掉、破坏语法（本机同日已在 `list_windows.ps1` 上踩过一次同类问题）。用「ASCII 脚本 + UTF-8 数据文件」分离，可同时避开脚本编码与命令行传参编码两个坑。

重出文档：改 `doc_content.json` 后重跑 `build_docx.ps1`，秒级生成新版本，不必重做排版。

## 3. 产物与三层验收

产物：`F:\RS_Lab\05_report\遥感数字图像处理实验报告.docx`，5.89 MB；含封面、技术路线、8 个步骤逐条展开、结果与结论、环境偏差说明、成果清单，插图来自 `05_report\screenshots`（01–16）。

1. **WPS 目视**：启动 WPS 打开该 docx 并截图留档（`_shots\w01_cover.png` 封面、`w02_body.png` 正文、`w03_page.png` 图片题注页、`w04_table.png` 表格页），确认中文字体无缺字、图注居中。
2. **COM 自查**：`pages=21  words=4239  images=16  tables=12`。
3. **OOXML 包校验**：解包后 `word\media` 下 16 个媒体文件共 5.86 MB、`<w:tbl>` 12 个、`<w:drawing>` 16 个、分页符 4 个、`sectPr` 1 个（A4 页面设置生效）。

## 4. 已知限制与可选增强

- 没有自动目录：未套用「标题 1/2」样式，WPS 左侧显示"暂无目录"；补齐样式即可生成目录。
- 无页眉页脚与页码。
- 部分截图是整窗口截图，含桌面/DOS 边缘留白，裁到软件窗口会更紧凑。
- 临时产物（`_wps_test.docx`、解包校验目录）生成后即清理。
