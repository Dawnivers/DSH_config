---
id: "11573488-6d27-44e6-837a-400007e4ea72"
title: "第3章《界面和代码》：老式 .doc 无损提取过程与 ArcObjects 几何代码要点"
description: "从 119808 字节 OLE2 .doc 中提取 482 段正文与 6 张内嵌 PNG 的可复用流程（Word COM SaveAs 会挂死），以及该章 ArcObjects 几何/空间参考代码的菜单项、核心 API 与已发现的代码缺陷。"
status: "active"
created_at: "2026-10-07T02:33:22.015Z"
updated_at: "2026-10-07T02:33:22.015Z"
content_hash: "1682560fa3ca07f0919f417bdd386906aa5fa4ec91d3aabaf290bcd0b8dbf3fa"
source_paths:
  - "第3章界面和代码(1).doc"
  - "chapter3_clean.txt"
  - "chapter3_outline.txt"
  - "chapter3_images"
session_ids:
  - "71f0747e-1acb-4758-a7d5-8f4c5f7b3781"
memory_body_ids:
  []
---

# 第3章《界面和代码》：老式 .doc 无损提取过程与 ArcObjects 几何代码要点

来源：一次「读不出来这份 .doc」的排查 + 全文通读会话。原始需求只是问助手有什么功能，随后转成对 `第3章界面和代码(1).doc` 的完整提取与内容梳理。

## 1. 可复用的提取流程（本机验证通过）

输入：`第3章界面和代码(1).doc`，119808 字节，文件头 `D0 CF 11 E0 A1 B1 1A E1` → 老式 OLE2 二进制 Word 文档；`WORD_OK version=16.0` 表示本机装有 Word 16。

**关键坑：Word COM `Document.SaveAs` 在本机会挂死。** 无可见窗口时 SaveAs 试图弹模态框，进程停在 `Responding: True` 但永不返回（两次后台任务均超时 120s 后被 kill），因此 `.doc -> .docx` 转换这条路不可用。改用两步分别取文本与取图：

1. **取正文（COM 读字符串，不做 SaveAs）**：绑定 Word COM，遍历 `Paragraphs` 拼正文文本，自行落盘，跑完再显式 kill Word 进程收尾。
2. **取插图（直接扫二进制）**：在 `.doc` 原始字节里搜媒体签名。本次命中 PNG 6 个（偏移 47351 / 66940 / 71887 / 76102 / 80588 / 83981），JPEG-APP0、JPEG-APP1、GIF、可放置 WMF 均为 0 命中。按 PNG 块结构（IHDR…IEND）切出完整文件，6/6 校验通过。

**执行环境坑：** 直接运行 `.ps1` 脚本文件被「AuthorizationManager 检查失败」的 PSSecurityException 拦下（执行策略问题）；把同一段脚本体改用进程内 `Invoke-Expression` 执行即可绕过。另外 Word 产出的段落分隔符是 `\r`，直接被当单行读取会把 482 段压成 1 行，必须先规范化换行和控制符（文件里出现 6 个 `0x01` 控制符）再读。

**结构核验结论：** 11 页（约）、482 段、6 个 InlineShapes/Shapes、4223 词、21926 字符；Comments / Footnotes / Endnotes / Revisions / Hyperlinks / Fields 全为 0，Sections = 1，无页眉页脚、无表格、无标题层级（全部为「正文」样式）。6 张图全部锚定在正文最前面 3 段，即文中「界面如上」所指。

产物（工作区根目录）：
- `chapter3_clean.txt` — 规范化换行后的 482 段全文
- `chapter3_outline.txt` — 逐段样式清单（段落号 | 样式 | 文本）
- `chapter3_images/img1.png` … `img6.png` — 6 张内嵌原图（866x526、212x131、161x112、156x116、133x68、223x114）
- `第3章界面和代码(1).doc` — 原件副本

## 2. 文档内容结构

「界面截图 → 数据准备 → 完整 `Form1.cs` 代码」三段式，单文件 `Form1.cs` partial class，`namespace 第3章`，基于 ArcGIS 10.2 Engine + VS2010 窗体。

数据准备：新建 `Geometry.mxd`，新建 `multipoint.shp`、`polyline.shp`、`polygon.shp` 三个矢量图层加载进去后保存关闭。

界面：`axTOCCcontrol1`（图层树）+ `axMapControl1`（地图视图）。顶部 MenuStrip 五个顶级菜单共 14 项：

| 顶级菜单 | 菜单项 |
|---|---|
| IGeometryCollection | AddGeometry、AddGeometryCollection、InsertGeometriesCollection、SetGeometries |
| ISegmentCollection | AddSegments、QuerySegments、SetSegments |
| IPointCollection | AddPointCollection、QueryPoints、UpdatePoint |
| Polygon | CreatePolygon |
| SpatialReference | GetSpatialReference、ChangeLayerSpatialReference、SetMapSpatialReference |

## 3. 代码要点（便于复用）

引用 `ESRI.ArcGIS` 的 esriSystem / Carto / Controls / SystemUI / Geometry / Geodatabase / DataSourcesFile / Display / CatalogUI（后者专为 `ISpatialReferenceDialog` 而加）。

基础部分：
- 构造函数先 `RuntimeManager.Bind(ProductCode.EngineOrDesktop)` 再 `InitializeComponent()`（顺序不能反）。
- `loadMapDocument()`：OpenFileDialog 选 `.mxd` → `CheckMxFile` → 沙漏光标 + `LoadMxFile` → `Extent = FullExtent`。
- `addFeature(layerName, geometry)`：按名找图层 → `IFeatureLayer.FeatureClass` → `IDataset.Workspace` → `IWorkspaceEdit` 开编辑 → Search 游标删光原有要素 → Insert 游标 + `CreateFeatureBuffer` 插入新几何 → `Flush` → `StopEditing(true)` → `ReleaseComObject`。
- `saveDocument()`：`MapDocumentClass.Open` → 检查 `IsReadOnly` → `ReplaceContents(map)` → `Save(UsesRelativePaths, false)`。

几何操作核心 API：`IGeometryCollection.AddGeometry` / `AddGeometryCollection` / `InsertGeometryCollection` / `IGeometryBridge.SetGeometries`；`Path.AddSegment` / `GeometryEnvironmentClass.AddSegments` / `QuerySegments` / `IGeometryBridge.SetSegments`；`SetPoints` / `AddPointCollection` / `QueryPoint` / `AddPoint` / `UpdatePoint` / `get_Point`；`CreatePolygon` 用 4 点 → 3 条 Line → `Path` → 逐段搬进 `Ring` → `Ring.Close()` → 装入 `Polygon`。

空间参考：`IGeoDataset.SpatialReference.Name`；`IGeoDatasetSchemaEdit.CanAlterSpatialReference` + `SpatialReferenceEnvironmentClass.CreateGeographicCoordinateSystem(4214)`（4214 = Beijing1954）+ `AlterSpatialReference`；`SpatialReferenceDialogClass.DoModalCreate(true,false,false,0)` → `IMap.SpatialReference` → `ActiveView.Refresh()` → 存盘。

## 4. 通读时发现的代码缺陷（属于审阅意见，非原文内容）

1. `addFeature` 找不到匹配图层时 `layer` 停在最后一个图层，不报错直接往下走，会写错图层；且比较为 `layer.Name.ToLower() == layerName`，图层名必须恰好是 `multipoint`/`polyline`/`polygon` 才命中。
2. 用 `Search(null, true)` 得到的是回收型游标（recycling），在其上 `feature.Delete()` 行为不可靠，惯例应为 `Search(null, false)`，且删除后未 `Flush`。
3. `querySegments` 按 `SegmentCount` 预建 `outputSegmentArray`，实际查回段数更少时剩余空 Line，弹窗会打出一串 `0, 0`。
4. `addPointCollection` 里的 `pointCollection2` 是死代码（原文注释自标），最终赋给 `multipoint` 的是 `pointCollection1`。
5. `insertGeometriesCollection` 连续两次插到索引 1，第二批会把第一批挤到后面，实际顺序与直觉相反。
6. `AlterSpatialReference` 只改元数据、不做投影变换，坐标值不变；且弹窗打印的是枚举名而非坐标系名称。
7. 正文只有 `Form1.cs`，缺 `Program.cs`/`Main` 与 `Form1.Designer.cs`，控件声明和事件绑定不在正文里。

## 5. 相关环境状态

会话内尝试把「Word COM SaveAs 挂死」等环境坑写入热记忆时被拒：记忆区已满（约 9846/10240 字节），归档需要可写 Memory Space，而本机目录中尚无可写空间，且底层 `mnemon` CLI 缺失（spawn ENOENT），因此相关坑位记录未能落盘。本文件即为这些坑位的持久化载体。
