---
id: "f120df6f-8480-4127-9793-8df0e970da36"
title: "Translation 智慧地铁：共享站点被连带关闭的修复（线路开关与站点开关分离 + 归属集合回归）与线路行点击目标拆分"
description: "2026-10-10 两轮迭代：先修「关 4号线连带关掉与 3号线共用的 10 个站」，把线路开关与站点开关拆开、可见性由 isVisible 组合算出并重新引入 stationOwners 归属映射（推翻 b193f736 的删 owners 结论），含 29/26/10 共站基准与 0/29/45/29、400/386 实测；再把线路行拆成「方块管显隐 / 名字只管切右栏」两个点击目标；附项目结构重排后的新文件路径（screenUI → bottom、StationPanel 拆目录、新增 popup 模块）。"
status: "active"
created_at: "2026-10-10T11:55:43.326Z"
updated_at: "2026-10-10T11:55:43.326Z"
content_hash: "045a7ca34a753d420fc30ed755903af2bfbc71411f062032bd23e3c21f7b1414"
source_paths:
  - "Translation/src/components/bottom/StationPanel/StationPanel.vue"
  - "Translation/src/components/bottom/StationPanel/MarkerTemplate.vue"
  - "Translation/src/components/bottom/Toolbar.vue"
  - "Translation/src/stores/stationState.js"
  - "Translation/src/cesiumTools/lineAndpoints/points/setpoints.js"
  - "Translation/src/cesiumTools/lineAndpoints/popup/popupManager.js"
session_ids:
  - "de7f4603-bb7b-4cc3-b092-3782c82c4ffe"
memory_body_ids:
  []
---

# 共享站点连带关闭的修复 + 线路行点击目标拆分

日期：2026-10-10。两个连续迭代，同一文件（站点面板）。

相关文档：
- `06177dd0-801f-488a-9ec4-6a1e0cefb741` —— 前置：`lineStationOn` 线路级开关的由来，其结论「共站只有一份开关、最后点的线路说了算」被本文第 2 节取代
- `b193f736-9678-4340-b1f0-5e763faf3a7e` —— 前置：写 show 模型（`hideStationByName`）。该文第 3 节「删掉 `owners` 归属 + `stationOwners` computed」被本文推翻：归属集合必须回来
- `3a0ce399-303d-4a00-95ef-e3c3d0db18af` —— StationPanel 面板落地与两个响应式/裁切真 bug（布局与 Teleport 结论不变）

## 1. ⚠️ 先说项目结构：文件已重排（写下来只是因为后面会一直用错路径）

用户在我上一次改动之后自行重排了目录。**旧路径 `Translation/src/components/screenUI/StationPanel.vue` 已不存在**（读它报 not found）。当前落点是：

| 旧 | 新 |
|---|---|
| `components/screenUI/Toolbar.vue` | `components/bottom/Toolbar.vue` |
| `components/screenUI/StationPanel.vue` | `components/bottom/StationPanel/StationPanel.vue` + `components/bottom/StationPanel/MarkerTemplate.vue` |
| — | 新增 `components/cesiumTools/lineAndpoints/popup/`（`popup.js`、`popupManager.js`） |

改动时间线（mtime 佐证）：`screenUI/foot.vue` 19:28 → popup/points 19:38 → MarkerTemplate 19:39 → router 19:41 → bottom/Toolbar.vue 19:48。`screenUI/foot.vue` 仍在，`RouterView` 由它和 `router/index.js`、`App.vue` 共同持有。

**教训**：跨轮次改这个面板前先确认路径存在；读不到文件不等于代码消失，很可能是被用户搬走了，先按符号（`stationObjs`、`lineStationOn`、`sp-check`）反查落点再动手。

## 2. 🔴 真 bug：关 4号线把与 3号线共用的站一起关掉

**用户场景**：先点 3号线，再点 4号线，然后关掉 4号线 → 3号线的一部分站点跟着灭。

**根因**：`toggleLine` 用「写站点标志位」表达线路开关：

```js
// 有 bug 的写法
const toggleLine = (line) => {
  lineStationOn[line.name] = next;
  names.forEach((name) => {
    const target = stationByName.get(name);
    if (target) target.checked = next;   // ← 共站只有一份 checked，被一起改写
  });
};
```

关 4号线时，代码把 4号线名下**所有**站（含与 3号线共用的那批）写成熄灭。共站只有一份 `checked`，于是 3号线那部分也黑了 —— 这就是「连坐假象」的真正来源，不是渲染问题。

**修法：线路开关与站点开关各自独立存，可见性由两者组合算出。**

```js
// 可见性 = 站点自己的开关开着 && 所属线路里至少有一条开着
const isVisible = (name) => {
  const target = stationByName.value.get(name);
  if (!target || target.checked === false) return false;
  const owners = stationOwners.value.get(name) ?? [];
  return owners.length === 0 || owners.some((n) => lineStationOn[n] !== false);
};

// 点线路：只翻线路自己的开关，绝不碰任何站点的 checked
const toggleLine = (line) => {
  lineStationOn[line.name] = !lineLit(line);
  syncAll();
};
```

`stationOwners`（站名 → 拥有它的线路名集合，由 `dataStore.Lines` 现算）**必须存在**：换乘站在三维里只画一个光锥，判断它该不该显示必须看「全部业主线路」，不能只看当前浏览的那条。这是共享对象模型下唯一正确的做法。

`syncAll()` 把组合结果整体落到三维对象上（只切 `show`，不销毁对象）：

```js
const syncAll = () => {
  const on = [], off = [];
  stationObjs.forEach((item) => (isVisible(item.name) ? on : off).push(item.name));
  hideStationByName(stationObjs, on, true);
  hideStationByName(stationObjs, off, false);
};
```

**取舍说明（重要）**：用户此前明确要求「不要搞得那么复杂」，那次重构删掉了 owners 归属集合（见 `b193f736`）。删掉的代价正是这个连带 bug —— 共享对象要判断「还有没有别的线撑着它」，就需要归属信息。本轮把归属作为**纯计算**（`computed`，无额外状态）加回，复杂度换正确性。

## 3. 实测基准与验证（3号线 ↔ 4号线）

接口数据先算基准：**3号线 29 站、4号线 26 站、共站 10 个**（宜山路、虹桥路、延安西路、中山公园、金沙江路、曹杨路、镇坪路、中潭路、上海火车站、宝山路）。

| 步骤 | 可见光锥 | 预期 |
|---|---|---|
| 全部隐藏 | 0 | 0 |
| 点 3号线 | 29 | 29 |
| 点 4号线 | **45** | 29+26−10（顺带验证共站只渲染一个光锥，不重复计数） |
| 关闭 4号线 | **29** ✅ | 29，10 个共站一个都没被连带关闭 |

回归（0 报错）：加载后 0 → 进入 `/nodes` 400（右栏 1号线 28/28）→ 全部隐藏 0 → 点 1号线 28（左栏只有第 1 行亮）→ 单关「富锦路」399 → 再点开 400 → 单关换乘站「呼兰路」399（27/28）→ 收起栏目 0 → 重新展开 399 且呼兰路仍是关闭态（状态保留）。

## 4. 线路行点击目标拆分：方块管显隐，名字管跳转

**用户要求**：「只有点击线路面板线路左侧的方形才显隐，只点击线路名字只让右侧站点面板跳转到对应线路。」

改前整行是一个 `<button @click="toggleLine(line)">`，点哪儿都切换显隐；`toggleLine` 里还顺手写 `focusedLine.value = line.name`。改后一行里两个各自独立的点击目标：

```html
<div class="sp-line">
  <button class="sp-check" @click.stop="toggleLine(line)"></button>  <!-- 只管亮/灭 -->
  <button class="sp-line-name" @click="focusedLine = line.name">     <!-- 只切右栏 -->
    <i class="sp-chip"></i><span>{{ line.short }}</span>
  </button>
</div>
```

`toggleLine` 里的 `focusedLine` 赋值被删除 —— 切线路现在是名字按钮的专属动作。CSS 相应调整：`.sp-line` 从按钮还原为容器（悬停不再整行变色，避免暗示「点哪儿都行」，只有名字悬停变青色）；`.sp-check` 从 12px 放大到 **14px** 并加 hover 青色高亮 —— 它现在是唯一管显隐的入口，必须一眼看出可点、也更好点中。

实测（0 报错）：进入 `/nodes` 400 → 点「5号线」**名字** 仍 400、右栏切到 5号线 15/15、左栏 18 行全亮不变 → 点「5号线」**方块** 386、右栏仍停在 5号线（没被切走）、左栏只有第 5 个灭 → 点「1号线」名字 仍 386、右栏切到 1号线 → 再点「5号线」方块 回到 400。

③ 那步的数字顺带验证两个机制在配合：5号线共 15 站，实际只灭了 **14** 个 —— 剩下的「莘庄」与 1号线共用，1号线还开着所以保持显示（即第 2 节的组合规则）。

## 5. 附带行为约定

- **批量操作**：`onHideAll` 只关线路开关，**不动站点 `checked`** —— 站点开关记的是「这个站我想不想看」的个人意图，不该被一次批量操作抹掉（线路全灭后它们本来也不可见）。`onShowAll` 两者都置真，否则行状态会和实际脱节。
- **点不可见站点**：`toggleStation` 若发现该站当前不可见（自己的开关关了，或所属线路都灭了），点一下就是「让它亮起来」，必要时把当前线路也点亮，避免出现「点了没反应」的死按钮。
- **行状态不可由站点标志位反推**：`lineLit(line) => lineStationOn[line.name] !== false` 只认线路自己那份开关。共站被点亮时若用 `some` 反推，会让 2/3/8 号线「还有亮的站」也成立、整片行跟着亮（`every` 反推则同样连坐）。
