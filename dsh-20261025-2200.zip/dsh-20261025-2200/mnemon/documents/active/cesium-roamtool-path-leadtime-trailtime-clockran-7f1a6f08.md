---
id: "7f1a6f08-9d0f-4d25-adfe-c436ac157c88"
title: "Cesium 参考项目 RoamTool 轨迹漫游内核剖析：时间即真值、path.leadTime/trailTime、clockRange 与时间轴 scrub 行为（供 Translation 列车漫游移植）"
description: "参考项目 Cesium/src/lib/RoamTool.js 的漫游内核结构、四个可复用决定（path leadTime/trailTime、clockRange、纯函数时间戳、destroy 顺序）、「不保存派生状态」纪律，以及原生 Timeline 与本项目复制版 timeline.js 在 shouldAnimate 上的行为差异；含移植目标 trainRoam.js 与待解问题。"
status: "active"
created_at: "2026-10-17T07:49:02.188Z"
updated_at: "2026-10-17T07:49:02.188Z"
content_hash: "2d251d518be55ef0a41879c3d7c0551513cde3e493ecacecdcf1957c306b43e9"
source_paths:
  - "Translation/src/cesiumTools/Time/timeline.js"
  - "Translation/src/cesiumTools/lineAndpoints/train/trainRoam.js"
session_ids:
  - "048db046-e445-4e4c-8b98-7dd64b5b0bd8"
memory_body_ids:
  []
---

# 参考项目 `RoamTool` 漫游内核剖析（2026-10-17 局部调查）

调查对象：`D:\WebGIS\web三维开发\Cesium`（Vite dev server 跑在 **5174** 端口，`src/main.js` 只有一行
`import './lesson/36轨迹漫游分析'`，所以打开页面即第 36 课）。核心文件
`src/lib/RoamTool.js`（481 行）、`src/lib/DrawTool.js`（545 行）。

目的：判断这套参考实现能否作为本项目 `Translation` 列车实时漫游的内核，以及**该抄什么、不该抄什么**。
本次只做阅读与对照，**未改任何文件**；移植方案已提出但未被用户确认。

## 1. 数据链路（很短，没有隐藏数据源）

```
DrawTool.DrawEndEvent.raiseEvent(绘制实体, positions, drawType, points)   // DrawTool.js:501
  → lesson 36:120 listener 取第 2 个参数 positions
  → roamTool.startRoam(positions, 30)                                     // 速度 30
```

`DrawTool` 完成绘制后依次 `unRegisterEvents()` → `destoryMarker()` → 复位 `drawType/drawEntity/positions`。
「画出来的折线就是轨迹」，没有任何站名、时刻表或外部接口。

## 2. RoamTool 的五块结构

| 块 | 位置 | 作用 |
|---|---|---|
| `getTime(positions, speed)` | :227 | 逐段 `距离/速度` 累加，返回 `{timeset, times}` |
| `startRoam(positions, speed)` | :59 | `SampledPositionProperty` + `availability` + `VelocityOrientationProperty`，配置 clock，挂相机 |
| `trackView` / `updateView3` / `updateView1` | :257 / :384 / :428 | 自由视角 / 第三人称 / 第一人称 |
| `pause` / `destroy` | :454 / :458 | 暂停、彻底清理 |
| `addExhaust` | :175 | 粒子拖尾，已注释、默认不启用 |

## 3. 四个可复用决定

1. **轨迹线交给 `PathVisualizer`，不手工画多段线**
   实体只用 `path: { material: PolylineGlowMaterialProperty(...), width: 10, leadTime: 10, trailTime: 10 }`。
   Cesium 1.97 `PathVisualizer.js:481-486`：`sampleStart = time - trailTime`、`sampleStop = time + leadTime`，
   且 `:492-496` 会把区间再夹到实体 `availability` 的 start/stop 内。
   → 「已走过的轨迹」是 `clock.currentTime` 的纯函数，拖时间轴自动正确，无需再维护一条高亮实体。
2. **`clockRange` 必须显式设置**（:131）
   ```js
   this.viewer.clock.clockRange = this.options.isLoop
     ? Cesium.ClockRange.LOOP_STOP
     : Cesium.ClockRange.UNBOUNDED;
   ```
   `isLoop` 默认 true。文档与参考项目 `CurrentRoute.vue` 都漏了这一步，于是漫游结束后实体“静默消失”。
3. **`getTime` 这类纯函数时间戳**优于读 `position._times`（私有字段），且结果可直接给面板/站点索引复用。
4. **`destroy()` 清理顺序**（:458）
   `camera.lookAtTransform(Matrix4.IDENTITY)`（先解相机锁）→ `Clear()`（移 onTick 监听）→ 停 clock → 隐藏并移实体。
   `startRoam` 开头（:61-63）先 `destroy()` 上一条，所以连续画线不残留。

## 4. 它为什么“能正常跑”：**没有保存任何派生状态**

整个类里没有 `metroIndex`、没有到站判断、没有 `setTimeout` 暂停。唯一真值是
`位置 = SampledPositionProperty.getValue(clock.currentTime)`。时间轴拖到哪，车就在哪，
不存在“索引与时间脱节”的 bug 面。

文档里各种补丁和参考实现的修修补补，本质都在为「额外保存了一份派生状态」付代价：
索引由位置推出，本不该被存；一旦存下就必须在「到站事件」与「时间轴拖动」两条更新路径间同步。

**核心纪律：站点索引 = `f(clock.currentTime)`，不是 `f(到达事件)`。**
停站也不要用 `setTimeout`，而应在采样时间上留缺口（停 2 秒就补 2 秒间隔）——停站成为时间轴上可拖、可回看的刻度。

## 5. 时间轴拖动行为：参考项目与本项目**不一致**（修正上一轮说法）

| | shouldAnimate 拖动时 | 松手后 |
|---|---|---|
| 原生 Timeline（5174 这套，`timeline: true`） | `Viewer.js:52-56` `onTimelineScrubfunction` → `clock.currentTime = e.timeJulian; clock.shouldAnimate = false` | 原生 `Timeline.js` 通篇无恢复 true 的代码，**车停住** |
| 本项目 `Translation/src/cesiumTools/Time/timeline.js`（复制版，1025 行） | mousedown 里 `shouldAnimate = false` 被注释（:779） | `createMouseUpCallback`（:800-802）写了 `timeline._clock.shouldAnimate = true`，**自动续播** |

即本项目 HUD 时间轴行为为「拖动期间暂停、松手继续跑」。接入 `/realtime` 后真正待解的是另外两件事：
拖出 `[start, end]` 区间列车会消失；「到站停顿」用 `setTimeout` 与时间轴不同步。

## 6. 它解决不了的那一半

没有「站」的概念。真实地铁实时轨迹必须回答「现在到哪一站、车里多少人」，属于站点/区间语义而非纯几何。
可作为**内核**移植（漫游 + 三种相机 + 清理 + 轨迹裁剪），站点层自建。

拟移植目标（未落地）：`Translation/src/cesiumTools/lineAndpoints/train/trainRoam.js`。

## 7. 相关文档

- `898c7711-8359-4297-8e5c-4fd4ef2b9a07` —— Translation `cesiumTools` 下工具封装惯例（材质 Property、清理接口、实体数基线）
- `34066e27-5ad4-41df-8448-8029411158f8` —— 发展历程面板：其中「当前节点由 `currentTime` 推出」与本纪律同源
- `a29177f1-d76e-4ea5-a05f-29ed71258be7` —— 课程存档与参考仓库核对方法
