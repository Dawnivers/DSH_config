---
id: "4b4b2f1f-f963-4446-89f8-d87657b8102c"
title: "Translation 路径规划面板增量：分段/换乘展开、全局线路同色规则、进出站步行为何不展示（坐标偏差 723 m）"
description: "在既有 guideload 路径规划文档之上的增量：planModel 新增 legs/viaStops、RouteDesign 可展开的地铁行与换乘行、线路颜色改回 dataStore.Lines 下标取色以与全局线路一致，以及高德坐标与项目站点坐标差 723 m 导致进出站步行属假数据故只留档不展示的取舍；含数据层与浏览器验证证据。"
status: "active"
created_at: "2026-10-19T05:14:45.688Z"
updated_at: "2026-10-19T05:14:45.688Z"
content_hash: "0f53d63700670f3c20904c01f48eb3ff5548ff9b562d8292938628887becc99c"
source_paths:
  - "Translation/src/components/bottom/StationPanel/QueryModePanel/guideload/planModel.js"
  - "Translation/src/components/bottom/StationPanel/QueryModePanel/guideload/RouteDesign.vue"
  - "Translation/src/components/bottom/StationPanel/QueryModePanel/guideload/useRoutePlan.js"
  - "Translation/src/components/bottom/Toolbar.vue"
  - "Translation/src/components/bottom/StationPanel/StationPanel.vue"
session_ids:
  - "f842a8c6-bcb8-4ff7-9f93-670880491724"
memory_body_ids:
  []
---

# 路径规划面板增量：展开交互 + 全局线路同色 + 步行数据取舍

日期：2026-10-19。前置文档：`44fe1831-c29a-4d4c-aed8-334dfb8fa556`（guideload 模式四文件结构、datalist 输入、几何走本地折线切片）。本文只记该文档之后的三项增量，不要再重复其内容。

## 1. 线路颜色必须与全局线路同色（用户追加要求）

`useRoutePlan.js` 里给分段上色改为**与线路图层完全相同的取色规则**，不再用独立的配色表：

```js
const index = dataStore.Lines.findIndex(line => line.name === lineName);
LINE_COLORS[index % LINE_COLORS.length]
```

同一取法已存在于 `Toolbar.vue`（约 369 行）、`StationPanel.vue`（约 38 行）与发展历程。收益：路径高亮的「1号线」与线路图层里的 1号线是同一种颜色；后续若整体换官方线路色，三处会一起变。

**判断依据**：凡涉及线路实体的颜色，一律走 `dataStore.Lines` 下标 + 全局 `LINE_COLORS` 取模，禁止在业务组件内自配颜色表。

## 2. 面板列表改为可展开（planModel + RouteDesign）

`planModel.js` 新增两个导出，接口顺序原样保留：

```
legs     = [ {type:'metro', segment}, {type:'transfer', station, distance, steps}, {type:'metro', …} ]
viaStops = 某段的中间途经站站名数组
```

- `segments` / `transfers` 保持原样，仍供三维渲染使用；`legs` 只是面板用的线性行程视图。
- **每两段之间都给换乘行**，即使站内步行距离为 0——否则两段地铁挨着显示，看不出此处要换线。
- `RouteDesign.vue` 列表项可点击展开：地铁行 → 「途经 N 站」+ 完整站序 `A → B → … → Z`；换乘行 → 接口 `instruction` 原文（如「步行360米到达陕西南路」），无指引的换乘行不可点。
- 展开态用普通对象 `{[index]: boolean}`（非 Set），换方案时 `watch(result)` 清空——旧下标会失效。
- `stopCount` 与展开站序可互校：`途经 N 站 + 起终 = stopCount`（实测 14 中间站 + 2 = 16 站）。

## 3. 关键取舍：进出站步行是假数据，只留档不展示

接口会返回「步行 723 米到达莘庄」这类进出站步行，原因是两套数据坐标不同：

| 数据源 | 莘庄站坐标 |
|---|---|
| 项目本地站点 | `121.38029,31.112356` |
| 高德 | `121.385373,31.111152` |

相差约 **723 m**。而面板上起点终点本来就是站，用户会认为「两边都选了莘庄还要走 723 m = 算错了」。

因此：
- **不展示** `accessWalk / arrivalWalk`，仅在数据里保留字段留档；
- **照常展示**站与站之间的换乘步行（陕西南路 1↔10 的 303 m 是真实站内通道）；
- 概况文案由「全程步行」改为「**换乘步行合计 303 m**」，与下方换乘行逐一加总一致。

另一个接口自身不一致点：换乘行 `walking.distance = 303 m`，而 `instruction` 写「步行360米」。**只显示 `instruction` 原文**，不额外并列一个 360 m 去和 303 打架。

## 4. 验证证据

- **数据层**（node 直接 import planModel + 真接口）：
  `莘庄→五角场` 5 元 / 84 分 / 换乘步行 303 m；1号线#3aa0ff 11 站 via=9，换乘 303 m，10号线#22d3ee 13 站 via=11。
  `富锦路→滴水湖` 12 元 / 154 分 / 换乘步行 477 m（250+227）；1号线 via=14、2号线 via=6、16号线 via=11。
- **浏览器**（最终代码，`/nodes`）：5 行行程 = `1号线 富锦路→人民广场 16站` / `换乘 人民广场 250 m` / `2号线 …` / `换乘 龙阳路 227 m` / `16号线 …`；概况 `12 元 154 分钟 89.9 km 换乘 2 次 换乘步行合计 477 m`。点地铁行展开站序、点换乘行展开指令、再点收起、换起终点后展开态清空。

## 5. 仍未做

段落级相机定位（点分段 → 相机飞到该段并单独加亮）。当前整条路径仍是一次取景；要做需引入分段选中状态并操作相机，不影响现有数据结构。
