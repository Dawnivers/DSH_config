---
id: "588b214f-8e08-47d1-afc7-46dce0e3d0af"
title: "Dawnivers 个人站「高德地图的开发」详情页交付：4:3 近方截图管线、无图功能卡回退、高德 JSAPI 自动化不可用"
description: "第三张项目详情页（?id=amap）的实现与素材结论：沿 5f0698d1 字段契约、mediaAspect 用 4:3 承接手机近方截图、features 缺图时的深色渐变+虚线回退渲染、以及高德 JSAPI 在自动化启动的 Chrome 里 layers=0 的实测坑（四种启动参数均无效）。"
status: "active"
created_at: "2026-10-22T02:28:51.656Z"
updated_at: "2026-10-22T02:28:51.656Z"
content_hash: "95928fb8f57a2f424b43e60fe7d5b37dfd0264578c442d67c3427c8a733a8974"
source_paths:
  - "src/project-data.js"
  - "src/project.js"
  - "src/project.css"
  - "src/script.js"
  - "public/projects/amap/search.jpg"
  - "public/projects/amap/poi.jpg"
  - "public/projects/amap/route.jpg"
  - "public/projects/amap/overview.jpg"
session_ids:
  - "86af759a-3563-44ff-8d03-2d70aa1f71fd"
memory_body_ids:
  []
---

# 高德地图详情页（`?id=amap`）交付记录

承接 `5f0698d1-06fe-47fc-8382-060face9e80c`（详情页骨架、`project-data.js` 字段契约、`demo.mp4` 自动探测）、`aa89a18c-d8b3-40f6-a526-cb72194162eb`（community 定稿、`mediaAspect` 字段来源）、`a5560456-0f63-497f-b0b1-ba900c089823`（高德学习仓库通读）。
页面：`http://localhost:8091/project.html?id=amap`；在线 Demo：`https://project3.dawnivers.top/`（Express 托管 `dist/`，5173 归智慧地铁）。
本页是三张项目卡里的最后一张，此前它是「案例整理中」不可点，本次补 `id` 与正文后三张卡（metro / community / amap）全部可点。

## 1. 素材：手机/窗口近方形截图按 4:3 顶部对齐裁切

作者自己截的三张（搜索 / 兴趣点 / 路径规划）是近方形（708×638、1438×1279×2），16:9 卡片会把顶部输入框和列表第一行裁掉。做法：

- 统一裁成 **4:3 且顶部对齐**，JPEG 压到 82–167 KB，放 `public/projects/amap/`。
- 页面数据里写 `mediaAspect: '4 / 3'`（字段沿用 `aa89a18c`），卡片按 4:3 渲染；其它页不声明仍为 16:9。
- 首屏主视觉复用「兴趣点」那张（有红色标记 + 天气卡，信息密度最高）；城市底座那张用早先的 `prod-check` 图。

文件名：`overview.jpg`（首屏 + 功能 04）/ `search.jpg` / `poi.jpg` / `route.jpg`。

经验：近方形截图别硬塞 16:9；先看截图的「必须保留的顶部信息」再定裁切锚点（顶部对齐 > 居中）。

## 2. 新能力：功能卡可以没有截图

`src/project.js` 的 `features.map` 原来无条件 `<img src>`，缺图会留白或被迫复用别的图。现改为：`feature.image` 为空时渲染一块深色渐变 + 虚线路线示意占位，`data-zoom` 与序号角标照常。
本次四张图齐了没用上，但后续哪个功能来不及截图可以直接不写 `image`，不必伪造素材。原则：**没有就空着，不拿别的图凑**。

## 3. 正文口径

- 首屏标签：高德 JSAPI 2.0 / React 19 / Express / SQLite。
- 数字概览：4 个 POI 分类入口、JSAPI 2.0、3 个历史接口、0 个原生依赖（SQLite 走 Node 内置 `node:sqlite`，不装 better-sqlite3）。
- 项目目的三条主线：地图是主状态；安全密钥收服务端（`_AMapService` 绝对地址那个坑）；走过的地点留得住（`poi_id` 去重）。
- 技术栈四组：地图能力（AMapLoader / Geocoder / Weather / Driving / PlaceSearch）、前端（React 19 + Vite 8 + Tailwind 3.4 + antd 6）、服务端（Express 4 + `node:sqlite` + `/_AMapService` 代理）、部署（Nginx 静态 + /api 反代 3000 + 宝塔 + 域名白名单）。
- 四个功能卡与截图一一对应：搜索与输入提示、兴趣点分类检索、驾车路线规划、城市联动与地图底座。
- **待核实**：页面技术栈写的是 Express + SQLite 的部署版；`a5560456` 记录的本地 `gaode-study-React - 拆分组件` 是纯前端 + json-server mock。两处不一致时以部署版为准，但本地仓库通读结论不要直接搬进页面文案。

## 4. 已知坑：高德 JSAPI 在自动化启动的 Chrome 里起不来

想在自动化里截「历史记录 / 路线规划」时发现：任何由脚本启动的 Chrome（无头、离屏、可见窗口、去掉 `--enable-unsafe-swiftshader` 软渲染，四种启动参数都试过）里高德地图图层都建不起来，探针读到的 `layers = 0`，页面白屏/空白底图。
另有一条：桥接的受控输入对这版 React 输入框无效（发 Backspace / 键盘事件后「No visible changes」）；真实 `Ctrl+A` + `Delete` 也不可靠，且抢不到用户真实窗口焦点（前台锁）。

结论：**高德相关截图只能由作者本人在真实浏览器里截**，自动化那条路别浪费时间；同理，需要地图真正渲染的审版截图（首屏含地图）也只能用真实截图代替。最终审版仍走 `%TEMP%\page-shot\` 的无头 CDP（页面本身不依赖地图渲染，静态图片加载即可）。

## 5. 验证

`node --check` + `npm run build` 通过；`dist/projects/amap/` 四张图产出；实测首屏、项目目的、技术栈、四个功能卡（点图可全屏放大）、视频位、页脚 CTA 排版正常；首页三张卡分别指向 `project.html?id=metro|community|amap`。
上线仍是把 `dist/` 覆盖到站点根目录。
