---
id: "291a5cbc-d6cc-44ab-9c29-8ef3146927e7"
title: "MetroProject 公开发布：单仓库双子项目、.gitignore 边界与「三道校验 + 推后复扫」密钥验收流程（2026-10-22 实测）"
description: "智慧地铁项目首次上传 Dawnivers/MetroProject（public）的完整发布记录：一个仓库装前端 Translation + 后端 Translation_BE 的 .gitignore 边界取舍、git check-ignore/精确子串/正则三道独立密钥校验与浅克隆远端复扫、GCM 2.0.886 浏览器授权方式、提交作者 noreply 归属坑与新仓库 force push 改写，附遗留的安全建议。"
status: "active"
created_at: "2026-10-22T08:26:08.952Z"
updated_at: "2026-10-22T08:26:08.952Z"
content_hash: "885e38a23e311b5f8b95e27927a66551884c997749dda543937510accf04f8ae"
source_paths:
  - ".gitignore"
  - "README.md"
session_ids:
  - "15f24a73-24b3-4787-9bff-e2ef8d4d820b"
memory_body_ids:
  []
---

# MetroProject 公开发布与密钥验收（2026-10-22 实测）

项目根：`D:\WebGIS\web三维开发\智慧地铁项目`；仓库：`https://github.com/Dawnivers/MetroProject`（public，默认分支 `main`）。

## 1. 结论先行

源码审查后**无需改代码**：前后端本来就把密钥放在环境变量里，没有硬编码。真正的工作量在于

1. 用根级 `.gitignore` 把「不能进仓库的东西」焊死在门外；
2. 用**三道互相独立的校验**证明没漏（不能只看扫描脚本自己说 clean）；
3. 推送后**把远端克隆回来再扫一遍**，验证的是实际发布物而不是本地暂存区。

`VITE_` 前缀变量会被 Vite 内联进 `dist` 的 js，浏览器可直接读，所以前端没有秘密；需要保密的键（高德 Web 服务 Key、数据库密码）只放后端 `.env`。

## 2. 仓库形态与规模

- **一个仓库装两个子项目**：`Translation/`（Vue 3 + Vite + Cesium 前端）、`Translation_BE/`（Express + PostgreSQL 后端）。目录名沿用开发期历史命名，未重命名（改名会牵动 vite/后端启动路径与文档）。
- 首次提交 `0ed5364`，远端树 **525 个文件**，工作区（不含 `.git`）**49.7 MB**。
- 最大的已跟踪文件：`Translation/src/assets/trainAndChisa_static.glb` **23.56 MB**（未触及 GitHub 单文件 100 MB 硬限，因此没有引入 LFS）；其后是 `docs/screenshots/*.jpg` 约 0.3 MB、`line1to18_2.json` 0.29 MB。
- `docs/screenshots/` 放 README 界面预览图：从 `.review/` 的原始审图截图压到**宽 1600、JPEG q85**，只保留 4 张（线网总览 / 实时列车 / 重点活动 / 发展历程）。

## 3. `.gitignore` 边界（根级一份，两个子项目共用）

白名单式的 `.env` 规则：忽略 `.env` 与 `.env.*`，**只放行 `.env.example`**；另加 `*.local`（覆盖 `Translation/.env.local`）、`node_modules/`、`dist/`、`*.bak-*`。

体积/版权类排除项，每一项都有明确理由：

| 排除项 | 体量 | 理由 |
|---|---|---|
| `.review/` | 123 MB | 本地审图截图，非产品资产 |
| `综合项目：智慧地铁/` | 726 MB | 第三方参考工程，且**自带 `.git`**，纳入会变成嵌套仓库 |
| `参考资料/` | — | 课程资料，不宜公开 |
| `tmp-raw/`、`*.bak-*` | — | 临时产物 |

配套动作：README 里写清环境变量表、目录结构与启动步骤，让两个 `.env.example` 作为模板随仓库走。

## 4. 三道独立校验（推送前）

1. `git check-ignore -v` 逐条确认 `.env`、`.env.local`、`node_modules`、`dist`、参考工程都被规则命中——验证的是**规则真的生效**，而不是规则写在那里。
2. **精确子串比对**：拿真实密钥值（高德 key、PG 密码、ion token 的完整串）在已暂存文件内容里做子串搜索 → 0 命中。这一道防的是「正则扫不出的自定义格式」。
3. **正则扫描**：32 位 key、JWT、`ghp_` / `github_pat_`、`sk-`、私钥块、明文 `password=` 赋值。唯一命中是误报——`shmetroActivity.js:21` 里 `eastday.com` 新闻链接中的哈希段，属正常内容。

## 5. 推送后复扫（验证发布物）

浅克隆远端到临时目录后检查：

- 文件数 525、仓库体积 95.2 MB（含 `.git`）；
- `.env*` 只有 `Translation/.env.example` 与 `Translation_BE/.env.example` 两个模板；
- 敏感目录（`.review`、参考资料、第三方工程、tmp-raw）漏入数 **0**；
- 对克隆内容重跑同一套正则扫描（112 个文本文件，413 个二进制跳过）→ `CLEAN`；
- 顺手 curl 了 README 引用的截图与资源，均返回 200，确认公开仓库里图片能正常渲染。

> 经验：**只信「从远端拿回来的副本」**。本地扫描通过但 `.gitignore` 写错、或文件早已被 `git add` 过的情况，只有复扫远端才能暴露。

## 6. 两个踩过的坑

### 6.1 提交作者归属：gitee 的 noreply 邮箱在 GitHub 上认不出来

首次提交作者是 `dawnivers <16738257+dawnivers@user.noreply.gitee.com>`，GitHub 贡献图不会计入。改为 repo-local 配置：

```
Dawnivers <304228860+Dawnivers@users.noreply.github.com>
```

改完 `git commit --amend` + **force push**。因为这是刚建的仓库、只有自己一个提交、无协作者，force push 无风险；若仓库已公开一段时间或有人 fork/clone，则应保留历史而不是改写。

### 6.2 GCM 2.0.886 没有 `github login` 子命令

`git credential-manager github login` 在 2.0.x 不存在（2.4+ 才有）。可行路径：直接 `git push` 触发 GCM 的 GUI 授权窗 →「Sign in with your browser」→ 浏览器跳到 GitHub OAuth 授权页点 **Authorize**（scope `repo gist workflow`）→ 回跳 `http://localhost:<随机端口>/?code=…` 完成。

- 授权页与回跳 tab 的 DOM 往往被保护（只能 navigate/reload），不需要读页面内容即可完成流程。
- **token 全程不落进对话**，也不要让助手转述页面里的 code。
- 完成后 `git branch --set-upstream-to` 提示 `branch 'main' set up to track 'origin/main'` 即为成功标志。

## 7. 遗留建议（交给用户决定）

- 高德控制台给「Web 服务」类型 Key 加 **服务器 IP 白名单**；前端 `VITE_` 变量藏不住，后端 Key 只该被后端用。
- 这些密钥此前长期以明文躺在本地 `.env`（现在也没进仓库）。若文件曾以任何方式外传，建议整体轮换一次。
- 可选的下一步：补 `LICENSE`（如 MIT）、把项目挂到个人网站的项目列表。

## 8. 复用清单（发布下一个项目时照抄）

1. 先审源码看密钥是否已环境变量化，再决定是否需要改代码；
2. 根级 `.gitignore` 用白名单 `.env.example`，大体积/第三方/带 `.git` 的目录逐条列明理由；
3. 推送前跑三道校验：`check-ignore` 生效性、真实值精确子串、正则扫描（接受并解释误报）；
4. 推送后浅克隆复扫 + 抽查图片/链接可达性；
5. 确认提交作者邮箱能对上目标平台的 noreply 格式，必要时在新仓库阶段 amend + force push；
6. README 自带环境变量表与启动步骤，模板 `.env.example` 随仓库走。
