---
id: "1fb626c5-1a97-47e4-b7b7-b1ee2c9998a5"
title: "Dawnivers 个人站：素材投放路径规范（视频 / Docs）、地铁详情页 07-08 补充、联系卡 mailto 兜底"
description: "个人站素材投放规范（demo.mp4 与 public/docs/ 路径、构建语义）、智慧地铁详情页新增 07/08 卡与左侧锚点裁切经验、联系卡 mailto 静默失效的真因与复制/选中兜底实现。"
status: "active"
created_at: "2026-10-22T05:48:43.674Z"
updated_at: "2026-10-22T05:48:43.674Z"
content_hash: "91b5af3f4ca6ba1c8a2aea79105fde2ca13c9a5947fddaf5fc065617e555cf0b"
source_paths:
  - "src/project-data.js"
  - "src/script.js"
  - "src/style.css"
  - "index.html"
  - "public/projects/metro/heatmap.jpg"
  - "public/projects/metro/route.jpg"
  - "public/projects/amap/search.jpg"
  - "public/docs"
session_ids:
  - "e611b742-581d-49d0-b27c-a5cd575ac2cf"
memory_body_ids:
  []
---

# 素材投放、地铁页补充与联系卡兜底

承接 `5f0698d1-06fe-47fc-8382-060face9e80c`（详情页骨架、`project-data.js` 字段契约、`demo.mp4` 自动探测）、`aa89a18c-d8b3-40f6-a526-cb72194162eb`（`mediaAspect` 字段、真机截图管线）、`588b214f-8e08-47d1-afc7-46dce0e3d0af`（`?id=amap` 交付、4:3 裁切、无图功能卡回退）。本文只记这三篇没有的部分。

站点：`http://localhost:8091/`（Express 托管 `dist/`）；详情页 `project.html?id=metro|community|amap`。

## 1. 作者自己投放素材的两条路径（本次明确）

**操作视频** —— 按项目放，文件名固定 `demo.mp4`（`project-data.js` 里写的是 `autodetect`，放进去即自动从「VIDEO · COMING SOON」占位卡换成带控件的 `<video>`，不改代码）：

```
public/projects/metro/demo.mp4
public/projects/community/demo.mp4
public/projects/amap/demo.mp4
```

线上地址 `/projects/<id>/demo.mp4`。想用别的文件名或 CDN 直链，改该项目的 `video.src` 即可。

**文档 Docs** —— 统一一个目录（此前不存在，需自建）：

```
public/docs/fenceng-manual.pdf   ← 分层分户
public/docs/centos-deploy.pdf
public/docs/metro-manual.pdf
public/docs/amap-manual.pdf
```

线上 `/docs/xxx.pdf`（Vite 把 `public/` 原样搬到站点根）。然后改 `src/script.js` 里 `docs` 数组对应条目：`href` 从 `'#'` 改成真实路径，`download` 写访客保存时的文件名（建议带 `.pdf`），可选 `url` 做整卡跳转。**`href` 一旦不是 `#`/空，卡片上的灰色「整理中 · Soon」会自动变成蓝色「下载 · Download」**——这条是现成机制，不用另写逻辑。

**构建语义（易踩）**：素材必须放 `public/`，`npm run build` 才会复制进 `dist/`。直接把 mp4/PDF 丢到服务器的 `dist/projects/<id>/` 或 `dist/docs/` 能立刻生效，但下次构建会清空 `dist/`，文件就没了。

**命名与体积建议**：文件名用英文/数字（中文名容易被 URL 编码），中文名写进 `download` 字段给访客看；视频 720p / H.264 / faststart / ≤15 MB，文档 PDF 单个 ≤20 MB——理由是作者服务器带宽有限，详情页的意义就是别让访客卡在下载上。

## 2. 智慧地铁详情页补 07 / 08

原 06「站点查询与换乘」与新加的路径规划撞主题，拆成：

- 新增 `07 站点拥堵热力图`：按站点实时客流生成热力层，约 400 站同图比拥挤度（客流区间 52–994），配线路/站点开关定位到具体站。
- 新增 `08 换乘路径规划`：起终点直接出方案（爱辉路 → 安亭：8 元 / 108 分钟 / 55.3 km / 换乘 2 次；18→3→11 号线；分段给站数、时长、里程、站内步行 239 m / 268 m），路线在三维里同步高亮。
- 原 `06` 收窄为「站点查询与站控措施」：站点检索后的在线状态卡片 + 站控措施 / 三维测距。

八个功能卡现为：`01 总览 · 02 实时轨迹 · 03 站点光柱 · 04 建设历程 · 05 重点活动 · 06 站点查询 · 07 热力图 · 08 路径规划`。文案里的数字全部取自作者截图上的真实读数，不臆造。

**裁切经验（可复用）**：路径规划截图的「8 元 108 分钟 / 线路概览 / 分段明细」全在左侧面板，**必须左对齐裁 16:9**，居中裁会切掉一半；热力图那张居中裁 16:9。产出 `public/projects/metro/heatmap.jpg`（233 KB）、`route.jpg`（183 KB，均 1440×810）。

**遗留**：热力图截图中央压着系统弹窗「渲染环境正常 · RTX 4070 · 125 FPS」，看着像截图事故。两个选项已抛给作者（重截 / 收紧裁切范围牺牲底部面板），待其选择。

## 3. 联系卡：`mailto` 没坏，是系统没接住

作者反馈「邮箱 1651146928@qq.com 的链接有问题」。核查 `index.html` 与 `dist/index.html`，`href="mailto:1651146928@qq.com"` 本身正确。真实原因：**Windows 未配置默认邮件客户端时，`mailto:` 交给系统后无人接管，Chrome 静默无反应，看起来就像链接坏了**。诊断口径：先比对源码与 `dist` 的 href，再看系统默认程序，不要直接改地址。

修法（`index.html` + `src/script.js`，无新依赖）：

- 邮箱行右侧加「复制」按钮：`navigator.clipboard.writeText` → 失败回退 `execCommand('copy')` + 临时 textarea → 仍失败则**用 Range 选中邮箱文本**并提示「已选中邮箱，按 Ctrl+C 复制」，保证任何情况下都有反馈。
- 整张邮箱卡片可点（`data-mailto` 挂在卡片上，`cursor: pointer`），点击唤起客户端并提示「正在唤起邮件客户端…」；复制按钮在卡内，`stopPropagation` 防止冒泡触发 mailto。此前只有那行蓝字可点，点图标或留白没反应。
- 反馈用轻量 Toast：`#site-toast`（`src/style.css` 末尾），`opacity + translateY` 过渡，`.is-show` 切换，2 秒后淡出。

验证配方：`node --check src/script.js` + `npm run build`；探针读 `{hasBtn, btnText, mailto, toastShown, toastText}` 与 `{rowClickable, rowMailto, copyInsideRow, btnCursor}`；排版截图 `%TEMP%\page-shot\` 的 `contact.png` 确认三张联系卡（邮箱 / 微信 / GitHub）对齐未被撑坏。无头环境拿不到剪贴板权限，正好用来验证选中兜底分支。

**未做**：微信 `lxy1651146928` 与 GitHub `@Dawnivers` 仍是纯文本，未加复制按钮；也未改成点击跳 `https://mail.qq.com/` 网页写信（两个选项已抛给作者）。

## 4. 通用验证与上线

`node --check` + `npm run build`（约 200–300 ms）→ 打开 `http://localhost:8091/project.html?id=<key>` → `%TEMP%\page-shot\capture.mjs`（无头 Chrome + CDP）出图审版。上线照旧把整个 `dist/` 覆盖到站点根目录，`docs/`、`projects/` 会一起带上去。
