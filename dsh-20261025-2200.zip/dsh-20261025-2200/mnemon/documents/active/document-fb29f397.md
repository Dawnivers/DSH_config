---
id: "fb29f397-6178-4180-b862-80be1a1289db"
title: "智慧地铁：开屏闸门从「等瓦片」改为「功能优先」（实体/列车真正就绪才放行，城市模型降为后台）"
description: "记录开屏加载闸门的第二次重构：闸门只等线路数据、线路与站点实体真正画进 viewer、列车 glb 被 Cesium 解析成功三项；城市 tileset 与外滩场景降级为后台不挡门。含三处代码改法、失败可见化、两份工程同步与构建指纹，以及 PowerShell 插值破坏模板字符串的踩坑。"
status: "active"
created_at: "2026-10-21T12:57:43.596Z"
updated_at: "2026-10-21T12:57:43.596Z"
content_hash: "875ea6e095d5df8d2fd4b5ec57a4e679cd4da023e9ebb645e4f75c8bb7da6728"
source_paths:
  - "Translation/src/stores/loadingState.js"
  - "Translation/src/components/loading/SciFiLoader.vue"
  - "Translation/src/views/cesiumView.vue"
  - "Translation/src/components/screenUI/left1.vue"
  - "Translation/src/components/bottom/Toolbar.vue"
  - "src/views/cesiumView.vue"
session_ids:
  - "942037a2-8fdf-4ab3-b8d0-2b51fabd9b3d"
memory_body_ids:
  []
---

# 开屏闸门：功能优先（2026-10-21）

对象：`D:\WebGIS\web三维开发\智慧地铁项目\Translation`（dev，部署目标 `https://project2.dawnivers.top/`，服务器出口约 3 Mbps）与工作区 `D:\WebGIS\web三维开发\智慧地铁_上线版\Project`（两处代码需保持同步）。

前置文档：
- `cae9f685-f116-4336-b935-5efccac23ac0` —— 开屏加载复刻到工作区、`initialTilesLoaded` 只触发一次这一源码依据、「超时放行」的必要性；
- `55afe1e9-54f3-43e2-83f1-9f367614bad6` —— 本地版逐资源校验与加权进度；
- `9c15ce40-c2f9-4c44-afe6-ede26e6cb8d3` —— 列车 glb 23.55MB→8.62MB 压缩与带宽背景。

## 1. 用户报告的故障（触发点）

「即使你显示列车模型加载完成，超时进入项目点击线路轨迹仍然无法显示。」要求：开屏结束时线路实体、站点实体、气泡框等功能必须已经可用，城市模型可以留在后台慢慢加载。

根因不是超时放行本身，而是**闸门盯错了对象**：它判定的是「城市首屏瓦片加载完」，功能层（线路/站点/气泡/列车）从未被验证过；列车项也只做到「HTTP 下载完」，Cesium 还没解析几何与贴图，进项目自然看不到车。

## 2. 新闸门设计

| 资源 | 参与闸门 | 判定方式 |
|---|---|---|
| 线路基础数据 | ✅ 阻塞 | `left1.vue` 的 `/getLine` 成功并写入 `cesiumStore` |
| 线路与站点实体 | ✅ 阻塞 | Toolbar 的 `renderLineEntities` + `renderStationMarkers` **真的画进 viewer** 之后 |
| 列车模型 | ✅ 阻塞 | 下载完成 **且** Cesium `Model.fromGltf` 解析成功 |
| 城市三维模型 | ❌ 后台 | 只显示进度，不挡门 |
| 外滩场景 | ❌ 后台 | 同上 |

`loadingState.js` 新增 `blockingAssets`（前三项）与 `allSettled()`：

```js
allSettled() {
  return this.blockingAssets.every(a => a.status === 'ok' || a.status === 'fail');
}
```

城市瓦片多久都不影响放行，`finish()` 时进度补到 100%。清单里后台项带金色「后台」小标签，与必须等的三项视觉区分。

## 3. 三个关键改动

### ① 实体就绪不再靠「数据到了」

`components/bottom/Toolbar.vue`：

```js
const markEntitiesReady = () => {
  if (!viewer.value || !lines.value.length) return; // viewer 与数据缺一不可
  const stationCount = lines.value.reduce((n, l) => n + (l.stations?.length || 0), 0);
  loading.doneAsset('entities', `${lines.value.length} 条线 / ${stationCount} 站`);
};
```

在两个 watch（数据到 / viewer 到）里各调一次，谁后到都能补上。原设计只监听数据，`renderLineEntities` 可能因 viewer 未就绪而空转，于是「完成」是假的。

### ② 列车从「下载完」改成「解析完」

`views/cesiumView.vue`：fetch 流式读完后追加一次静默解析，只有解析成功才写「已解析」。

```js
await fetch(...)                                // 字节进度 + 完整性校验
const model = Cesium.Model.fromGltf({ url, show: false });
await model.readyPromise;                       // 真正解析几何 + 解码贴图
model.destroy();
```

解析失败降级成「已下载」并 `console.warn`，不阻塞场景。

### ③ 城市模型退出 `allSettled`

见上表；这是把「功能可用」与「画面完整」两件事解耦的核心。

## 4. 顺带修掉一个误导

`left1.vue` 原来 `/getLine` 失败被 `catch {}` 静默吞掉，面板留空但开屏仍报「加载完成」。现在显式：

```js
catch {
  loading.failAsset('data', '接口失败');
  loading.failAsset('entities', '跳过（无数据）');
}
```

这样「线路轨迹点不开」时一眼能分清是接口、实体还是模型的问题。

## 5. 同步与构建

- 本地 `Translation`：五个模块经 Vite 转换接口全部 200（`stores/loadingState.js`、`components/loading/SciFiLoader.vue`、`views/cesiumView.vue`、`components/screenUI/left1.vue`、`components/bottom/Toolbar.vue`）。
- 工作区 `Project`：`loadingState.js`、`SciFiLoader.vue`、`left1.vue`、`Toolbar.vue` 逐字节同步；`cesiumView.vue` 因两份 LOD/预载差异单独适配（工作区 `PRELOAD_TRAIN` 段落与 `Model.fromGltf` 用法不同）。
- 构建：`✓ built in 1.85s`；`compress-dist` 175 文件 8.05MB → gzip 2.64MB (33%) / brotli 2.10MB (26%)；入口 `index-BVZzi3wr.js` 523,456 B。

## 6. 踩坑：PowerShell 插值破坏模板字符串

用 PowerShell 批量改文件时，`` ` `` 包裹的模板字符串里的 `${...}` 被 shell 抢先插值，`Toolbar.vue` 写出成：

```js
loading.doneAsset('entities', ${lines.value.length} 条线 /  站);
```

于是 Vite 返回 500（`[vue/compiler-sfc] Unexpected token, expected "," (68:33)`），并弹出整页错误 HTML。教训：**改含 `${}` 的前端源码不要走 PowerShell 双引号字符串**，直接编辑或写成单引号 here-string；改完必须过一遍 Vite 转换接口 200 校验。

## 7. 验收口径

预期开屏 2~4 秒消失。刷新 `localhost:5173`（Ctrl+Shift+R）后立刻点「线路轨迹」。若仍异常，按三条线索定位：哪一行红/一直加载中；Console 有无 `[loading]` 开头 warn；接口是否 200 —— 三者已分别对应接口、实体、列车解析。
