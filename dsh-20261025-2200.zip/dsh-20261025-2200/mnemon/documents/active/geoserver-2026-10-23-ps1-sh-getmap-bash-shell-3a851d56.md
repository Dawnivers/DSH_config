---
id: "3a851d56-7d49-45cc-be1b-76552c1139a3"
title: "GeoServer 初始化脚本交付（2026-10-23）：幂等 ps1/sh 双版、预检与 GetMap 自检设计、实测矩阵与 bash 子 shell 坑"
description: "可复用的一键发布脚本落地记录：deploy/ 下 init-geoserver.ps1 与 init-geoserver.sh 的实际文件位置、三条设计原则（预检失败即停、GET 判存在后再建的幂等、GetMap>1KB 出图自检）及其理由、-Recreate 与 RECREATE=1 的行为、两平台 5 种模式全部实测通过的结果、换项目只改 WS/DS/TABLE 三值与 .env 集中地址、以及 bash 中 $(...) 子 shell 吞掉全局变量的排查与修法。"
status: "active"
created_at: "2026-10-23T11:13:45.792Z"
updated_at: "2026-10-23T11:13:45.792Z"
content_hash: "6147944c7dd289bf4b28eeffa0ee7c7c70d257fe179964e0ba40a3615ccb3742"
source_paths:
  []
session_ids:
  - "9753e34e-a674-4f46-8128-42570b2f5cff"
memory_body_ids:
  []
---

# GeoServer 初始化脚本交付（2026-10-23）

前情三篇必读：REST 调用与端口归属的实证 `be91eaef-f93d-4d77-803d-b34651d1dfd1`；`Spatial` 库与 `admin_area` 发布细节 `e2a4925e-c390-44f3-bd15-8bf165e70b28`；本机安装与起停 `e2e0d83d-62f3-4208-a3c8-fffc9439376f`。本文只记**这次真正交付出去的脚本本身**：它放在哪、为什么这么设计、怎么验证过、还有哪个 shell 坑值得记住。

## 1. 交付物

目录 `D:\WebGIS\web三维开发\gis-access\deploy\`（在工作区之外，故未登记为 source path）：

| 文件 | 平台 | 职责 |
|---|---|---|
| `init-geoserver.ps1` | Windows 本机 | 建 workspace / PostGIS store / 图层 + 出图自检 |
| `init-geoserver.sh` | Linux 服务器 / Git Bash | 同上的 bash 版，用 `$WS $DS $TABLE` 拼所有 URL |
| `.env.example` | — | 端口与地址模板（PG_HOST/PG_PORT/GEOSERVER_URL/API_URL） |
| `README.md` | — | 用法与排错 |

脚本只做链路第 4 步，**不含**建库与灌数据（`psql`+`ogr2ogr`，依赖具体数据源，写死会变脆），**也不含** SLD 样式上传（默认 `polygon` 灰色多边形只是能看）。完整六步链路的分段说明见 `be91eaef-…` 第 5 节。

凭据不写进脚本，走环境变量/参数（`PGPASSWORD` 或 `-DbPass`、`.env`），避免密码进版本库；XML 里密码含 `& < >` 仍需转义。

## 2. 三条设计原则及理由

1. **先预检，失败即停。** 第一条请求就是 `GET rest/about/version.json`，非 200 立即 `exit 1` 并打印三条排查方向。理由：不让脚本跑到第五步才报错——那时已经忘了问题出在哪一步。通用部署原则：先验证依赖，再执行业务。
2. **幂等：GET 判存在，存在则「复用」，不盲目重跑。** 而不是靠 `500 已存在` 接错误。删除重生仍用 `DELETE ...?recurse=true`（见 `be91eaef-…`），但只在 `-Recreate` / `RECREATE=1` 时走该分支。
3. **出图自检。** 最后发一次真正的 WMS `GetMap`，校验 `HTTP 200 且 > 1KB`。理由：REST 返回 201 与「这张图能画出来」是两个参考点，中间还隔着样式缺失、SRID 不匹配、bbox 为空。

## 3. 实测矩阵（全部实跑，非推断）

| 模式 | PowerShell | Git Bash |
|---|---|---|
| 首次创建 | 三对象全建，GetMap 200 / 55324 bytes | 同 |
| 幂等重跑 | 三个「已存在，复用」，仍 200 | 同 |
| 强制重建（`-Recreate` / `RECREATE=1`） | 递归删除后重建，仍 200 | 同 |

预检会顺带打印服务端版本（`GeoServer 2.28.5`），这比只报「已连接」有用：能立刻发现连的是不是同一个实例。

## 4. 换项目时改什么

只改三个值，URL 路径全部由它们拼出，不需要手改地址：

```bash
WS=demo DS=demo_db TABLE=poi
RECREATE=1 ./init-geoserver.sh
```

`.env` 里只定义一次 host/port，任何端口变化只改这一处——与项目里把 `VITE_API_BASE_URL` 抽出来的做法同源：**地址只在一处定义**。

## 5. 值得记住的 bash 坑：`$(...)` 会吞掉全局变量

第一版写成：

```bash
gs_code() {
  GS_BODY_FILE=$(mktemp)      # 想借全局变量把响应体带出去
  curl -s -o "$GS_BODY_FILE" -w '%{http_code}' "$@"
}
code=$(gs_code GET about/version.json)   # ← 病根
echo "$GS_BODY_FILE"                     # 空
```

现象很迷惑：`code=200` 是对的（stdout 被捕获），但 `GS_BODY_FILE` 为空，下一步 `cat ''` 失败，`set -euo pipefail` 直接退出，报错却指向「版本未知」。

**原因**：`$(...)` 开子 shell，函数里的赋值只作用于子 shell，父 shell 拿不到。

**修法**：不要用命令替换调用有副作用的函数，让函数直接写 `$GS_CODE` / `$GS_BODY_FILE`，之后直接读：

```bash
gs_call GET 'about/version.json'
echo "$GS_CODE"
```

同类推论：想同时拿「返回值」和「副作用」，就别用一条命令替换，要么改结构，要么把副作用落到文件再用普通命令读。

## 6. 端口语义的两个旁证（承接 `be91eaef-…`）

- `GS` 变量只是客户端地址，**不会**让服务端换端口；实测 `curl localhost:8090/geoserver/web/` → `000`，`8080` → `302`。服务端端口由 `D:\geoserver\etc\jetty-http.xml:37` 的 `default="8080"` 或启动参数 `-Djetty.http.port=8090` 决定。
- 比 `000` 更危险的是 **404**：当 8090 上已有别的服务（如 Spring Boot）时，`GS` 打错端口会「连得上但连错进程」，排错方向被彻底带偏。所以预检要判 200/302，而不是只看能不能连。

## 7. 排错提示

- Windows 上写 `.sh` 用 Git Bash（`C:\Program Files\Git\bin\bash.exe`，5.2.12）；先 `bash -n` 过语法再实跑，能省掉一轮 `set -e` 的哑火。
- Git Bash 里的 `curl` 解析到 `/mingw64/bin/curl`，与 PowerShell 的 `curl`（`Invoke-WebRequest` 别名）行为不同，排错时先确认用的是哪一个。
- 端口占用自查：`Get-NetTCPConnection -LocalPort 8080,8090,5173 -State Listen -ErrorAction SilentlyContinue`，无输出即可启动。
