---
id: "715e6684-4186-4c51-82f8-1db889099650"
title: "Translation 底栏齿轮工具箱：点击选中规则 + HUD 鼠标皮肤实现交接"
description: "用户改版的齿轮工具箱交互规则（齿轮 hover 开合 / 工具点击切换 / 选中态常驻）的状态推导实现、HUD 鼠标皮肤（默认开启、隐藏系统光标、ESC 兜底、经纬度读数）的实现细节与两个 Vue 过渡坑、Playwright 实测证据，并注明它取代了 fc4a4675 中的旧 hover 规则。"
status: "active"
created_at: "2026-10-07T13:08:41.478Z"
updated_at: "2026-10-07T13:08:41.478Z"
content_hash: "03e9e3d6d144131d8be4e4324d169a858c06b6a548d9f191af3bb9585f921c88"
source_paths:
  - "Translation/src/components/screenUI/foot.vue"
  - "Translation/src/stores/counter.js"
session_ids:
  - "803fe957-5504-471a-a827-56fe537a0a71"
memory_body_ids:
  []
---

# Translation 底栏齿轮工具箱：点击选中规则 + HUD 鼠标皮肤

实现日期：2026-10-07。**本文取代 `fc4a4675-20f3-47bd-9576-90465837c1b9` 第 3 节的旧 hover 规则**（那份文档记录的「图标划过 120ms 防抖展开、齿轮只挂 mouseenter 导致能开不能收」已作废，其架构决策（Teleport 到 `.hud-canvas`、坐标反算、设计令牌重声明）与 Vite watcher 修复仍然有效，请一并参考）。

相关文档：`fc4a4675-20f3-47bd-9576-90465837c1b9`（工具箱与线路栏架构、旧 hover 状态机、EBUSY 坑）、`d6dc91dd-bff2-4971-897a-5b2fe5bf1580`（项目启动与 `getLine` 接口语义）、`46077717-b034-4315-a3c1-f04be09fed52`（cesiumView KeepAlive 改造）。

## 1. 交互规则（用户 2026-10-07 明确指定，覆盖旧规则）

| 规则 | 实现方式 |
|---|---|
| **只有齿轮**用鼠标移入/移出开合工具栏 | `gearHover` 仅由齿轮（**及工具栏本身**）的 `mouseenter/mouseleave` 驱动；移开后 220ms 延迟收起，回到热区即 `cancelClose()` |
| **工具栏内的图标**用点击 / 再次点击开合对应栏目 | `onToolClick`：`activeTool = (activeTool === key ? null : key)`；旧的 hover 防抖（`TOOL_OPEN_DELAY = 120ms`）**已整段删除**，`onToolEnter/onToolLeave` 不再参与展开 |
| **只要有工具处于选中态，鼠标移出也不收** | 把「工具栏是否显示」从开关变量改为**推导值**：`gearOpen = computed(() => gearHover.value || activeTool.value !== null)` |

- 核心写在一个 computed 里，因此「再次点击取消选中后、若鼠标已不在热区，工具栏自动收起」是推导出来的副作用，**不需要额外代码**。
- 工具栏本身必须算进 hover 热区：齿轮与工具栏之间有空隙，否则鼠标走到一半就被收掉、图标根本点不到。
- 彻底收起入口：`Esc`（`onDocKeydown`）与点击空白处（`onDocMouseDown`，排除齿轮与 `.gear-tools, .line-layer-panel`）。
- 产品取舍（当时向用户明示、可一行改回）：取消选中后鼠标若仍停在工具栏上，工具栏不会立刻消失，方便接着点另一个工具；要「取消即整体消失」，在 `onToolClick` 里同时把 `gearHover.value = false`。

## 2. HUD 鼠标皮肤（「显示鼠标位置」工具）

默认开启：`mouseToolOn = ref(true)`。

- **隐藏系统光标**：给 `html` 加 `.hud-cursor-none`，规则 `cursor: none !important` 写在**非 scoped** 样式块里才全局生效。
- **皮肤渲染**：`.hud-cursor` 经 Teleport 到 `body`，`position: fixed` + `translate3d` 跟随；**rAF 节流**避免每个 mousemove 都重渲染；监听只在开启时挂载；指针移出浏览器窗口时皮肤先隐身，避免停在边缘。
- **视觉**（用户要求「与项目贴合、尽量酷炫」，金 + 青 + 切角 HUD 风格）：金色准星（十字 + 金色菱形核心 + 青色内点）、内外**反向对转**刻度环（内层青色虚线菱形 5.5s/圈，外层金色刻度环反向 9s/圈）、青色脉冲扩散圈、两块读数 chip（金色 `SCREEN X 800 Y 430`、青色 `GEO 121.5012°E 31.2391°N`）。
- **经纬度来源**：pinia `cesiumStore.viewer`（`Translation/src/stores/counter.js` 暴露的 `viewer` ref），用 `camera.pickEllipsoid(mousePos)` + `ellipsoid.cartesianToCartographic` 换算，**未额外 import cesium**；指针在地球外时显示「超出地球范围」。
- **关闭路径**：再次点击工具图标 → 恢复系统光标、皮肤下场，并浮出提示条「**鼠标已隐藏** `ESC` **按键重新显示鼠标**」（ESC 键徽章闪烁，**点浮窗本身也能恢复**）；`Esc` 是兜底恢复入口，开启后提示条立刻消失。
- 工具图标的 `is-active` 绑的是**开关状态** `mouseToolOn`，不是工具栏的选中态——开着就一直高亮。
- 待办/可维护点：皮肤尺寸、转速、色板目前全写在 CSS 里（未做成 props/常量），微调需翻样式块。

## 3. 两个 Vue 隐性行为（本次实际踩到）

1. **`<Transition>` 按元素自身的 animation 时长决定何时真正移除节点**：提示浮窗根元素挂了 `animation: hch-breathe 2.6s infinite`，离场被拖长到 2.6 秒，看起来像「关不掉」。把无限动画挪到 `::after` 伪元素即恢复正常（伪元素不参与这次计算）。
2. **用 `translateX(-50%)` 居中的元素，进出场过渡类必须原样带上该 transform**：通用过渡类里的 `transform` 会覆盖居中位移，浮窗出场时会横向跳一下；解法是给它单独写 `hint-pop` 过渡并保留 `translateX(-50%)`。

## 4. 验证证据（Playwright 真实鼠标 + 截图）

齿轮规则 8 项全过（`click-rules.mjs`）：划过齿轮 → 工具栏显示、未选中移开 → 收起、点击线路图标 → 工具栏 + 线路栏（18 条）+ 选中态 1、**选中后鼠标移到老远 → 工具栏与栏目仍在**、再次点击 → 取消（工具栏保留、栏目收起）、取消后移开 → 全收、`Esc` → 全收。

鼠标皮肤 4 项全过（`cursor-verify.mjs`）：默认开启（皮肤在 DOM 且可见、系统光标被隐藏、无提示、读数 `SCREEN 800,420 / GEO 121.5012°E 31.2391°N`）→ 点击关闭（皮肤隐藏、系统光标恢复、提示文案完整、图标不再高亮）→ `Esc` 恢复（皮肤回来、提示消失）→ 移动后经纬度跟随变化。控制台无报错。

编译校验方式：直接请求 Vite dev server 的组件产物（`foot.vue` HTTP 200，约 219–225 KB），并断言 `hud-cursor` / `hc-reticle` / `hud-cursor-hint` / `mouseToolOn` / `pickLngLat` / `hud-cursor-none` / `hch-key` 等标记出现在产物中。
