---
id: "6a2ebece-f1d0-4be5-bc4d-b3484073c688"
title: "Translation 智慧地铁：400 站点实拍图资产管线（Wikidata P18 + 坐标匹配下载 → stationImg → queryTemplate.vue glob 接入）"
description: "2026-10-11 为 400 个上海地铁站点抓取实拍图并接进详情浮窗的完整做法与实测坑：选源对比（Commons 关键词搜索假阳性 / 维基百科条目不可达 / 选定 Wikidata P18 + 坐标匹配）、SPARQL 批量取回的查询策略、缩略图 URL 与限流约束、import.meta.glob 相对路径静默零匹配的定位手法、许可署名义务、未覆盖的 8 站。组件样式侧见同目录 HUD 改造文档 9b55863a。"
status: "active"
created_at: "2026-10-11T11:49:36.070Z"
updated_at: "2026-10-11T11:49:36.070Z"
content_hash: "0daeef745d7a14305b2717ed8e6a496ee5873db81eec6af5ef0ebdacd64baae6"
source_paths:
  - "Translation/src/components/bottom/StationPanel/queryTemplate.vue"
  - "Translation/src/assets/stationImg/CREDITS.md"
  - "Translation/vite.config.js"
session_ids:
  - "b587eda8-8e67-4213-9e63-0b82eea15c94"
memory_body_ids:
  []
---

# 站点实拍图资产管线（站点图片 → 浮窗）

2026-10-11 完成。目标：点击上海地铁站点后的详情浮窗里显示该站实拍照片，而不是占位框。组件样式与尺寸侧（HUD 化、图片区 300×210、卡片换边）见关联文档 `9b55863a-1c10-4f00-baa0-479ddaed58ab`，本文只记**图片来源、下载管线与前端索引接入**。

## 1. 选源结论

| 方案 | 结果 |
|---|---|
| Commons 关键词模糊搜索 | 命中率高但**有假阳性**：搜「迪士尼」返回的是「白银路站（开往迪士尼方向）」的站台照 |
| 维基百科条目首图 | ❌ 本机 `zh.wikipedia.org` / `en.wikipedia.org` **超时不可达** |
| ✅ Wikidata `P18`（条目代表图）+ **坐标匹配** | 392/400，无假阳性，最终采用 |

关键设计：**用坐标匹配而不是名字匹配**。Wikidata 的中文标签可能是繁体（`南京東路站`），项目库里是简体（`南京东路`），按名字对不上；坐标是唯一的。坐标匹配把成功率拉到 397/400（99.3%）。

## 2. 管线与实测数字

```
SPARQL 一次取回：415 个车站条目 / 1552 行（按 18 条线路的 P81 反查，约 1 分钟）
坐标匹配成功：  397/400
其中条目有 P18： 392
匹配上但无图：   5    未匹配：3
下载成功：      392   失败 0   共 20.7 MB（平均 56 KB/张，500px 宽）
输出目录：Translation/src/assets/stationImg/  文件名即站名，如 东昌路.jpg
```

同目录另有 `CREDITS.md`（逐张列出作者/许可/Commons 来源）与 `manifest.json`（机器可读版）。

**⚠ 许可义务**：图片来自 Wikimedia Commons，多为 **CC BY-SA**（`AttributionRequired: true`）。项目内部使用无碍，**对外发布或商用前需按 `CREDITS.md` 逐一核对并保留署名**。

## 3. 外部接口的实测约束（会再次踩到）

- **逐站调 `wbsearchentities` 会被限流**：返回 `You are making too many requests`，400 个站 10 分钟只跑完 50 个，并发会加剧。正确做法是 SPARQL 批量取回。
- **必须用 API 返回的 `thumb.wikimedia.org` 直链**：`commons` 的 `Special:FilePath` 重定向链在本机一直 `fetch failed`。
- **不能手改缩略图宽度**：`iiurlwidth` 会被**向上吸附**到标准档位（请求 480→得 500px，请求 640→得 960px），手动改 URL 里的宽度段直接返回 400。
- **可达性**：`commons.wikimedia.org`、`www.wikidata.org`、`query.wikidata.org`(SPARQL)、`thumb.wikimedia.org`、`upload.wikimedia.org` 可达；`zh/en.wikipedia.org` 不可达。
- **SPARQL 里别用 `wdt:P131+`** 追城市，会 504 超时。
- 下载脚本设计成**跳过已存在的同名文件**，所以首轮失败项直接重跑即可补齐（首轮 376 成功/16 失败 → 重跑后 392 成功/0 失败）。

## 4. 前端接入（queryTemplate.vue）

图片区三级回退：

```
1. 具名插槽 <slot name="image">          ← popup.js 想传什么就传什么
2. 内置同名图 assets/stationImg/<站名>.jpg
3. 都没有 → 占位框（「暂无图片」+ 站名）
```

索引写法（`Translation/src/components/bottom/StationPanel/queryTemplate.vue`）：

```js
const stationImageModules = import.meta.glob(
  '../../../assets/stationImg/*.{jpg,jpeg,png,webp}',
  { eager: true, query: '?url', import: 'default' },
);
// 建成 Map：'../assets/stationImg/人民广场.jpg' -> '人民广场' → URL
// 查找：props.attr?.name || props.label
```

`?url` 是为了拿资源 URL 而不是把图片 base64 内联；eager glob 收的只是 400 个字符串 URL（几十 KB），不会额外下载图片。

## 5. 最大坑：相对路径写错 → glob 静默匹配 0 个文件

组件位于 `src/components/bottom/StationPanel/`，到 `src/assets/stationImg/` 需要**退三级**。

```js
// ❌ 错：静默匹配 0 个文件，不报错、不警告
import.meta.glob('../assets/stationImg/*.{jpg,...}')
// ✅ 对：
import.meta.glob('../../../assets/stationImg/*.{jpg,...}')
```

表现极具迷惑性：**图片明明在磁盘上（392 张齐了），浮窗仍然显示占位框，且浏览器网络面板 0 个图片请求失败**——第一反应会怀疑 Vite 缓存或目录监听。

**定位手法（值得复用）**：用 `fetch('http://localhost:5173/<模块路径>')` 取 dev server **转译后**的模块文本，直接看 `import.meta.glob` 的展开结果：

```js
const stationImageModules = /* #__PURE__ */ Object.assign({
  // ← 空对象 = glob 匹配到 0 个文件（而不是缓存问题）
});
```

证据链：磁盘文件已含新注释 `true`、dev server 服务出的模块含新注释 `true`（说明 HMR/重新转换确实生效，模块长度 54353），但展开条目数仍为 0；改成三级路径后**同一模块长度 54353 → 111741、展开条目 0 → 392**，无需重启 dev server（改文件即触发重新求值）。这条对照把「缓存问题」与「路径写错」严格区分开了。

另注：`Translation/vite.config.js` 的 `server.watch.ignored` 只排除 `**/.*.tmpdir/**`、`**/.*.tmp`、`**/*.tmp` 这类原子保存临时文件（防止 Windows 上 EBUSY 让 dev server 退出），与 `stationImg` 目录无关，排查时不要误指。

## 6. 浏览器实测（Playwright 探针）

```
点击站点「东昌路」：
  hasPhotoTag: true   photoSrc: /src/assets/stationImg/%E4%B8%9C%E6%98%8C%E8%B7%AF.jpg
  photoLoaded: true   naturalSize: 500x375
  placeholderShown: false   hasTint: true
  photoRendered: 258.3 × 180.3（媒体区 260×182）
图片请求失败 0   页面错误 0
```

断言口径：`naturalSize` 非 null 才算图片真的解码成功；仅 `hasPhotoTag` 为 true 不足以判定。

## 7. 未覆盖的 8 个站点

`上海财经大学`、`康桥`、`桃浦新村`、`江杨南路`、`虹桥2号航站楼`、`醉白池`、`鹤涛路`、`龙居路`（3 个在 Wikidata 没匹配到条目，5 个条目本身无 P18）。这几个站显示占位框。补图方式：查该站 Commons 分类，或直接按站名把图丢进 `stationImg/`。

## 8. 遗留项 / 交叉引用

- 详情卡贴近屏幕顶部时关闭按钮会落在 HUD 顶栏之下（本次实测 `closeHit: "DIV.hud-content-bar"`，正常位置应为 `BUTTON.qp-close`）——属于图层遮挡问题，已在关联文档 `9b55863a-1c10-4f00-baa0-479ddaed58ab` 的遗留项中记录，待用户决定是否把卡片提到 HUD 之上。
- 本机 PowerShell 解析含中文的命令会报 `字符串缺少终止符`，验证脚本一律放 `%TEMP%` 下用 node 跑；`.mjs` 里不能用 `require`，要写 `import`。
