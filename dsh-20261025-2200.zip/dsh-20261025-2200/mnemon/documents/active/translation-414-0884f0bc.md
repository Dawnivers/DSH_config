---
id: "0884f0bc-9c68-4869-9ae0-e74c4fa37fd6"
title: "Translation 热力图回退为「相机停稳后更新」（414 行版）与交叉淡入被否决的依据"
description: "2026-10-18：用户要求回退掉「滚轮实时/逐帧重绘」，恢复 camera.moveEnd + 220ms 防抖；记录 701→414 行的删减清单、保留的两条防闪必要条件（先加层等 readyPromise 与 ImageryState.READY 后一帧内切换再删旧层、半径恒定屏幕像素 70px）、以及「交叉淡入本身即闪因（半透明重影）」这一对前文的否定结论与仍待验证的 Entity+ImageMaterialProperty 备选。"
status: "active"
created_at: "2026-10-18T12:22:47.657Z"
updated_at: "2026-10-18T12:22:47.657Z"
content_hash: "3381077f75bd6048c0e5564fb9539c6aaa337fc51b76c488f317ba8e5c7e4dcf"
source_paths:
  - "Translation/src/components/bottom/StationPanel/QueryModePanel/heatmap/cesiumHeatMap.js"
  - "Translation/src/components/bottom/StationPanel/QueryModePanel/heatmap/useHeatmap.js"
  - "Translation/src/components/bottom/StationPanel/QueryModePanel/heatmap/heatSource.js"
  - "Translation/src/components/bottom/StationPanel/QueryModePanel/QueryModePanel.vue"
session_ids:
  - "627060e9-23e6-4aeb-bffe-ecb7035af511"
memory_body_ids:
  []
---

# 热力图回退：相机停稳后更新（414 行版）

日期：2026-10-18。项目 `D:\WebGIS\web三维开发\智慧地铁项目\Translation`，主文件
`src/components/bottom/StationPanel/QueryModePanel/heatmap/cesiumHeatMap.js`（701 → **414 行**）。

相关文档：
- `eeba367f-a6db-44b9-a14c-a185f6d329bd`：四步流水线原理（canvas → PNG → `SingleTileImageryProvider`）、bbox 决定清晰度、`destory` 拼写坑。
- `0ce9c65f-6c6b-48c8-872b-d98bc80502a1`：视口 LOD + 三段式半径（`moveEnd` + 220ms 防抖那一版）。
- `80e553d9-d671-4832-87c3-3757f03875f1`：`postRender` 逐帧 `watchCamera` + 双分辨率 + 交叉淡入（**本文推翻其淡入结论与逐帧方案**）。

## 1. 为什么回退

用户原话：「将功能回退到我命令滚轮实时更新之前，那时候的逻辑是相机稳定后再更新」。
动机是复杂度失控：701 行里真正的算法（canvas → PNG → 贴矩形）只有一百多行，其余都是「看不见屏幕时」为压制闪烁而叠加的保护逻辑——
`postRender` 逐帧 watcher、三层过滤、运动中/停稳双分辨率、总量守恒交叉淡入 + retiring 队列、`document.title` 调试埋点。
（另有一次 `readPixels` WebGL 像素回读探针，会打断 Cesium 帧回调并让后续埋点失效，也一并撤销。）

## 2. 回退前后对照

| 项 | 回退前 | 回退后 |
|---|---|---|
| 更新触发 | `scene.postRender` 逐帧 + 三层过滤 + 缩放停稳定时器 | `camera.moveEnd` + **220ms 防抖，一次** |
| 分辨率 | 运动中低清 / 停稳高清（双预算） | 单一预算 `AREA_REST = 1000×1000`（`AREA_MOVING` 必须与之相等） |
| 换层 | 总量守恒交叉淡入 + retiring 队列 | 就绪后**一帧内直接切换** |
| 调试埋点 | 逐帧统计写 `document.title` | 已删 |

## 3. 保留的两条（不是"实时更新"，是防闪的必要条件）

1. **先加后删，且必须等就绪**：新层 `alpha = 0` 先 `addImageryProvider` → 等 `provider.readyPromise`
   **且纹理 `state === Cesium.ImageryState.READY`**（`waitForLayer` 用 rAF 轮询，1s 超时兜底）→ 一帧内 `alpha = 1` 并删旧层。
   顺序反过来（先删再加）中间会有 1~2 帧没有热力层，那就是"闪"。
2. **半径恒定屏幕像素**：`RADIUS_SCREEN_PX = 70`。`getDataURL()` 是快照，贴图被线性拉伸到矩形，
   所以半径必须用屏幕像素语义，绝不能随视高在「屏幕下限」和「地面尺度」之间切换——
   跨段时相邻两张图半径差过大会被看成闪（曾实测 `dR = 216%`）。

其他仍在的常量：`VIEW_PAD = 1.18`（贴图比视野外扩）、`CANVAS_MAX_SIDE = 1400`、`MIN_RADIUS_PX = 2.5`、
`MIN_INTERVAL = 540`（重绘最小间隔）、`ZOOM_EPS = 0.03`。视野外站点不画；视野里无站点时贴**全透明图**而不是删层，避免图层增删带来的空窗。

## 4. 新增结论：交叉淡入本身就是"闪"的来源

上一版（`80e553d9`）用「总量守恒淡入」使合成 alpha 恒为 1，数学上不透明，
但**视觉上是同一团热力画了两遍**：旧图一个位置、新图另一个位置（两张覆盖矩形差一帧的相机位移），中间还夹着半透明。
连续缩放时每 170~540ms 触发一次，看起来就是"热力在抖/闪"。

因此把 `SWAP_FADE_MS` 设为 **0（就绪后一帧内直接换）**。
理由是半径恒定屏幕像素 ⇒ 相邻两张图在屏幕上几乎一致（只差清晰度与覆盖矩形），瞬切看不出变化；
而淡入淡出一定产生半透明重影。这一条否定了 `80e553d9` 的淡入方案。

## 5. 库坑（沿用，勿删注释）

- `heatmap.js-fixed@2.0.2` 的 `package.json` 写 `"main": "heatmap.min.js"`，但包里没有该文件，必须
  `import * as heatmapPkg from 'heatmap.js-fixed/build/heatmap.js'`，否则 Vite 报 Failed to resolve import。
- **不能用 `build/heatmap.min.js`**：压缩版 `_colorize` 里 `k.data = l` 给只读访问器 `ImageData.data` 整体赋值，
  ESM 严格模式抛 `TypeError: Cannot assign to read only property 'data'`，热力图直接画不出。未压缩版已改为逐字节写。

## 6. 当前行为与验证

- 滚轮/拖动中：热力图形不重画，只是被整体缩放（略糊）；松手约 0.22s 后按当前视野重画一张并一次性换掉。
- 换视野时只有"哪些站进了视野"在变；颜色标尺取**全量**数据 max/min，颜色不跳。
- 已验证：挂载正常（`400 站 · 客流 50–994`）、飞到站点（真实 `moveEnd`）后完成重绘且无报错、离屏 canvas 存在、两个模块编译 200。

## 7. 仍然开放的怀疑

如果还有闪，就只剩「增删影像层」这一个来源。备选方案：
把热力从**影像层**改为 **`Entity` + `ImageMaterialProperty`**，完全不碰 Cesium 影像集合。
改动面较大，应作为独立一步、在排除"重影"因素之后再单独验证。
