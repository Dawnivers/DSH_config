---
id: "be91eaef-f93d-4d77-803d-b34651d1dfd1"
title: "GeoServer 部署自动化：REST API 作为 UI 的终端等价物、脚本变量复用边界与端口归属（2026-10-23 实测）"
description: "把「UI 点出来的工作区/Store/图层」翻译成可脚本化的 REST 调用：三条 curl 的实测结果与幂等化写法、换名复用时哪些参数可换哪些必须同步（含数据源类型变化导致 XML 结构整体改变）、SLD 样式上传与六步完整链路、Docker Compose 生产部署要点（initdb.d 与服务名而非 localhost）、以及 GS 变量不改变服务端端口的实证（jetty-http.xml 的 default=8080 与 -Djetty.http.port 覆盖）。"
status: "active"
created_at: "2026-10-23T11:07:53.378Z"
updated_at: "2026-10-23T11:07:53.378Z"
content_hash: "bf69e915944e032205d7ecd994e747fecec38e2e6f57206b3543cba506e67fdf"
source_paths:
  - "gis-prep/wuhan-first.png"
  - "gis-prep/geoserver-first-map.png"
session_ids:
  - "22ecbb96-b1b5-46db-a4ea-86c5247f2edc"
memory_body_ids:
  []
---

# GeoServer 部署自动化（2026-10-23 实测）

前情与前置事实见三篇：本机安装与验真 `e2e0d83d-62f3-4208-a3c8-fffc9439376f`；`Spatial` 库与 `admin_area` 图层发布实录 `e2a4925e-c390-44f3-bd15-8bf165e70b28`；上层项目设计（端口约定 8090/8080/5173）`266aea70-7a25-4d94-8359-39555b8b651f`。

本文只记这次被问到的四件事：**UI 操作能否脚本化、脚本能不能换名字复用、端口到底谁说了算、真要上服务器怎么做**。

## 1. 核心认识：Web UI 只是 REST API 的外壳

页面上每一次点击，最终落地成两样东西：一次 `POST /geoserver/rest/...` 请求，以及 `data_dir` 里的一个 XML 文件。所以「终端怎么做同样的事」= curl + REST API。

读出来的真实配置极简，印证了这一点：

```xml
<!-- data_dir/workspaces/topp/workspace.xml -->
<workspace>
  <id>WorkspaceInfoImpl--570ae188:124761b8d78:-7ffd</id>
  <name>topp</name>
</workspace>
```

## 2. 三条 curl 替代 UI 六页（实测全 201）

```bash
GS=http://localhost:8080/geoserver
AUTH="admin:geoserver"          # 出厂账号未改；实际用 -u $AUTH

# ① 建工作区
curl -u $AUTH -X POST -H "Content-Type: text/xml" \
  -d "<workspace><name>wuhan</name></workspace>" $GS/rest/workspaces

# ② 建 PostGIS 数据源
curl -u $AUTH -X POST -H "Content-Type: text/xml" \
  -d '<dataStore><name>spatial_db</name><connectionParameters>
        <host>localhost</host><port>5432</port><database>Spatial</database>
        <schema>public</schema><user>postgres</user><passwd>***</passwd>
        <dbtype>postgis</dbtype></connectionParameters></dataStore>' \
  $GS/rest/workspaces/wuhan/datastores

# ③ 发布图层（表名必须是库里真实存在的）
curl -u $AUTH -X POST -H "Content-Type: text/xml" \
  -d "<featureType><name>admin_area</name></featureType>" \
  $GS/rest/workspaces/wuhan/datastores/spatial_db/featuretypes
```

实测结果：三步均 `HTTP 201`；图层元数据回到 `wuhan:admin_area`，默认样式 `polygon`；随后 WMS `GetMap` 返回 `HTTP 200`、66,387 bytes PNG（截图 `gis-prep/wuhan-first.png`）。

**验收仍要落在服务层**：预览页能显示 ≠ 服务可被调用，必须另用 `GetMap` 验一次（与安装时「端口通不算装好」同一思路）。

## 3. 幂等化：运维脚本的基本要求

直接重跑会 `500 已存在`。标准做法是先递归删后建：

```bash
curl -u $AUTH -X DELETE "$GS/rest/workspaces/wuhan?recurse=true"
```

`recurse=true` 会把图层、数据源、工作区一起清掉。跑一次和跑十次结果一致，才叫幂等。

## 4. 「换个变量名就能复用吗」——一半对

**可直接替换的 8 个参数**：工作区名、数据源名、表名、host、port、database、user/passwd、`admin:geoserver`、URL 前缀 `localhost:8080`。前提是这些名字在 **XML 的 `<name>` 与 URL 路径里同时出现**，所以要用 `$WS` `$DS` `$TABLE` 变量，不要手改。

**必须同步、最容易出错的六处**：

1. **XML 里的名 与 URL 路径必须一致** —— 只改一处 → 404。
2. **数据库名大小写** —— `Spatial` ≠ `spatial`，这台机器已为此卡过一次。
3. **密码里的 XML 特殊字符** —— `& < >` 必须转成 `&amp; &lt; &gt;`，否则报一个和密码毫无关系的解析错。
4. **表名必须是库中真实存在的** —— `admin_area` 写成 `adminArea` 会 404，GeoServer 是拿这个名字回库查的。
5. **数据源类型一换，整个 XML 结构就变** —— 这是「换名复用」真正的边界：

   ```xml
   <!-- PostGIS -->
   <connectionParameters><host/><port/><database/><schema/><user/><passwd/><dbtype>postgis</dbtype></connectionParameters>
   <!-- Shapefile：完全不同的键 -->
   <connectionParameters><url>file:data/shapefiles/wuhan/admin_area.shp</url><charset>UTF-8</charset><create spatial index>true</create></connectionParameters>
   ```
6. **协议与端口** —— 上 HTTPS 或改端口后所有 URL 前缀跟着变，所以一开始就把 `GS=` 抽成变量。

结论：**换名可复用，仅当始终用 PostGIS**；换类型、漏改 URL、密码带特殊字符、跨大版本都不行。

## 5. 完整链路是六步，这三条 curl 只是第 4 步

```
1. CREATE DATABASE + CREATE EXTENSION postgis   ← psql
2. ogr2ogr 灌数据                                ← ogr2ogr
3. 启动 GeoServer                                ← startup.sh / 启动GeoServer.vbs
4. workspace / store / layer                     ← 本文三条 curl
5. 配样式（默认是灰色 polygon）                   ← 另一套 REST
6. GetMap 验 200                                 ← curl
```

第 5 步本次没做，所以图层是默认灰色填充。要分级设色就上传 SLD：

```bash
curl -u $AUTH -X PUT -H "Content-Type: application/vnd.ogc.sld+xml" \
  --data-binary @wuhan_style.sld $GS/rest/workspaces/$WS/styles/wuhan_style
```

**版本提醒**：这套 XML 是 2.28.5 的格式。GeoServer 3.0 基于 Spring Boot 重构，REST 大体兼容但细节可能变；大版本升级前脚本先在测试环境跑一遍。

## 6. `GS=localhost:8090` 不会让服务搬到 8090（实测）

```
curl :8090/geoserver/web/  → HTTP 000（端口空着，netstat 无监听）
curl :8080/geoserver/web/  → HTTP 302（真实服务）
```

`GS=` 只决定 curl 去哪儿找服务，是**客户端寻址**；端口由**服务进程启动时自己占用**。真正决定端口的是：

```xml
<!-- D:\geoserver\etc\jetty-http.xml:37 -->
<Set name="port">
  <Property name="jetty.http.port" deprecated="jetty.port" default="8080" />
</Set>
```

改法二选一：

- **A（推荐，不动原始配置）**：在 `D:\geoserver\start-geoserver.bat` 的 java 命令里加 `-Djetty.http.port=8090`，保留其余 `-DGEOSERVER_DATA_DIR` / `-DSTOP.PORT=8079` / `-DSTOP.KEY` 参数。
- **B**：直接改 `etc\jetty-http.xml` 的 `default="8080"` → `"8090"`。

改完必须重启，且 `netstat -ano | findstr :8090` 查到监听才算真的换了。

**易混来源**：Spring Boot 的 `server.port` 是真配置（自己的程序读自己的配置）；GeoServer 是别人的程序，看不见你 shell 里的变量。

**建议不改**：本机 8080 空着，Spring Boot 规划用 8090 刚好错开；一旦改 8090，既有脚本、书签、OpenLayers 代理配置全要跟着改——让 Spring Boot 换端口更省事。部署脚本里通常写 `GS=${GEOSERVER_URL:-http://localhost:8080/geoserver}`。

## 7. 真上服务器的标准做法：Docker Compose

```yaml
services:
  postgis:
    image: postgis/postgis:17-3.5
    environment: { POSTGRES_DB: Spatial, POSTGRES_USER: postgres, POSTGRES_PASSWORD: ${PG_PASSWORD} }
    volumes:
      - pgdata:/var/lib/postgresql/data
      - ./sql:/docker-entrypoint-initdb.d   # 首次启动自动执行 .sql
    ports: ["5432:5432"]
  geoserver:
    image: docker.osgeo.org/geoserver:2.28.5
    environment: { GEOSERVER_ADMIN_USER: admin, GEOSERVER_ADMIN_PASSWORD: ${GS_PASSWORD} }
    volumes: [ "./data_dir:/opt/geoserver_data" ]   # 配置持久化，重建容器不丢
    ports: ["8080:8080"]
    depends_on: [postgis]
volumes: { pgdata: }
```

两个关键点：

- **`docker-entrypoint-initdb.d`**：把 `01_postgis.sql` 丢进去 = 「数据库初始化」的终端标准答案。
- **GeoServer 连库必须写服务名 `postgis`，不能写 `localhost`** —— 容器内 localhost 指向容器自己，新手第一个坑。

## 8. 四种部署方式怎么选

| 方式 | 适用 | 代价 |
|---|---|---|
| Web UI | 学习、调样式、临时改 | 不可重复，换机器得重来 |
| REST + curl | 初始化脚本、CI/CD | 要写脚本，但可版本控制 |
| 打包 `data_dir` | 迁移、备份、多环境一致 | 不能跨大版本（2.28 的配置 3.0 读不了） |
| Docker Compose | 生产 | 要学 Docker，但环境完全可复现 |

实际项目是组合：容器跑 GeoServer，`data_dir` 挂进去（内含脚本初始化好的配置），数据库由 SQL 脚本初始化。

**附带的可利用事实**：`data_dir` 里每个配置都是纯文本（`workspaces/<ws>/workspace.xml`、`.../<store>/datastore.xml`、`.../<store>/<layer>/featuretype.xml`、`styles/`），因此可以整个进 Git —— 配置即代码，"我的 GeoServer 配置和你不一样"这类问题随之消失。
