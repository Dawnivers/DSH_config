---
id: "b99453f3-413a-43cb-aa85-3209bde4bde4"
title: "站点光锥「科幻脉冲」改造落地（cone.glsl 三层叠加 / flat:true 消除受光 / getRenderState 覆盖会丢 cull）+ GLSL 真机编译校验手法"
description: "选型拍板后的实施交接：cone.glsl 重写为底座+流动带+呼吸三层（秒级时间基准），setcone.js 加 flat:true 与 ADDITIVE_BLEND 实例覆盖（含必须显式写回 cull:BACK 的坑），Toolbar.vue STATION_CONF 拆普通站/换乘站双参数表；并纠正前序文档两条错误结论（TEXTURED 实为 POSITION_NORMAL_AND_ST、plastic 感源于 flat 默认 false 走 czm_phong），附构建/着色器编译/实机三档验证结果与调参入口。"
status: "active"
created_at: "2026-10-20T01:29:22.856Z"
updated_at: "2026-10-20T01:29:22.856Z"
content_hash: "dc780e638a50ed240e693082c42ef9f05e24df52b3b2962a56236694a14d07d4"
source_paths:
  - "Translation/src/cesiumTools/lineAndpoints/points/circleAndcone/cone.glsl"
  - "Translation/src/cesiumTools/lineAndpoints/points/circleAndcone/setcone.js"
  - "Translation/src/cesiumTools/lineAndpoints/points/circleAndcone/lightcolumn.glsl"
  - "Translation/src/components/bottom/Toolbar.vue"
  - "Translation/src/cesiumTools/lineAndpoints/points/setpoints.js"
  - "Translation/node_modules/cesium/Source/Scene/MaterialAppearance.js"
  - "Translation/node_modules/cesium/Source/Scene/Appearance.js"
  - "Translation/node_modules/cesium/Source/Scene/Primitive.js"
  - "Translation/node_modules/cesium/Source/Scene/RenderState.js"
  - "Translation/node_modules/cesium/Source/Shaders/Appearances/TexturedMaterialAppearanceFS.glsl"
session_ids:
  - "51d29740-5908-4fc3-86ce-230f11bb938e"
memory_body_ids:
  []
---

# 站点光锥「科幻脉冲」改造落地

前序文档 [0c3bdc53](documents/active/cone-glsl-st-0c3bdc53.md) 停在「方案 + 待拍板」，本文记录**拍板后的实际实施**、验证结果，以及两处必须纠正的技术结论。

拍板内容：走 ①②③（加色混合 + 连续呼吸 + 竖向流动带），气质取**科幻脉冲型**；换乘站单独做更「躁」的一档。

## 1. 改动范围（3 个文件）

| 文件 | 改法 |
|---|---|
| `Translation/src/cesiumTools/lineAndpoints/points/circleAndcone/cone.glsl` | 重写，46 → 96 行，纯注释 + 三层叠加 |
| `Translation/src/cesiumTools/lineAndpoints/points/circleAndcone/setcone.js` | `flat: true`、实例覆盖 `getRenderState`、uniform 改名 |
| `Translation/src/components/bottom/Toolbar.vue` | `STATION_CONF` 拆成普通站 / 换乘站两套 |

## 2. cone.glsl：三层叠加

高度来自几何副产品 `dis = length(st - 0.5)`（见前序文档的 `st` 语义分析），本文件里转成 `h`（0=锥底，1=锥尖）：

| 层 | 做法 | 观感意图 |
|---|---|---|
| 底座 `ground` | `pow(1.0 - h, 1.8)` | 光源在脚下，而不是整根均匀发亮 |
| 能量带 `pulse` | `fract(h * bandCount - t * flowSpeed)` 作相位，`pow(sin(phase*π), 6.0)` 收口 | 亮带自下而上跑；`fract` 回卷处恰好 `sin(0)=sin(π)=0`，**天然无缝**，不需要额外接缝处理 |
| 呼吸 `breathe` | `0.86 + 0.14 * sin(2π * 0.42 * beatSpeed * t)` | 慢节拍、小幅度，只做「是活的」的暗示 |

最终色大致是 `ground*0.28 + pulse*0.52` 的叠加再乘呼吸因子——两个系数就是整体亮度旋钮。

**时间基准必须改**：旧版 `czm_frameNumber / 10.0` 是帧驱动（60 FPS 下 12 Hz 方波，刺眼且随帧率漂移）；现在改 `/ 60.0` 得到**秒**，与同目录 [lightcolumn.glsl:29](Translation/src/cesiumTools/lineAndpoints/points/circleAndcone/lightcolumn.glsl#L29) 的写法对齐。改完实际节奏：0.42 Hz 呼吸 + 约 1.8 s 一根流光。

## 3. setcone.js：`flat: true` 才是「塑料锥」的真正解药

这是本次最重要的发现，也是推翻前序判断的地方。

`MaterialAppearance` 的 `flat` **默认 `false`**（[MaterialAppearance.js:101](Translation/node_modules/cesium/Source/Scene/MaterialAppearance.js#L101)）。`flat=false` 时片元走的是：

```glsl
gl_FragColor = czm_phong(normalize(positionToEyeEC), material, czm_lightDirectionEC);  // TexturedMaterialAppearanceFS.glsl
```

也就是说旧光锥**一直在被太阳光照射**：锥面法线朝外，一圈被明暗切成亮面/暗面，这就是「塑料锥 / 半透明贴纸」感的最大来源——比混合模式的影响还大。改成 `flat: true` 后走 `vec4(material.diffuse + material.emission, material.alpha)`，纯自发光，法线不再参与着色。

### 加色混合的正确接法 + 一个连带的坑

[Appearance.js:164-172](Translation/node_modules/cesium/Source/Scene/Appearance.js#L164)：只要 `translucent: true`，就**强制**改 `depthMask = false` 且 `blending = ALPHA_BLEND`，构造时传 `renderState` 无效。所以只能盖实例方法：

```js
appearance.getRenderState = () => ({
  depthTest: { enabled: true },
  depthMask: false,
  blending: Cesium.BlendingState.ADDITIVE_BLEND,
  cull: { enabled: true, face: Cesium.CullFace.BACK },   // ← 必须显式写回
});
```

**新坑**：一旦盖掉 `getRenderState`，`Appearance` 原本那套默认 renderState（含 `cull`）就一并丢了。`Primitive` 只拿这个返回值去 `RenderState.fromCache`（[Primitive.js:1713](Translation/node_modules/cesium/Source/Scene/Primitive.js#L1713)），不会补默认值，所以背面剔除默认消失——不写 `cull` 不会报错，只是每个锥子片元量翻倍。想让锥更像「实心光柱」可以把这行删掉，代价即此。

uniform 同时改名：`flickerSpeed` → `flowSpeed / bandCount / beatSpeed / energy`（旧名已名不副实），两个调用点均已同步。

## 4. Toolbar.vue：普通站 / 换乘站双参数

| 参数 | 普通站 | 换乘站 | 说明 |
|---|---|---|---|
| height | 500 | 650 | 更高 |
| 底半径 | 70 | 90 | 更粗 |
| flowSpeed | 0.55（1.8 s 走完一根） | 0.95（1.05 s，快 1.7×） | 越大越快 |
| bandCount | 1 | 2 | 双带追赶 |
| beatSpeed | 1.0（呼吸 2.4 s） | 1.6（1.5 s） | 呼吸更快 |
| energy | 1.0 | 1.5 | 整体更亮 |

换乘站的「躁」= 更快 + 双带 + 更亮三者叠加，单靠亮度会在 400 站里糊掉。

## 5. 验证（三档，逐档收紧）

1. **构建**：`vite build` ✓ 1.55 s，无报错；顺带 `compress-dist` 174 文件 8.04MB → gzip 2.64MB。
2. **GLSL 真机编译**：临时建 `__shadercheck.html`，用 `?raw` 把 `cone.glsl` 原文导入，塞进真实 WebGL 编译，只补 Cesium 注入的 `czm_material` / `czm_frameNumber` 等 → `vertex: OK` / `fragment: OK` / `program: built`，`MAX_VERTEX_TEXTURE_IMAGE_UNITS = 16`。**验完即删**，不要留在仓库。
3. **整机 App**：起 dev server，真实页面加载 18 条线、807.3 km，`.cesium-widget-errorPanel` 无匹配、站点标签 DOM 存在（如「凌兆新村」）→ `renderStation` 与材质管线都活着。

### 一个不要再踩的验证陷阱

试过用临时页 `__conecheck.html` 直接把整个 Cesium 场景搬进去跑，结果满屏

> RuntimeError: Vertex texture fetch support is required to render primitives with per-instance attributes. The maximum number of vertex texture image units must be greater than zero.

**这不是本次改动引入的 bug**，是那个临时页面的 WebGL 上下文/环境能力不足（同一进程里 `__shadercheck.html` 自建上下文报告的却是 16 个单元）。该 RuntimeError 在 Cesium 里只由 `Primitive` 的 batchTable、`PolylineCollection` 等几处抛出（[Primitive.js:2148](Translation/node_modules/cesium/Source/Scene/Primitive.js#L2148)）。结论：**整场景级验证必须在真实 App 页面做，别起临时整场景页**；临时页只用来隔离编译单个着色器。

## 6. 调参入口

| 想改什么 | 改哪里 |
|---|---|
| 流光快慢 | `Toolbar.vue` 的 `flowSpeed`（越小越慢） |
| 亮带宽窄/锐利 | `cone.glsl` 里 `pow(sin(phase*π), 6.0)` 的指数，调大更细更锐 |
| 整体亮度 | `STATION_CONF.opacity`，或 shader 里 `ground*0.28 + pulse*0.52` |
| 呼吸幅度 | `0.86 + 0.14 * ...` 里的 0.14 |
| 换乘站更躁 | `transfer.energy`（1.5 已很扎眼，2.0 接近纯白） |

## 7. 未闭环

- **观感未被人工确认**。本环境无法截图，「好不好看」只能给参数，需用户自己开 http://localhost:5173/ 看。
- 三个待观察点：流速（1.8 s 一根可能偏快）、换乘站双带是否太吵、**加色混合下同色线路并排的站是否会糊成一片**（加色叠加无上限，密集处会朝白色累积）——这是 ④ 地面光圈同步动起来之前必须先确认的。
- dev server 当时以后台 job `pwsh-40` 留在跑，未关。

## 8. 对前序文档的两处纠正

1. `MaterialSupport.TEXTURED.vertexFormat` 是 **`POSITION_NORMAL_AND_ST`，是带法线的**（[MaterialAppearance.js:316](Translation/node_modules/cesium/Source/Scene/MaterialAppearance.js#L316)）。前序文档说「TEXTURED 不带法线、要边缘光必须换 ALL」是错的，fresnel 边缘光用现有配置就能做。
2. 「塑料感」的主因不是混合模式单一因素：`flat` 默认 `false` 导致走 `czm_phong` 受太阳照射，是更前置的原因。加色混合只在解决了受光问题之后才见效。
