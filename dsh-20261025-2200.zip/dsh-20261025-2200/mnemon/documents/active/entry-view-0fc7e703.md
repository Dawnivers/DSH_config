---
id: "0fc7e703-b0e7-4610-999f-c040d0d0bab8"
title: "发展历程收尾：固定入场视角 ENTRY_VIEW、连续进度条、关掉流线（附「读用户浏览器相机参数」的探针技巧）"
description: "2026-10-12 发展历程收尾三项：固定入场视角 ENTRY_VIEW（用户否掉按线路取景）、进度条由类切换改为 --progress 连续填充条、生长线用 flowLength:0 关流线并补 glowPower/taperPower；另记录「用临时 DOM 探针 + 浏览器桥读用户页面相机参数」这一可复用技巧及其四个坑，以及像素级 A/B 在本场景失效的原因。"
status: "active"
created_at: "2026-10-12T11:24:46.193Z"
updated_at: "2026-10-12T11:24:46.193Z"
content_hash: "ef560af300ecd665335688cd8e05267a8eca3afa3f95dd660a4816c937373ab5"
source_paths:
  - "Translation/src/components/bottom/HistoryPanel/historyPanel.vue"
session_ids:
  - "session-d6cbf69c-ac7f-4b6b-a2a9-8468919b087a"
memory_body_ids:
  []
---

# 发展历程收尾：固定入场视角、连续进度条、关掉生长线的流线

日期：2026-10-12。承接 `bed0b7b7`（生长动画实现）、`34066e27`（面板外壳 + 数据集）、`507aed4a`（区间模型）。
只记这一轮新增的东西。

## 1. 固定入场视角（用户明确纠正：**不是**按线路取景）

用户原话：「**不是按线路跳转，而是记下我现在的相机参数，如果切换到这个路由，就飞到这个视角**」。

我第一版做成了「按当前线路的包围球取景」——被否掉了，因为换线路时相机会跟着动。
现在是一个常量：

```js
const ENTRY_VIEW = { lon, lat, height, heading, pitch, roll, duration };
```

- 只在**从别的路由切进 /strategy** 时 `camera.flyTo` 一次；
- 换线路时相机**纹丝不动**（实测切到 18 号线后六个值一字不变）；
- `setupGrowth()` 在换线路时也会跑，所以用一个 `entryViewApplied` 标志位兜住，只飞一次；
- `ENTRY_VIEW = null` 表示完全不干预相机。

实测：首页 `121.4582 / 31.2705 / 4822 / 131.2 / -45.35`（即 sceneManager 的 DEFAULT_VIEW）
→ 进入发展历程后 `121.3584 / 31.13 / 130 699 / -1.08 / -83.58`，与配置**完全一致**。

## 2. 可复用技巧：怎么拿到**用户浏览器里**的相机参数

浏览器桥（browser_* 那套）**没有 JS eval**，读不到页面里的 `__cesiumViewer`。做法是往页面里塞一个
**临时探针**：每 400ms 把 `camera.positionCartographic` + heading/pitch/roll 写进一个 DOM 元素，
再用 `browser_get_text` 从用户那个标签页里读出来。

四个坑：

1. **探针要放在面板内部**。`.history-panel` 有 `clip-path`，放到面板外面（负 top）会被裁掉。
2. **探针必须 `position: absolute`**。面板是 `display:flex`，普通 div 会变成 flex 子项、把三段布局挤坏。
3. **探针别加在根组件上**。改 `App.vue` 会触发整页 reload → **相机被重置**，等于把要取的值弄丢了。
   加在非根组件（`historyPanel.vue`）里，Vite 只热替换该组件，相机不动。
4. **连续快速改文件会把用户的标签页 HMR 刷坏**（表现：整个面板不渲染、路由层空白，
   但同一份代码在干净页面里完全正常）。刷新即可恢复，但刷新又会重置相机。

本轮最后实际是从用户发来的一张**截图**里直接读出了探针那行 JSON，没有走文本读取。
探针用完必须删干净：脚本块、模板节点、CSS、以及为了它才加的 `onMounted` import，**四处都要清**。

## 3. 进度条：间断跳变 → 实时连续

原来靠每个节点的 `is-done` / `is-current` 类上色，只能一段一段跳。现在：

```html
<ul class="hp-marks" :style="{ '--n': history.length, '--progress': progress }">
  <span class="hp-track-fill"></span>
```

```css
.hp-track-fill {
  position: absolute; z-index: 2; top: 5px; height: 2px;
  left: calc(50% / var(--n));                                  /* 对齐第一个圆点圆心 */
  width: calc((100% - 100% / var(--n)) * var(--progress));
  background: var(--line-color);
}
```

- `progress = currentTime / max`，每帧更新，再加 `transition: width .08s linear`（低帧率下也不顿）。
- 推导：每个节点占 `1/n` 且圆点居中 → 第一个圆点圆心在 `50%/n`、最后一个在 `100% - 50%/n`；
  而 `progress = seg/(n-1)`，第 i 个圆点在 `i/(n-1)` 处 —— **两者在段边界上正好重合**。
- 节点自带的半段连线**退化成纯灰底轨**，只负责给出精确对齐，不再上色（否则会和连续条打架、又变回跳变）。
- z-index：灰轨道 auto < 填充条 2 < 圆点 3。
- **「段头翻」保留**：`currentIndex = floor(currentTime / 10)` 只管文案，按段跳；只有条是连续的。

实测：采样 14 次 → **14 个不同宽度**（连续）；左端 `833.14` == 首个圆点圆心 `833.14`；
播完右端 `1418.23` == 末个圆点圆心 `1418.23`（误差 0）。

## 4. 生长线关掉流线 + 补回亮度

**起因**：用户看到生长线带着「原先的道路流线特效」，怀疑旧线没藏干净。
实测澄清：18 条全局线路 `show` 全为 `false`、可见的只有那条私有实体（`CallbackProperty`），
**流线是新线自己的** —— 因为 `setlines.js` 的 `renderLines()` 把材质写死成
`PolylineFlowMaterialProperty`，用它就必然带流线。

**必须用 `flowLength: 0`，不能用 `flowIntensity: 0`**：`polyGlowflow.glsl` 里那一支是
`material.emission *= flowIntensity`，乘 0 会把发光清零而 alpha 反被拉满 → 线上跑一条**黑带**；
`flowLength: 0` 让条件 `st.s > iTime && st.s < iTime` 恒不成立，整支不执行，才是真的没有。

顺带记一个生长期的怪现象：`st.s` 是**当前渲染出来的那条折线**上的归一化弧长，
所以亮带的世界位置 ≈ `iTime × 当前长度`，线从 2 个站涨到 28 个站的过程中会被一路往外拽。

**关掉后线条变暗变细**（平时亮度有相当一部分来自高亮段），补回 `glowPower 0.5→1.2`、`taperPower 0.05→0.5`。
实测：运行时读材质 = `{flowLength: 0, glowPower: 1.2, taperPower: 0.5}`；
新旧同取景逐像素比 → 变更 1.5%（变亮 1.12% / 变暗 0.38%），变亮的集中在线上。

## 5. 本轮的验证教训

- **像素级 A/B 在这个场景不好用**：远景下瓦片 LOD 自身漂移就有 **2.5~3%**，比被测对象的像素占比还大；
  把相机拉到贴近线路后漂移降到 **0%**，才可用。
- **运行时改这个自定义材质属性不会重绘**（把 `flowLength` 从 0 改成 0.4，画面不变）。
  所以「材质到底关没关」要靠**构造时传的值** + 着色器分支判断，不能靠运行时改来验证。
