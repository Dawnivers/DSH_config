---
id: "a29177f1-d76e-4ea5-a05f-29ed71258be7"
title: "语雀课程《Cesium_智慧地铁》「重保活动」章完整存档（功能说明 / UI 与数据 / 四段源码 / 渐变圆柱与线路闪烁机制 / 与本项目 /experiment 的落地差异）"
description: "新中地课程文档《重保活动》全文要点与全部源码：站线列表 + 重点活动面板、flyToLine/binkLineByName/addGradientCone/removeAllCones/flyToCone 五个 effectController 函数、WallGradientsMaterialProperty 自定义 wall 材质（含 GLSL 与 wallgradients.png）、mock 数据 staticData.activity 的 id 即站点下标；2026-10-14 已逐行核对参考仓库，纠正「语雀文档代码块比仓库多一行会 ReferenceError」，并补入 renderLines 用 PolylineGlowMaterialProperty(glowPower 0.12/width 20/isCache) 与 core.js 的 generateCirclePoints/pointsToPositions。"
status: "active"
created_at: "2026-10-14T01:38:58.928Z"
updated_at: "2026-10-14T01:51:09.351Z"
content_hash: "6b9581c9feeb77bb726418ba74ecf7321fb2fe22cd48305710adc2f373fb8a82"
source_paths:
  - "参考资料/重保活动-语雀课程/重保活动（语雀课程原文）.md"
  - "Translation/src/router/index.js"
  - "Translation/src/components/screenUI/foot.vue"
  - "综合项目：智慧地铁/smart-subway-warehouse/src/views/KeyActivity.vue"
  - "综合项目：智慧地铁/smart-subway-warehouse/src/cesiumTools/effectController.js"
  - "综合项目：智慧地铁/smart-subway-warehouse/src/cesiumTools/wallMaterial.js"
  - "综合项目：智慧地铁/smart-subway-warehouse/src/store/staticData.js"
session_ids:
  - "session-d6cbf69c-ac7f-4b6b-a2a9-8468919b087a"
memory_body_ids:
  []
---

# 语雀课程《Cesium_智慧地铁》「重保活动」章

- 原文：https://www.yuque.com/xzd/fgdede/ggmryxoohipmludf （密码 yzg4）
- 知识库：`fgdede`《Cesium_智慧地铁》 book_id `42389323`，doc_id `169588537`，内容最后更新 2025-06-19
- 本地留档（含 3 张插图）：`参考资料/重保活动-语雀课程/重保活动（语雀课程原文）.md` + `images/`
- 同知识库另一章存档见文档 `d509f38c-0930-4920-b7c1-7c0b441b5277`（第 8 章 发展历程）
- **2026-10-14 已逐行核对参考仓库**（`综合项目：智慧地铁/smart-subway-warehouse/src/`），差异见第 5 节「仓库核对」

> 取全文的方法：过密码后在页面里
> `fetch('/api/docs/<slug>?book_id=42389323&mode=markdown&plain=true&linebreak=true&anchor=true&latexcode=false', {credentials:'include'})`，
> **正文在 `data.sourcecode`**（不是 `data.body`，`data.body` 为空）。
> **不要用 DOM 抓取**：语雀新版编辑器开 `virtualRenderingGrey`，代码块按视口虚拟渲染，
> 长代码块（本页共 5 段）会被截断成 30 行左右且不报错；作者折叠过的 CSS 在网页上看着像缺失，markdown 源里是完整的。

## 0. 名字

「**重保活动**」= **重**点**保**障活动（重点保护活动），不是「重点活动」。
课程正文用的标题是「重保活动」，panel 标题写「重点活动」，参考项目文件名 `KeyActivity.vue`。三个指同一件事。

## 1. 功能说明（原文高亮块）

> 1. 进入重保活动菜单，展示每条线路上对应的重保活动
> 2. 点击重保活动，高亮对应的地铁线路，视角跳转，并渲染高亮块

## 2. UI 与数据

界面 = 「站线列表」+「重保活动列表」两部分：

- `subLineData` 直接从 pinia 取线路数据（本项目对应 `Translation/src/stores/stationState.js` 的 `lineEnts` + 线路配置）
- `activityData` 是 mock 的**重保活动数据**，放在 `staticData.js`

mock 数据结构（参考项目实测只有 4 条，全挂在 1 号线）：

```js
export const activity = [
  { id: 3,  activedLine: "1号线", activity: "领导参观", activedPlace: "长江大桥", activedTime: "8:30"  },
  { id: 7,  activedLine: "1号线", activity: "足球赛",   activedPlace: "体育场",   activedTime: "10:30" },
  { id: 12, activedLine: "1号线", activity: "领导巡视", activedPlace: "大学",     activedTime: "14:30" },
  { id: 14, activedLine: "1号线", activity: "露天演出", activedPlace: "景区",     activedTime: "..."   },
];
```

**关键：`id` 就是该线路 `stationsList` 的下标（0 基）**，不是业务 ID。
所以同一份 activity 拿到别的线路上跑，落点会完全错位——参考项目用一个 `activity` 常量配 `activedLine` 字段，
但 `showActiveArea` 里**根本没用 `activedLine` 过滤**，是直接拿 `activity` 全部 id 去当前线路里找站。
（想复用本项目的真实 18 条线数据，这里必须补一层「按线路过滤」或改成 `{line, stationName}` 的结构。）

## 3. 源码

### 3.1 组件（SFC，模板）

```html
<template>
    <div id="subLine-controller">
        <div class="item-wrapper">
            <div class="item" v-for="item in subLineData" @click.stop="handleItemClick(item)">
                <div class="box" :style="{ borderColor: item.color, backgroundColor: item.color }"></div>
                <span :style="{ color: '#34c5cf' }">{{ item.name.slice(-3) }}</span>
            </div>
        </div>
    </div>

    <div class="active-panel">
        <div class="header">
            <strong>重点活动</strong>
            <span>{{ date }}</span>
        </div>
        <div class="content">
            <div class="active-wrapper" v-if="activityData.length">
                <div v-for="item in activityData" :class="['acitve-item', item.isActive ? 'item-active' : '']"
                    @click="clickActiveItem(item)">
                    <div>{{ item.activedTime }}</div>
                    <div>{{ item.activedPlace }}</div>
                    <div>{{ item.activity }}</div>
                </div>
            </div>
            <a-empty v-else :image="simpleImage" description="无数据" />
        </div>
    </div>
</template>
```

（`item.name.slice(-3)` 只显示线路名后 3 个字，如「1号线」；注意 CSS 里是 `100%` 右侧对齐的 flex-wrap 网格，
`.item` 定宽 65×20，`.item-wrapper` `flex:1` —— 线路多时靠 wrap 换行，不滚动。）

### 3.2 组件（script setup，参考项目补全版）

```js
import { computed, onMounted, ref, onBeforeUnmount } from 'vue'
import { useLineData } from '@/store'
import { activity } from '@/store/staticData'
import { flyToLine, binkLineByName, addGradientCone, removeAllCones, flyToCone } from '@/cesiumTools/effectController'
import dayjs from 'dayjs'

const lineData = useLineData()
const subLineData = lineData.allData
let viewer
onMounted(() => { viewer = lineData.Viewer })
onBeforeUnmount(() => { removeAllCones(viewer) })   // 原文强调：记得清除副作用

const date = computed(() => dayjs().format("YYYY-MM-DD"))
const activityData = ref([])     // 重点活动列表
const currentStations = ref([])  // 当前线路上激活的站点

const handleItemClick = (item) => {
    const { name, stationsList, color } = item
    flyToLine(viewer, name)
    binkLineByName(name)
    currentStations.value = stationsList
    activityData.value = activity
    showActiveArea(color)
}

const showActiveArea = (color) => {
    removeAllCones(viewer)
    const ids = activityData.value.map(item => item.id)
    // 这里坐标直接取 index 和 id 对应的站点坐标
    const activedStations = currentStations.value
        .map((item, index) => { item.id = index; return item })
        .filter(item => ids.includes(item.id))
    activedStations.forEach(item => {
        const { position, id } = item
        addGradientCone(viewer, { position, color, name: id })
    })
}

const clickActiveItem = (item) => { flyToCone(viewer, item.id) }
```

### 3.3 effectController 四函数

```js
// 添加重保活动圆柱
// options: { position: {lng,lat,height}, height: 1000, baseHeight: 0, radius: 100, color: "#ff0000", name: "活动圆柱" }
const cones = []
export const addGradientCone = (viewer, options) => {
  const wallColor = Cesium.defaultValue(new Cesium.Color.fromCssColorString(options.color), Cesium.Color.AQUA)
  const name = Cesium.defaultValue(options.name, "")
  const center = Cesium.defaultValue(options.position, { lng: 0, lat: 0, height: 0 })
  const wallHeight = Cesium.defaultValue(options.height, 2600)
  const baseHeight = Cesium.defaultValue(options.baseHeight, 0)
  const radius = Cesium.defaultValue(options.radius, 200)

  const positions = generateCirclePoints([center.lng, center.lat], radius, baseHeight)
  const wallPositions = pointsToPositions(positions, baseHeight)   // 经纬度 → Cartesian3
  let minimumHeights = [], maximumHeights = []
  wallPositions.forEach(() => {
    minimumHeights.push(baseHeight)
    maximumHeights.push(baseHeight + wallHeight)
  })

  const cone = viewer.entities.add({
    name,
    center: new Cesium.Cartesian3.fromDegrees(center.lng, center.lat, baseHeight),
    wall: {
      positions: wallPositions,
      minimumHeights, maximumHeights,
      material: new WallGradientsMaterialProperty(wallColor),
    },
  })
  cones.push(cone)
}

// 删除所有圆柱（进面板/换线路都要先清）
export const removeAllCones = (viewer) => {
  cones.forEach((cone) => { cone && viewer.entities.remove(cone) })
  cones.length = 0
}

// 根据名称视角跳转到对应线路
export const flyToLine = (viewer, name) => {
  const targetEnt = lines.find((item) => item.name === name)
  if (!targetEnt) return
  viewer.flyTo(targetEnt)      // 直接 flyTo 实体，Cesium 自己算包围球
}

// 根据线路名称闪烁线路
let timerBink
let lastActiveRoute
export const binkLineByName = (name) => {
  const targetEnt = lines.find((item) => item.name === name)
  if (!targetEnt) return
  // 选中的就是刚高亮的那条：有定时器就直接返回（避免叠加）
  if (timerBink && name === lastActiveRoute) return
  // 换了线路：先清掉上一个定时器
  if (name !== lastActiveRoute && timerBink) {
    window.clearInterval(timerBink)
    timerBink = null
  }
  const originGlowPower = targetEnt.polyline.material.glowPower
  const timeBreak = 600
  let binkCount = 6
  let count = 0
  timerBink = setInterval(() => {
    if (count >= binkCount) { window.clearInterval(timerBink); timerBink = null }
    else {
      let isBink = count % 2 === 0
      targetEnt.polyline.material.glowPower = isBink ? originGlowPower * 4 : originGlowPower
      count++
    }
  }, timeBreak)
}
```

> `binkLineByName` 是**直接改 material 上的 `glowPower` 属性**（不是换材质、不是加 entity），
> 600ms 一次、共 6 次（亮→暗→亮→暗→亮→暗，约 3.6s）。
> 坑：换线路时必须 `clearInterval`，否则两个定时器抢同一条线；`lastActiveRoute` 在仓库里**始终是 undefined**
> （从来没有被赋值），所以「重复点击同一条线直接 return」这条短路实际上从不生效——`glowPower` 最后停在
> `originGlowPower * 4` 还是 `origin*1` 取决于 6 次计数的奇偶，代码里没有在结束时复位（偶发「一直亮着」）。

### 3.4 光柱材质源码（`wallMaterial.js`，原文标为「光柱材质源码」）

```ts
import * as Cesium from "cesium";

// 渐变墙体材质  color 颜色
function WallGradientsMaterialProperty(color) {
  this._definitionChanged = new Cesium.Event();
  this._color = undefined;
  this._colorSubscription = undefined;
  this.color = color;
}
Object.defineProperties(WallGradientsMaterialProperty.prototype, {
  isConstant: { get: function () { return false; } },      // ← 动态材质，每帧求值
  definitionChanged: { get: function () { return this._definitionChanged; } },
  color: Cesium.createPropertyDescriptor("color"),
});
WallGradientsMaterialProperty.prototype.getType = function () { return "WallGradients"; };
WallGradientsMaterialProperty.prototype.getValue = function (time, result) {
  if (!Cesium.defined(result)) result = {};
  result.color = Cesium.Property.getValueOrClonedDefault(
    this._color, time, Cesium.Color.WHITE, result.color
  );
  result.image = Cesium.Material.WallGradientsImage;
  return result;
};
WallGradientsMaterialProperty.prototype.equals = function (other) {
  return this === other ||
    (other instanceof WallGradientsMaterialProperty &&
      Cesium.Property.equals(this._color, other._color));
};

Cesium.Material.WallGradientsType = "WallGradients";
Cesium.Material.WallGradientsImage = "/src/assets/materialResources/wallgradients.png";
Cesium.Material.WallGradientsSource =
  "czm_material czm_getMaterial(czm_materialInput materialInput)\n\
{\n\
     czm_material material = czm_getDefaultMaterial(materialInput);\n\
     vec2 st = materialInput.st;\n\
     vec4 colorImage = texture2D(image, vec2(fract(st.t - time), st.t));\n\
     float time=fract(czm_frameNumber/10.0);\n\
     float isAlpha=step(0.5,time);\n\
     float dis = distance(st, vec2(0.5));\n\
     if(isAlpha>=1.0){\n\
        material.alpha = colorImage.a * color.a* dis *2.5;\n\
    }else{\n\
        material.alpha = colorImage.a * color.a * dis *2.0;\n\
    }\n\
     material.diffuse =  2.5 * color.rgb  ;\n\
     return material;\n\
 }";
Cesium.Material._materialCache.addMaterial(Cesium.Material.WallGradientsType, {
  fabric: {
    type: Cesium.Material.WallGradientsType,
    uniforms: { color: new Cesium.Color(1.0, 0.0, 0.0, 0.5), image: Cesium.Material.WallGradientsImage, time: 0 },
    source: Cesium.Material.WallGradientsSource,
  },
  translucent: function () { return true; },
});

export default WallGradientsMaterialProperty;
```

**这段 GLSL 的要点**：
- `vec2(fract(st.t - time), st.t)` —— 沿墙的 **t 方向做循环滚动采样**，所以贴图是**向上流动**的。
- 两个 alpha 分支（`isAlpha` 由 `fract(frameNumber/10.0)` 每 10 帧翻转一次）+ 系数 2.5/2.0 交替，
  造出**明暗呼吸**；再乘 `dis = distance(st, vec2(0.5))`（到墙心的距离），
  于是**圆柱中心最亮、边缘淡出**，看起来是个光柱而不是一个空心筒。
- `material.diffuse = 2.5 * color.rgb` 直接加亮，配合 `translucent: true`。
- 贴图路径 `"/src/assets/materialResources/wallgradients.png"` 是**绝对路径**：
  vite 下 `/src/...` 能被解析，但 `build` 后靠 public 或资源编译；照抄时要确认该 png 存在。
- `time` uniform 在 fabric 里恒为 0，**GLSL 里的 `time` 变量被内部 `float time=fract(...)` 遮蔽**，
  滚动相位实际由 `czm_frameNumber` 驱动 —— 所以这个材质不需要外部每帧推送 uniform 也会动。

### 3.5 flyToCone（选中活动）

```js
// 视角飞到圆柱
export const flyToCone = (viewer, name) => {
  const targetCone = cones.find((item) => item.name === name)
  if (!targetCone) return
  viewer.flyTo(targetCone, {
    offset: new Cesium.HeadingPitchRange(Cesium.Math.toRadians(40), Cesium.Math.toRadians(-40), 5000)
  })
}
```

原文提醒：**这里注意需要设置 `HeadingPitchRange` 参数**（否则默认俯角是 -90° 正俯视，光柱会变成一个圆点）。

## 4. 两个层级的「视角跳转」（本功能的骨架）

| 触发 | 目标 | 相机 API | 说明 |
|---|---|---|---|
| 点击左侧线路 | 整条线路 entity | `viewer.flyTo(targetEnt)` | 不传 offset，Cesium 用实体包围球自动算距离 |
| 点击活动卡片 | 某个光柱 entity | `viewer.flyTo(targetEnt, { offset: HeadingPitchRange(40°, -40°, 5000) })` | 必须给 offset，否则斜看不了 |

配套：先用 `removeAllCones` 清旧光柱 → 再按当前线路 + activity id 重建 → `binkLineByName` 闪线路。

## 5. 仓库核对（2026-10-14 逐行核对参考仓库，以仓库为准）

参考仓库路径：`综合项目：智慧地铁/smart-subway-warehouse/src/`

| 事实 | 位置 | 内容 |
|---|---|---|
| 线路实体缓存 | `cesiumTools/effectController.js:236` | `const lines = []`，模块级；注释写明「lines 是全局缓存的数据，没有办法在特殊的局部组件里面使用」 |
| 建线 | `effectController.js:237-269` | `renderLines` 用 `Cesium.PolylineGlowMaterialProperty({ color, glowPower: 0.12 })`、`width: 20`；新增 **`isCache`（默认 true）** 参数决定是否 `lines.push(lineEnt)` —— 这就是课程另一章说的「把图层控制收进 pinia」的铺垫：局部组件建的线不进全局缓存，才敢随便删 |
| 删除线路 | `effectController.js:272-276` | `removeAllLines` 是 **remove 不是 hide** |
| 闪烁 | `effectController.js:279-315` | 与文档一致，**但 292-295 行只有 `clearInterval` + `timerBink = null`**；文档代码块里多出的 `lastActiveEnt.polyline.material.glowPower = 0.12` 这一行**仓库里没有**，且 `lastActiveEnt` 在整个文件里不存在 → 照文档抄会 `ReferenceError` |
| 建圆工具 | `cesiumTools/core.js:22-38` | `generateCirclePoints(center, radius)`：**每 2° 取一个点，共 181 个点**（360/2+1）闭合；`getCirclePoint` 用 `ec = 6356725 + (6378137-6356725)*(90-lat)/90` 做**纬度相关的经度收缩**，不是简单的小圆近似 |
| 点转笛卡尔 | `cesiumTools/core.js:41-47` | `pointsToPositions(points, height)` → `Cesium.Cartesian3.fromDegrees(lng, lat, height)` |
| 光柱汇总 | `effectController.js:419-490` | `addGradientCone` / `removeAllCones` / `flyToCone` 与文档完全一致（`cones` 也是模块级数组） |
| 材质文件 | `cesiumTools/wallMaterial.js` | 与文档 3.4 一致，`export default WallGradientsMaterialProperty` |

**结论**：文档与本仓库只有一处硬差异（`lastActiveEnt` 那一行），其余逐字一致；仓库比文档多出的是
`renderLines` 的 `isCache` 参数与 `core.js` 的两个几何工具（文档把这些当"已有工具"没展开）。

## 6. 与本项目 `Translation` 的对应关系与落地差异

**对应路由已存在**：`Translation/src/router/index.js:24` 是 `{ path: '/experiment', component: EmptyView } // 重点活动`，
底部导航 `Translation/src/components/screenUI/foot.vue:25` 的 `key: 'experiment'` 与 `:138` 的 `experiment: '/experiment'`
就指向它 —— 也就是本章功能在本项目的落点，目前是空组件。

差异（照抄会踩）：

| 参考项目 | 本项目 Translation | 处理 |
|---|---|---|
| antd `a-empty`（无数据占位） | **没有 ant-design-vue 依赖**（package.json 只有 vue/pinia/cesium/dayjs…） | 自己写一个「无数据」占位 div |
| `dayjs` | 有 `dayjs@^1.11.11` | 可直接用 |
| `useLineData()` 里有 `allData` 与 `Viewer` | 本项目分在两个 store：Viewer 在 `src/stores/counter.js`（`cesiumStore.Viewer`），线路实体在 `src/stores/stationState.js` 的 `lineEnts` | 取数要改两处 |
| `lines` 模块级数组（effectController 里直接 find） | 没有等价模块级 `lines`；线路是用 `src/cesiumTools/lineAndpoints/line/setlines.js` 的 `renderLines(viewer, options)` 现建的 Entity，`polyline.material` 是 `PolylineFlowMaterialProperty` | `flyToLine`/`binkLineByName` 要改成按 `lineEnts` 或 `entity.name` 查 |
| 图元是 `PolylineGlowMaterialProperty`，`material.glowPower` 可写 | 本项目的 `PolylineFlowMaterialProperty` **同样有 `glowPower`**（另有 `flowLength / flowIntensity / taperPower`） | 闪烁逻辑可复用；但注意本项目已实测过：**`flowLength: 0` 才能真的关掉流动**，置 `flowIntensity: 0` 会让 alpha 拉满成黑带 |
| 线路名 `1号线` 直接匹配 | 本项目线路实体名与 `LINE_COLORS`/配置一致，18 条线只有 12 个颜色（`index % 12`） | 同色线路的点选要留意 |
| `generateCirclePoints` / `pointsToPositions` | 本项目需自建（`core.js` 那两个函数可直接搬，注意它不依赖任何项目状态） | 建圆柱前先确认这两个函数是否存在 |
| 站点对象形如 `{position:{lng,lat,height}, id}` | 本项目站点在 `stationObjs`，`addGradientCone` 期望的 `position.lng/lat` 需要现场映射 | 写映射时注意 Cesium 侧通常是 `Cartesian3` 或 `[lng,lat]` |

**注意**：本项目已有自己的一套「墙/光柱」材质吗？参考项目里另有 `ConeGlowBottomCircle`（在 dist 中可见），
与本篇的 `WallGradients` 不是同一个东西 —— 落地前先 grep 确认，别重复造。

## 7. 一句话总结这套做法

> 用**一条 `wall` 图元**（不是 `cylinder`）配合 `minimumHeights`/`maximumHeights` 撑出竖直面，
> 再挂一个**自定义 `isConstant=false` 的材质属性**，让 GLSL 每帧按 `czm_frameNumber` 滚动贴图 + 呼吸 alpha，
> 得到「渐变光柱」；线路高亮则退化成**改 `material.glowPower` 的定时器闪烁**；
> 两个层级的镜头跳转都靠 `viewer.flyTo`，区别只在给不给 `HeadingPitchRange`。
