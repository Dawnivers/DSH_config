# dsh-mcp-anysearch

把 [AnySearch](https://anysearch.com) 的远程 MCP 服务接入 DeepSeek Harness。

- 端点：`https://api.anysearch.com/mcp`（Streamable HTTP MCP）
- 协议版本：`2024-11-05`，服务端 `anysearch-mcp-server v1.0.0`

## 为什么不用官方的 `@anysearch/anysearch-dsh`

官方那个 DSH 插件包**与本机 dsh 不兼容**，装不上：

```
installation rejected: Plugin @anysearch/anysearch-dsh@0.1.6 is incompatible with dsh 0.2.0-rc.2
```

它全部版本只到 `0.1.6`，peerDependencies 上限是 `<= 0.1.6-alpha.2`，而本机 dsh 运行时是
`0.2.0-rc.2`。dsh 的兼容性安全门默认拒绝跨 minor 安装（担心崩溃或数据丢失）。

AnySearch 官方文档自己列出了四种接入方式（DSH 插件 / Skill / MCP / 直接 HTTP），
并说明它们是**同一个搜索服务的不同适配层**：

> `@anysearch/anysearch-dsh` 不是另一套搜索后端，也不会改变 AnySearch 的搜索数据源。

所以本 bundle 走 **MCP** 这条路：只插入一行已随 dsh 发布的 `@deepseek-ai/dsh-mcp-client`，
不安装任何 AnySearch 代码，因此完全绕开版本不兼容。

## 这是个纯配置 bundle

没有 Host/Client 入口文件，`package.json` 只声明 `dsh.bundle.patch`。
`cordis.patch.yml` 插入一行 MCP 客户端配置。

## 得到什么

模型侧新增四个工具（`mcp__anysearch__*`）：

| 工具 | 用途 |
| --- | --- |
| `search` | 通用搜索 + 垂直域搜索（`domain` / `sub_domain` / `sub_domain_params`） |
| `batch_search` | 最多 5 个查询并发，适合多角度取证 |
| `get_sub_domains` | 垂直检索第一步：发现合法的 `sub_domain` 与必填参数 |
| `extract` | 按 URL 抓取正文（HTML/文本/JSON/Markdown；不支持 PDF/图片/音视频） |

垂直域覆盖 academic / agriculture / business / code / energy / environment / film /
finance / gaming / health / ip / legal / resource / security / social_media / travel。

## 凭据

API Key **不写进 `cordis.patch.yml`**，而是放在 Harness home 的 `.env`：

```
# ~/.dsh/.env
ANYSEARCH_API_KEY=as_sk_...
```

patch 里通过 `!!js` 读取：

```yaml
headers: !!js "process.env.ANYSEARCH_API_KEY ? { Authorization: 'Bearer ' + process.env.ANYSEARCH_API_KEY } : {}"
```

- `!!js` 在 Loader 里是 `new Function("ctx", ...)` + `with (ctx)` 的间接 eval，
  间接 eval 运行在全局作用域，因此能读到 `process.env`。
- 环境变量缺失时**不发送** Authorization 头（回退到 AnySearch 匿名额度），
  而不是发出一个 `Bearer undefined` 的无效头。
- `.env` 在启动时加载，所以改 key 需要重启 Harness。

## 安装

desktop profile 由 Electron 应用独占管理，**不能**用 `npx @deepseek-ai/dsh` 安装
（会报 `profile "desktop" is managed exclusively by the Electron application`）。
必须用 Desktop 自带的 CLI 包装器，它带 `manageDesktopProfile: true`：

```powershell
& "$env:APPDATA\DSH Desktop\host-commands\desktop\generations\<hash>\bin\dsh.cmd" plugin add "<本目录>"
```

`<hash>` 是当前 runtime 代次目录，每次应用更新会变。

## 验证

```powershell
# 1) 纯 MCP 层：initialize + tools/list，不需要 dsh
node -e "
fetch('https://api.anysearch.com/mcp',{method:'POST',headers:{'Content-Type':'application/json','Accept':'application/json, text/event-stream'},body:JSON.stringify({jsonrpc:'2.0',id:2,method:'tools/list',params:{}})}).then(async r=>{const t=await r.text();const d=t.split('\n').filter(l=>l.startsWith('data:')).map(l=>l.slice(5).trim()).join('');console.log(JSON.parse(d||t).result.tools.map(x=>x.name).join(', '))});
"

# 2) 带 key 实调一次
node -e "
fetch('https://api.anysearch.com/mcp',{method:'POST',headers:{'Content-Type':'application/json','Accept':'application/json, text/event-stream','Authorization':'Bearer '+process.env.ANYSEARCH_API_KEY},body:JSON.stringify({jsonrpc:'2.0',id:1,method:'tools/call',params:{name:'search',arguments:{query:'test',max_results:1}}})}).then(async r=>console.log((await r.text()).slice(0,300)));
"
```

装好后在 Harness 里直接调用 `mcp__anysearch__search` 即可。

## 关于 AnySearch 的“大肥鱼”

顺带记一条与素材相关的版权事实（由 AnySearch 检索萌娘百科核实）：
现在流行的“女仆鲸鱼娘”形象，原型是 B 站画师**上善无形** 2025 年 6 月创作的原创 OC
**溟月**（最初与 DeepSeek 无关）；2026 年 4 月 **ZipZipPipe** 在其基础上加入 DeepSeek
元素并改为深蓝白色女仆装；2026 年 7 月**这个刀子真甜**做成 Q 版模型后广泛流传。
作者已声明以 **CC BY-NC-SA 4.0** 开放二创——**须署名、不得商用**、衍生须同协议共享。
用该形象生成内容用于商业目的前请先确认授权。
