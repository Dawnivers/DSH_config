/**
 * Agnes API 的共享底层。
 *
 * 从 `dsh-agnes-image` 里抽出、已被实测验证的部分：公共 DNS 解析、IPv4 优先、
 * 多地址重试、请求封装，以及二进制原子落盘。图像与视频两个插件都依赖这里，
 * 避免把同一套网络层维护两遍。
 *
 * 只使用 Node 内置能力，**不 import 任何 `@deepseek-ai/*` 包** —— profile 的
 * `node_modules` 里解析不到这些包，这是刻意的设计。
 */

import { lookup as lookupCb } from 'node:dns';
import { Resolver } from 'node:dns/promises';
import { request as httpsRequest, Agent as HttpsAgent } from 'node:https';
import { request as httpRequest, Agent as HttpAgent } from 'node:http';
import { randomUUID } from 'node:crypto';
import { mkdir, rename, rm, writeFile } from 'node:fs/promises';
import { dirname, join } from 'node:path';

/** 默认使用的可信公共解析器：本机系统 DNS 会把 Agnes 域名解析到坏地址。 */
export const DEFAULT_DNS_SERVERS = ['223.6.6.6', '8.8.4.4'];

/**
 * 读取一个字符串配置项，空串/空白视为未设置。
 * @param value - 原始值。
 * @param fallback - 未设置时的回退值。
 * @returns 规范化后的字符串。
 */
export function textConfig(value, fallback) {
  return typeof value === 'string' && value.trim() !== '' ? value.trim() : fallback;
}

/**
 * 读取一个正数配置项。
 * @param value - 原始值。
 * @param fallback - 未设置或非正数时的回退值。
 * @returns 规范化后的数字。
 */
export function numberConfig(value, fallback) {
  return Number.isFinite(value) && value > 0 ? value : fallback;
}

/**
 * 读取一个字符串数组配置项。
 * @param value - 原始值。
 * @param fallback - 不是数组时的回退值。
 * @returns 去掉空白项后的字符串数组。
 */
export function listConfig(value, fallback) {
  if (!Array.isArray(value)) return fallback;
  return value
    .filter((entry) => typeof entry === 'string' && entry.trim() !== '')
    .map((entry) => entry.trim());
}

/**
 * 把输入值规范成非空字符串数组。
 * @param value - 原始值。
 * @returns 过滤后的字符串数组。
 */
export function stringList(value) {
  return Array.isArray(value)
    ? value.filter((entry) => typeof entry === 'string' && entry.trim() !== '').map((entry) => entry.trim())
    : [];
}

/**
 * 一个按进程缓存的地址解析器，优先使用显式指定的公共解析器。
 *
 * 系统解析器在有些网络下不可信：它会给 API 域名返回一个证书里没有 DNS SAN 的
 * 地址（或直接重置连接），而所有公共解析器都一致给出可用的那个。`servers`
 * 为空数组时使用系统解析器。
 */
export class AddressCache {
  #entries = new Map();

  /**
   * 把主机名解析成候选地址。
   * @param hostname - 待解析主机。
   * @param preferIPv4 - 存在 A 记录时是否丢弃 IPv6 候选。
   * @param servers - 优先使用的公共 DNS；空数组表示使用系统解析器。
   * @returns 候选地址，IPv4 在前（当要求时）。
   */
  async resolve(hostname, preferIPv4, servers) {
    const key = `${hostname}|${preferIPv4 ? '4' : 'any'}|${servers.join(',')}`;
    const cached = this.#entries.get(key);
    const now = Date.now();
    if (cached !== undefined && cached.expires > now) return cached.addresses;
    const addresses = await this.#lookup(hostname, preferIPv4, servers);
    if (addresses.length > 0) this.#entries.set(key, { addresses, expires: now + 60000 });
    return addresses;
  }

  async #lookup(hostname, preferIPv4, servers) {
    const attempts = [];
    if (servers.length > 0) {
      const resolver = new Resolver({ timeout: 5000, tries: 2 });
      resolver.setServers(servers);
      attempts.push(() => collect(resolver, hostname));
    }
    attempts.push(() => new Promise((resolve, reject) => {
      // 必须用 node:dns 的回调版：node:dns/promises 的 lookup 忽略回调，会永久挂起。
      lookupCb(hostname, { all: true }, (error, addresses) => {
        if (error) reject(error);
        else resolve(Array.isArray(addresses) ? addresses : [addresses]);
      });
    }));
    for (const attempt of attempts) {
      try {
        const entries = await attempt();
        if (entries.length === 0) continue;
        const v4 = entries.filter((entry) => entry.family === 4);
        if (preferIPv4 && v4.length > 0) return v4;
        return entries;
      } catch {
        // 换下一个解析途径
      }
    }
    return [];
  }
}

/** 进程级共享地址缓存。 */
export const addressCache = new AddressCache();

/**
 * 从一个 resolver 收集两种地址族，容忍某一族缺失。
 * @param resolver - 已配置的 `dns.Resolver`。
 * @param hostname - 待解析主机。
 * @returns 地址条目，IPv4 在前。
 */
async function collect(resolver, hostname) {
  const [a, aaaa] = await Promise.allSettled([
    resolver.resolve4(hostname),
    resolver.resolve6(hostname),
  ]);
  const v4 = a.status === 'fulfilled' ? a.value : [];
  const v6 = aaaa.status === 'fulfilled' ? aaaa.value : [];
  return [
    ...v4.map((address) => ({ address, family: 4 })),
    ...v6.map((address) => ({ address, family: 6 })),
  ];
}

/**
 * 构造一个把连接钉定到某个地址的 `lookup`。
 * @param address - 要连接的地址。
 * @param family - 其地址族。
 * @returns 尊重调用方 `all` 选项的 `lookup`。
 */
function pinAddress(address, family) {
  return (_hostname, options, callback) => {
    if (options?.all) callback(null, [{ address, family }]);
    else callback(null, address, family);
  };
}

/**
 * 针对一个已钉定地址发起一次请求。
 *
 * 协议决定传输层，所以 http:// 基地址（测试与本地网关用）与真实 https:// 端点
 * 走同一条路径。
 *
 * `lookup` 必须放在 Agent 选项里，不能放在请求选项里：Agent 自己建 socket 会
 * 覆盖请求级 `lookup`。Agent 用 `keepAlive: false`，保证每次尝试都是新连接。
 * @param options - url、method、headers、body、timeout、signal 与地址。
 * @returns 状态码、响应头与响应体。
 */
export function httpAttempt({ url, method, headers, body, timeoutMs, signal, address, family }) {
  return new Promise((resolve, reject) => {
    const target = new URL(url);
    const secure = target.protocol === 'https:';
    const Agent = secure ? HttpsAgent : HttpAgent;
    const agent = new Agent({
      keepAlive: false,
      ...(address === undefined ? {} : { lookup: pinAddress(address, family) }),
    });
    const request = (secure ? httpsRequest : httpRequest)({
      host: target.hostname,
      ...(secure ? { servername: target.hostname } : {}),
      port: target.port === '' ? (secure ? 443 : 80) : target.port,
      path: `${target.pathname}${target.search}`,
      method,
      agent,
      headers: {
        Host: target.hostname,
        ...(body === undefined ? {} : { 'Content-Length': Buffer.byteLength(body) }),
        ...headers,
      },
      signal,
    }, (response) => {
      const chunks = [];
      response.on('data', (chunk) => chunks.push(chunk));
      response.on('end', () => resolve({
        status: response.statusCode ?? 0,
        headers: response.headers,
        body: Buffer.concat(chunks),
      }));
    });
    request.on('error', reject);
    request.setTimeout(timeoutMs, () => {
      request.destroy(new Error(`timed out after ${Math.round(timeoutMs / 1000)}s`));
    });
    if (body !== undefined) request.write(body);
    request.end();
  });
}

/**
 * 逐个尝试所有已解析地址，全部失败才放弃。
 *
 * 单个连接错误在这里不具结论性：该 API 的某一族或某一地址可能是死的，而另一个
 * 可用，系统解析器还可能返回一个会重置握手的地址。
 * @param config - 提供 DNS 服务器、IPv4 偏好与超时的配置。
 * @param request - url、method、headers 与 body。
 * @param signal - 取消信号。
 * @returns 状态码、响应头与响应体。
 */
export async function fetchWithFallback(config, request, signal) {
  const target = new URL(request.url);
  const addresses = config.resolveAddress !== ''
    ? [{ address: config.resolveAddress, family: 4 }]
    : await addressCache.resolve(target.hostname, config.preferIPv4, config.dnsServers);
  const attempts = addresses.length > 0 ? addresses : [undefined];
  const failureMessages = [];
  for (const entry of attempts) {
    if (signal.aborted) throw signal.reason ?? new Error('aborted');
    try {
      return await httpAttempt({
        ...request,
        timeoutMs: config.timeoutMs,
        signal,
        address: entry?.address,
        family: entry?.family,
      });
    } catch (error) {
      const message = error?.message ?? String(error);
      failureMessages.push(`${entry?.address ?? target.hostname}: ${message}`);
    }
  }
  const detail = failureMessages.join(' | ');
  const hint = /certificate|altname|self.signed|UNABLE_TO_VERIFY/i.test(detail)
    ? ' TLS 证书校验失败：地址与证书不匹配，可能是 DNS 被污染或代理在拦截 HTTPS。'
    : /ENOTFOUND|EAI_AGAIN/i.test(detail)
      ? ' DNS 解析失败。'
      : '';
  throw new Error(`无法连接 Agnes API（${target.hostname}）：${detail}${hint}`);
}

/**
 * 把字节原子地写到已解析的绝对路径。
 *
 * 为什么不用 `ctx.fs.writeText`：fs 契约只提供文本写入，而本地后端把字符串按
 * **UTF-8** 编码（`dsh-fs-local` 的原子写传 `encoding: 'utf8'`）。因此没有任何
 * JS 字符串能表示任意二进制：每个 ≥0x80 的字节会被重新编码成两个字节，而
 * base64 字符串落盘的只是它自身的 ASCII 字节。harness 也没有二进制写原语，
 * 所以字节走 `node:fs`。
 *
 * 约束与 harness 自身一致：调用方传入的是 `ctx.fs.resolve()` 返回的路径（锚定
 * 在会话工作区）；发布方式同样是"同目录 staging + rename"，读者不会看到半个文件。
 * @param absolutePath - 规范化的绝对目标路径。
 * @param bytes - 负载字节。
 * @param signal - 取消信号。
 */
export async function writeBytesAtomic(absolutePath, bytes, signal) {
  signal?.throwIfAborted();
  const directory = dirname(absolutePath);
  await mkdir(directory, { recursive: true });
  signal?.throwIfAborted();
  const stagingDir = join(directory, `.agnes-${process.pid}-${randomUUID()}.tmpdir`);
  const tempPath = join(stagingDir, 'payload.tmp');
  try {
    await mkdir(stagingDir, { recursive: true });
    await writeFile(tempPath, bytes, signal === undefined ? {} : { signal });
    await rename(tempPath, absolutePath);
  } finally {
    await rm(stagingDir, { recursive: true, force: true }).catch(() => {});
  }
}

/**
 * 按 content-type（或 URL 后缀）挑选文件扩展名。
 * @param mime - 响应 content-type，可能缺失。
 * @param url - 来源 URL，可能在负载是 URL 时给出。
 * @param fallback - 两者都没有可用信息时的扩展名。
 * @returns 带前导点的扩展名。
 */
export function extensionFor(mime, url, fallback = '.png') {
  const fromMime = typeof mime === 'string' ? /^[a-z]+\/([a-z0-9.+-]+)/i.exec(mime) : null;
  if (fromMime) {
    const subtype = fromMime[1].toLowerCase();
    if (subtype === 'jpeg' || subtype === 'jpg') return '.jpg';
    if (subtype === 'svg+xml') return '.svg';
    if (subtype === 'quicktime') return '.mov';
    if (subtype === 'mpeg') return '.mp4';
    return `.${subtype}`;
  }
  if (typeof url === 'string') {
    const match = /\.([a-z0-9]+)(?:[?#]|$)/i.exec(url);
    if (match) {
      const ext = match[1].toLowerCase();
      if (ext === 'jpeg') return '.jpg';
      if (/^[a-z0-9]{2,5}$/.test(ext)) return `.${ext}`;
    }
  }
  return fallback;
}

/**
 * 从负载开头字节识别图像类型。
 * @param bytes - 图像负载。
 * @returns 带前导点的扩展名，无法识别时 undefined。
 */
export function extensionFromMagic(bytes) {
  if (bytes.length >= 8
    && bytes[0] === 0x89 && bytes[1] === 0x50 && bytes[2] === 0x4e && bytes[3] === 0x47) return '.png';
  if (bytes.length >= 3 && bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff) return '.jpg';
  if (bytes.length >= 12
    && bytes.subarray(0, 4).toString('ascii') === 'RIFF'
    && bytes.subarray(8, 12).toString('ascii') === 'WEBP') return '.webp';
  if (bytes.length >= 6 && bytes.subarray(0, 3).toString('ascii') === 'GIF') return '.gif';
  return undefined;
}

/**
 * 从负载开头字节识别视频容器类型。
 * @param bytes - 视频负载。
 * @returns 带前导点的扩展名，无法识别时 undefined。
 */
export function videoExtensionFromMagic(bytes) {
  if (bytes.length >= 12 && bytes.subarray(4, 8).toString('ascii') === 'ftyp') {
    const brand = bytes.subarray(8, 12).toString('ascii');
    if (brand.startsWith('qt')) return '.mov';
    return '.mp4';
  }
  if (bytes.length >= 4
    && bytes[0] === 0x1a && bytes[1] === 0x45 && bytes[2] === 0xdf && bytes[3] === 0xa3) return '.webm';
  return undefined;
}

/**
 * 把图像输入解析成 API 可接受的形式。
 * @param value - URL、Data URI 或工作区内的文件路径。
 * @param ctx - 提供 `fs` 的插件上下文。
 * @param exec - 工具执行上下文。
 * @param cwd - 会话工作区（可为 undefined）。
 * @returns 公网 URL 或 Data URI。
 */
export async function resolveInputImage(value, ctx, exec, cwd) {
  if (/^https?:\/\//i.test(value) || /^data:[a-z]+\/[a-z0-9.+-]+;base64,/i.test(value)) return value;
  const target = await ctx.fs.resolve(value, {
    ...(cwd === undefined ? {} : { cwd }),
    signal: exec.signal,
  });
  const info = await ctx.fs.stat(target, exec.signal);
  if (info === undefined || info.type !== 'file') {
    throw new Error(`找不到输入文件 "${value}"：请给出可公开访问的 HTTPS URL，或工作区内已存在的文件路径。`);
  }
  const bytes = Buffer.from(await ctx.fs.readBytes(target, exec.signal));
  const ext = extensionFor(undefined, value);
  const mime = ext === '.jpg' || ext === '.jpeg'
    ? 'image/jpeg'
    : ext === '.webp'
      ? 'image/webp'
      : ext === '.gif'
        ? 'image/gif'
        : 'image/png';
  return `data:${mime};base64,${bytes.toString('base64')}`;
}
