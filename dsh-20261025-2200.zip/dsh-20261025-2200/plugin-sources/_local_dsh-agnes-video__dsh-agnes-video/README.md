# dsh-agnes-video

把 **Agnes Video 2.5 Flash**（`agnes-video-2.5-flash`）的视频生成能力接进 DeepSeek Harness，
以一个 Agent 工具 `agnes_video_generate` 暴露出来。

- 文档：<https://www.agnes-ai.cn/zh-Hans/docs/agnes-video-25-flash>（差异页）
  / <https://www.agnes-ai.cn/zh-Hans/docs/agnes-video-25>（公共参数与响应字段）
- 建任务：`POST {baseUrl}/v1/videos`
- 轮询：`GET {baseUrl}/agnesapi?video_id=<VIDEO_ID>&model_name=<MODEL>`

## 能力

| 模式 | `mode` | 用法 |
| --- | --- | --- |
| 文生视频 | `text` | 只给 `prompt` |
| 首尾帧控制 | `keyframe` | `first_frame` / `last_frame` 至少一个（图生视频） |
| 图片/音频参考 | `reference` | `images`、`audios` 至少一类非空；提示词里用 `<Picture 1>` / `<Audio 1>` 指代 |

视频是**异步任务**：工具会先建任务，再按自适应间隔轮询，完成后把视频下载到会话工作区并返回路径。

## 安装

这是一个 DSH bundle（`package.json` 里声明 `dsh.bundle.patch`）。安装用 Desktop 自带的
`dsh` CLI，它会转发给 profile 目录里的 pnpm，并自动把 bundle 登记进 `dsh.profile.bundles`：

```powershell
dsh plugin --profile desktop add "<本目录的绝对路径>"
```

装完 `agnes_video_generate` 会成为可调用工具。**代码改动后需要重启 Harness**：
profile 的 `hmr` 默认不监控模块根目录，且 `dsh-hmr` 明确忽略 `**/node_modules` 路径，
而插件正是从 `profiles\<profile>\node_modules\@local\dsh-agnes-video` 加载的。

也可以改用 Harness Web GUI 的 **设置 → 插件** 页面安装。

## 依赖与解析（一个必须知道的坑）

网络层与二进制落盘来自共享包 `@local/dsh-agnes-core`（与 `dsh-agnes-image` 同一份实现）。

**关键：`link:` 场景下依赖必须能从"真实路径"解析，而不是 profile 的 `node_modules`。**

`dsh plugin add` 只对插件目录执行 `pnpm add <spec>`，而 pnpm **不会为 `link:` 目标安装传递依赖**；
更麻烦的是，Node 会把 junction 解析成真实路径（`...\default-workspace\dsh-agnes-video\index.js`），
然后从**那里**逐级向上找 `node_modules` —— 于是 profile 里的 `node_modules\@local\dsh-agnes-core`
对它毫无帮助。这正是本插件第一次安装后加载失败（`ERR_MODULE_NOT_FOUND`）的原因。

因此工作区根目录有一个 `package.json` 把共享包声明为本地依赖，并已执行过一次安装：

```powershell
cd "<工作区>"
pnpm install          # 生成 node_modules\@local\dsh-agnes-core（junction）
```

换机器或清理 `node_modules` 后，需要重新执行这一步，否则两个插件都会在加载时失败。
（`dsh plugin add` 每次都会在工作区跑 pnpm，所以它通常会自动把这一步带出来。）

## 配置

配置在 `cordis.patch.yml` 的 `agnes-video` 行 `config` 里，字段含义见 `config.schema.json`：

| 字段 | 默认值 | 说明 |
| --- | --- | --- |
| `apiKey` | （patch 中已填） | Agnes API Key；留空则回退到环境变量 `AGNES_API_KEY`，**环境变量优先** |
| `model` | `agnes-video-2.5-flash` | 模型名 |
| `baseUrl` | `https://api.agnes-ai.cn` | API 基地址 |
| `defaultSeconds` | `5` | 未显式传 `seconds` 时的时长（`4`–`12`） |
| `defaultSize` | `720P` | 未显式传 `size` 时的档位；Flash 只能是 `720P` |
| `defaultAspectRatio` | `16:9` | 未显式传 `aspect_ratio` 时的画幅 |
| `outputDir` | `agnes-videos` | 工作区内保存结果的相对目录 |
| `timeoutMs` | `180000` | 单次 HTTP 请求（建任务/轮询/下载）超时 |
| `pollIntervalMs` | `2000` | 轮询间隔基准（毫秒） |
| `pollMaxIntervalMs` | `30000` | 被限流时轮询间隔退避的上限 |
| `pollTimeoutMs` | `900000` | 等待任务完成的总预算（15 分钟） |
| `submitRetryMs` | `300000` | 建任务遇到可重试错误时的重试总预算 |
| `maxOutputBytes` | `268435456` | 接受的最大视频字节数（256 MiB） |
| `preferIPv4` | `true` | 只保留 IPv4 候选地址 |
| `dnsServers` | `["223.6.6.6","8.8.4.4"]` | 解析用的公共 DNS；留空数组则用系统解析器 |
| `resolveAddress` | `""` | 钉定 API 域名的 IPv4 地址，绕过被污染的 DNS |

### 关于密钥

密钥目前按你的选择写在 `cordis.patch.yml` 里（工作区本地配置文件）。两点提醒：

- 该文件**不要提交到任何仓库**；目录已附 `.gitignore` 忽略 `cordis.patch.yml`。
- 密钥在本会话对话中出现过，如果这个渠道不够私密，建议去 Agnes 控制台**轮换一次**。

想改成不落盘的方式：给 Windows 设一个用户环境变量即可，插件会优先使用它。

```powershell
[Environment]::SetEnvironmentVariable('AGNES_API_KEY', 'sk-...', 'User')
```

## 工具参数

| 参数 | 必填 | 说明 |
| --- | --- | --- |
| `prompt` | 是 | 视频内容描述；参考模式用 `<Picture N>` / `<Audio N>` 指代素材 |
| `mode` | 否 | `text`（默认）/ `keyframe` / `reference` |
| `seconds` | 否 | 时长，字符串 `"4"`–`"12"` |
| `size` | 否 | `720P`（Flash 仅此一项） |
| `aspect_ratio` | 否 | `21:9` `16:9` `4:3` `1:1` `3:4` `9:16` |
| `seed` | 否 | 随机种子 |
| `first_frame` / `last_frame` | 否 | `keyframe` 模式的首/尾帧：工作区路径或公网 HTTPS URL |
| `images` | 否 | `reference` 模式的参考图（Flash ≤ 5 张） |
| `audios` | 否 | `reference` 模式的参考音频（Flash ≤ 3 段，需公网 URL） |
| `videos` | 否 | `reference` 模式的参考视频（仅 `agnes-video-2.5`；Flash 会拒绝） |
| `output_path` | 否 | 指定输出路径；缺省为 `agnes-videos/agnes-<video_id>.<ext>` |

工具返回 `path` / `bytes` / `model` / `mode` / `seconds` / `size` / `aspect_ratio` /
`video_id` / `task_id` / `quality` / `url` / `elapsed_ms`。

本地图片会自动转成 Data URI（公网 URL 原样透传）；**音频不做转换**，请给公网可访问的 URL。

## 实现上的要点（含实测观测，2026-10）

- **视频是异步任务，且会等很久。** 实测一条 4 秒 720P 视频从建任务到 `completed` 约
  **152 秒**，状态流转 `pending(0%) → in_progress(10% → 70%) → completed(100%)`。
  `pollTimeoutMs` 默认 15 分钟就是这个原因。
- **建任务会遇到队列满。** 文档未写：队列满时返回 **HTTP 503
  `{"code":"video_queue_full","message":...}`**。插件把它当可重试错误，指数退避重试。
- **免费账号限流很紧，且轮询接口自身也会限流。** 实测建任务常返回 **HTTP 429
  `{"error":{"message":...,"code":"rate_limit_exceeded"}}`**；按文档建议的 2 秒间隔轮询
  会频繁撞上 **HTTP 429 `{"code":429,"message":"查询过于频繁，请稍后重试"}`**（注意此处
  `code` 是**数字**）。因此轮询用自适应间隔：查询成功时缓降回 `pollIntervalMs`，
  被限流则指数退避到 `pollMaxIntervalMs`。
- **错误体有三种形状**，插件逐一解析：`{code,message}`、`{error:{message,code}}`、
  `{code:<number>,message}`；Flash 的参数校验失败则是 `{detail}`。
- **完成响应里 `internal_status`/`internal_progress` 不可用于判断完成**（文档明确），
  插件只看 `status` 与 `progress`，完成后取顶层 `url`。
- **轮询必须带 `model_name`**：`keyframe` 与 `reference` 模式必需，官方建议所有模式都带。
- **Flash 专属限制**在插件里前置校验（不发请求）：`size` 只能是 `720P`、`images` ≤ 5、
  `audios` ≤ 3、不接受 `videos`。这样能省下一次真实请求与一次限流配额。
- **落盘不能用 `ctx.fs.writeText`**：它按 UTF-8 编码，无法写任意二进制（`0x89` 会变成
  `c2 89`）。字节走共享层的 `writeBytesAtomic`（`node:fs` + 同目录 staging + rename），
  写完用 `ctx.fs.readBytes` 读回逐字节校验。代价是绕过了 fs 沙箱的写入围栏 —— 路径仍由
  `ctx.fs.resolve()` 锚定在会话工作区，但这层约束是代码自觉而非沙箱强制。
- **省略 `writeText` 的按调用策略会被拒。** 沙箱部署下策略的工作区根默认是应用安装目录，
  插件需要把会话 cwd 作为工作区根（`resolve` 的 `cwd` 兜底）。
- 插件不 import 任何 `@deepseek-ai/*` 包 —— profile 的 `node_modules` 里解析不到它们，
  这是刻意的设计。

## 验证

```powershell
# 本地契约测试（不依赖外网）：请求契约、503/429 退避、轮询限流恢复、模式校验、
# Flash 限制、字节保真落盘、工具 schema、生命周期
node test/verify-local.mjs
```

实测结果（2026-10-06）：本地 **44/44 通过**；真实 API 端到端跑通一遍
（建任务被 503 拒 → 退避成功 → 轮询 152 秒 → 下载 3,002,159 字节 MP4，魔数 `ftypisom`）。

真实契约探针留在 `../agnes-videos/probe-video-api.mjs`，改 API 用法前可以先跑它。

## 排查记录：为什么一开始调不通

与图像插件同源：本机系统 DNS 会把 `api.agnes-ai.cn` 解析到一个证书不含 DNS SAN 的坏地址
（观测到 `103.73.220.77`），且该域名还有坏掉的 AAAA 路径。多个公共解析器
（`223.5.5.5`、`223.6.6.6`、`119.29.29.29`、`8.8.4.4`）一致给出正确地址
`111.7.87.222`。因此共享层默认「可信公共 DNS + IPv4 优先 + 多地址重试」。
