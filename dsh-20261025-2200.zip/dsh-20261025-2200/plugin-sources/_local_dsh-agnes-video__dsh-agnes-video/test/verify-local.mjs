/**
 * dsh-agnes-video 本地契约测试（不依赖外网、不需要真实队列）。
 *
 * 起一个回环 HTTP 服务模拟 Agnes 的真实响应形状，覆盖：
 *   1. 建任务请求契约：model/mode/seconds/size/aspect_ratio/n 字段形状
 *   2. 建任务遇到 503 video_queue_full 与 429 rate_limit_exceeded 时必须退避重试
 *   3. 轮询：pending → completed；轮询被 429 限流时必须退避而不是失败
 *   4. 完成响应顶层 url 的下载与**字节保真**落盘
 *   5. 模式校验：text 禁媒体、keyframe 需首/尾帧、reference 需参考素材
 *   6. Flash 专属限制：size 只能是 720P、images <= 5、audios <= 3、不支持 videos
 *   7. 工具声明的 parameters/output 落在 DSH 支持的 JSON Schema 子集内
 *   8. effect 注销会摘掉工具
 *
 * 这些响应形状全部来自 2026-10 对真实 API 的实测（见 agnes-videos/probe-video-api.mjs）。
 */
import { createServer } from 'node:http';
import { mkdir, readFile, rm, stat, writeFile } from 'node:fs/promises';
import { join, resolve as resolvePath, dirname } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const here = dirname(fileURLToPath(import.meta.url));
const packageDir = resolvePath(here, '..');
const scratch = join(packageDir, '.verify-local');
const plugin = await import(pathToFileURL(join(packageDir, 'index.js')).href);

const failures = [];
const checks = [];
function check(label, condition, detail = '') {
  checks.push({ label, ok: Boolean(condition), detail });
  if (!condition) failures.push(`${label}${detail ? ` - ${detail}` : ''}`);
}

/** 一个带 ftyp 魔数的最小 MP4 负载，后接填充字节以便字节校验有意义。 */
const MP4 = Buffer.concat([
  Buffer.from([0x00, 0x00, 0x00, 0x18]),
  Buffer.from('ftypisom', 'ascii'),
  Buffer.from([0x00, 0x00, 0x02, 0x00]),
  Buffer.from('isomiso2avc1mp41', 'ascii'),
  Buffer.alloc(4096, 0xab),
]);

// --- 回环桩服务 ------------------------------------------------------------
const received = [];
const scripted = {
  /** 建任务响应队列：每项 {status, body}；用尽后走内置成功响应。 */
  create: [],
  /** 轮询响应队列：每项 {status, body}；用尽后走 fallbackPoll。 */
  poll: [],
  fallbackPoll: null,
};

const server = createServer((request, response) => {
  const chunks = [];
  request.on('data', (chunk) => chunks.push(chunk));
  request.on('end', () => {
    // 桩服务绝不允许把异常抛穿：一次未捕获的回调异常会让后续请求挂住，
    // 表现为被测插件「轮询超时」，从而掩盖真正的断言失败。
    try {
      handle(request, response, Buffer.concat(chunks));
    } catch (error) {
      response.writeHead(500, { 'Content-Type': 'application/json' });
      response.end(JSON.stringify({ detail: `stub failure: ${error.message}` }));
    }
  });
});

function handle(request, response, body) {
    const url = new URL(request.url, 'http://127.0.0.1');
    received.push({ method: request.method, path: url.pathname, query: url.searchParams, body });

    const send = (status, payload) => {
      response.writeHead(status, { 'Content-Type': 'application/json' });
      response.end(typeof payload === 'string' ? payload : JSON.stringify(payload));
    };

    if (url.pathname === '/v1/videos') {
      const next = scripted.create.shift();
      if (next !== undefined) return send(next.status, next.body);
      return send(200, {
        id: 'task_stub',
        task_id: 'task_stub',
        video_id: 'video_stub',
        object: 'video',
        model: 'agnes-video-2.5-flash',
        status: 'queued',
        progress: 0,
        seconds: '4',
        size: '720P',
        quality: 'standard',
      });
    }
    if (url.pathname === '/agnesapi') {
      const next = scripted.poll.shift();
      if (next !== undefined) return send(next.status, next.body);
      return send(200, scripted.fallbackPoll ?? completedPoll());
    }
    if (url.pathname === '/download/finished.mp4') {
      response.writeHead(200, { 'Content-Type': 'video/mp4' });
      return response.end(MP4);
    }
    return send(404, { detail: 'not found' });
}

await new Promise((done) => server.listen(0, '127.0.0.1', done));
const port = server.address().port;

/**
 * 完成态的轮询响应体（**就是响应体本身**，不要再包一层 {status, body}）。
 *
 * 注意区分两种对象：`scripted.poll` / `scripted.create` 的条目是
 * `{ status: <HTTP 码>, body: <响应体> }`（桩会解包成 HTTP 码 + 响应体）；而
 * `fallbackPoll` 直接就是响应体，所以它的 `status` 字段是**任务状态**
 * （pending/in_progress/completed/failed）。把两者混淆会让 `send(200, ...)`
 * 把包装对象原样发到线上，客户端读到的 status 就成了 HTTP 码 200。
 */
function completedPoll(seconds = '4') {
  return {
    status: 'completed',
    progress: 100,
    url: `http://127.0.0.1:${port}/download/finished.mp4`,
    seconds,
    size: '720P',
    quality: 'standard',
  };
}
scripted.fallbackPoll = completedPoll();

// --- 假 ctx ---------------------------------------------------------------
// 每次 apply 建立一套独立的生命周期状态：工具定义、effect 回调、注销标记。
// 共用一个可变变量会让「第二次 apply 覆盖第一次」变成隐蔽的测试假象。
const fsStub = {
  async resolve(requested, options = {}) {
    const absolute = resolvePath(options.cwd ?? process.cwd(), requested);
    return { displayPath: absolute, targetKey: absolute };
  },
  async stat(target) {
    const info = await stat(target.targetKey).catch(() => undefined);
    return info?.isFile() ? { type: 'file' } : undefined;
  },
  async readBytes(target) { return readFile(target.targetKey); },
  async writeText(target, content) {
    await mkdir(dirname(target.targetKey), { recursive: true });
    await writeFile(target.targetKey, content, 'utf8');
    return { operation: 'create', version: 'v1', before: null, after: content };
  },
};

/**
 * 建立一套插件生命周期上下文。
 * @param config - 传给 apply 的行配置。
 * @returns {{ definition: object, dispose: Function, isDisposed: Function, effectRegistered: Function }}
 */
function mountPlugin(config) {
  const state = { definition: undefined, effect: undefined, disposed: false };
  const ctx = {
    tools: {
      register: (definition) => {
        state.definition = definition;
        return () => { state.disposed = true; };
      },
    },
    // 与 Cordis 一致：effect 的返回值是**注销函数**，不是立刻执行的 disposer。
    // 直接 `return callback()` 会把插件的内层 disposer 暴露成 effect 本身，
    // 让「注销」断言变成假象。
    effect: (callback) => {
      const disposer = callback();
      state.effect = () => { disposer?.(); };
      return state.effect;
    },
    fs: fsStub,
  };
  plugin.apply(ctx, config);
  return {
    get definition() { return state.definition; },
    get disposed() { return state.disposed; },
    get effect() { return state.effect; },
    /** 触发插件的注销 effect（即外层 disposer 执行）。 */
    dispose() { state.effect?.(); },
  };
}

const APPLY_CONFIG = {
  apiKey: 'sk-local-test-key',
  baseUrl: `http://127.0.0.1:${port}`,
  model: 'agnes-video-2.5-flash',
  outputDir: 'agnes-videos',
  // 把地址钉定到回环地址，测试不依赖 DNS。
  resolveAddress: '127.0.0.1',
  timeoutMs: 5000,
  pollIntervalMs: 20,
  pollMaxIntervalMs: 60,
  pollTimeoutMs: 8000,
  submitRetryMs: 4000,
  maxOutputBytes: 64 * 1024 * 1024,
};
const mounted = mountPlugin(APPLY_CONFIG);
const registered = mounted.definition;

const exec = {
  name: 'agnes_video_generate',
  callId: 'local-video-1',
  signal: new AbortController().signal,
  agent: { session: { header: { cwd: scratch } } },
};

// --- 1. 工具声明 ----------------------------------------------------------
check('注册了 agnes_video_generate 工具', registered?.name === 'agnes_video_generate', registered?.name);
check('prompt 是必填参数',
  Array.isArray(registered?.parameters?.required) && registered.parameters.required.includes('prompt'),
  JSON.stringify(registered?.parameters?.required));

const ALLOWED_KEYWORDS = new Set([
  'type', 'properties', 'required', 'additionalProperties', 'items', 'enum', 'const',
  'oneOf', 'description',
]);
function scanSchema(node, path) {
  const offenders = [];
  if (node === null || typeof node !== 'object' || Array.isArray(node)) return offenders;
  for (const [key, value] of Object.entries(node)) {
    if (!ALLOWED_KEYWORDS.has(key)) offenders.push(`${path}.${key}`);
    if (key === 'properties' && value !== null && typeof value === 'object') {
      for (const [childName, child] of Object.entries(value)) offenders.push(...scanSchema(child, `${path}.${childName}`));
    }
    if (key === 'items') offenders.push(...scanSchema(value, `${path}[]`));
    if (key === 'oneOf' && Array.isArray(value)) {
      value.forEach((child, index) => offenders.push(...scanSchema(child, `${path}.oneOf[${index}]`)));
    }
  }
  return offenders;
}
const paramOffenders = scanSchema(registered?.parameters, 'parameters');
const outputOffenders = scanSchema(registered?.output?.schema, 'output');
check('parameters 落在受支持的 JSON Schema 子集内', paramOffenders.length === 0, paramOffenders.join(', '));
check('output.schema 落在受支持的 JSON Schema 子集内', outputOffenders.length === 0, outputOffenders.join(', '));

await mkdir(scratch, { recursive: true });

// --- 2. 建任务：503 队列满 -> 429 限流 -> 成功，必须退避重试 --------------
scripted.create.push(
  { status: 503, body: { code: 'video_queue_full', message: '视频队列已满，请稍后重试', data: null } },
  { status: 429, body: { error: { message: '您已达到免费用户的 API 速率限制。', type: 'AgnesAI_error', code: 'rate_limit_exceeded' } } },
);
const submitStarted = Date.now();
const first = await registered.execute({ prompt: '一只蓝色小鲸鱼在深海中游动', seconds: '4' }, exec);
const submitElapsed = Date.now() - submitStarted;
check('建任务在 503/429 后退避重试并最终成功', first?.video_id === 'video_stub', String(first?.video_id));
check('重试确实发生了等待（不是立刻重发）', submitElapsed >= 40, `${submitElapsed}ms`);
const createCalls = received.filter((entry) => entry.path === '/v1/videos');
check('建任务共发出 3 次请求（2 次失败 + 1 次成功）', createCalls.length === 3, String(createCalls.length));

const firstBody = JSON.parse(createCalls[0].body.toString('utf8'));
check('body.model 正确', firstBody.model === 'agnes-video-2.5-flash', firstBody.model);
check('body.mode 默认 text', firstBody.mode === 'text', firstBody.mode);
check('body.seconds 透传为字符串', firstBody.seconds === '4', JSON.stringify(firstBody.seconds));
check('body.size 默认 720P', firstBody.size === '720P', firstBody.size);
check('body.aspect_ratio 默认 16:9', firstBody.aspect_ratio === '16:9', firstBody.aspect_ratio);
check('body.n 固定为 1', firstBody.n === 1, JSON.stringify(firstBody.n));
check('text 模式不夹带任何媒体字段',
  ['first_frame', 'last_frame', 'images', 'audios', 'videos'].every((field) => firstBody[field] === undefined),
  JSON.stringify(firstBody));

// --- 3. 轮询：被 429 限流后仍要拿到 completed ------------------------------
scripted.poll.push(
  { status: 200, body: { status: 'pending', progress: 0 } },
  { status: 429, body: { code: 429, message: '查询过于频繁，请稍后重试' } },
  { status: 200, body: { status: 'pending', progress: 40 } },
);
const pollResult = await registered.execute({ prompt: '第二次调用', output_path: 'agnes-videos/second.mp4' }, exec);
const pollCalls = received.filter((entry) => entry.path === '/agnesapi');
check('轮询带上 video_id 与 model_name',
  pollCalls[0]?.query.get('video_id') === 'video_stub'
  && pollCalls[0]?.query.get('model_name') === 'agnes-video-2.5-flash',
  pollCalls[0]?.query?.toString());
check('被 429 限流后轮询继续而不是失败', pollResult?.video_id === 'video_stub', String(pollResult?.video_id));
check('轮询次数 >= 4（pending、429、pending、completed）', pollCalls.length >= 4, String(pollCalls.length));

// --- 4. 落盘字节保真 ------------------------------------------------------
const videoPath = pollResult?.path ?? '';
const written = videoPath === '' ? undefined : await readFile(videoPath).catch(() => undefined);
check('视频被下载到工作区', written !== undefined, videoPath);
check('落盘字节与生成结果一致', written?.equals(MP4) === true, `${written?.length} vs ${MP4.length}`);
check('返回 bytes 与实际一致', pollResult?.bytes === MP4.length, String(pollResult?.bytes));
check('输出扩展名按容器魔数判定为 .mp4', videoPath.endsWith('.mp4'), videoPath);
check('返回了顶层 url', typeof pollResult?.url === 'string' && pollResult.url.startsWith('http'), pollResult?.url);
check('elapsed_ms 是整数', Number.isInteger(pollResult?.elapsed_ms), String(pollResult?.elapsed_ms));

// --- 5. 模式与 Flash 限制校验（不应发出建任务请求）-----------------------
const beforeValidation = received.filter((entry) => entry.path === '/v1/videos').length;
const EXPECTED_REJECTIONS = [
  ['text 模式带 images 被拒', { prompt: 'x', images: ['https://example.com/a.png'] }],
  ['keyframe 缺首尾帧被拒', { prompt: 'x', mode: 'keyframe' }],
  ['keyframe 带 images 被拒', { prompt: 'x', mode: 'keyframe', first_frame: 'https://example.com/a.png', images: ['https://example.com/b.png'] }],
  ['reference 无参考素材被拒', { prompt: 'x', mode: 'reference' }],
  ['reference 带 first_frame 被拒', { prompt: 'x', mode: 'reference', first_frame: 'https://example.com/a.png', images: ['https://example.com/b.png'] }],
  ['Flash 拒绝非 720P', { prompt: 'x', size: '1080P' }],
  ['Flash 拒绝参考视频', { prompt: 'x', mode: 'reference', videos: [{ url: 'https://example.com/v.mp4' }] }],
  ['images 超过 5 张被拒', {
    prompt: 'x',
    mode: 'reference',
    images: [
      'https://example.com/a.png', 'https://example.com/b.png', 'https://example.com/c.png',
      'https://example.com/d.png', 'https://example.com/e.png', 'https://example.com/f.png',
    ],
  }],
  ['audios 超过 3 段被拒', {
    prompt: 'x',
    mode: 'reference',
    audios: ['https://e.com/1.mp3', 'https://e.com/2.mp3', 'https://e.com/3.mp3', 'https://e.com/4.mp3'],
  }],
  ['空 prompt 被拒', { prompt: '   ' }],
];
for (const [label, args] of EXPECTED_REJECTIONS) {
  let rejected = false;
  let message = '';
  try {
    await registered.execute(args, exec);
  } catch (error) {
    rejected = true;
    message = error.message;
  }
  check(label, rejected, message.slice(0, 120));
}
const afterValidation = received.filter((entry) => entry.path === '/v1/videos').length;
check('校验失败时不发出建任务请求', afterValidation === beforeValidation, String(afterValidation - beforeValidation));

// --- 6. keyframe 模式：本地首帧图走 Data URI ------------------------------
const inputImage = join(scratch, 'frame.png');
await writeFile(inputImage, Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]));
scripted.fallbackPoll = completedPoll('5');
await registered.execute(
  { prompt: '从首帧自然转场', mode: 'keyframe', first_frame: 'frame.png', seconds: '5' },
  exec,
);
const keyframeBody = JSON.parse(received.filter((entry) => entry.path === '/v1/videos').at(-1).body.toString('utf8'));
check('keyframe 传了 mode', keyframeBody.mode === 'keyframe', keyframeBody.mode);
check('本地首帧图被编码为 Data URI',
  typeof keyframeBody.first_frame === 'string' && keyframeBody.first_frame.startsWith('data:image/png;base64,'),
  String(keyframeBody.first_frame).slice(0, 40));
check('keyframe 不夹带 images/audios/videos',
  keyframeBody.images === undefined && keyframeBody.audios === undefined && keyframeBody.videos === undefined,
  JSON.stringify(keyframeBody));

// --- 7. reference 模式：公网 URL 原样透传 ---------------------------------
scripted.fallbackPoll = completedPoll('5');
await registered.execute(
  {
    prompt: '以 <Picture 1> 为风格参考',
    mode: 'reference',
    images: ['https://example.com/style.png'],
    audios: ['https://example.com/beat.mp3'],
  },
  exec,
);
const refBody = JSON.parse(received.filter((entry) => entry.path === '/v1/videos').at(-1).body.toString('utf8'));
check('reference 公网图片 URL 原样透传', refBody.images?.[0] === 'https://example.com/style.png', JSON.stringify(refBody.images));
check('reference 音频 URL 原样透传', refBody.audios?.[0] === 'https://example.com/beat.mp3', JSON.stringify(refBody.audios));

// --- 8. 失败任务 ----------------------------------------------------------
scripted.poll.length = 0;
scripted.fallbackPoll = { status: 'failed', progress: 100, error: { message: 'Invalid reference media' } };
const pollsBeforeFailed = received.filter((entry) => entry.path === '/agnesapi').length;
let failedMessage = '';
try {
  await registered.execute({ prompt: '会失败的任务', output_path: 'agnes-videos/failed.mp4' }, exec);
} catch (error) {
  failedMessage = error.message;
}
if (process.env.DEBUG_POLL === '1') {
  const after = received.filter((entry) => entry.path === '/agnesapi').slice(pollsBeforeFailed);
  console.log(`\n[debug] failed 用例轮询 ${after.length} 次；实际报错：${failedMessage.slice(0, 200)}\n`);
}
check('failed 状态转成带原因的报错', failedMessage.includes('Invalid reference media'), failedMessage.slice(0, 120));

// --- 9. 轮询超时后给出可续查的 video_id -----------------------------------
scripted.fallbackPoll = { status: 'pending', progress: 10 };
const shortBudget = mountPlugin({
  ...APPLY_CONFIG,
  pollIntervalMs: 10,
  pollMaxIntervalMs: 20,
  pollTimeoutMs: 150,
});
let timeoutMessage = '';
try {
  await shortBudget.definition.execute({ prompt: '超时任务' }, exec);
} catch (error) {
  timeoutMessage = error.message;
}
check('轮询超时报错里带上 video_id 便于续查',
  timeoutMessage.includes('video_stub') && timeoutMessage.includes('/agnesapi'),
  timeoutMessage.slice(0, 160));

// --- 10. 生命周期 ---------------------------------------------------------
check('注册被包在 effect 里', typeof mounted.effect === 'function');
check('注销前工具未被摘掉', mounted.disposed === false, String(mounted.disposed));
mounted.dispose();
check('注销 effect 会摘掉工具', mounted.disposed === true, String(mounted.disposed));

server.close();
await rm(scratch, { recursive: true, force: true });

// --- 结果 -----------------------------------------------------------------
for (const entry of checks) {
  console.log(`${entry.ok ? 'PASS' : 'FAIL'}  ${entry.label}${entry.ok || !entry.detail ? '' : ` - ${entry.detail}`}`);
}
console.log(`\n${checks.length - failures.length}/${checks.length} 通过`);
if (failures.length > 0) {
  console.log('\n失败项：');
  for (const failure of failures) console.log(`  - ${failure}`);
  process.exit(1);
}
