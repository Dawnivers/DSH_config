/**
 * 用无头 Edge/Chrome 的 DevTools Protocol 从视频抽帧，便于人工核对画面。
 *
 * 为什么不用 `--screenshot` + `--virtual-time-budget`：那会把虚拟时间快进，
 * 视频解码跟不上，页面还没 seek 到就截图了（实测超时）。这里改为：
 *   1) 本地 HTTP 服务提供视频与页面（避免 file:// 与 data URI 的体积/跨域问题）
 *   2) 页面 seek 到目标时间并画到 canvas，把状态写进 document.title
 *   3) 通过 CDP 轮询 title，就绪后 Page.captureScreenshot
 *
 * 用法：node extract-frames.mjs <视频路径> <输出目录> <秒数...>
 */
import { createServer } from 'node:http';
import { readFile, mkdir, writeFile } from 'node:fs/promises';
import { spawn } from 'node:child_process';
import { existsSync } from 'node:fs';
import { mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { basename, extname, join, resolve } from 'node:path';

const [videoArg, outDirArg, ...secondsArgs] = process.argv.slice(2);
if (videoArg === undefined || outDirArg === undefined) {
  console.error('用法: node extract-frames.mjs <视频路径> <输出目录> <秒数...>');
  process.exit(2);
}
const videoPath = resolve(videoArg);
const outDir = resolve(outDirArg);
const seconds = secondsArgs.length > 0 ? secondsArgs.map(Number) : [0.5, 4, 7];

const BROWSERS = [
  'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
  'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
  'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
  'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
];
const browser = BROWSERS.find((p) => existsSync(p));
if (browser === undefined) {
  console.error('找不到 Edge 或 Chrome');
  process.exit(2);
}

const videoBytes = await readFile(videoPath);
const mime = extname(videoPath).toLowerCase() === '.webm' ? 'video/webm' : 'video/mp4';

/** 页面：seek 到 window.__TARGET 秒后把该帧画到 canvas。 */
const PAGE = `<!doctype html><html><head><meta charset="utf-8"><style>
html,body{margin:0;padding:0;background:#101014;overflow:hidden}
canvas{display:block;width:100vw;height:auto}
</style></head><body>
<script>
const params = new URLSearchParams(location.search);
const TARGET = Number(params.get('t') || 0);
document.title = 'LOADING';
const video = document.createElement('video');
video.muted = true;
video.playsInline = true;
video.preload = 'auto';
video.src = '/video';

video.addEventListener('loadedmetadata', () => {
  const t = Math.min(TARGET, Math.max(0, video.duration - 0.06));
  video.currentTime = t;
});
video.addEventListener('seeked', () => {
  try {
    const canvas = document.createElement('canvas');
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    canvas.getContext('2d').drawImage(video, 0, 0, canvas.width, canvas.height);
    document.body.innerHTML = '';
    document.body.appendChild(canvas);
    document.title = 'READY ' + canvas.width + 'x' + canvas.height;
  } catch (e) {
    document.title = 'ERROR ' + e;
  }
});
video.addEventListener('error', () => {
  document.title = 'ERROR video ' + (video.error && video.error.code);
});
setTimeout(() => { if (document.title === 'LOADING') document.title = 'ERROR timeout'; }, 45000);
</script></body></html>`;

// --- 本地服务 -------------------------------------------------------------
const server = createServer((req, res) => {
  const url = new URL(req.url, 'http://127.0.0.1');
  if (url.pathname === '/video') {
    const range = req.headers.range;
    if (typeof range === 'string' && /^bytes=/.test(range)) {
      const [startText, endText] = range.replace('bytes=', '').split('-');
      const start = Number(startText) || 0;
      const end = endText ? Number(endText) : videoBytes.length - 1;
      const chunk = videoBytes.subarray(start, end + 1);
      res.writeHead(206, {
        'Content-Type': mime,
        'Content-Range': `bytes ${start}-${end}/${videoBytes.length}`,
        'Accept-Ranges': 'bytes',
        'Content-Length': chunk.length,
      });
      res.end(chunk);
      return;
    }
    res.writeHead(200, {
      'Content-Type': mime,
      'Accept-Ranges': 'bytes',
      'Content-Length': videoBytes.length,
    });
    res.end(videoBytes);
    return;
  }
  res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
  res.end(PAGE);
});

await new Promise((r) => server.listen(0, '127.0.0.1', r));
const port = server.address().port;
const base = `http://127.0.0.1:${port}`;
console.log(`视频 ${basename(videoPath)} ${(videoBytes.length / 1048576).toFixed(2)} MB，服务 ${base}`);

// --- 启动无头浏览器（CDP） ------------------------------------------------
const work = await mkdtemp(join(tmpdir(), 'agnes-frames-'));
const DEBUG_PORT = 9333;
const child = spawn(browser, [
  '--headless=new',
  '--disable-gpu',
  '--hide-scrollbars',
  '--no-first-run',
  '--no-default-browser-check',
  `--user-data-dir=${join(work, 'profile')}`,
  `--remote-debugging-port=${DEBUG_PORT}`,
  '--window-size=1280,720',
  'about:blank',
], { stdio: 'ignore' });

/** 等待 CDP 端点就绪，返回 webSocketDebuggerUrl。 */
async function waitForCdp() {
  for (let i = 0; i < 60; i += 1) {
    try {
      const res = await fetch(`http://127.0.0.1:${DEBUG_PORT}/json/version`);
      const info = await res.json();
      if (typeof info.webSocketDebuggerUrl === 'string') return info.webSocketDebuggerUrl;
    } catch {
      // 还没起来
    }
    await new Promise((r) => setTimeout(r, 500));
  }
  throw new Error('CDP 端点未就绪');
}

const wsUrl = await waitForCdp();
console.log('CDP 就绪');

/** 一个极简 CDP 会话。 */
class Cdp {
  #ws;
  #id = 0;
  #pending = new Map();

  static async connect(url) {
    const cdp = new Cdp();
    cdp.#ws = new WebSocket(url);
    await new Promise((res, rej) => {
      cdp.#ws.addEventListener('open', res, { once: true });
      cdp.#ws.addEventListener('error', rej, { once: true });
    });
    cdp.#ws.addEventListener('message', (event) => {
      const msg = JSON.parse(event.data);
      if (msg.id !== undefined && cdp.#pending.has(msg.id)) {
        const { resolve: res, reject: rej } = cdp.#pending.get(msg.id);
        cdp.#pending.delete(msg.id);
        if (msg.error) rej(new Error(msg.error.message));
        else res(msg.result);
      }
    });
    return cdp;
  }

  send(method, params = {}, sessionId) {
    const id = ++this.#id;
    return new Promise((res, rej) => {
      this.#pending.set(id, { resolve: res, reject: rej });
      this.#ws.send(JSON.stringify({ id, method, params, ...(sessionId ? { sessionId } : {}) }));
    });
  }

  close() { this.#ws.close(); }
}

const cdp = await Cdp.connect(wsUrl);

/** 取当前活动页面的 targetId。 */
async function pageTarget() {
  for (let i = 0; i < 30; i += 1) {
    const res = await fetch(`http://127.0.0.1:${DEBUG_PORT}/json/list`);
    const list = await res.json();
    const page = list.find((entry) => entry.type === 'page');
    if (page) return page;
    await new Promise((r) => setTimeout(r, 300));
  }
  throw new Error('找不到页面 target');
}

const target = await pageTarget();
const attached = await cdp.send('Target.attachToTarget', { targetId: target.id, flatten: true });
const sessionId = attached.sessionId;
await cdp.send('Page.enable', {}, sessionId);
await cdp.send('Runtime.enable', {}, sessionId);

async function titleOf() {
  const result = await cdp.send('Runtime.evaluate', {
    expression: 'document.title', returnByValue: true,
  }, sessionId);
  return String(result.result?.value ?? '');
}

await mkdir(outDir, { recursive: true });
let failed = 0;

for (const t of seconds) {
  await cdp.send('Page.navigate', { url: `${base}/?t=${t}` }, sessionId);
  let title = '';
  for (let i = 0; i < 120; i += 1) {
    await new Promise((r) => setTimeout(r, 500));
    title = await titleOf();
    if (title.startsWith('READY') || title.startsWith('ERROR')) break;
  }
  const pngPath = join(outDir, `${basename(videoPath, extname(videoPath))}-t${t}.png`);
  if (title.startsWith('READY')) {
    const shot = await cdp.send('Page.captureScreenshot', { format: 'png' }, sessionId);
    await writeFile(pngPath, Buffer.from(shot.data, 'base64'));
    console.log(`t=${t}s -> ${pngPath}  (${title})`);
  } else {
    console.log(`t=${t}s -> 失败: ${title}`);
    failed += 1;
  }
}

cdp.close();
child.kill();
server.close();
await rm(work, { recursive: true, force: true });
process.exit(failed > 0 ? 1 : 0);
