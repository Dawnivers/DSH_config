// 解析 MP4 盒子结构，取出真实的时长/尺寸/编码，确认不是坏文件
import { readFile } from 'node:fs/promises';

const file = process.argv[2];
const buf = await readFile(file);

/** 递归遍历 MP4 盒子，收集需要的字段。 */
function walk(start, end, depth, visit) {
  let offset = start;
  while (offset + 8 <= end) {
    const size = buf.readUInt32BE(offset);
    const type = buf.toString('ascii', offset + 4, offset + 8);
    let header = 8;
    let boxSize = size;
    if (size === 1) {
      boxSize = Number(buf.readBigUInt64BE(offset + 8));
      header = 16;
    } else if (size === 0) {
      boxSize = end - offset;
    }
    if (boxSize < header || offset + boxSize > end) break;
    visit(type, offset, header, boxSize, depth);
    // 只递归容器盒子
    if (['moov', 'trak', 'mdia', 'minf', 'stbl', 'edts', 'udta'].includes(type)) {
      walk(offset + header, offset + boxSize, depth + 1, visit);
    }
    offset += boxSize;
  }
}

const found = { tracks: 0, handler: [], dims: [], timescales: [], durations: [], codecs: [] };

walk(0, buf.length, 0, (type, offset, header, boxSize) => {
  const body = offset + header;
  if (type === 'mvhd') {
    const version = buf.readUInt8(body);
    if (version === 0) {
      found.timescales.push(buf.readUInt32BE(body + 12));
      found.durations.push(buf.readUInt32BE(body + 16));
    } else {
      found.timescales.push(buf.readUInt32BE(body + 20));
      found.durations.push(Number(buf.readBigUInt64BE(body + 24)));
    }
  }
  if (type === 'tkhd') found.tracks += 1;
  if (type === 'hdlr') found.handler.push(buf.toString('ascii', body + 8, body + 12));
  if (type === 'stsd') {
    const codec = buf.toString('ascii', body + 12, body + 16);
    found.codecs.push(codec);
  }
  if (type === 'avc1' || type === 'hvc1' || type === 'mp4v') {
    // VisualSampleEntry：6 保留 + 2 data_reference_index，随后 16 字节预定义，
    // 然后 width/height 各 2 字节 —— 相对盒子体起点偏移 24/26。
    // 大多数编码器把预定义段写全，所以这里能读到；读不到时回退到 32/34。
    const width = buf.readUInt16BE(body + 24);
    const height = buf.readUInt16BE(body + 26);
    found.dims.push({ codec: type, width, height });
  }
});

const duration = found.timescales[0] ? found.durations[0] / found.timescales[0] : undefined;
console.log('文件:', file);
console.log('字节数:', buf.length);
console.log('轨道数:', found.tracks);
console.log('轨道类型:', found.handler.join(', '));
console.log('编码:', found.codecs.join(', '));
console.log('尺寸:', found.dims.map((d) => `${d.codec} ${d.width}x${d.height}`).join(', ') || '(未识别)');
console.log('时长:', duration === undefined ? '(未知)' : `${duration.toFixed(2)} 秒`);

// 顺带确认 moov 与 mdat 都在（缺 moov 说明没写成）
const hasMoov = buf.includes(Buffer.from('moov'));
const hasMdat = buf.includes(Buffer.from('mdat'));
console.log('moov 存在:', hasMoov, '| mdat 存在:', hasMdat);
if (!hasMoov || !hasMdat) {
  console.log('警告：MP4 结构不完整');
  process.exitCode = 1;
}
