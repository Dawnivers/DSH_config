/**
 * Agnes Video 2.5 Flash 视频生成工具。
 *
 * 异步任务契约（https://www.agnes-ai.cn/zh-Hans/docs/agnes-video-25-flash）：
 *   POST {baseUrl}/v1/videos          建任务，响应含 video_id
 *   GET  {baseUrl}/agnesapi?video_id=<ID>&model_name=<MODEL>
 *                                     轮询；status 为 completed/failed 即结束，
 *                                     完成后顶层 url 是可下载的视频地址
 *
 * 两个实测观测（文档未写，2026-10）：
 *   - 建任务可能返回 **HTTP 503 `{"code":"video_queue_full"}`**（队列已满）；
 *   - 免费账号很容易撞上 **HTTP 429 `{"error":{...,"code":"rate_limit_exceeded"}}`**。
 *   两者都是可重试的，插件按指数退避重试，直到 submitRetryMs 预算耗尽。
 *
 * 只使用 Node 内置能力与共享层 `@local/dsh-agnes-core`，不 import 任何
 * `@deepseek-ai/*` 包。
 */

import {
  DEFAULT_DNS_SERVERS,
  fetchWithFallback,
  extensionFor,
  listConfig,
  numberConfig,
  resolveInputImage,
  stringList,
  textConfig,
  videoExtensionFromMagic,
  writeBytesAtomic,
} from '@local/dsh-agnes-core';

/** 分辨率档位。Flash 只接受 720P。 */
const SIZE_GRADES = ['720P', '1080P', '1K', '2K'];
/** 画幅比例白名单。 */
const ASPECT_RATIOS = ['21:9', '16:9', '4:3', '1:1', '3:4', '9:16'];
/** 时长（秒），文档：字符串 "4"-"12"。 */
const SECONDS = ['4', '5', '6', '7', '8', '9', '10', '11', '12'];
/** 生成模式。 */
const MODES = ['text', 'keyframe', 'reference'];
/** 媒体字段，text 模式一律不允许。 */
const MEDIA_FIELDS = ['first_frame', 'last_frame', 'images', 'audios', 'videos'];
/** 模型的 Flash 专属限制：size 固定 720P、图片 ≤5、音频 ≤3、不支持参考视频。 */
const FLASH_LIMITS = { maxImages: 5, maxAudios: 3, allowVideos: false, allowedSizes: ['720P'] };
/** 可重试的 HTTP 状态：限流、队列满、服务端错误。 */
const RETRYABLE_STATUS = new Set([408, 425, 429, 500, 502, 503, 504]);

/** Stable Loader identity. */
export const name = 'agnes-video';

/** Services this plugin needs; it stays inactive without them. */
export const inject = ['tools', 'fs'];

/**
 * Normalize the row config.
 *
 * 刻意不导出 `Config`：Cordis 会把导出的 `Config` 当作 schemastery schema 并调用
 * `Config.validate`，而普通函数会让整行激活失败。字段文档在 config.schema.json。
 * @param config - raw row config from the bundle patch.
 * @returns The normalized config.
 */
function normalizeConfig(config) {
  const source = config !== null && typeof config === 'object' ? config : {};
  return {
    model: textConfig(source.model, 'agnes-video-2.5-flash'),
    baseUrl: textConfig(source.baseUrl, 'https://api.agnes-ai.cn').replace(/\/+$/, ''),
    apiKey: textConfig(source.apiKey, ''),
    defaultSeconds: SECONDS.includes(source.defaultSeconds) ? source.defaultSeconds : '5',
    defaultSize: textConfig(source.defaultSize, '720P'),
    defaultAspectRatio: ASPECT_RATIOS.includes(source.defaultAspectRatio) ? source.defaultAspectRatio : '16:9',
    outputDir: textConfig(source.outputDir, 'agnes-videos'),
    timeoutMs: numberConfig(source.timeoutMs, 180000),
    pollIntervalMs: numberConfig(source.pollIntervalMs, 2000),
    pollMaxIntervalMs: numberConfig(source.pollMaxIntervalMs, 30000),
    pollTimeoutMs: numberConfig(source.pollTimeoutMs, 900000),
    submitRetryMs: numberConfig(source.submitRetryMs, 300000),
    maxOutputBytes: numberConfig(source.maxOutputBytes, 256 * 1024 * 1024),
    preferIPv4: source.preferIPv4 !== false,
    resolveAddress: textConfig(source.resolveAddress, ''),
    // 默认走可信公共解析器：本机系统 DNS 会把该域名解析到坏地址。
    dnsServers: listConfig(source.dnsServers, DEFAULT_DNS_SERVERS),
  };
}

/**
 * Read the session working directory used to resolve relative paths.
 * @param exec - tool execution context.
 * @returns The cwd, or undefined when the session has none.
 */
function sessionCwd(exec) {
  return exec?.agent?.session?.header?.cwd;
}

/**
 * 判断模型是否套用 Flash 的专属限制。
 * @param model - 模型名。
 * @returns 是否为 Flash 系列。
 */
function isFlash(model) {
  return /flash/i.test(model);
}

/**
 * 判断解析出来的某个字段是否是可用的标识（字符串或数字）。
 * @param value - 字段值。
 * @returns 是否为非空字符串或有限数字。
 */
function isIdentifier(value) {
  return (typeof value === 'string' && value.trim() !== '') || Number.isFinite(value);
}

/**
 * 把字段渲染成一行文本。
 * @param value - 字段值。
 * @returns 文本。
 */
function identifierText(value) {
  return typeof value === 'string' ? value.trim() : String(value);
}

/**
 * 从 Agnes 的错误响应体里取出一条可读消息。
 *
 * 实测存在三种形状：
 *   `{code,message}`（视频队列已满）、
 *   `{error:{message,code}}`（速率限制）、
 *   `{code:429,message}`（轮询过于频繁，此处 code 是**数字**）。
 * 建任务的 Flash 参数错误则是 `{detail}`。
 * @param body - 响应体。
 * @returns 消息文本；无法解析时返回原始片段。
 */
function errorMessage(body) {
  try {
    const parsed = JSON.parse(body);
    for (const value of [parsed?.error?.message, parsed?.message, parsed?.detail]) {
      if (typeof value === 'string' && value.trim() !== '') return value.trim();
    }
    for (const value of [parsed?.error?.code, parsed?.code]) {
      if (isIdentifier(value)) return identifierText(value);
    }
    return '';
  } catch {
    return body.slice(0, 300).trim();
  }
}

/**
 * 把 HTTP 失败转成具名原因，并标出是否值得重试。
 * @param status - HTTP 状态码。
 * @param body - 响应体。
 * @returns 错误对象，`retryable` 表示调用方可以退避重试。
 */
function httpFailure(status, body) {
  const detail = errorMessage(body);
  const hint = status === 401 || status === 403
    ? '认证被拒绝：检查 apiKey（或环境变量 AGNES_API_KEY），或该模型是否已开通。'
    : status === 429
      ? '请求被限流（免费账号速率限制较低）：已自动退避重试，仍失败则稍后再试。'
      : status === 503 && /queue_full/i.test(body)
        ? '视频队列已满：已自动退避重试。'
        : status === 404
          ? 'video_id 不存在：确认使用的是创建响应里的 video_id。'
          : status >= 500
            ? '服务端错误：已自动退避重试。'
            : '检查 mode 与媒体字段是否匹配、seconds/size/aspect_ratio 是否合法。';
  const error = new Error(`Agnes 视频请求失败（HTTP ${status}）：${hint}${detail ? ` 响应：${detail}` : ''}`);
  error.retryable = RETRYABLE_STATUS.has(status);
  return error;
}

/**
 * 校验一个值时抛出可读错误。
 * @param condition - 必须为真的条件。
 * @param message - 失败消息。
 */
function assert(condition, message) {
  if (!condition) throw new Error(message);
}

/**
 * 按生成模式规则校验参数组合。
 * @param mode - 生成模式。
 * @param media - 已解析的媒体字段。
 */
function validateMode(mode, media) {
  const present = MEDIA_FIELDS.filter((field) => {
    const value = media[field];
    if (value === undefined || value === null) return false;
    return Array.isArray(value) ? value.length > 0 : true;
  });
  if (mode === 'text') {
    assert(present.length === 0,
      `mode="text" 不接受任何媒体字段，但收到了：${present.join('、')}。要控制首尾帧请用 mode="keyframe"，要用参考素材请用 mode="reference"。`);
    return;
  }
  if (mode === 'keyframe') {
    assert(media.first_frame !== undefined || media.last_frame !== undefined,
      'mode="keyframe" 必须提供 first_frame 或 last_frame 至少一个。');
    const forbidden = present.filter((field) => field !== 'first_frame' && field !== 'last_frame');
    assert(forbidden.length === 0,
      `mode="keyframe" 不接受 ${forbidden.join('、')}；这些属于 mode="reference"。`);
    return;
  }
  assert(media.images.length > 0 || media.audios.length > 0,
    'mode="reference" 必须提供 images 或 audios 至少一类非空。');
  assert(media.first_frame === undefined && media.last_frame === undefined,
    'mode="reference" 不接受 first_frame / last_frame；这些属于 mode="keyframe"。');
}

/**
 * 调用 Agnes 建任务接口，对可重试错误做指数退避。
 * @param config - normalized config.
 * @param body - 建任务请求体。
 * @param exec - tool execution context.
 * @returns 创建任务的响应对象。
 */
async function submitTask(config, body, exec) {
  const started = Date.now();
  const deadline = started + config.submitRetryMs;
  let attempt = 0;
  for (;;) {
    exec.signal.throwIfAborted();
    const response = await fetchWithFallback(config, {
      url: `${config.baseUrl}/v1/videos`,
      method: 'POST',
      headers: {
        Authorization: `Bearer ${resolveApiKey(config)}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(body),
    }, exec.signal);
    const text = response.body.toString('utf8');
    if (response.status >= 200 && response.status < 300) {
      try {
        return JSON.parse(text);
      } catch {
        throw new Error(`Agnes 建任务返回的不是合法 JSON：${text.slice(0, 200)}`);
      }
    }
    const error = httpFailure(response.status, text);
    const remaining = deadline - Date.now();
    if (error.retryable === true && remaining > 0) {
      // 队列满 / 限流：1s、2s、4s… 上限 15s，且不超过剩余预算。
      const wait = Math.min(1000 * 2 ** Math.min(attempt, 4), 15000, remaining);
      attempt += 1;
      await sleep(wait, exec.signal);
      continue;
    }
    throw error;
  }
}

/**
 * 取本次调用要用的 API Key：环境变量优先于行配置。
 * @param config - normalized config.
 * @returns API Key，可能为空串。
 */
function resolveApiKey(config) {
  const fromEnv = typeof process.env.AGNES_API_KEY === 'string' ? process.env.AGNES_API_KEY.trim() : '';
  return fromEnv !== '' ? fromEnv : config.apiKey;
}

/**
 * 可被取消的等待。
 * @param ms - 毫秒。
 * @param signal - 取消信号。
 */
function sleep(ms, signal) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      signal.removeEventListener('abort', onAbort);
      resolve();
    }, ms);
    const onAbort = () => {
      clearTimeout(timer);
      reject(signal.reason ?? new Error('aborted'));
    };
    signal.addEventListener('abort', onAbort, { once: true });
  });
}

/**
 * 轮询任务直到完成或失败。
 *
 * 以 `status` 与 `progress` 为准：文档明确 `internal_status`/`internal_progress`
 * 不可用于判断完成。查询必须带 `model_name`（keyframe 与 reference 模式必需，
 * 官方建议所有模式都带）。
 *
 * **实测：轮询接口自身会限流。** 按文档建议的 2s 间隔查询会立刻命中
 * `HTTP 429 "查询过于频繁，请稍后重试"`，因此这里用自适应间隔：正常查询逐步
 * 收敛回 pollIntervalMs，被限流则指数退避（上限 pollMaxIntervalMs），并且只有
 * 成功拿到状态才算一次有效推进。
 * @param config - normalized config.
 * @param videoId - 创建任务返回的 video_id。
 * @param exec - tool execution context.
 * @returns 最终的查询响应。
 */
async function pollTask(config, videoId, exec) {
  const deadline = Date.now() + config.pollTimeoutMs;
  let last;
  let interval = config.pollIntervalMs;
  for (;;) {
    exec.signal.throwIfAborted();
    const query = new URLSearchParams({ video_id: videoId, model_name: config.model });
    const response = await fetchWithFallback(config, {
      url: `${config.baseUrl}/agnesapi?${query.toString()}`,
      method: 'GET',
      headers: { Authorization: `Bearer ${resolveApiKey(config)}` },
    }, exec.signal);
    const text = response.body.toString('utf8');
    if (response.status >= 200 && response.status < 300) {
      try {
        last = JSON.parse(text);
      } catch {
        throw new Error(`Agnes 查询返回的不是合法 JSON：${text.slice(0, 200)}`);
      }
      if (last.status === 'completed' || last.status === 'failed') return last;
      // 查询成功：间隔缓降到基准，避免持续贴着限流阈值。
      interval = Math.max(config.pollIntervalMs, Math.round(interval / 2));
    } else {
      const error = httpFailure(response.status, text);
      if (error.retryable !== true) throw error;
      interval = Math.min(interval * 2, config.pollMaxIntervalMs);
    }
    if (Date.now() >= deadline) {
      const error = new Error(
        `等待视频生成超过 ${Math.round(config.pollTimeoutMs / 1000)}s 预算。任务未丢失：`
        + `可用 video_id=${videoId} 继续查询 GET ${config.baseUrl}/agnesapi?video_id=${encodeURIComponent(videoId)}&model_name=${encodeURIComponent(config.model)}`,
      );
      error.videoId = videoId;
      error.lastStatus = last?.status;
      throw error;
    }
    await sleep(Math.min(interval, Math.max(0, deadline - Date.now())), exec.signal);
  }
}

/**
 * 注册 Agnes 视频生成工具。
 * @param ctx - agent-scoped services.
 * @param rawConfig - validated row config.
 */
export function apply(ctx, rawConfig) {
  const config = normalizeConfig(rawConfig);

  const disposers = [];
  ctx.effect(() => () => {
    while (disposers.length > 0) disposers.pop()();
  });

  disposers.push(ctx.tools.register({
    name: 'agnes_video_generate',
    description: 'Generate a video with the Agnes Video 2.5 Flash model (asynchronous task: '
      + 'submit, poll, then download the result into the session workspace). '
      + 'Use it for text-to-video, first/last-frame control (`mode: "keyframe"`), and image or audio reference '
      + '(`mode: "reference"`, refer to inputs in the prompt as `<Picture 1>` / `<Audio 1>`). '
      + 'This is asynchronous and may take minutes: the tool submits, polls until the task completes, then downloads. '
      + 'The finished video is returned as a workspace path.',
    timeoutMs: config.pollTimeoutMs + config.submitRetryMs + 120000,
    parameters: {
      type: 'object',
      additionalProperties: false,
      properties: {
        prompt: {
          type: 'string',
          description: 'Video content description. Recommended order: subject and scene, action and change, '
            + 'camera language, visual style, sound and rhythm, consistency requirements. '
            + 'In reference mode, name the placeholders explicitly, e.g. "以 <Picture 1> 为角色参考，跟随 <Audio 1> 的节奏".',
        },
        mode: {
          type: 'string',
          enum: MODES,
          description: 'Generation mode. "text" (默认): prompt only. "keyframe": control with first_frame/last_frame. '
            + '"reference": use images/audios as content, style or rhythm reference.',
        },
        seconds: {
          type: 'string',
          enum: SECONDS,
          description: `Video duration in seconds as a string. Defaults to ${config.defaultSeconds}.`,
        },
        size: {
          type: 'string',
          enum: SIZE_GRADES,
          description: `Output resolution grade. Defaults to ${config.defaultSize}. Flash only accepts 720P; `
            + 'use the agnes-video-2.5 model for 1080P/1K/2K.',
        },
        aspect_ratio: {
          type: 'string',
          enum: ASPECT_RATIOS,
          description: `Aspect ratio. Defaults to ${config.defaultAspectRatio}.`,
        },
        seed: {
          type: 'integer',
          description: 'Random seed; the same seed improves reproducibility.',
        },
        first_frame: {
          type: 'string',
          description: 'First-frame image for mode="keyframe": workspace path, absolute path, or public HTTPS URL.',
        },
        last_frame: {
          type: 'string',
          description: 'Last-frame image for mode="keyframe": workspace path, absolute path, or public HTTPS URL.',
        },
        images: {
          type: 'array',
          items: { type: 'string' },
          description: 'Reference images for mode="reference" (Flash: at most 5). '
            + 'Workspace path, absolute path, or public HTTPS URL.',
        },
        audios: {
          type: 'array',
          items: { type: 'string' },
          description: 'Reference audio for mode="reference" (Flash: at most 3). Must be publicly reachable HTTPS URLs.',
        },
        videos: {
          type: 'array',
          items: {
            type: 'object',
            additionalProperties: false,
            properties: {
              url: { type: 'string', description: 'Publicly reachable reference video URL.' },
              start_seconds: { type: 'number', description: 'Offset to start reading from. Defaults to 0.' },
              require_audio: { type: 'boolean', description: 'Require the reference video to carry an audio track.' },
            },
            required: ['url'],
          },
          description: 'Reference videos for mode="reference" on the agnes-video-2.5 model. '
            + 'Flash rejects any non-empty videos array.',
        },
        output_path: {
          type: 'string',
          description: 'Optional destination file path. Defaults to a file named after the task id under '
            + `"${config.outputDir}"` + ' in the session working directory.',
        },
      },
      required: ['prompt'],
    },
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          path: { type: 'string' },
          bytes: { type: 'integer' },
          model: { type: 'string' },
          mode: { type: 'string' },
          seconds: { type: 'string' },
          size: { type: 'string' },
          aspect_ratio: { type: 'string' },
          video_id: { type: 'string' },
          task_id: { oneOf: [{ type: 'string' }, { type: 'null' }] },
          quality: { oneOf: [{ type: 'string' }, { type: 'null' }] },
          url: { type: 'string' },
          elapsed_ms: { type: 'integer' },
        },
        required: ['path', 'bytes', 'model', 'mode', 'seconds', 'size', 'aspect_ratio', 'video_id', 'url', 'elapsed_ms'],
      },
      render: (_args, value) => [{
        type: 'text',
        text: `Generated video: ${value.path} (${value.bytes} bytes, ${value.model}, ${value.seconds}s ${value.size} ${value.aspect_ratio}, ${Math.round(value.elapsed_ms / 1000)}s elapsed)`,
      }],
    },
    async execute(args, exec) {
      const apiKey = resolveApiKey(config);
      if (apiKey === '') {
        throw new Error('Agnes 视频生成缺少 API Key：在 cordis.patch.yml 的行 config.apiKey 里设置，或设置环境变量 AGNES_API_KEY。');
      }

      const prompt = typeof args.prompt === 'string' ? args.prompt.trim() : '';
      assert(prompt !== '', 'prompt 不能为空。');

      const mode = MODES.includes(args.mode) ? args.mode : 'text';
      const seconds = SECONDS.includes(args.seconds) ? args.seconds : config.defaultSeconds;
      const size = SIZE_GRADES.includes(args.size) ? args.size : config.defaultSize;
      const aspectRatio = ASPECT_RATIOS.includes(args.aspect_ratio) ? args.aspect_ratio : config.defaultAspectRatio;

      const flash = isFlash(config.model);
      const limits = flash ? FLASH_LIMITS : {
        maxImages: 8, maxAudios: 3, allowVideos: true, allowedSizes: ['720P', '1080P', '1K', '2K'],
      };
      assert(limits.allowedSizes.includes(size),
        `${config.model} 只支持 size=${limits.allowedSizes.join('/')}，收到 "${size}"。${flash ? '要更高分辨率请把 config.model 换成 agnes-video-2.5。' : ''}`);

      const cwd = sessionCwd(exec);
      const images = stringList(args.images);
      const audios = stringList(args.audios);
      const videos = Array.isArray(args.videos)
        ? args.videos.filter((entry) => entry !== null && typeof entry === 'object' && typeof entry.url === 'string' && entry.url.trim() !== '')
        : [];
      assert(images.length <= limits.maxImages,
        `images 最多 ${limits.maxImages} 张，收到 ${images.length} 张。`);
      assert(audios.length <= limits.maxAudios,
        `audios 最多 ${limits.maxAudios} 段，收到 ${audios.length} 段。`);
      assert(!(flash && videos.length > 0),
        'agnes-video-2.5-flash 不支持参考视频（videos）：请移除 videos，或把 config.model 换成 agnes-video-2.5。');

      const media = {
        first_frame: undefined,
        last_frame: undefined,
        images: [],
        audios: [],
        videos: [],
      };

      // 本地文件转 Data URI；公网 URL 原样透传。
      for (const field of ['first_frame', 'last_frame']) {
        const value = typeof args[field] === 'string' ? args[field].trim() : '';
        if (value !== '') media[field] = await resolveInputImage(value, ctx, exec, cwd);
      }
      for (const value of images) media.images.push(await resolveInputImage(value, ctx, exec, cwd));
      // 音频不转 Data URI：不做格式嗅探，且文档要求公网可访问。
      media.audios.push(...audios);
      media.videos.push(...videos.map((entry) => ({
        url: entry.url.trim(),
        ...(Number.isFinite(entry.start_seconds) ? { start_seconds: entry.start_seconds } : {}),
        ...(typeof entry.require_audio === 'boolean' ? { require_audio: entry.require_audio } : {}),
      })));

      validateMode(mode, media);

      const body = {
        model: config.model,
        prompt,
        mode,
        seconds,
        size,
        aspect_ratio: aspectRatio,
        n: 1,
      };
      if (Number.isFinite(args.seed)) body.seed = args.seed;
      for (const field of ['first_frame', 'last_frame']) {
        if (media[field] !== undefined) body[field] = media[field];
      }
      if (media.images.length > 0) body.images = media.images;
      if (media.audios.length > 0) body.audios = media.audios;
      if (media.videos.length > 0) body.videos = media.videos;

      const started = Date.now();
      exec.signal.throwIfAborted();
      const created = await submitTask(config, body, exec);
      const videoId = typeof created?.video_id === 'string' && created.video_id !== ''
        ? created.video_id
        : typeof created?.id === 'string' && created.id !== ''
          ? created.id
          : undefined;
      assert(videoId !== undefined,
        `Agnes 建任务响应里没有 video_id：${JSON.stringify(created).slice(0, 300)}`);

      const final = await pollTask(config, videoId, exec);
      if (final.status === 'failed') {
        const message = final?.error?.message ?? JSON.stringify(final?.error ?? {});
        throw new Error(`Agnes 视频任务失败（video_id=${videoId}）：${message}`);
      }
      const url = typeof final?.url === 'string' && final.url !== '' ? final.url : undefined;
      assert(url !== undefined,
        `任务已完成但没有 url（video_id=${videoId}）：${JSON.stringify(final).slice(0, 300)}`);

      const download = await fetchWithFallback(config, { url, method: 'GET', headers: {} }, exec.signal);
      if (download.status < 200 || download.status >= 300) {
        throw new Error(`下载生成结果失败（HTTP ${download.status}）：${url}`);
      }
      const bytes = download.body;
      assert(bytes.byteLength > 0, 'Agnes 返回了 0 字节视频。');
      assert(bytes.byteLength <= config.maxOutputBytes,
        `生成结果 ${bytes.byteLength} 字节，超过 maxOutputBytes=${config.maxOutputBytes}。`);

      const extension = videoExtensionFromMagic(bytes)
        ?? extensionFor(download.headers['content-type'], url, '.mp4');

      const requested = typeof args.output_path === 'string' && args.output_path.trim() !== ''
        ? args.output_path.trim()
        : `${config.outputDir}/agnes-${videoId.replace(/[^A-Za-z0-9_-]/g, '_')}${extension}`;
      const sandboxPolicy = resolvePolicy(exec);
      const target = await ctx.fs.resolve(requested, {
        ...(cwd !== undefined
          ? { cwd }
          : sandboxPolicy?.workspaceRoot !== undefined
            ? { cwd: sandboxPolicy.workspaceRoot }
            : {}),
        signal: exec.signal,
      });

      // ctx.fs 没有二进制写原语（详见 core 的 writeBytesAtomic），字节走 node:fs。
      await writeBytesAtomic(target.displayPath, bytes, exec.signal);

      const written = Buffer.from(await ctx.fs.readBytes(target, exec.signal, config.maxOutputBytes));
      assert(written.byteLength === bytes.byteLength && Buffer.compare(written, bytes) === 0,
        `写入的视频字节与生成结果不一致：期望 ${bytes.byteLength} 字节，实际 ${written.byteLength} 字节。`);

      return {
        path: target.displayPath,
        bytes: bytes.byteLength,
        model: config.model,
        mode,
        seconds: typeof final.seconds === 'string' ? final.seconds : seconds,
        size: typeof final.size === 'string' ? final.size : size,
        aspect_ratio: aspectRatio,
        video_id: videoId,
        task_id: typeof created?.task_id === 'string' ? created.task_id : null,
        quality: typeof final.quality === 'string' ? final.quality : null,
        url,
        elapsed_ms: Date.now() - started,
      };
    },
  }));

  /**
   * 取本次调用的沙箱策略，并把会话 cwd 作为工作区根。
   *
   * 沙箱部署下 `ctx.fs` 是 `dsh-fs-sandbox`；省略按调用策略时后端会退回部署兜底
   * 工作区根（应用安装目录）。这里只用于 `resolve()` 的 cwd 兜底 —— 二进制落盘
   * 走 `writeBytesAtomic`，目标路径仍来自 `ctx.fs.resolve()`。
   * @param exec - tool execution context.
   * @returns 本次调用的策略，或 undefined（非沙箱部署 / 无法解析）。
   */
  function resolvePolicy(exec) {
    try {
      const service = typeof ctx.get === 'function' ? ctx.get('sandboxPolicy') : undefined;
      if (service === undefined) return undefined;
      const session = exec?.agent?.session;
      return session === undefined ? service.resolve() : service.resolve({ session });
    } catch {
      return undefined;
    }
  }
}
