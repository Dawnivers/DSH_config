# dsh-agnes-image

把 **Agnes Image 2.5 Flash**（`agnes-image-2.5-flash`）的生图能力接进 DeepSeek Harness，
以一个 Agent 工具 `agnes_image_generate` 暴露出来。

- 文档：<https://www.agnes-ai.cn/zh-Hans/docs/agnes-image-25-flash>
- Endpoint：`POST https://api.agnes-ai.cn/v1/images/generations`

## 能力

| 工作流 | 用法 |
| --- | --- |
| 文生图 | 只给 `prompt`（+ 可选 `size` / `ratio`） |
| 图生图 | `images: ["工作区路径或 HTTPS URL"]` |
| 多图合成 | `images: [图1, 图2, ...]`（按顺序说明每张图的角色） |

生成结果会**下载到会话工作区**并返回文件路径，Agent 可以直接用 markdown 图片语法展示、
或用 `present` 交付给你。

## 安装

这是一个 DSH bundle（`package.json` 里声明 `dsh.bundle.patch`）。安装用 Desktop 自带的
`dsh` CLI，它会转发给 profile 目录里的 pnpm，并自动把 bundle 登记进
`dsh.profile.bundles`：

```powershell
dsh plugin --profile desktop add "<本目录的绝对路径>"
```

装完 `agnes_image_generate` 会成为可调用工具。**代码改动后需要重启 Harness**：
profile 的 `hmr` 默认不监控模块根目录，而且 `dsh-hmr` 明确忽略 `**/node_modules` 路径
（插件正是从 `profiles\<profile>\node_modules\@local\dsh-agnes-image` 加载的），插件代码不会热重载。

也可以改用 Harness Web GUI 的 **设置 → 插件** 页面安装。

### 依赖解析（必读）

网络层与二进制落盘已抽到共享包 `@local/dsh-agnes-core`（与 `dsh-agnes-video` 共用）。
`package.json` 用 `link:../dsh-agnes-core` 声明该依赖，但 **`dsh plugin add` 不会为 `link:`
目标安装传递依赖**，而 Node 把 junction 解析成真实路径后会从工作区逐级向上找
`node_modules` —— 所以共享包必须由**工作区**提供。工作区根的 `package.json` 已声明它，
需要先装一次：

```powershell
cd "<工作区>"
pnpm install          # 生成 node_modules\@local\dsh-agnes-core
```

换机器或清理 `node_modules` 后要重新执行，否则插件加载时报 `ERR_MODULE_NOT_FOUND`。

## 配置

配置在 `cordis.patch.yml` 的 `agnes-image` 行 `config` 里，字段含义见 `config.schema.json`：

| 字段 | 默认值 | 说明 |
| --- | --- | --- |
| `apiKey` | （patch 中已填） | Agnes API Key；留空则回退到环境变量 `AGNES_API_KEY`，**环境变量优先** |
| `model` | `agnes-image-2.5-flash` | 模型名 |
| `baseUrl` | `https://api.agnes-ai.cn` | API 基地址，便于换域名/网关 |
| `defaultSize` | `2K` | 未显式传 `size` 时的档位（`1K`/`2K`/`3K`/`4K`） |
| `defaultRatio` | `1:1` | 未显式传 `ratio` 时的宽高比 |
| `outputDir` | `agnes-images` | 工作区内保存结果的相对目录 |
| `timeoutMs` | `360000` | 单次生成超时（毫秒），文档建议 60s–360s |
| `maxOutputBytes` | `67108864` | 接受的最大图像字节数 |
| `preferIPv4` | `true` | 只保留 IPv4 候选地址（该域名的 AAAA 路径在部分网络下是坏的） |
| `dnsServers` | `["223.6.6.6","8.8.4.4"]` | 解析 API 与图像下载域名用的公共 DNS；留空数组则用系统解析器 |
| `resolveAddress` | `""` | 钉定 API 域名的 IPv4 地址，绕过被污染的 DNS（仍做正常 TLS 主机名校验） |

### 关于密钥

密钥目前按你的选择写在 `cordis.patch.yml` 里（工作区本地配置文件）。两点提醒：

- 该文件**不要提交到任何仓库**；工作区已附 `.gitignore` 忽略 `cordis.patch.yml`。
- 密钥在本会话对话中出现过，如果这个渠道不够私密，建议去 Agnes 控制台**轮换一次**，
  然后只更新这个文件。

想改成不落盘的方式：给 Windows 设一个用户环境变量即可，插件会优先使用它。

```powershell
[Environment]::SetEnvironmentVariable('AGNES_API_KEY', 'sk-...', 'User')
```

设好后把 patch 里那一行 `apiKey` 删掉。注意：环境变量需要在 Harness 进程启动时就存在，
所以设完要重启 Harness。

## 工具参数

| 参数 | 必填 | 说明 |
| --- | --- | --- |
| `prompt` | 是 | 生成或编辑指令 |
| `size` | 否 | `1K` / `2K` / `3K` / `4K` |
| `ratio` | 否 | `1:1` `3:4` `4:3` `16:9` `9:16` `2:3` `3:2` `21:9` |
| `images` | 否 | 输入图：工作区相对/绝对路径或公网 HTTPS URL；本地文件会自动转成 Data URI |
| `output_path` | 否 | 指定输出文件路径；缺省为 `agnes-images/agnes-<时间戳>.<ext>` |

工具返回 `path` / `bytes` / `model` / `size` / `ratio` / `revised_prompt` / `task_id`。

### 实现上的几个要点

- **不要导出 `Config`**。Cordis 把导出的 `Config` 当作 schemastery schema，会调用
  `Config["~standard"].validate(config)`；普通函数会让整行激活失败并报
  `Cannot read properties of undefined (reading 'validate')`。
  配置校验改为插件内部的 `normalizeConfig()` 普通函数，字段文档放在 `config.schema.json`。
- **不使用 `fetch`**。Node 内置 `fetch`（undici）**忽略 `lookup` 选项**，无法钉定地址，
  而本机系统 DNS 会把 API 域名解析到坏地址。因此网络层直接用 `node:https` / `node:http`：
  解析（优先公共 DNS）→ 逐个地址尝试 → 成功即返回。
- **地址解析必须用 `node:dns` 的回调版**。`node:dns/promises` 的 `lookup` 忽略回调，
  传回调进去会永久挂起。
- **`lookup` 必须放在 Agent 选项里**，不能放在请求选项里：Agent 自己建 socket 会覆盖
  请求级 `lookup`。Agent 用 `keepAlive: false`，保证每次尝试都是新连接。
- **URL 里是字面 IP 时不会走 `lookup`**（Node 直接连，不做 DNS 解析）。所以地址钉定只对
  域名生效——真实 API 是域名，正好适用。
- `response_format` **只放在 `extra_body` 里**，不放顶层；图生图**不传** `tags`。
- 文生图优先请求 URL 输出，再自己下载；若服务端仍返回 `b64_json`（例如图生图场景），
  会走 base64 解码路径，并按魔数决定扩展名。
- **落盘不能用 `ctx.fs.writeText`（两个已修复的真实故障，2026-10 观测）**：
  1. **必须传按调用策略**。沙箱部署下 `ctx.fs` 是 `dsh-fs-sandbox`，变更由**按调用策略**
     围栏。省略 `writeText` 的第 5 个参数时，后端退回 `ctx.sandboxPolicy.resolve()` 的部署
     兜底工作区根（`dsh-base` 里 `workspaceRoot: !!js process.cwd()`，即应用安装目录），
     于是会话工作区内的写入被判为「不在可写根之下」→ `FS_SANDBOX_DENIED`。官方 fs 工具
     正是用 `sandbox.resolvePolicy("write", args, exec)` 把会话 cwd 作为工作区根一起传入。
  2. **`ctx.fs` 没有二进制写原语**。它只提供 `writeText`，而 `dsh-fs-local` 的原子写传
     `encoding: 'utf8'`，所以任何字符串都会按 UTF-8 编码：`bytes.toString('binary')` 会把
     `0x89` 变成 `c2 89` 从而撑大并损坏图片（3.79 MB → 5.68 MB）；改用 base64 也只是把
     base64 文本自身的字节写进去。因此字节走 `node:fs` 的 `writeBytesAtomic()`（同目录
     staging + `rename`，与 harness 自己的发布方式一致），写完用 `ctx.fs.readBytes` 读回
     逐字节校验。路径仍来自 `ctx.fs.resolve()`（锚定会话工作区），但这层约束由代码自觉
     而非沙箱强制 —— 这是刻意接受的偏离。
- 插件的本地测试桩必须与真实后端**同构**：`writeText` 按 UTF-8 写真实文件、`resolve`
  返回绝对 `displayPath`。用内存 Map + latin1 反解的桩会让上面第 2 个 bug 永远是绿的
  （这正是它长期未被发现的原因）。
- 插件只依赖 Node 内置能力与 `ctx.tools` / `ctx.fs` 两个 Harness 服务，
  **不 import 任何 `@deepseek-ai/*` 包** —— profile 的 `node_modules` 里解析不到这些包，
  这是刻意的设计。（`node:fs` 用于上方所述的二进制落盘。）

## 验证

```powershell
# 1) 本地端到端（不依赖外网）：请求契约 + 落盘字节保真 + Data URI 编码 + 解析偏好
node test/verify-local.mjs

# 2) 工具声明 + 真实 API（需要网络）
$env:NODE_PATH = "D:\DSH\dsh_data\DSH Desktop\resources\app\node_modules"
node test/verify.mjs
```

`verify-local.mjs` 起一个回环 HTTP 服务模拟 Agnes 的响应形状，断言：`size`/`ratio` 透传、
`response_format` 只在 `extra_body`、不传 `tags`、URL 与 base64 两条路径都能落盘且
**字节完全一致**、本地输入图被正确编码成 Data URI、公共 DNS 能解析出地址、
`preferIPv4=false` 时保留 IPv6 候选。

`verify.mjs` 用真实的 `@deepseek-ai/dsh-tools` schema 校验器验证工具声明落在
DSH 支持的 JSON Schema 子集内，并**真的调用一次 API**、下载图像、校验 PNG 魔数。
外网不可达时端到端部分会单独报告为「被阻断」，不计入失败。

实测结果（2026-10-06）：本地 33/33 通过；线上 20/20 通过，单次生成约 7–8 秒。

## 排查记录：为什么一开始调不通（2026-10 观测）

本机开着代理（VPN，海外节点），harness 出站走系统代理 `127.0.0.1:7897`。当时的失败链是：

1. **系统 DNS 把 `api.agnes-ai.cn` 解析到坏地址**（观测到 `103.73.220.77`）。
   该地址的证书 subject 为空、SAN 只有 `IP Address:103.73.220.77`，没有 DNS 名，
   按域名访问必然 `ERR_TLS_CERT_ALTNAME_INVALID`；放宽校验后它会 `302 → https://m.baidu.com`。
2. 同时该域名还有 **AAAA 记录**，而 Node（此处 v24.16.0）默认优先 IPv6，那条路也是坏的。
3. 多个公共解析器（`223.5.5.5`、`223.6.6.6`、`119.29.29.29`、`8.8.4.4`）**一致**给出正确地址
   `111.7.87.222`，其证书正常（Sectigo 通配符 `*.agnes-ai.cn`），用它能稳定成功。
   `www.agnes-ai.cn` 解析正常，作为对照。
4. 走代理建 CONNECT 隧道后拿到的仍是同一个坏证书 —— 代理是在直连（`agnes-ai.cn` 可能命中直连规则），
   所以**不是代理本身的问题，而是这条直连路径被污染**。

因此插件默认改用可信公共 DNS 解析 + IPv4 优先 + 多地址重试。若你的网络里系统 DNS 恢复正常，
可以把 `dnsServers` 设为 `[]` 让它回退到系统解析器。
