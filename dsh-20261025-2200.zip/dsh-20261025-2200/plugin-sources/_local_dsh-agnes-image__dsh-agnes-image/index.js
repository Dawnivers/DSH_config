/**
 * Agnes Image 2.5 Flash 生图工具。
 *
 * API 契约（https://www.agnes-ai.cn/zh-Hans/docs/agnes-image-25-flash）：
 *   POST {baseUrl}/v1/images/generations
 *   - 文生图：model / prompt / size 必填；URL 输出走 extra_body.response_format
 *   - 图生图与多图合成：输入图放在 extra_body.image（公共 URL 或 Data URI）
 *   - 顶层放 response_format 是错误用法；图生图不需要 tags
 *
 * 网络层（公共 DNS + IPv4 优先 + 多地址重试）与二进制落盘都来自共享包
 * `@local/dsh-agnes-core`，与 `dsh-agnes-video` 共用同一套实现 —— 不 import 任何
 * `@deepseek-ai/*` 包。
 */

import {
  DEFAULT_DNS_SERVERS,
  extensionFor,
  extensionFromMagic,
  fetchWithFallback,
  listConfig,
  numberConfig,
  resolveInputImage,
  textConfig,
  writeBytesAtomic,
} from '@local/dsh-agnes-core';

const SIZE_GRADES = ['1K', '2K', '3K', '4K'];
const RATIOS = ['1:1', '3:4', '4:3', '16:9', '9:16', '2:3', '3:2', '21:9'];

/** Stable Loader identity. */
export const name = 'agnes-image';

/** Services this plugin needs; it stays inactive without them. */
export const inject = ['tools', 'fs'];

/**
 * Normalize the row config.
 *
 * Deliberately NOT exported as `Config`: Cordis treats an exported `Config` as a
 * schemastery schema and calls `Config.validate`, which would need an
 * `@deepseek-ai/*` import that does not resolve from the profile. Validation is
 * therefore plain code here, and the loader keeps the row config as authored.
 * Field documentation lives in config.schema.json.
 * @param config - raw row config from the bundle patch.
 * @returns The normalized config.
 */
function normalizeConfig(config) {
  const source = config !== null && typeof config === 'object' ? config : {};
  return {
    model: textConfig(source.model, 'agnes-image-2.5-flash'),
    baseUrl: textConfig(source.baseUrl, 'https://api.agnes-ai.cn').replace(/\/+$/, ''),
    apiKey: textConfig(source.apiKey, ''),
    defaultSize: SIZE_GRADES.includes(source.defaultSize) ? source.defaultSize : '2K',
    defaultRatio: RATIOS.includes(source.defaultRatio) ? source.defaultRatio : '1:1',
    outputDir: textConfig(source.outputDir, 'agnes-images'),
    timeoutMs: numberConfig(source.timeoutMs, 360000),
    maxOutputBytes: numberConfig(source.maxOutputBytes, 64 * 1024 * 1024),
    preferIPv4: source.preferIPv4 !== false,
    resolveAddress: textConfig(source.resolveAddress, ''),
    // 默认走可信公共解析器：本机系统 DNS 会把该域名解析到坏地址。
    // 留空数组则回退到系统解析器。
    dnsServers: listConfig(source.dnsServers, DEFAULT_DNS_SERVERS),
  };
}

/**
 * Read the session working directory used to resolve relative paths.
 * @param exec - tool execution context.
 * @returns The cwd, or undefined when the session has none.
 */
function sessionCwd(exec) {
  return exec?.agent?.session?.header?.cwd;
}

/**
 * Turn an HTTP failure into a message that names the likely cause.
 * @param status - HTTP status code.
 * @param detail - response body excerpt.
 * @returns An actionable error message.
 */
function describeHttpFailure(status, detail) {
  const hint = status === 401 || status === 403
    ? '认证被拒绝：检查 apiKey（或环境变量 AGNES_API_KEY）是否有效。'
    : status === 429
      ? '请求被限流：稍后重试。'
      : status >= 500
        ? '服务端错误：稍后重试。'
        : '检查 model / size / ratio / images 是否符合文档。';
  return `Agnes 生图失败（HTTP ${status}）：${hint}${detail ? ` 响应：${detail}` : ''}`;
}

/**
 * 取本次调用要用的 API Key：环境变量优先于行配置。
 * @param config - normalized plugin config.
 * @returns API Key，可能为空串。
 */
function resolveApiKey(config) {
  const fromEnv = typeof process.env.AGNES_API_KEY === 'string'
    ? process.env.AGNES_API_KEY.trim()
    : '';
  return fromEnv !== '' ? fromEnv : config.apiKey;
}

/**
 * Call the Agnes image endpoint.
 * @param config - normalized plugin config.
 * @param body - request body.
 * @param signal - cancellation signal.
 * @returns The parsed JSON response.
 */
async function requestGeneration(config, body, signal) {
  const response = await fetchWithFallback(config, {
    url: `${config.baseUrl}/v1/images/generations`,
    method: 'POST',
    headers: {
      Authorization: `Bearer ${resolveApiKey(config)}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(body),
  }, signal);
  if (response.status < 200 || response.status >= 300) {
    const detail = response.body.toString('utf8').slice(0, 500);
    throw new Error(describeHttpFailure(response.status, detail));
  }
  try {
    return JSON.parse(response.body.toString('utf8'));
  } catch {
    throw new Error(`Agnes 返回的不是合法 JSON：${response.body.toString('utf8').slice(0, 200)}`);
  }
}

/**
 * Get the first generated image out of a response payload.
 * @param payload - parsed API response.
 * @returns The URL or base64 payload.
 */
function firstImage(payload) {
  const entry = Array.isArray(payload?.data) ? payload.data[0] : undefined;
  if (entry === undefined || entry === null) {
    throw new Error('Agnes 返回了空结果：响应中没有 data[0]。');
  }
  const url = typeof entry.url === 'string' && entry.url !== '' ? entry.url : undefined;
  const base64 = typeof entry.b64_json === 'string' && entry.b64_json !== '' ? entry.b64_json : undefined;
  if (url === undefined && base64 === undefined) {
    throw new Error('Agnes 返回的结果既没有 url 也没有 b64_json。');
  }
  return { url, base64, taskId: payload?.task_id };
}

/**
 * Register the Agnes image generation tool.
 * @param ctx - agent-scoped services.
 * @param rawConfig - validated row config.
 */
export function apply(ctx, rawConfig) {
  const config = normalizeConfig(rawConfig);

  // 沙箱部署下 ctx.fs 是 dsh-fs-sandbox：变更按**调用策略**围栏，而策略的工作区根
  // 默认是部署兜底值（应用安装目录）。这里取本次调用的策略只用于 resolve 的 cwd
  // 兜底；二进制落盘见 writeBytesAtomic。
  const policyService = (() => {
    try {
      return typeof ctx.get === 'function' ? ctx.get('sandboxPolicy') : undefined;
    } catch {
      return undefined;
    }
  })();

  const resolvePolicy = (exec) => {
    try {
      if (policyService === undefined) return undefined;
      const session = exec?.agent?.session;
      return session === undefined ? policyService.resolve() : policyService.resolve({ session });
    } catch {
      return undefined; // 回退到后端自己的策略解析
    }
  };

  // 整次注册包在一个 effect 里：插件卸载或 HMR 替换时工具会被一起摘掉。
  const disposers = [];
  ctx.effect(() => () => {
    while (disposers.length > 0) disposers.pop()();
  });

  disposers.push(ctx.tools.register({
    name: 'agnes_image_generate',
    description: 'Generate or edit an image with the Agnes Image 2.5 Flash model. '
      + 'Use it for text-to-image, image-to-image editing, and multi-image composition. '
      + 'Pass existing workspace image paths or public HTTPS URLs in `images` to edit or combine them. '
      + 'The generated image is downloaded into the session workspace and returned as a path; '
      + 'display it with markdown image syntax or present it to the user.',
    timeoutMs: config.timeoutMs + 60000,
    parameters: {
      type: 'object',
      additionalProperties: false,
      properties: {
        prompt: {
          type: 'string',
          description: 'Image generation or editing instruction. '
            + 'Text-to-image structure: subject + scene/environment + style + lighting + composition + quality. '
            + 'Image-to-image structure: requested change + new style/scene + elements to add or remove + elements to preserve.',
        },
        size: {
          type: 'string',
          enum: SIZE_GRADES,
          description: `Output size grade. Defaults to ${config.defaultSize}.`,
        },
        ratio: {
          type: 'string',
          enum: RATIOS,
          description: `Aspect ratio paired with the size grade. Defaults to ${config.defaultRatio}.`,
        },
        images: {
          type: 'array',
          items: { type: 'string' },
          description: 'Input images for image-to-image or multi-image composition: '
            + 'workspace-relative paths, absolute paths, or public HTTPS URLs. Omit for text-to-image.',
        },
        output_path: {
          type: 'string',
          description: 'Optional destination file path. Defaults to a timestamped file under '
            + `"${config.outputDir}"` + ' in the session working directory.',
        },
      },
      required: ['prompt'],
    },
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          path: { type: 'string' },
          bytes: { type: 'integer' },
          model: { type: 'string' },
          size: { type: 'string' },
          ratio: { type: 'string' },
          revised_prompt: { oneOf: [{ type: 'string' }, { type: 'null' }] },
          task_id: { oneOf: [{ type: 'string' }, { type: 'null' }] },
        },
        required: ['path', 'bytes', 'model', 'size', 'ratio'],
      },
      render: (_args, value) => [{
        type: 'text',
        text: `Generated image: ${value.path} (${value.bytes} bytes, ${value.model}, ${value.size} ${value.ratio})`,
      }],
    },
    async execute(args, exec) {
      const apiKey = resolveApiKey(config);
      if (apiKey === '') {
        throw new Error('Agnes 生图缺少 API Key：在 cordis.patch.yml 的行 config.apiKey 里设置，或设置环境变量 AGNES_API_KEY。');
      }

      const prompt = typeof args.prompt === 'string' ? args.prompt.trim() : '';
      if (prompt === '') throw new Error('prompt 不能为空。');

      const size = SIZE_GRADES.includes(args.size) ? args.size : config.defaultSize;
      const ratio = RATIOS.includes(args.ratio) ? args.ratio : config.defaultRatio;

      const body = {
        model: config.model,
        prompt,
        size,
        ratio,
        extra_body: { response_format: 'url' },
      };

      const cwd = sessionCwd(exec);
      const inputs = Array.isArray(args.images)
        ? args.images.filter((entry) => typeof entry === 'string' && entry.trim() !== '')
        : [];
      if (inputs.length > 0) {
        body.extra_body.image = [];
        for (const entry of inputs) {
          body.extra_body.image.push(await resolveInputImage(entry.trim(), ctx, exec, cwd));
        }
      }

      exec.signal.throwIfAborted();
      const payload = await requestGeneration(config, body, exec.signal);
      const { url, base64, taskId } = firstImage(payload);

      let bytes;
      let extension;
      if (base64 !== undefined) {
        bytes = Buffer.from(base64, 'base64');
        extension = extensionFromMagic(bytes) ?? extensionFor(undefined, undefined);
      } else {
        const response = await fetchWithFallback(config, { url, method: 'GET', headers: {} }, exec.signal);
        if (response.status < 200 || response.status >= 300) {
          throw new Error(`下载生成结果失败（HTTP ${response.status}）：${url}`);
        }
        bytes = response.body;
        extension = extensionFor(response.headers['content-type'], url);
      }

      if (bytes.byteLength === 0) throw new Error('Agnes 返回了 0 字节图像。');
      if (bytes.byteLength > config.maxOutputBytes) {
        throw new Error(`生成结果 ${bytes.byteLength} 字节，超过 maxOutputBytes=${config.maxOutputBytes}。`);
      }

      const requested = typeof args.output_path === 'string' && args.output_path.trim() !== ''
        ? args.output_path.trim()
        : `${config.outputDir}/agnes-${new Date().toISOString().replace(/[:.]/g, '-')}${extension}`;
      const sandboxPolicy = resolvePolicy(exec);
      const target = await ctx.fs.resolve(requested, {
        // 会话工作区优先；无会话 cwd 时用本次调用的策略工作区根，而不是后端默认根。
        ...(cwd !== undefined
          ? { cwd }
          : sandboxPolicy?.workspaceRoot !== undefined
            ? { cwd: sandboxPolicy.workspaceRoot }
            : {}),
        signal: exec.signal,
      });

      // ctx.fs 只提供文本写入且按 UTF-8 编码，无法写任意二进制（详见 core 里
      // writeBytesAtomic 的说明），因此字节走 node:fs；写完读回逐字节校验。
      await writeBytesAtomic(target.displayPath, bytes, exec.signal);

      const written = Buffer.from(await ctx.fs.readBytes(target, exec.signal, config.maxOutputBytes));
      if (written.byteLength !== bytes.byteLength || Buffer.compare(written, bytes) !== 0) {
        throw new Error(
          `写入的图像字节与生成结果不一致：期望 ${bytes.byteLength} 字节，实际 ${written.byteLength} 字节。`,
        );
      }

      return {
        path: target.displayPath,
        bytes: bytes.byteLength,
        model: config.model,
        size,
        ratio,
        revised_prompt: null,
        task_id: typeof taskId === 'string' ? taskId : null,
      };
    },
  }));
}
