/**
 * dsh-agnes-image 离线验证脚本。
 *
 * 它用真实的 DSH JSON Schema 校验器检查工具声明的 parameters / output.schema
 * 是否落在受支持的子集内，用假的 ctx.fs 与假的 tools 注册表驱动 execute，
 * 并真的调用一次 Agnes API、把图像写入本地目录后校验 PNG 魔数。
 *
 * 运行（从 dsh-agnes-image 目录）：
 *   node --experimental-loader=... 不必要；直接：
 *   $env:NODE_PATH="...app\node_modules"; node test\verify.mjs
 */
import { mkdir, readFile, rm } from 'node:fs/promises';
import { dirname, join, resolve as resolvePath } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const here = dirname(fileURLToPath(import.meta.url));
const packageDir = resolvePath(here, '..');
const scratch = join(packageDir, '.verify');

const dshModules = process.env.DSH_APP_NODE_MODULES
  ?? 'D:\\DSH\\dsh_data\\DSH Desktop\\resources\\app\\node_modules';

const failures = [];
const checks = [];
function check(label, condition, detail = '') {
  checks.push({ label, ok: Boolean(condition), detail });
  if (!condition) failures.push(`${label}${detail ? ` — ${detail}` : ''}`);
}

// --- 1. 用真实校验器检查 schema -------------------------------------------
const schemaPath = pathToFileURL(join(dshModules, '@deepseek-ai', 'dsh-tools', 'lib', 'types', 'json-schema.js')).href;
const { assertSupportedJsonSchema } = await import(schemaPath);

// --- 2. 加载插件 ------------------------------------------------------------
await rm(scratch, { recursive: true, force: true });
await mkdir(scratch, { recursive: true });

const plugin = await import(pathToFileURL(join(packageDir, 'index.js')).href);
check('导出 name', plugin.name === 'agnes-image', String(plugin.name));
check('inject 包含 tools/fs', Array.isArray(plugin.inject)
  && plugin.inject.includes('tools') && plugin.inject.includes('fs'), JSON.stringify(plugin.inject));
check('导出 apply 函数', typeof plugin.apply === 'function');
// Cordis 把导出的 Config 当 schemastery schema 调 .validate；普通函数会让整行激活失败。
check('不导出 Config（避免 Cordis 当 schema 校验）', plugin.Config === undefined,
  typeof plugin.Config);

// --- 3. 假 ctx / exec -------------------------------------------------------
try {
let registered;
const written = new Map();
const fakeCtx = {
  tools: {
    register(definition) {
      registered = definition;
      return () => {};
    },
  },
  effect: (callback) => callback(),
  fs: {
    async resolve(requested, options = {}) {
      const cwd = options.cwd ?? process.cwd();
      const absolute = resolvePath(cwd, requested);
      return { displayPath: requested, targetKey: absolute };
    },
    async stat(target) {
      return written.has(target.targetKey) ? { type: 'file' } : undefined;
    },
    async readBytes(target) {
      const value = written.get(target.targetKey);
      if (value === undefined) throw new Error(`not found: ${target.displayPath}`);
      return new Uint8Array(value, 'binary');
    },
    async writeText(target, content) {
      written.set(target.targetKey, content);
      return { operation: 'create', version: 'v1', before: null, after: content };
    },
  },
  logger: { warn: (message) => console.log(`  [warn] ${message}`) },
};

// key 来源优先级：环境变量 > 包内 patch 的 apiKey（与插件运行时一致）
const patchText = await readFile(join(packageDir, 'cordis.patch.yml'), 'utf8');
const patchKey = /^\s*apiKey:\s*'?([^'\r\n]+)'?\s*$/m.exec(patchText)?.[1]?.trim() ?? '';
const apiKey = (process.env.AGNES_API_KEY?.trim() ?? '') || patchKey;
check('拿到了 API Key', apiKey.startsWith('sk-'), apiKey === '' ? '未找到' : '格式异常');

plugin.apply(fakeCtx, {
  apiKey,
  model: 'agnes-image-2.5-flash',
  baseUrl: 'https://api.agnes-ai.cn',
  defaultSize: '1K',
  defaultRatio: '1:1',
  outputDir: 'agnes-images',
  // 与出厂默认一致：走可信公共解析器 + IPv4 优先
  dnsServers: ['223.6.6.6', '8.8.4.4'],
  preferIPv4: true,
  timeoutMs: 360000,
});

check('注册了工具', registered !== undefined && registered.name === 'agnes_image_generate',
  registered?.name);
check('工具声明了 timeoutMs', Number.isFinite(registered?.timeoutMs), String(registered?.timeoutMs));

// 真实子集校验（ctx.tools.register 内部对 output.schema 执行的就是这个）
try {
  assertSupportedJsonSchema(registered.parameters);
  check('parameters 落在 DSH schema 子集内', true);
} catch (error) {
  check('parameters 落在 DSH schema 子集内', false, String(error.message));
}
try {
  assertSupportedJsonSchema(registered.output.schema);
  check('output.schema 落在 DSH schema 子集内', true);
} catch (error) {
  check('output.schema 落在 DSH schema 子集内', false, String(error.message));
}
check('output.render 是函数', typeof registered.output.render === 'function');
check('parameters 根为 object', registered.parameters.type === 'object');
check('prompt 为必填', Array.isArray(registered.parameters.required)
  && registered.parameters.required.includes('prompt'), JSON.stringify(registered.parameters.required));

// --- 4. 真的生成一张图 ------------------------------------------------------
const exec = {
  name: registered.name,
  callId: 'verify-call-1',
  signal: new AbortController().signal,
  agent: { session: { header: { cwd: scratch } } },
};

console.log('调用 Agnes API 生成 1K 1:1 测试图 ...');
const started = Date.now();
let result;
let networkFailure;
try {
  result = await registered.execute({
    prompt: 'A single flat orange circle centered on a pure white background, minimal vector look',
    size: '1K',
    ratio: '1:1',
  }, exec);
} catch (error) {
  // 网络不可达是环境问题，不是插件缺陷：单独报告，不计入失败。
  networkFailure = `[${error?.name ?? 'Error'}] ${error?.message ?? error}`;
}

if (networkFailure !== undefined) {
  console.log(`  被阻断：${networkFailure}`);
} else {
  check('execute 成功返回', true);
  console.log(`  用时 ${((Date.now() - started) / 1000).toFixed(1)}s`);
  console.log(`  返回值 ${JSON.stringify(result)}`);

  const key = resolvePath(scratch, result.path);
  const stored = written.get(key);
  check('图像写入了 ctx.fs', stored !== undefined, result.path);
  if (stored !== undefined) {
    const bytes = Buffer.from(stored, 'binary');
    check('返回字节数与落盘一致', bytes.length === result.bytes, `${bytes.length} vs ${result.bytes}`);
    const isPng = bytes.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]));
    const isJpeg = bytes.subarray(0, 3).equals(Buffer.from([0xff, 0xd8, 0xff]));
    const isWebp = bytes.subarray(8, 12).toString('ascii') === 'WEBP';
    check('落盘内容是真实图像（魔数）', isPng || isJpeg || isWebp,
      `png=${isPng} jpeg=${isJpeg} webp=${isWebp}`);
    check('图像大于 1KB', bytes.length > 1024, `${bytes.length} bytes`);

    // 落到真实文件系统，供人工查看
    await mkdir(dirname(key), { recursive: true });
    const { writeFile } = await import('node:fs/promises');
    await writeFile(key, bytes);
    console.log(`  预览文件 ${key}`);
    console.log(`  文件头 ${bytes.subarray(0, 12).toString('hex')}`);
  }

  const rendered = registered.output.render({}, result);
  check('render 产出 text 内容块',
    Array.isArray(rendered) && rendered[0]?.type === 'text' && typeof rendered[0].text === 'string',
    JSON.stringify(rendered));
}

// --- 5. 错误路径：空 prompt ------------------------------------------------
try {
  await registered.execute({ prompt: '   ' }, exec);
  check('空 prompt 被拒绝', false, '没有抛错');
} catch (error) {
  check('空 prompt 被拒绝', /prompt/.test(String(error.message)), String(error.message));
}

// --- 6. 错误路径：无效 key（网络不可达时跳过） ------------------------------
written.clear();
plugin.apply(fakeCtx, { apiKey: 'sk-invalid-for-test', baseUrl: 'https://api.agnes-ai.cn' });
try {
  await registered.execute({ prompt: 'x' }, exec);
  console.log('  (注意：无效 key 请求竟然成功了)');
} catch (error) {
  const message = String(error.message);
  if (/无法连接 Agnes API/.test(message)) {
    console.log(`  跳过（网络不可达）：${message.slice(0, 120)}`);
  } else {
    check('无效 key 报出可读错误', /HTTP|Agnes/.test(message), message);
  }
}

// --- 汇总 -------------------------------------------------------------------
} finally {
  await rm(scratch, { recursive: true, force: true });
}

console.log('\n--- 检查结果 ---');
for (const entry of checks) console.log(`${entry.ok ? 'PASS' : 'FAIL'}  ${entry.label}${entry.ok ? '' : `  (${entry.detail})`}`);
console.log(`\n${checks.filter((entry) => entry.ok).length}/${checks.length} 通过`);
if (failures.length > 0) throw new Error(`${failures.length} 项失败`);
