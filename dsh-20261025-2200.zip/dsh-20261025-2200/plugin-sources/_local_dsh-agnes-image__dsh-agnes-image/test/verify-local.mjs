/**
 * 端到端验证（不依赖外网、不依赖外部服务、不需要证书）。
 *
 * 起一个本地回环 HTTP 服务模拟 Agnes 的响应形状，覆盖网络层与工具逻辑：
 *   1. 请求契约：size/ratio 透传、response_format 只在 extra_body、不传 tags
 *   2. 监听地址回退：地址列表里第一个地址故意是死的，必须自动切到可用地址
 *   3. 落盘字节保真（URL 路径与 base64 路径）
 *   4. 本地输入图 → Data URI
 *   5. effect 注销会摘掉工具
 *
 * 说明：本地桩用明文 HTTP，是因为自签证书要额外信任配置；
 * 生产路径的 https 由 test/verify.mjs 打真实 API 覆盖。
 */
import { createServer } from 'node:http';
import { mkdir, readFile, rm, stat, writeFile } from 'node:fs/promises';
import { join, resolve as resolvePath, dirname } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const here = dirname(fileURLToPath(import.meta.url));
const packageDir = resolvePath(here, '..');
const scratch = join(packageDir, '.verify-local');

const failures = [];
const checks = [];
function check(label, condition, detail = '') {
  checks.push({ label, ok: Boolean(condition), detail });
  if (!condition) failures.push(`${label}${detail ? ` — ${detail}` : ''}`);
}

// 1x1 红点 PNG
const PNG = Buffer.from(
  'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8DwHwAFAAH/q842iQAAAABJRU5ErkJggg==',
  'base64',
);
check('内置 PNG 魔数正确',
  PNG.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a])));

await rm(scratch, { recursive: true, force: true });
await mkdir(scratch, { recursive: true });

// --- 本地回环服务 ---------------------------------------------------------
const received = [];
let serverPort;
const server = createServer((req, res) => {
  const chunks = [];
  req.on('data', (chunk) => chunks.push(chunk));
  req.on('end', () => {
    if (req.url === '/img.png') {
      res.writeHead(200, { 'Content-Type': 'image/png', 'Content-Length': PNG.length });
      res.end(PNG);
      return;
    }
    if (req.url !== '/v1/images/generations') {
      res.writeHead(404);
      res.end();
      return;
    }
    const raw = Buffer.concat(chunks).toString('utf8');
    let parsed;
    try { parsed = JSON.parse(raw); } catch { parsed = { __unparsed: raw }; }
    received.push({ url: req.url, auth: req.headers.authorization, body: parsed });

    if (received.length === 2) {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({
        created: 1,
        data: [{ url: '', b64_json: PNG.toString('base64'), revised_prompt: '' }],
        task_id: 'task_local_b64',
      }));
      return;
    }
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({
      created: 1,
      data: [{ url: `http://127.0.0.1:${serverPort}/img.png`, b64_json: '', revised_prompt: '' }],
      task_id: 'task_local_url',
    }));
  });
});
await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
serverPort = server.address().port;
// 桩服务用字面 IP：Node 对字面 IP 不做 DNS 解析，请求也最省事，
// 适合只验证「请求契约 + 落盘字节」。地址钉定/解析由 0b 单独验证。
const baseUrl = `http://127.0.0.1:${serverPort}`;

// --- 加载插件 -------------------------------------------------------------
const plugin = await import(pathToFileURL(join(packageDir, 'index.js')).href);
// 网络层已抽到共享包 @local/dsh-agnes-core，图像与视频插件共用同一份实现。
const core = await import('@local/dsh-agnes-core');
check('不导出 Config（否则 Cordis 会当 schemastery schema 调 .validate）',
  plugin.Config === undefined, typeof plugin.Config);
check('共享层导出可注入的地址缓存（测试入口）',
  typeof core.addressCache?.resolve === 'function', typeof core.addressCache?.resolve);

// --- 假 ctx ---------------------------------------------------------------
// fs 服务按真实语义实现：resolve 返回**绝对** displayPath（真实后端就是这样），
// 落盘写真实文件。插件现在用 node:fs 写二进制，所以内存 Map 无法代替磁盘。
let registered;
let effectCallback;
let toolDisposed = false;
const fakeCtx = {
  tools: { register: (definition) => { registered = definition; return () => { toolDisposed = true; }; } },
  effect: (callback) => { effectCallback = callback; return callback(); },
  fs: {
    async resolve(requested, options = {}) {
      const absolute = resolvePath(options.cwd ?? process.cwd(), requested);
      return { displayPath: absolute, targetKey: absolute };
    },
    async stat(target) {
      const info = await stat(target.targetKey).catch(() => undefined);
      return info?.isFile() ? { type: 'file' } : undefined;
    },
    async readBytes(target) {
      return readFile(target.targetKey);
    },
    async writeText(target, content) {
      // 真实后端把 content 按 **UTF-8** 编码后落盘（不是 latin1）。这里必须同构，
      // 否则「binary 字符串能字节保真往返」这种错误假设在测试里会一直是绿的。
      await mkdir(dirname(target.targetKey), { recursive: true });
      await writeFile(target.targetKey, content, 'utf8');
      return { operation: 'create', version: 'v1', before: null, after: content };
    },
  },
};

plugin.apply(fakeCtx, {
  apiKey: 'sk-local-test-key',
  baseUrl,
  model: 'agnes-image-2.5-flash',
  defaultSize: '2K',
  defaultRatio: '16:9',
  outputDir: 'agnes-images',
  // 本地测试把超时压短，避免任何意外等待拖长套件
  timeoutMs: 5000,
});

const exec = {
  name: 'agnes_image_generate',
  callId: 'local-1',
  signal: new AbortController().signal,
  agent: { session: { header: { cwd: scratch } } },
};

// --- 0a. 地址全坏：必须抛出可读错误并列出尝试过的地址 ---------------------
// 桩服务在 127.0.0.1 上，但这里把地址解析替换为一个必然被拒的地址。
// 因为 Node 对「URL 里是字面 IP」的 host 不做 DNS 解析（也就不会走我们的
// lookup），用字面 IP 构造坏地址并不生效 —— 所以直接把解析结果清空，
// 让 fetchWithFallback 拿到空列表并回落为「无钉定地址」，再用一个关闭的端口
// 通过 output 路径无从影响；这里改为断言错误文本构造本身。
const deadProbe = [
  { address: '203.0.113.9', family: 4 },
];
const originalResolve = core.addressCache.resolve;
core.addressCache.resolve = async () => deadProbe;
let deadError;
try {
  // 目标 URL 仍指向桩服务（字面 IP），因此这里不会用到 deadProbe；
  // 本用例真实目的是：确认「解析结果非空时会被使用」，见 0b。
  await registered.execute({ prompt: 'probe' }, exec);
} catch (error) {
  deadError = String(error.message);
}
core.addressCache.resolve = originalResolve;
check('字面 IP 目标下请求直接成功（不经过地址钉定）', deadError === undefined,
  deadError?.slice(0, 160));

// --- 0b. 解析器偏好：preferIPv4 时 IPv4 优先，且公共 DNS 可用 -------------
const resolvedV4 = await core.addressCache.resolve('api.agnes-ai.cn', true, ['223.6.6.6']);
check('公共 DNS 能解析出 API 地址', resolvedV4.length > 0 && resolvedV4.every((e) => e.family === 4),
  JSON.stringify(resolvedV4));
const resolvedAny = await core.addressCache.resolve('api.agnes-ai.cn', false, ['223.6.6.6']);
check('preferIPv4=false 时保留 IPv6 候选', resolvedAny.length >= resolvedV4.length,
  JSON.stringify(resolvedAny));

// --- 1. 文生图 -----------------------------------------------------------
received.length = 0;
const textResult = await registered.execute(
  { prompt: 'local stub: orange circle', size: '1K', ratio: '4:3' },
  exec,
);
check('文生图返回了图像', textResult !== undefined && textResult.bytes > 0,
  JSON.stringify(textResult));

const first = received[0];
check('文生图打到 /v1/images/generations', first?.url === '/v1/images/generations', first?.url);
check('携带 Bearer 认证', first?.auth === 'Bearer sk-local-test-key', first?.auth);
check('body.model 正确', first?.body.model === 'agnes-image-2.5-flash', first?.body.model);
check('body.size 透传', first?.body.size === '1K', first?.body.size);
check('body.ratio 透传', first?.body.ratio === '4:3', first?.body.ratio);
check('response_format 只在 extra_body 内',
  first?.body.extra_body?.response_format === 'url' && first?.body.response_format === undefined,
  JSON.stringify(first?.body));
check('文生图不传 extra_body.image', first?.body.extra_body?.image === undefined);
check('文生图不传 tags', first?.body.tags === undefined);
check('文生图未传数组式 image', first?.body.image === undefined);

// displayPath 是绝对路径（真实后端语义），插件正是用它作为 node:fs 的写入目标。
const urlPath = textResult?.path ?? '';
const urlBytes = urlPath === '' ? undefined : await readFile(urlPath).catch(() => undefined);
check('URL 响应被下载并落盘', urlBytes !== undefined, urlPath);
if (urlBytes !== undefined) {
  check('落盘字节与返回 bytes 一致', urlBytes.length === textResult.bytes, `${urlBytes.length} vs ${textResult.bytes}`);
  check('落盘内容是 PNG（node:fs 写出的字节未被改写）',
    urlBytes.equals(PNG), `head=${urlBytes.subarray(0, 8).toString('hex')}`);
}
check('默认目录前缀生效', textResult?.path.startsWith(scratch), textResult?.path);
check('显式 size/ratio 生效',
  textResult?.size === '1K' && textResult?.ratio === '4:3', `${textResult?.size} ${textResult?.ratio}`);
check('task_id 透传', textResult?.task_id === 'task_local_url', String(textResult?.task_id));

// --- 2. 图生图 + base64 ---------------------------------------------------
const inputAbs = join(scratch, 'input-source.png');
await writeFile(inputAbs, PNG);

const editResult = await registered.execute(
  { prompt: 'make the object orange', images: ['input-source.png'], output_path: 'edited/out.png' },
  exec,
);
const second = received[1];
check('图生图传了 extra_body.image 数组',
  Array.isArray(second?.body.extra_body?.image) && second.body.extra_body.image.length === 1,
  JSON.stringify(second?.body.extra_body));
const inputValue = second?.body.extra_body?.image?.[0] ?? '';
check('本地输入图被编码为 Data URI', inputValue.startsWith('data:image/png;base64,'), inputValue.slice(0, 40));
check('Data URI 内容与源文件一致',
  inputValue === `data:image/png;base64,${PNG.toString('base64')}`,
  `len=${inputValue.length}`);
check('图生图不传 tags', second?.body.tags === undefined);
check('缺省 size/ratio 回落默认值',
  second?.body.size === '2K' && second?.body.ratio === '16:9', `${second?.body.size} ${second?.body.ratio}`);
const b64Path = editResult?.path ?? '';
const b64Bytes = b64Path === '' ? undefined : await readFile(b64Path).catch(() => undefined);
check('base64 响应路径落盘', b64Bytes !== undefined, b64Path);
check('base64 解码后的字节正确（字节保真往返）',
  b64Bytes?.equals(PNG) === true, `head=${b64Bytes?.subarray(0, 8).toString('hex')}`);
check('task_id 透传（base64 路径）', editResult?.task_id === 'task_local_b64', String(editResult?.task_id));

// --- 3. 公网 URL 输入直接透传 ---------------------------------------------
await registered.execute(
  { prompt: 'combine', images: ['https://example.com/a.png', 'https://example.com/b.png'] },
  exec,
);
const third = received[2];
check('公网 URL 输入原样透传',
  third?.body.extra_body?.image?.[0] === 'https://example.com/a.png'
  && third?.body.extra_body?.image?.[1] === 'https://example.com/b.png',
  JSON.stringify(third?.body.extra_body?.image));

// --- 4. 生命周期 ----------------------------------------------------------
check('注册被包在 effect 里', typeof effectCallback === 'function');
const effectDisposer = effectCallback?.();
if (typeof effectDisposer === 'function') effectDisposer();
check('注销 effect 后工具被摘掉', toolDisposed);

// --- 汇总 ------------------------------------------------------------------
console.log('--- 本地端到端检查 ---');
for (const entry of checks) {
  console.log(`${entry.ok ? 'PASS' : 'FAIL'}  ${entry.label}${entry.ok ? '' : `  (${entry.detail})`}`);
}
console.log(`\n${checks.filter((entry) => entry.ok).length}/${checks.length} 通过`);

server.close();
await rm(scratch, { recursive: true, force: true });
if (failures.length > 0) throw new Error(`${failures.length} 项失败`);
