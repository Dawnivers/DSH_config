// 极简静态文件服务：把工作区的图片暴露给本机/局域网，用于测试
// Agnes 服务端能否取到 first_frame 图片。
import { createServer } from 'node:http';
import { readFile, stat } from 'node:fs/promises';
import { extname, join, normalize } from 'node:path';

const root = process.argv[2] ?? process.cwd();
const port = Number(process.argv[3] ?? 8123);
const host = process.argv[4] ?? '0.0.0.0';

const TYPES = {
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.mp4': 'video/mp4',
};

const server = createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host}`);
  const requested = normalize(decodeURIComponent(url.pathname)).replace(/^([/\\])+/, '');
  const file = join(root, requested);
  console.log(`${new Date().toISOString()} ${req.method} ${url.pathname} -> ${file}`);
  try {
    const info = await stat(file);
    if (!info.isFile()) throw new Error('not a file');
    const body = await readFile(file);
    res.writeHead(200, {
      'Content-Type': TYPES[extname(file).toLowerCase()] ?? 'application/octet-stream',
      'Content-Length': body.length,
      'Cache-Control': 'no-store',
    });
    res.end(body);
  } catch (error) {
    res.writeHead(404, { 'Content-Type': 'text/plain' });
    res.end(`not found: ${requested}\n`);
  }
});

server.listen(port, host, () => {
  console.log(`静态服务已启动 http://${host}:${port} 根目录 ${root}`);
});
