/**
 * Defer real session creation until the first prompt.
 *
 * The panel calls `session.create` as soon as it connects, but a session that
 * is opened and never used should leave zero trace in the store/GUI. This
 * wrapper answers `session.create` with a provisional id (minted locally,
 * nothing persisted), serves `session.history` for provisional ids as empty,
 * and materializes the real session — same id, original create payload — on
 * the first `session.prompt` for that id. Abandoned provisional ids are
 * pruned after {@link PROVISIONAL_TTL_MS}.
 *
 * Provisional sessions also answer `session.models` from the host-wide
 * `session.modelCatalog` (via the Host API adapter, plus a pending switch)
 * and remember `session.selectModel` until materialization, so the composer can
 * show a model switcher before the first message.
 *
 * @module @yuxianglin/dsh-bridge-browser/src/session-deferral
 */
import type { ImageAttachmentLimits } from '@deepseek-ai/dsh-attachment';
import type { BrowserHostApi } from './host-api.ts';
/**
 * Wrap the gateway sessions API so `session.create` returns a provisional id
 * without creating anything; the real session materializes on the first
 * `session.prompt` for that id.
 *
 * @param api - Gateway API implementation.
 * @param enabled - Whether deferral is active; false returns the API untouched.
 * @param imageLimits - actual host image capability, used for the synthetic
 * empty history before the deferred Session exists.
 * @returns the original API when disabled, otherwise the wrapped API.
 */
export declare function withSessionDeferral(api: BrowserHostApi, enabled: boolean, imageLimits?: ImageAttachmentLimits): BrowserHostApi;
//# sourceMappingURL=session-deferral.d.ts.map