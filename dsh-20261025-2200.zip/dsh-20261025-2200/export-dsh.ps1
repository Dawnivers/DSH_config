#requires -Version 7
<#
.SYNOPSIS
  导出一份可搬到新电脑的 DSH「人格 + 项目历史」迁移包。

.DESCRIPTION
  收集构成「和你一起做过很多项目、懂你风格」的全部持久数据：
    - %DSH_HOME%\sessions          每个会话的完整对话（.zstd jsonl）
    - %DSH_HOME%\attachments       会话里发过的图片/文件（可跳过）
    - %DSH_HOME%\storages          workspace 注册表、cost-meter 账本、会话索引
    - %DSH_HOME%\skills            装到 home 的技能包
    - %DSH_HOME%\task-board        任务板账本
    - %DSH_HOME%\.credentials.yaml API 密钥（明文，仅靠文件 ACL 保护，可直接搬）
    - %USERPROFILE%\.mnemon        MEMORY.md / USER.md / memories.json —— 真正的「它记得你」
    - 各 profile 的 package.json / lock / cordis.patch.yml（不含 node_modules，重装更快）
    - 所有 link: 插件的源码目录（自研插件，market 装不回来）

  刻意不导出：node_modules、cache、browser-sessions（登录态与本机绑定）、日志、端口 shim。

.EXAMPLE
  pwsh -File .\export-dsh.ps1
  pwsh -File .\export-dsh.ps1 -SkipAttachments -OutRoot 'E:\dsh-migration'
#>
[CmdletBinding()]
param(
  [string]$OutRoot = 'D:\dsh-migration',
  [switch]$SkipAttachments,
  [switch]$ExcludeSecrets
)

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'

function Get-DshHome {
  if ($env:DSH_HOME) { return $env:DSH_HOME }
  return (Join-Path $env:USERPROFILE '.dsh')
}

function Invoke-Robocopy {
  param([string]$Source, [string]$Destination, [string[]]$ExcludeDirs = @())
  $rcArgs = @($Source, $Destination, '/E', '/R:1', '/W:1', '/NFL', '/NDL', '/NJH', '/NJS', '/NP')
  if ($ExcludeDirs.Count -gt 0) { $rcArgs += '/XD'; $rcArgs += $ExcludeDirs }
  $null = robocopy @rcArgs
  if ($LASTEXITCODE -gt 7) { throw "robocopy failed ($LASTEXITCODE): $Source -> $Destination" }
}

function Get-TreeStats {
  param([string]$Path)
  if (-not (Test-Path $Path)) { return [pscustomobject]@{ files = 0; mb = 0 } }
  $f = Get-ChildItem $Path -Recurse -File -Force -ErrorAction SilentlyContinue
  return [pscustomobject]@{ files = $f.Count; mb = [math]::Round((($f | Measure-Object Length -Sum).Sum / 1MB), 2) }
}

$dshHome = Get-DshHome
$mnemonHome = Join-Path $env:USERPROFILE '.mnemon'
$stamp = Get-Date -Format 'yyyyMMdd-HHmm'
$dest = Join-Path $OutRoot "dsh-$stamp"

Write-Host "DSH_HOME : $dshHome"
Write-Host "mnemon   : $mnemonHome"
Write-Host "导出到    : $dest"
Write-Host ''

New-Item -ItemType Directory -Force -Path $dest | Out-Null

# ---------------------------------------------------------------- 1. home 目录
$homeDirs = @('sessions', 'skills', 'storages', 'task-board', 'pets', 'llm-deepseek',
  'agents-anywhere', 'dsh-usage', 'dsh-session-archive')
if (-not $SkipAttachments) { $homeDirs += 'attachments' }

foreach ($d in $homeDirs) {
  $src = Join-Path $dshHome $d
  if (-not (Test-Path $src)) { Write-Host "skip (missing): $d" -ForegroundColor DarkGray; continue }
  Invoke-Robocopy -Source $src -Destination (Join-Path $dest "home\$d") -ExcludeDirs @('cache', 'Cache')
  $s = Get-TreeStats (Join-Path $dest "home\$d")
  Write-Host ("  home\{0,-20} {1,5} files  {2,8:N2} MB" -f $d, $s.files, $s.mb)
}
if ($SkipAttachments) { Write-Host '  home\attachments        已跳过（历史会话里的图片会显示不出来）' -ForegroundColor Yellow }

# ---------------------------------------------------------------- 2. home 文件
$homeFiles = @('.credentials.yaml', '.env', 'pet.json', 'skin-center-active.json', '.anonymous-user-id')
New-Item -ItemType Directory -Force -Path (Join-Path $dest 'home') | Out-Null
$withheld = @()
foreach ($f in $homeFiles) {
  $src = Join-Path $dshHome $f
  if (-not (Test-Path $src)) { continue }
  if ($ExcludeSecrets -and $f -in @('.credentials.yaml', '.env')) {
    $withheld += $f
    Write-Host "  home\$f  (含密钥，已排除)" -ForegroundColor Yellow
    continue
  }
  Copy-Item $src (Join-Path $dest "home\$f") -Force
  Write-Host "  home\$f"
}
if ($withheld.Count -gt 0) {
  @(
    '本迁移包刻意不含以下文件（含密钥，禁止外传）:'
    ''
    ($withheld | ForEach-Object { "- $_" })
    ''
    '换机时请从旧机单独复制，或用 GUI 重新录入 API Key。'
  ) | Set-Content (Join-Path $dest 'home\SECRETS_WITHHELD.txt') -Encoding utf8
}

# ---------------------------------------------------------------- 3. mnemon（记忆本体）
if (Test-Path $mnemonHome) {
  Invoke-Robocopy -Source $mnemonHome -Destination (Join-Path $dest 'mnemon') -ExcludeDirs @('cache', 'logs', 'Cache')
  $s = Get-TreeStats (Join-Path $dest 'mnemon')
  Write-Host ("  mnemon                  {0,5} files  {1,8:N2} MB" -f $s.files, $s.mb)
} else {
  Write-Host '  !! 没找到 ~/.mnemon —— 迁移包不含记忆，新机不会认识你' -ForegroundColor Red
}

# ---------------------------------------------------------------- 4. profile 配置
$profileMeta = @('package.json', 'pnpm-lock.yaml', 'pnpm-workspace.yaml', 'cordis.patch.yml', 'cordis.yml')
$linkSources = @{}
$profilesDir = Join-Path $dshHome 'profiles'
$profileReport = @()

if (Test-Path $profilesDir) {
  foreach ($prof in (Get-ChildItem $profilesDir -Directory | Where-Object { $_.Name -notlike '.*' })) {
    $dstProf = Join-Path $dest "profiles\$($prof.Name)"
    New-Item -ItemType Directory -Force -Path $dstProf | Out-Null
    foreach ($m in $profileMeta) {
      $src = Join-Path $prof.FullName $m
      if (Test-Path $src) { Copy-Item $src (Join-Path $dstProf $m) -Force }
    }
    $entry = [ordered]@{ profile = $prof.Name; plugins = @(); links = @() }
    $pkgPath = Join-Path $prof.FullName 'package.json'
    if (Test-Path $pkgPath) {
      $pkg = Get-Content $pkgPath -Raw | ConvertFrom-Json
      $deps = [ordered]@{}
      foreach ($set in @('dependencies', 'devDependencies')) {
        $node = $pkg.$set
        if ($null -ne $node) { foreach ($p in $node.PSObject.Properties) { $deps[$p.Name] = "$($p.Value)" } }
      }
      foreach ($name in $deps.Keys) {
        $spec = $deps[$name]
        if ($spec -like 'link:*') {
          $target = $spec.Substring(5).Replace('/', '\')
          $slug = ($name -replace '[@/]', '_') + '__' + (Split-Path $target -Leaf)
          $exists = Test-Path $target
          $entry.links += [ordered]@{ name = $name; target = $target; slug = $slug; exists = $exists }
          if ($exists) { $linkSources[$target] = $slug }
        } else {
          $entry.plugins += [ordered]@{ name = $name; spec = $spec }
        }
      }
    }
    $profileReport += [pscustomobject]$entry
    Write-Host ("  profiles\{0,-14} {1} 个市场插件, {2} 个 link 插件" -f $prof.Name, $entry.plugins.Count, $entry.links.Count)
  }
}

# ---------------------------------------------------------------- 5. link 插件源码
if ($linkSources.Count -gt 0) {
  Write-Host ''
  Write-Host '复制自研（link:）插件源码…'
  foreach ($target in $linkSources.Keys) {
    $slug = $linkSources[$target]
    $dst = Join-Path $dest "plugin-sources\$slug"
    Invoke-Robocopy -Source $target -Destination $dst -ExcludeDirs @('node_modules', '.git', 'dist\cache', '.turbo')
    $s = Get-TreeStats $dst
    Write-Host ("  {0,-52} {1,5} files {2,8:N2} MB" -f $slug, $s.files, $s.mb)
  }
}

# ---------------------------------------------------------------- 6. manifest
$wsList = @()
$wsFile = Join-Path $dshHome 'storages\workspace.json'
if (Test-Path $wsFile) {
  $wsJson = Get-Content $wsFile -Raw | ConvertFrom-Json
  foreach ($p in $wsJson.tables.workspaces.PSObject.Properties) {
    $wsList += [ordered]@{
      id            = $p.Name
      path          = $p.Value.path
      title         = $p.Value.title
      sessionCount  = @($p.Value.sessionIds).Count
      pathExists    = (Test-Path $p.Value.path)
    }
  }
}

$appVersion = 'unknown'
$appPkg = 'D:\DSH\dsh_data\DSH Desktop\resources\app\package.json'
if (Test-Path $appPkg) { try { $appVersion = (Get-Content $appPkg -Raw | ConvertFrom-Json).version } catch {} }

$manifest = [ordered]@{
  kind          = 'dsh-migration-kit'
  schemaVersion = 1
  exportedAt    = (Get-Date).ToString('o')
  machine       = [ordered]@{ name = $env:COMPUTERNAME; user = $env:USERNAME; userProfile = $env:USERPROFILE }
  dshHome       = $dshHome
  mnemonHome    = $mnemonHome
  dshVersion    = $appVersion
  includeAttachments = (-not $SkipAttachments)
  profiles      = $profileReport
  workspaces    = $wsList
  stats         = (Get-TreeStats $dest)
  restoreHint   = 'RESTORE.md（与本脚本同目录）'
}
$manifest | ConvertTo-Json -Depth 8 | Set-Content (Join-Path $dest 'manifest.json') -Encoding utf8

# ---------------------------------------------------------------- 7. 自带说明书与还原脚本
foreach ($c in @('RESTORE.md', 'restore-dsh.ps1', 'export-dsh.ps1')) {
  $src = Join-Path $PSScriptRoot $c
  if (Test-Path $src) { Copy-Item $src (Join-Path $dest $c) -Force }
}

$total = Get-TreeStats $dest
Write-Host ''
Write-Host ("完成：{0}  ({1} 个文件, {2:N2} MB)" -f $dest, $total.files, $total.mb) -ForegroundColor Green
Write-Host "把它连同 RESTORE.md 一起拷到移动硬盘 / 网盘即可。" -ForegroundColor Green
