---
id: "c78f3a16-ac75-45fb-9ad6-6616d78c061f"
title: "dsh plugin add 报 ERR_PNPM_UNEXPECTED_STORE：PATH 里 pnpm 10.33.0 抢在 11.8.0 前面（web profile，2026-11-08）"
description: "web profile 用 pnpm 11.8.0 装的 node_modules，但 dsh plugin add 子进程从 PATH 解析到 pnpm 10.33.0 去 store\\v10 找包导致 UNEXPECTED_STORE；含源码定位（runPlugin→runProfilePnpm 走 PATH）、只在本进程置顶 11.8.0 shim 的修法、以及三种残留失败信号的分诊表。与 ac6baad9 方向相反、互补。"
status: "active"
created_at: "2026-11-08T09:13:09.863Z"
updated_at: "2026-11-08T09:13:09.863Z"
content_hash: "cf315d6e66e13ffcf01b75bb9c95d34553c6f47d9a1592154e8de032dbf10cf1"
source_paths:
  - "install-dsh-with-pencil.ps1"
session_ids:
  - "febe2c90-22af-4c61-9420-092313f9dc8f"
memory_body_ids:
  []
---

# dsh plugin add 撞上第二个 pnpm：根因与 shim 修法

排查日期：2026-11-08。宿主：DSH Desktop（`D:\DSH\dsh_data\DSH Desktop`），目标 profile：`web`。
现象：安装 pencil 相关插件时 `dsh plugin add` 失败，报 `ERR_PNPM_UNEXPECTED_STORE`。

相关文档（本文与其方向相反，互为对照）：
- `ac6baad9-9666-4ff6-99ff-d67b6334c628` — Translation 项目里 pnpm **11** 去动 pnpm **10** 装的 `node_modules` 被中止（NO_TTY 那条链）；本文是 pnpm **10** 去动 pnpm **11** 装的 `node_modules`。两份合起来才是「本机两个 pnpm 不能混用」的完整说明。
- `bc1691b2-c8c1-41ad-a301-37cac4c79602` — pnpm store 本身是 profile 插件的实体存放地，不是可清理缓存。

## 1. 根因（一句话）

`web` profile 是 pnpm **11.8.0** 装的（`.modules.yaml` 记 `packageManager: pnpm@11.8.0`、`storeDir: C:\Users\林先语\AppData\Local\pnpm\store\v11`），而 `dsh plugin add` 在子进程里从 **PATH** 解析到了 pnpm **10.33.0**（`C:\Users\林先语\AppData\Roaming\npm\pnpm.cmd`），它默认去 `store\v10` 找包。v10 用散装 index、v11 用 `index.db`，格式互不兼容 → `UNEXPECTED_STORE`。

**用户没有操作错**：本机并存两个 pnpm 是既成事实——Translation 项目仍依赖 10.33.0，所以两个都不能删。

## 2. 源码证据（均为 checkout/npx 缓存的只读文件）

- `...\node_modules\@deepseek-ai\dsh\lib\bin.js` L234-236：`case "plugin"` → `process.exit(await runPlugin(invocation.profile, invocation.args, options.packageManager))`。
- `...\lib\plugin-BGnVfe_D.js` L63-99：`runPlugin` 组 context/options 后调 `runProfilePnpm`；L94 专门处理 `exitCode === 127` 并打印「pnpm was not found; install pnpm and make it available on PATH」——**即 pnpm 是从 PATH 找的，不是固定用安装目录里那份**。
- `...\@deepseek-ai\dsh-plugin-manager\lib\types\operations.js` L246+：`runProfilePnpm` 会先拍 `package.json` / `pnpm-lock.yaml` 快照、做兼容性 preflight、把 pnpm 输出落到 `.plugin-manager/logs/operation-*/pnpm.log`（失败时 dsh 会打印该路径）。
- PATH 实测顺序（`where pnpm`）：① DSH Desktop `runtime-commands\...\bin\pnpm.cmd` = 11.8.0；② `C:\Users\林先语\AppData\Roaming\npm\pnpm.cmd` = 10.33.0 ← 实际被解析到的那个。
- 该 runtime-commands 的 `pnpm.cmd` 是 Electron-as-node 包装（`ELECTRON_RUN_AS_NODE=1` + `npm_config_runtime=electron`、`npm_config_target=44.0.0`），不是普通 pnpm 启动器，不建议硬编码改它。
- 探针验证：把 shim 目录置顶 PATH 后让 dsh 转发 `--version`，输出 **11.8.0** → 确认「置顶 PATH 即可换靶」。

## 3. 修法：不动全局 pnpm，只在本进程置顶 shim

写 `D:\DSH\shims\pnpm.cmd`，内容转发到 DSH 自带 pnpm：

```bat
node "D:\DSH\dsh_data\DSH Desktop\resources\app\node_modules\pnpm\bin\pnpm.cjs" %*
```

脚本 `install-dsh-with-pencil.ps1`（工作区内）第 3 段在**真装模式**下依次做三件事：

```powershell
# ① 写出 shim（不碰系统 PATH、不碰全局 pnpm）
# ② 校验 shim 版本，不是 11.x 直接终止
if ($shimVer -notmatch '^11\.') { Die "shim 版本异常：$shimVer" }
# ③ 只在本进程把它置顶
$env:PATH = "$ShimDir;$env:PATH"
```

**为什么不升级全局 pnpm**：Translation 的 `node_modules` 是 v10 store 装的，把全局 pnpm 升到 11 会让那边报同一个错（方向反过来，见 `ac6baad9`）。切靶不动枪是唯一两边都活的解。

注意：shim 在**工作区 cwd** 下 `store path` 会给出 `D:\.pnpm-store\v11`，在 **profile 目录 cwd** 下才是 `C:\...\pnpm\store\v11`。dsh 安装时 cwd 是 profile 目录，所以正常路径下 store 是对的；若仍报 store 不匹配，再显式加 `--config.store-dir`。

## 4. 残留失败信号分诊表

| 现象 | 含义 | 下一步 |
|---|---|---|
| 仍是 `UNEXPECTED_STORE` 但提到 **v11** | 已用上自带 pnpm，只是 store 路径不对（`D:\.pnpm-store`） | 给 `dsh plugin` 加 `--config.store-dir` |
| `ERR_PNPM_ABORTED_REMOVE_MODULES_DIR_NO_TTY` | pnpm 11 的 `verify-deps-before-run` 默认值改为 `install`，偷偷跑 install 后判定重建 | profile 的 `pnpm-workspace.yaml` 加 `verifyDepsBeforeRun: false`（camelCase；项目级 `.npmrc` 对 pnpm 专属键无效） |
| 装成功但校验段红 | 装了没落盘 | 看 `C:\Users\林先语\.dsh\profiles\web\.plugin-manager\logs\operation-*\pnpm.log` |

## 5. 状态与回滚

- 本轮只做了「语法检查（仅解析未执行）」与 shim/脚本的准备，**未确认安装成功**；结论是根因确定 + 修法已固化进脚本。
- 回滚点：`D:\DSH\backup\web-20261108-170706`（约 17914 个文件，可用脚本 `-RestoreFrom` 恢复）。
