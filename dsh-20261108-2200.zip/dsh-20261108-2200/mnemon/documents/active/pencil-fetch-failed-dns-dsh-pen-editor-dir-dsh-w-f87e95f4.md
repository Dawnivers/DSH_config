---
id: "f87e95f4-b382-40f9-9570-0c921c3d11e0"
title: "Pencil 编辑器包离线注入：fetch failed 的代理/DNS 根因与 DSH_PEN_EDITOR_DIR 方案（dsh-with-pencil 0.7.0 第三、四关，2026-11-08）"
description: "记录 dsh-with-pencil@0.7.0 真装成功（退出码 0、三项产物校验通过）后，第四层画布渲染卡在 fetch failed 的网络定位：editor-bundle-v0.1.94.zip 直连 DNS 解析失败、代理 127.0.0.1:7897 返回 200 而 Node fetch 未走代理；给出走代理下载 + SHA-256 比对一致 + DSH_PEN_EDITOR_DIR 指向本地 out 的离线注入法、必须重启进程、以及四层验证顺序。前置：c78f3a16（pnpm）、50661f2d（IGNORED_BUILDS）、6720aca3（脚本）、817893a4（版本）。"
status: "active"
created_at: "2026-11-08T09:32:42.622Z"
updated_at: "2026-11-08T09:32:42.622Z"
content_hash: "08627da3c81b29f2ceaf2688752e20ea66f217eb08f1340108632c616364e624"
source_paths:
  - "install-dsh-with-pencil.ps1"
session_ids:
  - "4e541418-9f72-43b8-b151-6c9f1d3879e0"
memory_body_ids:
  []
---

# 第三关通过、第四关卡住：编辑器包的离线注入

日期：2026-11-08。profile `web`，宿主 DSH **0.2.0-rc.2**（Node v24.16.0），插件 `dsh-with-pencil@0.7.0`，脚本 `install-dsh-with-pencil.ps1`。
**前置文档**：`c78f3a16`（pnpm 10.33.0 抢在 11.8.0 前 → `UNEXPECTED_STORE`）、`50661f2d`（`ERR_PNPM_IGNORED_BUILDS` + robocopy 回滚残留）、`6720aca3`（脚本五段设计）、`817893a4`（版本选型）。

## 1. 真装成功的确证（第三关关闭）

补 `sharp: false` 与清理残留后重跑，第 3–5 段输出：

```
[OK] pnpm shim 就绪：11.8.0  (D:\DSH\shims\pnpm.cmd)
[OK] allowBuilds 已补 sharp: false（原文件备份 pnpm-workspace.yaml.bak-20261108-172024）
[OK] 已清理残留：node_modules\dsh-with-pencil
[OK] 已清理残留：node_modules\@pen.dev
+ dsh-with-pencil 0.7.0
Packages: +65 -12
Progress: resolved 315, reused 75, downloaded 0, added 65, done
Done in 2.7s using pnpm v11.8.0
[OK] 安装命令执行成功
=== 4. 校验 ===
[OK] package.json 已声明：0.7.0 / 实际版本 0.7.0 / 官方 @pen.dev/cli 已就位
=== 5. 收尾 ===
[OK] 已写入用户环境变量 DSH_PEN_EDITOR_CACHE_DIR=D:\DSH\pencil-editor
```

关键对比：这次 `reused 75, downloaded 0`（前两次是 `downloaded 59`），说明前一轮的包在 pnpm store 里完好、失败纯属收尾策略判定。**`+65 -12` 里那 `-12` 是正常替换**，不是包缺失。

产物落盘核实（profile 的 `node_modules\dsh-with-pencil`）：

```
lib\index.js      True   宿主侧
lib\client.js     True   浏览器侧（web 界面靠它渲染画布标签）
cordis.patch.yml  True   插件挂载声明
```

profile bundle 列表变成：`@deepseek-ai/dsh-base, @deepseek-ai/dsh-web-app, dshmarket, dsh-better-sidebar, @linxin666/dsh-web-all, dsh-with-pencil`。

## 2. 四层验证：前三层过、第四层死

启动方式（两行环境变量都要，用户级变量对已开窗口不生效）：

```powershell
$env:DSH_PEN_EDITOR_CACHE_DIR = 'D:\DSH\pencil-editor'
npx --yes @deepseek-ai/dsh@0.2.0-rc.2 web
```

| 层 | 结果 | 失败含义 |
|---|---|---|
| 1 页面能开 | ✅ | 插件把宿主搞崩 → 回滚 |
| 2 会话能建 | ✅ | 与其他插件（dshmarket / better-sidebar）打架 |
| 3 画布标签出现（`pen.dev 画布`） | ✅ | 侧栏插槽冲突（最可能是 `dsh-better-sidebar` 抢 `sidebar-right`） |
| 4 编辑器渲染 | ❌ `fetch failed` | 首次下载 editor bundle 失败 |

**第 3 层通过是有价值的负结果**：`dsh-better-sidebar` 与 `dsh-client-ui-sidebar-right` 目前**没有**冲突，之前列的"侧栏打架"风险在本机可降级。

## 3. 第四层根因：域名直连解析失败，代理可用但 Node fetch 没走

插件内写死的下载源（从 `lib` 里 grep 出）：

```
版本：0.1.94
API： https://api.pencil.dev
包：  https://fauuw1qyejoc3spm.public.blob.vercel-storage.com/editor-bundle-v0.1.94.zip
SHA-256（内置）：7b655d0ee6b18ca460959573661c250db650538443466c2783dd089d3e4ad22a
```

网络实测：

| 路径 | 结果 |
|---|---|
| 代理端口 `127.0.0.1:7897` 是否在听 | True |
| `curl` 走代理 HEAD 该 zip | `200 Connection established` + `HTTP/1.1 200 OK`，`Content-Length: 24792525` |
| `curl` 直连 | `curl: (6) Could not resolve host`（DNS 解析失败/污染） |

环境里 `HTTP_PROXY` / `HTTPS_PROXY` = `http://127.0.0.1:7897`、`NODE_USE_ENV_PROXY=1`、`no_proxy` 含 `127.0.0.1,localhost,.local` 与内网地址；Windows 系统代理 `ProxyEnable=1 / ProxyServer=127.0.0.1:7897`。

结论：**代理本身没问题，是 dsh 进程内的 Node `fetch` 没吃到代理配置**（子进程环境被清洗，或插件自建请求）。这一整类不确定性不值得继续调，直接绕开。

## 4. 离线注入方案（已验证到"目录就绪"）

```powershell
# ① 走代理把包下到本地（23.6 MB）
curl -x http://127.0.0.1:7897 -L -o D:\DSH\pencil-editor\download\editor-bundle-v0.1.94.zip `
  'https://fauuw1qyejoc3spm.public.blob.vercel-storage.com/editor-bundle-v0.1.94.zip'

# ② 校验必须与内置值一致：7b655d0e…4ad22a
Get-FileHash <zip> -Algorithm SHA256      # 实测 MATCH ✅

# ③ 解压——zip 里就一个 out/ 目录，index.html 在其下
#    D:\DSH\pencil-editor\download\extract\out\index.html

# ④ 指向它（持久 + 当前窗口各一遍）
[Environment]::SetEnvironmentVariable('DSH_PEN_EDITOR_DIR','D:\DSH\pencil-editor\download\extract\out','User')
$env:DSH_PEN_EDITOR_DIR = 'D:\DSH\pencil-editor\download\extract\out'

# ⑤ 必须 Ctrl-C 停掉 dsh web 再重启：环境变量是启动时读的，界面上的「重试」无效
npx --yes @deepseek-ai/dsh@0.2.0-rc.2 web
```

与 `DSH_PEN_EDITOR_CACHE_DIR` 的分工：后者是**缓存根**（默认落 `C:\Users\<user>\.dsh\dsh-with-pencil\editor`，故挪到 D 盘），前者是**直接指定已解压的编辑器目录、跳过下载**。两者可并存。

## 5. 兜底判读与回滚

- 若重启后仍报同样错误 → 插件没读该变量，先确认 `$env:DSH_PEN_EDITOR_DIR` 在进程里；仍无效则看报错是否变成 `ENOENT` / `missing asset`，那种情况多半是层级问题（可能需要指 `extract` 而非 `extract\out`）。
- 该 zip 保留在 `D:\DSH\pencil-editor\download\`，将来插件升级换 editor 版本时可复用"下载 + 比对 SHA-256"这套流程。
- 回滚：`.\install-dsh-with-pencil.ps1 -RestoreFrom 'D:\DSH\backup\web-20261108-172024'`（另有 `web-20261108-170706`、`171628` 两份更早备份）。

## 6. 方法论小结

1. **层层剥离**：真装失败的三个卡点（pnpm store 版本 → allowBuilds 策略 → 编辑器下载）彼此无关，每次只推进一层，不要在失败态上叠改动。
2. **"包已装上"≠"安装失败"**：pnpm 的 `IGNORED_BUILDS` 与插件的 `fetch failed` 都是收尾阶段判死，产物已落盘；判断要看具体退出点而非最终红字。
3. **下载类故障先测网络通路再改代码**：一条 `curl -x` 的 HEAD 就能把"代理坏了"与"进程没走代理"分开，比调 Node 代理配置快得多。
4. **校验优先**：手动替换官方产物前必须比对内置 SHA-256，否则等于在无法验证的二进制上做实验。
