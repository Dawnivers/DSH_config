---
id: "af46c87d-2aab-4980-8421-752bbf7f38a5"
title: "schedule 驱动 DSH 周备份的端到端实测通过（2026-11-07 真实推送与验收数据）"
description: "记录 2026-11-07 用一次性 schedule after 任务驱动 publish-dsh.ps1 真实推送 GitHub 的一次完整验证：四条验收逐项通过、耗时从此前 482s 降到 200.9s 的原因（先剪枝再导出使导出量 77MB→39MB）、远端保留 2 包、包内无密钥，以及 GitHub contents API 必须带 User-Agent 才返回数据的实测坑；含「先验证成功再关看板」的顺序理由。"
status: "active"
created_at: "2026-11-07T12:34:35.076Z"
updated_at: "2026-11-07T12:34:35.076Z"
content_hash: "c27db3e72f0bfd748fdcd9e3dca29cba636401c8aef32ae44f88c6aafc01f02f"
source_paths:
  - "dsh-migration/publish-dsh.ps1"
  - "dsh-migration/prune-sessions.mjs"
  - "dsh-migration/distill-dsh.mjs"
session_ids:
  - "eb0ec7f5-7a09-45b2-b76d-ae1ef09ea9fc"
memory_body_ids:
  []
---

# schedule 驱动 DSH 周备份：端到端实测通过（2026-11-07）

背景：DSH 配置周备份的定时已从任务看板卡 `ead69e05` 迁到 schedule 插件任务 `schedule-d248da8c`（迁移机制、两种载体的补发/会话绑定差异见 `9cf2539b`；发布流水线 publish-dsh.ps1 的设计取舍见 `284e4a5f`）。迁移后只验证过「到点 → 恢复会话 → 追加 followup」的投递链路（60 秒 after 测试提醒），**没有验证过「schedule 投递后真的能跑完并推送成功」**。本文补上这一段。

## 1. 验证方式

建一条一次性 `kind: after` 任务（`afterSeconds: 60`）复刻正式 weekly 任务的 prompt，让它自然触发后在本会话执行真实备份；跑完删除该任务，正式任务保留在排程上（下次 2026-11-08 22:00）。这样一次覆盖整条链：**cron/after 触发 → 宿主投递 → 会话执行 → 脚本跑通 → GitHub 推送成功 → 验收**。

## 2. 结果：四条验收全部通过

| # | 检查项 | 实测 |
|---|---|---|
| 1 | `D:\dsh-migration\publish-state.json` 的 `result` / `sizeMB` | `pushed` / 11.6，与本地 zip 实际大小差 0.001 MB |
| 2 | 远端 main 出现新包 + `LATEST.json` | `dsh-20261107-2029.zip` 11.60 MB + `LATEST.json` |
| 3 | `LATEST.json` 的 sha256 = 本地 `Get-FileHash` | 两侧同为 `B0A590FB…4430BAD1` |
| 4 | 远端只留 2 个包 / 包内无密钥 | 2 个（本周 + 上周 `dsh-20261101-2200.zip`）；包内 `home\` 无 `.credentials.yaml`、无 `.env` |

远端最终内容：`LATEST.json`、`README.md`、`dsh-20261101-2200.zip`(11.28MB)、`dsh-20261107-2029.zip`(11.60MB)；上一周之前的 `dsh-20261025-2200.zip` 按保留策略被清掉。包内条目 1573 个，`distill/` 6 份摘要、`mnemon/` 341 条、`profiles/` 13 条，`RESTORE.md`/`EXCLUDED.md` 齐全。

脚本自身旁证：提炼 32 个会话（跳过子代理 107 / 碎片 3）→ `distill-20261107.md` 84.6 KB、打码 0 处；剪枝真搬 28 个会话 43.74 MB 到 `D:\dsh-migration\session-trash\20261107-2029`；包内脱敏 `changedFiles: 0, replacements: 0`；密钥体检 `{"result":"clean","candidates":0}`。

## 3. 耗时数据修正：200.9s，不是 8~10 分钟

| 跑次 | 耗时 | 包大小 | 导出量 |
|---|---|---|---|
| 2026-11-01（看板卡） | 482.3s | 11.28 MB | 会话/projcache 未剪 |
| 2026-11-07（schedule） | **200.9s** | 11.60 MB | 剪枝后 39.23 MB / 1282 文件 |

差异原因：脚本顺序是「提炼 → 剪枝 → 导出」，本次先搬走 28 个大会话，导出总量从 77 MB 级别降到 39 MB，压缩与组装都跟着变快。**结论：历史 8~10 分钟的估算应按数据量退让，不能用固定阈值判断是否超时。** 但 prompt 里「必须 `run_in_background: true` 启动、用 `job_output`（必要时 `wait: true`）收结果，不要前台干等」这条保留——某周会话没剪或数据量回升时前台仍可能超时，而 DSH 的 pwsh 超时是**转后台 job 而非杀进程**，误判成失败的风险实打实。

## 4. 实测坑：GitHub contents API 不带 User-Agent 返回空

用 PowerShell 直接请求 `https://api.github.com/repos/Dawnivers/DSH_config/contents?ref=main` 时返回为空（`远端文件数: 0`），加上 `User-Agent` 头重试才拿到完整 JSON 列表。因此**验收第 2 条看到「0 个文件」不等于推送失败**，先补 UA 再判定；`curl.exe -x http://127.0.0.1:7897` 走代理那条命令本身是正常的（同时 `Substring` 对空串取长度还会抛 `MethodInvocationException`，别让这个 stderr 误导结论）。

## 5. 产物落点与后续

- 本次包：`D:\dsh-migration\dsh-20261107-2029.zip`（11.60 MB），回收站目录 `D:\dsh-migration\session-trash\20261107-2029`（57 文件 66.37 MB，含 manifest，30 天后才可 `--purge`）。
- 正式任务状态：`schedule-d248da8c` weekly、weekdays `[7]`、22:00 Asia/Shanghai、`active`，`scheduledAt 2026-11-08T14:00:00Z`（本地 11-08 22:00），投递记录 0。明天那次才验证「周期性 cron 自然触发」，今天只验证了投递+执行链路。
- 一次性验证任务已 `deleted: true`，避免与正式任务重复跑。

## 6. 关闭任务看板的前置条件与顺序

备份链路既已由 schedule 独立跑通，看板的「保险」价值只剩回滚便利性，而它的定时本就 `enabled: false`（不跑的定时器不构成保险，手动入口一条 `pwsh -NoProfile -File .\publish-dsh.ps1` 即可替代）。可关的三条（省 6,774 token/步）：

```yaml
- id: web-ui-task-board          # 3,431 token/步
  disabled: true
- id: web-ui-task-board-github   # 1,800 token/步
  disabled: true
- id: code-index                 # 1,543 token/步
  disabled: true
```

改 `C:\Users\林先语\.dsh\profiles\desktop\cordis.patch.yml`（改前备份带时间戳副本，重启生效）。关掉后侧栏「任务看板」入口消失，另两张卡（「任务看板冒烟演示」无定时、「DSH 外壳补丁 live 体检」已停用）只是看不见，数据在 `ledger-v2.json` 里完好、重新启用插件可读回。注意关插件后回滚要改 yml + 重启，不能再用 `task_board_schedule` 一行改回。

## 7. 源文件

- `dsh-migration/publish-dsh.ps1` — 本次实际执行主体（提炼→剪枝→导出→脱敏/体检→zip→force push→写 publish-state.json）
- `dsh-migration/prune-sessions.mjs`、`dsh-migration/distill-dsh.mjs` — 被编排的两步
- 相关文档：`9cf2539b`（看板→schedule 迁移记录）、`284e4a5f`（发布流水线与 token/代理）、`3a43c83f`（看板卡 prompt 冻结与 promptPrefix 补丁）
