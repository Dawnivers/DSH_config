---
id: "68b45688-ab13-43fb-90be-e78debf6c763"
title: "pen.dev 画布为何留在 web profile：DSH 双 profile 架构、桌面端安装的真实代价与 C 盘占用（2026-11-08 实测）"
description: "回答\"机器上是不是有两个 DSH\"\"为什么插件不装进桌面端\"：实测两个进程/端口/插件数、~/.dsh 共享与隔离的边界、desktop profile 的 18 依赖 9 个 link 地形与两次 EPERM 事故、CLI 要求完全退出 Desktop 的硬约束、peer 精确钉导致的升级断裂、三条可选路线与安全安装流程，以及 npx 把 495MB 落在 C 盘的违规与 A/B/C 补救。前置：92617817（黑屏真因）、817893a4（版本矩阵）、379b1ca7（离线注入收尾）。"
status: "active"
created_at: "2026-11-08T12:24:15.212Z"
updated_at: "2026-11-08T12:24:15.212Z"
content_hash: "b646c43c4159e181c1c9eaa2ec3df52e9825a7d2adfae4a2184baa4f19eabae9"
source_paths:
  - "install-dsh-with-pencil.ps1"
session_ids:
  - "be6c1036-4a0d-44c9-b9e5-3d8812627bf2"
memory_body_ids:
  []
---

# 为什么 pen.dev 画布留在 web profile，而不是装进桌面端

日期：2026-11-08。宿主 DSH **0.2.0-rc.2**，插件 **dsh-with-pencil@0.7.0**（已登录、画布可用）。
**前置文档**：`92617817`（"纯黑"= iframe 高度 0 + pen.dev 强制登录，CDP 实证）、`817893a4`（版本适配矩阵）、`379b1ca7`（离线编辑器注入收尾）。
本文只记**登录打通之后**才被问到、且需要实测才能回答的两件事：一、机器上到底跑着几个 DSH；二、为什么不把插件装进 desktop profile。

## 1. 实测：不是两个 DSH，是同一程序的两份 profile

| 端口 | 进程 | PID | profile | 插件数 |
|---|---|---|---|---|
| **57870** | `DSH Desktop.exe` | 34212 | `desktop` | **18**（dsh-tui / modlens / agnes / video-storyboard / context7 / mnemon……） |
| **3080** | `node.exe`（npx 起） | 28896 | `web` | **4**（dshmarket / better-sidebar / dsh-web-all / **dsh-with-pencil**） |

程序本体同版本，差别只在读哪份配置。类比：同一个 Chrome，两个 `--user-data-dir`。

**共享**（同一份 `C:\Users\<user>\.dsh\`）：`sessions/`、`attachments/`、`.credentials.yaml`、`dsh-usage/`、`skills/`、`storages/`。
**隔离**：`profiles/desktop` 与 `profiles/web` 各自的 `package.json` / `node_modules`。

后果：两个界面看到**同一批会话**和同一个"今日消费"；但插件是隔离的，所以 **Desktop 窗口永远没有画布标签** —— 这是 profile 隔离，不是 bug。

端口语义也值得写清：3080 那个进程死掉 → 浏览器立刻白屏；**只关浏览器标签** → 服务与画布状态都还在。画布是 iframe 镶在网页里，与 DSH 主界面同源。

> 未实测的风险（架构推断）：两个进程同时对同一个 session 发消息可能互相覆盖，因为它们各自持有内存状态而 `sessions/` 是共享的。切换界面时先停手。

## 2. desktop profile 的地形：这才是"不建议装"的真正理由

`profiles/desktop/package.json` 有 18 个依赖，其中 **9 个是本地源码引用**：

```
link: .../dsh-agnes-core, dsh-agnes-image, dsh-agnes-video,
      dsh-mcp-anysearch, dsh-browser/packages/browser/bridge-browser,
      dsh-academic-research-skills, dsh-archify, dsh-context7
file: .../dsh-video-storyboard
```

含义：任何一次 `pnpm add` 都要重解析这 18 个依赖、重建这 9 个 link；而 Windows 上建 link 需要 rename/junction —— 正是 HMR watcher 占目录时会 `EPERM` 的那个操作。本机在这个目录上出过两次事故：

| 事故 | 位置 |
|---|---|
| pnpm store 被当缓存清理 → profile 依赖被重写成空 | `profiles/desktop` |
| pnpm 11 升级 link 依赖时 rename EPERM → package.json 未改、node_modules 已乱 | `profiles/desktop` |

**硬约束**：CLI 源码里明写（`plugin-BGnVfe_D.js:11`）——

> Open DeepSeek Harness Desktop once to initialize its profile, **then fully quit it** before running `dsh plugin --profile desktop`.

即操作窗口是"你没法用 DSH"的时段；而 Desktop 启动时若发现依赖缺失，会**直接把 profile 依赖重写成空**（已亲眼见过）。相比之下 web profile 坏了只影响 3080，Desktop 照常工作 —— 这就是把 18 个插件隔离在外面的价值。

**第二条**：插件 0.7.0 把 peer **精确钉死**在 `0.2.0-rc.2`。Desktop 迟早升到 `0.2.1-rc.x`，届时：装在 web → 最坏 3080 起不来；装在 desktop → 轻则画布标签消失，重则**整个桌面端拒绝启动**。

## 3. 什么情况下值得冒险装进 desktop

| 使用频率 | 建议 |
|---|---|
| 偶尔一次 | 保持现状，需要时起 3080，用完 Ctrl-C |
| 一周 3 次以上 | 可考虑，但走安全流程 |
| 想和 archify / video-storyboard **共享工具上下文** | 只能装 desktop（同进程才能共享） |

安全流程（第 ② 步必须用户本人做，因为退出 Desktop 会杀掉当前会话）：

```powershell
# ① 全目录备份（18 插件 + 9 个 link，慢，别中断）
robocopy 'C:\Users\林先语\.dsh\profiles\desktop' 'D:\DSH\backup\desktop-<时间戳>' /E
# ② 用户手动完全退出 DSH Desktop
# ③ 补 allowBuilds.sharp（否则 ERR_PNPM_IGNORED_BUILDS）
# ④ 用 pnpm 11.8.0 的 shim 装（否则 ERR_PNPM_UNEXPECTED_STORE）
$env:PATH = 'D:\DSH\shims;' + $env:PATH
npx --yes @deepseek-ai/dsh@0.2.0-rc.2 plugin --profile desktop add dsh-with-pencil@0.7.0
# ⑤ 重开 Desktop 验证
```

## 4. 另一个被这轮暴露的账：npx 把 ~495MB 放到了 C 盘

```
C:\Users\林先语\AppData\Local\npm-cache          933.4 MB
其中 _npx（就是 dsh web 那份运行时）             494.9 MB
```

`npx` 默认整包落 C 盘，与用户"安装一律 D 盘"的硬规矩冲突。三条补救：

- **A（推荐）**：`npm config set prefix D:\DSH\npm-global` + `npm config set cache D:\DSH\npm-cache`，再 `npm i -g @deepseek-ai/dsh@0.2.0-rc.2`，之后直接 `dsh web`，不走 npx。
- **B（最省事）**：只 `npm config set cache D:\DSH\npm-cache`，npx 照用但不再吃 C 盘。
- **C**：装进 desktop profile 一窗搞定 —— 现阶段不建议（见 §2）。

## 5. 登录之后的落盘事实（此前文档没覆盖）

- 登录态持久化在 `C:\Users\林先语\.dsh\dsh-with-pencil\state.json`（560 B，字段 `email` + 504 字符 `token`），下次免登录。**该文件是凭据，不要读出或写进任何记录。**
- 画布标题栏显示绑定路径，但 `designs/design.pen` **不会**立刻出现在磁盘：全盘搜 `D:\Users\林先语\Documents\deepseek-harness` 与 `C:\...\.dsh` 只找到 `@pen.dev/cli` 自带的 4 个库文件（`halo/lunaris/nitro/shadcn.lib.pen`，11-08 17:16）。结论：**懒创建，首次编辑/保存才落盘**。所以"编辑器能显示"≠"端到端通"。
- 端到端验收标准：在画布侧发指令让模型 `pencil_mcp_open` 打开 `designs/design.pen` 并插入一个 frame，画布出现图形且文件落盘才算通。
- 画布底部两张模板建议卡（humanoid robotics control panel / Lisbon coworking 之类）是 **pen.dev 自家 agent 的入口，点了就是花它账号的 credits/天数** —— 本套方案的目的正是绕开它，别点。
- 仍未解的问题：**手工编辑 + DeepSeek 改本地 .pen 是否会消耗 pen.dev 的"5 设计/月"**。需在登录可用后去账号页比对用量涨幅，目前无结论。

## 6. 结论表（回给用户的定版）

| 问题 | 答案 |
|---|---|
| 要不要装 pen.dev 桌面版 | 不需要，CLI + 编辑器包都已本地化 |
| 能不能不花它的钱做编辑 | 能，编辑器与 9 个工具全本地，模型跑 DeepSeek |
| 要不要登录 | **要**，`get-session` 无账号即拦，硬门槛 |
| 是否两个 DSH | 不是，一个程序两份 profile |
| 画布为什么只在 3080 | 插件装在 web profile |
| 5 天/月会不会被算 | 待实测 |
