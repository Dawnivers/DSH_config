---
id: "f145d381-0818-4e87-93e9-c3fec0c18f81"
title: "实验一：QGIS 批量计算五植被指数（NDVI/NDBI/NDWI/SAVI/EVI）的踩坑与可复跑脚本"
description: "QGIS 批量计算五植被指数的完整可复跑方案：L2SP 反射率换算、DN=0 填充掩膜、gdal_calc 不传播 NoData、EVI 分母保护、QGIS API 与崩溃坑、最终成果数值。"
status: "active"
created_at: "2026-11-08T10:01:11.216Z"
updated_at: "2026-11-08T10:01:11.216Z"
content_hash: "da076a02b871fcca3e6abd1329605047d3939c7e5e4168ac443bab8da14d4f11"
source_paths:
  - "实验一/run_all.py"
  - "实验一/render_one.py"
  - "实验一/annotate.py"
  - "实验一/make_rgb2.py"
  - "实验一/check.py"
session_ids:
  - "11f11495-4001-491a-92fc-f96be397ae09"
memory_body_ids:
  []
---

# 实验一：QGIS 批量计算五种植被指数

工作区 `F:\植被遥感\实验一`，数据为 Landsat C2 L2SP 原始 DN（6 个 SR 波段，7671 × 7781，EPSG:32650，约 227 MB/文件）。全程用 `qgis_process` + PyQGIS 后台执行，不抢占用户桌面。同机其他遥感实验（ENVI + ArcMap，东湖 NDWI/MNDWI）见 `4c9e5e3a-3e5a-46d0-899b-1366e2dbd754` 与 `9a6d1e61-5598-45f2-afa8-2bbe2df41884`。

## 1. 最终成果与数值（可信基线）

| 指数 | 公式 | 值域 | 均值 |
|---|---|---|---|
| NDVI | (B5−B4)/(B5+B4) | −0.9887 ~ 1.0000 | 0.6213 |
| NDBI | (B6−B5)/(B6+B5) | −0.9932 ~ 0.9982 | −0.1800 |
| NDWI | (B3−B5)/(B3+B5) | −0.9999 ~ 0.9996 | −0.6175 |
| SAVI | 1.5(B5−B4)/(B5+B4+0.5) | −0.3139 ~ 0.7935 | 0.3673 |
| EVI | 2.5(B5−B4)/(B5+6B4−7.5B2+1) | −0.3880 ~ 4.0214 | 0.3683 |

产物：`指数成果\`（5 个指数 GeoTIFF + 6 个 `B*_refl.tif` 反射率 + `_RGB.tif` + `.qml` 样式）、`实验截图\成果图\*.png`（无注记）、`实验截图\图_*.png`（1800×2135，带标题/公式/色带/统计）。

保留脚本：`run_all.py`（完整两步流程）、`render_one.py`（PyQGIS 出图）、`annotate.py`（加注记色带）、`check.py`、`make_rgb2.py`。

## 2. 必须注意的五个坑

1. **L2SP 原始 DN 不是反射率**：先做 `DN × 0.0000275 − 0.2`。不换算直接算指数比例影响小，但报告系数对不上。
2. **约 31.78% 像元是 DN=0 填充区**：直接代入 (A−B)/(A+B) 得 0/0 → `inf`/`nan`。必须在反射率阶段把 DN≤0 置为 −9999。
3. **`gdal:translate -a_nodata` 只声明不改值**：0 仍作为真值参与计算。应改用 QGIS 原生重分类/掩膜（`A > 0` 严格条件），不要用 `numpy.where(cond, A*scale-0.2, -9999)` 的写法——`where` 会先算完分支表达式。
4. **`gdal_calc` 默认不传播输入 NoData**：−9999 会进入分子分母，NDVI 一度出现 −1622 ~ 509。修法是在公式里显式掩膜，例如 `A>0 且 B>0` 才计算，否则输出 NoData。
5. **EVI 分母 `A+6B−7.5C+1` 趋零会放大成假值**（曾出 −119.79）：加约束，分母 ≤ 0.2 时跳过。

## 3. 环境与 API 坑

- **QGIS 脚本结束调用 `QgsApplication.exitQgis()` 会崩溃**，退出码 `0xC0000005` / −1073741819，但计算已完成；批处理脚本直接不调 exit 即可（仍可能 exit=1 但产物正常）。
- `QgsRasterBandStats` **没有 `.validPercent`**，只有 `validPercent` 在别处；用栅格属性统计 `STATISTICS_VALID_PERCENT` 代替。
- `QColor` 不在 `qgis.core`，要从 `qgis.PyQt.QtGui` 导入。
- `QgsContrastEnhancement(...)` 重载要显式数据类型，否则真彩色渲染出全白图；最终改用 numpy + Pillow 直接线性拉伸反射率合成真彩色。
- QGIS 自带 GDAL 里 `gdal_calc` 在 `D:\QGIS\apps\Python312\Scripts\`；处理算法路径 `D:\QGIS\apps\qgis-ltr\python\plugins\processing\algs\gdal\`（无 `RasterCalculator.py`，QGIS 版栅格计算器走 `gdal:rastercalculator`）。
- 反射率均值参考：B2 0.0353 / B3 0.0652 / B4 0.0667 / B5 0.2727 / B6 0.1951 / B7 0.1169。

## 4. 交付边界

用户最初要求"提示词补全式伪造人工操作截图"，未执行伪造；所有图均为真实计算渲染。docx 中 7 个截图占位，1、2（数据下载 / QGIS 加载界面）未生成，3–7 用 `实验截图\图_*.png`。报告模板写的是 ArcMap，而实际用 QGIS 3.44，界面不一致需与老师确认；备选方案是改用 ArcGIS Pro `RasterCalculator`。
