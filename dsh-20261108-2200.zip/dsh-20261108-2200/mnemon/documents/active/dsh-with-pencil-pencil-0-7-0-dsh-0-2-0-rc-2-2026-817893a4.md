---
id: "817893a4-bef0-4ec8-971e-51bb2adee33b"
title: "dsh-with-pencil（Pencil 设计插件）版本适配矩阵：0.7.0 对齐本机 DSH 0.2.0-rc.2 的判定与安装路径（2026-11，web profile）"
description: "用 npm 实测发布时间 + peerDependencies 反查 dsh-with-pencil 各版本对应的 DSH 内核线，确认 0.7.0 精确匹配本机 0.2.0-rc.2，并记录 0.8.0/0.6.0/0.5.x 的错配点、0.7.0 安装命令、相对 0.8.0 的实质损失与三条风险。纠正\"按视频发布日期选版本\"的误判方法。"
status: "active"
created_at: "2026-11-08T09:00:05.379Z"
updated_at: "2026-11-08T09:00:05.379Z"
content_hash: "bd14e4e31d5b7af3d99eef147d5ab780364dc0816706922a9dbfc4ddf1f947c4"
source_paths:
  []
session_ids:
  - "80f0f71e-0803-4229-b03e-5c82b455b846"
memory_body_ids:
  []
---

# dsh-with-pencil 版本适配矩阵（本机 DSH 0.2.0-rc.2）

## 0. 结论先行

- 本机内核：`@deepseek-ai/dsh-tools` / `@deepseek-ai/dsh-client-*` = **0.2.0-rc.2**（随 Electron 外壳 `dsh-plugin-desktop` 打包，见文档 `ab5164f9-c8fb-4ebb-befe-305e70609cb7`），Node **v24.16.0**。
- 匹配的插件版本：**`dsh-with-pencil@0.7.0`**（2026-10-10 发布），其 README 明写「targets Harness `0.2.0-rc.2` only」，peerDependencies 全部钉在 `0.2.0-rc.2`。
- 关键方法论纠正：**适配看 peerDependencies 的版本钉，不看发布日期/视频时间**。作者每个版本随 DSH 发版重新钉一次 peer，所以「8 月视频里那版」恰恰是最不匹配的。

## 1. 实测版本时间线（npm）

| 插件版本 | 发布时间 | 钉死的 DSH peer | 对本机 0.2.0-rc.2 |
|---|---|---|---|
| 0.5.0 | 2026-08-18 | `^0.1.0-rc.6` | ❌（视频里那版） |
| 0.5.5 | 2026-08-27 | `^0.1.0-rc.6` | ❌ |
| 0.6.0 | 2026-09-26 | `0.1.7-rc.2` | ❌ |
| **0.7.0** | **2026-10-10** | **`0.2.0-rc.2`** | ✅ |
| 0.8.0 | 2026-11-04 | `0.2.1-rc.5` | ❌ |

0.7.0 的 peer 全集：`react ^18.2.0`、`@deepseek-ai/dsh-tools`、`dsh-client-locale`、`dsh-client-ui-conversation`、`dsh-client-ui-sidebar-right`、`dsh-client-ui-plugin-manager` 均为 `0.2.0-rc.2`；`engines.node` = `^22.19.0 || >=24.0.0`（本机 v24.16.0 通过）。运行时依赖仅 `@pen.dev/cli@0.3.0` + `@deepseek-ai/schemastery ~3.18.4`。

0.7.0 与 0.8.0 **同源**：`@pen.dev/cli@0.3.0`、官方 editor `0.1.94` 完全一致 → 涉及「pen.dev 5 设计/月配额」之类的功能面结论在两版间不变。

## 2. 装 0.7.0 的确切命令（web profile）

```powershell
# ① 先把 editor 缓存挪出 C 盘（默认落 C:\Users\<user>\.dsh\dsh-with-pencil\editor）
$env:DSH_PEN_EDITOR_CACHE_DIR = 'D:\DSH\pencil-editor'

# ② 安装（版本号必须是 0.2.0-rc.2，插件版本必须钉 0.7.0）
npx @deepseek-ai/dsh@0.2.0-rc.2 plugin --profile web add dsh-with-pencil@0.7.0

# ③ 重启：先 Ctrl-C 掉在跑的进程
npx @deepseek-ai/dsh@0.2.0-rc.2 web
```

前置动作：整目录备份 `C:\Users\<user>\.dsh\profiles\web`（本机曾因清理 pnpm store 出过事故）。
从 0.5.x/更早迁移需在插件页**重新设置 `visionMode`**；从旧开发版迁移需先移除 `pen-dev-bridge-bundle` 与 `pen-dev-bridge`，否则同一画布路由注册两次。

## 3. 0.7.0 相对 0.8.0 的实质损失

| 0.8.0 改动 | 对本机影响 |
|---|---|
| 全部 peer 对齐 `0.2.1-rc.5` | 就是装不上的原因，无解（除非先把内核升到 0.2.1 线，见文档 `36e69a5c-e174-4212-a097-191463584022`） |
| 选区上下文 `interpolate: false`，防图层名 `{{}}` 被当模板变量展开 | **唯一实质损失**：避开图层名含双花括号即可 |
| 澄清 Pencil 路径相对原会话项目；新增 `working_directory` 工具 | 说明性/增量工具，不影响基本可用 |
| 复核 0.2.1 新 API 后保留原生 Sidebar / 配置表单 / 原生视觉默认 | 0.7.0 已具备 |

## 4. 三条风险（装前须知）

1. **它是 web profile 插件，不是 desktop 的**：画布出现在 `npx dsh web` 界面，不在 Desktop 窗口；能否塞进 desktop profile 上游文档未写。
2. **右侧栏冲突**：本机 web profile 已有 `dsh-better-sidebar`，而该插件要注入 `dsh-client-ui-sidebar-right`。装完先只验证「标签页能否打开」，别急着调布局。
3. **首次开画布需联网**从 pen.dev 官方源下载 editor 0.1.94 并校验 SHA-256；走代理时最易无声失败（错误在空白 iframe 之前显示，但文案可能含糊）。离线可用 `DSH_PEN_EDITOR_DIR` 指向本地 `out` 目录。

## 5. 插件自身能力要点（0.7.0）

- 注册 9 个核心模型工具：`pencil_mcp_open` / `get_app_state` / `batch_get` / `get_guidelines` / `execute` / `get_screenshot` / `export_html` / `export_nodes` / `insert_image`；5 个旧 CLI 助手默认隐藏（`DSH_PEN_LEGACY_TOOLS=1` 恢复）。
- `visionMode` 默认 `multimodal`（Harness 默认 `deepseek-flash` = DeepSeek-V4.1-Flash 支持图片输入）；`deepseek-v4-pro` 纯文本，无法消费截图；`text` 模式仅供视觉转译包装路由使用。
- 画布绑定会话、右栏原生标签页、Agent 编辑走可见 editor IPC 并等原子保存；画布关闭时退化到官方 headless 引擎。
- 验证方法学：视觉用 `get_screenshot` 抽查（颜色/字体/对齐/位置），文字与属性内容用 `batch_get` 读节点，`export_nodes` 只用于交付产物。

## 6. 可复用的判定流程

1. 读本机 `resources\app\node_modules\@deepseek-ai\dsh-tools\package.json` 拿真实内核版本（不要依赖发布日期）。
2. 拉目标插件 `npm view <pkg> versions` + 各版本 `peerDependencies`，找与内核精确相等的那一版。
3. 顺带核 `engines.node` 与运行时依赖是否引入额外原生库。
4. 只在匹配版本上评估 CHANGELOG 差异，不接受「最新章节体验更好」这种方向性建议。
