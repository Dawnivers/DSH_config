---
id: "ce470377-6fea-473a-af27-af0f5ec641a6"
title: "dsh-video-storyboard 落地实录（2026-11-07）：抖音 URL 归一化与错误分类已实测通过，cookie 墙最终定论 + desktop profile 是复制版的坑"
description: "dsh-video-storyboard 在 v0.6.8 源码上的落地改动与实测结论：抖音 modal_id 形态归一化为 /video/<id> 后 probe 正常，错误分流为「URL 形态/缺 cookie/真不支持」；顺带实证 Chromium 127+ App-Bound Encryption 使 --cookies-from-browser 在本机彻底不可用、iesdouyin 分享页已无直链；以及 desktop profile 装的是复制版导致源码改动不进 DSH、必须跑 scripts/install-dev.mjs 的运维坑。"
status: "active"
created_at: "2026-11-07T14:28:21.386Z"
updated_at: "2026-11-07T14:28:21.386Z"
content_hash: "d7f87e08607dd592490fdb0969c1755604c8751fa7a8f7bb8d85bc19637c8ea9"
source_paths:
  []
session_ids:
  - "ab1bc519-00ed-45df-a178-36e4b8a28b84"
memory_body_ids:
  []
---

# dsh-video-storyboard 落地实录（2026-11-07）

承接 `73d5a289-e348-4259-a937-080ca2b693fe`（支持矩阵与 cookie 墙，属接入前实测）与 `41779d84-0c91-41fd-9781-29e62149d40e`（插件评估）。本文只记**这次真正改了什么、验证到哪一步、以及旧文档没覆盖的两条结论**。

## 1. 改动范围（源码 v0.6.8，位于 `D:/Users/林先语/Documents/dsh-plugins/dsh-video-storyboard`）

| 文件 | 改动 |
|---|---|
| `src/storyboard/url.js` | 新增站点 URL 归一化：从 `douyin.com/user/self/...?modal_id=<id>&type=general` 这类弹层/搜索页抽出视频 id，改写为 `https://www.douyin.com/video/<id>`，返回 `{url, site, rewritten, from}` |
| `src/storyboard/ytdlp.js` | 错误三分流：URL 形态不认 / 缺 cookie / 真不支持；缺 cookie 时输出可执行的修复指引而非「site unsupported」 |
| `src/storyboard/fetch.js` | `probeUrl()` 串上归一化与分类，probe 结果带 `link`、`site`、`note`、`auth` |
| `src/storyboard/format.js` | 结果文案对齐新的分类语义 |
| `test/site-url.test.mjs`、`test/ytdlp-errors.test.mjs` | 新增：归一化纯函数用例、错误分类用例 |
| `docs/USAGE.zh.md`、`CHANGELOG.md` | 同步说明与条目 |

diff 规模约 +283/−29（6 文件 + 2 新测试）。

## 2. 实测：归一化确实救掉了「看起来不支持」这一类

输入（搜索页 + modal_id 形态）：

```
https://www.douyin.com/user/self/search/<关键词>?aid=<uuid>&modal_id=<videoId>&type=general
```

纯函数层（不联网）：

```json
{ "url": "https://www.douyin.com/video/<videoId>", "site": "douyin", "rewritten": true }
```

`probe` 层（真跑 yt-dlp）输出要点：

- `link:` 归一化后的 `/video/<id>`
- `note: rewritten from … — that URL shape has no extractor, the video page form does (same video, same cache entry)`
- `available: no video formats reported` / `auth: anonymous (resolution not guaranteed)`
- `!! NEEDS COOKIES — the link is fine and the site is supported; the extractor just wants a cookie jar (a guest cookie is enough, no login needed). Do NOT call this "site unsupported".`

结论：**“站点不支持”这句话在本机已经不再误导**。同一条链接从“直接判死”变成了“差一份游客 cookie”。

## 3. cookie 墙：三条免浏览器路线全部实证为死路

| 路线 | 结果 |
|---|---|
| `yt-dlp --cookies-from-browser edge` | `Could not copy Chrome cookie database` —— Edge 在跑，`…\Edge\User Data\Default\Network\Cookies` 被独占，连 `Copy-Item` 都报 being used by another process（yt-dlp #7271） |
| 自写 DPAPI + AES-GCM 解 Chromium cookie（`chrome-cookie-probe.py`，40 行） | Chrome 库能复制、能读行、能取 32 字节 key，但解密全部失败：`The computed authentication tag did not match the input authentication tag` → 即 **Chromium 127+ 的 App-Bound Encryption**。插件 `src/storyboard/ytdlp.js:209` 那条提示说的就是它 |
| 免登录分享页 `iesdouyin.com/share/video/<id>` 抠直链 | 返回 200 / 32335 字节的**壳页**：`"uri":"v0…"` 与 `play_addr` 命中 **0** 次，另有 `captcha` 风控标记 |

**定论**：`--cookies-from-browser` 在这台机器上无论 Edge 开不开都成不了（关掉 Edge 只是解决锁，解不开的仍是 App-Bound 加密）。唯一稳的是**浏览器内导出 cookies.txt**：装 `Get cookies.txt LOCALLY` 扩展 → 打开 douyin.com → Export → 落到本地 → 写进 `DSH_VIDEO_COOKIES` 或 `~/.dsh/video.json` 的 `cookies` 字段；`video_*` 工具本来就吃这个参数。

抖音提取器要的是访问 cookie（`s_v_web_id` 之类设备标识），**不是登录态**；`yt_dlp/extractor/tiktok.py` 的 `DouyinIE._real_extract` 在拿不到 detail JSON 时抛 `Fresh cookies (not necessarily logged in) are needed`，而非“不支持”。

## 4. 运维坑：desktop profile 里装的是**复制版**，源码改动不会进 DSH

- 实际加载路径：`C:/Users/林先语/.dsh/profiles/desktop/node_modules/dsh-video-storyboard`，`version=0.6.8`、`main=./src/index.js`，是 `cp` 出来的副本（不是 symlink，`LinkType=` 为空）。
- 后果：改源码后重启 DSH，`video_probe` 仍走旧逻辑（现场表现为仍然吐 `this site is not supported by the installed yt-dlp build`）；另外工具层是**进程启动时组合**的模块，热改源码也不可能生效。
- 生效步骤：`cd <插件目录> && node scripts/install-dev.mjs`，然后重启 DSH Desktop。
- `scripts/install-dev.mjs` 的三个设计点（读源码所得，复用时别改坏）：
  - 必须是复制而非软链：Node 解析裸包名用真实路径，软链会让它从源码目录向上找不到宿主包。
  - `SKIP` 含 `.tmp`：里面是调试输出与 Edge 一次性 profile，`Cookies` 被占用时 `cp` 会直接失败。
  - profile 由 Electron 独占管理，`dsh plugin --profile desktop ...` 会被拒，所以只能这个脚本改 `package.json` 的 `dependencies` + `dsh.profile.bundles`（首次安装留 `package.json.bak-*`）。

## 5. 操作原则（本次踩到的教训）

读视频这类任务**不要用「操作桌面 + 抓屏/录屏」代劳**：用户明确反对接管电脑，且桌面路径慢、易被前置窗口遮挡、还受 USER_CONTROL 抢占。优先顺序应为：yt-dlp 直取 → 本地文件 → 字幕轨（B 站的 CC/AI 字幕优先于裁条 OCR）→ 以上都不行才考虑录屏，且先问。
