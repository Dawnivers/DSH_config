---
id: "aac1741e-a57b-419a-9842-695f14b6c707"
title: "多模型协作编排：先例、成熟模式、坑，与一个可跑的 DSH 四步配方"
description: "用户提出「ChatGPT 出美术 / Claude 监管 / DeepSeek 干活」的多模型协同时，全网检索得到的先例与工程结论：5 个有名字的模式（strong-planner/cheap-worker、FrugalGPT 级联、路由、MoA、跨模型 PR 审查）、3 个被论文验证的坑（self-preference、generator-verifier gap、级联成本反转）、可用工具层（LiteLLM 网关等），以及一个强模型只出现三次的四步 workflow 骨架；并记录美术环节为何尚无闭环、ccSwitch 重启痛点为何能被网关层绕开。"
status: "active"
created_at: "2026-11-08T06:28:17.869Z"
updated_at: "2026-11-08T06:28:17.869Z"
content_hash: "cf5c8468cc0365384ecebf714219a3ddb6b2e1ec07be79fb8ff40e503af650f4"
source_paths:
  []
session_ids:
  - "d90c9438-8bfb-4240-b2ac-2f158301a853"
memory_body_ids:
  []
---

# 多模型协作编排：先例与工程结论

日期：2026-11-08。背景：用户想搭一个「桌面平台 + 多模型分工」的工作流——ChatGPT 负责美术设计、Claude 负责监管/审查、DeepSeek 负责具体实现，形态参考 Codex / DSH 这类桌面 agent 平台；痛点是 ccSwitch 切模型要重启 Codex/Claude Code，与多模型频繁切换冲突。

结论先行：**这套组合有正式名字，不是自创**，它至少是三个已知模式的叠加。真正没有先例的只有「让两个模型互评美术」那一环。

## 1. 五个有名字的成熟模式（按与用户方案的贴合度排）

| 模式 | 机制 | 代表实现/来源 | 对应关系 |
|---|---|---|---|
| **Strong planner / cheap workers** | 强模型一次调用拆出几条**互不重叠**的路线 → 便宜模型**互相看不见**地并行做 → 强模型综合 → 强模型扮「敌审」攻击自己的产出 | LLMRagent 的 `think_harder()`（R 包 vignette "super-brain"）https://rdrr.io/cran/LLMRagent/f/vignettes/super-brain.Rmd | 几乎等于「Claude 规划+审查、DeepSeek 干活」 |
| **LLM Cascade（级联）** | 先最便宜的回，置信度不够才升级到贵模型 | FrugalGPT（Stanford，报告成本降幅可达 98%）http://speech.ee.ntu.edu.tw/~hylee/ml/ml2023-course-data/FrugalGPT-v2.pdf | 用户方案的降本内核 |
| **Model Routing（路由）** | 按 query 复杂度分类后派给不同模型；分 classifier-based / cascade / semantic 三类 | NeuralTrust 2026 综述 https://neuraltrust.ai/blog/llm-model-routing | 用户方案缺的「谁决定派给谁」 |
| **Mixture-of-Agents（MoA）** | 多层聚合：每层多个模型互看彼此草稿再改，最后汇总 | 开源 `moa-llm` https://pypi.org/project/moa-llm/ 、llama-index mixture-of-agents pack | 更重、成本 N×，不是轻量方案 |
| **跨模型 PR 审查** | A 模型写 PR，B 模型审并修 | Claude Code 审 Codex 的 PR 一类团队实践（superset / Paradev 比较文档）https://github.com/superset-sh/superset | 「Claude 监管」的工程化形态 |

学术族名：**generator–verifier**、**LLM-as-a-judge**、**cascade with conformal routing**（RouteNLP https://browse-export.arxiv.org/abs/2604.23577 ）。

LLMRagent 那篇连示例参数都贴近用户设想（强模型 = 推理型大模型，便宜端 = 小模型），其四段结构与计费特征值得直接借用：

1. **Plan** — 强模型拆成几条**真正不同**的路线（一次调用）
2. **Work** — 便宜模型**互盲**并行，避免趋同（关键：各自只拿到 plan 里属于自己的那条）
3. **Synthesize** — 强模型比较草稿、丢掉不合格的、写最终答案
4. **Verify** — 强模型扮敌审，只出问题清单，发现实质缺陷才跑一轮修订

强模型只计费 2~4 次调用，**token 量全压在便宜端**——这正是省钱的位置。

## 2. 三个被论文验证过的坑（这套方案都会踩）

1. **self-preference bias**：模型评价**自己**的输出会系统性偏高 → 「换一家来审」方向是对的，这是该设计最值钱的部分。
2. **generator–verifier gap**：验证者弱于生成者就抓不到错 → 审查方必须 ≥ 生成方，否则「监管」是橡皮图章。
3. **cascade 成本反转**：升级率一高，级联反而比直接用贵模型更贵 → 必须埋点统计「被退回重做」的比例，超过约 30% 就该直接上强模型。

## 3. 美术环节：目前没有闭环，这是事实不是妥协

- **审美没有 ground truth**，verifier 无从判对错，只能提意见。
- **画布状态不可 diff**：代码能比 diff，图层树比不了，「改得好不好」无法自动打分。
- 因此业界在这一环的做法是**人验收**，而不是 agent 循环。让两个模型互评美术 ≈ 把人的审美判断外包给两个模型互相说服，闭环不成立。

**建议形态**：美术环节只做辅助——出方向、写文案、查对比度/可访问性；最终裁决留给人。

## 4. 工具层与「重启」痛点的绕法

| 层 | 工具 | 作用 |
|---|---|---|
| 网关 | LiteLLM、OpenRouter、TrueFoundry | 一个 key 挂多家，**按次指定模型**；把 Codex / Claude Code / 脚本统一指向本地代理即可绕开 ccSwitch 的重启切换 |
| 编排 | LangGraph、CrewAI、AutoGen、DSH `workflow` | 把「谁在什么时候被调用」写成代码 |
| 模式实现 | LLMRagent、moa-llm、llama-index mixture-of-agents | 不重复造轮子 |

最省事的第一步：装 **LiteLLM 本地代理**，所有 CLI 指向它、模型名按次传参——不换平台就能消掉重启痛点。

## 5. 可直接跑的四步 DSH workflow 骨架

```js
// 1) 规划：强模型，只调一次
const plan = await agent(`拆成 3 条互不重叠的实现路径：${task}`,
  { model: '<强模型>', label: 'plan' });

// 2) 干活：便宜模型，并行、互盲（各自只拿 plan 里属于自己那条）
const drafts = await Promise.all(plan.paths.map(p =>
  agent(`只做这一条，不要参考其他方案：${p}`,
    { model: '<便宜模型>', label: 'work' })));

// 3) 综合：强模型，扔不合格的
const synth = await agent(`合并草稿，指明舍弃了哪些及原因：${JSON.stringify(drafts)}`,
  { model: '<强模型>', label: 'synthesize' });

// 4) 敌审：强模型，只读，只出问题清单（不给写权限）
const review = await agent(`你是敌审。找出 synth 的实质缺陷，只输出问题数组。`,
  { model: '<强模型>', label: 'verify',
    schema: { type: 'object', properties: { issues: { type: 'array', items: { type: 'string' } } } } });
```

强模型四步里只出现三次，其余量在便宜端。生产化时应加「退回率」埋点，用来决定是否该放弃级联。

## 6. 诚实的边界

- 检索到的多为**博客、论文、R/Python 包**，不是经过大规模生产验证的标准流程。真正沉淀成基础设施的只有两类：**网关（LiteLLM / OpenRouter）** 与 **级联降本**。
- 「多模型协作」目前更像**手艺**而非工程规范：几个并行、何时升级、审查用什么 schema，全靠调。
- DSH 侧的相关前提（没有「复杂度自动升级多智能体」的机制，编排只由显式工具调用或 preset 决定）见既有文档 `f3e88214-9bd9-4a3f-bfb7-4d1bd0125017`。

## 来源

- LLMRagent super-brain vignette：https://rdrr.io/cran/LLMRagent/f/vignettes/super-brain.Rmd
- FrugalGPT：http://speech.ee.ntu.edu.tw/~hylee/ml/ml2023-course-data/FrugalGPT-v2.pdf
- LLM Model Routing（NeuralTrust）：https://neuraltrust.ai/blog/llm-model-routing
- RouteNLP：https://browse-export.arxiv.org/abs/2604.23577
- moa-llm：https://pypi.org/project/moa-llm/
- Claude Code × Codex 跨模型 PR 审查：https://github.com/superset-sh/superset
- AI-Rig（Claude/Codex 集成实践）：https://github.com/Borda/AI-Rig
