---
id: "0edb3e3f-3692-4943-97fd-45b6e6fd469d"
title: "Blender 三渲二「整图惨白」真因与描边壳遮挡：Mix 节点语义、alpha 眼窝与官图配色标定"
description: "MMD 角色三渲二面板第二轮的排查记录：Mix(MULTIPLY) 在 fac=0 时输出 A 导致边缘光灌满全图（惨白真因）、MixShader 的 fac 取反接 alpha、反壳描边把脸/头发壳从发缝透出并盖住眼睛、按官图网格采样反推暗部色与新增皮肤提色/饱和度面板参数；并修正前文「眼睛被刘海挡住」的结论。"
status: "active"
created_at: "2026-11-07T15:20:06.206Z"
updated_at: "2026-11-07T15:20:06.206Z"
content_hash: "9d3940804f7d639bb2681e5b344dbf4774670d1f1447261395147ea448578bae"
source_paths:
  - "blender/tl_panel.py"
  - "blender/42_ref_tuned.py"
  - "blender/43_lightvariants.py"
  - "blender/44_skin_sample.py"
  - "blender/45_skin.py"
  - "blender/46_eyefaces.py"
  - "blender/47_eyepos.py"
  - "blender/48_tex_stats.py"
  - "blender/49_face_raw.py"
  - "blender/50_bisect.py"
  - "blender/51_no_outline.py"
  - "blender/README.md"
session_ids:
  - "7fdb36a2-ced1-47df-8bbb-b31dddd5c269"
memory_body_ids:
  []
---

# 三渲二「整图惨白」真因、描边壳遮挡与官图配色标定

**背景**：`b29dc8c2-4462-4630-b91b-eacec84a1be3` 记录了 `blender/tl_panel.py` 面板的实现结构与三个「改了不生效」坑，`92ba49c0-9d5e-4438-854e-456acc15e864` 记录节点链与 8 条症状表。本文只记**在面板可调之后**这一轮的排查结果：用户报告「皮肤惨白」→ 定位到与皮肤参数无关的节点语义错误；顺带修好眼睛不可见（推翻前文结论）、补饱和度/皮肤提色参数，并用官图采样做配色标定。

---

## 1. 惨白的真因：`Mix(MULTIPLY)` 在 factor=0 时输出 A 本身

出问题的接法（边缘光）：

```
rim_color ──A──┐
rim_strength ─B── Mix(MULTIPLY), factor = 菲涅尔遮罩 ── ADD.factor
```

- 直觉假设「遮罩=0 → 输出 0 → 边缘光不出现」。**实际 Blender 的 Mix 是 lerp**：`fac=0` 输出 **A 本身**，`fac=1` 才输出 `A×B`。
- 于是边缘光色 `(0.62, 0.84, 1.0)` 被**无条件加到每一个像素**，所有固有色冲到 1.0：皮肤、白裙、头发全成纯白，二分也看不出来。症状看着像「皮肤参数不对/过曝」，根子在接线。

**正解**：乘法给满，遮罩挂到 ADD 的 factor 上。

```
l.new(rim_c.outputs[0], r_a)
l.new(rim_str.outputs[0], r_b)
r_fac.default_value = 1.0          # MULTIPLY 的 fac 固定 1 → 得到 边缘色×强度
l.new(rim_ramp.outputs["Color"], a_fac)   # 遮罩改成 ADD 的 factor
```

**可复用判断**：凡是用 Mix 节点做「遮罩 × 颜色」，先问一句「fac 的 0 端到底输出什么」。要「0 端为 0」必须用 MULTIPLY 且 fac=1，或者改用 `Multiply` 数学节点 / `Mix` 的 blend 语义显式确认。

## 2. 定位手法：逐段二分渲染

`blender/50_bisect.py` 把材质链拆成「贴图 → 提色 → 阴影」三段，每段单独渲一帧（`render/61_step1_tex.png`、`62_step2_tint.png`、`63_step3_shadow.png`）：

- 贴图直连发光 → **正常暖肤色**（说明贴图、UV、色彩空间都没问题；`49_face_raw.py` 确认 `Face_D.png` 走 `mmd_tex_uv.Base UV`、sRGB、REPEAT、FLAT）
- 加提色后仍正常 → 排除提色
- 接上阴影/边缘光那一段才变白 → 锁定在 Mix 结构

**先做「贴图直通发光」这一帧**是这轮最省时间的动作：它一次性排除了贴图、UV、色彩空间、槽位顺序四类怀疑。

## 3. 眼睛不可见：不是刘海挡住，是**脸的描边壳**糊住了

前文 `b29dc8c2` 第 5 节的红眼测试结论是「眼睛被刘海 + 相机高度挡住」。本轮推翻：

- `blender/46_eyefaces.py` 扫槽位面数，眼睛几何**确实存在**：`Eye_` 360 面、`Eye_+` 290、`Eye_Hi` 216、`Face_Eyewhite` 110、`Face_Eyelash` 998、`Facial` 896，且**没有任何空槽**。
- `blender/47_eyepos.py` 给出位置：`Eye_`/`Eye_Hi`/`Face_Eyelash` 都在 y≈-0.02～-0.026、z≈1.508～1.531，与脸面（`Face_` z 1.444～1.593）同一深度层。
- `blender/51_no_outline.py` 关掉描边壳（`render/70_no_outline.png`）→ **眼睛立刻出现**。所以眼睛一直没被挡，是被**脸的壳**盖住了；壳还被放大 5mm 从刘海缝里透出来，形成额前黑带。

**解法**：按材质名把 `hair` / `face` 从描边壳的源里剔除，只给皮肤与衣服描边（描边壳的源选择要按类过滤，而不是「除 `TL_` 前缀外全要」——后者是 `b29dc8c2` 4.2 为防 ReferenceError 定的规则，需与之叠加）。

**推论**：反壳描边的固有副作用是「薄处透明/镂空处会被壳填黑」。凡是角色带 alpha 镂空（发丝、睫毛、眼窝），先检查壳。

## 4. 眼窝靠贴图 alpha 挖空 → alpha 必须接回 MixShader

为做纯色二分而丢掉 alpha 后，脸皮把眼睛糊住。接回时的坑：`ShaderNodeMixShader` 的 **fac=0 取第一个输入**（自发光），fac=1 取第二个（透明），所以 fac 要喂 **1 - alpha**：

```
alpha_inv(SUBTRACT, 1 - base.Alpha) → alpha_mix.Factor
emis.Emission → alpha_mix.inputs[1]
transp.BSDF  → alpha_mix.inputs[2]
# 透明方式兼容：surface_render_method = "DITHERED"，老属性 blend_method = "HASHED"
```

补充证据：`blender/48_tex_stats.py` 量了 `Eye_D.png` / `Face_D.png` / `Hair_D.png` / `Bangs_D.png`，**alpha_min = alpha_mean = 1.0、alpha<0.5 比例 0**，即贴图文件名里的 "D" 通道并不是 alpha 遮罩，别被文件名误导；但材质本身的 alpha 输入仍需保留原始链路。

## 5. 官图配色标定：网格采样 + 暗部色=暗部÷亮部

做法（`blender/44_skin_sample.py` 等）：对官图取 6×4 / 8 行网格采样，直接读 hex，不靠眼睛估。

| 区域 | 实测 |
|---|---|
| 白裙亮部 | `#f4f2ee` 暖白 |
| 白裙暗部 | `#a0bec9` 冷蓝灰 |
| 头发中间调 | `#5f83b6` → `#4f7dc3` |
| 头发暗部 | `#3666b2` 饱和蓝 |
| 皮肤亮部 | `#fbf1ec` |
| 皮肤暗部 | `#ddc7c5` 暖粉 |
| 背景 | `#f4f2ee` |

**换算规则**：暗部色是**乘在固有色上**的，所以 `暗部色 ≈ 暗部实测 ÷ 亮部实测`：

- 布料 → (0.66, 0.78, 0.86)
- 头发 → (0.55, 0.70, 0.90)
- 皮肤 → (0.94, 0.80, 0.80) 暖粉
- 背景 → 官图暖白

**新增两个面板参数**（都在 `blender/tl_panel.py`）：

- `saturation`（默认 1.2）：之前整片发灰缺的就是它
- 皮肤提色：颜色 (0.99, 0.90, 0.86) + 强度 0.85，因为原贴图肤色被截到 255 变纯白

## 6. 热重载坑：改类属性不注销旧类 → AttributeError

给 `TLToonSettings` 加 `saturation` 后报：

```
AttributeError: 'TLToonSettings' object has no attribute 'saturation'
```

原因：`tl_panel.py` 是 `exec` 重跑注册的，旧类仍被已注册的 PropertyGroup 实例持有，新代码的 `build_materials` 拿旧实例取新属性。**改类定义必须 `unregister()` 旧类再 `register()`**（日志里「'TL_PT_panel' 已被注册过，注销先前的」是正常且必要的现象）。

## 7. 仍然对不上的地方（结构性，不是参数）

1. **白裙贴图本身接近纯白**：官图的蓝灰阴影是画师手绘，一条全局二分线变不出来。试过侧上光 70° + 阈值 0.68（`blender/43_lightvariants.py` → `render/31_A_side.png`、`31_B_upperleft.png`），裙子正面仍全亮。
2. **头发丢了 toon 贴图**：原模型靠 `mmd_toon_tex` + sphere 贴图做渐变，为做三渲二绕过 `mmd_shader` 等于扔掉作者调好的渐变 → 头发现在是淡青线稿。
3. **深色材质死黑**：`Cloth_Dressin` 这类深色固有色乘暗部色后掉到 0.1 以下，像破洞。需改成「提亮式暗部」（加法而非乘法）。
4. 姿势不同（T-pose vs 动态），构图无法逐像素比；描边粗细不分层（官图头发细、轮廓粗）。

**对照图**：`blender/render/40_compare.png`（首轮）、`41_compare_fixed.png`（修完惨白/眼睛后）、`50_skin_full.png` + `51_skin_face.png`（修后全景/近脸）。

## 8. 复现命令形态

所有脚本仍走 MCP for Blender 裸 TCP（见 `92ba49c0` 第 1 节），执行后回执形如 `{"built": 50, "applied": 50}`；参数与实现留在 `blender/tl_panel.py`，运行记录与用法在 `blender/README.md`。
