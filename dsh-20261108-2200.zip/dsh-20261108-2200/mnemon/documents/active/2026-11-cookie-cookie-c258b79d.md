---
id: "c258b79d-a5c0-47df-a928-ba46c768c508"
title: "抖音取源 2026-11 收盘结论：cookie 已验通但签名墙未破（别再走导 cookie 路线）"
description: "对 73d5a289（卡点是游客 cookie）的实测修正：用户导出 douyin.txt 后 yt-dlp 接受了 cookie 但仍返回空，分享页/App 端接口/Edge 缓存全部封死，Chromium 127+ App-Bound Encryption 使 --cookies-from-browser 与手写 DPAPI 解密均不可行；结论是抖音已无免费后台直链通道，只剩付费 API 或用户提供本地文件。另含 desktop profile 为复制版、需重跑 install-dev 后重启才生效。"
status: "active"
created_at: "2026-11-07T14:40:10.068Z"
updated_at: "2026-11-07T14:40:10.068Z"
content_hash: "4d9ba32a517f3d4f4d4675f2405d9e1d981a2994fd7d11a71e9323fc353520da"
source_paths:
  - "chrome-cookie-probe.py"
session_ids:
  - "86f332a2-84eb-4021-8b01-b35ea9ff1dfb"
memory_body_ids:
  []
---

# 抖音取源 2026-11 收盘结论：cookie 已验通但签名墙未破

**日期**：2026-11-07（Asia/Shanghai，同日两轮：上轮见 `73d5a289-e348-4259-a937-080ca2b693fe`）
**触发**：用户要读一条 17 分钟抖音教程（`https://www.douyin.com/video/7696895863838362907`，`modal_id` 形态来自主页搜索弹层），并**明确否决**了「录屏 / 抢鼠标操作桌面」的取源方式。
**一句话结论**：**抖音已没有「像 B 站那样」的免费纯后台直链通道。** 上轮文档判断的「卡点只是一份游客 cookie」被本轮实测推翻——cookie 已导出且被接受，卡点变成**每次请求现算的签名（a_bogus）**。

---

## 1. 本轮排除掉的四条路（均为本机实测）

| 通道 | 结果 |
|---|---|
| 用户按指引导出 `D:\cookies\douyin.txt` → `yt-dlp --cookies` | cookie 文件 9.6 KB / 71 行 / 67 对，含 `s_v_web_id`、`ttwid`、`UIFID`、`sid_guard`、`__ac_signature`、`passport_csrf_token`（缺 `msToken`/`SESSDATA`）。yt-dlp **接受了**它——报错从 `expected=True`（缺 `s_v_web_id`）变成 `expected=False`，但 `aweme/v1/web/detail` 返回空 |
| 免登录分享页 `iesdouyin.com/share/video/<id>` 抠 `play_addr`/`"uri":"v0..."` | 不带 cookie：200 但 32 KB **壳页**，`play_addr` 命中 0、带 captcha 标记；带 cookie 反而更严：**6.3 KB + captcha=2** |
| App 端 `aweme.snssdk.com` / `api.amemv.com` 的 `aweme/v1/aweme/detail` | 200 但 body **0 字节**；`www.iesdouyin.com/aweme/v1/web/...` TLS 直接失败 |
| Edge 本地 HTTP 缓存捞 mp4 | 949 个缓存文件 / 507 MB，`ftyp` 命中 **0**——MSE 流不留成品文件 |

## 2. 为什么 `--cookies-from-browser` 在本机永远不行

- **认证标签不匹配**：手写脚本（工作区 `chrome-cookie-probe.py`，DPAPI + AES-GCM，40 行）能拿到 32 字节 key、能读出 cookie 行，但 `AesGcm.Decrypt` 一律 `The computed authentication tag did not match the input authentication tag` —— 即 **Chromium 127+ 的 App-Bound Encryption**。插件里早就写着这条提示（`dsh-video-storyboard/src/storyboard/ytdlp.js:209`）。
- **Edge 开着时 cookie 库被独占锁**：连 `Copy-Item` 都报 `being used by another process`。
- 结论：**只有浏览器内部扩展能读明文**（`Get cookies.txt LOCALLY` / Cookie-Editor → Netscape 格式）。这也是本轮唯一走通的一步，但它只解决「拿到 cookie」，不解决「签名」。

## 3. 社区状态与我的实测一致

- yt-dlp 的 Douyin 提取器源码里就留着 TODO：`Run verification challenge code to generate signature cookies`。
- 社区实战（`vidknot` 的 `DOUYIN_FALLBACK.md`，2026-08 记录）：四层 fallback —— `f2 dy --mode one`（iesdouyin 分享页 + cookie）曾被验证可用，而**分享页现在只剩 captcha 空壳**；yt-dlp 被标为 broken 兜底；最后只剩**付费第三方 API**（TikHub 等，`TIKHUB_API_KEY`）。

## 4. 决策：还剩三条路，推荐「用户给本地文件」

| 方案 | 成本 | 备注 |
|---|---|---|
| ① 付费 API（TikHub 等） | 注册 + 按次计费 | 拿到 key 后接入约 10 分钟 |
| **② 用户把视频存成本地文件（推荐）** | 用户约 1 分钟 | 手机「保存到相册」传电脑 / 去水印站下载 → 给路径。之后 `video_probe`→`video_storyboard` 全程后台，零桌面操作 |
| ③ 自建 CDP 签名下载器 | 1–2 小时且随抖音改版即废 | 不建议为单条视频做 |

**不要再做**：再让人导一次 cookie（已证无效）、再试 `--cookies-from-browser`、再试分享页。插件的 `probeUrl` 对 `site === 'douyin'` 仍会回 `!! NEEDS COOKIES`，这句是**误导**——加了 cookie 也没救，应改成「需签名或本地文件」（此改动已向用户提出，未获批准前不动手）。

## 5. 附带的工程事实：profile 里是复制版，改源码不生效

`C:\Users\林先语\.dsh\profiles\desktop\node_modules\dsh-video-storyboard` 是 **v0.6.8 的复制目录**（`LinkType=` 为空、非 symlink），所以改 `D:\Users\林先语\Documents\dsh-plugins\dsh-video-storyboard` 源码后工具行为不变——这正是「重启后 `video_probe` 还说站点不支持」的原因。同步方式：

```powershell
cd D:\Users\林先语\Documents\dsh-plugins\dsh-video-storyboard
node scripts/install-dev.mjs   # 复制进 desktop profile
# 然后重启 DSH Desktop（插件树在进程启动时组合）
```

本轮已执行并通过冒烟测试（`resolveSiteUrl` 把 `modal_id` 弹层链接重写成 `/video/<id>`，返回 `site:"douyin", rewritten:true`）。**重启由用户自己按，agent 不代按**，以免打断会话。

## 6. 视频内容侧已备好的东西

片头目录已从画面读到，分六段：准备事项 00:40 / 常见贴图 02:17 / 三渲二基本原理 03:57 / 人物着色渲染 06:50 / 后期处理 13:32 / 课程推荐 15:40。一旦拿到本地文件即可按此六窗口分批出分镜 + 台词（有音轨走 ASR，画面走分镜）。

---

**相关**：上轮 yt-dlp 矩阵与 URL 形态坑（`modal_id` 不被识别、三类错误应分开抛）见 `73d5a289-e348-4259-a937-080ca2b693fe`；插件能力边界、成本模型与 install-dev 前置见 `41779d84-0c91-41fd-9781-29e62149d40e`；更早的「录屏 + 字幕条 OCR」兜底流程（本次被用户否决）见 `d20835a4-9b6e-4ab4-a4c2-d393e8c0f2a4`。
