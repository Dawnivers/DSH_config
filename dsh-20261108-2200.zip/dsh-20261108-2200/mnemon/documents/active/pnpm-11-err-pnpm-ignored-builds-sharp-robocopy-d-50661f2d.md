---
id: "50661f2d-c545-46a1-a385-2f9f332d195d"
title: "pnpm 11 的 ERR_PNPM_IGNORED_BUILDS（sharp）与 robocopy 回滚残留：dsh-with-pencil 真装第二关（web profile，2026-11-08）"
description: "真装 dsh-with-pencil@0.7.0 时，pnpm 版本冲突解决后卡在 pnpm 11 默认禁止未授权依赖构建脚本（sharp@0.34.5，exit 3）；记录 allowBuilds 白名单机制、为何写 sharp: false 而非 true，以及 robocopy /E 回滚不删新增目录导致的「文件在、台账无」半状态与带路径校验的清理修法。前置：c78f3a16（pnpm 版本）与 6720aca3（脚本结构）。"
status: "active"
created_at: "2026-11-08T09:19:07.080Z"
updated_at: "2026-11-08T09:19:07.080Z"
content_hash: "40cbf1af5c277ae6f2e333a4947b7e940239996c47b6546f171304348e2d178f"
source_paths:
  - "install-dsh-with-pencil.ps1"
session_ids:
  - "a8874710-ad85-4f77-b217-6cbf3e89d473"
memory_body_ids:
  []
---

# 真装第二关：IGNORED_BUILDS 与回滚残留

日期：2026-11-08。profile `web`，宿主 DSH **0.2.0-rc.2**（Node v24.16.0），目标插件 `dsh-with-pencil@0.7.0`，脚本 `install-dsh-with-pencil.ps1`。
**前置文档**：`c78f3a16`（pnpm 10.33.0 抢在 11.8.0 前面导致 `UNEXPECTED_STORE` 的根因与 shim 修法）、`6720aca3`（脚本五段结构、门控、备份指纹设计）。

## 1. 第一关确认已通过（实测）

按 `c78f3a16` 的 shim 方案重跑后，第 3 段输出：

```
[OK] pnpm shim 就绪：11.8.0  (D:\DSH\shims\pnpm.cmd)
[OK] 已把 D:\DSH\shims 置顶到 PATH
执行：npx --yes @deepseek-ai/dsh@0.2.0-rc.2 plugin --profile web add dsh-with-pencil@0.7.0
✓ Lockfile passes supply-chain policies (218 entries in 1.2s)
dependencies:
+ dsh-with-pencil 0.7.0
Packages: +65 -12
```

即：**dsh 确实从 PATH 解析 pnpm，置顶 shim 就换了靶**；`UNEXPECTED_STORE` 不再出现，包在解析/链接层实际装上了。

## 2. 新卡点：`ERR_PNPM_IGNORED_BUILDS`（exit 3）

```
[ERR_PNPM_IGNORED_BUILDS] Ignored build scripts: sharp@0.34.5
Run "pnpm approve-builds" to pick which dependencies should be allowed to run scripts.
dsh: plugin command failed; diagnostics: C:\Users\林先语\.dsh\profiles\web\.plugin-manager\logs\operation-iZ04xw\pnpm.log
[安装失败，开始回滚]
```

机制：**pnpm 11 默认不允许执行依赖的 postinstall / install 脚本**，没被显式批准的依赖会被记为「ignored builds」，pnpm 以非零码退出。dsh 把非零码当失败，触发脚本回滚。

注意：这是**收尾策略检查**判死，不是下载或链接失败——产物已经落盘，只是 pnpm 拒绝收尾。

## 3. 批准机制：profile 的 `pnpm-workspace.yaml` → `allowBuilds`

`C:\Users\林先语\.dsh\profiles\web\pnpm-workspace.yaml` 原文（14 行，LF 行尾）：

```yaml
packages:
  - .

nodeLinker: hoisted
autoInstallPeers: false
allowBuilds:
  # allow-builds policies: true = run the install script, false = skip it.
  cloudflared: false
  cpu-features: false
  node-pty: true
  ssh2: true
```

`sharp` 不在表里 → 被拒。修法是补一行，脚本用正则锚定空行级 `allowBuilds:` 后插入（原文件先备份成 `pnpm-workspace.yaml.bak-<时间戳>`）：

```powershell
$patched = $yamlText -replace '(?m)^allowBuilds:\s*$', "allowBuilds:`n  sharp: false"
```

## 4. 为什么是 `sharp: false` 而不是 `true`

- `sharp` 的原生可执行文件由**可选依赖** `@img/sharp-win32-x64@0.34.5` 提供，本轮日志里它已随包下载完成（8.68 MB）。
- 该依赖的 install 脚本只做存在性/平台校验，不需要真实编译。
- 写 `false` 同时满足两件事：**通过 pnpm 的策略检查**（被显式声明，不再算 ignored）＋**装插件时不联网跑脚本**。
- 这与表内既有的 `cloudflared: false`（只带构建期 bundler）、`cpu-features: false`（纯可选加速器）是同一思路；`node-pty` / `ssh2` 因 SSH 插件需要原生二进制必须 `true`。

推广规则：新增依赖的原生能力若由 optional dep 提供，声明 `false`；若必须编译/下载原生二进制，声明 `true`。

## 5. 脚本缺陷：`robocopy /E` 回滚不删新增目录

回滚后实测残留（package.json **未**登记 `dsh-with-pencil`）：

```
node_modules\dsh-with-pencil   True   ← 残留
node_modules\@pen.dev          True   ← 残留
node_modules\.pnpm             True
```

原因：回滚用 `robocopy /E`，只复制/覆盖备份中存在的文件，**不会删除备份之后新增的目录**（`/MIR` 才会镜像删除，但本脚本刻意不用 `/MIR`，见 `6720aca3`）。结果 profile 处于「文件在、台账没有」的半状态，下一次安装会叠加在这种脏树上。

修法（真装模式且带路径校验，防误删）：

```powershell
if ($fullPath.StartsWith([System.IO.Path]::GetFullPath($ProfileRoot), 'OrdinalIgnoreCase')) {
  Remove-Item $fullPath -Recurse -Force
}
```

脚本因此从 198 行增至 233 行，语法检查（仅解析）通过。

## 6. 剩余关卡与判断

| 关卡 | 信号 | 判断 |
|---|---|---|
| peer 依赖 | `[WARN] Issues with peer dependencies found` | **无害**。`autoInstallPeers: false`，且 `@deepseek-ai/*` 由宿主提供，本来不会满足 |
| 运行时加载 | 装完 `dsh web` 起来点画布 | 真正的考验；Tauri/Electron 混用与侧栏插槽冲突都可能在此暴露 |

## 7. 状态与回滚点

- 本轮**未确认安装成功**：走完到 `allowBuilds` 补丁 + 残留清理的修正，等待再次重跑。
- 备份两处（均可用脚本 `-RestoreFrom` 恢复）：`D:\DSH\backup\web-20261108-170706`（约 17914 文件）、`D:\DSH\backup\web-20261108-171628`（17916 文件，package.json 指纹 `FAE24651A5B902D4`）。
- 失败日志约定位置：`C:\Users\林先语\.dsh\profiles\web\.plugin-manager\logs\operation-*\pnpm.log`。
