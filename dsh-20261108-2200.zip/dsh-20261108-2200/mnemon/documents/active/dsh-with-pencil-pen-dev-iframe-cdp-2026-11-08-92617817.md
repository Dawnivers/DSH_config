---
id: "92617817-cb0c-4f86-b7d0-3f0262770003"
title: "dsh-with-pencil 第五层：画布\"纯黑\"的真因——pen.dev 强制登录 + iframe 高度链归零（CDP 实证，2026-11-08）"
description: "记录插件离线注入成功后画布仍全黑的排查结论：编辑器脚本其实加载成功、停在 \"Sign in to pen.dev\"（No session found），黑屏是窄视口下 iframe 高度链全部算成 0；含无头 Chrome + CDP 抓 iframe 内日志的可复用手法、资产 200 校验、401 语义，以及\"绕过登录/5天额度\"问题的最终答案。前置文档 379b1ca7（重启与离线短路）、6720aca3（安装脚本）、817893a4（版本矩阵）。"
status: "active"
created_at: "2026-11-08T09:42:53.865Z"
updated_at: "2026-11-08T09:42:53.865Z"
content_hash: "120b71f1944aa20c026217df0b013507b9d10df8a7d1953b28f3291142083c84"
source_paths:
  []
session_ids:
  - "95108877-adc5-4b0c-80f9-052d9d647e8a"
memory_body_ids:
  []
---

# 第五层：画布成功加载，但卡在 pen.dev 登录；"纯黑"其实是高度 0

日期：2026-11-08。profile `web`，宿主 DSH **0.2.0-rc.2**，插件 **dsh-with-pencil@0.7.0**，编辑器离线目录 `D:\DSH\pencil-editor\download\extract\out`。
**前置文档**：`379b1ca7`（重启验证 / `DSH_PEN_EDITOR_DIR` 短路下载 / 401 属正常）、`6720aca3`（安装脚本）、`817893a4`（版本矩阵）。本文只记**画布打开之后**才发现的两件事，不重复前三层。

## 1. 观察到的两个互不相干的故障

| 现象 | 真因 | 归属 |
|---|---|---|
| 报错消失、标签页标题出现 `default-workspace / designs/design.pen / 导出`，但主体全黑、连工具栏都没有 | 父容器整条高度链算成 **0px**，不是渲染崩 | DSH web 布局（窄视口 / 首次未刷新） |
| 刷新后能看到内容，却是 `Sign in to pen.dev` 登录页 | 编辑器启动即 `get-session`，无账号就拦在登录 | pen.dev 编辑器自身 |

两者会互相掩盖：先看到黑屏会以为脚本没跑起来，其实脚本跑得很好。

## 2. 决定性证据：CDP 抓 iframe 内部（可复用手法）

浏览器扩展桥不可用（`browser_list_tabs → no browser extension is connected`）时，用**独立无头 Chrome + CDP** 探测，不动用户现有窗口：

```powershell
chrome.exe --headless=new --remote-debugging-port=9322 --user-data-dir=D:\DSH\chrome-cdp <url>
# 探活：GET http://127.0.0.1:9322/json/version
```

要点：
- Node 24 自带 WebSocket（`typeof WebSocket === 'function'`），不需要 `ws` 包；脚本里写 `ws.onmessage = ...`，**不要**写 `ws.onmessage = (e) => msg = e.data` 这类导致 `Invalid left-hand side in assignment` 的笔误。
- 画布是 iframe，**必须在 iframe 的执行上下文里 eval** 才能拿到 `document.body.innerText` 和它自己的 console；在顶层页面 eval 只能看到 `iframes: []` 外壳（因为面板还没挂）。
- 顶层页面找不到 iframe，多半是面板未展开 → 先用 CDP `Input.dispatchMouseEvent` 点「pen.dev 画布」按钮，再重查 frame 树。
- 面板宽度为 0 时 iframe 报 `h=0`；点击后若视口足够大，同一帧立刻变成 `719×920`。

抓到的 iframe 日志（决定性三行）：

```
[INFO] Processing session...
[INFO] No session found, login needed
[DEBUG] Loading design file: Er
[DEBUG] Scene loaded successfully.
```

配上 iframe 内 `bodyText` = `Sign in to pen.dev / Email Address / Send Code / I have a password` —— 链路全通，只差账号。

## 3. 高度归零的完整链条

视口 800×600 时，从外到内全部为 0（CDP 实测）：

```
IFRAME.dsh-penhost-frame   h=0   (styleH:0px)
DIV.dsh-penhost-body       h=0   flex:1 1 0%
DIV.dsh-penhost-panel      h=0   inline style height:0px
DIV.P3OORG_tabBody         h=0
DIV._tabHostBody_* / SECTION._tabHost_*  h=0
```

视口 1600×1000 时同一链条恢复 `920/962`。结论：**先刷新页面让它按当前窗口尺寸重新布局**，再点画布；只有刷新后仍为 0 才需要写 `dsh-penhost-frame { height: 100% }` 之类的 CSS override 兜底（未实施）。

## 4. 排除性检查（证明"不是文件缺失/不是网络"）

- `/pen-editor/assets/index.js` → **200，len=5636292**；`index.html` 1371 字节、`assets/` 26 个文件共 41.8MB，`<script type="module" crossorigin>` 与 `assets/index.css` 都在。
- `index.html` 自带严格 CSP（`default-src 'self'`、`connect-src` 白名单含 `https://api.pen.dev` `/ api.pencil.dev`），所以**不要**给页面塞外链脚本去"调试"，会被 CSP 拦。
- `api.pencil.dev` 走代理可达（status=404，1.4s），控制台无网络错误 → fetch failed 那类问题确已由离线目录彻底绕过。
- 客户端拼 URL 的位置：`editorUrl = '/pen-editor/index.html?binding=' + encodeURIComponent(state.binding)`；`/pen-editor/index.html` 无 binding 时 `editor-assets.js:240` 直接 `401 "bind the canvas to a conversation first"` —— 裸访问 401 是设计，不是故障。真正的 body 由 `injectBootstrap()` 注入 binding 后才返回 200。

## 5. 对"能否绕过 pen.dev 5 天/月额度"的最终答复

**绕不过登录这一关。** 编辑器启动第一件事是 `get-session`，没有账号就停在登录页；即使完全不用它的托管 agent、只让本地 DSH 改 `.pen` 文件，也必须注册 pen.dev 账号。
"已登录 + 纯本地操作是否计入 agent 天数" **尚未验证**——进不去画布就没法对照用量页，需要登录后自行观察账号页计数。

## 6. 收尾与遗留

- 调试用无头 Chrome 已结束（端口 9322 释放），`dsh web` 仍在 3080 未动。
- 可复用探针脚本留在 `D:\DSH\`：`cdp-probe.mjs`（frame/日志）、`cdp-eval.mjs`（顶层按钮清单）、`probe3.mjs`（点击 + 高度链）。查 DSH 前端问题可直接改 URL 复用。
- 下一步只需人手：刷新 → 点画布 → 邮箱 + `Send Code` 登录；若仍黑，才进入 CSS 高度 override 阶段。
