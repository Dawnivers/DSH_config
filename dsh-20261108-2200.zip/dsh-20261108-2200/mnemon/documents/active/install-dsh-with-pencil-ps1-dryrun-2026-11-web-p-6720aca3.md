---
id: "6720aca3-246e-4298-91d6-d2036ffdacca"
title: "install-dsh-with-pencil.ps1 安装/自动回滚脚本：设计契约、预检门控与 DryRun 踩坑（2026-11，web profile）"
description: "记录为 dsh-with-pencil@0.7.0（匹配 DSH 0.2.0-rc.2）编写的一次性安装脚本的五段结构、四条硬门控（内核版本/进程类型/备份指纹/产物校验）、回滚为何用 robocopy /E 而非 /MIR，以及 DryRun 误报 FATAL、`.\\脚本` 只在当前目录解析、Editor 缓存落 D 盘等实操结论。版本选型见文档 817893a4。"
status: "active"
created_at: "2026-11-08T09:06:08.787Z"
updated_at: "2026-11-08T09:06:08.787Z"
content_hash: "037ddc9156171e698cc97c8a2696e1dd2de60c5b4b273c5ab092237dddeca03f"
source_paths:
  - "install-dsh-with-pencil.ps1"
session_ids:
  - "d17b4494-28af-4161-8d5a-f85744b6bb8f"
memory_body_ids:
  []
---

# install-dsh-with-pencil.ps1：安装与自动回滚脚本

日期：2026-11-08。目标 profile：`web`。宿主内核：DSH **0.2.0-rc.2**（Node v24.16.0）。
**配套阅读**：版本选型与 peer 矩阵见文档 `817893a4-bef0-4ec8-971e-51bb2adee33b`（结论：`dsh-with-pencil@0.7.0` 是唯一精确匹配线）。
脚本路径：`install-dsh-with-pencil.ps1`（工作区根，约 173 行；仅做过 `-DryRun` 预检，**尚未真装**）。

## 1. 为什么要脚本而非三条命令

手工 `npx ... plugin add` 有三个不可观测的失败面：装错插件版本（peer 不匹配时报错含糊）、安装中断留下半成品 profile、编辑器缓存默认落在 C 盘。脚本把这三点变成可回滚的单一事务。

## 2. 五段结构（变量区集中在顶部）

```powershell
$ProfileName  = 'web'
$ProfileRoot  = Join-Path $env:USERPROFILE ".dsh\profiles\$ProfileName"
$BackupRoot   = 'D:\DSH\backup'            # 备份不落 C 盘
$EditorCache  = 'D:\DSH\pencil-editor'     # 编辑器缓存落 D 盘
$ExpectDshVer = '0.2.0-rc.2'               # 本机内核
$PluginSpec   = 'dsh-with-pencil@0.7.0'    # 唯一匹配该内核的插件版本
$AppResources = 'D:\DSH\dsh_data\DSH Desktop\resources\app'
```

| 段 | 职责 | 关键契约 |
|---|---|---|
| 0 | 还原模式旁路入口 | 只允许从 `D:\DSH\backup` 前缀下还原（路径前缀校验，防手滑删错） |
| 1 | 预检 | **内核版本必须等于 0.2.0-rc.2，不符直接拒绝执行**（防装错版本的第一道闸）；检查 Node 版本、profile 存在、目录就绪、在跑的 dsh 进程类型 |
| 2 | 备份 | `robocopy /E` 到 D 盘，记录文件数与 `package.json` 指纹 |
| 3 | 安装 | `npx --yes`（缺 `--yes` 会卡在交互确认上无声挂住） |
| 4 | 校验 | **不只看退出码**：验 `node_modules\dsh-with-pencil\lib\index.js` 实体存在、`package.json` 实际版本号、`@pen.dev\cli` 就位 |
| 5 | 收尾 | 把 `DSH_PEN_EDITOR_CACHE_DIR` 写入用户级环境变量 |

## 3. 回滚为何用 `/E` 而不是 `/MIR`

安装失败分支自动回滚：

```powershell
& npx --yes "@deepseek-ai/dsh@$ExpectDshVer" plugin --profile $ProfileName add $PluginSpec
if ($LASTEXITCODE -ne 0) {
  robocopy $BackupDir $ProfileRoot /E /R:1 /W:1 /NFL /NDL /NJH /NJS | Out-Null
  Die "安装失败（退出码 $LASTEXITCODE），profile 已还原"
}
```

`/E` 只补回文件、**不删除**安装过程中新产生的东西。这样即使备份本身有问题，最坏情况也只是"没退干净"，而不会把用户原有文件删掉。需要彻底还原时才手动走 `-RestoreFrom`（该模式用 `/MIR`，且有 YES 二次确认）。

## 4. 已验证的预检输出（DryRun，本机实测）

```
[OK] profile 存在：C:\Users\林先语\.dsh\profiles\web
[OK] Node 24.16.0
[OK] 内核版本匹配：0.2.0-rc.2
[!!] 检测到 1 个 dsh 进程在跑，建议先 Ctrl-C 关掉再装
[OK] 目录就绪：D:\DSH\backup
[OK] 目录就绪：D:\DSH\pencil-editor
```

## 5. 三个踩过的坑

### 5.1 DryRun 误报 `[FATAL] package.json 里没有 dsh-with-pencil`

DryRun 跳过了第 3 段安装，却仍然执行第 4 段"校验安装结果"——逻辑自相矛盾，是脚本自身的 bug，与环境无关。修法：DryRun 下第 4 段整体跳过并打印"跳过校验，未安装任何东西"。

### 5.2 `.\install-dsh-with-pencil.ps1` 报"不会被识别为 cmdlet"

`.\文件名` 只在**当前目录**解析，不递归搜索。工作区是 `D:\Users\林先语\Documents\deepseek-harness\default-workspace`，不在用户主目录。两种解法：

```powershell
cd 'D:\Users\林先语\Documents\deepseek-harness\default-workspace'; .\install-dsh-with-pencil.ps1 -DryRun
# 或绝对路径（含中文/空格必须加引号）
& 'D:\Users\林先语\Documents\deepseek-harness\default-workspace\install-dsh-with-pencil.ps1' -DryRun
```

环境事实：本机 `pwsh 7.6.9`，`LocalMachine = RemoteSigned` → 本地脚本可直接运行，不需要 `-ExecutionPolicy Bypass`；脚本用到的 `Get-CimInstance` / `[System.IO.Path]::GetFullPath` / `robocopy` 全部兼容。

### 5.3 "有 dsh 进程在跑"不能一刀切

| 进程类型 | 要不要停 | 原因 |
|---|---|---|
| **Desktop 宿主**（当前窗口） | **不用停** | 它用 `desktop` profile，与要安装的 `web` 目录互不相干 |
| **`dsh web` 服务** | **必须 Ctrl-C** | 它加载的正是 `web` profile，安装期间文件被占用 |

旧逻辑一律"建议关掉"属于误伤。改为打印命令行让用户自行判断，只在 `CommandLine` 命中 `(\s|")(web|dsh-web)(\s|"|$)` 时才警告。

## 6. 使用顺序与两条未验证边界

```powershell
.\install-dsh-with-pencil.ps1 -DryRun   # ① 干跑核对路径与内核版本
.\install-dsh-with-pencil.ps1           # ② 真装（先 Ctrl-C 关掉 dsh web）
npx --yes @deepseek-ai/dsh@0.2.0-rc.2 web   # ③ 启动
```

未验证 / 不保证：

1. **`npx` 那步未在本机网络（可能走代理）验证过**。脚本能捕获退出码并回滚，但**判断不了"装上了却跑不起来"**——那只能靠实际打开画布验证。
2. **内核版本检测硬编码 `$AppResources` 路径**。升级 Desktop 换安装目录后检测会 fail-safe 到"跳过校验并提示"，不会误伤；但也意味着可能漏掉版本不符。
3. 脚本**不检查 desktop profile 的冲突**。它只碰 `web`，而 `web` 已有 `dsh-better-sidebar`，两者都要抢 `dsh-client-ui-sidebar-right` 插槽——画布标签页打不开时先怀疑此处。

另需提前想清楚：该插件是 web profile 插件，**画布不会出现在 Desktop 窗口**，而是需要额外起一个 `npx dsh web` 进程——这是"多开一个界面"，不是"装进现有界面"。
