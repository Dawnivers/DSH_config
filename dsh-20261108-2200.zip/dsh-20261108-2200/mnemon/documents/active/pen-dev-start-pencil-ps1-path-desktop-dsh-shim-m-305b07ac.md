---
id: "305b07ac-b7a1-43fb-b0e0-fc05c8566766"
title: "pen.dev 画布端到端打通与日常启动手册：start-pencil.ps1、PATH 上 desktop 专用 dsh shim 陷阱、MCP 落盘验证（2026-11-08）"
description: "记录 dsh-with-pencil 在 web profile 登录成功后的收尾：用 pencil_mcp_execute 真正写出 design.pen 并导出 out/H0jCUo.png 作为端到端证据；start-pencil.ps1 的定位/校验/使用与停止方式；PATH 里的 dsh 是写死 desktop profile 的桌面端 shim（不能用 dsh web 起画布）；脚本挡掉的三种必然失败；后台 job exit code 1 = 被外部终止；pen.dev 计费仍未实测。前置：68b45688（双 profile 架构与为何不装 desktop）、92617817（黑屏真因=登录+高度0）、379b1ca7（离线注入收尾）。"
status: "active"
created_at: "2026-11-08T12:31:24.901Z"
updated_at: "2026-11-08T12:31:24.901Z"
content_hash: "9f6a9ac8feb4db2e169fabf9c768a2ecaae9e7fa309001d43d8dee9bea0e8ba3"
source_paths:
  - "start-pencil.ps1"
  - "install-dsh-with-pencil.ps1"
  - "designs/design.pen"
  - "designs/out/H0jCUo.png"
session_ids:
  - "c025d7da-c09f-460a-a99e-a1d68359a27b"
memory_body_ids:
  []
---

# 画布端到端打通之后：怎么起、怎么验、哪些坑已经踩平

日期：2026-11-08（20:31 前后）。profile `web`，宿主 DSH **0.2.0-rc.2**，插件 **dsh-with-pencil@0.7.0**，编辑器离线目录 `D:\DSH\pencil-editor\download\extract\out`。
**前置文档**：`68b45688`（双 profile 架构 / 为何不装 desktop / C 盘占用）、`92617817`（黑屏真因 = pen.dev 强制登录 + iframe 高度链归零）、`379b1ca7`（离线注入收尾与重启流程）。
本文只记**登录打通（用户口头确认"已经登录"）之后**新获得的两件事：一套可复制的日常启动方式，和一次真正的端到端落盘验证。不重复安装与排障推导。

## 1. 端到端验证：不再只是"编辑器能显示"

登录后画布交出完整工具栏（选择/矩形/形状▾/文字/组件/便签/抓手/钢笔/画板/滑块、`Share`、`100%` 缩放），底部两条空状态模板卡（`Control panel for a humanoid robotics factory floor`、`Warm minimal booking site for a Lisbon coworking space`）。
**判据不是"能看到 UI"，而是"发一条指令后磁盘上有产物"**。验证指令（在 web 界面左侧对话里发）：

```
用 pencil_mcp_open 打开 designs/design.pen，然后用 pencil_mcp_execute
插入一个 frame：x=120, y=120, width=400, height=300,
fill=#1F2937, cornerRadius=12，标题文字 "Hello pen.dev"。
再用 pencil_mcp_get_screenshot 截图确认画布上有东西。
```

结果四环全通：

| 环节 | 证据 |
|---|---|
| MCP 工具可调 | `pencil_mcp_execute` 写出 frame + text 两个节点 |
| 画布↔文件同步 | 服务日志连续 `reloaded externally changed canvas: .../design.pen (1 → 2 → 3 top-level nodes)`，另有一次 `designs/hc-test.pen (0 top-level nodes)` |
| 磁盘落盘 | `designs/design.pen` **816 B**，含 `"version": "2.14"` 与生成的 `fileToken`（UUID）——证明是懒创建：标题栏写着路径也要等第一次编辑/保存才落盘 |
| 导出可用 | `designs/out/H0jCUo.png`，**800×600**、16423 B（frame 是 400×300 的 2× 图） |

`.pen` 的节点形态（可直接照抄当模板）：frame 支持 `x/y/name/width/height/fill/cornerRadius/layout/justifyContent/alignItems`，text 子节点用 `content/textGrowth/textAlign/fontFamily/fontSize/fontWeight/fill`。

**关键点**：这条链路跑的是 DeepSeek（web 界面里选的模型）+ 本地 pen.dev 编辑器，**没有经过 pen.dev 的托管 agent** —— 这正是搭建这套的目的。底部那两张模板卡是 pen.dev 自家 agent 的入口，点了就会消耗它的账号额度，**不要点**。

## 2. PATH 上那个 `dsh` 不是通用 CLI（最容易踩的新坑）

```
C:\Users\林先语\AppData\Roaming\DSH Desktop\host-commands\desktop\generations\<hash>\bin\dsh.cmd
```

内容里写死三行关键环境（`ELECTRON_RUN_AS_NODE=1`、**`DSH_DESKTOP_DEFAULT_PROFILE=desktop`**、`DSH_HOME=C:\Users\林先语\.dsh`），最后调用 `DSH Desktop.exe ... resources\app\lib\desktop-cli.js %*`。

结论：**`dsh web` 不要用** —— 它会带着 `desktop` 档案跑，而画布插件装在 `web` 档案里，行为不确定（可能起第二个桌面实例）。起画布一律走已验证的 npx 那条：`npx --yes @deepseek-ai/dsh@0.2.0-rc.2 web`（该份代码在 `C:\Users\林先语\AppData\Local\npm-cache\_npx\...`，约 495 MB，见 `68b45688` 的 C 盘占用与 A/B/C 补救）。

## 3. 日常启动：`start-pencil.ps1`

脚本在工作区根目录（`start-pencil.ps1`，`pwsh -NoProfile -Command` 语法校验通过）。它做的事：校环境变量 → 校离线编辑器目录 → 校插件版本 → 校端口 → 起服务。

```powershell
cd 'D:\Users\林先语\Documents\deepseek-harness\default-workspace'
.\start-pencil.ps1            # 正常启动
.\start-pencil.ps1 -Check     # 只体检不起服务
.\start-pencil.ps1 -MoveCache # 一次性把 npm 缓存挪到 D 盘（需重下 ~495 MB）
# 停止：在那个窗口按 Ctrl-C
```

启动成功时终端打印 `dsh web: http://127.0.0.1:3080/?token=xxxxxxxx` —— **token 每次都是新的，别收藏，从终端复制**。起来后：打开该地址 → 选会话 → 点「pen.dev 画布」。登录态已存在 `~/.dsh/dsh-with-pencil/state.json`（email + token 两个字段），**不用重登**，除非过期。

想常驻可最小化到后台：

```powershell
Start-Process pwsh -ArgumentList '-NoExit','-Command','cd ''<workspace>''; .\start-pencil.ps1' -WindowStyle Minimized
```

**脚本挡掉的三种"必然失败"**（设计意图，比脚本本身更重要）：
1. `DSH_PEN_EDITOR_DIR` 指向不存在的目录 → 直接 FATAL，不启动（避免退回远程下载而失败）；
2. 插件未安装 → FATAL 并提示先跑 `install-dsh-with-pencil.ps1`；
3. 3080 已被占用 → 不重复启动，打印占用 PID 与 `Stop-Process -Id <PID> -Force`，避免两个实例互相打架。

## 4. 两个观测经验

- **后台 job 的 `[exit code: 1]` 不一定是崩溃**：这次 web 服务结束时日志最后一行仍是正常的 canvas reload，没有任何 error，属于被外部终止；Windows 上强杀进程就结算成 1，且不带信号标记。判据应看"日志尾部有无报错"，而不是退出码。
- **profile 隔离在这次收尾里被反向验证了**：3080 停掉后 `57870 / DSH Desktop.exe PID 34212` 照常运行，`design.pen` 也仍在。代价仍是"Desktop 窗口永远没有画布标签"（见 `68b45688`）。

## 5. 仍未验证的一项

**pen.dev 的 5 天/月额度到底会不会被扣**。当前用法（本地编辑器 + DeepSeek 驱动 + 自建 frame）理论上不触发托管计量，但这是推断：需要用几天后去看 pen.dev 账号的用量页涨不涨才有结论。这也是唯一还开着的口子。
