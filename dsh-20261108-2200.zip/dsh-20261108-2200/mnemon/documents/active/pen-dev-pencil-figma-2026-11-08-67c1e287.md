---
id: "67c1e287-c414-4b24-a6b6-ca340ca5ccb6"
title: "截图取证：截图里的设计工具是 pen.dev（Pencil）而非 Figma（2026-11-08）"
description: "用户质疑「这不是 Figma 吗」后，通过放大截图局部 + pen.dev 官方文档交叉验证得出的工具归属结论：六条排除 Figma 的界面证据、被推翻的「DSH Design Systems 画布」错误结论、以及图像本身来自视频帧的判读。供后续做 pen.dev ↔ Figma 对照或继续讨论该工具时直接复用。"
status: "active"
created_at: "2026-11-08T04:38:30.414Z"
updated_at: "2026-11-08T04:38:30.414Z"
content_hash: "e635df14a086b4ffcaec51b5496ff3af30b1c617da98c8c2a742e830b763a99c"
source_paths:
  - "shot-crops/righttop.png"
  - "shot-crops/bottom.png"
  - "shot-crops/corner.png"
  - "shot-crops/toolbar.png"
session_ids:
  - "adcd11e4-517e-44aa-8fa2-7b73b12860db"
memory_body_ids:
  []
---

# 截图取证：那个设计工具是 pen.dev（Pencil），不是 Figma

用户贴了一张设计工具截图；agent 先误判为「DSH Desktop 自带的 Design Systems 画布」，用户反问「真的吗？这个不是 Figma 吗」。放大截图局部（`shot-crops/righttop.png`、`bottom.png`、`corner.png`、`toolbar.png`）并核对 pen.dev 官方文档后，结论成立：**不是 Figma，是 pen.dev（Pencil）桌面版**。

## 1. 排除 Figma 的证据（截图 ↔ 文档逐条对应）

| 截图里的证据 | 判定 |
|---|---|
| 标签页 `miaoma-test.pen — Edited` | `.pen` 是 pen.dev 的文档格式（Figma 是 `.fig`） |
| 工具栏**竖排在左侧**（箭头/矩形/T/组件/便签/抓手/形状/画板/带滑条面板） | Figma 工具条横排于顶部中央，左侧只有图层树 |
| 右上角 `Agents \| Design Systems` 双页签 | Figma 右侧是 `Design / Prototype`，无 Agents 页签 |
| 属性面板分组 `Context / Alignment / Position / Flex Layout / Padding / Dimensions / Appearance / Fill / Stroke / Effects / Export`，含 `Hug Width` `Hug Height` `Fill Width` `Fill Height` `Clip Content` | 与 pen.dev Interface 文档的 Flex layout 章节逐条对应；Figma 叫 **Auto layout**，无独立 `Flex Layout`+`Dimensions` 分组 |
| 顶部 `Set Repository` | 把 `.pen` 文档绑到代码仓库做 design↔code 同步，Figma 无此物 |
| 左下角输入框 `Design with Claude or Codex…` + 模型下拉（`GPT 5.4`、`⚡6x`）+ 附件 + 发送，上方 `1 object selected` | pen.dev 的 **AI agent composer**；Figma 无模型选择器 |

文档依据：`https://docs.pencil.dev/core-concepts/pencil-interface`、`/getting-started/ai-integration`、`/core-concepts/pen-files`、`/design-and-code/design-to-code`。

## 2. 被推翻的错误结论（别再重复）

上一轮把 `Design Systems` 四个字当成 DSH 内置设计画布的依据，属硬凑。实际核对本机 `C:\Users\林先语\.dsh\profiles\desktop` 与 `web` 的依赖清单（dsh-tui、dsh-web-all、modlens、agnes 系列、better-sidebar、mnemon、video-storyboard…），**没有任何设计画布类插件**。DSH Desktop 里不存在这样的画布，遇到类似截图先查文档再开口。

## 3. 图像本身不是用户屏幕

左下角残留 `1人正在…` 人气遮罩 → 这是**视频/直播截帧**，画面中的人在录屏演示 pen.dev 画「妙码 CRM · 客户管理」页面（画板 1440×1024，prompt 提到用 shadcnui 设计 CRM）。判断截图来源时，先看有无播放器/直播残留 UI。

## 4. pen.dev 关键事实（文档侧，供后续对照）

- 定位不是「Figma 替代品」，而是**设计完直接同步成仓库里的代码**（Set Repository + Code on Canvas + HTML/SVG/PDF 导出）。
- 外部集成走 MCP：顶层工具 `get_style`、`read_skill`、`get_app_state`、`execute`，条件性提供 `save`（`--disable_save_tool` 可关）、`browser`（桌面宿主时）、`spawn_agents`（需 `--enable_spawn_agents`）。
- 排障要点：外部客户端连不上 → 确认 pen.dev 在跑且有 `.pen` 打开、改完 MCP 配置要重载客户端；agent 改错文档 → 用 `get_app_state()` 确认活动文档。
- 选择框语义：蓝色=普通元素，**洋红=组件源**，紫色=组件实例；组件/实例语义与 Figma 概念同源但命名不同。

## 5. 未做（用户当时被问过但未答复）

尚未产出 pen.dev ↔ Figma 的完整能力/适用人群对照表；如果用户回头要，按上面证据直接扩写即可，不必重新截图。
