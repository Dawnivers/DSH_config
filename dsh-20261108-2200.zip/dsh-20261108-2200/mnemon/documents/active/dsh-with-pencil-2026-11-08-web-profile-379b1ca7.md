---
id: "379b1ca7-1063-4ca5-bc1b-00ba13658483"
title: "dsh-with-pencil 第四层收尾：重启验证通过、离线路径确证短路下载、画布按钮仍需人工点击（2026-11-08，web profile 实况）"
description: "记录 dsh-with-pencil@0.7.0 离线编辑器注入的实际接管结果：写用户级 DSH_PEN_EDITOR_DIR（含 *CACHE* 笔误教训）、停旧进程释放 3080、重启后日志确证路由与 9 个 pencil_* 工具注册、editor-assets.js:30 短路下载的源码证据、/pen-editor 无 binding 时返回 401 属正常而非故障、以及浏览器桥无扩展导致画布按钮只能人工点击的边界。前置：f87e95f4（根因与方案）、6720aca3（脚本）、817893a4（版本）。"
status: "active"
created_at: "2026-11-08T09:37:45.975Z"
updated_at: "2026-11-08T09:37:45.975Z"
content_hash: "e6df34534916d81e57566e2290eb75ac9a1ea8eb79bd29d7b31d813a9e2eead6"
source_paths:
  - "install-dsh-with-pencil.ps1"
session_ids:
  - "ff8fe711-6414-47df-8661-bfae7db8d39a"
memory_body_ids:
  []
---

# 第四层收尾：离线注入真的生效了，剩下一步只能人手点

日期：2026-11-08。profile `web`，宿主 DSH **0.2.0-rc.2**（Node v24.16.0），插件 **dsh-with-pencil@0.7.0**，脚本 `install-dsh-with-pencil.ps1`。
**前置文档**：`f87e95f4`（fetch failed 的 DNS/代理根因 + DSH_PEN_EDITOR_DIR 方案）、`6720aca3`（安装脚本五段设计）、`817893a4`（版本适配矩阵）。
本文只记**方案被执行并验证之后**才知道的事，不重复前置文档的方案推导。

## 1. 接管执行序列（可复制的重启流程）

环境变量改完**必须重启进程**，点界面上的「重试」无效（变量在启动时读一次）：

```powershell
# ① 查 3080 上到底是谁
Get-NetTCPConnection -LocalPort 3080 -State Listen | Select-Object OwningProcess
Get-CimInstance Win32_Process -Filter "ProcessId=<PID>" | Select-Object CommandLine, ParentProcessId

# ② 写用户级（持久）+ 当前进程级（当窗口立即生效）
[Environment]::SetEnvironmentVariable('DSH_PEN_EDITOR_DIR','D:\DSH\pencil-editor\download\extract\out','User')
[Environment]::SetEnvironmentVariable('DSH_PEN_EDITOR_CACHE_DIR','D:\DSH\pencil-editor','User')
$env:DSH_PEN_EDITOR_DIR = 'D:\DSH\pencil-editor\download\extract\out'

# ③ 停旧、重启
Stop-Process -Id <PID> -Force
npx --yes @deepseek-ai/dsh@0.2.0-rc.2 web
```

实测旧进程形态：`node ...\npm-cache\_npx\7eff65a5cfe9d1d1\node_modules\@deepseek-ai\dsh\lib\bin.js web`，父进程是 `cmd.exe /d /s /c dsh web`。杀掉后脚本确认「3080 已释放」，新进程重新监听。

**踩坑**：一开始把两个变量名写成 `DSH_PEN_EDITOR_CACHE`（漏了 `_DIR`），读回时两个都是空值 —— 说明写错名字不会报错，只会静默不生效。改完务必回读确认。

## 2. 启动日志就是「插件加载成功」的判据

```
env in this process: D:\DSH\pencil-editor\download\extract\out
[dsh-with-pencil] pen.dev canvas routes ready at /pen-editor (binds workspace on conversation trigger)
[dsh-with-pencil] registered 9 pencil_* tools (pen=...\@pen.dev\cli\dist\index.mjs, mcp=...\mcp-server-windows-x64.exe; workspace resolves per call)
dsh web: http://127.0.0.1:3080/?token=<redacted>
```

四件事一次确认：环境变量进了进程、路由挂上、9 个 `pencil_*` 工具注册、`@pen.dev/cli` 与 windows-x64 MCP 二进制路径都解析到了。
反过来说，**看不到这三行 `[dsh-with-pencil]` 就是没加载**，不要去看画布表现。

## 3. 源码证据：有本地 index.html 就绝不走下载

`lib/editor-assets.js:26-64` 的 `editorDirectory()`：

```js
if (process.env.DSH_PEN_EDITOR_DIR) candidates.push(path.resolve(process.env.DSH_PEN_EDITOR_DIR))
...
for (const candidate of candidates) {
  try { if (fs.statSync(path.join(candidate, 'index.html')).isFile()) { resolvedEditorDir = candidate; return candidate } }
  catch (error) { /* 试下一个 */ }
}
try { resolvedEditorDir = await editorInstaller({...}) }   // ← 只有全部候选都没 index.html 才联网
catch (error) { throw new Error(`${message}; retry the canvas open or set DSH_PEN_EDITOR_DIR for offline use`) }
```

所以离线注入不是「让下载更容易成功」，而是**整条 fetch 分支不可达**——`fetch failed` 这一类不确定性被结构性排除。校验 `Test-Path ...\out\index.html` 为 True 即可放心。
解压后 zip 顶层就一个 `out/`，要指向的是 `out` 这一层，不是 `extract`。

## 4. `/pen-editor` 返回 401 是正常的，别误判

带 token 登录主页面后探测：

| 请求 | 响应 | 含义 |
|---|---|---|
| `/`（带 token） | 200，44408 字节 | 登录成功，cookie 建立 |
| `/pen-editor` | 401 | **有路由、但缺 canvas binding**，属预期 |
| `/pen-editor/` | 404 | 前缀路由不带尾斜杠 |
| `/pen-editor/index.html` | 401 | 同上，缺 binding |

路由注册是 `kind: 'prefix', path: '/pen-editor'`（`canvas-host.js:1056`），handler 交给 `editorAssets.serve`，binding 由 `/pen-host/bind` 在会话触发画布时建立。**curl 探测 401 不能作为「插件坏了」的证据**，它只说明还没绑定会话。

## 5. 真正的剩余边界：画布按钮点不了

`browser_list_tabs` → `Error: no browser extension is connected to the bridge`。没有浏览器桥扩展，就没有点击/读页面的入口，因此「在会话里点一下画布按钮」这一步无法自动化，只能由用户手动完成。

- 宿主的 `/pen-host/ipc`、`/pen-host/state`、`/pen-session-token` 等端点全部按 binding 做 401 门控，**绕过 UI 直接调接口造不出 binding**。
- 想让 agent 代点，前置是装好桥接扩展（如 `dsh-see-now` 一类），这与插件安装是两件独立的事。

## 6. 状态与回滚

- 验证实例当时跑在后台 job `pwsh-45` 里；日常使用应在自己终端起 `npx --yes @deepseek-ai/dsh@0.2.0-rc.2 web`（用户级变量已持久化，新窗口自动带上）。
- 回滚一条命令：`.\install-dsh-with-pencil.ps1 -RestoreFrom 'D:\DSH\backup\web-20261108-172024'`（该备份 19755 个文件，package.json 指纹 `FAE24651A5B902D4`）。
- 下载好的 `editor-bundle-v0.1.94.zip`（23.6 MB）保留，SHA-256 `7b655d0e…4ad22a` 与插件内置值一致；插件升级会换版本号，届时需要重新下载+校验。

## 7. 下一层若仍失败，按症状分流

| 症状 | 指向 |
|---|---|
| 画布出来但红字报 `ENOENT` / `missing asset` | `DSH_PEN_EDITOR_DIR` 层级错（试指 `extract` 而非 `extract\out`） |
| 画布标签点了无反应 / 空白 | 侧栏插槽问题，临时禁用 `dsh-better-sidebar` 二分（注：第 3 层已通过，此项风险实际已降低） |
| 报错提 `fileURI` / workspace | 已过资源加载阶段，转查 `__penFileURI` 注入与 workspace 绑定 |
| 启动即崩 | 插件与宿主冲突，直接回滚 |
