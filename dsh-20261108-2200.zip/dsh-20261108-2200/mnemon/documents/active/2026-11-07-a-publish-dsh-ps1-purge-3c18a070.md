---
id: "3c18a070-eeb5-4f8a-88f4-ae6bdd470227"
title: "回收站自动清空接入周备份（2026-11-07 方案 A：publish-dsh.ps1 推送成功后 purge）"
description: "提炼+剪枝闭环里 --purge 从未挂上，回收站只增不减；记录用户选定方案 A 后的实现（新增 purge-trash.ps1、publish-dsh.ps1 在推送成功后调用、参数与默认值）、判据仍由 prune-sessions.mjs 复核、三组测试证据、首次真清时间与边界风险。"
status: "active"
created_at: "2026-11-07T13:03:41.881Z"
updated_at: "2026-11-07T13:03:41.881Z"
content_hash: "4a87b1946cf1419687518918e964191e41839f0134db295e4147fdf9d8220102"
source_paths:
  - "dsh-migration/publish-dsh.ps1"
  - "dsh-migration/purge-trash.ps1"
  - "dsh-migration/prune-sessions.mjs"
session_ids:
  - "session-db72ccee-2dca-4521-9c44-9357dfadb8d1"
memory_body_ids:
  []
---

# 回收站自动清空接入周备份（2026-11-07，方案 A）

闭环里缺的一环：`prune-sessions.mjs` 只把会话**搬进** `D:\dsh-migration\session-trash\`，`--purge` 从未被任何调度调用，于是「30 天后悔药窗口」实际从不生效——回收站只增不减。2026-11-07 查得已有 200 个文件 / 151.3 MB，两个批次（`20261101-2209` 71 个会话、`20261107-2029` 28 个会话）。

用户当次在 A/B 之间选了 **A：跟着周备份一起清**，不新增调度。

## 1. 新增 `purge-trash.ps1`

只做「挑批次、报体积、核对结果」，删除仍交给 `prune-sessions.mjs --purge`，判据只有一份。

| 参数 | 默认 | 作用 |
| --- | --- | --- |
| `-TrashRoot` | `D:\dsh-migration\session-trash` | 回收站根目录（`publish-dsh.ps1` 传 `$OutRoot\session-trash`） |
| `-OlderThanDays` | `30` | 判定线，年龄取 `manifest.json` 的 `at` |
| `-Apply` | 关 | 不带就是演练；带了才真删 |

安全边界（都是硬条件，不是建议）：

- 只认名字形如 `yyyyMMdd-HHmm` **且**含 `manifest.json` 的目录——人工丢进回收站的东西一概不碰；
- 年龄读 `manifest.json.at`；读不到就跳过并告警，绝不退回用目录名或 mtime 猜；
- 未满判定线的批次直接 `continue`，连 node 都不调用；
- 调用 node 后仍要复核：`exit != 0` 或目录仍在，都按「未清空」记，不谎报释放体积。

## 2. `publish-dsh.ps1` 接在推送成功之后

```
distill --days 7
  → prune --digest-dir … --min-age-hours 12 --apply
  → export → 脱敏 → 密钥体检 → zip
  → git push（失败即 throw，不会走到下面）
  → purge-trash.ps1 -Apply -OlderThanDays 30      ← 新增
  → 写 publish-state.json
```

- 位置在 `Write-Ok ($pushOut)` 与「4. 收尾」之间，即**备份先落地、再清本地**；推送失败时脚本已 throw，回收站不会被清。
- 新增两个参数：`-PurgeOlderThan`（默认 30）、`-NoPurge`（跳过清理，便于临时保留全部批次）。
- `-DryRun` 在推送前就 `return`，所以演练永远不会删回收站——这一点靠位置保证，不靠额外判断。
- 清理失败只 `Write-Warn`，不阻断备份（它不影响包内容）。

## 3. 测试证据（2026-11-07，21:0x）

| 用例 | 结果 |
| --- | --- |
| 两个脚本 AST 解析 | 0 错误 |
| 真实回收站 `-Apply` | 6.3 / 0.4 天两批全部保留，清空 0 个，200 文件不变 |
| 假回收站 `-Apply`：40 天批 + 3 天批 + 无 manifest 的人工目录 | 40 天批被清（node 打印 `已清空`，目录消失）；3 天批与人工目录完好 |
| 假回收站 `-OlderThanDays 60`：40 天批 | 判定「未满 60 天 → 保留」 |

## 4. 首次真清时间

`20261101-2209` 的 `manifest.at` 是 2026-11-01T14:09Z，满 30 天在 2026-12-01T14:09Z。周备份落在周日 22:00，故：

- 2026-11-29 那次：28.3 天，**不清**；
- **2026-12-06 那次：35.3 天，第一次真正清空**（约 85 MB / 71 个会话）；
- `20261107-2029` 批要到 2026-12-13 才会被清。

## 5. 边界与风险

- 过了 30 天就是**永久删除**，没有二次确认——这是设计如此，后悔药窗口就是全部保障；
- 机器长期关机不影响：年龄按 manifest 算，下次运行补清（前提是批次目录还在本地）；
- 若将来 `prune` 改了回收站布局（去掉 manifest 或改命名），本脚本会整天跳过而不是误删，属于安全的失败方向。

## 6. 未做的部分

- 没有改 schedule 任务的 prompt（它绑定在 `session-e2ba3bc9`），因此 11-08 那次执行不会主动核对 purge 结果；要看效果就翻 `publish` 输出里「清理回收站」那一段，或手动跑 `purge-trash.ps1`（不带 `-Apply`）。
- 没有把「清空了几批 / 释放多少 MB」写进 `publish-state.json`，需要时从日志取。
