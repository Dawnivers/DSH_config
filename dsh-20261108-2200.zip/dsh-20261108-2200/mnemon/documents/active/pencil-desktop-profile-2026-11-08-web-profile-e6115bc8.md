---
id: "e6115bc8-f05c-4920-b21c-102ecb78aaec"
title: "pencil 画布的日常启动入口与「不装进 desktop profile」决策（2026-11-08，web profile）"
description: "记录 dsh-with-pencil 跑通后的运维结论：为何坚持装在 web profile 而不装 desktop（18 依赖/9 个 link:、必须完全退出 Desktop、peer 精确钉死导致升级断裂）、真装时的安全序列、start-pencil.ps1 + pencil.cmd 别名启动方式、PATH 里 Desktop 的 dsh.cmd shim 冲突、ASCII 写文件破坏中文路径的坑，以及 skills 是全局共享目录、web 端本就能加载、skills-manager 需单装的边界。"
status: "active"
created_at: "2026-11-08T12:45:28.107Z"
updated_at: "2026-11-08T12:45:28.107Z"
content_hash: "19e2a7f89b2cfbf75eb9619b385014116288877f5aa9cec79ffa0dd7d2021748"
source_paths:
  - "start-pencil.ps1"
  - "install-dsh-with-pencil.ps1"
  - "designs/design.pen"
session_ids:
  - "ceaa8518-a0e4-4cdc-a2fa-df90b72acd79"
memory_body_ids:
  []
---

# pencil 画布的启动入口与 profile 隔离决策

日期：2026-11-08。profile `web`，DSH **0.2.0-rc.2**，插件 **dsh-with-pencil@0.7.0**。
**前置文档**：`f87e95f4`（fetch failed 根因与 DSH_PEN_EDITOR_DIR 方案）、`6720aca3`（install-dsh-with-pencil.ps1 五段设计）、`379b1ca7`（重启验证与日志判据）、`817893a4`（版本适配矩阵）。
本文只记**跑通之后**的运维结论：入口怎么给、为什么不搬进桌面端、以及两条被实际踩到的 Windows 坑。

## 1. 结论：插件留在 web profile，不进 desktop

技术上可行（桌面端内核同为 `0.2.0-rc.2`，编辑器与登录态都已就绪），但代价不对等：

| 维度 | web profile | desktop profile |
|---|---|---|
| 依赖规模 | 5 个包 | **18 个包，其中 9 个是 `link:`/`file:` 本地源码引用** |
| 每次 `pnpm add` | 小树，几分钟 | 重新解析 18 个依赖、重建 9 个 link |
| 操作窗口 | 随时 | **必须先完全退出 Desktop**，期间无法使用 DSH |
| 失败后果 | 3080 起不来，Desktop 照常工作 | 轻则画布消失，重则**桌面端拒绝启动**（依赖缺失时会把 profile 依赖重写成空） |
| 升级断裂 | 3080 挂掉，Desktop 无感 | peer 精确钉死 `0.2.0-rc.2`，桌面端一升到 `0.2.1-rc.x` 就整端风险 |

`link:` 清单（desktop）：`dsh-agnes-core`、`dsh-agnes-image`、`dsh-agnes-video`、`dsh-mcp-anysearch`、`browser/bridge-browser`、`dsh-academic-research-skills`、`dsh-archify`、`dsh-context7`，外加 `file:` 的 `dsh-video-storyboard`。Windows 上建 link 依赖 rename/junction，正是 HMR watcher 占用目录时会 EPERM 的那个操作——本机 10 月两次事故（pnpm store 被当缓存删、pnpm 11 升级 link 时 rename EPERM）都发生在这个 profile 上。

硬约束来自 CLI 源码 `plugin-BGnVfe_D.js:11`：**先打开一次 Desktop 初始化 profile，然后完全退出它**才能跑 `dsh plugin --profile desktop`。也就是说操作窗口期一旦写坏，连启动都进不去。

**唯一的加分场景**：想和 archify / video-storyboard 在同一进程里共享工具，才必须装 desktop。

## 2. 如果真要装 desktop，安全序列

```powershell
# ① 备份（18 插件 + 9 link，慢，别中断）
robocopy 'C:\Users\林先语\.dsh\profiles\desktop' 'D:\DSH\backup\desktop-<时间戳>' /E
# ② 人手完全退出 DSH Desktop（agent 无法代做：退出会杀掉自身会话）
# ③ 补 allowBuilds.sharp，否则 ERR_PNPM_IGNORED_BUILDS
# ④ 走 pnpm 11.8.0 shim，否则 ERR_PNPM_UNEXPECTED_STORE
$env:PATH = 'D:\DSH\shims;' + $env:PATH
npx --yes @deepseek-ai/dsh@0.2.0-rc.2 plugin --profile desktop add dsh-with-pencil@0.7.0
# ⑤ 重新打开 Desktop 验证
```

只有第 ② 步必须人工。更划算的替代方案就是下面第 3 节的双击启动。

## 3. 日常入口：start-pencil.ps1 + pencil 别名

`start-pencil.ps1`（工作区根）做四件事，并挡掉三种必然失败：

```
[OK] DSH_PEN_EDITOR_DIR / DSH_PEN_EDITOR_CACHE_DIR 已设
[OK] 离线编辑器就位（缺 index.html 直接 FATAL）
[OK] 画布插件版本 0.7.0（缺包直接 FATAL，提示先跑 install 脚本）
[OK] 端口 3080 空闲（被占用则打印占用 PID 与 Stop-Process 命令，拒绝重复启动）
→ npx --yes @deepseek-ai/dsh@0.2.0-rc.2 web
```

用法：`-Check` 只做预检不启动；`-MoveCache` 一次性把 npm 缓存挪到 D 盘；`Ctrl-C` 停止（`dsh web` 是前台进程）。启动后终端打印的 `http://127.0.0.1:3080/?token=...` **每次都是新 token，不要收藏**。

免 `cd` 的别名：

```cmd
:: D:\DSH\bin\pencil.cmd
@echo off
pwsh -NoProfile -ExecutionPolicy Bypass -File "D:\DSH\bin\start-pencil.ps1" %*
```

`D:\DSH\bin` 已加入**用户级 PATH**，需新开窗口才生效。脚本副本放在纯 ASCII 路径下，原因见 4.2。

## 4. 两个实际踩到的坑

### 4.1 PATH 里已经有一个 `dsh`，且是桌面端专用 shim

```
PATH 第 2 项：C:\Users\林先语\AppData\Roaming\DSH Desktop\host-commands\desktop\generations\<hash>\bin
其中 dsh.cmd 内容：
  set "ELECTRON_RUN_AS_NODE=1"
  set "DSH_DESKTOP_DEFAULT_PROFILE=desktop"     ← 默认档案被写死
  set "DSH_HOME=C:\Users\林先语\.dsh"
  "D:\DSH\dsh_data\DSH Desktop\DSH Desktop.exe" --expose-internals <app>\lib\desktop-cli.js %*
```

推论：**不要用 `dsh web` 起画布端**，它会带着 desktop 档案跑（可能起第二个桌面实例），而插件在 web 档案里。若将来真做「全局装 D 盘、直接 `dsh web`」的方案，新 bin 目录必须插到 PATH **第 1 位**（不是追加），且与桌面端 `dsh` 同名会长期造成歧义——收益只是省缓存与启动时间，不值得维护 PATH 顺序。

### 4.2 `-Encoding ASCII` 把中文路径写成 `???`

第一版用 ASCII 写 `pencil.cmd`，`林先语` 变成 `???`，命令直接失效，且**写入时不报错**。8.3 短路径也救不了（该目录未生成短名）。解法：把 `start-pencil.ps1` 复制到纯 ASCII 路径 `D:\DSH\bin\start-pencil.ps1`，cmd 只引用 ASCII 路径。教训：Windows 下批量写脚本文件默认用 UTF-8（无 BOM 亦需复核），写完**回读检查是否含 `???`**。

## 5. 端到端验证结论（一次就够，别再重跑）

`designs/design.pen`（816 字节，含 `fileToken`）由 `pencil_mcp_execute` 写入一个 frame + 一个 text 节点，导出得到 `designs/out/H0jCUo.png`（800×600 的 2× 图）。日志中 1→2→3 个顶层节点的 `reloaded externally changed canvas` 记录证明画布与文件同步。四环全通：MCP 工具可调 → 文件同步 → 磁盘落盘 → 导出可用，且驱动模型是 DeepSeek 而非 pen.dev 托管 agent。

服务被外部终止时表现为 `[exit code: 1]` 且日志无错误（最后一行仍是正常 reload）——Windows 强杀即 exit 1，不要当故障排查。

## 6. skills 的边界（易误解点）

- 32 个 skill 在**全局共享目录** `C:\Users\林先语\.dsh\skills\`，两个 profile 读同一份，**不需要「装到网页端」**。
- web profile 的 `dsh-base` 依赖里已含 `@deepseek-ai/dsh-skill`、`dsh-skill-filesystem`、`dsh-skill-badge`、`dsh-tool-skill`，网页端 agent 本就可用 `/` 调起。
- 三个 UI 设计 skill：`design-md`（84 份品牌设计 token）、`design-taste-frontend`（anti-slop 美术指导 + 真实浏览器截图检查）、`react-bits`（218 个动效组件索引，按需取单文件）。
- 唯一缺的是管理面板 `@michengai/dsh-skills-manager@1.3.0`，目前只在 desktop profile；它的 peer 是**范围约束** `>=0.2.0-rc.1 <0.3.0-0`，与本机 0.2.0-rc.2 兼容，可单独装进 web（装前必须先停 3080，避免 pnpm 动 `node_modules` 时 EPERM）。

## 7. 收尾清单（文件位置）

| 项 | 位置 |
|---|---|
| 启动脚本 | `start-pencil.ps1`（工作区根）、`D:\DSH\bin\start-pencil.ps1`（ASCII 副本） |
| 命令别名 | `D:\DSH\bin\pencil.cmd` |
| 安装/回滚脚本 | `install-dsh-with-pencil.ps1` |
| 设计文件 | `designs\design.pen`，导出 `designs\out\H0jCUo.png` |
| 离线编辑器 | `D:\DSH\pencil-editor\download\extract\out` |
| 备份 | `D:\DSH\backup\web-20261108-172024` |
