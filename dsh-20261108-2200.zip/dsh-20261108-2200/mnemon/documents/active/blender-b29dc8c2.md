---
id: "b29dc8c2-4462-4630-b91b-eacec84a1be3"
title: "Blender 三渲二侧栏面板实现：参数分组、脸/眼分流与三个「改了不生效」坑"
description: "在 MMD 角色（清宵，50 材质槽）上把三渲二做成 Blender N 侧栏可调面板的后半段实现记录：tl_panel.py 的运行时注册结构、二分/光位/暗部色/边缘光/描边/整体六组参数与按材质名分流的脸/眼专项，以及 update 回调挂载时机、描边自拷贝 ReferenceError、固有色其实在贴图这三个坑。前半段的节点链与坑表见 92ba49c0。"
status: "active"
created_at: "2026-11-07T15:05:45.551Z"
updated_at: "2026-11-07T15:05:45.551Z"
content_hash: "8b08d65f63ea34a496bc47059fc0aa79fe615b8fc5f43dbdc76f4cee0975c433"
source_paths:
  - "blender/tl_panel.py"
  - "blender/30_register_panel.py"
  - "blender/31_verify.py"
  - "blender/32_diffuse.py"
  - "blender/33_eyetest.py"
  - "blender/34_eye_level.py"
  - "blender/35_final.py"
  - "blender/README.md"
  - "blender/render/24_final.png"
session_ids:
  - "46f880c2-81d5-4d28-8ccc-896857cf20a1"
memory_body_ids:
  []
---

# Blender 三渲二侧栏面板：实现结构与坑

**背景**：`92ba49c0-9d5e-4438-854e-456acc15e864` 记了「批量把 50 个 MMD 材质改成三渲二」的节点链与 8 条坑表，收尾时明确的短板是**脸过曝、眼睛看不见、参数只能改脚本重跑**。用户随后要求「做成可调面板」并提供「1+2」（脸部专项 + 面板），本文只记这一段新增的实现与验证。理论来源仍是 `f3eceb7d-ac36-486f-85d7-887c745c03bb`（脸部阴影必须半兰伯特单独控、描边分层）。

---

## 1. 成品形态：运行时注册的单个 .py

- 全部逻辑收在一个 `blender/tl_panel.py`（约 18 KB，`syntax ok` 自检通过），由 `blender/30_register_panel.py` 送进 Blender 主线程 `exec` 注册。
- 类清单：`TLToonSettings`（挂在 `bpy.types.Scene.tl_toon` 的 `PointerProperty`）、`TL_OT_build` / `TL_OT_apply` / `TL_OT_restore` 三个操作符、`TL_PT_panel`（3D 视图 `N` 侧栏「三渲二」页签）。
- `register()` 对每个类 `try/except ValueError: pass`，所以**重复注册不会炸**；日志里的「bl_idname 'tl.build' 已被注册过，注销先前的」是正常现象，不是错误。
- **这是运行时注册**：关掉 Blender 就没了。要常驻，把 `tl_panel.py` 丢进 `%APPDATA%\Blender Foundation\Blender\5.2\scripts\addons\` 并在偏好设置里启用。

## 2. 参数分组（全部带 `update=_push`，拖动即重算）

| 组 | 控件 |
|---|---|
| 二分 | `ramp_body` 0.52 / `ramp_face` 0.22 / `eye_flat` 眼睛不参与阴影 |
| 虚拟光方向 | `azimuth` 28° / `elevation` 20°（**只挪分界线，不改亮度**） |
| 暗部色 | 皮肤 / 脸部 / 头发 / 布料 / 眼睛 五个色块 |
| 边缘光 | 强度 0.25 / 颜色 |
| 描边 | 开关 / 粗细 0.006 / 颜色 |
| 整体 | 亮度（emission）0.9 / 背景色 |
| 底部 | 已处理材质数 + 「还原原材质」按钮 |

`_push` 是统一回调：任一滑块变动 → 重算全部材质链 → 不需要点「应用」。构建成功后回执形如 `{"panel_registered": true, "ops": [true, true, true], "materials_built": 50, ...}`。

## 3. 脸/眼分流：按材质名前缀分类

`31_verify.py` 实测的分类结果：

| 材质前缀 | 类别 | 对应参数 |
|---|---|---|
| `Face_` | face | `ramp_face` 0.22（压低→脸基本常亮，避开凹陷脏影） |
| `Eye_` | eye | `eye_flat`（不参与阴影） + 眼睛暗部色 |
| `Hair_*` | hair | 头发暗部色 |
| `Cloth_*` | cloth | 布料暗部色 |
| `Down_Skin` | skin | 皮肤暗部色 |

**验证方式（可复用）**：把 `ramp_body` 从 0.52 改成 0.35 →
`Cloth_Dress` 的 `TL_Ramp` 变成 0.35 ✓，同一次操作 `Face_` 的 `TL_Ramp` 仍是 0.22 ✓，再复原回 0.52。一次对照同时证明「实时生效」和「脸是独立一套」。

## 4. 三个坑

### 4.1 `update` 回调必须在类注册**之前**声明
写进 `props(..., update=fn)`（即属性声明时挂上）。注册完成后往 `__dict__` 上补 `update` **无效且不报错**，表现是「滑块拖了没反应」。这是本轮最花时间的一个。

### 4.2 反壳描边不能把自己复制出来的壳选进源
`_ensure_outline()` 找源网格时若把上一版的 `TL_Outline` 也算进来，就变成「先删它、再对它 `copy()`」：

```
ReferenceError: StructRNA of type Object has been removed
  at tl_panel.py:339  outline = mesh_obj.copy()
```

解法：挑源网格时**排除 `TL_` 前缀对象**。凡是「复制自身做效果的脚本」，第二次运行都要防这个。

### 4.3 「发白」不是接线问题，是固有色本来就白
`32_diffuse.py` 扫了全部 50 个材质：**diffuse 全是 (1,1,1)**，ambient 0.753；颜色在贴图里（如 `Alpha_D.png` 平均 ≈ 0.379/0.454/0.582）。这个角色本身白衣白腿，所以「看不出二分」主要是参数问题。给用户的两个手动入口：布料暗部色从 (0.70,0.74,0.88) 压到 (0.55,0.60,0.80)；整体亮度 0.9 → 0.85。

## 5. 眼睛「看不见」的正确结论

做法：**红眼测试**——把 `Eye_` 材质染成纯红渲一帧（`33_eyetest.py` / `22_eyetest.png`），画面里一个红点都没有，但 `34_eye_level.py` 量到 `face_z = 1.655`、相机 `z = 1.68`，且模型刘海很长。

结论：**眼睛几何存在，被刘海 + 相机高度挡住**，不是没渲染、也不是材质坏了。视口里转到平视即可确认。这类「某部件消失」的怀疑，先做**纯色替换测试**判定「有没有被画」，再谈着色。

## 6. 安全与回退（延续前一轮纪律）

- 未保存用户的 `.blend`；新增节点一律 `TL_` 前缀，原 `mmd_shader` 节点原封不动。
- `blender/25_restore.py` 按原顺序还原 50 个材质槽并删 `TL_` 节点；面板底部也有「还原原材质」按钮。
- 流程与坑同步写进工作区 `blender/README.md`（第 89 行版本，已 present 给用户）。

## 7. 还没做（下一轮的抓手）

- **描边分层**：头发细、外轮廓粗 → 需要按材质组拆成两个反壳。
- **眼透 / 虹膜高光**：单独给 `Eye_` 加一层。
- **头发法线**：空物体 + 顶点组，且空物体必须与人物父子绑定。
- 二分线逐材质微调（现在只有 body / face 两档 0.52 / 0.22）。
- 结论口径：参数是「整体基线」，真正的成片是逐材质看图调出来的。
