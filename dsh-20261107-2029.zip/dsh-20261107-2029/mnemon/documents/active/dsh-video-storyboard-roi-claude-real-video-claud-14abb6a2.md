---
id: "14abb6a2-3750-43ec-b629-c2864b91197b"
title: "dsh-video-storyboard 竞品定位与 ROI 路线（对比 claude-real-video / claude-video / screenpipe，2026-11）"
description: "dsh-video-storyboard 与 claude-real-video、claude-video、video-analyzer、screenpipe 的定位对比：增速数据、七条基于源码的优势证据（格子密度即节奏、音频条带与节奏分析、硬字幕 OCR、六工具面、成本纪律、工程完整度、URL 链路）、七条劣势（单出口 DSH、无成品交付物、无说话人分离、无 --why、依赖重、英文触达弱、Apache 署名摩擦），以及按 ROI 排序的三步动作。含源码行号与文件路径。"
status: "active"
created_at: "2026-11-07T08:36:38.964Z"
updated_at: "2026-11-07T08:36:38.964Z"
content_hash: "b33b5a2d26e938a31f9b57230f2824be69648849ec00066620c3333a63391584"
source_paths:
  []
session_ids:
  - "f3cf0aef-efc0-49f9-acef-17545f418654"
memory_body_ids:
  []
---

# dsh-video-storyboard 竞品定位与 ROI 路线

日期：2026-11-07。对象：`dsh-video-storyboard`（作者 SAOS-3624，Apache-2.0）。本机源码 `D:\Users\林先语\Documents\dsh-plugins\dsh-video-storyboard`（本地 0.6.8，HEAD `e01f363`，npm latest 0.6.9，已发 32 个版本）。对比对象：claude-real-video（crv）、claude-video、video-analyzer、screenpipe，并附带同作者的 `dsh-see-now`。相关实现层评估见文档 `41779d84-0c91-41fd-9781-29e62149d40e`（能力边界/成本模型/注册契约），本文只谈**竞争位置与下一步**，不重复其内容。

## 1. 增速而非存量：星数差距不等于质量差距

| 项目 | 星 | 建仓 | 天数 | 日均 |
|---|---|---|---|---|
| claude-video | 20,072 | 2026-04-24 | ~197 | ~102 |
| dsh-see-now（同作者） | 437 | 2026-11-01 | 6 | ~73 |
| **storyboard** | **456** | 2026-10-26 | 12 | **~38** |
| screenpipe | 22,254 | 2024-06-19 | ~870 | ~26 |
| claude-real-video | 2,295 | 2026-06-30 | ~130 | ~18 |
| video-analyzer | 1,614 | 2024-11-10 | ~727 | ~2 |

12 天 456 星、32 个 npm 版本、0 个 open issue。结论：差距的**唯一主因是触达基数**，不是功能质量——这是后面所有 ROI 建议的前提，别把力气花在"再补一个功能"上。

## 2. 强于竞品的地方（均有源码/文件证据）

1. **一格 = 一镜，格子大小 = 切点密度（1/1…1/8）**。crv 的 `--grid` 与 claude-video 都是等大 contact sheet；"看格子大小就知道哪里开始快剪"是本项目独有表达（README 第 44、137 行自述）。
2. **音频结构分析**。`src/storyboard/sheet.js:250 addAudioStrip` 把响度/静音画成条带（`STRIP_SILENCE` 灰带）；`src/storyboard/audio.js:248 rhythmProfile` 用 3–6Hz ÷ 0.5–2Hz 能量比区分**口播 vs 音乐**（`MOD_BAND=[3,6]`，10 支片子实测，由 `test/audio-rhythm.test.mjs` 守住）。竞品对音频只做转录，不做结构判断。
3. **硬字幕 OCR**。`src/ocr_bridge.py` + `src/storyboard/subtitle-strip.js` 能抠烧进画面的字幕；crv 明确承认像素里的字幕检测不到（只认 srt/vtt）。这是真空缺。
4. **工具面 6 个 vs 竞品 1 条 CLI**：`probe`（只读容器头、不花图 token）、`storyboard`、`zoom`（复核某格）、`locate`（按台词找时间点，纯文本不解码帧）、`subtitles`、`help`，外加设置页（`src/index.js:4-7` 的注释即清单）。
5. **成本纪律**。384 token 封顶、`dryRun` 先报价、`scripts/verify-image-tokens.mjs` 实测校验、`tierMap` 可覆盖。crv 只讲"留 26 帧省 token"，无单图预算硬承诺。
6. **工程完整度**。src+bins 67 文件 / 14,417 行 / 43 个测试文件；`bin/doctor.mjs`、`bin/asr-check.mjs`、`scripts/guard-publish.mjs`；三份 README + FAQ + 五分钟入门 + CREDITS/NOTICE。对照 claude-video 215 个 open issue，本项目 0。
7. **URL 链路的工程化**（`src/storyboard/ytdlp.js`）：`discoverYtdlp` 真跑一次 `--version`（残缺安装比不存在更坑）；argv 数组永不经过 shell；cookie 三级来源（显式参数 > env > `~/.dsh/video.json`，因为 DSH 桌面版读不到 `setx` 的环境变量）；"没有 cookie 不再阻断，先探再判断"（早期硬抛被真实使用证伪）。

## 3. 弱于竞品的地方

1. **出口只有 DSH 一个**。crv 一条 `npx skills add` 可进 50+ 宿主；claude-video 吃 Claude 生态。star 差距的根因。
2. **没有"成品交付物"**。crv 产 `SUMMARY.md`（章节 + 时间码 + 屏上文字）并可用 `--kb` 存笔记；本项目只产图 + 清单，摘要要模型现写。用户要"一份能转发/存档的分析"时差这一步。
3. **没有说话人分离**。crv 有 `--speakers`（45MB 本地模型）；访谈/多会议场景只能给出模糊答案。
4. **没有焦点参数**。crv 的 `--why "find the pricing strategy"` 让分析围绕一个问题；本项目有 `strategy`/`tierMap`/`dryRun` 一套调度旋钮，缺"我关心什么"。
5. **依赖最重**：ffmpeg + yt-dlp + Python venv（ASR ~498MB + OCR）。竞品遇原生字幕近乎零依赖。`doctor` 已缓解，但首装仍是劝退点（README 自述"过半反馈不是 bug，是没配 ASR"）。
6. **英文触达弱**。有 `README.en.md`，但 `docs/` 全中文，GitHub 英文关键词命中低——搜 "video storyboard llm" 找不到。
7. **Apache-2.0 署名要求**对二次分发是摩擦（保护版权是对的，代价是 fork 生态变少；v0.5.0 由 MIT 变更）。

## 4. 一句话定位

- crv / claude-video = **一次性视频分析器**：输入链接，输出可引用摘要。轻、跨宿主、英文。
- 本项目 = **可复核的分镜索引**：把 90 分钟压成能引用格号的图，同时说明哪里响、哪里静、哪里是口播、哪里是快剪。重、深、单生态。
- 竞品赢在分发，本项目赢在"信息密度 + 可复核性"，但分发劣势会掩盖该优势。

## 5. 按 ROI 排序的动作

1. **开一个非 DSH 出口**（唯一能把 456 抬到 2k+ 的动作，且不需改核心逻辑）。`package.json` 已把 `plan/scan/segments/sheet/frames/pipeline` 全导出，写库的成本已付：包一个 `npx dsh-video-storyboard` CLI + 一份 agentskills.io 格式 skill，并在 `README.en.md` 首屏提及。
2. **产出一份 `board.md`**（最划算的近期动作）。`src/storyboard/format.js`（63KB）已算齐章节、时间码、台词、LUFS、静音段、节奏标签，只差串成可独立阅读的 Markdown——对位 crv 的 `SUMMARY.md`。
3. **两个小挂点**：`--why`（直接进 prompt 与 tier 选择）；`--speakers`（本机已有 sherpa-onnx，见 `scripts/reference-server-sherpa.py`，加 diarization 模型即可接）。

## 6. 会话中被证伪的前提

上一轮把对比对象错认成 `dsh-see-now`（见你所见，437★）时的结论不适用；本次全部以 storyboard 的 0.6.9 口径重做。另注意 README 描述里的 "audio envelope" 与实现不完全同名：包络在 `audio.js` 是**测量手段**，进图的是 `sheet.js` 的响度/静音**条带**，别对外宣称"把波形画进分镜图"。
