---
id: "8559b1b5-4a02-4f6c-b55c-2c6fa692c1dc"
title: "叠加分析改为路网口径：每个圆先算可达面再求交（overlay-network，2026-11-04）"
description: "commit e02ae6e：叠加分析从「直线圆求交」升级为「多个真实可达面求交」。后端新增 GET /api/poi/overlay-network 与只取几何的 isochroneGeom SQL，在 Java 里逐圆算等时圈后当作 kind='area' 喂回既有 overlay 细分（求交逻辑只留一份）；前端切到新端点、共用 surfaceLayer/networkLayer 同时画多块可达面与路网、面板按可达面面积与重叠度（1 重 141 / 2 重 9）分版统计。含实测数据、ObjectNode.set() 泛型推断坑与「mvn 增量编译假 SUCCESS 必须 clean compile」的教训。承接 5ca9ab7a / b6132b1a / acb716e0。"
status: "active"
created_at: "2026-11-04T10:37:25.543Z"
updated_at: "2026-11-04T10:37:25.543Z"
content_hash: "e287cd9bd48f08f1b8ae3ee8125f9ab2ecb89ce5a9f9c54f08f4bec5211b9401"
source_paths:
  - "serviceAnalysis/BE/src/main/resources/mapper/PoiMapper.xml"
  - "serviceAnalysis/BE/src/main/java/com/dawnivers/be/mapper/PoiMapper.java"
  - "serviceAnalysis/BE/src/main/java/com/dawnivers/be/service/PoiService.java"
  - "serviceAnalysis/BE/src/main/java/com/dawnivers/be/controller/PoiController.java"
  - "serviceAnalysis/FE/src/composables/useBufferAnalysis.js"
  - "serviceAnalysis/FE/src/map/drawing.js"
  - "serviceAnalysis/FE/src/view/mapView.vue"
  - "serviceAnalysis/FE/src/stores/analysis.js"
  - "serviceAnalysis/FE/src/components/OverlayPanel.vue"
session_ids:
  - "e4670498-a1c8-4f6a-9610-3881f5498a8c"
memory_body_ids:
  []
---

# 叠加分析改为路网口径（2026-11-04，commit `e02ae6e`）

> 上一轮的「叠加只叠步行圆 + 矩形/自由绘制整链下线」见
> `b6132b1a-7236-4c27-9669-4353cb74fecb`；等时圈接口的设计依据见
> `5ca9ab7a-f15a-4956-a70a-320314090a89`；800 m / 步行 10 分钟的口径见
> `acb716e0-90da-4a84-a8a3-36a77603a58c`。
> 本文只记录**这一轮新增**的：把每个圆换成真实可达面再求交。

提交：`e02ae6e 20 叠加分析改为路网口径：每个圆先算成真实可达面，再求交。`
规模：**9 文件，+326 / −3**。后端接口已实测通过；GUI 坐标漂移导致界面点击未验成功，手工确认留给用户。

---

## 1. 需求原话与语义升级

用户要求：叠加分析也要显示路网与可达面，**多个区域的路网和路网面同时显示**，
并且**对可达面重叠的点进行统计并分版展示**。

语义因此从「圆求交」变成「可达面求交」：

```
之前：圆A(2.01 km²) ∩ 圆B(2.01) ∩ 圆C(2.01)          ← 直线口径，面积是标称值
现在：可达面A(0.99) ∩ 可达面B(0.88) ∩ 可达面C(0.21)    ← 每个都沿步行网走出来
```

圆只是「点击位置 + 800 m 预算」的操作单元，**统计口径一律用可达面**。
这一点很关键：面板若继续显示 2.01 km²，就是在用直线口径解释路网口径的结果。

## 2. 架构选择：不写巨型 SQL，在 Java 里循环复用既有细分

```
for 每个圆:
    isochroneGeom(lon, lat, radius)  → 可达面 WKT + GeoJSON + 路网骨架
    ↓ 把可达面当作 kind='area' 的普通 WKT
喂给【现有的】overlay SQL（ST_Node + ST_Polygonize 细分、按 deg 分组、数设施）
```

| 做法 | 评价 |
|---|---|
| 新写一条「多圆心等时圈 + 求交」的巨型 SQL | ❌ 求交逻辑出现第二份，改一处漏一处 |
| 每条 SQL 内部再套 `pgr_drivingDistance` | ❌ 与单点等时圈口径容易漂 |
| **逐圆取几何 → 复用 overlay 细分** | ✅ 只有一份求交逻辑；每块几何还能单独返给前端画 |

**代价**：N 次往返。实测 3 个圈 2.6 s，6 个圈估计 5–8 s，前端靠 loading 态兜住。

**新增 SQL 只有 `isochroneGeom`**：只出几何与统计元数据，比完整版少一次 POI 统计。
`PoiMapper.overlay` 那条两百行的细分 SQL **一行未复制、未改动**。

## 3. 后端契约

- 新端点：`GET /api/poi/overlay-network`（控制器增量很小，主要逻辑在 `PoiService.overlayNetwork`）
- 输入仍是若干圆（`id` / `name` / 圆心 / 半径），输出新增 `surfaces[]`：

```jsonc
surfaces: [ { "id":"s1", "name":"...", "areaKm2":0.991, "snapM":62,
              "usedBudgetM":..., "edgeCount":162,
              "surface": {GeoJSON}, "skeleton": {GeoJSON} } ]
```

- 每个面同时带 `areaKm2` / `snapM` / `usedBudgetM` / `edgeCount` / `surface` / `skeleton`：
  前端一块面就能自解释「这是怎么来的」，不必回头查单点接口。
- 少于 2 个圆能走出来可达面时抛 400，文案点明原因：
  `fewer than 2 circles have a reachable network (nearest road may be farther than the budget)`。
  这是真实场景（郊区点最近路网在 1,198 m 外），不是异常。

## 4. 实测数据（3 个相交圆，江汉路一带）

```
HTTP 200   2,638 ms   51 KB
并集   1.922 km²   150 个设施
按重叠度
  1 重  1.768 km²   141 个
  2 重  0.155 km²     9 个

s1 面积 0.991   吸附 62 m   162 段
s2 面积 0.876   吸附 65 m   165 段
s3 面积 0.212   吸附 190 m    50 段
```

**各档相加 = 并集（141 + 9 = 150）**，因为原子面互不相交。这条恒等式是「分版统计」正确性的自检点：
面板里并集设施数与各重叠度档之和**永远相等**；不等就是细分或计数出了问题。

## 5. 前端

| 文件 | 改动 |
|---|---|
| `composables/useBufferAnalysis.js` | 叠加请求切到 `/api/poi/overlay-network` |
| `map/drawing.js` | 新增 `setOverlaySurfaces()`：一次画多块可达面 + 多套路网 |
| `view/mapView.vue` | 接线 `setOverlaySurfaces` |
| `stores/analysis.js` | 合并各 `surfaces` 的面积（面板要用真实可达面积，不是圆面积） |
| `components/OverlayPanel.vue` | 面列表显示可达面积；「按重叠度」一栏带**面积 + 设施数**，即需求要的「分版展示」 |

**图层复用**：叠加的多块可达面与单点多套路网共用 `surfaceLayer` / `networkLayer`（与单点等时圈同一对图层），
互斥清理不会残留。若另开图层组，单点切叠加时必然出现「旧面还在」。

## 6. 两个坑（都可复现）

### 6.1 `ObjectNode.set()` 的泛型推断把链式调用打断

```java
// ❌ javac 报「找不到符号」，静态类型被推成 JsonNode，第二个 .set() 就没有了
node.put("id", id).put("areaKm2", a).set("surface", s).set("skeleton", k);

// ✅ 先落到显式变量，再 set
ObjectNode out = objectMapper.createObjectNode();
out.put("id", id).put("areaKm2", a);
out.set("surface", s);
out.set("skeleton", k);
```

原因：`set()` 声明为 `<T extends JsonNode> T`，链式上下文里没有目标类型可推，退化到上界 `JsonNode`。

### 6.2 `mvn -o compile` 报 BUILD SUCCESS，但跑起来 500

真实现象：接口返回

```
"message": "Unresolved compilation problem: The method set(String, JsonNode) is undefined for the type JsonNode"
```

而 `mvn -o compile` 连续两次 `BUILD SUCCESS`、`target/classes/PoiService.class` 时间戳还更新了。

- 增量编译没有真正重编那个文件（源码 18:32:15 / class 18:32:16，看着像新编译，内容仍是旧的）
- `mvn -q` 还会把编译失败整个吞掉，只剩运行时异常

**排查顺序**：改完 Java 见到"莫名其妙的运行时编译错误"，先 `mvn clean compile` 看真报错，
不要信增量编译的 SUCCESS；需要看报错时别加 `-q`。

> 另有一次与代码无关的失败：提交信息里的双引号把 shell 命令截断，改用把 message 写入文件再 `git commit -F`。
> 这类「提交失败但代码没问题」的误判很费时间。

## 7. 验证边界（诚实记录）

- 后端：`/api/poi/overlay-network` 实测 200、数据自洽（deg 各档相加 = 并集）。
- 前端：`vite build` 通过 + 模块级核对确认「前端调新端点 / drawing 有 setOverlaySurfaces / mapView 已接线 / store 合并 surfaces 面积」四项为真。
- **未做**：浏览器里逐点点击的端到端确认——Windows 窗口被挪动导致截图坐标持续漂移，点击落不到地图上。
  这一条留给用户在界面上按「开叠加 → 连点 3 个相近点 → 看多块可达面 + 按重叠度」验一眼。

## 8. 未做的事（避免后人误以为已有）

- `roadmap.md` 仍停在 F5 时代，本文的 §2.4.16（路网等时圈）与 §2.4.17（叠加路网口径）**尚未写入**。
- 重叠度目前只有 `1 重 / 2 重` 这类按面的覆盖层数；「重叠的点」统计落在各档 `poi` 计数上，
  没有单独的「同一设施被几个面覆盖」明细列表（明细接口仍是展开时才拉的那一份）。
- 6 个圆的耗时未实测，只有 3 圆的 2.6 s 与线性外推。
