---
id: "70a36633-d284-4595-ae45-08eaaabe13a9"
title: "GeoServer 部署打包：裁剪 data_dir 时误删 www/icons 导致灰方块，与容器日志轮转（2026-11-04）"
description: "裁剪 geoserver_data 时误删 www/icons 导致 POI 灰方块的第三条根因、7 项自检脚本、md5 同源验证法，以及 Docker 日志 max-size/max-file 与 GeoServer 自带 RollingFile 冲突的取舍；附 gs-fix 部署纪律。"
status: "active"
created_at: "2026-11-04T12:16:29.542Z"
updated_at: "2026-11-04T12:16:29.542Z"
content_hash: "09aa2839f133f23f137687137d70ec8a171b26798d463da9b45440b5b2edc73e"
source_paths:
  - "serviceAnalysis/deploy/tools/build-geoserver-data.ps1"
  - "serviceAnalysis/deploy/README.md"
  - "serviceAnalysis/deploy/docker-compose.yml"
  - "serviceAnalysis/deploy/geoserver_data/workspaces/wuhan/styles/poi_icons.sld"
  - "serviceAnalysis/deploy/geoserver_data/security/urlchecks.xml"
session_ids:
  - "3975bc41-7ebf-40ee-8bd9-73826c7384fe"
memory_body_ids:
  []
---

# 部署包里少了 www/icons：另一条「图标灰方块」根因

> 与之前两条根因区分开：
> - URL Checks 默认拒绝 → `ba3a2263-3b2e-4fea-b1c5-f202fe57a8c5`
> - 换机器迁移清单 / MVT 前置条件 → `c693a398-0925-4054-925c-3e7113eb3131`
>
> 本文是**第三条、也是最容易复发的一条**：配置全对、规则也放行了，但部署用的 `geoserver_data/` 里**根本没有图标文件**。

## 1. 症状与判据

公网页面 `https://project4.dawnivers.top/` 街区级 POI 全是灰方块，GeoServer 日志**一句不报**。与 URL Checks 那次的指纹一样（静默），但取证路径不同：

| 检查 | 结果 | 结论 |
|---|---|---|
| 服务器 `geoserver_data/www/icons/` 是否存在 | 不存在 | ← 真凶 |
| 本地源目录 `www/icons/` | png + svg 共 9 个文件齐全 | 文件有，没传上去 |
| `security/urlchecks.xml` | 已有 `http://localhost:8080/geoserver/www/.*` 放行 | 规则没问题 |
| `poi` 图层默认样式 | `poi_icons`（FE 也显式写 `STYLES: 'wuhan:poi_icons'`） | 样式没问题 |

**根因**：首次裁剪 GeoServer 数据目录（27MB → 0.35MB）时，把 `www/` 整体当成 demo 数据排除了。该目录里确实有 384KB 的 OpenLayers 示例，但**同一目录下还藏着 4 组图标**（`school/hospital/mall/park` 的 svg+png）。文件缺失时 GeoServer 画占位方块且不报错，所以看起来像「SLD 没生效」。

**教训**：裁剪 `data_dir` 不能按目录名一刀切。`www/` 既是 demo 资源目录又是 ExternalGraphic 的资源根，必须按文件名白名单保留 `www/icons/*`。

## 2. 修复与验证（可复现）

1. 补齐 `geoserver_data/www/icons/`（9 个文件，共 8KB）
2. 重启 GeoServer（`sa_geoserver`），**清掉 GeoTools 的失败图形缓存**——只补文件不重启可能仍画方块
3. 四个 URL 自检：`/geoserver/www/icons/{school,hospital,mall,park}.svg` 全部 `HTTP 200` + `image/svg+xml`
4. 渲染验收：`GetMap` 取一张 POI 瓦片 → 45KB PNG（对照关掉 ExternalGraphic 的纯圆点样式 40KB，量级区分「出图了」vs「几 KB 空图」）
5. **公网链路同源验证**：走 `https://project4.dawnivers.top/geoserver/...` 取同一 bbox，与直连 GeoServer 的结果 **md5 一致**（`d4c376e1a41fd16fe9835d6af88ce97e`），排除「绕过反代」的假阳性
6. 目视确认：蓝学士帽=学校、红十=医院、橙购物袋=商场、绿树=公园

验证后自检四层仍通过：前端 200 / BE up / DB 13 / GeoServer 出图 200。

## 3. 顺带解释：为什么缩小后只剩小圆点（不是 bug）

`poi_icons.sld` 本来就是两档比例尺：

| 规则 | 条件（比例尺分母） | 渲染 |
|---|---|---|
| `overview` | > 50000 | 3px 圆点 |
| school/hospital/mall/park | ≤ 50000 | 36px ExternalGraphic 图标 |
| label | ≤ 12000 | 名称文字 |

所以只有放大到街区级才出图标；概览层的小圆点是设计如此。

## 4. 防复发：`deploy/tools/build-geoserver-data.ps1`

从 `D:\geoserver\data_dir` 生成部署用目录，**内置 7 项自检**（含 `www/icons/school.svg` 这类关键文件），缺文件直接报错、不许部署。`deploy/README.md` §④ 记录了这个坑 + 比例尺规则，排错表新增一行「图标是灰方块」。

> 关键取舍：把「哪些文件必须带」写进脚本自检，而不是靠在文档里叮嘱——裁剪脚本本身才是复发点。

## 5. 另一处隐患：容器日志不轮转

- `logging.xml` 开着 `stdOutLogging: true` → 日志同时进容器 stdout；Docker 默认 `json-file` 驱动**不轮转**，`/var/lib/docker/containers/*/*-json.log` 会无限增长（实测 `sa_geoserver` 已 924KB，数据目录内 `geoserver.log` 346KB 且在长）。
- 先试了宿主机 logrotate（`/etc/logrotate.d/`，`copytruncate`），随后**撤掉**：`DEFAULT_LOGGING.xml` 里 `geoserver.log` 用的是 Log4j2 `RollingFile` appender，**自带轮转**，两套一起上会互相打架。
- 最终方案：只在 `docker-compose.yml` 给四个服务（db/geoserver/backend/web）加 `logging` 锚点 `max-size: 10m / max-file: "3"`，随后 `docker compose config` 校验语法通过。**需要重建容器才生效**，没有动正在演示的环境。

## 6. 部署纪律（务必记住）

整份 `geoserver_data/` 重新上传后，**必须跑 `./deploy.sh gs-fix`**：`datastore.xml` 里的 `crypt1:` 是用本地旧口令加密的，服务器上的库口令已换过，不修就断连。
