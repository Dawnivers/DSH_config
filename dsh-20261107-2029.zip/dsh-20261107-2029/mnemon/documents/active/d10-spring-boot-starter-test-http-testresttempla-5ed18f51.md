---
id: "5ed18f51-1be1-45fb-8d51-ce224ea8ae05"
title: "D10 测试落地：spring-boot-starter-test + 三接口 HTTP 集成测试（TestRestTemplate 而非 MockMvc、psql 独立信源、3 用例绿）"
description: "武汉 GIS 项目 BE 侧第一批自动化测试的完整落地实录：pom 加 spring-boot-starter-test、@SpringBootTest(RANDOM_PORT)+TestRestTemplate 的 seam 选择理由、三个用例的断言与期望值独立信源、容差与 Long/Integer 踩坑、mvn test 实测输出与提交号，以及数据不变才绿的测试库技术债与 404 用例建议。"
status: "active"
created_at: "2026-10-29T08:23:17.180Z"
updated_at: "2026-10-29T08:23:17.180Z"
content_hash: "61cfa049b2f63a99d2728172646cda30a98234401f6564ae45283ed3c0c61377"
source_paths:
  - "BE/pom.xml"
  - "BE/src/test/java/com/dawnivers/be/PoiApiTest.java"
  - "BE/src/main/java/com/dawnivers/be/controller/PoiController.java"
  - "FE/docs/roadmap.md"
session_ids:
  - "b6644b88-e880-4717-940d-970c97a2adda"
memory_body_ids:
  []
---

# D10 测试落地：三接口 HTTP 集成测试

承接 `6dfea3ef-afec-4994-95ba-d6ddd5dbfd60`（D10 coverage 接口 + §7 的测试计划）。那篇只写了**计划**（seam、依赖、用例期望值）；本文是**已落地并跑绿**的实录。前置的整体分层与 profile 密码方案见 `6b85ed40-4278-4e1f-b061-02a6fc74fc95`。

## 1. 结果先看

```
[INFO] Tests run: 3, Failures: 0, Errors: 0, Skipped: 0, Time elapsed: 3.721 s
[INFO] BUILD SUCCESS
```

启动日志里 `The following 1 profile is active: "local"` —— 证明测试确实读 `application-local.properties`、连的是真库 `Spatial`，不是假数据。Tomcat 起在 `port 32379`（随机端口），**没有碰 8094**，所以跑 `mvn test` 前不必停掉手动启的服务。

提交：BE `206c3b2`（`06 spring-boot-starter-test + 三接口 HTTP 集成测试（3 用例绿）`，2 files changed / 74 insertions）；FE `7187541`（接口总览表 + coverage 契约改 adcode + 里程碑补 D5-D10）。BE 前一条 `41516db` 是用户自己提交的 `05 coverage`。

## 2. 依赖：只加一个 test scope

`BE/pom.xml` 的 `<dependencies>` 末尾追加（父 pom 已管版本，不写 version）：

```xml
<dependency>
  <groupId>org.springframework.boot</groupId>
  <artifactId>spring-boot-starter-test</artifactId>
  <scope>test</scope>
</dependency>
```

它带进来 JUnit5 / AssertJ / `TestRestTemplate` / MockMvc / Mockito，本次**只用了前三个里的后两个**（`@Test`、`assertThat`、`TestRestTemplate`）；MockMvc 与 Mockito 没用到（不写桩，连的是真库）。

## 3. seam 为什么是 TestRestTemplate 而不是 MockMvc

| | MockMvc | TestRestTemplate |
|---|---|---|
| 真起 Tomcat | 否 | **是** |
| `@RequestParam` 转换 | 只走一部分 | **完整链路** |
| `ResponseStatusException` → 404 | 要手写断言 | 框架直接给状态码 |
| 可信度 | 中 | **高** |

6 个接口全是 HTTP 语义（状态码、参数绑定、JSON 序列化），MockMvc 会把"参数绑定"这一层替你吃掉，等于测不到最容易出错的那层。

类级形状：

```java
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class PoiApiTest {
    @Autowired private TestRestTemplate rest;
}
```

## 4. 三个用例与"期望值独立信源"

**关键纪律**：每个断言的期望值必须能指向 psql 手工 SQL 的独立输出，不能是"跑一遍代码看它输出啥"。

| 用例 | 断言 | 期望值 | 信源 |
|---|---|---|---|
| `学校周边800米_总数与分类分布对得上` | `count` | 124 | psql `ST_DWithin(...800)` |
| | `byCategory.school` / `park` | 109 / 3 | 同上 |
| | `nearest` 长度 | 5 | 契约：`limit` 默认 5（`PoiController` 默认值 5、上限 50） |
| | `nearest[0].name` | 武汉大学-教1楼 | psql `order by d limit 5` |
| | `nearest[0].distanceM` | 53.0 | 同上 |
| | 四类之和 == `count` | —— | **自洽性**，不依赖外部数值 |
| `覆盖统计_武昌区_密度与分类对得上` | `total` / `areaKm2` / `perKm2` / `park` | 1681 / 100.06 / 16.8 / 119 | psql（`ST_Area` 手算） |
| `poi详情_解放公园_名字与照片数对得上` | `name` / `tel` / `photos.size()` | 解放公园 / 027-82421760 / 3 | psql `where gid=1`、`jsonb_array_length(raw->'photos')` |

第三条额外价值最大：它**测到了 `StringListTypeHandler`**（当初踩 `argument type mismatch` 才写出来的 `photos` 解析），现在被固定住了。

## 5. 断言写法上的两个坑

1. **容差**：`distanceM` 用 `assertThat(x).isCloseTo(53.0, within(0.5))`。`::geography` 是球面近似，SQL 侧与 Java 侧浮点末位会差在第 4 位；写 `isEqualTo(53.0)` 测的是浮点而不是地理。需要 `import static org.assertj.core.api.Assertions.within;`（不在 `Assertions` 类的方法里，静态导入即可）。
2. **`109L` 而不是 `109`**：`byCategory` 是 `Map<String, Long>`，AssertJ 的 `containsEntry` 做 `equals`，`Integer 109` 与 `Long 109L` 不等，报错信息会显示成 "expected: 109 but was: 109"，极易误判。

另：`getForObject` 遇到 404 直接抛异常，要断言状态码必须用 `getForEntity` 拿 `ResponseEntity`。

## 6. 技术债与下一步（D11）

- **只在数据不变时才绿**：三条用例直连 `Spatial`，重跑 ETL 换数据后 124 / 1681 / 3 张照片全会变。两条路：建 `Spatial_test` 灌冻结数据（推荐，但与生产解耦的成本是工作量翻倍）；或把 `isEqualTo` 放宽成范围断言（立刻失去大部分价值，不推荐）。当前**先留着，记为技术债**。
- **错误分支没写进测试**：404（`gid=999999999`、`adcode=999999`）与 400（`adcode=abc`、`radius=9999`）只手工验过。若补，性价比最高的是加一条 404 用例（用 `getForEntity`）。
- D11 主任务仍是 `PoiController.nearby` 的 `lon ∈ [-180,180]` / `lat ∈ [-90,90]` 范围校验（`radius` 已有 `(0,5000]`、`limit` 已有 `(0,50]` 校验）。
- 顺带的环境提醒：Maven 输出 `Nothing to compile - all classes are up to date` 属正常；但若改了代码仍出现这句，说明改动没被编译。

## 7. 相关文档

- `6dfea3ef-afec-4994-95ba-d6ddd5dbfd60` — D10 coverage 接口规格与 §7 测试计划（本文兑现它）
- `6b85ed40-4278-4e1f-b061-02a6fc74fc95` — 三层职责边界与 profile 密码方案（测试连库的前提）
