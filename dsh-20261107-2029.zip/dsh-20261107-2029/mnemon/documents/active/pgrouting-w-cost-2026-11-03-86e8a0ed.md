---
id: "86e8a0ed-6aa3-46c3-bdfd-833910a9724d"
title: "pgRouting 启用 → 步行网导入 → 验收：-W 用法纠错、cost 单位判据与容器化前提（2026-11-03 续）"
description: "承接 1baeb05d 的导入实操续篇：pgRouting 与 PostGIS 是独立扩展且需按库 CREATE EXTENSION、osm2pgrouting 的 -W 是取参选项而非交互提示（改用 PGPASSWORD）、cost 由边长而非 mapconfig 决定因而必须体检单位、最终数据路径 D:\\QGIS\\Test\\Wuhan，以及容器化前必须对齐的三件事（schema/数据不进 git/连接串外部化）与 Docker 官方镜像缺 pgRouting 的初始化方案。"
status: "active"
created_at: "2026-11-03T11:37:25.673Z"
updated_at: "2026-11-03T11:37:25.673Z"
content_hash: "7f803e91afbb86ca7a2d5257e84990c42a6aa32e71b36af587c29a3006aa74a3"
source_paths:
  - "serviceAnalysis/BE/src/main/resources/application.properties"
  - "serviceAnalysis/BE/src/main/resources/application-local.properties"
  - ".gitignore"
session_ids:
  - "03886df3-3076-4d87-952e-efd237e4df0b"
memory_body_ids:
  []
---

# pgRouting 启用 → 步行网导入 → 验收（2026-11-03 续篇）

承接《OSM 路网数据获取 → osm2pgrouting 导入 → 验收：Windows 实操记录》（id `1baeb05d-1168-4e1d-b25a-3a5975f4c857`）与《单点路网等时圈 vs 全城格网》（id `acb716e0-90da-4a84-a8a3-36a77603a58c`）。

**本篇修正旧文档一处错误**：`1baeb05d` 写的「`-W` 交互输入密码」不成立，见第 2 节。旧文档未改动，以本篇为准。

## 1. pgRouting 与 PostGIS 是两个独立扩展（实测状态）

| 项 | 证据 |
|---|---|
| `pg_available_extensions` | `pgrouting 4.0.1 NOT_INSTALLED`、`postgis 3.6.2 3.6.2` |
| 磁盘文件（全局一份） | `D:\PostgreSQL18.4\data\18\share\extension\pgrouting.control`、`pgrouting--4.0.1.sql`、`lib\libpgrouting-4.0.dll`、`bin\osm2pgrouting.exe` |
| PG / PostGIS | PostgreSQL 18.4 (x86_64-windows, msvc-19.44.35226)、PostGIS 3.6 USE_GEOS=1 USE_PROJ=1 |

- PostGIS 不依赖 pgRouting；**pgRouting 依赖 PostGIS**（边表几何）。
- 扩展是**按库启用**：文件在盘上 ≠ 装进某个库。`Spatial` 库需显式 `CREATE EXTENSION IF NOT EXISTS pgrouting;`，重复执行不报错。
- `osm2pgrouting.exe` 是 pgRouting 项目附带的**独立命令行工具**，不是扩展；它建 `walk_ways` 表不依赖 `pgr_*` 函数，但后续 `pgr_connectedComponents` / `pgr_drivingDistance` 依赖，所以扩展要在验收前装。
- 「看起来像自带」是因为 EDB Stack Builder 一体化安装包把扩展文件一次铺到 share/lib。

## 2. ★ `-W` 在 osm2pgrouting 里是取参选项，不是交互提示

实测报错：

```
the required argument for option '--password' is missing
```

| 工具 | `-W` 语义 |
|---|---|
| `psql` | 开关，运行到一半交互提示输密码 |
| `osm2pgrouting` | `-W [ --password ] arg`，**必须跟值**，不会提示 |

推荐做法：**删掉 `-W`，改用 `PGPASSWORD`**（osm2pgrouting 走 libpq，自动读取）：

```powershell
$env:PGPASSWORD = Read-Host 'Postgres password'   # 不回显、不进历史
& "$BIN\osm2pgrouting.exe" -f $PBF -c "$BIN\mapconfig_for_pedestrian.xml" `
  -d Spatial -U postgres -h localhost -p 5432 --clean --prefix walk_ --attributes
```

备选：直接 `-W '密码'`（密码进 `Get-History`，不推荐）；或从 `application-local.properties` 里正则抽 `spring.datasource.password=` 赋给 `$env:PGPASSWORD`（密码不进历史，但路径含中文易粘错）。设过 `PGPASSWORD` 后，同一窗口的 `psql` 也不再问密码。

## 3. 另一个高频坑：PowerShell 变量不跨窗口

报错 `术语 '\osm2pgrouting.exe' 不会被识别` 说明 `$BIN` 是空串——用户在新开的 PowerShell 里直接跑命令，而 `$BIN` 只存在于上一个窗口。**给用户的步骤必须自带变量区 + 自检三行**：

```powershell
$BIN  = 'D:\PostgreSQL18.4\data\18\bin'
$PBF  = 'D:\QGIS\Test\Wuhan\hubei.osm.pbf'
$TMPD = 'D:\QGIS\Test\Wuhan\tmp'
$env:TMP = $TMPD; $env:TEMP = $TMPD; $env:GDAL_TMPDIR = $TMPD
$BIN; Test-Path "$BIN\osm2pgrouting.exe"; $env:TMP    # 第二行必须 True
```

## 4. cost 由边长决定，不由 mapconfig 决定 → 单位必须体检

对比四个配置文件体积（`mapconfig.xml` 2072 B、for_cars 1442、for_bicycles 3140、for_pedestrian 1100），且步行配置里**没有 `way`/`priority` 段**；默认配置的 `ways` 段只有 `highway/cycleway/tracktype/junction` 四个 tag_name 声明、无系数规则。结论：**没有自定义 cost 规则时，`cost` 由 `osm2pgrouting` 按边长算**（`length_m` 与 `cost` 同源），`avg_cost / avg_len_m ≈ 1` 即两者都是米。因此导入后必跑单位体检，别假设。

验收 SQL（贯通链路的三件事）：

```sql
-- 单位
SELECT count(*) edges, round(sum(length_m)/1000) AS total_km,
       round(avg(length_m)::numeric,1) avg_len_m,
       round(avg(cost)::numeric,1) avg_cost FROM walk_ways;
-- 连通性
SELECT component, count(*) FROM pgr_connectedComponents(
  'SELECT gid AS id, source, target, cost, reverse_cost FROM walk_ways')
GROUP BY component ORDER BY 2 DESC LIMIT 5;
-- 步行网构成
SELECT highway, count(*), round(sum(length_m)/1000) FROM walk_ways GROUP BY highway ORDER BY 2 DESC;
```

判据：`avg_len_m` 20–500 m 为正常；最大连通分量占比 >80% 健康、50–80% 等时圈会缺角、<50% 停手查拓扑；`pgr_drivingDistance` 的 `max_agg_cost` 必须 ≤ 预算（800）。

## 5. 最终数据路径与 GDAL 验证

用户把 pbf 搬到 **`D:\QGIS\Test\Wuhan\hubei.osm.pbf`（53.55 MB）**，临时目录 `D:\QGIS\Test\Wuhan\tmp`。

- 路径非 ASCII：无 ✅
- 从新路径读 `lines` 层：**275,840** 条（= highway 非空的线数），无 `Cannot create C:\Users\...` 报错 ✅

即中文路径 + GDAL 是此前那个 `Cannot create` 的直接原因，换纯英文路径即消失。`D:\osm_data` 已不存在，`D:\osm_tmp` 仍存在（早期方案遗留）。

## 6. 容器化的真实结论（回答「Docker 打包后是不是都装好了」）

**不是。** 官方镜像里 PostGIS 有、pgRouting 通常没有：

| 镜像 | PostGIS | pgRouting |
|---|---|---|
| `postgres:18` | ❌ | ❌ |
| `postgis/postgis:18-3.6` | ✅ 扩展文件在 | ❌（部分 tag 捆了，需实测 `ls /usr/share/postgresql/*/extension/pgrouting*`） |
| `pgrouting/pgrouting` | ✅ | ✅ 但版本滞后 |

而且「镜像里有 .so/.control」仍 ≠「库里已 `CREATE EXTENSION`」。方案：
- **A（推荐）** `postgis/postgis` + `docker/initdb/00_extensions.sql`（`CREATE EXTENSION IF NOT EXISTS postgis;` 再 `pgrouting;`，容器**首次**初始化时自动执行）；若那一行失败说明镜像没带。
- **B** 自写 Dockerfile：`FROM postgis/postgis:18-3.6` + `apt-get install postgresql-18-pgrouting`（包名要与 PG 大版本对齐）。

比扩展更容易翻车的三件事：① **数据不在镜像里**（POI、`grid_500m` 39,820 格、16,016 条 POI、`walk_ways`）→ 用 `pg_dump -Fc` 在 initdb 里 `pg_restore`，**不要把 53 MB pbf 塞进 initdb**（每次重建都重跑导入）；② GeoServer 的 5 个 SLD、`poi_icons`、`data_dir`（含 `security/urlchecks.xml` 图钉放行规则）只能挂载，不能重建；③ PG 容器默认 `LANG=C`，中文排序/LIKE 行为可能不同。

## 7. 部署方向不会倒逼本地开发（只有 3 处要现在对齐）

| # | 事项 | 现状 |
|---|---|---|
| 1 | 表放哪个 schema | 全留 `public`，用 `walk_` 前缀区分（拆成 `routing.walk_ways` 会让 8 个接口的 SQL 全要加前缀） |
| 2 | 数据进不进 git | **已做对**：根 `.gitignore` 挡了 `data/`，`git ls-files` 无 `.pbf/.gpkg/.shp`（`data/` 下 121 MB shp.zip + 53 MB pbf 未跟踪）。写 Dockerfile 时要照抄成 `.dockerignore` |
| 3 | 连接串 | **已做对**：`application.properties` 里 `jdbc:postgresql://localhost:5432/Spatial`，密码在 `application-local.properties`；容器化只需换 `localhost` → `db:5432` |

额外一条：**本地路径也用纯英文**，让「本地跑通」才等于「容器里跑通」（容器里中文路径坑自动消失，但本地不消失）。

Docker Desktop 装 D 盘（含 WSL2 发行版迁移）的事已由用户要求写入长期记忆，此处不重复。

## 8. 待办（截至本次截断仍未完成）

1. `CREATE EXTENSION IF NOT EXISTS pgrouting;`（用户尚未确认执行，`installed_version` 仍是 `NOT_INSTALLED`）
2. 用 `PGPASSWORD` 方案跑导入，确认 `Ways processed ≈ 275,840`
3. 跑第 4 节三组验收 SQL，把 `avg_len_m/avg_cost` 与最大连通分量占比贴回
4. Docker 打包方向未定：用户倾向「只做一键起库（C）」再扩到「只容器化数据库（A）」

脚本类工作约定：用户自己敲 SQL/命令，助手只给参数含义、自检方法和判据（见 `acb716e0` 第 7 节）。
