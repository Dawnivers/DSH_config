---
id: "d9648adb-4cce-4305-9989-6c0a78ff8d74"
title: "步行路网入库存量口径：railway 为何进不来、cost 单位、裁剪该在哪做（2026-11-03 结论）"
description: "步行路网入库前的三个口径结论：mapconfig 只认 highway（铁路自动排除）、length_m 为米制可作 cost、裁剪只裁输出不裁输入（视图而非 DELETE）；附 Docker/部署对本地步骤的耦合点。"
status: "active"
created_at: "2026-11-03T11:08:49.673Z"
updated_at: "2026-11-03T11:08:49.673Z"
content_hash: "8a1399e0ecc5f4786a63e5466f5354a5fec1ada5d261a12b4d3908b106851e6d"
source_paths:
  - "serviceAnalysis/BE/src/main/resources/application.properties"
  - "serviceAnalysis/data"
session_ids:
  - "66d05615-3c3f-4d02-b4cf-373422773771"
memory_body_ids:
  []
---

# 步行路网入库：范围口径、cost 单位与裁剪策略

承接 OSM 导入实操记录 `1baeb05d-1168-4e1d-b25a-3a5975f4c857`、武汉 bbox 与 `wuhan_walk.gpkg` 文档 `ae1011f5-62db-4d3c-9f7b-63660a422f96`、800 m 口径与 pgRouting 环境核对 `acb716e0-90da-4a84-a8a3-36a77603a58c`。本篇回答三件在导入前必须定死的事：**该不该清洗铁路、cost 用哪一列、要不要裁到武汉范围**。

## 1. QGIS 的 `lines` 里那些铁路，导入时根本进不来

`D:\PostgreSQL18.4\data\18\bin\mapconfig_for_pedestrian.xml`（1100 字节）全文只有一个 `<tag_name name="highway" id="1">`，**没有任何 `railway` / `waterway` / `building` 项**。实际放行的 `tag_value`：`road / primary / primary_link / secondary / secondary_link / tertiary / tertiary_link / residential / living_street / service / track / pedestrian / services / path / cycleway / footway / bridleway / byway / steps / unclassified`；`trunk`、`trunk_link` 是**被 XML 注释掉的**，`motorway` 压根没列。

| QGIS `lines` 图层里看得到的 | 是否进 `walk_ways` |
|---|---|
| `railway=*`（铁路、地铁） | ❌ 标签不是 highway，不匹配 |
| `waterway=*`（河流） | ❌ |
| `motorway` / `trunk` | ❌（未列 / 被注释） |
| footway / residential / primary / secondary … | ✅ |

根因：**QGIS 的 `lines` 是 OGR OSM 驱动"把所有线状要素都塞进来"的展示层，而 `osm2pgrouting` 是直接解析 pbf 按配置挑路**——两者不是同一条数据通路。所以「铁路要不要清洗」这个问题的答案是**不需要，导入时被配置自然排除**；不必在 QGIS 里做属性过滤，也不必事先删要素。

副作用：真正的风险不是多进来，而是**少进来**——若 `Ways processed` 远低于预期量级（湖北全省步行网约 30–50 万条），说明配置只匹配上一部分标签，要按 `highway` 分组统计核对（见承办文档 4.4 节）。

## 2. `cost` 的单位：`length_m` 是米，别猜

配置里**没有任何 `<cost>` / `<priority>` / `maxspeed` 规则**，所以 cost 由 `osm2pgrouting` 自己从二进制内嵌的建表 SQL 推出。对 `bin` 下的可执行文件做字符串检索，命中：

```sql
length_m = ST_length(geography(geom))
cost_s   = ... ST_length(geography(ST_Transform(geom,4326))) / (maxspeed::float * 5.0/18.0)
```

**关键点是 `geography`**：它按椭球面算，单位是**米**（不是度）。由此：

| 列 | 含义 | 用法 |
|---|---|---|
| `length_m` | 米 | ✅ **推荐**，与已有 `ST_DWithin(..., 800)` 的直线圆完全同口径，对比时唯一变量是"直线 vs 路网" |
| `cost` / `reverse_cost` | 由 `length_m` 派生，步行配置无 `maxspeed` 时量纲不稳定 | 需要"10 分钟"这类时间预算时才用 |

`pgr_drivingDistance` 的第二参数 budget 直接吃这个量纲：`budget = 800` 就是 800 米。

验收判据（导入后一条 SQL）：`avg(length_m)` 落在 20–500 之间即符合米制预期；若 `avg(cost) ≈ avg(length_m)` 说明 cost 也是米，用哪列都行；若两者差一个系数，说明 cost 是秒，坚持用 `length_m`。

## 3. 裁剪：**不在 QGIS 裁，也不建议裁输入**

### 不能在 QGIS 裁（工具链硬约束）
`osm2pgrouting` 只认 `.osm` / `.pbf`，读不了 GPKG / Shapefile。QGIS 裁出来的产物喂不进建图工具。

### 不该裁输入（会伪造断头路）
在边界处切断路网，边界附近的路会变成"假断头路"，等时圈凭空缺一块，且事后分不清是「数据本来就断」还是「我裁断的」。已有结论沿用：省界切片导入后，武汉边界的等时圈会真实伸到孝感/黄冈，属正常现象，README 写明即可。

### 正确做法：**裁输出，不裁输入**
`pgr_drivingDistance` / `pgr_connectedComponents` 的边 SQL 参数本身就是**一条 SQL 字符串**，所以"只算武汉市"= 查询里加 `WHERE`，而不是先建一张裁过的表：

```sql
-- 边 SQL 里过滤（pgr_* 都接受）
'SELECT gid AS id, source, target, length_m AS cost, length_m AS reverse_cost
   FROM walk_ways'
```

需要"武汉版"边表（出图或加速）时，**导入之后在 PG 里用视图**，并**用 `CREATE VIEW` 而不是 `DELETE`**：

```sql
CREATE VIEW walk_ways_wuhan AS
SELECT w.* FROM walk_ways w
JOIN (SELECT ST_Union(geom) AS g FROM admin_area) a ON true
WHERE ST_Intersects(w.the_geom, a.g);
```

理由：`DELETE` 会让节点变孤点，`pgr_drivingDistance` 结果莫名变短，且删了必须重导才能恢复；视图随时可弃。

## 4. 顺带确认的部署耦合（只记会影响本地操作的部分）

- **pgRouting 不是 PostGIS 自带**：两者是平级独立扩展，pgRouting 依赖 PostGIS。安装包把文件铺到 `share\extension\` 和 `lib\` **不等于库里可用**——`pg_available_extensions` 显示 `pgrouting | 4.0.1 | NOT_INSTALLED` 就是这种状态，必须对**每个库**单独 `CREATE EXTENSION IF NOT EXISTS pgrouting`（`Spatial` 库当时 postgis 已装、pgrouting 未装）。同理 `osm2pgrouting.exe` 是独立命令行工具（工具建表，扩展算路），两者缺一不可。
- **Docker 方向对本地开发步骤几乎无影响**（SQL、扩展、导入、图层同一套），但三处现在就要对齐：① 表全留 `public`，用 `walk_` 前缀区分，别拆 `routing.walk_ways`（否则已写好的接口 SQL 全要加前缀）；② 原始数据不进 git（`data/` 已在 `.gitignore`，实测 121 MB `shp.zip` + 53 MB pbf 未被跟踪），`.dockerignore` 要照排；③ 连接串已外部化（`application.properties` + `application-local.properties`），容器里只需把 `localhost` 换成服务名。
- **镜像层面**：`postgis/postgis` 带 PostGIS 但**不保证带 pgRouting**，需要在 `initdb/00_extensions.sql` 里显式 `CREATE EXTENSION`，或自写 Dockerfile `apt-get install postgresql-18-pgrouting`；`/docker-entrypoint-initdb.d` **只在首次初始化时执行**。数据用 `pg_dump -Fc` 还原，不要把 53 MB pbf 塞进 initdb 每次重建都跑一遍导入。
- **Docker Desktop 默认吃 C 盘**：镜像与 WSL 发行版默认落在 `C:\Users\<用户>\AppData\Local\Docker\wsl`，装之前就要改 Disk image location 到 `D:\Docker\wsl`，装完再迁很麻烦（与本机"大文件走 D 盘"的惯例一致）。
- 中文用户名路径坑（`Cannot create C:\Users\???...\osm_tmp_nodes_*`）**在 Linux 容器里自动消失**，这反而说明本地也应统一用纯英文路径，才能保证"本地跑通 = 容器跑通"。
