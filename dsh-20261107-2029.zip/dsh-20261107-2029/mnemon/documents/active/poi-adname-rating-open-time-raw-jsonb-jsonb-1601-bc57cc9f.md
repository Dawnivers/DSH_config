---
id: "bc57cc9f-1539-4461-be68-ff971a2df9ec"
title: "POI 详情字段扩展第一层：adname/rating/open_time 从 raw jsonb 提取、jsonb 同名键类型不一致坑与全表 16016 条零错误验证（2026-10-31）"
description: "PoiDto 由 12 增至 17 字段（adname/businessArea/poiType/rating/openTime）的零配额实现：SQL 正则与 nullif 处理 biz_ext 同名键 string/[] 混型；全表 16016 条逐条走 API 验证零错误且与 SQL 统计一致；前端详情卡加四行并删除 13 区边界反查 60 行；记录 detail 列因 extensions=all 已无价值、EIO 写盘事故教训。关联 2367f33f、1f15e7d4、fcf2dd32。"
status: "active"
created_at: "2026-10-31T03:01:28.151Z"
updated_at: "2026-10-31T03:01:28.151Z"
content_hash: "451cde5625702b9903c9a37617a1c310e597087be28acad9fc891e493a4f4896"
source_paths:
  - "BE/src/main/java/com/dawnivers/be/dto/PoiDto.java"
  - "BE/src/main/resources/mapper/PoiMapper.xml"
  - "FE/src/components/PoiDetailCard.vue"
  - "FE/docs/roadmap.md"
  - "etl/sources/amap.py"
  - "etl/spec.md"
session_ids:
  - "0c17245f-8f5e-419c-bad1-e082eb371e01"
memory_body_ids:
  []
---

# POI 详情字段扩展（第一层，零配额）

承接 `2367f33f-16bf-4bb1-9117-5c2058a830b5`（PoiDto 第 12 字段 adcode、密度倍数）与 `1f15e7d4-0d2b-4c51-84a3-23c019ed1792`（etl/spec.md §3.3 按需补详情设计）、`fcf2dd32-10e1-4183-a8b3-334b4ee039bd`（jsonb→List 的 TypeHandler 方案）。

## 1. 核心结论：`detail` 补详情机制本项目用不上

查库事实（2026-10-31）：

| 列/键 | 情况 |
|---|---|
| `detail` | 16016 条全 NULL |
| `detail_fetched_at` | 0 条有值 |
| `raw->'biz_ext'` | 16016 条全有（100%） |

原因：`etl/sources/amap.py:89` 列表抓取传的是 `extensions: "all"`，高德关键词搜索带该参数即返回详情级数据。
因此 `etl/spec.md` §3.3 设计的「按需补详情」链路（含负缓存、`detail_fetched_at` 判据）**整个可以搁置**，不消耗配额即可拿到 rating/open_time/photos 等字段。
遗留待办：`detail` / `detail_fetched_at` 成了死字段，建议在 `etl/spec.md` 标注「已评估：因 extensions=all 无需使用」，避免以后看到 `detailFetched: false` 困惑。

## 2. 后端：PoiDto 12 → 17 字段

| 字段 | 来源 | 覆盖率 |
|---|---|---|
| `adname` | `raw->>'adname'` | 100% |
| `businessArea` | `raw->>'business_area'` | 100% |
| `poiType` | `raw->>'type'` | 100% |
| `rating` | `raw->'biz_ext'->>'rating'` | 7181 / 16016 ≈ 45% |
| `openTime` | `raw->'biz_ext'->>'open_time'` | 9221 / 16016 ≈ 58% |

### 真正踩到的坑：jsonb 同名键类型不一致

`biz_ext` 里同一个键有时是字符串、有时是**空数组 `[]`**：

| 键 | string | array `[]` |
|---|---|---|
| `rating` | 7181 | 8835 |
| `open_time` | 9221 | 6795 |

`->>` 对数组返回字符串 `"[]"`，直接 `::float8` 必然 `invalid input syntax`。SQL 兜底（`BE/src/main/resources/mapper/PoiMapper.xml`）：

```sql
case when raw->'biz_ext'->>'rating' ~ '^[0-9]+(\.[0-9]+)?$'
     then (raw->'biz_ext'->>'rating')::float8 end      as rating,
nullif(nullif(raw->'biz_ext'->>'open_time','[]'),'')   as open_time
```

**教训：这类稀疏脏数据只抽 3 条测试必然漏掉** —— 抽到有值的 45% 就全绿。

## 3. 前端：详情卡 6 行 → 11 行

`FE/src/components/PoiDetailCard.vue`：

- 新增「商圈」「评分 ★」「营业时间」「类型」四行；评分有值渲染橙色数字（`.rating`）+ 金色星（`.star`），无值 `—`。空值判断用 `poi.rating != null`、`show()` 用 `===` 显式判空（不能用 `||`，否则数字 0 被吃掉）。
- 「所属区」改为直接 `poi.adname`。
- **删除 60 行**：`loadAreas()` / `findDistrict()` / 13 区边界 `/api/areas` 反查及其模块级缓存、`district` ref、`districtSeq` 竞态保护、`onScopeDispose`，连带 `GeoJSON`、`fromLonLat`、`ref`、`watch`、`onScopeDispose` 五个 import 清掉。少一个请求、少一次 4326→3857 投影。
- `computed` 导入也是多余的，一并删除。
- 未尽事项：「查看详情」按钮仍无事件，数据已全摊在卡片上，该按钮可能已无必要（待用户决定删除或改作“复制坐标/在高德打开”）。

真实样例（gid=1）：解放公园 → 江岸区 / 永清 / 4.8 / 06:00-22:00 / 风景名胜;公园广场;公园。

## 4. 验证清单（本次最有价值的方法论）

| 验证 | 结果 |
|---|---|
| SQL 全表跑 | ✅ 16016 行无错 |
| **全表 16016 个 gid 逐个走 API** | ✅ **0 条出错**；rating 有值 7181 / null 8835、openTime 有值 9221 / null 6795、adname 16016，与 SQL 期望**完全一致** |
| rating 为 `[]` 的 POI（gid 654/87/93） | ✅ 返回 `null`，不 500 |
| `mvn test`（PoiApiTest） | ✅ 3 用例全绿 |
| `vite build` | ✅ 208 modules transformed，退出码 0 |
| dev server 模块编译 | ✅ PoiDetailCard.vue / App.vue / selection.js 全 200 |

实用技巧：16016 个 gid 拼进命令行会触发 Windows「文件名或扩展名太长」，改为先把 gid 列表写临时文件、脚本读文件，才跑通全量扫描。

## 5. 事故与教训

编辑 `PoiDetailCard.vue` 时出现 `ReplaceFileW EIO (Win32 32)` 写盘失败，文件处于半改状态（import 已删、函数体还在）；随后 `old_string and new_string must differ`、`file changed since it was read` 接连报错。
处理：用 Python 一次性完成删除，之后**每改一步都跑一次 `vite build`** 确认，最终 208 modules / 退出码 0。
教训：单文件大改后必须立即构建验证，不能连续多次编辑后再统一验证。

记录：`FE/docs/roadmap.md` 新增 §4.3，写明「同名键类型不一致」的坑与全表验证数据。
