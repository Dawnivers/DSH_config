---
id: "bb123ac8-c0dd-4e80-b55a-28aff04ec3c3"
title: "本机网络下 Overpass 不可用 vs BBBike 可用：实测端点表 + BBBike 交付物验证 + 665 MB XML 导入运行观测与索引补建（2026-11-03）"
description: "承接 b6e7be56 / 6dbb05cc / 1baeb05d。实测 Overpass 各端点从本机网络全部失败（406/502/超时）、BBBike 200/2.4s 可用；BBBike 实际交付 planet_113.415,29.941_115.359,31.387.osm.gz 解压得同名目录内 665 MB 全要素 XML（generator osmium/1.15.0，bounds 已含缓冲）；导入期用 CPU/内存判活的观测值与阈值；--clean 后不建索引需手动补 source/target/GIST 三条。"
status: "active"
created_at: "2026-11-03T15:00:19.265Z"
updated_at: "2026-11-03T15:00:19.265Z"
content_hash: "7154a425b403a28f764e39d222511e78f2dc3d6d4e520095aec1efcf2ee69f3c"
source_paths:
  - "serviceAnalysis/data"
session_ids:
  - "8f1d445b-e5fa-4aa4-ad47-21485abb68e7"
memory_body_ids:
  []
---

# Overpass 不可用 / BBBike 可用（本机实测）+ BBBike 交付物验证 + 665 MB XML 导入运行观测

承接 `b6e7be56-6c61-4aa2-adba-2f5dcaf43a2c`（PBF→XML 可行路径盘点）、`6dbb05cc-bcfb-49f6-b3d3-dcab56a79723`（osm2pgrouting 3.0.0 只吃 XML）、`1baeb05d-1168-4e1d-b25a-3a5975f4c857`（获取→导入→验收）。本篇只补三件前几篇没有的东西：**本机网络对 Overpass 的可达性实测**、**BBBike 交付物的真实形态**、**665 MB XML 导入过程中的运行观测与索引补建**。

## 1. Overpass 从本机网络走不通（实测端点表）

起因：overpass-turbo 页面报 `Request rejected. (e.g. server not found, request blocked by browser addon, request redirected, internal server errors, etc.)`。逐端点实测后确认不是查询写错：

| 端点 | 结果 | 判读 |
|---|---|---|
| `overpass-api.de`（POST） | 406 Not Acceptable（1.8 s） | 连接通但被拒；加浏览器 UA 改 GET 后 curl 报 HTTP 000，5.1 s 无响应 |
| `overpass-api.de/api/status` | 30 s 超时 | 状态接口都拿不到 |
| `z.overpass-api.de/api/status` | **502**（2.1 s） | 负载均衡端异常 |
| `overpass.kumi.systems` | 30 s 超时 | — |
| `overpass.private.coffee` | 30 s 超时 | — |
| `overpass.osm.jp` | SSL 握手失败（1.0 s） | — |
| `overpass.osm.ch/api/status` | 400（1.9 s） | 路径不对但**链路通** |
| `overpass.openstreetmap.ru` | 11 s 无响应 | 慢/不通 |
| `extract.bbbike.org` | **200（2.4 s）** | ✅ 可用 |
| `download.geofabrik.de/asia/china/hubei.html` | 15 s | 通但慢（53 MB pbf 曾成功下载） |

结论：**不是查询问题，是服务端 502 + 疑似本机代理（Clash Verge 分流）拦截**。POST 能秒回 406、状态页却超时，是典型的拦截特征。

可操作推论：

- 现阶段**不要再反复试 Overpass**，浪费时间；直接走 BBBike。
- 「数据同源」要讲清楚：BBBike 与 Overpass 都以 OSM 主库为准，差别只在**整块裁剪 vs 按条件筛**。真正影响本项目的是：BBBike 给全要素（建筑/水系/POI 都在），Overpass 能只取 `way["highway"]`，体积可能差 10 倍。
- Overpass 一旦恢复，优先用它是更好的选择：查询语句本身可复现（能贴进 README）、可只取 highway、可做多边形/行政区裁剪。BBBike 的 bbox 难以精确复现，且数据新鲜度是排队时的快照（滞后数小时）。

## 2. BBBike 交付物：先确认「文件还是目录」

实际交付 `planet_113.415,29.941_115.359,31.387.osm.gz`（56.63 MB）。解压后**生成一个同名文件夹**，真正的 XML 在文件夹里面：

```
D:\QGIS\Test\Wuhan\planet_113.415,29.941_115.359,31.387.osm\      ← 目录
    planet_113.415,29.941_115.359,31.387.osm                        ← 文件 665.11 MB
```

坑：路径同名导致 `Get-Content` 报 `无法获取内容，因为它是目录`，容易被误判成「文件损坏/为空」（`Get-Item` 报 0 MB）。**验证脚本第一步应先 `Test-Path -PathType Leaf`**。

交付物内容（前 4 行）：

```xml
<?xml version='1.0' encoding='UTF-8'?>
<osm version="0.6" generator="osmium/1.15.0">
  <bounds minlat="29.941" minlon="113.415" maxlat="31.387" maxlon="115.359"/>
  <node id="244075861" version="26" timestamp="2025-09-22T02:34:20Z" ... />
```

要点：

- `generator="osmium/1.15.0"` —— BBBike 后端是 osmium 生成，格式标准，`osm2pgrouting` 的 expat 能正常解析。
- **665 MB 是全要素**（不只是路），XML 相对 pbf 膨胀 5–10 倍是正常现象；`mapconfig_for_pedestrian.xml` 只认 `highway`，其余要素自动跳过，无需手工清洗。
- bounds 已比目标 bbox 略大（113.415–115.359 / 29.941–31.387），边界缓冲天然存在。
- 早前「直接喂 `.gz` 给 osm2pgrouting」的提醒仍成立：它不认压缩包，必须先解压成 `.osm`。

## 3. 导入命令要点（与旧文档的差异）

```powershell
$BIN  = 'D:\PostgreSQL18.4\data\18\bin'
$OSM  = 'D:\QGIS\Test\Wuhan\planet_...\planet_....osm'   # 单引号，路径含逗号与点
$env:PGPASSWORD = Read-Host 'Postgres password'          # 不再用 -W

& "$BIN\osm2pgrouting.exe" -f $OSM -c "$BIN\mapconfig_for_pedestrian.xml" `
  -d Spatial -U postgres -h localhost -p 5432 --clean --prefix walk_ --attributes
```

- **`-W` 与 `PGPASSWORD` 二选一**：设了 `PGPASSWORD` 还加 `-W` 会报 `required argument for option '--password' is missing`。
- `--clean` 会先删表，**且不建索引**（配置摘要显示 `Don't create indexes`）。
- 临时目录必须纯 ASCII：`$env:TMP = $env:TEMP = $env:GDAL_TMPDIR = 'D:\QGIS\Test\Wuhan\tmp'`（中文用户名会让 GDAL 报 `Cannot create C:\Users\??????\...`）。

## 4. 导入卡在 `Parsing data` 时怎么判活

665 MB XML + expat 单线程，窗口长时间不刷新是**正常**的。判活看进程而非输出：

```powershell
$p = Get-Process osm2pgrouting -ErrorAction SilentlyContinue
if ($p) { "CPU: $([math]::Round($p.CPU,1)) s   内存: $([math]::Round($p.WorkingSet64/1GB,2)) GB" } else { '已结束' }
```

实测观测（本机 31.2 GB 物理内存）：

| 时点 | CPU 累计 | 内存 | 判读 |
|---|---|---|---|
| 运行 38 s | 32.7 s | 3.96 GB | 满速单核 |
| 运行 55 s | 43.6 s（10 s 内 +10 s） | 4.16 GB，10 s 内 **+0 MB** | 节点表已建完，内存**平台期**，不会 OOM |

判据表：

- CPU 累计**在涨** → 在干活，继续等（预计全程 5–20 分钟，之后 `Creating topology` 还要几分钟）。
- CPU 不动且内存不变 → 可能卡住。
- 进程消失 → 已结束，去看原窗口末行 `Ways processed` / `Vertices processed`。

**内存稳定在 4 GB 左右是健康信号**，不必因为「4 GB」就担心爆内存；真正该看的是它是否停止增长。

## 5. 导入后补索引（`--clean` 不建索引的后果）

不建索引时 `pgr_drivingDistance` 能跑但慢，`pgr_connectedComponents` 这类全图查询明显更慢。验收通过后补：

```sql
CREATE INDEX IF NOT EXISTS idx_walk_ways_source ON walk_ways (source);
CREATE INDEX IF NOT EXISTS idx_walk_ways_target ON walk_ways (target);
CREATE INDEX IF NOT EXISTS idx_walk_ways_geom   ON walk_ways USING GIST (the_geom);
ANALYZE walk_ways;
```

## 6. 仍待确认的两个数（决定后续实现）

验收 SQL 落在 `D:\QGIS\Test\Wuhan\verify_walk.sql`（7 段，每段带合格标准）。其中两条是分水岭：

1. `avg_len_m` 的单位——是米还是度，决定后续用 `length_m` 还是先换列。
2. 最大连通分量占比——决定这份数据能否直接用于等时圈。

这两条过了，才可以写第一个等时圈接口。
