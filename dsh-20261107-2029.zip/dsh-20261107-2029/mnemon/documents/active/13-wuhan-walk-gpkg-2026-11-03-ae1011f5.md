---
id: "ae1011f5-62db-4d3c-9f7b-63660a422f96"
title: "武汉研究区外接矩形（含 13 分区明细）与步行路网导出物 wuhan_walk.gpkg（2026-11-03 实测）"
description: "从 Spatial 库 admin_area 实测的武汉整体外接矩形坐标（可直接用于裁剪/地图初始化）、13 个分区各自 bbox、bbox 面积 20407 km² vs 各区面积和 8575 km² 的结论（bbox 不能替代市域），以及从湖北 pbf 裁出的 QGIS 可视化用 wuhan_walk.gpkg（87237 条线，无拓扑）。OSM 导入链路见文档 1baeb05d。"
status: "active"
created_at: "2026-11-03T08:38:58.233Z"
updated_at: "2026-11-03T08:38:58.233Z"
content_hash: "ed5005d42c210fff3166999e79dacda86de751934d8a1482fe544dc33bcb8818"
source_paths:
  - "serviceAnalysis/data"
  - "serviceAnalysis/BE/src/main/resources/mapper/AreaMapper.xml"
  - "serviceAnalysis/BE/src/main/resources/application.properties"
session_ids:
  - "09159584-2621-4d41-9b1e-e533885486cf"
memory_body_ids:
  []
---

# 武汉研究区外接矩形与步行路网导出物（2026-11-03 实测）

数据来源：本机 `Spatial` 库（PostgreSQL 18.4 / PostGIS，连接配置见 `serviceAnalysis/BE/src/main/resources/application.properties`），区划表 `admin_area`，全部为 EPSG:4326。
OSM 数据的获取/导入/验收链路见文档 `1baeb05d-1168-4e1d-b25a-3a5975f4c857`，本文只记录**空间范围数字**与**派生导出物**。

## 1. 武汉整体最小外接矩形（WGS84）

```
左下角 (lon_min, lat_min) = (113.696546, 29.971758)
右上角 (lon_max, lat_max) = (115.076846, 31.363321)
```

即 bbox 记法 `113.696546,29.971758,115.076846,31.363321`。这是 13 个区几何并集的 `ST_XMin/YMin/XMax/YMax`，可直接用于地图初始 extent、裁剪窗口、外部数据下载的 bbox 参数。

## 2. 关键结论：bbox 面积是市域面积的 2.4 倍

| 量 | 值 |
|---|---|
| 外接矩形面积（按 4326→geography 近似） | 约 **20,407 km²** |
| 13 个区面积之和（`ST_Area(geom::geography)`） | 约 **8,575 km²** |

武汉是"东西窄、南北长 + 西南—东北斜向"的形态，外接矩形里大部分是空的（含孝感、黄冈、咸宁、鄂州等邻市区域）。
**因此：**
- bbox 只适合当**下载/显示窗口**，**不要**用 bbox 当"武汉市域"做面积统计、裁剪结果落库或写作"研究区面积"。
- 真正裁剪/统计一律用 `admin_area` 的 `ST_Union(geom)` 做 `ST_Intersects` / `ST_Contains`。
- 若必须用矩形做栅格/格网分析，考虑改用**分区并集 + 格网求交**，或对 bbox 做分区掩膜，否则覆盖率分母会偏大 2 倍以上。

## 3. 13 个分区各自 bbox（撑开整体范围的是江夏/新洲/黄陂）

| 区 | xmin | ymin | xmax | ymax |
|---|---|---|---|---|
| 蔡甸区 | 113.6965 | 30.2522 | 114.2224 | 30.6868 |
| 东西湖区 | 113.8889 | 30.5858 | 114.2875 | 30.7891 |
| 汉南区 | 113.7501 | 30.1816 | 114.1186 | 30.3772 |
| 汉阳区 | 114.1193 | 30.4562 | 114.2934 | 30.6066 |
| 洪山区 | 114.1673 | 30.3844 | 114.6359 | 30.6958 |
| 黄陂区 | 114.1515 | 30.6688 | 114.6125 | 31.3633 |
| 江岸区 | 114.2516 | 30.5759 | 114.3972 | 30.7011 |
| 江汉区 | 114.2198 | 30.5660 | 114.2982 | 30.6441 |
| 江夏区 | 114.0311 | 29.9718 | 114.5936 | 30.5360 |
| 硚口区 | 114.1486 | 30.5635 | 114.2794 | 30.6340 |
| 青山区 | 114.3383 | 30.5699 | 114.5576 | 30.6792 |
| 武昌区 | 114.2550 | 30.3368 | 114.4148 | 30.6296 |
| 新洲区 | 114.4675 | 30.5591 | 115.0768 | 31.0395 |

- 北界由**黄陂区 31.3633** 决定，南界由**江夏区 29.9718**、西界由**蔡甸区 113.6965**、东界由**新洲区 115.0768** 决定（整体 bbox 四个角分别来自这四个区）。
- 主城研究（武昌/洪山/江汉/江岸/硚口/汉阳/青山）的窄 bbox 大致是 `113.8889,30.3368,114.6359,30.7891`，做单点等时圈演示只需这一块。
- 现状 `admin_area` 表几何可正常按区统计（13 行），但**对整表做 `GROUP BY` 出整体 bbox 的写法容易触发 `字段 "t.e" 必须出现在 GROUP BY 子句中`**；用子查询先 `ST_Union` 再取 XMin/YMin/XMax/YMax 更稳。

## 4. 派生导出物：`D:\osm_tmp\wuhan_walk.gpkg`（仅供可视化）

为绕开"QGIS 打开湖北全省 pbf 的 `lines`（333,149 条）渲染一两分钟、省尺度下几乎看不见"的问题，从同一 pbf 按武汉 bbox 裁出一份 GPKG：

| 项 | 值 |
|---|---|
| 路径 | `D:\osm_tmp\wuhan_walk.gpkg`（纯 ASCII 目录，见下） |
| 大小 | 29.97 MB |
| 要素数 | **87,237** 条 LineString |
| 范围 | `(113.442879, 29.795648) - (115.190479, 31.596288)` |
| 已剔除 | `motorway` / `trunk` / `construction` / `proposed` 等高速与在建路 |

按 `highway` 分类（前几类）：`unclassified 21654 / service 17118 / residential 13078 / footway 8644 / tertiary 7691 / secondary 5446 / primary 4440 / path 1915 / primary_link 1512 / track 1113 / steps 1113 / secondary_link 960 / cycleway 810 / living_street 602 / tertiary_link 373 / pedestrian 342 / corridor 158 / busway 95 / services 66 / platform 58 / road 43`。
（注意：`service` 与 `unclassified` 占比高，是 OSM 中国区"小区/厂区内部路 + 未分级路"多的典型特征。）

**用途边界**：这份 GPKG 只用来**看**（QGIS 秒开、属性表秒出真要素数）。路口顶点不共享、**没有 `source/target/cost`**，不能直接喂 `pgr_drivingDistance`；拓扑图仍须由 `osm2pgrouting` 读原始 pbf 生成 `walk_ways`。

## 5. 同一 pbf 的图层体量（GDAL/OGR OSM 驱动，湖北全省）

| 图层 | 条数 |
|---|---|
| `points` | 226,227 |
| `lines` | 333,149 |
| `multipolygons` | 254,785 |

- `points` 比 `lines` 少属于**正常**：OGR 的 OSM 驱动只把**独立带标签节点**放进 `points`（POI、路口标记等），构成道路几何的中间节点在装配 `lines` 时才用，不单独成要素。所以"点层只有 22 万"不能当作数据缺失的证据。
- `ogrinfo` 对 pbf 报 `Feature Count: -1` 是**懒统计**，不是 0；QGIS 图层属性里的"要素总数：未知"同理，属性表打开后要等它数完。判据应看"范围是否正确"（108.36,29.03 : 116.14,33.27）和线是否渲染出来，而不是属性表刚打开时的空表。
- `ogrinfo -dialect SQLite` 对 OSM 层不支持 `ST_MaxX/ST_MinX`（`no such function`），按 bbox 过滤要换写法或先导出。

## 6. 环境约束（沿用）

GDAL OSM 驱动读大 pbf 时会把节点索引写到临时目录，**中文用户名路径会被 ANSI 编码成 `??????` 而失败**（`Cannot create C:\Users\??????\AppData\Local\Temp\osm_tmp_nodes_...`）。因此本机统一使用 `D:\osm_tmp` 作临时/输出目录；工程目录 `...\服务设施可达性分析平台\serviceAnalysis\data` 含中文，pbf 与导出物都建议放纯英文短路径。
