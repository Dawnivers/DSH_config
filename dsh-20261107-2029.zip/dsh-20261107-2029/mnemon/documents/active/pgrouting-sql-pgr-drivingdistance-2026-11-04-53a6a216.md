---
id: "53a6a216-38cb-451e-af70-a1b62650fa82"
title: "pgRouting 图查询契约与等时圈 SQL 逐层解析：边表/节点表配合、pgr_drivingDistance 输入输出、边界截断（2026-11-04）"
description: "walk_ways 与 walk_ways_vertices_pgr 如何通过 source/target 配合（in_edges/out_edges 陷阱、JOIN 原型 SQL、为何必须拆两表）、pgr_drivingDistance 那个 SQL 字符串是输入图定义而非输出、必需列名 id/source/target/cost 与可选 reverse_cost 的实测报错、SELECT * 的静默 58 倍错误、返回 5 列与 edge=-1 语义、ST_Collect 用法，以及\"只走完整节点\"导致边界最多少一条边长的截断缺陷与补半截边思路。"
status: "active"
created_at: "2026-11-04T03:02:28.368Z"
updated_at: "2026-11-04T03:02:28.368Z"
content_hash: "45deef6a1ae9452427c0d56626e5df49ecdbdbd3a50288b8326caeeadc26e23b"
source_paths:
  - "serviceAnalysis/data"
session_ids:
  - "fb9feca8-da4d-4203-beb9-32b6643dd2c6"
memory_body_ids:
  []
---

# pgRouting 图查询契约与等时圈 SQL 逐层解析（2026-11-04）

> 承接 `dbd640e1-aa8a-419c-8f48-b7c3e4d6aefe`（walk_ways 表结构、cost 单位是度的坑、连通性验收）
> 与 `acb716e0-90da-4a84-a8a3-36a77603a58c`（等时圈口径）。本文只补那两篇未展开的部分：
> **两张表怎么配合、`pgr_drivingDistance` 那个 SQL 字符串到底是什么、结果怎么读、边界为什么被截断。**

## 1. 本次导入产生的表（实测，2026-11-04）

| 表 | 行数 | 大小 | 角色 |
|---|---|---|---|
| `walk_ways` | 241,611 | 106 MB | 边表，每行一个路段 |
| `walk_ways_vertices_pgr` | 183,396 | 377 MB | 节点表，每个路口/端点 |
| `configuration` | 20 | 48 kB | 字典：`tag_id` → `tag_key/tag_value` |
| `walk_pointsofinterest` | **0** | 32 kB | POI 表，本次为空 |

- `osm_nodes / osm_ways / osm_relations` **没有建**——那是 `--addnodes` 才生成的原始 OSM 表。
- `walk_pointsofinterest` 为空是因为 `mapconfig_for_pedestrian.xml` 里只有 `<tag_name name="highway">`、没有任何 `<poi>` 规则；
  项目自己的 POI 在独立的 `poi` 表（16,016 条高德数据），**这张空表不影响等时圈**。
- `walk_ways` 里**没有 `highway` 列**，只有数字 `tag_id`；字符串要 `JOIN configuration c ON c.tag_id = w.tag_id` 才有。
  （早期误以为数据库原生有 highway，实际全部来自 this join。）

## 2. 两张表怎么配合

`source` / `target` 存的是 **`walk_ways_vertices_pgr.id`**，不是 `osm_id`，也不是坐标。

```sql
-- 一条边 + 两端节点
SELECT w.id, w.source, w.target, w.length_m,
       s.x AS src_lon, s.y AS src_lat, t.x AS tgt_lon, t.y AS tgt_lat
FROM walk_ways w
JOIN walk_ways_vertices_pgr s ON s.id = w.source
JOIN walk_ways_vertices_pgr t ON t.id = w.target
WHERE w.id = 1234;
-- 实测：1234 | 5638 | 1148 | 169.0 | 114.27205/30.15632 → 114.27377/30.15655（江夏区）
```

### ★ `in_edges` / `out_edges` 不能当成"全部邻边"

实测节点 `id=88`：`in_edges = {}`、`out_edges = {1818}`，
但实际相连的边有 **2 条**（125 指向它、1818 从它出发）。

**要查全连接必须用 `source = :n OR target = :n`**，不要只读数组列。
`in_edges` 为空只说明它是某条路的源头端点，不代表它是孤点。
（`x`/`y` 是 `geom` 的冗余副本，快速取值可用；空间查询仍须用 `geom` 才吃到 GiST 索引。）

### 为什么必须拆两张表

图 G=(V,E)：路口若按边重复存储，一个 5 叉路口会有 5 份坐标副本，改一处漏一处就断网，且
Dijkstra「从节点找邻居」需要节点是独立实体。拆开后每步走 `walk_ways.source/target` 索引（已自动建好）。

## 3. ★ 那个 SQL 字符串是「输入」，不是「输出」

```sql
pgr_drivingDistance(
  'SELECT id, source, target, length_m AS cost, length_m AS reverse_cost FROM walk_ways', -- 输入：图
  26086, -- 起点节点 id
  800,   -- 预算（米）
  false  -- 无向
)
-- → 输出只有 5 列：seq, node, edge, cost, agg_cost
```

PostgreSQL 函数不能"接收一张表"，pgRouting 需要游标去逐行迭代图数据，游标由这段 SQL 文本现造：
`OPEN cursor FOR '...'; FETCH`。所以列名是**函数内部按名字找的**，实测证据：

| 实验 | 结果 |
|---|---|
| `'SELECT id, source, target, length_m FROM walk_ways'`（缺 cost） | ❌ `Column 'cost' not Found` |
| 列名全改别名（`id AS foo ...`，位置对） | ❌ `Column 'id' not Found`（按名字，不看位置） |
| 不存在的表 | ❌ `关系 "no_such_table" 不存在` |
| 4 列、带 cost、**不带** reverse_cost | ✅ 2,984 行（reverse_cost 省略时等于 cost） |
| `'SELECT * FROM walk_ways'` | ⚠️ **能跑但结果错**（见下） |

**`length_m AS cost` 不是在改名，是在改口径**：`walk_ways.cost` 单位是度（179 m → 0.00186），
`length_m` 是米。用字符串而非表名的好处就是口径可在此处替换而不用改表：
过滤子集 / 步速加权 `length_m / 1.2 AS cost` / 换视图 / 换数据集。

### ★ 最危险的静默错误

```
SELECT *  ：175,233 行，max_agg_cost = 2.6
正确写法  ：  2,984 行，max_agg_cost = 799.6
```

`SELECT *` 恰好带出 `id/source/target/cost/reverse_cost` 五个列名，**函数不报错**，
但 `cost` 是度 → 预算 800「度」≈ 88,800 km → 把整个连通分量（正等于主连通分量 175,233 节点）全吞了。
不报错、有结果、数字规整，但完全不是要的东西。**永远显式写五列，不要 `SELECT *`。**

## 4. 输出 5 列怎么读 + edge = -1

```
seq |  node  |  edge  | cost | agg_cost
 1  | 26086  |   -1   |  0.0 |   0.0     ← 起点自身，没有"来路"
 2  | 147705 | 179944 | 33.4 |  33.4
 3  | 167028 | 214183 |  4.7 |  38.0
 5  | 18631  | 27773  | 45.4 |  45.4     ← agg_cost 会因分支回退，不是单调列
```

**一行 = 一个被走到的节点**，`edge` 是"怎么走到它的那条边"，`agg_cost` 才是预算累加。

- `JOIN walk_ways w ON w.id = dd.edge` 会把"边号"翻译成几何，**同时自动丢掉 `edge = -1`**（表里没有 id=-1）。
  实测：原始 2,984 行 → JOIN 后 2,983 行（2,983 个不同 edge，无重复）。
- `WHERE dd.edge <> -1` 在 INNER JOIN 下**是冗余的防御性写法**；换 `LEFT JOIN` 时则**必需**，
  否则多出一行 `geom = NULL`。建议保留：读代码的人一眼知道起点已被排除。
- `ST_Collect` 打包 2,983 条 LINESTRING → 1 个 `MULTILINESTRING`，返回类型实测即 MULTILINESTRING。
  这里用 `ST_Collect` 而非 `ST_Union` 是对的（只需打包，不需处理相交、更快）；之后 `ST_Buffer(...,25)` 出面。

## 5. ★ 边界被截断：`pgr_drivingDistance` 只返回"完整走到"的节点

实测最远 3 个节点的邻边全部被丢：

```
节点 19469：已走 799.6 m，邻边 214721(13.0 m) → 812.6 m > 800 → DROP
                           邻边 193152(79.0 m) → 878.6 m → DROP
                           邻边  10911(181.5 m)→ 981.1 m → DROP
节点 136819：799.4 m，邻边 4.3 / 23.4 / 101.2 m 全 DROP
节点 165219：799.3 m，邻边 7.6 / 11.9 / 25.3 m 全 DROP
```

后果：几何停在最后一个完整节点（≈799.x m），**少画最多一条边长**。
本数据平均边长约 12–20 m 可忽略；郊区平均边长 200 m 时半径误差可达 25%。

补半截边思路（骨架，需注意两个坑）：

```sql
WITH dd AS (...),                                        -- WHERE edge <> -1
reach AS (SELECT w.*, dd.agg_cost FROM dd JOIN walk_ways w ON w.id = dd.edge),
partial AS (
  SELECT ST_LineSubstring(w.geom, 0, LEAST(1, (800 - r.agg_cost) / w.length_m)) AS geom
  FROM reach r JOIN walk_ways w ON (w.source = r.node OR w.target = r.node)
  WHERE r.agg_cost + w.length_m > 800
)
SELECT ST_Collect(geom) FROM (SELECT geom FROM reach UNION ALL SELECT geom FROM partial) t;
```

- 坑 1：`ST_LineSubstring` 第三参是**比例 0–1**，不是米；分母用 `length_m`。
- 坑 2：切的方向要与实际行走方向一致，否则切错头（`source` 端 vs `target` 端）。

## 6. 其它必须记住的坑

- **`source`/`target` 指 `vertices_pgr.id`，不是 `osm_id`**（`osm_id` 是 OSM 原始编号）。
- **边的方向 ≠ 单行**：`source→target` 是几何方向；步行一律传 `false`（无向）。
  传 `true` 只能顺向走，反向路断掉；有向/无向结果通常差 1.5–2 倍，若相等反而可疑。
- 孤立节点存在（连通分量 95.55% 指的是主分量）。孤立点不影响等时圈（走不到就不出现），
  但"183,396 个节点"这个总数偏乐观。
- `pgr_dijkstra` 渲染路线时 `LEFT JOIN` 是必须的：最后一行 `edge = -1`（到达终点），
  INNER JOIN 会把终点那一截丢掉。
- **psql/PowerShell 实测小坑**：SQL 里用中文别名会触发 `无效的 "UTF8" 编码字节顺序`，
  一律改用 ASCII 别名；`$r.Trim()` 在 `[System.Management.Automation.ErrorRecord]` 上报方法不存在，
  批量循环里要先 `($r | Out-String).Trim()`，否则一个不存在的表就把整个盘点脚本打断。
