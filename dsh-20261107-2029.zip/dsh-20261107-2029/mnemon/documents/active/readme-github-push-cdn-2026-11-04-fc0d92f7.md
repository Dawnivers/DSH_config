---
id: "fc0d92f7-2ac2-48f2-a429-3e2595132cc1"
title: "项目发布收尾与线上核验：README 实测截图入档、GitHub push 与 CDN 缓存陷阱（2026-11-04 完工）"
description: "ServiceAvailable 完工发布流程：提交前清理工作区垃圾改动、截图像素/体积压缩口径、push 遇 GitHub 500 的处理、以及「用 GitHub Contents API 而非 raw.githubusercontent 核对线上 README」的实测教训；附完工规模数据与 D20 遗留项。"
status: "active"
created_at: "2026-11-04T11:14:14.486Z"
updated_at: "2026-11-04T11:14:14.486Z"
content_hash: "99bb08ddb0ad2af62cb4cda5ab3f030b942711bb1ff611d140e4923f29f08714"
source_paths:
  - "serviceAnalysis/README.md"
  - "serviceAnalysis/FE/docs/roadmap.md"
  - "serviceAnalysis/FE/docs/img"
  - "serviceAnalysis/BE/pom.xml"
session_ids:
  - "92edeec0-573a-43cc-b7e3-ec3dcc35acb8"
memory_body_ids:
  []
---

# 项目发布收尾与线上核验（ServiceAvailable，2026-11-04 完工）

> 承接三篇实现类文档：项目设计 `266aea70-7a25-4d94-8359-39555b8b651f`、
> 等时圈接口 `5ca9ab7a-f15a-4956-a70a-320314090a89`、
> 叠加改路网口径 `8559b1b5-4a02-4f6c-b55c-2c6fa692c1dc`。
> 本文只记**发布这一环**：README 证据图入档、提交前清理、推送、线上核验。
> 仓库：`https://github.com/Dawnivers/ServiceAvailable`，终点提交 `fb7a4a7`。

---

## 1. 实测截图入档：先压，再引用

两张 README 证据图都是真实运行帧，从 PNG 压成 JPEG 后入库（原图 1.2–1.6 MB → 192–244 KB）：

| 文件 | 原始 | 入档 | 参数 |
|---|---|---|---|
| `FE/docs/img/overlay-network.jpg` | 1.2 MB PNG | 244 KB（1400×781） | 宽 1400，质量 86 |
| `FE/docs/img/isochrone.jpg` | 1.6 MB PNG | 192 KB（1400×523） | 宽 1400，质量 86 |

取舍理由：仓库里放 1 MB+ 的图会拖慢 clone，而 1400 px 宽在 GitHub 渲染宽度下肉眼无差别。
**与仓库里 `preview-*.png`（设计稿）要区分开**：实测帧的图注必须写明统计口径与实测数字
（如「并集 3.44 km² / 103 个、1 重 96 + 2 重 7 = 103、耗时 2800 ms」），否则读者无法判断这是不是真的跑过。

配套的 README 写法：接口小节 = 语义一句话 + 关键实现取舍 + **一张实测图 + 一张直线/路网对照表**，
数字全部可回溯到 SQL 实测（例：汉口清潭公园 800 m，圆 2.01 km²/38 个 ↔ 可达面 0.80 km²/23 个，吸附 52 m）。

## 2. 提交前必须过一遍「脏改动」

推送前 `git status` 出现两处**非本次意图**的脏 hunk，均来自此前调试残留，直接 `git checkout --` 还原：

| 文件 | 脏在哪 |
|---|---|
| `BE/pom.xml` | XML 注释里混进一行 shell：`& 'D:\maven\bin\mvn.cmd' -q spring-boot:run` |
| `FE/src/map/probe.js` | `try` 块里多了一个空行 |

同时**保留用户真实改动**：`FE/src/components/AnalysisResult.vue` 标题改为「直线可达性分析结果」，
与 `ReachPanel`（路网口径）成对，一眼分得清口径——这类命名区分属于产品语义，不该当噪音回滚。

## 3. 推送

流程：`git remote -v` → ahead/behind（`## main...origin/main [ahead 7]`）→ 提交 → push → 再核 ahead/behind 应为 `0 0`、工作区干净。

- 本次共 8 个提交一次推上（18–23 六个功能/修复提交 + 两份 docs）。
- **首次 push 遇 `remote: Internal Server Error` + `! [remote rejected] main -> main`（exit 1）**：
  这是 GitHub 侧抖动，等约 8 秒重试即成功（`3a5f141..a0acd0c`）。**不要因此改代码或 force push。**

## 4. ★ 线上核验：别用 raw.githubusercontent

推送成功后核对线上 README，出现一次**误判**：

```
commits API 显示 fb7a4a7 已在 main        ✅
raw.githubusercontent.com/.../README.md   ❌ 不含 isochrone.jpg / 清潭公园
```

根因：`raw.githubusercontent.com` 有 CDN 缓存，新路径图片立刻 200，**老路径 README 仍是旧对象**；
加 `?v=` cache buster 也不保证生效（CDN key 含查询串但仍可能命中旧缓存）。

**权威做法**：走 Contents API 取原文 —

```
GET https://api.github.com/repos/<owner>/<repo>/contents/README.md?ref=main
Header: Accept: application/vnd.github.raw
```

实测返回 13275 bytes，`isochrone.jpg`、`清潭公园`、`overlay-network.jpg` 全部命中，与本地 HEAD 一致。
（注：当时用 PowerShell 解 base64 报「找不到 FromBase64String 的参数计数为 2 的重载」，
所以更省事的是直接加 `Accept: application/vnd.github.raw` 拿明文，不做 base64 解码。）

## 5. 完工规模（`git rev-list` 实测，非估算）

| 项 | 值 |
|---|---|
| 提交 | 65 个，`dc16ba9`(2026-10-24) → `fb7a4a7`(2026-11-04)，12 个活跃日 |
| 代码 | 11,179 行（FE `FE/src` 8,846 / BE `BE/src` 1,851 / SQL 482），FE 34 文件、BE 25 文件 |
| 接口 | 10 个（含 `GET /api/poi/isochrone`、`POST /api/poi/overlay-network`） |
| 文档 | `FE/docs/roadmap.md` 2,711 行 + `README.md` 254 行 + 14 张截图 |
| 数据 | POI 16,016 / 格网 39,820 / 步行网 241,611 边，主连通分量 95.55% |

**D19–D20 遗留**：README、14 张截图、代码与远端全部就绪；**30 秒演示录屏尚未录**
（已给 5 段脚本：全市视图→热力图切换→点选等时圈→叠加 3 点→导出 CSV），
roadmap 的 D19–D20 行已同步为「录屏 ❌」。
