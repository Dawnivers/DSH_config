---
id: "b0122682-e16e-45ff-b016-93a348f4ef9e"
title: "G2 完成：wuhan:grid_500m 的 grid_total SLD（7 档 rule + REST 发布/更新命令 + 三个渲染坑：fill-opacity=0 不等于透明、stroke-width=0 仍描边、最高档必须拆）"
description: "格网热力图样式的实施记录：styles/grid_total.sld 的 7 条 Rule 分档与实测格子数、YlOrRd 配色与 0.78 填充透明度、Rule 只写 Filter 不写 Symbolizer 才真透明、必须整体删 <Stroke> 而非设宽 0、≥10 一档在市中心过饱和需在 25 处再拆、工作区级样式命名约定、SLD 上传 POST 与改样式 PUT 的 REST 命令及图层 defaultStyle 绑定、三条看图验收判据，以及 G3 四个分类样式的换字段指引。承接 G1 文档 02506967。"
status: "active"
created_at: "2026-11-01T09:07:01.376Z"
updated_at: "2026-11-01T09:07:01.376Z"
content_hash: "3d9a1b9f9776b78588e32c8d3a1087c4f40ca5606da3cae71beaf9cfd5ade495"
source_paths:
  - "styles/grid_total.sld"
  - "styles/poi_by_category.sld"
  - "FE/docs/roadmap.md"
  - "FE/docs/img/grid-heatmap-city.png"
  - "FE/docs/img/grid-heatmap-zoom.png"
session_ids:
  - "97a06fe7-3986-4758-bf76-06b10be800fb"
memory_body_ids:
  []
---

# G2：`grid_total` SLD 与三个渲染坑

承接 G1 发布文档 `02506967-ac28-421f-886e-e0cc13e39d9f`（图层 `wuhan:grid_500m` 发布、默认几何取 `geom`）与后端口径 `78d9ef59-2a33-4d23-acd5-69e269678eac`（`r_*` 相对倍数）。本篇记录 **G2：为格网图层写 SLD 并上线**。多几何列规则另见 `6c405b1e-c8cb-4ed3-b4c7-032caf043b73`。

## 1. 产物

| 项 | 值 |
|---|---|
| 文件 | `styles/grid_total.sld`（XML 1.0 / UTF-8，中文注释，`<NamedLayer>` 名 = 样式名） |
| 样式名 | `wuhan:grid_total`（**工作区级**，不在全局样式列表里） |
| 绑定 | `wuhan:grid_500m` 的 `defaultStyle` |
| 渲染图 | `FE/docs/img/grid-heatmap-city.png`（900×700 全市）、`grid-heatmap-zoom.png`（800×640 街区级） |

`styles/` 既有约定：每个图层一个 `.sld`，`<?xml?>` + 中文头注释说明「可调的三处」，`<NamedLayer><Name>` 与文件名同名。新文件照此写即可，参照 `styles/poi_by_category.sld`。

## 2. 分档设计（7 条 Rule）

阈值沿用 `[0.2, 1, 3, 10]`，最高档再拆一刀（见坑 3）：

| Rule | 条件 | 颜色 | 全市格子数 |
|---|---|---|---|
| `no_data` | `r_total IS NULL` | 不画 | 0（防御性） |
| `band1_none` | `< 0.2` | 不画 | 26,786（67.3%） |
| `band2_low` | `0.2 – 1` | `#fecc5c` | 6,848 |
| `band3_mid` | `1 – 3` | `#fd8d3c` | 2,867 |
| `band4_high` | `3 – 10` | `#f03b20` | 2,145 |
| `band5_extreme` | `10 – 25` | `#bd0026` | 1,056 |
| `band6_core` | `≥ 25` | `#67000d` | 118 |

- 配色：ColorBrewer **YlOrRd**（顺序型数据）。
- 填充透明度 **0.78**，让天地图底图透出来。
- 分级用**顺序 `<Rule>` + 各自 `<ogc:Filter>`**，**不要用 `<ColorMap>`**（那是栅格专用）。

## 3. 三个坑（按踩到的顺序）

### 坑 1：`fill-opacity=0` ≠ 透明

第一版空档写成：

```xml
<PolygonSymbolizer>
  <Fill><CssParameter name="fill-opacity">0</CssParameter></Fill>
  <Stroke><CssParameter name="stroke-width">0</CssParameter></Stroke>
</PolygonSymbolizer>
```

结果：**2/3 的地图被灰色网格糊住**。原因——`<Fill>` 里只给 `fill-opacity` 不给 `fill` 色时，GeoServer 回退到**默认灰**填充，opacity 0 落在「已有颜色的照常」之外/被忽略。

**正解：该档 Rule 一个 Symbolizer 都不给。** SLD 允许 Rule 只有 `<ogc:Filter>`，没有 Symbolizer 才真的什么都不画。

```xml
<Rule>
  <Name>band1_none</Name>
  <ogc:Filter>
    <ogc:PropertyIsLessThan>
      <ogc:PropertyName>r_total</ogc:PropertyName><ogc:Literal>0.2</ogc:Literal>
    </ogc:PropertyIsLessThan>
  </ogc:Filter>
</Rule>
```

### 坑 2：`stroke-width=0` 仍会描边

透明生效后，放大到街区级仍见格与格之间有**暗红细线**（0 宽被当成极细线而不是无描边）。

**正解：把整个 `<Stroke>` 元素删掉**，而不是把 width 设 0（本项目里一次找到并删除了 4 处 Stroke 块）。去掉描边后相邻同色格连成一片，才是热力图该有的样子。

### 坑 3（设计层）：最高档会过饱和，必须在 25 处再拆

只保留 `≥10` 一个深红档时，市中心范围内 **437 格里有 301 格（69%）都落在这一档**，渲染成一整片没有层次的深红。

先查该档内部分布再决定切点：`min 10.1 / p25 15.2 / p50 19.7 / p75 28.0 / max 57.0` —— 内部确有梯度，于是在 **25** 处拆成 `10–25`（1,056 格）与 `≥25`（118 格），核心区才浮出来。

**可复用判据**：某一档在某视窗内占比 >60% 且该档内 p50 明显偏离下界（如 19.7 vs 10），就该拆档；拆点取 p25–p50 附近。

## 4. 发布与更新（REST，可复现）

认证用 Basic（GeoServer 自带默认管理账号，口令按本机实际值填，不要写进仓库）。

```powershell
$b = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes("admin:<pwd>"))
$h = @{ Authorization = "Basic $b" }

# ① 首次上传为工作区级样式（注意 ?name= 在工作区地址上）
Invoke-WebRequest "http://localhost:8080/geoserver/rest/workspaces/wuhan/styles?name=grid_total" `
  -Method POST -Headers $h -ContentType "application/vnd.ogc.sld+xml" `
  -Body ([System.IO.File]::ReadAllBytes("<repo>\styles\grid_total.sld"))
# → HTTP 201

# ② 绑定为图层默认样式
Invoke-WebRequest "http://localhost:8080/geoserver/rest/workspaces/wuhan/layers/grid_500m" `
  -Method PUT -Headers $h -ContentType "application/json" `
  -Body '{"layer":{"defaultStyle":{"name":"wuhan:grid_total"}}}'
# → HTTP 200，随后查 .json 应见 defaultStyle = wuhan:grid_total

# ③ 改样式不要重传，PUT 同一地址（本次共改 3 次）
Invoke-WebRequest "http://localhost:8080/geoserver/rest/workspaces/wuhan/styles/grid_total" `
  -Method PUT -Headers $h -ContentType "application/vnd.ogc.sld+xml" -Body (bytes)
```

界面路径（备用）：样式 → 添加新的样式（工作区 `wuhan`、名称 `grid_total`、上传文件）→ 提交 → 验证 → 图层 → `wuhan:grid_500m` → 发布 → 默认样式。

**发布前本地先校验 XML**（本次靠它抓到一个 `<CssParameter>` 漏写 `name=` 的笔误）：解析一遍 XML + 打印每条 Rule 的 Name/Title/fill/opacity 清单，比在 GeoServer 上试错快得多。

## 5. 看图验收三条判据

```
GET http://localhost:8080/geoserver/wuhan/wms?service=WMS&version=1.1.0&request=GetMap
    &layers=wuhan:grid_500m&styles=&bbox=113.70,29.97,115.08,31.36
    &width=900&height=700&srs=EPSG:4326&format=image/png&transparent=true
```

| 看什么 | 通过标准 |
|---|---|
| 郊区 | 大片空白，不是灰块 → 透明生效 |
| 格与格之间 | 无黑/红细线 → 无描边 |
| 市中心 | 有深浅层次（`#bd0026` vs `#67000d`）→ 拆档生效 |

出图前顺手用 SQL 核对视窗内各档格子数（本次 12/17/29/78/301），配比异常说明阈值或字段错了，比盯着图猜快。

## 6. 下一步 G3（未做）

复制 `grid_total.sld`，换字段与色系：

| 样式 | 字段 | 色系 |
|---|---|---|
| `grid_school` | `r_school` | Blues |
| `grid_hospital` | `r_hospital` | Reds |
| `grid_mall` | `r_mall` | YlOrBr |
| `grid_park` | `r_park` | Greens |

⚠️ **公园必须单独定阈值**：`r_park` 零值率 86.9%、max 47.69，直接套 `[0.2,1,3,10,25]` 会一片深绿。其余三类零值率 76.9%–81.6%，可先沿用。

## 7. 文档同步

`FE/docs/roadmap.md` 新增 §2.4.11（1289 → 1367 行），含分档表、三个坑的现象/原因/正解、分类图改法。G1 对应 §2.4.10。
