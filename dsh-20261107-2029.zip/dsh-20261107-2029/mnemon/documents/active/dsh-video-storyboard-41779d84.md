---
id: "41779d84-0c91-41fd-9781-29e62149d40e"
title: "dsh-video-storyboard 视频分镜插件评估：能力边界、成本模型与本机前置条件"
description: "对第三方 DSH 插件 dsh-video-storyboard（v0.6.8）的接入前评估：它把视频转成宫格图+时间码清单以实现「看视频」，含实读到的注册契约（inject 只声明 tools、apply 看门狗、attachments 运行期探测）、成本档位与 token 量级、格式支持=ffmpeg 解复用器范围、三条取源路径与 blob: 死路，以及本机缺 ffmpeg、插件未安装的现实前置。"
status: "active"
created_at: "2026-11-06T10:41:15.110Z"
updated_at: "2026-11-06T10:41:15.110Z"
content_hash: "f6c460b0cc4fa9cfa9f173dd9c00b2be9d679e18fdb8b9612368bdd7e7da6f36"
source_paths:
  []
session_ids:
  - "1b104793-469e-4434-a0f8-8dc6f4f2bfa0"
memory_body_ids:
  []
---

# dsh-video-storyboard 评估：它是否真的增强「看视频」能力

日期：2026-11-06。对象：https://github.com/SAOS-3624/dsh-video-storyboard（Apache-2.0，v0.6.8）。
本文是**接入前评估 + 实现层核实**，不是安装记录；插件当前**未安装**于 desktop / web 任一 profile。

## 1. 结论

- **是质变，但增强的是上下文带宽，不是感知精度**。当前基线：agent 对视频零能力（`modlens` 是读图、`agnes_video_generate` 是生成视频，都不是「看」）。
- 它把视频降采样成「每镜头一张代表帧 + 精确时间码 + evidence.json」，一次视觉调用即可读完数分钟素材。
- **最佳定位：看片第一眼 + 时间点定位**。不适合逐帧辨小字、判断音乐/语气、或对同一素材反复追问（那些场景它自己承认输给 `dsh-video-see` / `watch-skill` / `dsh-video-lens`）。

## 2. 管道（README 描述）

视频文件/URL → ffmpeg 解码、缩到 64×36 逐帧比 HSV（色相环形距离、按饱和度降权）→ 切点检测（自适应该片分数分布 + 爆点窗口逐帧重判）→ 一帧 = 一镜头 → 格子大小 = 该处切点密度（1/1…1/8 八档）→ DP 按行打包成尽量少的方形画布并裁边 → 宫格 PNG + 带时间码文本清单 + `.evidence.json`。

## 3. 实读到的注册契约（源码核实，比 README 可信）

来源：`src/index.js`、`package.json`、`dsh.plugin.json`（raw.githubusercontent.com 直取，v0.6.8）。

- **`inject` 只声明 `['tools']`，不声明 `attachments`**。原因：cordis 的 `inject` 是硬前缀——服务未就绪时 `apply` 根本不被调用，插件永久停在「加载中」，日志无输出，表现为装插件把 DSH 卡死。图片能力改为运行期探测（`src/tools/shared.js` 的 `attachSheetImages`），宿主无 attachments 时降级成纯文本结果，工具照常注册。
- ⚠️ **`dsh.plugin.json` 的 `entry.inject` 仍写着 `["tools","attachments"]`，与 `src/index.js` 不一致**——manifest 与源码漂移，说明这类插件装前必须看源码而非只看清单。
- **`apply` 套 15 秒看门狗**（`APPLY_TIMEOUT_MS`），且异常一律吞掉并返回空 disposer：最坏是插件不能用，不是应用起不来。`DSH_VIDEO_DEBUG=1` 才把错误抛出（否则「静默不工作」难查）。真实事故：`Object.keys(ctx)` 在 cordis 上下文抛错导致整个 DSH 启动崩溃。
- **图片回传路径**：`execute` 返回过 `output.schema` 的规范值，`output.render` 渲染成 ContentBlock[]，图片块为 `{ type:'image', attachment: ImageAttachmentRef }`，ref 必须由 `ctx.attachments.saveImage()` 提交真正编码后的 PNG/JPEG 字节（会解码校验）才拿得到。→ **图是进多模态上下文的，不是给文件路径**；这决定了它「真能用」。
- **一个工具一个文件**（`src/tools/<name>.js`）：宿主管参数走 schema，schema 未声明的参数被静默丢弃，所以 handler 读了哪些 args 必须能与 schema 声明静态对齐（`test/schema-audit.test.mjs`）。
- disposers 必须最先声明（曾因 TDZ 抛 ReferenceError 被 catch 吞掉，工具注册成功但从未登记解绑）。
- 设置页挂 `webServer` 用动态 `ctx.inject`（webServer 可能晚于插件就绪），CLI 宿主则只注册工具。
- `peerDependencies`: `@deepseek-ai/dsh-tools >=0.1.0-rc.7`（optional）；`bin` 三个：`scan-video` / `storyboard` / `doctor`；`engines.node >=20`。
- 同作者的**陪看功能是另一个包 `dsh-watch-together`**（单向依赖本包），不在本包内注册。

## 4. 成本模型（README 报数，未实测）

- 默认 `auto`：约 240 秒一张图 → 3 分钟片约 1 张图 ≈ 233 vision token。
- 同片 `full` 6912 token vs `skim` 384，**差 18 倍**。
- `auto` 成为默认的起因：模型看到枚举第一项是 `full` 就选了它，一条 PV 烧掉 6 倍预算 → 旋钮被收回工具自己。
- `dryRun: true` 只扫描排布、不出图不取帧不转写；扫描有缓存，第二次近乎免费。
- 本地耗时（90s≈8s、5min≈40s、3min≈20–25s）：成本 ∝ 帧数 = 时长 × 帧率，解码是大头，**不是实时播放**，agent 侧不存在「看 3 分钟」。
- **长片贵在张数不在时长**：2.5 小时按 `auto` 约 39 张。

## 5. 能力盲区

- **时间维度：丢运动**。一格 = 一镜头的一张代表帧，镜头内运动不可见；0.3 秒快闪在 1/8 档只有 **100×56**，只够认出换没换镜头。
- **空间下限**：混合档位填充率 79–95%，行内矮格上方必有缝；<约 1% 的画面变化（PPT 多一行字）在 64×36 上不可见。
- **声音全聋**：未配 ASR 只能「看图说话」；配了也只拿到文本，语气/音乐/音效丢失。ASR 成本高（sherpa ≈500MB / funasr ≈2.1GB，需独立 venv）。
- 硬字幕在 URL 模式下本就糊（扫描用 360p 副本，清单会标 `[from the 360p scan copy]`）；本地文件读原片。

## 6. 格式与取源

- **格式 = 你那份 ffmpeg 的解复用器范围**，插件不设白名单：mp4/mkv/mov/avi/webm/flv/ts/m4v/wmv/mts…，编码取决于 ffmpeg 构建。例外只有三类：DRM（设计上不做绕过）、文件损坏不完整、ffmpeg 未编入该编码。
- **取源三条路**：① 本地路径（最优：原片、无下载、字幕清楚）；② http(s) 链接 → yt-dlp 下载（任何 yt-dlp 支持站，需登录喂 `cookies.txt`，但分析用 360p 副本）；③ 兜底下载成本地文件。
- **浏览器桥不是第四条取源路**：桥只给 DOM/文本，拿不到视频像素流，无法「看着标签页播放」。它的真实用途是**找直链**：`browser_snapshot` 看有无 `<video src="https://...">` → 交给 yt-dlp；若 `src` 是 `blob:`（MediaSource 页内拼流）任何外部工具都取不到 → 改喂页面 URL 让 yt-dlp 自己解析，或从 DevTools Network 捞 `.m3u8`/`.mp4`。
- Windows 截屏只能抓**当前单帧**，可做「这一刻画面对不对」，替不了分镜。

## 7. 本机前置条件（2026-11-06 实测）

- `ffmpeg` / `ffprobe`：**未安装** → 硬前提，不装第一步即报错。可用 `node bin/doctor.mjs` 自查。
- `yt-dlp`：有 → `D:\python\Scripts\yt-dlp.exe`。
- `python`：有 → `D:\python\python.exe`（想上 ASR / 硬字幕 OCR 的基础）。
- 插件**未出现在** `C:\Users\林先语\.dsh\profiles\desktop` 与 `...\profiles\web` 的 dependencies / bundles 中。
- 安装路径注意：README 明说 `dsh plugin` 拒绝桌面版 profile，Electron 需 `git clone` + `node scripts/install-dev.mjs`（复制目录，改完要重跑）。**须遵守用户「装东西一律装 D 盘」的既有规则**：ASR venv 与模型权重别落 C 盘，pip 缓存指 `D:\pip-cache`。
- 建议顺序：`winget install Gyan.FFmpeg` → `doctor.mjs` 验证 → 克隆装 desktop profile → 拿真实短视频跑 `dryRun: true` 核对切点数/张数/token 是否符合上表估算 → 再决定要不要上 ASR。

## 8. 待验证项

- 第 4 节的耗时与 token 数字、第 5 节的填充率与尺寸阈值均出自 README，**未在本机实测**。
- README 讲六工具（含 `video_subtitles`、`video_help`），`src/index.js` 顶部注释仍写四个 → 版本与文档可能不同步（0.6.0 曾整批删掉 `cells`/`sheets`/`adaptive` 重写）。
- `dsh.plugin.json` 与 `src/index.js` 的 inject 声明不一致，实际生效行为需装后确认。
