---
id: "1d743c89-19ba-40b7-98db-b3ae722e46d0"
title: "ServiceAvailable 生产上线实录：四容器编排、本地构建产物推送、五个部署坑与线上基线（project4.dawnivers.top）"
description: "武汉公共服务设施可达性分析平台首次生产部署的完整结论：宝塔 v12 + Docker 四容器（pgrouting 18-3.6 / 自建 GeoServer 2.28.5 Jetty / Spring Boot 后端 / nginx 前端）端口收敛到 127.0.0.1、本地构建上传而非服务器编译的理由、五个真实踩坑（PGDATA 路径、GeoServer crypt1 口令、pg_isready 假健康、Windows 可执行位、宝塔 80+443 同 server 块导致跳转死循环）、HTTPS 全链路与真实接口验收基线、4GB swap 与发版脚本要点。"
status: "active"
created_at: "2026-11-04T12:10:10.836Z"
updated_at: "2026-11-04T12:10:10.836Z"
content_hash: "f511c68aadd5d55a2a034f609f32efe4f42ef3483161a57c3388be3f58a0ce92"
source_paths:
  - "serviceAnalysis/deploy/README.md"
  - "serviceAnalysis/deploy/push.ps1"
  - "serviceAnalysis/deploy/docker-compose.yml"
  - "serviceAnalysis/deploy/deploy.sh"
session_ids:
  - "d16941fe-cd5f-465e-bcce-fa4d9c860785"
memory_body_ids:
  []
---

武汉公共服务设施可达性分析平台（ServiceAvailable）于 2026-11-04 首次部署到公网 `https://project4.dawnivers.top`，浏览器实测天地图底图、13 区划面、16,016 POI、500m 格网可达性热力图、图例统计全部正常。本文只记**可复用结论**，不含口令与数据快照。

相关前情：GeoServer 的 REST 脚本化与 Compose 要点见 `be91eaef-f93d-4d77-803d-b34651d1dfd1`；HTTPS/HTTP2 判定与混合内容审计思路见 `b19f41c5-ad92-4a44-b144-984d68cf63ea`。

## 1. 拓扑：四容器 + 一个外部端口

| 容器 | 镜像 | 暴露 |
|---|---|---|
| `sa_db` | `pgrouting/pgrouting:18-3.6-4.0.1` | 仅内部网 `sa_net` |
| `sa_geoserver` | 自建镜像（本地官方 2.28.5 Jetty 发行版） | `127.0.0.1:18080` 仅维护 |
| `sa_backend` | 自建 Spring Boot | 内部 |
| `sa_web` | nginx + `dist` | `127.0.0.1:8088` |

外面由宝塔 nginx 443 反代到 `127.0.0.1:8088`。**宿主机 5432 已被宝塔自带 PG 占用**，这种排布一个端口都不冲突——这是端口方案的约束来源，不是随意选择。

## 2. 两个被迫的工程取舍（理由比结论重要）

**不在服务器编译。** 该服务器出口带宽仅约 0.5 MB/s，但上传约 2.2 MB/s。于是流程定为：本地 `mvn` + `pnpm` 出产物 → `push.ps1` 上传 → 服务器只构建运行镜像 → 跑四层自检。服务器路径 `/www/wwwroot/serviceAnalysis`，发版入口 `deploy/push.ps1`；数据库容器不动，数据不随发版丢失。

**GeoServer 不用官方镜像。** 从 `docker.osgeo.org` 拉 700MB 实测只有 68 KB/s（≈3 小时）；本地 `D:\geoserver` 本就是官方 Jetty 发行版，打包 124MB 上传约 50 秒。拉基础镜像走腾讯云内网源 `mirror.ccs.tencentyun.com`。

## 3. 五个真实踩坑（每条都会静默失败，值得长期复用）

1. **PG18 镜像改了 PGDATA**：数据目录是 `/var/lib/postgresql/18/docker`，沿用旧的挂 `.../data` 会把数据写进容器可写层，重建即丢。
2. **GeoServer 数据源口令不通用**：本地 `data_dir` 里存的是 `crypt1:` 加密串，密钥在 `security/geoserver.jceks`；换强口令后它解不开。正解是走 REST 接口回写连接参数，让 GeoServer 自己重新加密，而不是手改 XML。
3. **`pg_isready` 会假健康**：它走 socket 探测，`pg_restore` 数据还没灌完就报 healthy，导致后端提前启动、连到空库。健康检查必须探到「数据可查询」这一层。
4. **Windows 传递可执行位丢失**：`startup.sh` 进镜像变 644 → `Permission denied`。打包/构建阶段要显式 `chmod +x`。
5. **宝塔 v12 把 `listen 80` 与 `listen 443 ssl` 写在同一个 server 块**：「非 `/.well-known` 就 301」的写法会让 HTTPS 301 到自己 → 死循环。必须按 `$scheme` 判断并放行 ACME 路径：
   ```nginx
   set $hx 0;
   if ($scheme = http) { set $hx 1; }
   if ($request_uri ~ ^/\.well-known/) { set $hx 0; }
   if ($hx = 1) { return 301 https://$host$request_uri; }
   ```
   另注：用宝塔后台部署证书后要确认 443 server 块里的 **反代 include 没被覆盖**（检查 `proxy/project4.dawnivers.top/*.conf` 仍在）。

## 4. 线上基线（后续回归就比这几个数）

| 项 | 值 |
|---|---|
| `/api/poi/nearby` 800m @武大点 | 124 个设施（school 109 / hospital 2 / mall 10 / park 3） |
| `/api/poi/isochrone`（pgr_drivingDistance） | **1.168 km²、吸附 11 m、约 5.1 s**（与本地基线一致） |
| `/api/stats/coverage` 洪山区 | 1940 个 / 514.76 km² / 3.77 个每 km² |
| WMS | 三图层 + 5 种热力图样式（grid_total/school/hospital/mall/park）全部 200 |

`isochrone` 响应字段：`areaKm2 / byCategory / count / edgeCount / items / itemsTotal / nodeId / partialCount / skeleton / snapM / center?`。等时圈在容器内跑通，说明 pgRouting 扩展与路网数据在镜像化后没有退化。

## 5. 运维补充

- 服务器原无 swap，3.6GB 内存跑四个 JVM 迟早被 OOM kill → 已加 **4GB swap**；实际四容器合计仅约 760MB（db 165MB / geoserver 418MB / backend 176MB / web 3MB），余量充足。
- 版本库排除：`deploy/.env`、`deploy/geodata/`、`deploy/artifacts/`、`deploy/geoserver-dist/`、`*.tgz`、GS `logs/`。`deploy/geoserver_data/security/geoserver.jceks` 是密钥库，若仓库公开需评估是否改为部署时上传。
- 遗留项：服务器上还有 2026-09-15 遗留的停止态 `postgis` 容器与 `kartoza/postgis` 镜像（2.5GB），与本次无关，可清理腾空间。

## 6. 待用户决定

1. `deploy/`（约 260 文件）+ `.dockerignore` + `.gitignore` 改动尚未提交 git。
2. 上述遗留镜像是否清理。

源码位置：`serviceAnalysis/deploy/`（`docker-compose.yml`、`Dockerfile.backend(.src)`、`Dockerfile.frontend(.src)`、`Dockerfile.geoserver`、`deploy.sh`、`push.ps1`、`README.md`）。
