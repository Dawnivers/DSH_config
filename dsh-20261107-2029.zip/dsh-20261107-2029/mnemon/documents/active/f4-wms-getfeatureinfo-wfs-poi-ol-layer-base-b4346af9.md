---
id: "b4346af9-bbcb-47b6-b128-5f360391455d"
title: "F4 热力图点格弹窗：WMS GetFeatureInfo（非 WFS）实现 + POI 误挂 ol-layer-base 修复 + 分析/热力互斥的进入退出"
description: "热力图点格弹窗的落地记录与取舍证据：为何只能走 WMS GetFeatureInfo 而不能用 WFS、pickGrid/store/GridPopup 三层分工与 singleclick 的热力图优先分叉、零覆盖格返回空数组不是错误、getFeatureInfoUrl 的 bbox 缓存前提、ratio 1.5 下手算像素坐标必错、POI 层误挂 ol-layer-base 与注释/roadmap 设计意图矛盾导致图钉被去色的根因与修复、进分析关热力亮 POI 退出恢复原态的实现与图例模式探针验证法、以及浏览器工具点不到 canvas 时的播种数据验证手法与验收清单缺口。"
status: "active"
created_at: "2026-11-01T12:09:05.443Z"
updated_at: "2026-11-01T12:09:05.443Z"
content_hash: "ce493e40a90eb3ffea3abbe24848afe9a24414e6cdc4da5746ce1d87d6f258dc"
source_paths:
  - "FE/src/map/gridInfo.js"
  - "FE/src/stores/grid.js"
  - "FE/src/components/GridPopup.vue"
  - "FE/src/view/mapView.vue"
  - "FE/src/map/wms.js"
  - "FE/src/stores/layers.js"
  - "FE/src/style.css"
  - "FE/src/App.vue"
session_ids:
  - "fecdd100-bd20-4eda-9941-c7a9048aae80"
memory_body_ids:
  []
---

# F4 热力图点格弹窗 + 两处与设计意图不一致的修复

## 0. 结论先行

- 热力图点格**只能**走 WMS `GetFeatureInfo`，`WFS GetFeature` 在语义、体积、时延三条上都不成立。
- 浏览器侧 `ImageLayer + ImageWMS` **没有 feature**，`forEachFeatureAtPixel` 永远拿不到东西。
- 「分析模式下 POI 变灰」是**代码与注释/设计相反**的 bug：`createPOILayer` 多挂了 `ol-layer-base`。
- 进入分析模式时「关热力、亮 POI，退出恢复进入前状态」须**记住原状态**，不能写死。

相关既有文档（勿重复实现，只做引用）：

- `da1967ee-48c7-4bea-a9b9-e8a2e803d61e`：F1 热力图接入、`className` 必须挂 layer 而非 source、heat↔poi 互斥、建层顺序。该文末尾把 F4 记为「尚未做」，本文即其续篇。
- `81c93b00-c684-4f65-a859-87e533a10776`：D13 分析模式灰化与 `className` 属构造参数（改完必须 F5）。
- `02506967-ac28-421f-886e-e0cc13e39d9f`：`wuhan:grid_500m` 的 `GetFeatureInfo` 返回体（`total/school/hospital/mall/park` + 五个 `r_*` + `centroid`），是弹窗的现成数据源。

## 1. 为什么是 WMS `GetFeatureInfo` 而不是 WFS

| | WMS `GetFeatureInfo` | WFS `GetFeature` |
|---|---|---|
| 输入 | 图片上的像素 (x, y) + 当时 bbox/宽度 | 查询条件（bbox / 属性过滤 / 字段） |
| 输出 | 该像素落到的**那个**要素 + 属性（约 700 B） | 完整要素集合（几何 + 属性，GML/GeoJSON） |
| 语义 | 「你画的这张图上，这一点是什么」 | 「我要这批数据」 |

热力图渲染链路是 `new ImageLayer({ source: new ImageWMS(...) })`——浏览器手里只有服务器渲好的整屏 PNG，没有任何 feature 对象。所以：

```js
map.forEachFeatureAtPixel(evt.pixel, ...)   // ❌ 在 ImageLayer 上根本不存在这条路
```

只能回头问服务器。用 WFS 的代价：视窗内上千个 500 m 方格，每格 5 顶点 + 15 属性 → 几百 KB 到几 MB，序列化比出图慢一个数量级，且还要前端自己判「点在哪个格子里」。

**判据**：栅格化表达里问「这点是什么」→ `GetFeatureInfo`；要「一批几何做计算/编辑/hover 高亮」→ WFS 或 MVT。当前只有点一下看统计这一种需求，因此不引入 WFS。

## 2. 实现：仍是三层分工

| 文件 | 职责 |
|---|---|
| `FE/src/map/gridInfo.js`（新） | `pickGrid(map, evt)`：拼 `GetFeatureInfo` URL、取 `features[0].properties`；另导出 `GRID_CATEGORIES` |
| `FE/src/stores/grid.js`（新） | `info / loading / error` + `setInfo / setError / clear`，getter `centroid` |
| `FE/src/components/GridPopup.vue`（新） | 纯展示卡片，视觉对齐 `PoiDetailCard`（`CARD_W = 288`、`right:16 / top:76`、`z-index:15`） |
| `FE/src/view/mapView.vue` | `singleclick` 里热力图优先分叉；新增 `registerWatcher('gridClear')` |
| `FE/src/App.vue` | 挂 `<GridPopup>`，与 POI 卡同锚点 |

请求在 `map/`、状态在 `stores/`、展示在 `components/`——与 `pickGid` / `selection` 完全同构，别把 fetch 写进组件。

### `singleclick` 分叉

```js
if (analysis.active) return;          // 分析模式：这一下是选中心，不查详情

if (layerStore.visible.heat) {        // ★ 热力开着 → 用户点的是「面」
  selection.clear();                  //   别让 POI 卡与格子卡同时出现
  gridStore.setLoading(true);
  const props = await pickGrid(map, evt);
  if (props) gridStore.setInfo(props);
  else gridStore.clear();             //   点在透明区（无覆盖）→ 收起卡片
  return;
}

const gid = await pickGid(map, evt);  // 否则维持原 POI 详情
```

虽然 heat↔poi 互斥（见 `da1967ee`）使谁先判断都等价，但写成「热力可见就先查格子」表达的是**意图**：这一模式下用户点的是面。

### `pickGrid` 的三道防线

```js
if (!heatLayer || !heatLayer.getVisible()) return null;  // 图层没开 → 不发请求
if (!url) return null;                                   // 没出过图 → bbox 未知
if (!data.features?.length) return null;                 // 点在透明格 → 正常空
```

第三道是**语义要点**：67.3% 的格子为零覆盖（透明），点上去 `features` 为空数组。这不是错误，是「这里本来就没设施」——收卡片，不报错。

## 3. 两个必踩的坑

### ① 用 `getFeatureInfoUrl()`，别手算像素

`source.getFeatureInfoUrl(coordinate, resolution, projection, params)` 会自动沿用该 source **最近一次**请求的 bbox / WIDTH / HEIGHT，而 `GetFeatureInfo` 是按「同一张图」定位的，bbox 差 0.001 度就落到隔壁格。

但热力层 source 设了 `ratio: 1.5`（WMS 实际渲的是视窗 1.5 倍图）。手算 `X/Y` 与 `WIDTH/HEIGHT` 时**两者都必须乘 1.5**，漏乘的后果是点偏一格或返回空，**且不报错**。所以结论是：交给 `getFeatureInfoUrl()`，不要自己拼。

副作用：图层不可见（没发过请求）时它返回 `undefined` → 必须先判 `getVisible()`，这也是上一节第一道防线的来源。

### ② 空响应 ≠ 失败

`FEATURE_COUNT: 1` + `INFO_FORMAT: application/json`；`data.features` 为空即「无覆盖」，不要弹「请求失败」。

## 4. Bug：POI 图钉被分析模式一起去色

用户反馈「分析模式下 POI 图层不要变成灰色」。根因是**实现与设计意图相反**：

```js
// createPOILayer 里多出来的一行
className: 'ol-layer-base'   // ❌
```

而 `mapView.vue` 的注释一直写着「POI 层不挂 `.ol-layer-base`，所以图钉仍然是彩色」，`roadmap §2.4.1` 的设计也是「地图变灰、分析要素突出」。**注释是对的，代码是错的。**

修复后去色名单（`#map.is-analysis .ol-layer-base` 只命中挂了类的元素）：

| 图层 | 变灰 | 理由 |
|---|---|---|
| 底图（天地图） | ✅ | 地图底子，压下去 |
| 注记 | ✅ | 同上 |
| 武汉区划 | ✅ | 「地图的一部分」，见 `81c93b00` |
| 热力图 | ✅ | 万一还开着也不抢视觉 |
| **POI 设施** | ❌ **彩色** | 分析要看的对象，必须突出 |
| 分析图形（缓冲圈/多边形） | ❌ | 本就红色，且未挂类 |

> 教训：**「设计意图」类断言必须进验收清单**。这类 bug 构建通过、HTTP 正常、页面无异常，只有肉眼看颜色才能发现。

## 5. 分析模式与热力图互斥（进入时切换，退出时恢复）

图层在分析模式下被工具栏替换，看不到勾选状态。实现要点：

- **进入**分析：关热力图、亮 POI（否则「分析对象」不可见）。
- **退出**分析：按**进入前**的状态恢复，不是无脑把热力重新打开。
- 验证探针：图例模式跟随 `visible.heat`，进入分析后图例变回「图例 WMS 样式 学校/医院/商场/公园」即证明热力已关；退出后图例回到热力图例即证明恢复。

## 6. 验证到哪一步

| 环节 | 方法 | 结果 |
|---|---|---|
| `GetFeatureInfo` 接口 | 此前 curl 实测（见 `02506967`） | ✅ 176/19/53/96/8 + 五个 `r_*` |
| 弹窗渲染 | **临时把真实响应塞进 `stores/grid.js`**，读 DOM 后立刻撤掉 | ✅ 数值、降序排序、倍数全对；默认不显示已复验 |
| 构建 | `vite build` | ✅ 265 modules / 341 ms |
| 类归属核对 | 全项目搜 `className` | ✅ 仅 base / anno / admin / heat 挂 `ol-layer-base` |
| **点击链路端到端** | 浏览器工具点不到地图 canvas（只接受元素索引，`singleclick` 需要真实坐标） | ⚠️ 未跑通，需人工点一次 |

**「播种数据验视图层」是可复用手法**：视图层的正确性不必依赖端到端点击——把真实响应灌进 store，就能单独验证渲染、排序与空态；但**必须成对撤回**，否则留下假数据（同 F1 里「临时改默认值绕 UI」那条，见 `da1967ee`）。

风险判断：`pickGrid` 与 `pickGid` 用同一个 OL 官方 `getFeatureInfoUrl()`，后者已在 D12 验证过，因此点击链路风险低。

## 7. 提交

- `f856ec6` 分析模式与热力图互斥：进入关热力亮 POI，退出按进入前状态恢复
- `dc2b203` 修复 POI 误挂 `ol-layer-base` 导致图钉被去色
- `b67eb6f` F4 点格弹窗：WMS `GetFeatureInfo`（非 WFS），热力可见时点选优先查格子（5 文件 +478/−2）

均为 Windows 下 `LF → CRLF` 告警，非问题。

## 8. 待补

- `roadmap §2.4.13` 补 F1/F4 前端链路与点格弹窗，并更新 D 编号。
- 验收清单补三行（这是本轮 bug 的直接来源）：
  ```
  □ 分析模式：底图/注记/区划变灰
  □ 分析模式：POI 图钉保持彩色   ← 本轮漏的
  □ 分析模式：缓冲圈红色可见
  ```
- 人工端到端点一次深红色块，应弹出「176」；无反应先看 console 的 `getFeatureInfoUrl` 报错。
