---
id: "d7871c12-0760-4ec1-a939-fde0953a1fdb"
title: "selection store 竞态验收与 GetFeatureInfo 真实返回结构：FE D12 Step 2/3 实测修正（2026-10-30）"
description: "FE D12 Step 2/3 的实测结论与对既有方案的修正：Pinia 方法必须放 actions（放 getters 会变成 Promise、调用报 is not a function）、loading 必须收进 finally 带 reqSeq 条件、6 条 selection 验收含人为延迟制造真实乱序；GeoServer GetFeatureInfo 的 gid 实为 feature.id \"poi.1\" 而非 properties.gid、raw 字段致响应约 3KB、FI_POINT_TOLERANCE=3 即可命中建议 10；以及 clickToGid.js 纯函数契约与「先独立写再接线」的验收路线。"
status: "active"
created_at: "2026-10-30T09:41:04.140Z"
updated_at: "2026-10-30T09:41:04.140Z"
content_hash: "0faa0a5b6f6fe2a8e8a4cf358d5b225f366a10cb947fc62e9e81692edc0f2551"
source_paths:
  - "FE/src/stores/selection.js"
  - "FE/src/map/clickToGid.js"
  - "FE/src/map/wms.js"
  - "FE/src/view/mapView.vue"
  - "FE/docs/roadmap.md"
  - "BE/src/main/resources/application.yml"
session_ids:
  - "fa9b0269-d89c-47e9-b18d-43f619cd6c00"
memory_body_ids:
  []
---

# selection store 竞态验收与 GetFeatureInfo 真实返回结构（FE D12 Step 2/3）

本文只记 **实测推翻了什么、确认了什么**，以及可以直接复用的验收手法。
前置与总体设计见 `e6e821b8-8ad6-4a4a-a43b-28efd3409221`（D12 点击查询实现方案），图层 watch 侧见 `97dfeb05-26ab-49f1-b8e4-47147bc2a429`。

## 1. 关键修正一：GeoServer 返回里没有 `properties.gid`

原方案写的是「`features[0].properties.gid`」，**实测是错的**。用数据库里的真实坐标精确换算像素后发 GetFeatureInfo（`FI_POINT_TOLERANCE=3`），返回：

```jsonc
{
  "type": "FeatureCollection",
  "features": [{
    "type": "Feature",
    "id": "poi.1",                       // ★ gid 在这里，格式 <layer>.<fid>
    "geometry": { "type": "Point", "coordinates": [114.292598, 30.610841] },
    "properties": {
      "amap_id": "B001B0IZT0",           // ← 不是 gid
      "name": "解放公园", "category": "park", "typecode": "110101",
      "address": "解放大道1861号", "adcode": "420102", "tel": "027-82421760",
      "lon": 114.292598, "lat": 30.610841,
      "raw": "{...高德完整原始 JSON，约 2KB...}",   // ★ 无法排除，撑大响应
      "detail": null, "detail_fetched_at": null,
      "source": "amap", "fetched_at": "2026-10-25T03:18:11.756Z"
    }
  }]
}
```

三个结论：

1. **取 gid 走 `feature.id`**：`'poi.1'` 按 `.` 切开取最后一段 → `Number()` → `1`。取完必须用 `Number.isInteger()` 校验，否则格式变化时会 `fetch('/api/poi/NaN')`。
2. **响应约 3KB**，因为 `raw` 带出了高德原始 JSON。这比 `fetch('/api/poi/{gid}')` 的清洗后响应只多不少，因此**「GetFeatureInfo 只当拾取器」的职责边界被实测坐实**：只取一个 gid，属性一律回 BE。
3. **`FI_POINT_TOLERANCE=3`（默认值）在精确坐标下即可命中**；实测 3 / 10 / 30 三档都能点到。但那是用数据库坐标算出的像素，真实手点会抖几像素，仍建议显式给 `10`。

### 排障路径（下次同类问题直接照抄）

- 第一次按估算的 3857 bbox 发请求 → `features: []`、`numberReturned: 0`，换 5 个坐标全空。**空数组不等于图层没数据**，只等于没点到几何点。
- 查 GetCapabilities：`wuhan:poi` 存在，`SRS=EPSG:4326`，bbox `113.7958~114.8257, 30.1572~31.0151`（换算 3857 为 `12667691,3523772,12782338,3634710`）→ 说明之前选的 bbox 落在图层范围内，「范围不对」这个假设被排除。
- 查样式 `poi_icons`（标题是乱码，说明属性编码非 UTF-8，不影响功能）：无 `MinScaleDenominator/MaxScaleDenominator`，排除缩放约束。
- 最后**从数据库直接取一条真实 POI 坐标**（`1|解放公园|114.292598|30.610841`），精确换算到像素（x=231 y=192）→ 一次命中。**这就是「空结果」的正解：不要猜像素，从数据源反推。**

psql 直连踩坑：`psql -d Spatial` 参数解析失败并报 `用户 "-d" Password 认证失败`，最终靠 `BE` 侧 `spring.datasource.*`（`jdbc:postgresql://localhost:5432/Spatial`，用户 `postgres`）拿到连接方式后查询。

## 2. 关键修正二：Pinia 方法写进 `getters` 会直接炸

学生版 `selection.js` 把 `SetPoi(gid)` 与 `clear()` 写进了 `getters`。这不是风格问题：

```
store keys = $id,$onAction,$patch,$reset,...,poi,loading,error,reqSeq,SetPoi,clear,...
SetPoi ERR: s.SetPoi is not a function
clear   ERR: s.clear is not a function
```

成因：`getters` 的每一项都被 `computed()` 包装，执行 getter 函数时 **`gid` 参数是 `undefined`**，得到的是函数体执行结果（一个 Promise）而非函数本身。且 `getters` 里写 `this.reqSeq += 1` 是在改 state，本就不该发生。

| | `getters` | `actions` |
|---|---|---|
| 本质 | computed 包装的只读值 | 普通可调用函数 |
| 用法 | `store.x`（不带括号） | `store.x()`（带括号） |
| 能改 state / 能 await | 不能 / 不能 | 能 / 能 |

**判据**：`store 上能看到这个 key` 不等于「方法可用」——必须实际调用一次。

## 3. `loading` 必须收进 `finally`（真 bug）

第一版把 `loading = false` 写在函数尾部，遇到 `if (!res.ok) { ...; return }` 时被跳过 → **404 时 `loading` 卡在 `true`，卡片永远显示「正在读取」，看不到「该设施不存在」**。
`fetch` 网络异常会抛异常而非返回 `!res.ok`，同理把 `loading` 卡死。

定型结构（已验收版本）：

```js
async setPoi(gid) {
  if (!gid) return;
  this.reqSeq += 1; const seq = this.reqSeq;   // 必须存局部变量，否则比较永远成立
  this.loading = true; this.error = null;
  try {
    const res = await fetch(`/api/poi/${gid}`);
    if (!res.ok) { this.error = res.status === 404 ? '该设施不存在' : `服务异常（${res.status}）`; this.poi = null; return; }
    const data = await res.json();
    if (seq !== this.reqSeq) return;           // 过期响应丢弃
    this.poi = data;
  } catch (e) { if (seq === this.reqSeq) this.error = '网络异常'; }
  finally { if (seq === this.reqSeq) this.loading = false; }   // 唯一关 loading 的地方
}
clear() { this.poi = null; this.error = null; this.loading = false; this.reqSeq += 1; }
```

`clear()` 里的 `reqSeq += 1` 不可省：否则点空白关卡片后，在途请求回来序号仍对得上，卡片会自己弹回来。

## 4. 验收手法：伪造真实乱序

本地网络太快，`setPoi(1); setPoi(39)` 通常是后者先发也先回，**过期响应分支根本没执行，是假通过**。
做法：拦截 `fetch`，让 `gid=1` 的请求人为延迟 1200ms，再 50ms 后发 `gid=39`，制造「先发后到」：

```
真实乱序后 gid=39 | name=政和广场 | loading=false
```

最终 6 条全过：正常（解放公园 / photos 3 / loading false）、404（error 文案正确且 loading false）、clear 三字段归位、竞态最终 gid=39、clear 作废在途、无效 gid 不发请求。
探针用完必须清理并核对「剩余 0」。

## 5. Step 3 `src/map/clickToGid.js` 的契约与验收路线

职责是**纯函数**：输入 `map, evt`，输出数字 gid 或 `null`。不渲染、不取详情、不 import store。

- 找图层：按 `map.getLayers()` 里哪个 `source.getParams().LAYERS === 'wuhan:poi'` 反查，这样不必改动已验收的 `FE/src/map/wms.js`。
- `source.getFeatureInfoUrl(evt.coordinate, view.getResolution(), view.getProjection(), { QUERY_LAYERS:'wuhan:poi', INFO_FORMAT:'application/json', FEATURE_COUNT:1, FI_POINT_TOLERANCE:10 })`。**`coordinate` 是地图坐标不是 `evt.pixel`**；该方法可能返回 `null`，必须判空。
- `features` 为空 → 返回 `null`（上层调 `clear()` 收卡片），**不要返回 `undefined`**，否则 `gid === null` 判断会漏。
- 接线在 `FE/src/view/mapView.vue`：`map.on('singleclick', async (evt) => ...)`，返回值是 `EventsKey` 对象，卸载时用 `ol/Observable.js` 的 `unByKey()` 摘（不是 Vue watch 那套）。

**验收只能在浏览器里点**（不像 Step 2 能在控制台独立验），因为没有 map 实例就拿不到输入。判据：zoom ≥ 15 出图钉 → 点图钉 Network 出现 `GetFeatureInfo` 200 → `selection.poi.name` 对上 → 点空白 `poi === null` → 连点两个以后点的为准。

## 6. 服务状态与一个「假死」经验

端口：BE `8094`、GeoServer `8080`、FE Vite `5173`，全部在跑。
之前三次误判过程「被终止」、并重复启动导致端口冲突，实为：**用 `mvn spring-boot:run` 时 Maven 在前台拉起 java 子进程，会话结束时 Maven 自己退出，但子进程留下继续服务**。所以判断后端是否活着要看**端口占用者**（`8094` 被 java pid 占用即为活着，看其父进程是否为 maven），而不是看启动命令的会话是否还在。连续 20 秒探测全 200 才算稳定。

## 7. 一句话结论

本次两个「方向性错误」都不是逻辑错：一是 **把协议细节当成了猜想**（`gid` 不在 `properties` 里，必须实测一次 GetFeatureInfo 才知道），二是 **把 Pinia 的 `getters` 当成了 methods**（必须实际调用一次才知道）。可复用的教训是——验收要能失败：竞态得人为造乱序，方法可用性得 `store.x()` 跑一遍。
