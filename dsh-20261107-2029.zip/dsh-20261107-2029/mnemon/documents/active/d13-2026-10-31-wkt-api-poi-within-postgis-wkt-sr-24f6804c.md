---
id: "24f6804c-23be-44b1-8cb3-dde07dd8a478"
title: "D13 分析链路端到端（2026-10-31）：绘制→WKT→/api/poi/within→PostGIS→面板，含「先建交互后画圆」顺序坑与 WKT 隐式转换 SRID=0 实测"
description: "框选/自由绘制一个多边形从鼠标到结果面板的完整八跳链路（3857 几何→4326 WKT→store→防抖去重→GET /api/poi/within→Controller/Service 校验→三条 PostGIS 查询→DTO→派生 UI），附两个已踩实的坑：syncDrawing 里 setTool 的 clear() 会擦掉刚画的圆（必须 setTool→setRadius→setCenter），以及 WKT 裸字符串进 ST_ 函数会被隐式转成 SRID=0 几何（mixed SRID 报错 / 面积按平方度静默算错）。"
status: "active"
created_at: "2026-10-31T10:54:56.303Z"
updated_at: "2026-10-31T10:54:56.303Z"
content_hash: "831282f53baa65ece94b9e5091d84c03edd52f69d81653926573b4f5145435c3"
source_paths:
  - "FE/src/map/drawing.js"
  - "FE/src/view/mapView.vue"
  - "FE/src/stores/analysis.js"
  - "FE/docs/roadmap.md"
  - "FE/docs/img/card-to-buffer.png"
session_ids:
  - "e152e135-289a-404a-9b04-2845bd150db5"
memory_body_ids:
  []
---

# D13 分析链路端到端（2026-10-31）

承接绘制交互层（`af40cfc5`）、`within` 接口选型（`aac88bd9`）与四项修正（`81c93b00`）。本文记录**一次完整跑通的链路**（框选矩形 → 结果面板），以及链路上两个已经踩实、且都能"不报错地给出错误结果"的坑。

## 1. 八跳链路（按当前代码逐跳核对）

```
① 鼠标两击定框
② OL 几何：3857 的 Polygon，三层嵌套数组 [[ring][point][x,y]]
③ toWkt()：3857→4326，数组→字符串 "POLYGON((114.36 30.52, ...))"
④ store.setGeometry({ wkt, areaKm2 })   只存值，不存 OL 对象
⑤ watch → 防抖 260ms → 指纹去重 → 请求序号 → GET /api/poi/within?wkt=<encodeURIComponent>&limit=50
⑥ 后端：Controller 限 limit(0,200] → Service 静态校验 + ST_IsValid 体检 → 三条 SQL（全部 ST_GeomFromText(#{wkt},4326)）
⑦ JSON { count, areaKm2, centroid, byCategory, items[] } → setResult(data, elapsed)
⑧ 派生：displayResult（按勾选类别过滤重算）→ 结果面板（最大余数法占比）/ SQL 横幅 / 地图图形
```

关键实现点：

- `drawing.js` 不 import 任何 store，只经 `onPoint({lon,lat})` / `onPolygon({wkt,areaKm2})` / `onMeasure({meters})` 上报；`mapView.vue` 把回调接到 `stores/analysis.js`。
- `toWkt(geom)` 必带 `dataProjection: 'EPSG:4326'` + `featureProjection: proj()`；漏掉 `dataProjection` 的后果是拿"米"和"度"比较，**返回 0 条且不报错**。
- `requestKey()` 指纹：点选 `nearby|lon|lat|radius`，多边形 `within|wkt`，`measure` 返回 null 不查询 → 改类别勾选不重查库。
- 后端三处 SQL：`inspectWkt`（ST_IsValid / ST_Area(g::geography)/1e6 / ST_Centroid）、`countByCategoryWithin`（group by category）、`itemsWithin`（按形心距离排序并加 `gid` 保证并列稳定，带 gid/坐标供点击定位）。
- 必须单独做 `ST_IsValid` 体检：`ST_Within` 遇自相交多边形**不报错，只返回空**，前端会误判"这片区域没设施"。
- `#{wkt}` 走 JDBC 预编译参数，不拼字符串——这是防注入的实际机制，不是风格问题。

## 2. ★ 坑一：`syncDrawing` 里 `clear()` 把刚画好的圆擦掉（顺序问题）

**现象**：点设施详情卡「附近分析」后，store 有 center、接口返回 50 条、结果面板与 SQL 横幅全对，**只有地图上没有圆**，且无异常。

**根因**：`mapView.syncDrawing()` 原来顺序是 `setRadius → setCenter → setTool`。`drawing.setTool()` 判断"工具真的变了才 `clear()`"（见 `FE/docs/roadmap.md` §2.4.4），而进入分析模式时内部 `tool` 从 `null` 变 `'point'` → `changed === true` → 把刚画好的圆和圆心一起清掉。

**修法**：先建交互、再上参数、最后画几何：

```js
drawing.setTool(analysis.tool, callbacks)  // ① 该清就清
drawing.setRadius(analysis.radius)         // ②
drawing.setCenter(analysis.center)         // ③ 最后画，不会被清
```

**可迁移判据**：凡是"某人会 `clear()` / `removeByKind()` 的 API"，必须排在绘制动作之前调用，否则后画的图形会被后到的清理覆盖。诊断口诀——**数据层全对、只有图形不对，就别查数据链路，去查"图形被谁清掉了"**。

**为什么回归没抓到**：两条入口路径进的是同一个 `syncDrawing`，但初始 tool 状态不同——"点地图选中心"时 tool 已是 `'point'`（changed=false 不清），"从卡片进入"时从 `null` 变 `'point'`（changed=true 清）。**验证一个清理逻辑，必须覆盖所有能触达它的入口，尤其是初始状态不同的那条。**

验证数据（CDP 复现卡片路径）：点击前 `kinds=[] active=false zoom=9`；点击后 `kinds=[circle(r=800), center]`、`zoom→14`、`relCard=true`、`sqlBar="ST_DWithin(geom::geography, 圆心, 800)·9ms·50条"`；1.2s 后再查圆仍在，无渲染异常。

## 3. ★ 坑二：WKT 裸字符串进 ST 函数 → 隐式转成 SRID=0 几何

同一条 POLYGON 在五处测试的结果（`psql` 实测）：

| 写法 | 可跑 | 结果 SRID | 说明 |
|---|---|---|---|
| `ST_Area('POLYGON(...)')` | ✅ | **0** | 值是平方度 0.0012 |
| `ST_Area('POLYGON(...)'::text)` | ✅ | **0** | 证明存在 text→geometry 隐式转换 |
| `ST_Within(geom, 'POLYGON(...)')` | ❌ | — | `Operation on mixed SRID geometries (Point, 4326) != (Polygon, 0)` |
| `ST_GeomFromText(wkt, 4326)` | ✅ | 4326 | **项目采用**，count=224 |
| `ST_SetSRID(wkt::geometry, 4326)` | ✅ | 4326 | 等价，同样 224 |

所以答案是"能用，但进去的是 SRID=0 的几何"，两个副作用：

1. **跨表空间运算直接报错**（mixed SRID）；
2. **面积/距离类函数按度算，不报错但差 9 个数量级**——`ST_Area('POLYGON(...)')` 得 0.0012（平方度），`ST_Area(ST_GeomFromText(...,4326)::geography)` 得约 1275 万（平方米）。

三条纪律：判点在面内必 `ST_GeomFromText(#{wkt},4326)`；算面积先定 SRID 再 `::geography` 再 `/1e6` 得 km²；不要裸字符串。同理，`ST_Within` 遇自相交多边形**静默返回空**，所以体检单独一步。

## 4. 三个必须记住的形变

| 形变 | 从 | 到 | 忘掉/做错的后果 |
|---|---|---|---|
| 坐标系 | 3857（米） | 4326（度） | 返回 0 条，不报错 |
| 数据结构 | 嵌套数组 | WKT 字符串 | `@RequestParam String` 接不到 |
| SRID | 裸字符串（0） | 4326 几何 | mixed SRID 报错，或面积按度静默算错 |

数组只存在于最内层：点 `[x,y]`、线 `[[x,y],...]`、**多边形 `[[[x,y],...]]` 比线多一层"环"**（因为可能有洞）；直接给 `[[x,y],[x,y]]` 当多边形，OL 会当成多个单点环，几何非法。环必须首尾闭合。

## 5. 排除法备注

「地图右侧一条黑竖条」经确认是 `vite-plugin-vue-devtools` 的悬浮面板（`.vue-devtools__panel`），仅开发模式出现，生产构建没有，**不是布局 bug**。这类"只在 dev 出现的视觉元素"优先怀疑 devtools / HMR overlay，别改 CSS。

## 6. 复现与清理纪律

排查用 CDP 脚本（如 `FE/_repro_card.mjs`）走真实操作路径、拍图存 `FE/docs/img/`，**用完删净并检查 `mapView.vue` 无 `__dbg` 残留**；改完跑一次 `npm run build`（退出码 0）再汇报。文档小节插进 `roadmap.md` 后要检查编号顺序（本轮曾把 2.4.6 插到 2.4.5 前面再修正）。

相关文档：`af40cfc5`（drawing.js 四工具与 OL Draw 接管条件）、`aac88bd9`（ST_Within vs WFS 选型与性能判读）、`81c93b00`（灰化与 className 构造参数）。
