---
id: "2a171bba-cb28-4e2a-a20e-f4023ac1ab44"
title: "FE 天地图底图成组切换（矢量 vec+cva / 影像 img+cia）：basemaps.js 收口、setSource 换源与验证手法（2026-10-31）"
description: "openlayers服务平台开发/FE 的底图切换实现实录：URL 集中到 basemaps.js、store 白名单、watch 成组 setSource、shallowRef 传 map、构建产物 grep 与逐模块编译探测，以及 Vite 改 .env 只重读一次导致注记静默 undefined 的坑。"
status: "active"
created_at: "2026-10-31T02:36:19.495Z"
updated_at: "2026-10-31T02:36:19.495Z"
content_hash: "c51e8e55bf86bb0e6beb5b0b2d0e5473c46d18a6954f82cc29507b81be5cdd71"
source_paths:
  - "FE/src/map/basemaps.js"
  - "FE/src/stores/layers.js"
  - "FE/src/view/mapView.vue"
  - "FE/src/App.vue"
  - "FE/src/components/TopBar.vue"
  - "FE/.env.example"
session_ids:
  - "17cd2ae6-6f25-4855-b6f7-bdb31651daf2"
memory_body_ids:
  []
---

# FE 底图成组切换实现与验证（2026-10-31）

承接 D3 的 `.env` 注入与 img_w+cva_w 配对事实（`30b1760a`、`bbb7fcbf`），本文只记「底图矢量/影像切换」这一版落地后的设计与可复用验证手法。tk 值只存在 `FE/.env`，不入文档、不入库。

## 1. 改动面（6 个文件 + 1 个新建）

| 文件 | 角色 |
|---|---|
| `FE/src/map/basemaps.js`（新） | 四个瓦片服务 URL 表 + `createBaseSource(kind)` / `createAnnoSource(kind)` / `baseMapLabel(kind)` |
| `FE/src/stores/layers.js` | 新增 `baseMap: DEFAULT_BASE_MAP`（默认 `'vector'`）+ `setBaseMap()` 白名单校验（拼错直接拒收，store 里不留脏值） |
| `FE/src/view/mapView.vue` | URL 不再写死，按当前 `store.baseMap` 建 source；`watch(store.baseMap)` 换源；`tiandituLayers`/`MasktiandituLayers` → `baseLayer`/`annoLayer` |
| `FE/src/App.vue` | `baseMap` 由本地 ref 改为 store 的 computed 桥（setter 走 action，便于以后埋点/记偏好）；面板底图行名字用 `baseMapLabel` 跟随 |
| `FE/src/components/TopBar.vue` | 矢量/影像按钮，v-model 绑定上面的 computed |
| `FE/.env` / `FE/.env.example` | 补 `VITE_TDT_IMG` / `VITE_TDT_CIA`，注明 vec↔cva、img↔cia 成组关系 |

顺手清掉 `mapView.vue` 里 12 行注释掉的 `adminLayer` 示例及随之无用的 `ImageLayer`/`ImageWMS`/`XYZ`/`ref` 引用。

## 2. 设计规则（会重复用到）

1. **底图必须成组切换**：`vec` 配 `cva`、`img` 配 `cia`。只换其中一个就是「影像上图叠矢量注记」。
2. **URL 收口在 `map/basemaps.js`**，组件与视图层不出现瓦片地址；加底图时 URL 表与 store 白名单一起加。
3. **`import.meta.env` 键名必须写字面量**：`import.meta.env.VITE_TDT_IMG`。写成 `import.meta.env['VITE_TDT_' + kind]` 依赖构建期静态替换的运气，不可靠。
4. **换源用 `setSource(新对象)`，不用 `setUrl + refresh`**：新 source 的瓦片缓存天然干净，不会残留旧底图瓦片。
5. **watch 不加 `immediate`**：初始 source 在创建图层时已按当前 `baseMap` 建好，加 immediate 只会白建两轮 source、白发两轮瓦片请求。
6. **OL 实例一律 `shallowRef` / 模块作用域变量**：普通 `ref` 会把 Map/图层/要素包成 Proxy，身份判断全坏。父子传实例用 `emit('ready', map)`，销毁时 `emit('ready', null)`；父级 `MapScaleReadout` 之类需要实例的组件接这个值。
7. **点击链路唯一入口**：`map.on('singleclick')` → `pickGid(map, evt)` → `selection.setPoi(gid)` 或 `selection.clear()`；搜索选中（`onPick`）也走 `selection.setPoi`，别开第二条链路。卸载顺序：`unByKey(clickKey)` → `stopAll()`（解除图层 watch）→ `map.setTarget(undefined)`。
8. 控件布局：`defaults({ rotate: false, attribution: false })`，把底部中间留给数据统计条，避免与自绘面板抢位。

## 3. 验证手法（可复用）

- **构建**：`vite build` 输出到临时 outDir，验证完即删。
- **产物 grep**（比"编译通过"更强的判据）：产物 JS 里 `vec_w`/`cva_w`/`img_w`/`cia_w` 各出现 1 次，且 `undefined` 拼地址 0 处。
- **dev server 逐模块探测**：`GET /src/main.js`、`/src/App.vue`、`/src/view/mapView.vue`、`/src/stores/layers.js`、`/src/map/basemaps.js`、`/src/components/TopBar.vue` 全 200 = Vite 编译通过。
- **进程/端口核查**：先看 5173 是谁、命令行指向哪个 vite；避免旧进程占端口。

## 4. 踩到的坑

- **改 `.env` 必须重启 dev server；一次写多行也只重读一次**。实测一次写入 `VITE_TDT_IMG` + `VITE_TDT_CIA`，旧 dev server 只加载到了前者，后者缺失 → 影像注记地址变成 `undefined`，**不报错、只是静默不出字**。重启后四个变量齐全（`VITE_TDT_VEC/CVA/IMG/CIA`）。判据：探测注入内容里键名是否齐全，而不是只看有没有 URL。
- 写 `roadmap.md` 时 Vite watcher 报 `EBUSY ... .roadmap.md.*.tmpdir/roadmap.md.tmp`：编辑器的临时目录被锁，属无害噪声；事后确认 `docs` 下无残留临时目录。
- 浏览器 bridge 被 `USER_CONTROL` 拒绝、且无扩展连接时，截图验证做不了；改用无头 Chrome 或让用户自己刷新确认（先例见 `30b1760a`）。
- 天地图瓦片带 `Referer` 会 403，脚本验证时见 `a1c65b87` 的记录。

## 5. 遗留（小）

- 顶栏按钮顺序现在是「影像底图、矢量底图」，而默认高亮是矢量（第二个），可对调 `BUTTONS` 顺序让默认高亮落第一个。
- `roadmap.md` §4.1 已同步成组规则/换 source 理由/改 .env 重启坑；§2.5 的「BaseMapSwitch 先不做」已标为不需要做。

相关文档：`30b1760a-48fb-46fb-8b0d-7ffd1b282605`（FE D3 验收与 .env 注入）、`bbb7fcbf-0682-468d-b7e0-54be35852fee`（vanilla D3 WGS84 底图抉择）、`a1c65b87-9f7b-4f61-a154-9b52872efa6a`（坐标系偏移与天地图 403）。
