---
id: "a62f2d6a-3c58-41be-b7bc-d284ac2c0b88"
title: "叠加明细口径一致性与缓冲区分分钟换算（overlay-items 端点修正 + 80 m/分钟，2026-11-04）"
description: "commit 0e14438：主请求已切 /overlay-network 但明细/导出共用函数仍打旧 /api/poi/overlay，导致面板是路网口径、明细是直线口径；修法、口径闭合四数恒等式（union.poi=itemsTotal=items.Count=ΣbyDegree=150）。commit 0c4ab8a：WALK_M_PER_MIN=80 m/分钟单点常量，滑杆/地图标签/两个面板三处显示分钟及弱化样式理由，路网卡用 usedBudgetM 故显示更短时间。承接 8559b1b5。"
status: "active"
created_at: "2026-11-04T10:54:22.478Z"
updated_at: "2026-11-04T10:54:22.478Z"
content_hash: "17e739a49371cff12d0804fc93e0d2779320060ad234c6eeccab20e4e9724ed3"
source_paths:
  - "serviceAnalysis/FE/src/App.vue"
  - "serviceAnalysis/FE/src/stores/analysis.js"
  - "serviceAnalysis/FE/src/components/AnalysisToolbar.vue"
  - "serviceAnalysis/FE/src/components/AnalysisResult.vue"
  - "serviceAnalysis/FE/src/components/ReachPanel.vue"
  - "serviceAnalysis/FE/src/map/drawing.js"
session_ids:
  - "beebf1e3-ca4d-421e-880f-b7ae581659f8"
memory_body_ids:
  []
---

# 叠加明细口径一致性 + 缓冲区步行时间换算（2026-11-04）

承接《叠加分析改为路网口径：每个圆先算可达面再求交》`8559b1b5-4a02-4f6c-b55c-2c6fa692c1dc`（commit `e02ae6e`）。
本篇只记 e02ae6e 之后两个提交：`0e14438`（明细端点修正）、`0c4ab8a`（半径滑杆显示分钟）。

---

## 1. `0e14438`：面板数字变了口径，明细却还在旧端点

**用户报的现象**：「同时有可达面结果和直线距离面结果，明细只展示直线距离的结果，没有可达面的结果」。

**根因是一行 URL。** 叠加分析有两个请求：

| 用途 | 端点 | 口径 |
|---|---|---|
| 主请求（面板数字） | `POST /api/poi/overlay-network` | 可达面求交 |
| 展开明细 / 导出 CSV（共用 `fetchOverlayItems()`） | `POST /api/poi/overlay` ← 漏改 | 直线圆求交 |

```js
// FE/src/App.vue  fetchOverlayItems()
- fetch('/api/poi/overlay',      { body: JSON.stringify({ shapes, withItems: true }) })
+ fetch('/api/poi/overlay-network', { body: JSON.stringify({ shapes, withItems: true }) })
```

于是同一张卡里两套数：面板 `1 重 0.87 km²/4 个、2 重 0.03 km²/2 个`，
明细却是直线圆并集的 42 条 —— **完全另一批设施**（路网口径并集只有 6 个）。用户看到的是"错的人"。

### 1.1 教训：改口径要按"同一次分析有几个请求"清点，不是按文件搜

`withItems` 是**按需**的第二次请求（主接口默认 `withItems=false`，4 KB vs 26 KB），
它与主请求不同文件路径、不同函数名，`grep overlay-network` 在 App.vue 里最初只匹配到 0 次。
**清点方法是列出该功能的全部入口**：面板首屏、展开明细、导出 CSV、单点卡、叠加卡 ——
凡共用一个 `fetch*()` 的地方一起改。改完 `grep` 旧端点，只剩注释里的历史说明，才算干净。

### 1.2 自检恒等式（这条比任何单测都便宜）

```
union.poi == itemsTotal == items.Count == Σ(byDegree 各档设施数)
```

实测（3 个相交圆，江汉路一带，`withItems=true`）：

```
HTTP 200 · 2,815 ms · 70 KB
union.poi=150  itemsTotal=150  items.Count=150  ΣbyDegree=150   ← 四数相等
明细前 5 条全部 deg=2（落在两圆重叠区），每条带 deg 字段
```

各档相加等于并集，是因为原子面互不相交。**四数不等就是两次请求打到了不同口径**——
先查 URL，不要先查 SQL。`deg` 随明细下发，使"某设施被几个可达面覆盖"在列表里也可见，
这就是需求里"重叠的点要统计并分版"的落点。

---

## 2. `0c4ab8a`：半径滑杆显示对应步行时间

**用户口径**：「以 800 m 10 分钟的速度来看，拉动缓冲区大小要显示对应步行时间」。

常量定死并**只写一处**（`FE/src/stores/analysis.js`）：

```js
WALK_M_PER_MIN = 80   // 800 m / 10 min；1.33 m/s，对齐《城市居住区规划设计标准》慢行 500–800 m
```

滑杆、地图标签、两个结果面板全读它。**为什么强调单点定义**：同一个换算在两个文件各写一遍，
拖到某个值会出现"滑杆 15 分钟 / 地图标签 14 分钟"，两边单独看都对，极难发现。

| 位置 | 显示 |
|---|---|
| `AnalysisToolbar.vue` 滑杆 | `100 m — 1250 m ≈ 15.6 分钟 — 2000 m`（当前值右侧加一档弱样式 `.tp-cur-min`：9.5px、`#c26a5a`、400） |
| `map/drawing.js` 圆标签 | `缓冲区 800 m ≈ 10 分钟` |
| `AnalysisResult.vue` / `ReachPanel.vue` 大数字 | `76 个设施在 800 m（≈10 分钟）内` |

小数保留一位，整数不显示 `.0`（`10 分钟` 不写成 `10.0 分钟`）。
视觉上分钟比米弱一档：**米是用户设的事实，分钟是按步速折算的**。

换算表（实测脚本核对）：100→1.3 / 400→5 / 600→7.5 / **800→10** / 1000→12.5 / **1200→15** / 1600→20 / 2000→25 分钟。

### 2.1 路网卡会显示比 800 m 更短的时间，这不是 bug

路网卡说明读的是 `usedBudgetM = 800 − snapM`（起点吸附距离）。
起点被吸到 191 m 外的路上时，显示 `609 m ≈ 7.6 分钟` —— 是"实际只剩这么多可走"的诚实结果。

---

## 3. 相关文件

| 文件 | 角色 |
|---|---|
| `serviceAnalysis/FE/src/App.vue` | `fetchOverlayItems()` 明细/导出共用请求，端点在此 |
| `serviceAnalysis/FE/src/stores/analysis.js` | `WALK_M_PER_MIN` 常量、`surfaces` 面积合并 |
| `serviceAnalysis/FE/src/components/AnalysisToolbar.vue` | 半径滑杆 + 分钟刻度 |
| `serviceAnalysis/FE/src/components/AnalysisResult.vue`、`ReachPanel.vue` | 面板大数字的分钟说明 |
| `serviceAnalysis/FE/src/map/drawing.js` | 圆标签文案 |

## 4. 遗留

`PoiMapper.xml` 已 843 行、3 条大型 SQL，前端 6 个文件行为变更，而 `roadmap.md` 仍停在 F5。
待补：§2.4.16 等时圈、§2.4.17 叠加路网口径、§2.4.18 时间口径。
