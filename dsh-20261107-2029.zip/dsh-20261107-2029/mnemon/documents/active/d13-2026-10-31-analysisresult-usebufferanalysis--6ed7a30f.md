---
id: "6ed7a30f-825e-4871-97ea-74c76265b941"
title: "D13 可达性分析结果面板（2026-10-31）：AnalysisResult 卡片、useBufferAnalysis 取数（防抖/竞态/指纹去重）、CSV 诚实导出、为点击定位补 gid+坐标后端字段"
description: "结果面板落地：大数字+分类占比条+最近设施+CSV 导出的结构与文案切换（圆心/范围）；取数 composable 的 260ms 防抖、请求序号竞态处理、参数指纹去重、前端类别过滤与后端过滤等价的依据；CSV 带 BOM 且注明\"非全量\"；为列表点击定位给 NearestDto/WithinItem 补 gid/lon/lat 并同步 MyBatis constructor resultMap；分析模式下列表点击只 flyTo、不开详情卡的理由与实测数据。"
status: "active"
created_at: "2026-10-31T09:03:55.846Z"
updated_at: "2026-10-31T09:03:55.846Z"
content_hash: "cee8e59bb9840416fa87d31da75a84f19c20fb61d964d4dec79c6bbcb99e5962"
source_paths:
  - "FE/src/components/AnalysisResult.vue"
  - "FE/src/composables/useBufferAnalysis.js"
  - "FE/src/stores/analysis.js"
  - "FE/src/App.vue"
  - "BE/src/main/java/com/dawnivers/be/dto/NearestDto.java"
  - "BE/src/main/java/com/dawnivers/be/dto/WithinItem.java"
  - "BE/src/main/resources/mapper/PoiMapper.xml"
  - "FE/docs/roadmap.md"
session_ids:
  - "d7004072-3092-470f-a0d0-708251c98a39"
memory_body_ids:
  []
---

# D13 可达性分析结果面板（2026-10-31）

承接绘制工具系列：`af40cfc5`（drawing.js + OL 拖拽坑）、`81c93b00`（灰化与四工具修正）、`c4bebf46`（点击式语义 + 缓冲圈像素真因）。三篇都停在"能画出图形"，本文记录**图形之后的结果展示链路**：取数、面板、导出，以及为此对后端契约做的扩展。

## 1. 链路与文件

```
drawing.js 回调 → stores/analysis.js（center/geometry/radius/categories/result）
                → composables/useBufferAnalysis.js（调 /nearby 或 /within）
                → components/AnalysisResult.vue（纯展示）
                → App.vue（取数接线、CSV 导出、列表点击 flyTo）
```

面板仍是"纯展示"，不 import store；状态与请求都在 store/composable 一层。

## 2. 面板结构与两种模式的文案切换

```
可达性分析结果            圆心：已选点
83  个设施在 800 m 内
──────────────────────────
医院 / 诊所              36 · 43%
▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓░░░░░░░
学校 / 商场 / 公园 …
──────────────────────────
最近的设施（最多 5 条）
● 冠佳口腔                82 m
──────────────────────────
[        导出 CSV        ]
```

- 大数字 30px 红色（整卡视觉重心），后接说明文案。
- 四个类别**按数量降序**，色条 `width` 直接取百分比。
- 列表超过 5 条时显示「还有 N 条，导出 CSV 查看全部」。
- 点选模式：副标题「圆心：已选点」+「个设施在 800 m 内」；框选/自由绘制：`范围：1408.75 km²` +「个设施在范围内」。

**文案跟随"几何来源"而非工具名**：二选一的分支条件是 `result` 来自 `nearby` 还是 `within`，不是当前 `tool`（工具已切换但结果还没回时不会说错话）。

## 3. 四个实现决定

### 3.1 类别勾选在前端过滤，不改后端

`byCategory` 是**全量**分类计数，且接口契约保证 `count = Σ byCategory`。因此剔掉未勾选类别后重新求和，与让后端按类别过滤**完全等价**，不是近似值。

实测：取消勾选「公园」→ 大数字 83 → 79（正好减 4），公园那行消失。

副产品：切换勾选**不触发新请求**（参数指纹里已去重）。

### 3.2 防抖 260ms

半径滑杆拖动时 `input` 连续触发，不防抖会打十几个请求。

### 3.3 竞态用请求序号

慢请求回来时用户可能已改半径或换了范围。不做序号比较就会出现「拖到 2000 m 却显示 800 m 的数」。响应落地前比对当前序号，过期响应直接丢弃。

### 3.4 CSV 带 BOM，且不假装是全量

- 以 `\ufeff` 开头，否则 WPS/Excel 打开中文乱码。
- 三段结构：参数（中心/半径或面积）→ 分类汇总（数量+占比）→ 设施清单。
- 末尾注明「清单为接口返回的前 47 条，非全量」——接口本来只回前若干条，导出不要暗示全量。

实测：2812 字节、59 行。

## 4. 为"列表可点击定位"扩展后端契约

原先的断链：
- `/api/poi/nearby` 的 `nearest[]` **没有 gid、也没有坐标**
- `/api/poi/within` 的 `items[]` 有 gid 但**没有坐标**

给两个 record 各加 `lon`/`lat`（`nearest` 另补 `gid`）：

```java
public record NearestDto(String name, String category, Double distanceM,
                         Long gid, Double lon, Double lat) { }
public record WithinItem(Long gid, String name, String category, Double distanceM,
                         Double lon, Double lat) { }
```

**关键约束：字段顺序必须和 MyBatis `constructor` resultMap 的参数顺序一致**，DTO 与 `PoiMapper.xml` 两边必须同步改，否则是一运行就错位的静默 bug。改完 `PoiApiTest` 6 个全绿。

同时注意语义差异：`WithinItem.distanceM` 是**距多边形形心**的米数，不是距某个设施；`NearestDto.distanceM` 是距中心点。前端展示文案不要混用同一句话。

## 5. 一个主动改掉的设计：列表点击只 flyTo，不开详情卡

分析模式下详情卡被隐藏（右侧让给结果面板），此时打开详情卡等于"点了一下什么都没发生"。因此列表点击只把镜头飞到该设施，结果面板保留。

实测：点击第一条 → 面板仍在、详情卡未打开、镜头移动到位。想查详情就退出分析模式再点地图。

**可迁移判据**：任何"列表项 ↔ 地图对象"的联动，先确认目标侧的展示容器在当前模式下是否可见；不可见时联动应降级为视野操作（flyTo / 高亮），而不是照旧打开一个看不见的面板。

## 6. 实测数据（CDP 派发真实鼠标事件）

```
浏览模式下面板存在: false
刚进分析模式（未选点）面板存在: false      ← 空态不该有卡片

点选：圆心：已选点 / 83 个设施在 800 m 内
      医院 36·43% / 学校 25·30% / 商场 18·22% / 公园 4·5%
      Σ分类 83 = 大数字 83 ✓   Σ占比 100% ✓
      色条 43.37% / 30.12% / 21.69% / 4.82%（与占比一致）
      列表 5 条全部 link:true，提示「还有 45 条」

框选：范围：1408.75 km² / 11,399 个设施在范围内
      医院 3,949·35% / 商场 3,504·31% / 学校 3,124·27% / 公园 822·7%
```

校验要点：**分类数量之和要等于大数字、占比之和要等于 100%**，这两条能一次抓出取数错位或过滤漏项。

## 7. 遗留

- 构建产物 504 KB 触发 Vite「chunks larger than 500 kB」提示（退出码 0，OpenLayers 占大头），D19 打磨阶段再考虑 code splitting。
- `nearby` 的 `nearest` 契约新增三个字段；`selection.js` 只读 `name/category/distanceM`，不受影响。
- 未做：按类别筛选时地图 POI 同步变化、点击列表项在地图上高亮该点。
