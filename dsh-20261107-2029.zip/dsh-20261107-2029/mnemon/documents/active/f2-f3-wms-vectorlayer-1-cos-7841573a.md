---
id: "7841573a-0f0b-43ff-ad5a-249ab907ef2c"
title: "F2–F3 悬停/选中/类别联动与缓冲圈半径补偿：WMS 探针链路、双 VectorLayer 语义、1/cos(φ) 米制补偿（含三个只在运行时暴露的坑）"
description: "从代码与 git 反查补记的 F2–F3 落地知识：为什么位图图层必须「先问服务器再画」、probe.js 统一探针的四条契约、hover/selection 必须两个图层、四道性能锁、模式名 grid ≠ 图层 id heat、模式别用 watcher 同步而应 resolve() 现读、投影米 ≠ 地面米需 1/cos(φ) 补偿；另附文档与实况对账方法。"
status: "active"
created_at: "2026-11-03T02:07:14.686Z"
updated_at: "2026-11-03T02:07:14.686Z"
content_hash: "08abed82fdf1ca3e85b1a411f2b64876eefb4206ad7fda9a99b5b38d9ef7ec8e"
source_paths:
  - "serviceAnalysis/FE/src/map/probe.js"
  - "serviceAnalysis/FE/src/map/hover.js"
  - "serviceAnalysis/FE/docs/roadmap.md"
  - "serviceAnalysis/README.md"
session_ids:
  - "edb93241-b0c5-4ad9-8ee7-7398d3ef079c"
memory_body_ids:
  []
---

# F2–F3：悬停、选中态、类别联动、缓冲圈半径（2026-11-01 实现，2026-11-03 补记）

提交时间 11-01 20:42–21:06（git 08–14），当时只堆功能未写文档，本文按代码与提交反查补账。
关联：`2087fac7-b9b7-479d-8a8e-aaf48a198420`（F5 叠加分析收尾，时间上在 F2–F3 之后但先被记录）、
`6ed7a30f-825e-4871-97ea-74c76265b941`（D13 结果面板，本文的缓冲圈半径问题在它之后才暴露）。

## 1. 位图图层没有 Feature：只能「问一次再画」

POI 与热力图都是 `ImageLayer + ImageWMS`——服务器渲好的整张位图，浏览器侧没有 Feature，
`forEachFeatureAtPixel()` 永远返回空（同一条坑在早期 D12 点击查询上已踩过一次）。所以悬停链路只能是：

```
pointermove → GetFeatureInfo 问服务器「这个像素是什么」→ 拿回 geometry → 画到自己的 VectorLayer
```

`map/probe.js` 把这个动作收敛成唯一入口：
`probeFeature(map, evt, layerId, extra, opts)` → `{ id, geometry, properties, url }`
（`url` 留着自己能复现那一条请求，便于对比).

| 设计 | 取值 | 理由 |
|---|---|---|
| 通道 | **GetFeatureInfo**，不是 WFS | 只回 1 个要素 ≈ 700 B / 实测 **12 ms**；WFS 回整窗要素几百 KB |
| 坐标 | **不做投影变换** | 回来的几何跟随请求的 `SRS`（= view 投影 3857）；再按 4326 解会把米当度 |
| 取要素 | `opts.requireContain` 逐个 `intersectsCoordinate` | 一个像素可能压 4 个格子，GeoServer 返回顺序无保证 |
| 失败处理 | 先 `text()` 再 `JSON.parse` | GeoServer 抛错是 **HTTP 200 + XML**，直接 `.json()` 只报 `Unexpected token '<'` |

## 2. 悬停与选中必须拆成两个图层

| 图层 | zIndex | className | 样式语义 |
|---|---|---|---|
| 悬停 `source` | 90 | `ol-hover` | 临时指示：深墨蓝双描边 / 白晕 + 蓝光圈，标签是深色药丸 |
| 选中 `selSource` | 91 | `ol-select` | 已定下的对象：主色 `#1565C0` 实线 + 常驻标签，POI 半径 18（悬停 15） |

**共用一个 source 会互相擦**：「选中 A 格后鼠标划过 B 格」是正常操作，悬停清场（`source.clear()`）
会把选中一起抹掉。两个 className 都**不挂 `ol-layer-base`**——分析模式下它们也不该被去色。

热力格的**双描边是刻意的**：外圈深墨（浅黄底上撑边界）+ 内圈白（深红底上才看得见），
一条线做不到「在哪一档背景上都清楚」。

## 3. 性能靠四道锁（`hover.js` 顶部常量）

| 锁 | 阈值 | 拦什么 |
|---|---|---|
| 时间锁 `THROTTLE_MS` | 90 ms | 连续移动狂发请求；冷却结束补一次，保证停下时最后一格也亮 |
| 位移锁 `MIN_PIXEL_MOVE` | 5 px | 手抖 |
| 结果锁 `lastId` | — | 还在同一格 → 不重画 |
| `inFlight` | — | 慢请求堆叠 |

拖动时（`evt.dragging`）一律不查。

## 4. 三个只在运行时暴露的坑

**坑 1：模式名 ≠ 图层 id，静默失效。**
模式是 `'grid'`，而图层 `properties.id` 是 `'heat'`。第一版直接把 `mode` 当 layerId 传给探针，
`probeFeature` 里 `.find(id === layerId)` 找不到 → 返回 `null` → **悬停完全没反应且不报错**。
POI 因两者同名（都叫 `'poi'`）侥幸能用，于是「一半好用」最容易骗过人。
修法：显式映射 `const LAYER_OF = { grid: 'heat', poi: 'poi' }`。
通用教训：**凡是「用户可见但代码里叫另一个名字」的枚举，映射表要显式写出来，不要靠同名巧合。**

**坑 2：模式别用 watcher 同步，改成每次现读。**

```js
resolve() {
  if (analysis.active) return null;            // 分析模式下鼠标在选中心，不悬停
  if (layerStore.visible.heat) return 'grid';   // 热力优先（store 里两者本就互斥）
  if (layerStore.visible.poi) return 'poi';
  return null;
}
```

第一版用 `registerWatcher` 把 store 推成 `'grid' | 'poi'` 存进闭包变量，多了一次状态跳转：
watcher 没触发 / 触发时 hover 还没建 / 顺序错开，表现都是「悬停全哑」。
无缓存 → 不存在「没同步上」。`registerWatcher('hoverReset')` 只负责**突变时擦残留**，不负责传模式。

**坑 3：投影米 ≠ 地面米，缓冲圈半径要按 `1/cos(φ)` 补偿。**

Web Mercator 在纬度 φ 处夸大 `1/cos(φ)`（武汉 ≈ 30.6°N → ≈ 1.16）。
不补偿时，滑杆设 800 m 会在屏幕上画出约 690 m 的真实距离；反过来说，
「800 m ≈ 84 px @ z14」这类像素账也只有在补偿后才对得上。

```js
// paintCircle（画圈）与 resizeCircle（拖滑杆改半径）共用同一个函数，
// 两条路径不会各说各话
```

这类 bug 不报错、也不让数字对不上（统计走后端 geography，与画法无关），
只有拿尺子量屏幕才看得出来。**通用教训：凡是「在地图上画一个已知物理长度」的地方，
都要先问一句「这个长度是什么单位」。**

## 5. 类别联动

热力按 全部 / 学校 / 医院 / 商场 / 公园 切换时，弹窗与悬停只算**当前类**；
实现上同一图层换 `STYLES` 参数（`updateParams`），不重建图层、不重发统计请求。

## 6. 提交账（git 08–14）

| 提交 | 交付 |
|---|---|
| 08 | 抽出 `probe.js` 统一探针 + 悬停高亮（格子描边 / POI 光圈 + 名称），四道锁 |
| 09 | 低缩放不再静默，光标旁出「放大到 z11」提示 |
| 10–11 | 悬停模式改 `resolve()` 现读 store；补 `LAYER_OF`（`grid → heat`） |
| 12 | 热力类别联动：弹窗与悬停只算当前类，切换不重发请求 |
| 13 | 选中态独立图层（主色描边 + 常驻标签，与悬停并存） |
| 14 | 缓冲圈半径 `1/cos(纬度)` 补偿 |

## 7. 顺带得到的方法：文档落后于实况时怎么对账

本项目 `FE/docs/roadmap.md` 曾停在「D18 完成 → D19 起点」，实际已到 F5。有效对账顺序：

1. `git log` 的提交主题（比记忆可靠，能看出未记的功能）；
2. 代码原文（`@GetMapping`/`@PostMapping` 计数得出接口数、样式目录数、图层 `properties.id`）；
3. surefire 报告（测试用例真实数量）；
4. 端口/进程（哪些服务在跑，演示前要先拉起来）。

用这四样能一次定位「文档写的 N ≠ 实际 N」的位置。**文档里的行数、接口数、样式数这类
可数事实要写成可核对的数字，而不是「若干」。**
