---
id: "6dfea3ef-afec-4994-95ba-d6ddd5dbfd60"
title: "D10 落地：/api/stats/coverage 按区统计接口（参数改 adcode、perKm2 归 Java、count(*) 与 filter 的结论）"
description: "武汉 GIS 项目 D10 阶段 /api/stats/coverage 的完整规格与落地实录：契约字段、4 个文件改动、adcode vs district 参数决策、perKm2 用 BigDecimal 在 Service 计算、AreaMapper.xml 的 resultMap/select 写法与 integer↔text JOIN 注意点、实测验收结果与 psql 基线、count(*) filter 不会多计数的更正、下一步测试 seam/依赖/用例期望值。"
status: "active"
created_at: "2026-10-29T01:46:10.144Z"
updated_at: "2026-10-29T01:46:10.144Z"
content_hash: "c97ce473047ab3a6a0c245b2d33c1cf1b9a8a085b345de66fdf0ecc567a74d93"
source_paths:
  - "BE/src/main/java/com/dawnivers/be/service/AreaService.java"
  - "BE/src/main/resources/mapper/AreaMapper.xml"
  - "BE/src/main/java/com/dawnivers/be/controller/AreaController.java"
  - "BE/src/main/java/com/dawnivers/be/dto/CoverageDto.java"
  - "BE/src/main/java/com/dawnivers/be/dto/DistrictStatDto.java"
  - "BE/src/main/java/com/dawnivers/be/mapper/AreaMapper.java"
  - "FE/docs/roadmap.md"
session_ids:
  - "66b32340-12c6-4c1a-9426-6b583262ca92"
memory_body_ids:
  []
---

# D10 · `/api/stats/coverage`（按区统计）

代码仓库根：`D:\WebGIS\web二维开发\openlayers服务平台开发`，后端在 `BE/`，端口 **8094**，库 `Spatial`（PostgreSQL + PostGIS），MyBatis XML 映射。

## 1. 契约

```jsonc
// GET /api/stats/coverage?adcode=420106
{
  "adcode": 420106,          // Long
  "district": "武昌区",       // 保留中文名，前端可直接显示
  "total": 1681,             // Long
  "areaKm2": 100.06,         // Double（驼峰，全项目统一）
  "perKm2": 16.8,            // Double，Java 计算，保留 2 位
  "byCategory": { "school": 525, "hospital": 590, "mall": 447, "park": 119 }
}
```

## 2. 参数决策：用 `adcode` 而不是 `district`（中文名）

早期文档（见 `563ae7f5` 第 5 节骨架）写的是 `?district=武昌区`，D10 改为 **`?adcode=420106`**，理由：

1. Windows 下 psql/curl 传中文参数会报 `无效的 "UTF8" 编码字节顺序`（本机已踩过多次）；
2. `adcode` 是天然主键，区名理论上可能重名；
3. FE 端 `/api/areas` 返回的每个 feature 都带 `adcode`，D12 前端可直接用。

注意：`563ae7f5` 里的 JSON 骨架是旧版（`by_category` / `per_km2` 下划线 + `district` 参数）；**以运行时代码为准**，现为驼峰 `byCategory` / `perKm2` / `areaKm2`。

## 3. 改动文件（4 个 + 2 个 DTO）

| 文件 | 作用 |
|---|---|
| `BE/src/main/java/com/dawnivers/be/dto/DistrictStatDto.java` | record，接 MyBatis 结果：`adcode, district, total, areaKm2, school, hospital, mall, park`（全用包装类 `Long`/`Double`） |
| `BE/src/main/java/com/dawnivers/be/dto/CoverageDto.java` | record，对外：`adcode, district, total, areaKm2, perKm2, Map<String,Long> byCategory` |
| `BE/src/main/java/com/dawnivers/be/mapper/AreaMapper.java` | `DistrictStatDto statByAdcode(@Param("adcode") long adcode);` —— 放 `AreaMapper` 而非 `PoiMapper`，因为主表是 `admin_area` |
| `BE/src/main/resources/mapper/AreaMapper.xml` | `resultMap id="DistrictStatMap"`（`<constructor>` + `idArg`/`arg` 顺序对齐 8 个参数）+ `select id="statByAdcode"` |
| `BE/src/main/java/com/dawnivers/be/service/AreaService.java` | `coverage(long adcode)` |
| `BE/src/main/java/com/dawnivers/be/controller/AreaController.java` | `@GetMapping("/stats/coverage")`，类上是 `@RequestMapping("/api")` |

**SQL 结果形状 vs Java 形状的分工**：SQL 出平的 8 列（`count(...) filter (where category=...)`），Java 里再装进 `Map`，**不在 SQL 用 `json_object_agg` 拼 map**（否则变成"数据库定形状"，违反 `6b85ed40` 的三层边界）。

### AreaMapper.xml 关键点

```xml
<select id="statByAdcode" resultMap="DistrictStatMap">
    select a.adcode as adcode,
           a.name as district,
           count(p.gid) as total,
           round((ST_Area(a.geom::geography)/1e6)::numeric, 2) as "areaKm2",
           count(*) filter (where p.category = 'school')   as school,
           count(*) filter (where p.category = 'hospital') as hospital,
           count(*) filter (where p.category = 'mall')     as mall,
           count(*) filter (where p.category = 'park')     as park
    from admin_area a
    left join poi p on p.adcode = a.adcode::text
    where a.adcode = #{adcode}
    group by a.adcode, a.name, a.geom
</select>
```

- **`p.adcode`（text） = `a.adcode`（integer）必须显式 `::text`**，PG 不会自动转。
- 但 **select 里不要 `a.adcode::text`**——保持 integer，MyBatis 转 `Long` 没问题；`::text` 只用在 JOIN 条件。
- `round(double, int)` 在 PG 不存在，必须先 `::numeric` 再 `round(..., 2)`（与项目已有坑一致）。
- `<select>` 内嵌 XML 注释可用但会留空白；**建议把说明写到标签外**，方便 SQL 复制到 psql 调试。

## 4. perKm2 在 Java（Service）算，不在 SQL 算

理由：可测（不连库即可验证 1681/100.06=16.80）、精度可控、符合"计算归数据库、展示格式归 Java"之后的**后处理归 Java** 的细分。

```java
double perKm2 = s.areaKm2() > 0
        ? BigDecimal.valueOf(s.total())
            .divide(BigDecimal.valueOf(s.areaKm2()), 2, RoundingMode.HALF_UP)
            .doubleValue()
        : 0.0;
```

- 用 `BigDecimal.setScale/HALF_UP`，**不用** `Math.round(x*100)/100.0`（浮点误差）。
- `areaKm2 <= 0` 必须保护：Java double 除 0 得 `Infinity`，Jackson 序列化成 `null`，前端拿到 null 极隐蔽。
- `statByAdcode` 查不到返回 `null`（MyBatis 特性，不抛异常）→ 抛 `ResponseStatusException(HttpStatus.NOT_FOUND, "district not found: " + adcode)`。

Controller 不做额外校验：`@RequestParam long adcode` 传 `abc` 自动 400，负数查不到自然 404。

## 5. 实测验收（2026-10-29，全部通过）

psql 基线（adcode 420106 武昌区）：`total 1681 / areaKm2 100.06 / school 525 / hospital 590 / mall 447 / park 119`。

```
GET /api/stats/coverage?adcode=420106
{"adcode":420106,"district":"武昌区","total":1681,"areaKm2":100.06,"perKm2":16.8,
 "byCategory":{"school":525,"hospital":590,"mall":447,"park":119}}

adcode=999999 -> 404
adcode=abc    -> 400
GET /api/areas    -> 200 85166（字节）
GET /api/poi/1    -> 200
```

至此 6 个业务接口齐备：`/api/hello`、`/api/ping-db`、`/api/areas`、`/api/poi/{gid}`、`/api/poi/nearby`、`/api/stats/coverage`。

## 6. 更正：`count(*) filter (...)` 在空 join 下**不会**多计数

曾判断"某区无 POI 时 left join 产生一行 p.*=null，`count(*)` 会算成 1"，**这是错的**（已用 psql 实测）。

- 陷阱只存在于**没有 filter 的 `count(*)`**：空 join 时确实 = 1。
- 一旦加上 `filter (where p.category='school')`：`p.category` 为 null → `null = 'school'` 结果是 `NULL` 而非 `false` → `FILTER(WHERE NULL)` 不计数 → **0，正确**。
- 实测：模拟不存在的 adcode join，`total=0, school_star=0, school_gid=0`。
- 结论：把分类从 `count(*)` 统一成 `count(p.gid)` **是"更稳"的一致性建议，不是修 bug**（去掉 filter 时 `count(*)` 才会错）。当前代码 `total` 用 `count(p.gid)`、分类用 `count(*) filter(...)` 两者都正确。

## 7. 下一步：统一加测试（D10–D11）

背景：用户问"为什么要 seam，启动 SpringBoot 用 URL 就能取数"。理由：8094 无监听时 URL 是死的；数据一变手动验证就失效；手动 curl 无法重复运行、没有"上次通过"记录。

已定的三个决定：

| 项 | 选择 |
|---|---|
| seam | **URL 层**：`@SpringBootTest(webEnvironment = RANDOM_PORT)` + `TestRestTemplate`（把 curl 写成 Java，一次覆盖路由 + SQL + 序列化） |
| 数据库 | 先连真库 `Spatial`；上 CI 再换 H2 / Testcontainers |
| 用例数 | 先 3 个（每接口一条主路径） |

依赖：`pom.xml` **还没加 `spring-boot-starter-test`**（此前只 `dependency:resolve` 过，未落进 pom）；`src/test` 目录还不存在。用户要求**先加 coverage（JaCoCo）再统一加测试**。

三个用例与期望值（期望值来自 psql，不从代码倒推）：

1. `GET /api/poi/1` → 200、`name="解放公园"`、`photos.size()=3`
2. `GET /api/poi/nearby?lon=114.36&lat=30.54&radius=800` → 200、`count=124`、`byCategory.school=109`
3. `GET /api/stats/coverage?adcode=420106` → 200、`total=1681`、`perKm2=16.8`、`byCategory.park=119`

提醒：`@SpringBootTest` 会真实读 `application-local.properties`（本地密码 profile，见 `6b85ed40`）并连 `Spatial` 库。

## 8. 相关文档

- `6b85ed40-4278-4e1f-b061-02a6fc74fc95` — D5 三层职责边界、profile 密码方案（本文的分工与 profile 前提）
- `563ae7f5-4d89-40d3-af0b-fc24c1f473cc` — FE 侧 WMS 接入与接口骨架初版（其 coverage 骨架已过时）
