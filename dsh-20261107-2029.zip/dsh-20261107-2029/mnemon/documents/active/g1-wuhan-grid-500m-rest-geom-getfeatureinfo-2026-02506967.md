---
id: "02506967-ac28-421f-886e-e0cc13e39d9f"
title: "G1 发布 wuhan:grid_500m：REST 发布命令、双几何列默认取 geom 的两条验证、GetFeatureInfo 直接供弹窗（2026-11-01）"
description: "GeoServer 侧把 PostGIS 表 grid_500m 发布为 wuhan:grid_500m 的实施记录：现有工作区/store 现状、featuretypes REST POST 方式与 HTTP 201、grid_500m 同时含 Polygon geom 与 Point centroid 的默认几何风险及「出图是面 + geometry_name=geom」双验证法、GetFeatureInfo 一次返回 total/school/hospital/mall/park 与五个 r_ 倍数及 centroid 因而不需新接口、以及留给 G2 的 SLD 待办。"
status: "active"
created_at: "2026-11-01T08:48:28.996Z"
updated_at: "2026-11-01T08:48:28.996Z"
content_hash: "b4144b01d288f7e0b015e4b9ba6fd2170690e70fa548f54e71b07a1f5ec89a5f"
source_paths:
  - "FE/docs/roadmap.md"
  - "BE/db/README.md"
  - "BE/db/03_refresh_grid_500m.sql"
session_ids:
  - "cc82139b-9bc5-4521-aa2e-090527fe17e7"
memory_body_ids:
  []
---

# G1：发布 `wuhan:grid_500m`

承接口径设计 `7e3e84a2-3ab6-4682-9580-62fa711654a3`（D16：800m 圆、相对倍数分档）、后端落地 `78d9ef59-2a33-4d23-acd5-69e269678eac`（B1–B5 四脚本）与增量刷新 `e4bb7d7e-f4a3-401e-a566-739be00284d0`（03b）。本篇只记录 **G1：把 PostGIS 表发布成 GeoServer 图层** 这一步。

## 1. 发布前的现状（先探测再动手）

| 项 | 值 |
|---|---|
| GeoServer | `http://localhost:8080/geoserver`（端口 8080 的属主进程 4592） |
| 工作区 | 已存在 `wuhan`（另有 cite / ne / nurc / sde / sf / tiger / topp / it.geosolutions） |
| 数据存储 | `wuhan:spatial_db`，type=PostGIS，库 `Spatial`、schema `public`、localhost:5432、user postgres |
| 发布前已有图层 | `admin_area`、`empty_poi`、`poi` |
| 发布后 | 追加 `wuhan:grid_500m` ✅ |

`grid_500m` 建表后并**不会自动**出现在 store 的 featuretypes 列表里，必须显式发布。

## 2. 走 REST 发布，不点 Web 界面

```
POST /rest/workspaces/wuhan/datastores/spatial_db/featuretypes
{"featureType":{"name":"grid_500m","nativeName":"grid_500m",
                "srs":"EPSG:4326","projectionPolicy":"FORCE_DECLARED","enabled":true}}
→ HTTP 201 Created
```

理由：可复现、能贴进文档、环境可一键重建（README 可写「图层发布走 REST」）。参照对象是已有的 `poi` featuretype 参数（EPSG:4326、FORCE_DECLARED、enabled）。

## 3. 必须验的坑：表里有两个几何列

`grid_500m` 同时有：

```
geom      -> org.locationtech.jts.geom.Polygon
centroid  -> org.locationtech.jts.geom.Point
```

GeoServer **把两列都识别成几何属性**。若默认几何选中 `centroid`，整个热力图会画成**一堆点**而不是方格，且表面看起来「图层正常、有数据」，很容易误判为成功。

### 双验证法（两条都要做）

| 验证 | 观测 | 结论 |
|---|---|---|
| WMS GetMap 出图（400×400 图块，6970 bytes） | 600×600 灰色**方格 + 黑边** | 是面 ✅ |
| WFS/GetFeatureInfo | `geometry_name = "geom"`、`geometry.type = Polygon` | 默认几何为 geom ✅ |

只做出图不够（灰面在缩得很小时也可能像点阵），只做属性查询也不够（不证明渲染正确）。临时图片验完即删。

## 4. 意外收获：GetFeatureInfo 就是弹窗数据源

在江汉路中心点查一格，一次请求返回全部统计与定位信息：

```jsonc
{
  "geometry_name": "geom",
  "geometry": {"type":"Polygon", "coordinates":[[[114.282,30.582], ...]]},
  "properties": {
    "total": 176, "school": 19, "hospital": 53, "mall": 96, "park": 8,
    "r_total": 46.86, "r_school": 17.43, "r_hospital": 42.27,
    "r_mall": 84.27, "r_park": 29.35,
    "centroid": {"type":"Point","coordinates":[114.28425,30.58425]},
    "cell_i": 25396, "cell_j": 6796
  }
}
```

对照 §D16 定下的「颜色用倍数、弹窗用数量」：

| 用途 | 字段 | 来源 |
|---|---|---|
| 地图着色 | `r_total` / `r_school` / … | SLD 直接读 feature 属性 |
| 弹窗显示 | `total` / `school` / `hospital` / `mall` / `park` | 同一份 JSON |
| 前端定位 | `centroid` | 同一份 JSON |

**结论：G 阶段不需要为点格弹窗新写任何后端接口**，WMS/GetFeatureInfo 已够用。

## 5. 图层当前状态与遗留

```
wuhan:grid_500m  →  已发布，enabled，用 GeoServer 默认多边形样式（灰色）
                     EPSG:4326，包围盒 113.697~115.079 / 29.970~31.361
```

还是灰的 —— 因为**还没写 SLD**，这正是 G2 的事。G2 要点（尚未实施）：

- 五档用 `<Rule>` + `<ElseFilter>` 顺序匹配，**不要用 `<ColorMap>`**（那是栅格用的）；
- 第 1 档 `r_total < 0.2` 不画任何东西（26,786 个零值格保持透明，只显示有覆盖区域）；后续 `0.2–1 / 1–3 / 3–10 / ≥10`；
- 边框透明（39,820 个格子的黑边会糊成一片黑网）；填充透明度约 0.75 让天地图底图透出。

## 6. 记录位置

全过程（REST 命令、双几何验证、GetFeatureInfo 实测 JSON）已写进 `FE/docs/roadmap.md` 的 §2.4.10，与 §2.4.9（格网热力图设计决策与实测基线）、§2.4.9 ⑨（增量刷新）平级。
