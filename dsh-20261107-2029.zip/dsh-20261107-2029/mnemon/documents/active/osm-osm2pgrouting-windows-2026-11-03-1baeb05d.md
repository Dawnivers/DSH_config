---
id: "1baeb05d-1168-4e1d-b25a-3a5975f4c857"
title: "OSM 路网数据获取 → osm2pgrouting 导入 → 验收：Windows 实操记录（2026-11-03）"
description: "武汉步行路网的 OSM 数据源选型（Geofabrik Hubei vs BBBike vs Overpass）、实际导入参数与坑、QGIS 只见点数据的原因、GDAL OSM 驱动中文临时目录报错、导入后拓扑/单位验收 SQL。承接等时圈方案文档 acb716e0。"
status: "active"
created_at: "2026-11-03T08:15:14.898Z"
updated_at: "2026-11-03T08:15:14.898Z"
content_hash: "3c50f74cd277dc40849069f8402fc2b33ab59d1dcefe3971ca42a855a3740ca0"
source_paths:
  - "serviceAnalysis/data"
  - "serviceAnalysis/BE/src/main/resources/application.properties"
session_ids:
  - "3a63623e-f07a-4a49-9782-c184f859070b"
memory_body_ids:
  []
---

# OSM 路网数据获取 → osm2pgrouting 导入 → 验收（2026-11-03 实操）

承接《单点路网等时圈 vs 全城格网》（文档 id `acb716e0-90da-4a84-a8a3-36a77603a58c`）的第 3 节工具链核对；本篇记录“数据从哪来、怎么进库、进来后怎么验收”的可复用结论与实测坑。

## 1. 数据源选型（结论：用 Geofabrik 湖北分片）

`https://download.geofabrik.de/asia/china/hubei-latest.osm.pbf`（注意：`china/hubei.html` 是说明页，不是直链）。

| 源 | 特点 | 取舍 |
|---|---|---|
| Geofabrik 湖北分片 | 按省界切片；实测下载文件 `hubei-261102.osm.pbf` 仅 **53.6 MB**；每天更新，页面直接给 `data up to` 时间戳，**可复现** | **推荐** |
| BBBike Extract（extract.bbbike.org） | 自定义 bbox 裁剪，选 `Protocol Buffer (PBF)`，生成后邮件通知 | 想严格控制范围时用；bbox 各方向多留 0.05°，否则边界处等时圈会“撞墙” |
| Overpass API | 直接按 `way["highway"](...)` 取 XML；必须带 `(._;>;);` 才会把节点一并取出，否则得到无坐标空壳 | 小范围验证最快 |

- 三者同源（OSM 主库，ODbL），差异只在“切哪一块、什么时候切”。
- **不建议直接用武汉 13 区外接矩形**（`113.696546,29.971758,115.076846,31.363321`，由蔡甸/新洲/江夏/黄陂撑开）：矩形 20,407 km² vs 市域 8,575 km²，**2.38 倍**，会混入孝感/黄冈/鄂州/咸宁路网，既浪费又让连通性验收口径混浊（孤立片段会让拓扑“看起来正常”）。省界切片至少不跨省。
- 用省界数据的副作用：武汉边界处等时圈会真实伸到孝感/黄冈，属正常现象，需在 README 说明。

## 2. 本机导入链路（实测可用）

`D:\PostgreSQL18.4\data\18\bin` 下 `osm2pgrouting.exe` 3.0.0 / `shp2pgsql` / `pgsql2shp` 齐备；依赖 DLL（`libexpat-1.dll`、`libpq.dll`、`libgcc_s_seh-1.dll`、`libwinpthread-1.dll`）都在同目录，可直接运行。GDAL 3.9.2，OSM 驱动只读支持 `.osm`/`.pbf`。

关键参数：

```powershell
& "$BIN\osm2pgrouting.exe" -f D:\osm_data\hubei.osm.pbf `
  -c "$BIN\mapconfig_for_pedestrian.xml" `
  -d Spatial -U postgres -h localhost -p 5432 `
  --clean --prefix walk_ --attributes -W
```

- `-c` **必须显式指定**，默认值 `/usr/share/osm2pgrouting/mapconfig.xml` 在 Windows 上不存在。
- 步行配置在 `bin` 目录下：`mapconfig_for_pedestrian.xml` 已含 `residential/pedestrian/path/footway/steps` 等标签；另有 bicycle/car 版本。
- `--attributes` 才会拆出 `highway`、`name` 等列；`--prefix walk_` 得到 `walk_ways` / `walk_ways_vertices_pgr`，与 `poi`、`grid_500m` 隔离。
- `-W` 交互输入密码，避免密码进 shell 历史。

## 3. 生效的坑（都是实测踩到才发现的）

1. **QGIS 打开 pbf 只见点**：OGR OSM 驱动把同一 pbf 拆成 5 层 `points / lines / multilinestrings / multipolygons / other_relations`；QGIS 默认只加第一层 `points`（含所有 POI 与道路拐点节点）。**路在 `lines` 层**，用“添加矢量图层”勾选 `lines` 即可。数据本身没丢：湖北全省 `lines` 实测 `unclassified 57371 / residential 43991 / service 41879 / tertiary 22719 / footway 18540 / motorway 18460 / primary 13704 / secondary 13057`。样式要细线（0.26–0.5 mm），否则十几万条线糊成黑色又被误判成“没数据”。
2. **GDAL OSM 驱动 + 中文用户名临时目录会失败**：报 `Cannot create C:\Users\??????\AppData\Local\Temp\osm_tmp_nodes_...`（ANSI 编码把中文用户名变成 `?`）。改 `TEMP`/`--config CPL_TMPDIR` 到纯 ASCII 目录（如 `D:\osm_tmp`）即可。**推论：pbf 与临时目录都应放在纯英文路径**，当前 pbf 所在 `...\服务设施可达性分析平台\serviceAnalysis\data` 含中文，导入前应复制到 `D:\osm_data\`。
3. `ogrinfo -dialect SQLite` 对 OSM 层不支持 `ST_MaxX` 等空间函数（`no such function`），按 bbox 过滤需换表达式或先导出。
4. **QGIS 里看到线 ≠ 有拓扑**：等时圈需要 `source/target/cost` 的图，那一步由 `osm2pgrouting`（内部调 `pgr_createTopology`）完成。
5. **`cost` 单位必须核验**：步行 config 的 cost 源自 OSM `length`，不是必然为米。用 `ST_Length(geom::geography)` 对照一条已知路（如珞喻路 ≈ 2 km 量级）；量级不符就加 `cost_m` 列重算——否则 800 m 预算按“度”算会把全城圈进来。

## 4. 导入后验收 SQL（先跑这两条，再谈等时圈）

```sql
-- ① 连通分量：最大分量占比 >80% 健康；50–80% 可跑但会缺角；<50% 先修
SELECT component, count(*) AS nodes
FROM pgr_connectedComponents('SELECT id, source, target, cost FROM walk_ways')
GROUP BY component ORDER BY nodes DESC LIMIT 5;

-- ② 单位核验
SELECT id, name, cost, ST_Length(geom::geography) AS real_m
FROM walk_ways WHERE name LIKE '%珞喻路%' ORDER BY real_m DESC LIMIT 5;
```

- 中国 OSM 小区/校园内部路大面积缺失，分量数天然多，要看**最大分量的绝对规模能否覆盖研究区**，不只看比例。
- 若连通性“异常地好”（接近 100%），反而要查是否被粗容差焊在一起（例：跨长江的 `footway`）。
- 统计“市外边”：`LEFT JOIN (SELECT ST_Union(geom) g FROM admin_area)` 后 `NOT ST_Intersects`；保留它们不影响起点在武汉内的等时圈，但要在文档注明数据范围。

## 5. 建议执行顺序

小范围 Overpass `.osm` → 导入 + 连通分量体检 → 确认 cost 单位 → 单点等时圈全链路跑通 → 换 Geofabrik 湖北分片重跑 2–4 步。先跑小数据，因为问题在小数据上一眼能看出；上全城后数量级变化会让任何异常都显得“可能正常”。

## 6. 源文件与路径

- 数据：`serviceAnalysis/data/hubei-261102.osm.pbf`（53.6 MB）
- 库：`Spatial`（PostgreSQL 18.4 / PostGIS 3.6.2 / pgRouting 4.0.1）
- 工具：`D:\PostgreSQL18.4\data\18\bin\`（osm2pgrouting、mapconfig_*.xml、shp2pgsql）
- 临时目录：`D:\osm_tmp`（纯 ASCII）
