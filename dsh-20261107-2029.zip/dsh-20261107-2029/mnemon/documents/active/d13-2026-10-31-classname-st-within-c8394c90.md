---
id: "c8394c90-f05c-4973-bb3e-be44d6f1e3bf"
title: "D13 分析模式进入逻辑落地（2026-10-31）：双入口接线、底图灰化的 className 做法、ST_Within 边界口径实测"
description: "D13 分析模式第一步的实际实现记录：analysis store 字段与 action、卡片/顶栏两个入口的接线、LayerPanel↔AnalysisToolbar 切换、SearchBox muted、底图/注记挂 className 实现\"只灰底图不灰分析要素\"的正确做法（含 OL 合并同 className 容器的实测发现）、CDP 实点验证数据、3 工具去缓冲区的取舍、以及必须与 within/nearby 口径对齐的 ST_Within vs ST_Covers 边界实测（138/139）与待拍板事项。"
status: "active"
created_at: "2026-10-31T07:49:55.799Z"
updated_at: "2026-10-31T07:49:55.799Z"
content_hash: "cae123a646ee0633e2605bdfb080d6ce16ae2d9fb477ca6e21f26014557875bf"
source_paths:
  - "FE/src/stores/analysis.js"
  - "FE/src/components/AnalysisToolbar.vue"
  - "FE/src/components/TopBar.vue"
  - "FE/src/components/SearchBox.vue"
  - "FE/src/components/PoiDetailCard.vue"
  - "FE/src/view/mapView.vue"
  - "FE/src/App.vue"
  - "FE/src/style.css"
  - "FE/docs/roadmap.md"
session_ids:
  - "0ff5fc12-4b23-49bd-b1a8-0b904773892a"
memory_body_ids:
  []
---

# D13 分析模式进入逻辑落地（2026-10-31）

背景：用户要求「先写进入分析模式的逻辑」——点 UI 卡片或搜索框旁的分析工具都能进入；进入后搜索框变样式、图层控制面板换成分析工具面板、整个地图变灰。本文记录这一步实际怎么做的、哪些是实测验证过的、以及它和空间查询口径的耦合点。

设计阶段的结论（为什么是两个入口共用一个 store、为什么不是二选一）见 `b14cafea-9e0d-4037-97df-74891bdb4b59`；空间查询选型见 `aac88bd9-69ac-4d43-8d3e-21de64c49f18`。本文只补落地细节与新增实测。

## 1. 新增文件

| 文件 | 内容 |
|---|---|
| `FE/src/stores/analysis.js` | 新增。`active / tool / radius / categories / center / result` + 9 个 action |
| `FE/src/components/AnalysisToolbar.vue` | 新增。纯展示组件，和 LayerPanel 同一路数（props 进、emit 出，不碰 store） |

`center` 约定为 `{ lon, lat, name }`，`radius` 默认 800，`categories` 默认全选（school / hospital / mall / park）。

## 2. 改动接线

| 文件 | 改动 |
|---|---|
| `FE/src/App.vue` | 两个入口接线：TopBar `@tool` → 切换分析模式（`center = null`）；PoiDetailCard `@nearby-analysis` → `analysis.enter({ center: poi })` 同时 `selection.clear()`；左侧面板用 `v-if / v-else` 在同一位置切换 `LayerPanel` ↔ `AnalysisToolbar` |
| `FE/src/components/TopBar.vue` | 「分析工具」按钮从 `disabled` 改为可切换态；进入后显示分析模式徽章（呼吸动效） |
| `FE/src/components/SearchBox.vue` | 新增 `muted` prop → `.is-muted`（背景变灰、图标变淡） |
| `FE/src/components/PoiDetailCard.vue` | 新增 `nearby-analysis` 事件，按钮点出去带当前 POI |
| `FE/src/view/mapView.vue` | 底图/注记图层挂 `className: 'ol-layer-base'`；容器按 `active` 绑 `is-analysis` |
| `FE/src/style.css` | 灰化规则 + 分析模式十字光标 |

## 3. ★ 地图变灰的正确做法（本次最有复用价值的一条）

**不要给 `#map` 整体加 `filter: grayscale(1)`。** 那会把红色缓冲圈、测距线、POI 图钉一起灰掉，分析要素失去视觉优先级。

正确做法是只给底图/注记图层挂自定义 class，再由 CSS 只对那个类加滤镜：

```js
// mapView.vue —— className 是 OL 图层的正规选项
new TileLayer({ className: 'ol-layer-base', source: createBaseSource(...) })
```

```css
#map.is-analysis .ol-layer-base {
  filter: grayscale(1) brightness(1.04) contrast(0.96);
}
```

依据：OL 源码 `Layer.js` 有 `@property {string} [className='ol-layer']`；canvas 渲染器里 `container.className = layerClassName`（`VectorLayer.js / TileLayer.js / ImageLayer.js` 等均继承该行为），所以类确实落在渲染容器元素上。

**实测发现**：base 和 anno 两个图层挂**同一个** className 时，OL 会把它们合并进同一个容器 —— 渲染后 DOM 里只有一个 `.ol-layer-base`，一条 CSS 同时生效。想要分开灰/不灰时要注意这个合并行为。

结果：底图、注记变灰；POI 图钉、区划线保持彩色，符合设计稿意图。若要连 POI 一起灰，把 className 也挂到 POI 层即可，但不建议——图钉会失去类别配色。

## 4. 验证方式与实测数据（不是肉眼看的）

用无头 Chrome + CDP 实际点击，核对渲染后的 DOM 与计算样式。要点：**先统计 class 属性命中的元素，不要用字符串包含判断**——第一版检查把 `<style>` 文本里的类名也数了进去，误报 `tool-panel: 1`。

```
【浏览模式】
layerPanel: 1, toolPanel: 0, modeBadge: 0
mapClass: "", baseFilter: "none", searchMuted: false, mapCursor: "auto", toolBtnActive: false

【点「分析工具」后】
layerPanel: 0, toolPanel: 1, modeBadge: 1
mapClass: "is-analysis"
baseFilter: "grayscale(1) brightness(1.04) contrast(0.96)"
searchMuted: true, mapCursor: "crosshair", toolBtnActive: true
tools: ["点选","框选","测距"], radiusText: "800 m"
cats: ["学校","医院 / 诊所","商场 / 超市","公园"]

【再点一次 → 退出】全部回到浏览模式
```

卡片入口（先让详情卡出现再点「附近分析」）：

```
analysisActive: true, tool: "point", radius: 800
center: { lon: 114.292598, lat: 30.610841, name: "解放公园" }
cardClosed: true, toolPanel: 1, mapClass: "is-analysis"
面板底部: "中心：解放公园"
```

坑：CDP 序列化 Vue 响应式对象时 `center` 会变成 `{}`，看着像丢数据；用 `JSON.stringify` 后取 `centerJson` 才是准的（`{"lon":114.292598,"lat":30.610841,"name":"解放公园"}`）。**别据此判断丢参。**

验证用的临时脚本 `_cdp-check.mjs`、`_cdp-entry2.mjs` 用完即删，未留在仓库。

## 5. 一处按判断改的设计：3 个工具而不是 4 个

设计稿是「点选 / 框选 / 缓冲区 / 测距」，实际做成**3 按钮 + 1 滑杆**，去掉了「缓冲区」：缓冲区是「以点为中心向外扩」这个动作，已由半径滑杆表达，做成按钮等于一个永远按下的死键。

另补两个设计稿没有的细节：测距模式下半径与类别置灰（量距离不需要选类别）；面板右上角加 ✕，否则退出只能回顶栏找。

## 6. 与空间查询口径的耦合：ST_Within 不含边界（本次新实测）

分析模式下一步是点选圆心画圆（`ST_DWithin` + geography）与框选多边形（`/api/poi/within`）。框选这条必须先定口径，因为 `ST_Within` / `ST_Contains` **都不含边界**：

| 点的位置 | `ST_Within` | `ST_Contains` | `ST_Covers` | `ST_Intersects` |
|---|---|---|---|---|
| 内部 | t | t | t | t |
| 在边上 | **f** | **f** | t | t |
| 在顶点上 | **f** | **f** | t | t |
| 外面 | f | f | f | f |

（同一正方形对 4 个构造点实测；原因是 DE-9IM 要求 A 内部与 B 内部相交，点落在边界上只与 B 的边界相交。）

在真实库上构造「框左边界正好穿过某个 POI」的场景（x = 114.292598，即「解放公园」的经度）：`ST_Within` 得 **138** 条，`ST_Covers` / `ST_Intersects` 得 **139** 条，差的那条正是 `gid=1`。**用户直觉是「框住了就算」，`ST_Within` 会莫名少一个。**

同时确认了 13 区划场景没有这个问题：16016 个 POI 中 **0 个**落在区界上，按 Covers 统计每个 POI 恰好被 1 个区覆盖，落在所有区外也是 0 —— 所以区划统计两函数无差别，**只有用户手画的框**（像素对齐容易压过点）会暴露差异。

结论与待办：用户画框选设施建议改用 `ST_Covers(面, 点)`；若改，`countByCategoryWithin` 与 `itemsWithin` **两条 SQL 必须同步改**，否则右侧计数与列表会差一条，测试期望值 125 也需重核。此项当时留待用户拍板，**尚未改动**。

## 7. 状态与下一步

`vite build` 211 modules 通过、退出码 0；dev server 七个模块均 200。

现在进入分析模式后**地图上还没有任何反应**——点选圆心、画圆、出结果都未接。按 roadmap 顺序：

1. `useBufferAnalysis.js`：点地图取坐标 → 画圆 → 调 `/api/poi/nearby`
2. `AnalysisResult.vue`：覆盖数 / 分类占比 / 最近设施
3. 框选 + 测距：Draw 交互 + 3857→4326 投影转换

已同步 `FE/docs/roadmap.md`（§2.4 D13 分析模式进度、新增 §2.4.1「分析模式下地图变灰的正确做法」）。

## 相关文档

- `b14cafea-9e0d-4037-97df-74891bdb4b59` —— D13 入口设计决策（双入口单 store 的由来）
- `aac88bd9-69ac-4d43-8d3e-21de64c49f18` —— ST_Within vs WFS CQL 选型实测（geography 无 ST_Within、小表全表扫描判读、GeoServer 缺 gid）
- `266aea70-7a25-4d94-8359-39555b8b651f` —— 项目总体设计与里程碑
