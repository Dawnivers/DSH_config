---
id: "6f82fe74-64d3-4573-ba22-d123fae844c0"
title: "D13 /api/poi/within 落地：最终契约、6 道校验、错误 message 配置，以及测试双编码陷阱（2026-10-31）"
description: "GET /api/poi/within 已实现后的最终契约、6 道校验与错误文案、include-message 存量缺陷、Double 科学计数法与 TestRestTemplate 双编码陷阱、psql 交叉核对基线、投影 3857→4326 的前端入口坑。"
status: "active"
created_at: "2026-10-31T03:24:10.595Z"
updated_at: "2026-10-31T03:24:10.595Z"
content_hash: "6ef57411ad0a88eea7b4924ea42724fed6842781fb1de1cb729c2c3619df50b7"
source_paths:
  - "BE/src/main/java/com/dawnivers/be/controller/PoiController.java"
  - "BE/src/main/java/com/dawnivers/be/service/PoiService.java"
  - "BE/src/main/java/com/dawnivers/be/mapper/PoiMapper.java"
  - "BE/src/main/resources/mapper/PoiMapper.xml"
  - "BE/src/main/resources/application.properties"
  - "BE/src/test/java/com/dawnivers/be/PoiApiTest.java"
  - "FE/docs/roadmap.md"
session_ids:
  - "52e2a3fc-0ad4-4ab7-80df-bb1e5ec07483"
memory_body_ids:
  []
---

## 定位

`GET /api/poi/within` 的**已落地实现记录**。选型论证（PostGIS `ST_Within` vs GeoServer WFS CQL `INTERSECTS`、函数一致性与小表全表扫描判读）见文档 `aac88bd9-69ac-4d43-8d3e-21de64c49f18`，本文只记实现后的真实契约、校验边界、错误面与踩坑。

前端绘制与调用尚未开始（本轮明确「先不用做前端」）。

## 1. 最终接口契约

```
GET /api/poi/within?wkt=POLYGON((...))&limit=20
```

- `wkt`：**必须 URL 编码**（前端 `encodeURIComponent`）。实测武大三角形编码后 84 字符。
- `limit`：默认 20，允许区间 `(0, 200]`。
- 不存在的参数键一律不存在——与项目既有约定一致（键恒存在、缺值 `null`、全驼峰）。

```jsonc
{
  "count": 125,
  "areaKm2": 5.85,
  "centroid": { "lon": 114.366667, "lat": 30.536667 },
  "byCategory": { "school": 98, "hospital": 10, "mall": 14, "park": 3 },
  "items": [
    { "gid": 2745, "name": "武汉大学国学院(珞东一路)", "category": "school", "distanceM": 106 }
  ]
}
```

### 与 `nearby` 有意不同的两处（设计决定，不是疏漏）

1. **列表字段叫 `items` 而非 `nearest`**。多边形没有圆心，排序基准是**形心**（`ST_Centroid`），叫 `nearest` 会误导为「与某设施的距离」。形心已实测落在凹多边形内部（`ST_Contains(geom, ST_Centroid(geom))` = true）。
2. **每个 item 带 `gid`**。`nearby.nearest` 没有 gid，但分析结果列表要能点回详情，而详情接口 `/api/poi/{gid}` 只认 gid——不带 `gid` 链路就断。这条与 WFS 方案拿不到 gid 的问题（见 `aac88bd9`）同源。

## 2. 服务端 6 道校验与错误文案

坏几何在 PostGIS 里**不抛异常，而是返回 0 条**，前端会以为「这片区域没有设施」，排查无线索。因此单独做一次 `inspectWkt`（`ST_IsValid` + 面积 + 形心一次取回，省一次往返），坏几何明确 400。

| 输入 | 状态 | message 示例 |
|---|---|---|
| 自相交 / 退化多边形 | 400 | `wkt is not a valid polygon (self-intersecting or degenerate?)` |
| `POINT`、`LINESTRING` 等非面 | 400 | `wkt must be POLYGON(...) or MULTIPOLYGON(...)` |
| WKT 语法错误 | 400 | `wkt cannot be parsed: 错误: parse error - invalid geometry` |
| 空 WKT / 缺 `wkt` | 400 | `Required parameter 'wkt' is not present.` |
| 面积超限（>20000 km²） | 400 | `polygon too large: 21831103.49 km², max 20000.00` |
| `limit` 越界 | 400 | `limit must be in (0, 200], got 999` |

面积上限取 20000 km²：全国范围多边形实测被拦下（2.18e7 km²），而武汉全域量级正常放行。

## 3. 四个实现级陷阱

**① `include-message=always` 是必须项，且是存量缺陷**
Spring Boot 3 默认 `server.error.include-message=never`，400 响应体只有 `{timestamp,status,error,path}`。对 `within` 尤其致命——自相交、非面、面积超限三种都是 400，前端无法区分原因。该缺陷**连既有的 `nearby` 400 也一起中招**，改 `application.properties` 后两个接口都恢复带 `message`。

**② `Double.toString` 会把面积变成科学计数法**
首版拼出 `polygon too large: 2.183110349E7 km²`。超 1e7 自动切科学计数法，改用 `BigDecimal.toPlainString()`。

**③ 解析错误消息自带换行**
PG 的 parse error 文本含换行，需要清洗后再拼进 message。

**④ 测试里 URL 被编码两次（`TestRestTemplate`）**
`UriComponentsBuilder.encode().toUriString()` 的结果交给 `TestRestTemplate` 会再编一遍：`%20` → `%2520`，服务端收到乱码 WKT 返回 400，测试里表现为 `Expecting actual not to be null`（因为 `getForObject` 对 4xx 返回 null），**看起来像接口坏了，其实只是测试写法问题**。改用模板变量 `?wkt={wkt}` 让 `TestRestTemplate` 自己编码即可。前端用 `encodeURIComponent` 一次就够，不受此影响。

排查提示：这类失败先确认是 4xx 还是空数据，`getForObject` 的 null 不具有区分力。

## 4. 测试策略与验证基线

`PoiApiTest` 现 6 个用例全绿，期望值**全部来自 psql 独立查询，不从实现反推**：

- 学校周边 800 m：`count=124` / school 109 / park 3 / 最近 = 武汉大学-教1楼 53.0 m；另有一条纯内部自洽断言（四类之和 == count）。
- 覆盖统计 420106：`total=1681` / `areaKm2≈100.06` / `perKm2≈16.8` / park 119。
- POI 详情 gid=1：解放公园 / `027-82421760` / 3 张照片。

`within` 的三条正常用例均与 psql 交叉核对一字不差：

| 形状 | count | areaKm2 |
|---|---|---|
| 三角形（武大） | 125 | 5.85 |
| 矩形（东湖） | 3 | 4.25 |
| **凹多边形** | 406 | 16.49 |

凹多边形是刻意选的——最容易暴露「形心在多边形外」导致的 ordering 解释错误。MULTIPOLYGON 用例结果与三角形一致（125 / 5.85）。5 个存量接口（`/api/hello`、`/api/poi/1`、`/api/poi/nearby`、`/api/stats/coverage`、`/api/areas`）回归全 200。

## 5. 性能：不走索引不是问题

`ST_Within` 是 bbox-aware 函数，有 GiST 索引时会自动使用；但当前 16016 行 / 3876 页，优化器判全表扫描更快（实测 69 ms），`enable_seqscan=off` 也不切。数据涨到几十万行会自然切过去，**不需要任何改动**。

## 6. 改动面

新增 4 个 DTO：`WithinDto` / `WithinItem` / `LonLat` / `WktInfoDto`；`PoiMapper.java` + `PoiMapper.xml` 加 3 个方法（`inspectWkt` / `countByCategoryWithin` / `itemsWithin`）；`PoiService` 加 `within()` 与校验；`PoiController` 加 `/within`；`application.properties` 加 `server.error.include-message=always`；`PoiApiTest` 加 3 个用例。

## 7. 下一步（接前端时最容易卡的一处）

```js
new WKT().writeGeometry(geom, {
  dataProjection: 'EPSG:4326',                              // ★ 必须是 4326
  featureProjection: map.getView().getProjection(),          // 画布是 3857
})
```

不转投影时 `ST_Within` 返回 **0 条且不报错**——这是整条链路最隐蔽的失败模式。
