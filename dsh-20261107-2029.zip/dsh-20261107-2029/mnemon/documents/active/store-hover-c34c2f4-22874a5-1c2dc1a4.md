---
id: "1c2dc1a4-c230-4c66-bb6e-8b25137f4bd7"
title: "悬停模式解析改为事件内回读 store：热力图 hover 完全失效的根因、修复（c34c2f4）与低缩放提示（22874a5）"
description: "热力图悬停“完全没反应”的根因排查与修复记录：watcher 同步到 hover 内部 mode 的中间状态不可靠且无反馈，改为 createHoverController(map,{resolve}) 每次 pointermove/探针前现读 store；低缩放不再静默而在光标旁跟随浮提示；含为何单靠浏览器工具验不到 pointermove。"
status: "active"
created_at: "2026-11-01T12:43:27.445Z"
updated_at: "2026-11-01T12:43:27.445Z"
content_hash: "5fcbb1d101f50ddfdab7710a3c3da702617ead3c2e4fc5a6793f32ea64cf4936"
source_paths:
  - "FE/src/map/hover.js"
  - "FE/src/view/mapView.vue"
  - "FE/src/map/probe.js"
  - "FE/src/map/gridInfo.js"
session_ids:
  - "26290233-2401-4321-92ba-ec2792aa440e"
memory_body_ids:
  []
---

# 热力图悬停失效：从「缓存模式」改成「每条事件现读 store」

承接 `3b390220-5bbb-4d43-b8ca-60b0421972db`（probe.js 统一探针 + hover.js 双层描边/光圈，提交 `e210f79`）。该文档描述的是**设计意图**；本文记录上线后用户实测暴露的真实缺陷、根因与改法，是 hover 实现的**修正版**，阅读时以本文的模式管理方式为准。

相关：`b4346af9-bbcb-47b6-b128-5f360391455d`（F4 点格弹窗、GetFeatureInfo 的 101×101 窗口与 bbox 前提、PickGrid 三道防线）。

## 1. 症状

- POI 悬停：**正常**（光圈 + 名称）。
- 勾上「可达性热力图」后悬停格子：**完全没有任何反应** —— 不只是没有描边，连为低缩放准备的那句「放大到 z11 才能选格子」提示也不出现。

这条对比很关键：提示和描边**同在一个 `mode === 'grid'` 分支里**。两种反馈同时缺席，说明问题不在样式、不在探针返回、也不在缩放门槛，而是 **`mode` 根本没变成 `'grid'`**。

## 2. 根因：watcher → 控制器内部变量的中间状态

旧实现把「当前该查谁」缓存进了 hover 控制器：

```js
// mapView.vue（旧）
hover = createHoverController(map);
syncHover();                                   // 初始对齐
registerWatcher('hover', () => [analysis.active, visible.heat, visible.poi], syncHover);

function syncHover() {
  if (analysis.active) hover.setMode(null);
  else if (visible.heat) hover.setMode('grid');
  else if (visible.poi) hover.setMode('poi');
  else hover.setMode(null);
}
```

失效路径：只要 watcher 没有按预期触发（或触发时 `hover` 尚未建好、被赋成 `null` 后早退），`mode` 就**永远停在旧的 `'poi'`**。此后在热力图上悬停，程序问的是「这点有没有 POI」→ 没有 → `clear()` → 用户看到的是**彻底失灵**，且没有任何日志或提示能把「mode 没切」这件事暴露出来。

教训（可复用到本项目所有 map 控制器）：

> 派生状态（store → 控制器内部枚举）一旦被缓存，就必须为「同步失败」设计一个可观测的出口；否则故障表现与「功能没实现」完全相同，排查成本极高。

## 3. 改法（`c34c2f4`，2 files / +60 −33）：拉模式取代推模式

不再缓存，**每次鼠标移动、每次发探针前都重新问一遍 store**：

```js
// hover.js
export function createHoverController(map, options = {}) {
  const resolve = () => options.resolve?.() ?? null;

  function currentMode() {
    const next = resolve() ?? null;      // 现读，不缓存
    if (next !== mode) { /* 切模式：清场、清 lastPixel/lastId */ }
    return mode;
  }
  // onMove 与 run 开头都调用 currentMode()
}
```

```js
// mapView.vue：把判断逻辑作为回调传入，不再写 syncHover / setMode
hover = createHoverController(map, {
  resolve() {
    if (analysis.active) return null;
    if (layerStore.visible.heat) return 'grid';
    if (layerStore.visible.poi) return 'poi';
    return null;
  },
});
```

配套清理：

- 删掉 `setMode` 与 `syncHover`，对外只留 `clear()` / `reset()` / `destroy()`；`reset()` 供外部状态突变（进出分析模式）后立刻清残留高亮。
- `unByKey(pointermove)` + `map.removeLayer(layer)` 仍在 `destroy()` 里，卸载不留监听与图层。
- 调试输出 `[hover] 模式 → poi|grid` 限定在 dev，避免生产刷屏。

**取舍**：`resolve()` 在每次 pointermove 上执行，代价是与 store 三次布尔比较（远小于 90 ms 节流窗口），换来「不存在同步失败状态」。在事件驱动的三维/地图控制器里，这条交换几乎总是值得的。

## 4. 低缩放不再静默（`22874a5`，1 file / +22 −2）

`MIN_GRID_ZOOM = 11` 的门槛依据见前文文档（101×101 查询窗口在 z9 宽约 30 km，返回要素与鼠标位置无关；z11 起 1–2 个候选且命中正确）。但原实现直接 `clear(); return;`，用户只得到「坏了」的结论。

改为在光标旁浮提示，且**复用同一个 Feature 只改坐标**，避免每次 mousemove 重建样式：

```js
if (mode === 'grid' && zoom < MIN_GRID_ZOOM) {
  lastId = '__hint__';
  const existing = source.getFeatures()[0];
  if (existing && existing.get('__hint')) existing.getGeometry().setCoordinates(lastCoord);
  else { /* 新建 tip，标记 __hint，setStyle(hintStyle(...)) */ }
  return;
}
```

注意点：提示必须跟着光标走（早前一版把坐标固定在首次位置，看着像卡死）；`__hint` 标记用于区分「这次是提示还是真高亮」，否则复用逻辑会把真正的格子描边改成提示。

## 5. 验证边界（必须由用户协助）

浏览器自动化工具**只能按元素索引点击，无法在地图画布上移动鼠标**，因此 `pointermove` 全链路无法自验。自查能做的只有 `pnpm build`（269 modules，~310 ms，通过）与页面无异常加载；所以本轮改动**未经渲染验证**，交给用户按下列顺序确认：

1. 刷新后动鼠标 → Console 出现 `[hover] 模式 → poi`
2. 勾「可达性热力图」再动 → 出现 `[hover] 模式 → grid`（关键判据）
3. z9 时应在光标旁看到「放大到 z11 才能选格子」
4. 放大到 z12–z14 悬停 → 深蓝外框 + 白内框 + 「N 个」标签

若第 2 步没有出现 `grid`，问题在 `layerStore.visible.heat` 没被置 true（图层面板与 store 脱钩），而非 hover 本身；若出现了但仍无框，则要看 Network 里 `GetFeatureInfo` 的 Response（空 features / 200+XML 报错 / 几何被判不包含）。

## 6. 提交

```
e210f79  08 悬停高亮：抽出 probe.js 统一探针（初版，setMode + watcher）
22874a5  09 悬停：低缩放不再静默失效，光标旁跟随提示
c34c2f4  10 修悬停热力图不生效：模式改为每次事件现读 store（resolve 回调）
```

均已推送 `Dawnivers/ServiceAvailable` main。
