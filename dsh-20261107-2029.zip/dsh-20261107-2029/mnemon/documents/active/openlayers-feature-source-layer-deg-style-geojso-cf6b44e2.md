---
id: "cf6b44e2-269d-4d09-bc00-35b7836b1ce1"
title: "本项目 OpenLayers 渲染链路：Feature/Source/Layer 职责、deg→style 上色、GeoJSON coordinates→3857 Polygon，以及 drawend 时序坑（要素在 dispatch 之后才入 source）"
description: "前端叠加/绘制图层的渲染数据流记录：z100 绘图层与 z99 结果层的分工与填充透明度理由、overlayResultStyle 按 deg 上色、几何数组由 ST_AsGeoJSON 写/readFeatures 解析/Canvas 渲染器逐帧转像素的接力、两次坐标系变换、以及 drawend 时 Feature 尚未入 source 导致\"两个圆心\"/removeFeature 删不掉的复现与 setTimeout 0 修法。"
status: "active"
created_at: "2026-11-02T13:11:14.202Z"
updated_at: "2026-11-02T13:11:14.202Z"
content_hash: "e96f807953600038ddfe5e05a00f2c4f5124b69aac82bfc0a640fefe3a8e2391"
source_paths:
  - "FE/src/map/drawing.js"
  - "FE/src/view/mapView.vue"
  - "FE/src/stores/analysis.js"
  - "BE/src/main/resources/mapper/PoiMapper.xml"
session_ids:
  - "eb53dbac-d75a-48c4-838a-55d8c13317f2"
memory_body_ids:
  []
---

# 本项目地图渲染链路（FE/src/map/drawing.js 为中心）

配套记录：叠加分析的 SQL 与接口见 `ba6de451-a7df-45f6-a031-d8f4a2ca66d9`，
叠加模式下可调面/activeShapeId 见 `29c3b714-0c26-4c43-a9e9-8b6cd26a6a6b`，
缓冲圈 3857 口径见 `564a4172-29af-4a5a-a5a8-87b0a8821d51`。

## 1. 两个图层各管一段（z99 / z100）

| 图层 | zIndex | source 里是什么 | 谁往里加 | style 函数 |
|---|---|---|---|---|
| 绘图层 | 100 | 用户画的圆/框/自由面（最多 6） | `draw.on('drawend')` 后由 Draw 自己 add | `analysisStyle` |
| 结果层 | 99 | 后端平面细分出的原子面 | `setOverlayResult()` 里 `addFeatures` | `overlayResultStyle` |

- 结果层不删绘图层：画 2 个面 → 屏幕 5 个面 = 2（轮廓，z100）+ 3（原子面，z99）。
  「你画的 A」在概念上被切成「A 独占 + 中间」两块，但原始轮廓仍压在上面。
- 原子面块数**由几何决定，不是写死 3**：不相交 2 块、正常相交 3 块、一个切另一个 4 块；
  3 个面两两相交是 7 块。前端一行不用改。
- 绘图层填充只有 `FILL_ALPHA≈0.06`：再高会盖住下面的实心重叠色块。

## 2. 「按 deg 上色」发生在哪

```js
// drawing.js  overlayResultStyle(feature)
const deg = feature.get('deg');        // 后端 properties.deg
const color = DEGREE_COLORS[deg];      // 1 重 / 2 重 / ...
```

Layer 本身**不知道 deg 是什么**：渲染时它遍历 `source.getFeatures()`，把当前 feature
作为参数递给 style 函数，函数读 `get('deg')` 返回 Style，Layer 拿 Style 去画。
所以「3 个原子面 3 种颜色」是 style 函数逐个求值的结果，不是图层的某个样式参数。

## 3. 几何数组由谁确定：四段接力

```
PostGIS ST_Polygonize + ST_Dump → 每块一行 POLYGON（经纬度顶点串）
ST_AsGeoJSON(..., 6)::json       → coordinates 三层嵌套数组（4326，6 位≈0.11 m）
new GeoJSON().readFeatures(fc, {dataProjection:'EPSG:4326', featureProjection: proj()})
                                 → ol/geom/Polygon（3857，米）
Canvas VectorLayer 渲染器         → 每帧 getPixelFromCoordinate → 像素路径 → fill/stroke
```

要点：

- 没有人手工拼数组，两端都是现成序列化/解析函数；`coordinates` 是 `[环][点][x,y]`，首尾点相同表示闭合。
- `readFeatures` 之后几何**不再是数组**，要用 `feature.getGeometry().getCoordinates()`（单位已是 3857 米，如 12722070）。
- 两次坐标变换：4326 →（readFeatures）3857 →（渲染时）屏幕像素。所以平移缩放不重发请求，只重算像素。
- 唯一需要自己操心的是 `dataProjection`/`featureProjection`；写错的表现是「地图一片空白但控制台不报错」。

## 4. Feature / VectorSource / VectorLayer 的关系（易混点）

```
Feature（几何 + properties + 可选要素级 style）← addFeature ← VectorSource（数组 + change 事件）← 构造传入 ← VectorLayer
```

- **没有反向引用**：Feature 不知道自己在哪个图层；同一个 Feature 可以同时存在于多个 Source。
- 几何单独存在 `geometry_`，`feature.get('geometry')` 取不到，必须 `getGeometry()`。
- 样式优先级：`Feature.getStyle()` > `Layer` 的 style 函数 > 默认。本项目悬停/选中层用要素级样式，
  因为只画一个要素、不必写判断分支。
- 删除是 `source.removeFeature(f)`（对象仍在内存），`clear()` 见下方时序注意。

## 5. drawend 时序坑（本项目实测过的真 bug）

`drawend` 触发时 **Feature 还没进 source**：Draw 是先 `dispatchEvent('drawend')`，之后才 add。
所以回调里立刻操作 source 会漏掉刚画的要素，表现为两种症状：

| 症状 | 原因 |
|---|---|
| 点选后出现「两个圆心」 | `paintCircle()` 立刻执行时清不到新要素 |
| 超过 6 个面时 `applyShapeMeta/removeFeature` 删不掉 | 同样是因为要素尚未入 source |

修法（`drawing.js`、`mapView.vue` 两处都用同一招）：**推到下一拍**，那时要素已在 source 里。

```js
draw.on('drawend', (e) => { ...; setTimeout(paintCircle, 0); });

if (!ok) setTimeout(() => drawing?.applyShapeMeta(analysis.shapes), 0);
```

因果链的准确表述（不要简化成「drawend 直接触发图层重绘」）：

```
drawend → 我们的回调 → Draw 随后把 Feature 塞进 VectorSource
        → source 触发 'change' → 渲染器标记需重绘 → 下一帧 rAF 调 style 函数绘制
```

## 6. 排查取向

| 现象 | 先怀疑 |
|---|---|
| 块数不对（2 面得 5 块） | 后端 `ST_Polygonize/ST_Node` 切分，不是前端 |
| 小碎块变直线 | `ST_AsGeoJSON` 精度（本项目 6 位） |
| 几何飞到地球外、空白无报错 | `readFeatures` 的 `dataProjection`/`featureProjection` |
| 刚画的东西清不掉 / 重复出现 | drawend 时序，检查是否在回调内同步操作 source |
