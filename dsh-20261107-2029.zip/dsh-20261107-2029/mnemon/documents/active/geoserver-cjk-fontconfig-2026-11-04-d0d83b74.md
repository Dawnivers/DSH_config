---
id: "d0d83b74-e759-4dd0-a6f3-699b84fb3a8b"
title: "GeoServer 容器中文标签全是豆腐块：缺 CJK 字体 + fontconfig 别名映射（2026-11-04）"
description: "POI 标签渲染成 □□□ 的根因（eclipse-temurin 基础镜像零中文字体、SLD 写死 Microsoft YaHei）、装文泉驿 + 99-cjk-alias.conf 做字体名映射而不改 SLD 的修法，以及 GetMap/md5 同源验收与「环境资源缺失」类坑的排查顺序。"
status: "active"
created_at: "2026-11-04T12:22:24.080Z"
updated_at: "2026-11-04T12:22:24.080Z"
content_hash: "1236e452e81364c4de22180603cbf3c59b347e987b477ea8ad37d840c4bdac3a"
source_paths:
  - "serviceAnalysis/deploy/Dockerfile.geoserver"
  - "serviceAnalysis/deploy/fonts/99-cjk-alias.conf"
  - "serviceAnalysis/deploy/README.md"
  - "serviceAnalysis/deploy/geoserver_data/workspaces/wuhan/styles/poi_icons.sld"
session_ids:
  - "3dd2ff68-ddaa-4693-8ca4-73bade3feac1"
memory_body_ids:
  []
---

# 中文标签变豆腐块：不是 SLD 错，是容器里没有汉字字形

接续同一天的另一条根因（图标灰方块）：`70a36633-d284-4595-ae45-08eaaabe13a9`。两者是同一类坑的两副面孔——**代码与配置都对，运行环境缺资源**。URL 放行背景见 `ba3a2263-3b2e-4fea-b1c5-f202fe57a8c5`，新机迁移清单见 `c693a398-0925-4054-925c-3e7113eb3131`。

## 1. 症状与判据

图标修好后，公网页面 `https://project4.dawnivers.top/` 街区级 POI 的**名称标签全部是 `□□□`**，图标本身正常。

| 检查 | 结果 | 结论 |
|---|---|---|
| `poi_icons.sld` 里 label 的 `font-family` | `Microsoft YaHei` | SLD 写法没问题 |
| 容器内 `fc-list :lang=zh` | 只有 DejaVu 系（8 个字体，零中文） | ← 真凶 |
| 宿主机是否有现成中文字体 | 无（同样只有 dejavu-sans-fonts） | 无法直接挂载复用 |
| GeoServer 日志 | 干净，无任何字体告警 | 与灰方块一样属静默失败 |

**根因**：`Dockerfile.geoserver` 基于 `eclipse-temurin:17-jre`，该基础镜像只带 DejaVu 西文字体。JVM 在 SLD 里找不到 `Microsoft YaHei`，按 AWT/SWT 兜底行为**把每个汉字画成一个方框**，不抛异常、不写日志。

**为什么本地永远看不到**：开发机是 Windows 版 GeoServer，系统自带微软雅黑，同一份 SLD 直接就好。这是「本地能跑 ≠ 容器能跑」的典型渲染侧表现。

## 2. 修法：装字体 + 映射字体名，不动 SLD

```dockerfile
# Dockerfile.geoserver 新增
RUN apt-get update && apt-get install -y --no-install-recommends \
        fontconfig fonts-wqy-zenhei && fc-cache -f
COPY deploy/fonts/99-cjk-alias.conf /etc/fonts/conf.d/99-cjk-alias.conf
```

关键取舍是**不改 SLD**：`deploy/fonts/99-cjk-alias.conf` 用 fontconfig 别名把 `Microsoft YaHei`、`SimHei`、`宋体`、`黑体` 等 Windows 字体名统一指向文泉驿，于是

- 服务器 → 文泉驿渲染
- 开发机 Windows → 继续用雅黑

同一份 SLD 两边都正确。另外补了 `sans-serif → 文泉驿` 兜底，以后新样式写了个不存在的字体名也不会退回豆腐块。**改字体只改这一个 conf 文件**，不要散落进 SLD。

代价：镜像 677MB → 705MB（+28MB）。

## 3. 验收（可复现）

1. 容器内字体确认：`docker exec sa_geoserver fc-list :lang=zh | wc -l` → `3`；`docker exec sa_geoserver fc-match "Microsoft YaHei"` → `wqy-zenhei.ttc`
2. 渲染必须落在**标签规则生效的比例尺**：`poi_icons.sld` 的 label 规则是 `MaxScaleDenominator ≤ 12000`（实测按约 1:2200 取 GetMap）→ 得到 27KB PNG，标签为真汉字（如「武汉大学国内合作部」「招生就业处组织部」「采购与招标管理中心」）
3. **公网链路同源验证**：走 `https://project4.dawnivers.top/geoserver/...` 取同一 bbox，与直连 GeoServer 的 md5 完全一致（`e8115eba4b00bf7b8ca8f7cc96f2c172`），排除反代缓存或绕过反代的假阳性
4. 四层自检仍通过：前端 200 / BE up / DB 连通 13 / GeoServer 出图 200

## 4. 沉淀的排查纪律

- **渲染相关资源必须显式进镜像或数据目录**：图标文件（`geoserver_data/www/icons/`）、字体（镜像 apt + fontconfig）都算。GeoServer 缺这两类资源时**一律静默降级**（灰方块 / 豆腐块），日志不报错，所以「接口 200 但显示不正常」时先怀疑环境资源，再怀疑样式。
- 样式侧验收要**先确认当前比例尺命中了哪条规则**，否则容易把「概览层本来就是 3px 圆点」误判成渲染失败。
- 修复步骤都写进了 `deploy/README.md`（§④-b 字体、排错表新增「标签是 □□□」一行）与 `deploy/tools/build-geoserver-data.ps1` 的自检项，避免下次重新裁数据目录或重建镜像时复发。
