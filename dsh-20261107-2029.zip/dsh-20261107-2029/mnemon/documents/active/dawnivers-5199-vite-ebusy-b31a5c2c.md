---
id: "b31a5c2c-e322-4a6e-9c37-58b1180eab52"
title: "Dawnivers 个人站「设施可达性分析」详情页交付：可覆写文案字段与 5199 预览 / Vite EBUSY 坑"
description: "第四张项目详情页（?id=serviceAnalysis）的交付记录：6 张 500 米格网/路网分析截图接入、src/project.js 把 stackNote / ctaTitle / ctaNote 从写死改为可由 project-data 覆写（默认值不变）、5199 独立 vite 预览与写文件触发 EBUSY 崩溃的规避方式。承接 5f0698d1 的字段契约、588b214f 的截图与回退经验、aa89a18c 的 mediaAspect。"
status: "active"
created_at: "2026-11-04T13:08:49.880Z"
updated_at: "2026-11-04T13:08:49.880Z"
content_hash: "75921c2766105d9bbe11dd9f0a664ea0bcb1ada11ab38c974a3efbec7c41eec1"
source_paths:
  - "src/project-data.js"
  - "src/project.js"
  - "src/script.js"
  - "vite.config.js"
  - "public/projects/serviceAnalysis"
  - "server.js"
session_ids:
  - "b8e61806-2c05-4b61-a13f-fe8c2ded240d"
memory_body_ids:
  []
---

# 设施可达性分析详情页（`?id=serviceAnalysis`）交付记录

承接 `5f0698d1-06fe-47fc-8382-060face9e80c`（详情页骨架、`project-data.js` 字段契约、`demo.mp4` 自动探测、新增项目四步流程）、`588b214f-8e08-47d1-afc7-46dce0e3d0af`（无图功能卡回退、素材管线）、`aa89a18c-d8b3-40f6-a526-cb72194162eb`（`mediaAspect` 来源）。
页面：`http://localhost:5199/project.html?id=serviceAnalysis`；在线 Demo：`https://project4.dawnivers.top/`。

本页是站内第四张项目卡，沿前三个页面同一套架构：hero → 01 项目目的 → 02 技术栈 → 03 功能截图 → 04 操作演示 → 页尾 CTA。首页卡片原本就有 `id: 'serviceAnalysis'`（`src/script.js` 用 `project.html?id=<id>` 拼链接），所以只需补数据与素材，不动首页。

## 1. 新增能力：详情页部分文案可由数据覆写

`src/project.js` 里有两处写死给三维项目的文案，此次改为"默认值 + 数据可覆盖"：

| 字段 | 原默认（仍保留） | 本页覆写 |
|---|---|---|
| `stackNote` | 从三维底座到数据服务的技术组合 | 从空间数据库到地图前端的整条链路 |
| `ctaTitle` | 想到现场看看？ | 想自己量一段距离？ |
| `ctaNote` | 在线 Demo 需要加载三维瓦片… | 在线 Demo 首次进入要等 GeoServer 出图，缩放和点格会慢半拍… |

原则：**默认值不删**，未声明的页面（metro / community / amap）显示完全不变。后续再接非三维项目时，优先走覆写字段，而不是在 `project.js` 里加 if。

## 2. 素材

`public/projects/serviceAnalysis/` 下六张：`overview / grid / grid-cell / search / route / overlay`，PNG 统一转 JPEG 后每张 260–310 KB，与其它项目一个量级；页面宽度/比例沿用默认 16:9，不需要 `mediaAspect`。
首屏主视觉用 `overview`，六个功能卡与六张图一一对应：格网热力、单格统计、搜索详情卡、直线 vs 路网、多面叠加、全市底图。

## 3. 正文口径（按截图实数，不编造）

- 数字概览：16,016 个设施点位 / 13 个行政区 / 500 m 格网 / 40%（直线口径虚高，由 50 → 30 那组实测得出）。
- 关键数字：单格 214 个设施 = 全市 57 倍，分类坡度 86.1 / 63.2 / 27.5 / 14.7 倍；搜索「武汉」命中 3,774 条、地址 383 条；起点吸附偏移 37 m、查询 77 ms；叠加并集 1.99 km² 覆盖 72 个设施，重叠 0.15 km² 内 4 个 2 重。
- 文案主线是"判断"而不是功能罗列：为什么要用路网代替圆（长江/铁路/封闭厂区切断直线）、为什么用倍数而不是绝对个数、为什么吸附偏移与 50 m 缓冲半径要摊在面板上。
- **待核实**：技术栈里的「10 个 REST 接口」「常驻内存约 760 MB」「宝塔 v12」来自项目记录而非截图，数值变了要回改。

## 4. 视频位

按约定留空：`video.src = ''`、`autodetect: '/projects/serviceAnalysis/demo.mp4'`，封面借用路网分析那张图，页面显示 `VIDEO · COMING SOON` 占位卡。把录屏放到 `public/projects/serviceAnalysis/demo.mp4` 刷新即自动切换为带控件的 `<video>`，不改代码。

## 5. 环境坑：独立 vite 预览（5199）与 EBUSY 崩溃

- 端口分工沿用旧结论（5173 归智慧地铁、8091 为 Express 托管 `dist/`），本次再起一个 vite dev 用 **5199**，`vite.config.js` 的 `/api → localhost:8091` 代理 + 多页 entry 无需改动。
- 实测坑：dev server 运行期间用编辑器/工具的"原子写入"改 `src/project.js` 时，写入会在 `src/` 下临时生成 `.<name>.<pid>.<uuid>.tmpdir/`，vite 的 FSWatcher 会 `EBUSY: resource busy or locked` 直接崩进程（exit 1）。规避：改完文件再启动 dev server，或崩了直接重启；不要靠 HMR 连改大文件。
- 审版：六张图实测 HTTP 200 `image/jpeg`；整页用无头截图分段（1600 宽，分 3400–5200 高多段）逐段核排版，未见破版。
- 辅助工具的签名以实际版本为准：Windows 截图工具不接受 `use_vision` / `use_ui_tree` 之类的旧参数，传了会 pydantic 校验失败。

## 6. 收尾

dev server 已关、临时预览 png 已清；**发线上仍需 `npm run build` 让 `dist/` 同步**。首页三+一张卡全部可点：`metro / community / amap / serviceAnalysis`。
