---
id: "6f3311ba-8b61-417a-bf6d-e533e0317cc0"
title: "实验四《地图制图与输出》MapSymbolize：符号化、唯一值渲染与 300dpi BMP 导出的实现与实测坑"
description: "VS2010 + ArcObjects 10.2 实验四交付记录：IMapDocument 加载 mxd、左键按几何类型换符号、右键唯一值渲染、IExport/IActiveView.Output 导出 300dpi BMP；含本机四个实测坑（AoInitialize 必调、FocusMap 不可赋值、FeatureClass 读不到改用 IFeatureLayer2.ShapeType、显示对象须先 StartDrawing 再设变换）与产物路径清单。"
status: "active"
created_at: "2026-11-01T02:37:32.755Z"
updated_at: "2026-11-01T02:37:32.755Z"
content_hash: "d4c1b11ac339a46b01f70860b746e72c75a22abe314a816971bec890475dd921"
source_paths:
  - "实验四/MapSymbolize/MapSymbolize/Form1.cs"
  - "实验四/MapSymbolize/MapSymbolize/SymbolSelectorForm.cs"
  - "实验四/MapSymbolize/MapSymbolize/Program.cs"
  - "实验四/MapSymbolize/MapSymbolize/Form1.Designer.cs"
  - "实验四/地图输出.bmp"
  - "实验四/shots"
session_ids:
  - "66a4da57-7038-4801-928d-ec26cbc0174b"
memory_body_ids:
  []
---

# 实验四《地图制图与输出》（MapSymbolize）实现与实测复盘

工作区 `F:\AE 开发\实验四`。一次会话内完成：可运行工程 + 实测截图（对应指导书图 2~8）+ 300dpi BMP 交付图 + 程序包/源码包。
技术栈与实验三一致：**VS2010 + ArcObjects SDK 10.2，C# / .NET 4.0，x86**，MSBuild 4.0 命令行编译。
环境背景（ArcGIS 10.2 运行时、路径坑）参见实验三文档 `0b50b09c-791d-4bc1-8b09-d58be68a1901`。

## 1. 工程结构

工程根 `F:\AE 开发\实验四\MapSymbolize\MapSymbolize.sln`（工程目录 `MapSymbolize\MapSymbolize\`）。

| 文件 | 职责 |
|---|---|
| `Program.cs` | `AoInitialize` 初始化 + Desktop 许可 |
| `Form1.Designer.cs` | Toolbar / TOC / MapControl 布局 + 两个按钮 |
| `Form1.cs`（约 741 行，3 个 region） | 一、加载地图（L90–370）；二、左键设符号 / 右键唯一值渲染（L372–588）；三、地图输出 BMP 300dpi（L590–728） |
| `SymbolSelectorForm.cs` | 符号选择器，内部用 SymbologyControl |

数据在 `bin\data\`：`国家基础地理信息.mxd` + 城市、主要城市、铁路、行政区划四个 shapefile（另生成 `.sr.lock` 锁文件，属正常现象）。

## 2. 四项功能的实现要点

### 2.1 加载地图
`new MapDocumentClass().Open(mxdPath)` → 校验 `MapCount` → `get_Map(0)` → `ApplyEngineeringSymbols(map)` 给每层按几何类型配符号 → `ShowLayerLabels(map)` → 交给控件 → 设 `Extent = FullExtent` 并 `Refresh`；`finally` 里 `mapDocument.Close()`（已关闭再关会抛异常，故 try/catch 吞掉）。

### 2.2 左键点击图层设符号
TOC 命中测试拿到图层 → 按几何类型选对应符号库（点/线/面）→ `SymbolSelectorForm` 选择 → 用 `ISimpleRenderer` 包一层替换原渲染器并刷新图例。

### 2.3 右键唯一值渲染
只对面图层生效：`IDataStatistics` 统计 `NAME` 字段唯一值，每类用 HSV 随机颜色生成实心填充符号，写入 `IUniqueValueRenderer`。实测把 **34 个省份染成 34 种颜色**。

替代思路：`ApplyEngineeringSymbols` 中统一用 `ISimpleRenderer` 替换图层原有渲染方式，`renderer.Label = ((ILayer)featureLayer).Name`，借此把“默认符号”换成有设计的配置。

### 2.4 地图输出 BMP（300dpi）
关键流程（`ExportMapToBmp`，Form1.cs 约 L648 起）：

1. `ratio = dpi / 96.0`，用 `activeView.ExportFrame.right/bottom × ratio` 算出像素宽高；
2. `new ExportBMPClass()`，设 `ExportFileName`、`Resolution = dpi`、`PixelBounds`（0,0,w,h）；
3. `int exportHdc = export.StartExporting()`；
4. `new SimpleDisplayClass()` → **先 `StartDrawing(exportHdc, (short)esriScreenCache.esriNoScreenCache)`**；
5. **之后再**取 `DisplayTransformation` 设 `Resolution = dpi`、`VisibleBounds = activeView.Extent`、`Bounds = pixelBounds`；
6. 用白色 `SimpleFillSymbol` + `DrawRectangle(pixelBounds)` 铺白底；
7. 组 `tagRECT{0,0,pixelWidth,pixelHeight}`，调 `activeView.Output(exportHdc, dpi, ref rect, activeView.Extent, null)`，再 `exportDisplay.FinishDrawing()`；
8. `FinishExporting()` + `Cleanup()`，`finally` 兜底 Cleanup 并 `Refresh()`，最后 `File.Exists` 判定成败。

实测产物：**1253×1788 像素 = 4.18×5.96 英寸 @300dpi**。

## 3. 本机实测踩到的四个坑（最有复用价值）

1. **必须调用 `AoInitialize`**：漏掉时地图控件本身能创建，但 `IFeatureClass` 全为 `null`、地图不显示。要在 `Main` 里 `new AoInitializeClass().Initialize(esriLicenseProductCodeAdvanced)`。
2. **`ActiveView.FocusMap = map` 抛“未实现该方法”**：本机只能用 `((IMapControl3)axMapControl1.Object).Map = map` 赋值。
3. **`IFeatureLayer.FeatureClass` 取不到**：几何类型改用 `IFeatureLayer2.ShapeType` 判断。
4. **导出 BMP 全空白**：根因是显示对象的 `Resolution`/`VisibleBounds`/`Bounds` 在 `StartDrawing` **之前**设置会被覆盖；必须放到 `StartDrawing(导出 HDC)` 之后。另需同时按 `dpi/96` 放大 `ExportBMP.PixelBounds`。

其他细节：
- 字段名 `Path` 与 `ESRI.ArcGIS.Geometry.Path` 冲突，代码中写全 `System.IO.Path`。
- `axToolbarControl1_OnItemClick` 里要重新 `SetBuddyControl(axMapControl1)` 并刷新 TOC 与 ActiveView，否则工具栏命令后图层框不同步。

## 4. 产物清单（`F:\AE 开发\实验四\`）

| 文件 | 说明 |
|---|---|
| `2244275060-林先语-实验四-程序.zip` | 可运行程序 + data + 交付图 + shots |
| `2244275060-林先语-实验四-源码.zip` | 纯源码（sln + 10 个源文件） |
| `地图输出.bmp` | 交付地图，6 722 934 bytes |
| `shots\figure2_initial.png` … `figure8_output_map.png` | 图 2~8 实测截图 |
| `MapSymbolize\MapSymbolize\bin\Debug\MapSymbolize.exe` | 26 112 bytes |

截图与 bin 目录各留一份（工作区 `shots\` 与 `bin\Debug\shots\`），打包时按指导书图号命名。

## 5. 未完成/可延续项

- 实验报告尚未按模板撰写（模板填报流程见实验三文档 `0b50b09c` 第 4 节）。
- 可选：把 `Form1.cs` 改成“教学式展开版”（变量集中前置、每步单独成段）便于逐段阅读讲解。
