---
id: "c8570e75-8ba5-46ba-aba4-f2821b83f339"
title: "悬停热力图二次失效：mode('grid') 被当成图层 id 传给探针（LAYER_OF 映射，396d6cc）"
description: "热力图悬停在前端「模式→图层 id」错位下的再次失效：根因（probeFeature 按 l.get('id') 找图层，热力图 layer id 是 'heat' 而非 'grid'，POI 恰好同名侥幸可用）、四步排查证据（手工 URL 200/176 → 读 OL getFeatureInfoUrl → DOM 调试探针打印真实 URL 与响应 → 调生产 run() 验 lastId）、无 console 时的 DEV-only 调试块手法与清理、以及静默 null 的反思与未落地的 warn 建议。"
status: "active"
created_at: "2026-11-01T12:49:32.960Z"
updated_at: "2026-11-01T12:49:32.960Z"
content_hash: "c1a563a21b78928c58b084145e1cc19cbc2eae54476d657f5f42258ccd216d59"
source_paths:
  - "FE/src/map/hover.js"
  - "FE/src/map/probe.js"
  - "FE/src/stores/layers.js"
  - "FE/src/view/mapView.vue"
session_ids:
  - "cdf1c8e1-7e98-4b2e-b049-ab3395742b87"
memory_body_ids:
  []
---

# 悬停热力图二次失效：模式名 ≠ 图层 id

提交：`396d6cc  11 修悬停热力图不生效的根因：mode('grid') 被当成图层 id 传给探针，而图层 id 是 'heat'；POI 因两者同名侥幸可用。新增 LAYER_OF 映射`（2 files, +12 / −1，已推 `Dawnivers/ServiceAvailable` main）。

前序文档（勿重复实现，只引用）：

- `3b390220-5bbb-4d43-b8ca-60b0421972db`：`probe.js` 统一 GetFeatureInfo 探针 + `hover.js` 双层描边/光圈、几何随 SRS 返回、三重节流锁（提交 `e210f79`）。本文的 `LAYER_OF` 是对该文档里 `probeFeature(map, evt, layerId, …)` 签名的必要补充。
- `1c2dc1a4-c230-4c66-bb6e-8b25137f4bd7`：修的是**另一个**根因——`mode` 被缓存在控制器内部导致同步失败（`c34c2f4`）+ 低缩放浮提示（`22874a5`）。改完后 POI 悬停正常，但热力图悬停**仍然完全没反应**，于是才有本文。
- `b4346af9-bbcb-47b6-b128-5f360391455d`：F4 点格弹窗与 `getFeatureInfoUrl` 的 101×101 窗口、bbox 前提。

## 1. 根因

`probeFeature` 是按**图层对象的 `id` 属性**取图层的：

```js
const layer = map.getLayers().getArray().find((l) => l.get('id') === layerId);
if (!layer || !layer.getVisible()) return null;   // ← 静默返回 null
```

而 `hover.js` 把自己的**模式**直接当图层 id 传了进去：

```js
// 旧
probeFeature(map, { coordinate: lastCoord }, mode, …)   // mode = 'grid' | 'poi'
// 新
const LAYER_OF = { grid: 'heat', poi: 'poi' };
probeFeature(map, { coordinate: lastCoord }, LAYER_OF[mode], …)
```

| 模式 | 应传的图层 id | 旧代码实际传的 | 结果 |
|---|---|---|---|
| `'poi'` | `'poi'` | `'poi'` | 撞对 → POI 一直正常 |
| `'grid'` | **`'heat'`** | `'grid'` | 找不到图层 → `null` |

结论：**热力图悬停从上线起一次请求都没发过。** POI 能用纯属两个名字恰好重合。

## 2. 取证顺序（这次没靠猜）

浏览器工具读不到 console，也合成不出 `pointermove`，所以每一步都必须有一个**可读的输出**：

| 步骤 | 手段 | 证据 | 结论 |
|---|---|---|---|
| ① | 手工拼 GetFeatureInfo 请求 | `HTTP 200`，769 B，返回 `grid_500m.16822`、`total=176`、`r_*`、`centroid` | 服务端与参数都对，**问题在前端** |
| ② | 读 OL 的 `getFeatureInfoUrl` 实现 | 由 `getForViewAndSize(coordinate, resolution, 0, 101)` 取 extent，`X = floor((c0-e0)/res)`、`Y = floor((e3-c1)/res)`，`VERSION ≥ 1.3` 才用 `I/J`，否则 `X/Y` | 只要 OL 真被调用，URL 就一定合法 |
| ③ | 临时 DEV-only 调试块：先 `setCenter` 到江汉路 `[114.2843, 30.5843]` + `setZoom(13)`，等 120 ms，再打印内部状态与 URL | `mode=grid zoom=13.00 URL=/geoserver/wuhan/wms?…&X=50&Y=50&WIDTH=101&HEIGHT=101&SRS=EPSG%3A3857&BBOX=12721105.06…  HTTP=200 len=769`，响应里就是 `grid_500m.16822` | URL 与响应全对，**是前端没拿回来** |
| ④ | 顺着 ③ 读 `hover.js` 里那一行调用 | `probeFeature(..., mode, ...)` vs 签名 `layerId` | **定位**：`'grid'` 找不到 id 为 `'heat'` 的图层 |
| ⑤ | 改完后让调试按钮直接调生产路径 `run()` | `mode=grid zoom=13.00 lastId=grid_500m.16822 高亮层要素数=1 几何类型=Polygon` | 通 |
| ⑥ | 删调试块 + `grep dbg` 残留检查 + build | 干净；`✓ 269 modules transformed / built in 352ms`；页面快照里已无「模拟探针」按钮 | 收尾完成 |

关键判据：**能返回数据却渲染不出来，先怀疑「自己有没有真的发请求」，而不是样式或坐标系。** 前两轮排查都在怀疑几何/样式/缩放，浪费在错误的分支上。

## 3. 无 console 时的调试手法（可复用）

浏览器工具看不到 console、也点不中 canvas 上的要素，于是在 `hover.js` 里加一个仅 DEV 生效的块（定位完即删）：

- 一个绝对定位的 `div`（`right:12px;bottom:56px;z-index:120`）当输出窗；
- 一个「模拟探针(grid)」按钮：先把视图拉到真实悬停会出现的场景（z13），`await setTimeout(120)` 等瓦片稳定，**再调用生产代码路径**（最终版直接 `run()`），把 `mode / zoom / center / lastId / 高亮层要素数 / 几何类型` 写进 DOM；
- 早期版本还打印了 `hit.url` 与原始响应前 200 字——这一步才是真正破案的地方。

两条经验：

1. 调试块要能**驱动生产路径**，另写一条 fetch 只能证明「服务端没问题」（本轮就是这样被带偏一次）。
2. 临时块必须留 `grep dbg` 的清理判据，并 `if (dbg) dbg.remove()` 挂在 `destroy()` 上，避免残留在卸载后仍指向已移除节点。

## 4. 反思与未落地建议

这个 bug 能藏这么久，是因为给它套了一层"看起来合理"的抽象（`mode` 概念），而两个名字在 POI 上恰好重合掩盖了错位。

- 更稳的写法：一开始就直接传 `'heat'` / `'poi'` 两个真实图层 id，模式只用于分支。
- 更重要的：`probeFeature` 找不到图层时**静默 `return null`**，让「逻辑错位」与「确实没要素」在表现上完全相同。建议后续约定——这类"按 id 找对象"的函数找不到时**至少 `console.warn` 一次**。
- 状态：该 `warn` 只是建议，**尚未落地**（本轮结束时仍在征询）。下次动 `probe.js` 时优先补上。

## 5. 验收

`heat` 默认值已改回 `false`；刷新后：勾上「可达性热力图」→ 放大到 z12–14 → 划过彩色格子应出现深蓝外框 + 白色内框 + 上方「176 个」；z9 时划过应浮出「放大到 z11 才能选格子」。
