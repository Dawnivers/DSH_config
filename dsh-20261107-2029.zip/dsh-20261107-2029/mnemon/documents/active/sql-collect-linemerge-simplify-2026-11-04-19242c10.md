---
id: "19242c10-96b1-40c9-91ae-1604e9281a5c"
title: "等时圈最终 SQL 逐站解析与线几何后处理：Collect/LineMerge/Simplify 分工（2026-11-04）"
description: "PoiMapper.xml 等时圈最终版 SQL 的九段流水线逐段语义（params/snap/used/dd/partial/skel/surf/pois/JSON）、半截边补全算法、以及 ST_Collect→ST_LineMerge→ST_Simplify→ST_Buffer 四步各自职责的实测对照（2949 部件/7056 点 → 1261 部件/2820 点，长度几乎不变 vs 缩短 0.2 km）、Simplify 容差单位随 SRID 变化与对多边形须用 PreserveTopology。性能数字见 de888790，pgr_* 输入契约见 5ca9ab7a / 53a6a216。"
status: "active"
created_at: "2026-11-04T08:34:17.114Z"
updated_at: "2026-11-04T08:34:17.114Z"
content_hash: "8de94bd331f7add028eb004ba59d29f7879c323b0cf07a25bff83778a87cd3bb"
source_paths:
  - "serviceAnalysis/BE/src/main/resources/mapper/PoiMapper.xml"
  - "serviceAnalysis/BE/src/main/java/com/dawnivers/be/service/PoiService.java"
session_ids:
  - "2ad81333-8e4c-4a4d-986c-d78b6e6fd33f"
memory_body_ids:
  []
---

# 等时圈最终 SQL 逐站解析与线几何后处理（2026-11-04）

> 承接三篇已存文档，不重述其结论：
> - `de888790-a1ee-45f8-b4c5-b871629c6849` —— 索引 / CTE MATERIALIZED / 缓冲调优的**性能实测**
> - `5ca9ab7a-f15a-4956-a70a-320314090a89` —— `pgr_*` 输入契约、吸附误差口径
> - `53a6a216-38cb-451e-af70-a1b62650fa82` —— 边表/节点表配合、`pgr_drivingDistance` 输出语义、边界截断
>
> 本篇只补两块：**① 最终版 SQL 的九段流水线各自在做什么、参数为什么这么写**；
> **② `ST_Collect` / `ST_LineMerge` / `ST_Simplify` / `ST_Buffer` 的分工与实测对照**。
> 源码：`serviceAnalysis/BE/src/main/resources/mapper/PoiMapper.xml`、`PoiService.java`。

## 0. 九站流水线总览

```
① params  装参数为一行（click 几何 + budget）
② snap    点 → 最近路网节点，顺带算 snap_m
③ used    扣预算：budget − snap_m（GREATEST 防负）
④ dd      在路网图上扩散，得到"走得到的边"（只有编号）
⑤ partial 把"走不完的边"切成半截，补齐边界
⑥ skel    所有线段 Collect + LineMerge 焊成骨架线
⑦ surf    骨架 Simplify 后 buffer 50 m → 面
⑧ pois    ST_Within 面内设施 → 全量统计 + 分页
⑨ JSON    一个 json_build_object 一次返回
```

## 1. 各站关键约束（易错点）

| 站 | 必须这么写 | 不这么写的后果 |
|---|---|---|
| ① `params` | `ST_SetSRID(ST_MakePoint(#{lon}, #{lat}),4326)`；`#{budget}::numeric` | MakePoint 出来 SRID=0 → 后面全部 `mixed SRID` 报错；numeric/double 混算出错 |
| ① | **经度在前** | 写反不报错，直接跑到南半球 |
| ② `snap` | 内层 `ORDER BY v.geom <-> p.click LIMIT 5`，外层按 `ST_Distance(::geography)` 精排 | `<->` 在 4326 单位是**度**，经纬方向不等长（武汉 1°经≈96 km，1°纬≈111 km），单层排序会选错节点 |
| ③ `used` | `GREATEST(budget - snap_m, 0)` | 负数传给 pgr 行为未定义；归零后自然得到空结果 |
| ④ `dd` | 图 SQL 显式 `length_m AS cost`；`WHERE edge <> -1` | `SELECT *` 会拿"度"当米（见 5ca9ab7a）；不过滤会多一行起点自身 |
| ⑤ `partial` | `ST_LineSubstring` 第三参是 **0–1 比例**，两端方向要分情况 | 切错头会接出"跨过去"的怪线；不补面积少约 27% |
| ⑥ `skel` | 必须先 `ST_Collect(ARRAY[...])` 再 `ST_LineMerge` | LineMerge 只吃单一几何，不能直接吃多行 |
| ⑦ `surf` | `ST_Buffer(ST_Simplify(g,0.00005)::geography, 50, 'quad_segs=2')` | 4326 上直接 buffer，50 被当成"度"≈5500 km |
| ⑧ `pois` | 统计与分页**拆两个 CTE** | 单个 CTE 里 LIMIT 50 再 `count(*)` → 计数永远是 50 |
| ⑨ | 整体 `::text` + `resultType=String`，Service 用 `objectMapper.readTree()` | 与 `/overlay` 接口保持一致 |
| ⑨ | `round((sum(...)/1000)::numeric, 2)` | `round(double,int)` 在 PG 不存在 |

补充：`count(*) FILTER (WHERE category='school')` 一次算四类，比四个 `count(case when...)` 干净；
`coalesce(json_agg(...),'[]'::json)` 让前端不必判空。

## 2. `dd` 不是线数据 —— 这是理解整条 SQL 的分水岭

`pgr_drivingDistance` 输出固定 5 列，**全是数字**：

```
seq | node   | edge   | cost | agg_cost
 1  | 26086  | -1     | 0.0  | 0.0
 2  | 147705 | 179944 | 33.4 | 33.4
```

`dd.edge` 是边的**编号**，几何在 `walk_ways.geom`。所以 `JOIN walk_ways w ON w.id = dd.edge`
不是冗余，而是唯一把编号翻译成坐标的途径（实测 2949 行全部匹配成功）。

**分工原则**：`pgr_*` 只算拓扑与权重，永不产出几何；几何的唯一来源是边表。

## 3. 半截边（`partial`）：边界精度的关键

`pgr_drivingDistance` 只返回**整条可达边**，预算会在最后一条边中途耗尽，因此最多少一条边长的缺口。

```sql
ST_LineSubstring(w.geom,
  CASE WHEN w.source = d.node THEN 0
       ELSE 1 - LEAST(1, (u.used_budget - d.agg_cost) / NULLIF(w.length_m,0)) END,
  CASE WHEN w.source = d.node
       THEN LEAST(1, (u.used_budget - d.agg_cost) / NULLIF(w.length_m,0))
       ELSE 1 END)
```

三个要点：
- 比例 = 剩余预算 / 边长，**不是米**；
- 从 `source` 端走到切 `[0, frac]`，从 `target` 端走到切 `[1-frac, 1]`；
- `NULLIF(w.length_m,0)` 防除零。

筛选条件：`agg_cost + length_m > used_budget`（走不完的边）且 `w.id NOT IN (SELECT edge FROM dd)`（避免重复）。
实测约 128–130 条半截边、4.5 km；**不补则面积从 1.085 → 0.791 km²（−27%）**。

## 4. `ST_Collect` vs `ST_LineMerge` vs `ST_Simplify`（实测对照）

同一份骨架在四个变体下的实测：

| 变体 | 类型 | 部件数 | 点数 | 总长 |
|---|---|---|---|---|
| 原始 collect | MULTILINESTRING | 2,949 | 7,056 | 35.71 km |
| 只 LineMerge | MULTILINESTRING | **1,261** | 5,368 | **35.71 km** |
| 只 Simplify | MULTILINESTRING | 2,949 | 5,966 | 35.51 km |
| **两者都做（采用）** | MULTILINESTRING | **1,261** | **2,820** | 34.73 km |

一句话分工：**LineMerge 管"段太多"，Simplify 管"点太多"。**

| | `ST_Collect` | `ST_LineMerge` | `ST_Simplify` |
|---|---|---|---|
| 干的事 | 多行几何打包成一个 `MULTI*` | 首尾相接的线段焊成一条 | 删掉近直线的拐点（Douglas-Peucker） |
| 改的量 | 行数 → 1 | **部件数** | **点数** |
| 需要参数 | 否 | 否 | 容差 |
| 改变形状 | 否 | 否（长度一毫米不变） | 是（误差 ≤ 容差） |
| 风险 | 无 | 交叉路口（>2 线相交）拒绝合并 | 可断线；对面可能自相交 |

对比 `ST_Union`：Collect 只是"装盒"（快、部件数不变），Union 要做拓扑合并（慢、会裁重叠），
这里只需要"可达路网的整体"，用 Collect 是对的。

**执行顺序不可乱**：`Collect → LineMerge → Simplify → Buffer`
（Simplify 放在 Buffer 之前是为了性能：输入点数少约 30% 的耗时节省）。

**为什么两处容差不同**：缓冲前 `0.00005`（≈5 m，只影响形状，省 30% 时间），
输出 GeoJSON 用 `0.00002`（≈2 m，用户可见的精度更高）。

## 5. Simplify 的两个坑

1. **容差单位跟着 SRID 走**：4326 下 `0.00005` ≈ 5.5 m（纬度）/ 4.7 m（武汉经度）；
   3857 下 `0.00005` 是 0.05 mm，等于没简化。数字必须随坐标系换算。
2. **对多边形须用 `ST_SimplifyPreserveTopology`**：`ST_Simplify(polygon, ...)` 可能产出
   自相交（细长条被削成"8"字）。当前 `ST_Simplify(p, 0.00002)` 作用在 buffer 出的面上，
   实测该容差未出问题，但放大到 0.0005 之类就可能失效 —— 换大容差前先改函数。

## 6. 返回字段的用途（前端契约）

| 字段 | 谁用 | 说明 |
|---|---|---|
| `status` | 前端 | `ok` / `no_network`（`snap > budget`） |
| `nodeId` / `snapM` / `usedBudgetM` | 提示 + 调试 | 透明度三件套 |
| `areaKm2` | 面板 | 实测 1.069 km²（同预算圆的约 53%） |
| `surface` | 地图 | 简化后约 6.6 KB |
| `skeleton` | 地图 | 简化后约 60–75 KB |
| `edgeCount` / `partialCount` / `walkKm` | 面板 + README | 2,951 + 130 段 / 35.7 km |
| `count` / `itemsTotal` | 面板大数字 | 74（圆口径 83） |
| `byCategory` | 分类条 | 四个 `FILTER` 聚合 |
| `items` | 列表 | 分页后 50 条 |
