---
id: "55dafa4c-52e1-4cf5-8224-0d066d0bff8d"
title: "D11 后端收尾实录：nearby 的 lon/lat 范围校验、include-message 沉默、格式化器被 Prettier 抢占与四项遗留"
description: "武汉 GIS 项目 BE 阶段收尾记录：PoiController.nearby 补 lon/lat 校验并调整校验顺序、五项 curl 验收（含证明运行中服务确为新代码）、Spring Boot 2.3+ include-message 默认 never 导致 400 无 message、VSCode 中 Java 无法格式化的根因是 Prettier 抢占默认格式化器（redhat.java）、后端完成判定与四条未清技术债、D12 前端起步前的风险点。"
status: "active"
created_at: "2026-10-29T08:54:14.847Z"
updated_at: "2026-10-29T08:54:14.847Z"
content_hash: "a9a7ea81e0ff15b41a683f6a56d4ed038b428b0dccc17e72dc1a43abf87c6788"
source_paths:
  - "BE/src/main/java/com/dawnivers/be/controller/PoiController.java"
  - "BE/src/test/java/com/dawnivers/be/PoiApiTest.java"
  - "BE/.vscode/settings.json"
  - "FE/docs/roadmap.md"
session_ids:
  - "9079a16d-d211-4d35-a622-566e9ed59d0f"
memory_body_ids:
  []
---

# D11 后端收尾实录（as-built）

关联：三层边界与「controller 管门」的定稿见 `6b85ed40-4278-4e1f-b061-02a6fc74fc95`；三条 HTTP 测试的落地与「只在数据不变时才绿」的债务见 `5ed18f51-1be1-45fb-8d51-ce224ea8ae05`。本文只记 D11 这一步把什么改成了什么样、怎么证明它是通的、以及还欠什么。

## 1. 改了什么：`PoiController.nearby` 补 lon/lat 校验

位置：`BE/src/main/java/com/dawnivers/be/controller/PoiController.java`（`@GetMapping("/nearby")`）。

新增两条，与既有的 `radius ∈ (0,5000]`、`limit ∈ (0,50]` 并列：

```java
if (lon < -180 || lon > 180) {   // 经度 东西 ±180
    throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
            "lon must be in [-180, 180], got " + lon);
}
if (lat < -90 || lat > 90) {     // 纬度 南北 ±90（不对称，别写反）
    throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
            "lat must be in [-90, 90], got " + lat);
}
```

两条被放在方法**最前面**（lon → lat → radius → limit），理由：多参数同时越界时报错要报"最上游的那个坐标"，先报 radius 会掩盖坐标本身就错的事实。

**校验为什么在 controller 而不在 service**：这一层校验的是**入参门槛**（HTTP 参数能否构成一次合法查询），不是业务规则；service 收到的一定是已合法化的参数。这与 `6b85ed40` 里"controller 管门、service 管算"的边界一致。反过来，数据库返回值的健全性不是 controller 的事。

### 关于"前端怎么会传出 lat=999"

真实来源不是手滑输入，而是 **lon/lat 传反**（`lon=30.54&lat=114.36`）：把经纬度顺序写反后，纬度位置塞了个经度值，于是超界。所以校验的真正价值是**在接口层立刻炸掉，而不是静默返回 `count:0`**——后者是最坏的失败形态（前端显示"附近没有 POI"，人以为数据没了）。

## 2. 验收：五项 curl（8094）

```
radius=9999                        -> 400   原有半径校验没被挪代码破坏
lat=999                            -> 400   只有新代码才拦
lon=30.54&lat=114.36（传反）       -> 400   真实场景能拦
lon=0&lat=90（边界）               -> 200   闭区间上界写对
lon=180&lat=0（边界）              -> 200   同上
主路径 lon=114.36&lat=30.54        -> count:124, byCategory{school:109,hospital:2,mall:10,park:3}, nearest 武汉大学-教1楼 53.0m
```

**验收设计要点**：`lat=999 → 400` 与 `lat=90 → 200` 这一对是最小充分组合——前者排除"服务根本没重启还在跑旧代码"，后者排除"区间误写成开区间"。只跑越界不跑边界，改错区间也看不出来。

`mvn clean test`：`Tests run: 3, Failures: 0, Errors: 0`，一次通过。运行中的服务 PID 21948 在 8094 上，实测响应已含新校验，故**运行实例确实是新代码**。

## 3. 400 响应里没有 `message`（不是 bug）

实际响应体只有 `{"timestamp","status":400,"error":"Bad Request","path"}`，看不到 `"lon must be in ..."`。

原因：**Spring Boot 从 2.3 起 `server.error.include-message` 默认 `never`**——错误详情可能含堆栈/SQL/内部路径，默认不回客户端。`ResponseStatusException` 的 reason 只进日志（`WARN ... Resolved [...ResponseStatusException: 400 BAD_REQUEST "lon must be..."]`）。

三选项与取舍：保持现状（推荐，D11 目标只是"不再静默 count:0"，`400` 已达成）；`include-message=always`（连 500 堆栈也可能外泄，生产不开）；`on_param`（几乎无实际用途）。结论：**不加**。副作用要知道：前端调试 400 时读不到原因，只能看后端日志；测试里同样断言不到 message（同一个 `ErrorAttributes`），只能断言状态码。

## 4. VSCode 里 Java 按 `Shift+Alt+F` 没反应：Prettier 抢占

排查链（按顺序走，能省很多时间）：

1. `F2 + Backspace` 本来就不是格式化——`F2` 是 Rename Symbol。默认格式化是 `Shift+Alt+F`。
2. 已装 `redhat.java-1.58.0`（连同 vscjava 全家桶共 7 个 Java 扩展），**provider 存在**。
3. `BE/.vscode/settings.json` 只配了 `java.jdt.ls.java.home`、`java.configuration.runtimes`、`java.configuration.maven.globalSettings`、`maven.executable.path`，无格式化相关项，排除显式禁用。
4. 状态栏右下角语言已识别为 `Java`，排除"文件当纯文本"。
5. 命中的是提示原文：**"扩展 'Prettier - Code formatter' 配置为格式化程序，但不能格式化 'Java' 文件"** —— Prettier 不支持 Java，成了 Java 的默认 formatter，于是静默失败。

修法：`BE/.vscode/settings.json` 追加（注意上一行补逗号）：

```json
"[java]": { "editor.defaultFormatter": "redhat.java" }
```

值必须是扩展 id `redhat.java`，**不是** `vscjava.vscode-java-pack`（那是扩展包，不含格式化器）。`java.format.settings.profile` 不设即 Eclipse 风格 4 空格（与本项目一致），设 `GoogleStyle` 会变 2 空格，别加。

### 为什么不建议 `editor.formatOnSave`

本项目代码要自己手写。存盘自动格式化会掩盖自己缩进错在哪、看不出格式退化的起点。手动按 `Shift+Alt+F` 本身就是练习。快捷键无反应时，备选路径：命令面板 `Format Document`、右键菜单、以及 `redhat.java` 自带的 `Java: Format`（命令名独立于通用快捷键）。

## 5. 后端算不算完成：判据与结论

**是。** 判据（对照 roadmap §8）：

- 6 个接口全部实现；
- `mvn clean test` 3/3 绿；
- 边界行为符合预期（404/400）；
- 空间索引生效（`Bitmap Index Scan`，23.9ms）；
- 数据库密码不进 git；
- D11 技术债（lon/lat 校验）清零。

唯一剩下的动作是提交（提交时先格式化，否则 diff 全是空白噪音）：

```
git add src/main/java/com/dawnivers/be/controller/PoiController.java
git commit -m "07 nearby 补 lon/lat 范围校验（D11 技术债清零）"
```

## 6. 四条遗留（与功能无关，但会在这两天撞上）

1. **测试依赖真实数据**：124 / 1681 / 3 张照片都从活库 `Spatial` 查出。D16 若重建 `grid_500m` 或重跑 ETL，测试必红。解法：`Spatial_test` 冻结数据，或 `@Sql` 独立数据集。
2. **错误分支无测试保护**：`gid=999999999→404`、`adcode=999999→404`、`adcode=abc→400`、`radius=9999→400`、`lat=999→400` 全手工验过，只有主路径有测试。性价比最高的是补 `poi/{gid}` 的 404 与 `nearby` 的 400 两条（约 15 行，`getForEntity`）。
3. **`include-message` 关着**（见 §3），前端调试只能靠日志。
4. **`radius` 上限 5000 没有依据**：D13 缓冲区若要做 5km+ 的圈会 400。到那时改数字即可，但要先知悉。

## 7. D12 起步前的已知风险

D12 是纯前端（`stores/layers.js`、`map/wms.js`、`map/layers.js`、`components/LayerPanel.vue`、`composables/useLayerSync.js`）。最可能撞的坑：`ImageWMS` 在拖拽时每帧重发 GeoServer 请求导致卡顿，§8 判据"拖动不卡成幻灯片"就是防它，解法是 `refreshInterval` 节流。

> 注：`05d1317d-4e21-4582-8c4a-80cab1cc825b` 已记录 D12 曾在 2026-10-25 提前完成，实际结构与 WMS 参数以该文档为准；本节只作风险提示。
