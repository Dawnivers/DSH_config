---
id: "29c3b714-0c26-4c43-a9e9-8b6cd26a6a6b"
title: "叠加分析里「只调刚画的那个圆」:activeShapeId 单一真相 + 虚线可调/实线锁定 + 半径滑杆在叠加模式下的语义（5 文件改动）"
description: "叠加（多面）模式下半径滑杆的作用域设计：activeShapeId 为唯一真相、虚线=可调/实线=已定稿、拖滑杆实时改几何与面板数字但统计延迟 260ms 才刷新、面积用 πr² 而非量多边形；含 5 个文件的接线位置与遗留歧义（是否要地图上拖边改半径）。"
status: "active"
created_at: "2026-11-02T08:45:54.497Z"
updated_at: "2026-11-02T08:45:54.497Z"
content_hash: "095dc0c4bf44a3eb896f755d4c57a7c50e88afe6d6912c186e40863561d8c132"
source_paths:
  - "FE/src/stores/analysis.js"
  - "FE/src/map/drawing.js"
  - "FE/src/view/mapView.vue"
  - "FE/src/components/AnalysisToolbar.vue"
  - "FE/src/App.vue"
session_ids:
  - "f0284119-69ea-4d47-b944-108f07cd7b24"
memory_body_ids:
  []
---

# 叠加分析里「只调刚画的那个圆」

叠加模式（2–6 个面求原子面/按重叠度统计）此前只支持「画完就定稿」，半径滑杆在叠加模式下是失效的。
本次给叠加面补上**半径可继续调整**能力，并把「调谁」显式化。

## 1. 交互规则（最终形态）

| 时刻 | 圆的样子 | 滑杆作用对象 |
|---|---|---|
| 点选画完第 1 个圆 | 虚线（可调） | 这个圆 |
| 拖半径滑杆 | 圆实时伸缩 | 同上 |
| 再画出第 2 个圆 | 第 1 个变实线（锁定） | 第 2 个圆 |
| 第二笔是框选/自由绘制 | 圆全部变实线 | 无（标签消失） |
| 拖过滑杆之后 | 已锁定的圆不再变化 | — |

- **虚线 = 还能调，实线 = 已定稿**：不用看右侧面板就知道当前状态。
- 左上「缓冲区半径」标题旁出现红色小标签 **`调 A`**，指明滑杆当前调的是哪个面。
- 只允许「刚画的那一个」可调：多面叠加里若拖一下让几个圆一起变，重叠关系瞬间全乱，用户无法判断自己在调什么。

## 2. 状态模型：`activeShapeId` 是单一真相

```
画完圆 A  → activeShapeId = 's1'  （A 虚线）
画完圆 B  → activeShapeId = 's2'  （A 锁定实线，B 虚线）
画完矩形  → activeShapeId = null  （B 也锁定）
删除面    → 若删的正是 activeShapeId，则置 null
```

- `analysis.js` 持有 `activeShapeId`；`drawing.js` 只通过 `setActiveShape(id)` 被**单向推入**，自己不决定谁是 active（与「drawing 不 import store」的既有约束一致）。
- `updateShapeRadius(id, radius, areaKm2)` **只改 `shapes` 里那一条，不动 `activeShapeId`**——调半径不是换主体。
- 面积按 `πr²`（地面米）直接算，**不用量那个 32 边形**：量多边形恒比 πr² 小约 0.3%。
- 半径 → 投影米的换算仍走 `toMapRadius(meters, lat) = meters / cos(lat)`；叠加模式下 `center` 恒为 null，因此这个分支不会误重画单图形缓冲圈。

## 3. 统计「慢半拍」是故意的

拖滑杆时并集/交集数字**先保留旧值**，停手 260 ms 后才重算：

```js
// 增删面 → 统计语义变了，必须清
addShape()           { this.overlayResult = null }
removeShape()        { this.overlayResult = null }

// 改半径 → 还是同一组面，先留着旧数字，等新结果覆盖
updateShapeRadius()  { /* 不清 overlayResult */ }
```

- 每拖一下就清空面板会闪到不可用；滑杆本身 50 m 步长 + 连续拖动合并成一次请求（`cancelPending` + 重新计时），不会打爆后端。
- 三处同步：地图几何重建、圆上标签（`A · 1200 m`）、右侧面板（`A 缓冲圈 1200 m 4.52 km²`）。

## 4. 与既有规则的衔接（重要）

- 叠加模式下**换工具不再清已画的面**（矩形 ↔ 自由绘制 ↔ 点选）。这是对 D13「换工具即清空」的**定向改写**：`clearSketch()` 里用 `if (!this.overlay)` 包住 `shapes/shapeSelected/overlayResult` 的清理，清空只由「清空」按钮或关掉叠加开关负责。否则画到第 3 个想换画法，前两个就没了。
- 叠加面仍用 `kind:'shape'` 自成一路，不能被 `paintCircle` / `removeByKind('circle'|'polygon')` 波及；`setRadius` 因此在 `center == null`（叠加模式）时直接不重画。

## 5. 改动文件（5 个，无新增文件）

| 文件 | 改动 |
|---|---|
| `FE/src/stores/analysis.js` | `activeShapeId` 状态；`addShape/removeShape` 维护它；新增 `updateShapeRadius(id, radius, areaKm2)`；`clearSketch` 受 `overlay` 条件保护；`resetOverlay` 清 `activeShapeId` |
| `FE/src/map/drawing.js` | `setActiveShape(id)`；虚线/实线由 active 决定；`setRadius` 在叠加模式分叉（`resizeCircle` 式重建，不碰其它圆）；`registerShape` 用 `kind:'shape'` |
| `FE/src/view/mapView.vue` | 新增 `onShapeRadius` 回调 → `analysis.updateShapeRadius`；`watch(analysis.activeShapeId)` → `drawing.setActiveShape(id ?? null)` |
| `FE/src/components/AnalysisToolbar.vue` | 「调 {{ activeLabel }}」标签（`activeLabel` prop） |
| `FE/src/App.vue` | `activeShapeLabel` 计算属性（由 `shapes.find(x => x.id === activeShapeId)` 派生，避免再存一份） |

验证：`vite build` 通过（271 modules，~366 ms）；页面实测叠加面板显示 `1 / 6 个面`、`A 缓冲圈 800 m 2.01 km²`、「至少需要 2 个面才能叠加」「再画 1 个面才能开始叠加」。

## 6. 遗留 / 待确认

- **歧义未消**：本次实现的是「拖左上半径滑杆」。若要「在地图上直接拖圆的边缘改半径」（抓手柄拉伸），需另加 `Modify` 或自定义 pointer 抓取，是另一套交互，做之前要先与用户确认。
- 锁定的圆目前不能点一下重新激活（只有新画的才可调）。

## 相关文档

- `ba6de451-a7df-45f6-a031-d8f4a2ca66d9`：叠加分析整体落地（PostGIS 平面细分、原子面、API 契约、`kind:'shape'` 决定）——本文是它的交互补充。
- `564a4172-29af-4a5a-a5a8-87b0a8821d51`：3857 下 `1/cos(纬度)` 换算的来源，本文 `toMapRadius` 沿用。
- `af40cfc5-8af4-4ba1-ac1f-ea2990af3a42`（D13）：`drawing.js` 工具与回调形态、「换工具即清空」的原始规则，本文对其做了 overlay 例外。
