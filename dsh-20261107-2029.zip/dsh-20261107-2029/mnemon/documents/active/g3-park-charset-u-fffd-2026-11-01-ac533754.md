---
id: "ac533754-9c9f-4b60-a2a1-d073f50a0648"
title: "G3 四张分类热力图：park 必须退回「按个数」分档、charset 坑复发与 U+FFFD 检测法（2026-11-01）"
description: "四张分类 SLD（school/hospital/mall/park）的实施结论：三类沿用相对倍数阈值、park 因倍数量子化（1 个=3.67 倍）必须改用原始个数分档及实测分布证据；CSS 之外两条坑——REST 上传不带 charset=UTF-8 会让中文变 U+FFFD 但渲染照常、必须用 FFFD 计数验证；前端用 updateParams 切换样式而非重建图层。承接 G2 文档 b0122682。"
status: "active"
created_at: "2026-11-01T09:26:12.473Z"
updated_at: "2026-11-01T09:26:12.473Z"
content_hash: "c279c692b3e3bf6ef540d1561bbdd0c17d299540bd5edb02ecf56c7dac1c69cf"
source_paths:
  - "styles/grid_school.sld"
  - "styles/grid_hospital.sld"
  - "styles/grid_mall.sld"
  - "styles/grid_park.sld"
  - "styles/_gen_grid_sld.py"
  - "FE/docs/roadmap.md"
  - "FE/docs/img/grid-heatmap-categories.png"
session_ids:
  - "50ce0fd6-48fb-4dac-9bc5-612c4b1a3231"
memory_body_ids:
  []
---

# G3：四张分类热力图（`grid_school` / `grid_hospital` / `grid_mall` / `grid_park`）

承接 G2 文档 `b0122682-e16e-45ff-b016-93a348f4ef9e`（`grid_total` 的 7 档规则与三个渲染坑）与 G1 文档 `02506967-ac28-421f-886e-e0cc13e39d9f`（图层发布）。G2 结尾留的指引是「四类只需把 `r_total` 换成 `r_school` / `r_hospital` / `r_mall` / `r_park`」——**实测证明这句话对三类成立、对公园不成立**。本篇只记录增量。

## 1. 最终结果（5 个样式全部在线）

| 样式名 | 判定字段 | 配色 | 阈值 | 可见档 |
|---|---|---|---|---|
| `wuhan:grid_total` | `r_total` | YlOrRd | `.2 / 1 / 3 / 10 / 25` | 6（+1 透明） |
| `wuhan:grid_school` | `r_school` | Blues | `.2 / 1 / 3 / 10 / 25` | 5 |
| `wuhan:grid_hospital` | `r_hospital` | Reds | `.2 / 1 / 3 / 10 / 25` | 5 |
| `wuhan:grid_mall` | `r_mall` | YlOrBr | `.2 / 1 / 3 / 10 / 25` | 5 |
| **`wuhan:grid_park`** | **`park`（原始个数）** | Greens | `1 / 2 / 3 / 4` | 4 |

仓库真源：`styles/grid_school.sld`、`styles/grid_hospital.sld`、`styles/grid_mall.sld`、`styles/grid_park.sld`；生成脚本 `styles/_gen_grid_sld.py`（保证四个 SLD 结构一致，改阈值只改脚本里的表）。

## 2. 核心发现：倍数量子化 → 相对分档对 park 失效

按统一阈值先算四类的档位配比，`park` 直接暴露异常：

| 类别 | 无覆盖 | 0.2–1 | 1–3 | 3–10 | 10–25 | ≥25 |
|---|---|---|---|---|---|---|
| school | 30,611 | 3,414 | 2,357 | 2,323 | 1,018 | 97 |
| hospital | 32,501 | 2,757 | 1,500 | 1,851 | 969 | 242 |
| mall | 32,396 | 2,292 | 1,796 | 2,152 | 1,013 | 171 |
| **park** | 34,598 | **0** | **0** | 3,892 | 1,157 | 173 |

`park` 的 `0.2–1` 与 `1–3` 两档**各有 0 个格子**。原因在分母：

```
公园基准 0.1356 /km² × 圆面积 2.0106 km² = 0.2727
0 个 → 0 倍
1 个 → 1 / 0.2727 = 3.67 倍   ← 从 0 直接跳到 3.67
2 个 → 7.33 倍，3 个 → 11.00 倍 …… 步长恒为 3.67
```

倍数是**量子化**的（间距 3.67），小数阈值在这维度上没有意义：图上只会出现 3 种绿，而图例写着「0.2–1 倍平均」却一个格子都没有，读者会以为样式坏了。

### 改用原始个数的实测分布

| `parks_in_circle` | 格子数 | 占比 | 对应 `r_park` |
|---|---|---|---|
| 0 | 34,598 | 86.89% | 0.00 |
| 1 | 2,849 | 7.15% | 3.67 |
| 2 | 1,043 | 2.62% | 7.33 |
| 3 | 538 | 1.35% | 11.00 |
| 4 | 330 | 0.83% | 14.67 |
| ≥4 合计 | 792 | 1.99% | — |

图例写「1 个 / 2 个 / 3 个 / ≥4 个」，**不解释倍数**。

> **可推广判据**：若某类「1 个」的倍数就远超 1（本例 3.67），说明该类的相对倍数失去区分度，应退回绝对数量分档。反过来说，只有分子的最小粒度远小于分母基线时，相对倍数分档才成立。

**注意**：这意味着同一张图集合里**两种图例不能混用**——四类是相对倍数语义，公园是绝对个数语义，图例文案必须分开写。

## 3. 坑 4：REST 上传不带 `charset=UTF-8` → 中文变 U+FFFD，但渲染完全正常

G2 的坑 3 已记录过 GBK 落盘导致 WMS 500（`SAXParseException`）。这次**以更隐蔽的形式复发**：第一批四个样式用 `Content-Type: application/vnd.ogc.sld+xml`（无 charset）POST/PUT，结果是：

| 现象 | 结果 |
|---|---|
| 图层渲染 | **完全正常**，HTTP 200、字节数正常 |
| 严格 UTF-8 解码 | **通过**（字节序列合法） |
| 内容里的 U+FFFD 替换字符 | **有** —— 中文全变成 `�` |

即：解码合法性 ≠ 内容正确。旧坑的报错形态（解析失败 500）这次没出现，所以不看内容就发现不了。

### 一行诊断（必须做）

```powershell
$s = [Text.Encoding]::UTF8.GetString([IO.File]::ReadAllBytes("stored.sld"))
([regex]::Matches($s, [char]0xFFFD)).Count    # 必须为 0
```

取存储版的地址：`GET /rest/workspaces/wuhan/styles/<name>.sld`。

### 修复

上传/覆盖时把 `Content-Type` 写成 `application/vnd.ogc.sld+xml; charset=UTF-8`，重传后复查五个样式 `FFFD=0`、`<sld:Title>` 中文正常。修复后 GeoServer 会重新序列化（约 4,860 字符、CJK 39 字、注释被丢弃），**仓库里的 `.sld` 才是可读真源**。

> 通用教训：凡「Windows + 中文 + XML/JSON 上传」，`Content-Type` 必带 `charset=UTF-8`；且**验收要看 U+FFFD 计数，不要只看渲染成功或 HTTP 200**。

## 4. 前端切换样式：不重建图层

```
.../wms?layers=wuhan:grid_500m&styles=wuhan:grid_park&...
```

OpenLayers 里改样式只重发请求：

```js
layer.getSource().updateParams({ STYLES: 'wuhan:grid_school' })
```

比换图层/重建 source 快得多，也不需要为 5 个样式发布 5 个图层。

## 5. 验收自检（本次实际执行）

- 上传返回 201（首次）/ 200（覆盖），工作区样式清单出现 `grid_school / grid_hospital / grid_mall / grid_park`。
- 五个样式 WMS 渲染自检：全部 HTTP 200 且非空（`grid_total` 62,967 B、`school` 54,045 B、`hospital` 45,461 B、`mall` 43,267 B、`park` 34,999 B）。
- 存储版 `Abstract` 抽查中文正确：`每个 500m 格子的中心 800m 步行圈内公园数量（原始个数）。`

文档配图：`FE/docs/img/grid-heatmap-categories.png`（2×2 合成对比图，比四张分开更便于对照）；`FE/docs/img/grid-heatmap-city.png` 与 `grid-heatmap-zoom.png` 见 G2。

## 6. 落地位置

- 设计/踩坑叙述进了 `FE/docs/roadmap.md` 的 **§2.4.12 G3：四张分类热力图**（G2 在 §2.4.11）；roadmap 里同时保留了「两种图例不能混用」的提醒。
- 顺手修掉的模板 bug：`title[:-2]` 截断「可达性」只去掉 2 字，生成了「公园**可**数量」，四类 `Abstract` 全部改为「…数量」。
