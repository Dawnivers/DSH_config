---
id: "6c405b1e-c8cb-4ed3-b4c7-032caf043b73"
title: "GeoServer 多几何列只取「列顺序第一个」：实测证据、界面不可改、三条修法（grid_500m 撞坑，2026-11-01）"
description: "实证 GeoServer/PostGIS 数据存储在表或视图含多个几何列（grid_500m 的 Polygon geom 与 Point centroid）时的默认几何判定规则——按列顺序取第一个几何列，不看类型、界面无开关；含对照视图实验数据（同数据不同列序渲染成面 vs 点）、Wicket 编辑图层页确认「Customize attributes」只改 Nillable/出现次数、三条修法（推荐只暴露 geom 的视图、重排原表列序不可行的原因、把 centroid 转 text）与发布后自检方法。承接 G1 发布文档 02506967。"
status: "active"
created_at: "2026-11-01T08:57:03.986Z"
updated_at: "2026-11-01T08:57:03.986Z"
content_hash: "6e122c82c7e35d27d1a40a59f9e41a8e3f27c3f77987d6ac48739e78406f4e68"
source_paths:
  - "BE/db/03_refresh_grid_500m.sql"
session_ids:
  - "2096ad12-bbb5-44ab-9e04-7deebeb0c165"
memory_body_ids:
  []
---

# 多几何列的默认几何规则：实测结论与修法

承接 G1 发布文档 `02506967-ac28-421f-886e-e0cc13e39d9f`（该文只提出「双几何列可能选错 centroid」的风险与双验证法）。本篇回答后续追问的实操问题：**发布后发现选到 `centroid`，怎么改？** 答案分两层——规则是什么、以及为什么界面帮不上忙。

## 1. 结论先行

> GeoServer 的 PostGIS 数据存储把表/视图里的每个几何列都当成「一个几何属性」，**默认几何 = 列顺序中的第一个几何列**，不看类型（Point/Polygon 一视同仁），**Web 界面没有可切换的开关**。

所以「选错」不是配置错，是**列序错**。修法只能在数据侧解决。

## 2. 对照实验（同一份数据、只换列序）

```sql
-- 故意把 centroid 排在 geom 前面
CREATE VIEW _test_geomorder AS
SELECT gid, centroid, geom
FROM grid_500m WHERE gid < 50;
```

| 对象 | 列顺序 | 属性类型探测 | WMS GetMap 渲染 |
|---|---|---|---|
| `grid_500m`（原表） | `gid, **geom**, centroid, …` | geom→Polygon，centroid→Point | 600×600 **方格（面）** ✅ |
| `_test_geomorder`（视图） | `gid, **centroid**, geom` | 同上，仅顺序不同 | **红点（点）** ❌ |

补充证据：WFS/GetFeatureInfo schema 里两列都在（`centroid`→`gml:PointPropertyType`、`geom`→`gml:SurfacePropertyType`），要素同时带 `<wuhan:centroid><gml:Point>` 与 `<wuhan:geom><gml:Polygon>`——**两个几何都返回，只是渲染取第一个**。

实验用到的坑：`/geoserver/wuhan/ows` 这类工作区级 OWS 端点在本机返回 **404**，WFS 要打全局 `/geoserver/ows` 或 `/geoserver/wfs`；PowerShell 拿回 XML 时别用 `Invoke-WebRequest` 直接当字符串处理（失败会连带 `Matches`/`Substring` 报 null）。

**实验对象已全部清理**（REST 删图层 + `DROP VIEW`），清理后 `wuhan` 图层清单恢复为 `admin_area / empty_poi / grid_500m / poi` 四个，`grid_500m` 出图字节数正常（2013 bytes @ 小 bbox）。

## 3. 为什么界面改不了

`grid_500m` 编辑图层页 →「数据」页签 →「要素类型」区：

```
☐ Customize attributes
属性      类型      Nillable  Min/Max
geom      Polygon   false     1/1
centroid  Point     false     1/1
cell_i    Integer   true      0/1
...
```

勾上 `Customize attributes` 后能改的只有 **Nillable 与出现次数（Min/Max Occurrences）**，**没有「哪个是默认几何」这一项**。GeoServer 把多几何列建模为多个几何属性，默认几何由属性顺序决定，界面从未暴露该开关。

## 4. 修法 A（推荐）：发布只含 `geom` 的视图

不动原表，最干净：

```sql
CREATE OR REPLACE VIEW grid_500m_v AS
SELECT gid,
       geom,                 -- 唯一几何列，且排第一
       cell_i, cell_j,
       total, school, hospital, mall, park,
       r_total, r_school, r_hospital, r_mall, r_park
FROM grid_500m;
```

三个理由：

| 好处 | 说明 |
|---|---|
| 几何唯一 | 无从选错，且以后加列也不会翻转顺序 |
| `GetFeatureInfo` 更干净 | 不再返回嵌套的 Point 对象 |
| 前端不缺坐标 | 面的顶点里已有坐标，`centroid` 非必需 |

三条必须知道的性质：

- **视图是实时查询**：`03_refresh` 更新基表后视图自动反映，**无需重建视图**；
- **索引仍生效**：PostgreSQL 会把简单视图内联到基表，`geom` 的 GIST 索引照常命中；
- **视图只读**：GeoServer 只能查不能写——本项目不需要写，无影响。

发布步骤：psql 建视图 → 图层 → 添加新的资源 → 工作区 `wuhan` / store `spatial_db` → 勾 `grid_500m_v` → 数据页签 SRS 填 `EPSG:4326` 并「从数据中计算」→ 发布页签选默认样式 → 保存 → 预览确认是方格 → 确认无误后再删旧 `grid_500m` 图层。

## 5. 修法 B（本阶段不可行）：重排原表列序

要 `geom` 成为第一个几何列只能 `ALTER TABLE ... DROP COLUMN centroid`，但 `centroid` 是统计与前端定位的必需字段，删不得。真要做等于重建整表（`01` 改列序 → `02` 重生成 → `03` 重算，约 15 分钟）。**只在尚未算数据、刚建表时值得做。**

## 6. 修法 C：既想暴露 centroid 又不让它当几何

把它转成非几何类型即可，GeoServer 不会再当候选几何：

```sql
CREATE OR REPLACE VIEW grid_500m_v AS
SELECT gid,
       geom,                               -- 第一几何列 ✅
       centroid::text AS centroid_wkt,     -- WKT 文本，不再是 geometry
       total, school, ...
FROM grid_500m;
```

不需要坐标时直接用修法 A 的省略版更简单。

## 7. 发布后的自检（任一不过即说明选错）

1. **出图看形状**（最快）：打一个小 bbox 的 `GetMap`（`image/png`，400×400），**方格=对，散点=错**。空白/异常时先比对字节数（几百字节≈空图，几千以上≈有内容）。
2. **查 `geometry_name`**：`GetFeatureInfo`（`info_format=application/json`）响应里的 `"geometry_name"` 必须是 `geom`，`geometry.type` 必须是 `Polygon`。

两条都要做：只看出图，缩得很小时点阵与灰面可能难分辨；只查属性，不证明渲染取的就是那个几何。
