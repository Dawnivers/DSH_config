---
id: "953b3a3c-92ec-4ac6-b6cf-587e0e6894f2"
title: "点格取值的三处修正：按几何包含挑格（弃 features[0]）+ zoom&lt;11 拦截 + 防 GeoServer 200+XML 异常"
description: "实测证据与落地修正：GetFeatureInfo 返回几何已是请求 SRS(3857) 不能再按 4326 解；低缩放 FEATURE_COUNT 截断会返回邻居格子故须做几何包含判定；zoom 可靠性实测边界与 MIN_GRID_ZOOM=11 的保守取值；GeoServer 报错返回 HTTP 200+XML 需先读 text 再解析；OL import 必须带 .js 扩展名；含桩对象接真实 pickGrid 的验证手法与提交 5cec4c6。"
status: "active"
created_at: "2026-11-01T12:21:50.268Z"
updated_at: "2026-11-01T12:21:50.268Z"
content_hash: "1e80d7fc973a4a7a5823adeb6ac68c8959b56d58e5b8cb0588ade6b2d51ea72c"
source_paths:
  - "FE/src/map/gridInfo.js"
  - "FE/src/view/mapView.vue"
  - "FE/src/stores/grid.js"
  - "FE/src/components/GridPopup.vue"
  - "FE/src/App.vue"
session_ids:
  - "336041bf-a794-4bdd-b504-967053f98995"
memory_body_ids:
  []
---

# 点格取值修正：几何包含 + 缩放门槛 + 200+XML

> **本文是更正与补充，不是重复。** 既有文档
> `b4346af9-bbcb-47b6-b128-5f360391455d`（F4 点格弹窗）把 `pickGrid` 写成「取
> `features[0].properties`」，**这条已被实测推翻**；其分层（`map/` → `stores/` → `components/`）、
> `singleclick` 热力优先分叉、零覆盖返回空数组不是错误等结论仍然有效。
> `getFeatureInfoUrl` 的 101×101 窗口语义见 `8af60aef-8742-4d45-a743-efdbecbc6ca8`，
> 格子数据口径见 `7e3e84a2-3ab6-4682-9580-62fa711654a3` 与 `02506967-ac28-421f-886e-e0cc13e39d9f`。

## 0. 结论先行

1. **不能取 `features[0]`**：低缩放下 `FEATURE_COUNT=8` 会截断，返回的可能是**离点击点很远的格子**。
   必须逐个候选做**几何包含**判定，只认真正盖住点击点的那一个。
2. **几何无需再变换**：`GetFeatureInfo` 跟着请求里的 `SRS` 返回，本项目 `SRS=EPSG:3857`
   （= view 投影），回来的坐标**已经是 3857**。写成 `dataProjection: 'EPSG:4326'` 会把 3857 数值
   当度数读，几何范围变 `Infinity`，`intersectsCoordinate` **永远判不中**。
3. **`MIN_GRID_ZOOM = 11`**：zoom≥10 实测 3/3 全中，但 z10 候选数 6–8 已贴着 `FEATURE_COUNT=8`
   上限，换位置可能漏；z11 候选只剩 1–2 个，取保守值 11。
4. **GeoServer 报错返回 `HTTP 200 + XML`**，`res.json()` 只会抛 `Unexpected token '<'`，
   把真实原因埋掉。必须先 `res.text()`，失败时提取 `<ServiceException>` 文本。

## 1. `features[0]` 错在哪（实测）

用同一坐标（江汉路格心，正确值 **176**）在真实 GeoServer 上跑：

| zoom | 1px 对应米 | 候选数 | `features[0]` 结果 |
|---|---|---|---|
| **9** | 305.7 | **8** | **146** ❌ |
| 10 | 152.9 | 6–8 | 176 ✅ |
| 11 | 76.4 | 1–2 | 176 ✅ |
| 12 | 38.2 | 1–2 | 176 ✅ |
| 14 | 9.6 | 1 | 176 ✅ |

z9 的 8 个候选**格心全在点击点西侧两格**：

```
total=146  格心 114.2750,30.5795  含点击点=false
total=199  格心 114.2750,30.5840  含点击点=false
total=174  格心 114.2750,30.5885  含点击点=false
total= 90  格心 114.2750,30.5930  含点击点=false
total=169  格心 114.2795,30.5795  含点击点=false
total=153  格心 114.2795,30.5840  含点击点=false
total=144  格心 114.2795,30.5885  含点击点=false
total=109  格心 114.2795,30.5930  含点击点=false
点击点: 114.2843,30.5843
```

**原因**：查询窗口固定 101×101 像素，BBOX 宽度 = 101 × resolution。z9 时窗口约 **30,881 m** 宽，
盖住上千个格子，GeoServer 按 `FEATURE_COUNT=8` 截断，返回的是**表里靠前的几条**，
与点击位置无关（没有按距离排序）。z14 窗口仅 965 m，刚好一个格子。

## 2. 修正后的取值逻辑

```js
import GeoJSON from 'ol/format/GeoJSON.js';
const geoJson = new GeoJSON();

for (const f of data.features) {
  // 几何已经是请求 SRS（3857），不要再传 dataProjection
  const geom = geoJson.readGeometry(f.geometry);
  if (geom.intersectsCoordinate(evt.coordinate)) {
    return f.properties ?? null;
  }
}
return null;
```

配套：`export const MIN_GRID_ZOOM = 11;`，`view.getZoom() < MIN_GRID_ZOOM` 时**不发请求**，
卡片给中性提示（如「请放大到街区级再点格子（当前 z9.0，需 ≥ z11）」），而不是当成错误。

修正后同一套探针的回归结果：

```
MIN_GRID_ZOOM = 11
zoom  9 -> null   64≠82   66      ← 被门槛拦截（若放行则取到错格）
zoom 10 -> 176✓   82✓     66✓
zoom 11 -> 176✓   82✓     66✓
zoom 12 -> 176✓   82✓     66✓
zoom 14 -> 176✓   82✓     66✓
```

## 3. GeoServer 的 200 + XML

图层参数不合法时（例如探针里 `QUERY_LAYERS` 的图层没同时出现在 `LAYERS` 中）：

```
HTTP 200  <ServiceException>QUERY_LAYERS contains layers not cited in LAYERS.
          It should be a proper subset of those instead</ServiceException>
```

`res.json()` 直接抛 `SyntaxError: Unexpected token '<'`（错误栈指向 undici `parseJSONFromBytes`），
真实原因完全丢失。做法：先 `res.text()`，`try { JSON.parse(text) } catch`，
用正则抽 `<ServiceException[^>]*>([\s\S]*?)</ServiceException>` 的消息；UI 只显示
「格子查询失败（详情见控制台）」，`console.warn` 留原始信息。

注意：用**自建探针**手拼 `GetFeatureInfo` URL 时必须把 source 自己的 `LAYERS`/`STYLES` 一起带上，
`QUERY_LAYERS ⊂ LAYERS`。真实链路里 `ImageWMS` 会合并 source params，所以线上不报这个错——
这是**探针问题**，但也因此暴露了上面的解析缺陷。

## 4. 项目约定：OL 的 import 必须带 `.js`

用 Node 直接 import 前端模块做验证时，裸路径会 `ERR_MODULE_NOT_FOUND`：

- `ol/format/GeoJSON` → 必须写 `ol/format/GeoJSON.js`
- 本地模块 `./heatmap` → 必须写 `./heatmap.js`

项目里所有 OL import 本来就带 `.js`，这里漏写算是真 bug。追加 `.js` 后 `import` 真实
`pickGrid` 才能跑起来。

## 5. 验证手法（可复用）

不靠推测：用桩对象冒充 `map` / `ImageWMS`（含其自身 `params`：`LAYERS`/`STYLES`/`FORMAT` 等），
**import 项目里真实的 `pickGrid`**，对真实 GeoServer 发请求，按「已知格心坐标 + 已知 total」
断言返回的 `total` 是否等于期望值，并在多个 zoom 上跑（9/10/11/12/14）。

配套命令：`npm run build` 验证（本次 267 modules / 324 ms ✅），再刷新 5173 页面确认图层面板
正常渲染（证明新 import 没有运行时爆炸）。

## 6. 涉及文件与提交

| 文件 | 变化 |
|---|---|
| `FE/src/map/gridInfo.js` | 几何包含挑格、`readGeometry` 去掉 `dataProjection`、`MIN_GRID_ZOOM`、200+XML 解析、带 `.js` 的 import |
| `FE/src/view/mapView.vue` | 低缩放拦截与提示 |
| `FE/src/stores/grid.js` | 错误态存放（`setError` / `clear`） |
| `FE/src/components/GridPopup.vue` | 中性提示文案、数字统一 `Number()` |
| `FE/src/App.vue` | 弹窗挂载位置 |

提交链：`b67eb6f`（07 点格弹窗）→ `cf517f2`（08 修正 `getFeatureInfoUrl` 注释错误）→
**`5cec4c6`（09 本次修正）**，已 push 到 `main`。

## 7. 仍待人工确认

浏览器端手动验收未完成（点 canvas 工具受限）：勾热力图 → 放大到 z≥11 → 点深红块 → 应弹「176」；
z<11 点应看到「请放大到街区级」提示而非错误。
