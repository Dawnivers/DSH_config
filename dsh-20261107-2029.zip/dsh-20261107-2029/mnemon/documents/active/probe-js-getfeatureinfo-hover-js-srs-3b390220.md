---
id: "3b390220-5bbb-4d43-b8ca-60b0421972db"
title: "悬停高亮实现：probe.js 统一 GetFeatureInfo 探针 + hover.js 双层描边/光圈（几何随 SRS 返回、三重节流锁）"
description: "鼠标悬停高亮（热力图格子描边+总数、POI 白晕光圈+名称）的落地记录：为何位图层也能拿到几何、GetFeatureInfo 在 SRS=3857 下直接回米制几何因而不做投影变换、probe.js 与 clickToGid/gridInfo 的统一、独立 ol-hover 层不参与去色、三重锁与低缩放不探针的性能依据（12ms/700B）、无文本 canvas 无法用元素选择器验证的误判教训、提交 e210f79。"
status: "active"
created_at: "2026-11-01T12:37:29.289Z"
updated_at: "2026-11-01T12:37:29.289Z"
content_hash: "2b4f689ae756f54380060b47748ef6be750ea2cbf22f2cb583d3f02526149e92"
source_paths:
  - "FE/src/map/probe.js"
  - "FE/src/map/hover.js"
  - "FE/src/map/clickToGid.js"
  - "FE/src/map/gridInfo.js"
  - "FE/src/view/mapView.vue"
session_ids:
  - "24e21080-4ba7-4b72-94f3-41c0acabfdde"
memory_body_ids:
  []
---

# 悬停高亮（hover）实现与取舍

提交：`e210f79  08 悬停高亮：抽出 probe.js 统一探针，热力图格子描边+总数、POI 光圈+名称（节流/位移/结果三重锁）`（5 files, +426 / −105，已推到 `Dawnivers/ServiceAvailable` main）。

前置文档（勿重复实现，只引用）：

- `b4346af9-bbcb-47b6-b128-5f360391455d`：F4 点格弹窗、`pickGrid` 的三道防线、`getFeatureInfoUrl` 的 101×101 窗口与 bbox 缓存前提、POI 误挂 `ol-layer-base`。
- `da1967ee-48c7-4bea-a9b9-e8a2e803d61e`：F1 热力图接入、`className` 必须挂 layer、heat↔poi 互斥、建层顺序。
- `81c93b00-c684-4f65-a859-87e533a10776`：D13 分析模式灰化。
- `02506967-ac28-421f-886e-e0cc13e39d9f`：`wuhan:grid_500m` 的 GetFeatureInfo 返回字段（`total/school/hospital/mall/park` + `r_*` + `centroid`）。

## 1. 关键实测事实：位图层也能拿到几何

原判断「`ImageLayer + ImageWMS` 手上没有 Feature，所以高亮无从谈起」只对了一半——**没有 Feature 对象，但服务端会把几何一起吐回来**。实测（请求 `SRS=3857`）：

```
features 数 = 1
id = grid_500m.15533
geometry.type = Polygon
第一个顶点 = 12719810.2960026, 3532117.91067106   ← 米，不是度数
properties.total = 0
```

推论（这套 hover 能成立的全部依据）：

1. 前端**不需要**预存要素、不需要 WFS、不需要 MVT。
2. 回来的几何**已经在请求的 SRS 下**（OL 自动拼的 `SRS=EPSG:3857`，因地图 view 是 3857）。所以 `probe.js` **绝不能**再传 `dataProjection: 'EPSG:4326'` 去解——那样会得到 `Infinity` 或离谱偏移。判据：坐标量级 `1.2e7` = 米；量级 ~114 = 度。
3. 每次只回 1 个要素、约 700 B、响应 **12 ms**（首次 65 ms 是建连），悬停频率撑得住。

## 2. 结构：探针统一，表现分离

| 文件 | 职责 |
|---|---|
| `FE/src/map/probe.js`（新） | `probeFeature(map, evt, layerId, extra, { requireContain }) → { id, geometry, properties } \| null`，唯一的 GetFeatureInfo 通道 |
| `FE/src/map/hover.js`（新） | `createHoverController(map) → { setMode('grid'\|'poi'\|null), clear(), destroy() }` |
| `FE/src/map/clickToGid.js` | 改为复用 `probeFeature`，不再自带 fetch |
| `FE/src/map/gridInfo.js` | 同上；`MIN_GRID_ZOOM` 继续对外导出 |
| `FE/src/view/mapView.vue` | 建 hover 控制器 + `registerWatcher('hover', …)` 同步模式，`onBeforeUnmount` 里 `destroy()` |

理由：点击（取 gid / 取格子属性）和悬停（取几何）问的是**同一件事**——「这点是什么」。两份 fetch 必然在错误处理、坐标系、要素挑选上漂移。统一到一条探针后，两处坑只修一次。

`probeFeature` 内保留的两个踩出来的坑：

- **GeoServer 出错回 HTTP 200 + XML**：先 `res.text()` 再 `JSON.parse`；解析失败时从 `<ServiceException>` 里抠出真实报错再抛，否则界面只会看到一句无信息的 JSON 错误。
- **一个像素压住多个要素、返回顺序无保证**：`requireContain: true` 时逐条 `intersectsCoordinate` 挑真正包含点击点的那个（101 px 窗口在 z9 可宽达 30 km，靠 `FEATURE_COUNT` 截断的顺序不可信）。

## 3. 视觉实现（用户要求「尽量好看」）

一格/一点要在深红格子和浅黄格子上都看得见，单色描边做不到，所以都叠**两层 Style**。

热力图格子（`hover.js`）：

```js
// 外层：深墨蓝 5px + 极淡白填充 → 在浅色格子上撑出边界
{ stroke: 'rgba(16, 42, 67, 0.55)', width: 5, fill: 'rgba(255,255,255,0.10)' }
// 内层：纯白 2px → 在深红格子上才看得见的那一圈
{ stroke: '#ffffff', width: 2, text: `${total} 个` }
```

POI：

```js
{ radius: 15, stroke: 'rgba(255,255,255,0.95)', width: 6 }  // 白晕，把图钉从底图抠出来
{ radius: 15, stroke: '#1565C0', width: 2.5, fill: 'rgba(21,101,192,0.14)', text: name } // 主色光圈 + 名称
```

文字标签统一「深墨蓝底 + 白字 + padding」模拟胶囊；NAME 截断 12 字、向上偏移 26 px。

独立图层：`zIndex: 90`（高于 WMS 的 0/10，低于分析图形的 100），`className: 'ol-hover'`，**不挂 `ol-layer-base`** → 任何模式下都不会被灰度滤镜吃掉。

## 4. 性能：三重锁 + 两条硬闸

| 锁 | 阈值 | 作用 |
|---|---|---|
| 时间锁 | 90 ms | 冷却期不重复发；另挂拖尾定时器，保证鼠标停住时最后一格仍会亮 |
| 位移锁 | 5 px | 手抖不算移动 |
| 结果锁 | 同 `id` | 还在同一格就不重画，跨格才更新 |
| 在途锁 | — | 慢请求不堆叠 |

硬闸：

- `if (evt.dragging) return;` —— 拖地图时不发请求。
- `zoom < MIN_GRID_ZOOM (11)` 不探针。z9 时一格仅 1–2 像素，101 px 窗口内候选格子可能根本不在鼠标下；宁可不亮也不能亮错格（与 F4 点格同一判据）。

节流后悬停 2 秒约 3–8 次请求，对 GeoServer 可忽略。

## 5. 模式切换

```js
function syncHover() {
  if (analysis.active) hover.setMode(null);            // 分析时鼠标在选中心，别抢
  else if (layerStore.visible.heat) hover.setMode('grid');
  else if (layerStore.visible.poi) hover.setMode('poi');
  else hover.setMode(null);
}
registerWatcher('hover', () => [analysis.active, layerStore.visible.heat, layerStore.visible.poi], syncHover);
```

遵守项目约定：watch 一律走 `watchControl/watchController.js` 的 `registerWatcher`，不直接写 vue `watch()`（`stopAll()` 才能一次清干净）。`destroy()` 里 `unByKey(pointermove)` + `map.removeLayer()`。

## 6. 验证边界与一条误判教训

| 项 | 结果 |
|---|---|
| `vite build` | ✅ 269 modules / 353 ms |
| 页面 reload | ✅ 无异常 |
| GetFeatureInfo 带几何（3857） | ✅ 顶点 1.27e7 米 |
| 探针耗时 | ✅ 12 ms |
| **悬停的实际渲染** | ⚠️ 未验到 —— 浏览器工具只能按元素索引点击，**无法在地图画布上移动鼠标** |

**误判教训**：查 `#map .ol-hover`、`#map div.ol-layer`、`.ol-layer-base` 全部返回 `No element matched selector`，一度以为高亮层没挂上。但 `.ol-layer-base` 也查不到而**去色确实生效**——说明该读取工具只匹配含文本的元素，对无文本的 canvas/空 div 一律「无匹配」。**「选择器查不到」不等于「DOM 不存在」**，尤其对 canvas 渲染层；这类结论只能用可观测行为（样式生效、图例文本、控制台）证伪。

留给用户的 30 秒验收清单：POI 上划 → 蓝圈+白晕+名称；开热力图并 z≥11 划深红格 → 深蓝+白双层描边 +「176 个」；空白处 → 自动消失；进分析模式 → 全部停止。

排错索引：有圈无名字 → `properties.name` 字段名；描边位置偏移 → 几何被当 4326 解（查 `probe.js` 是否多传 `dataProjection`）；完全没反应 → `pointermove` 未触发或控制台报错。

## 7. 未做 / 可继续

- 悬停未用真实鼠标验证（工具限制），渲染细节可能仍需一轮人工回归。
- 悬停气泡是 canvas 标签而非 DOM 卡片，长名称只能截断；若以后要富文本（图标、按钮），需换成 Overlay。
