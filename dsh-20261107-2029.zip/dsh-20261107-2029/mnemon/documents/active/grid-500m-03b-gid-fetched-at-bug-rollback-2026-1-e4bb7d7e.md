---
id: "e4bb7d7e-f4a3-401e-a566-739be00284d0"
title: "grid_500m 增量刷新 03b：gid 标记法、fetched_at 首跑漏数 bug、ROLLBACK 试验法与「改坐标必跑全量」边界（2026-11-01）"
description: "在 03 全量刷新之外新增的 BE/db/03b_refresh_incremental.sql 增量方案实施记录：为何只重算受影响格子（每 POI 约 9.34 格）、刷新标记表 grid_500m_refresh_state 与 gid 递增检测（替代 fetched_at，附首跑静默漏数的实测证据）、事务内换 ROLLBACK 的安全验证法与 788ms 实测、DELETE 拦截与 UPDATE 改坐标静默漏算的已知边界、03 与 03b 交替使用的一致性保证。"
status: "active"
created_at: "2026-11-01T07:34:51.779Z"
updated_at: "2026-11-01T07:34:51.779Z"
content_hash: "5bc0a43424433d3c55636ae833b435a6c4fdacb1589788b9737c9e63c1186ff1"
source_paths:
  - "BE/db/03b_refresh_incremental.sql"
  - "BE/db/03_refresh_grid_500m.sql"
  - "BE/db/README.md"
session_ids:
  - "e0e6396e-0025-4c17-b6a9-3ddf714e461b"
memory_body_ids:
  []
---

# grid_500m 增量刷新（03b）

承接全量实施记录 `78d9ef59-2a33-4d23-acd5-69e269678eac`（四脚本清单、动态分母）与 `670609e7-9a57-4551-abbc-294345b6bd63`（预计算刷新策略取舍、每 POI 约 9.34 格）。那两篇讲**全量刷新与口径**；本篇只讲**加了新 POI 之后如何增量更新**，以及增量方案的能力边界。

起点问题：「之后新增 poi 数据行，只需要重跑 `03` 吗？」

答：**正确但很浪费**。`03` 每次都从 `poi` 全表重新聚合，39,820 格全部重算，5–15 分钟；而一条 POI 平均只影响约 9.34 个格子。删除/改坐标仍必须走全量。

## 1. 交付物

`BE/db/03b_refresh_incremental.sql`（约 8.3 KB），与 `01/02/03/04` 同目录。

## 2. 流程

```
① 查本次新增 POI（gid > 上次记录的 last_max_gid）
② 只找出这些 POI 粗筛范围覆盖的格子（实测每 POI 约 10 格）
③ 这些格子先置 0，再精确重算（粗筛方框 + 精算 800m 圆，同 03 的两层夹逼）
④ 全表重算 5 个 r_ 倍数列（纯算术，1–2 秒；因为分母被新数据改变了）
⑤ 推进标记
```

第 ④ 步不能省：新增 POI 改变了分母，`avg(r_*)` 必须重新自洽（实测保持 1.0001）。

## 3. 必须用 `gid` 递增，不能用 `fetched_at`

第一版用 `fetched_at`（列默认 `now()`，看起来天然适合当「新增标记」）。事务内实测暴露真 bug：

- 首次运行时标记表初始化为**当前时刻**；
- 刚插入的 POI 的 `fetched_at` 也等于当前时刻；
- `fetched_at > 标记` 恒为 false → 新增数据被静默漏掉。

实测输出即为 `本次新增 POI: 0 条，受影响格子: 0 个`，而实际上确实刚插过数据。

改用 `gid > last_max_gid`：`gid` 是 serial 单调递增，不依赖时钟与时区，精确无歧义。删除检测用「当前行数 < 上次行数」→ `RAISE EXCEPTION` 拦截，不静默算错。

**可复用的教训**：用时间戳做增量水位，在「水位初始化时刻 ≈ 数据写入时刻」的场景必然漏数；能选单调序列就别选时间。

## 4. 验证方法：把它塞进事务再 `ROLLBACK`

正式脚本里是 `COMMIT`，测试时换成 `ROLLBACK` 在库上真跑一遍（含 `INSERT` 测试数据），跑完数据零残留。这比「读代码确认逻辑对」强得多，能抓到上面那种时序 bug。

配套检查：插入前后取同一区域的格子聚合（`cells / sum_total / sum_school / sum_hospital`），以及全表一致性自检。

实测（插入 2 条 POI：1 学校 + 1 医院，位置相距很远）：

| 指标 | 前 | 后 | 差 |
|---|---|---|---|
| 受影响格子 | 21 | 21 | — |
| `sum(total)` | 445 | 463 | **+18** |
| `sum(school)` | 111 | 121 | **+10** |
| `sum(hospital)` | 156 | 164 | **+8** |

`+10 + 8 = +18` 自洽；`sum4 ≠ total` 的格 0；`total` 为 NULL 0；`avg(r_total)` 1.0001；**耗时 788 ms**（对比全量 5–15 分钟）。

单条 POI 场景：影响 10 个粗筛格，其中 9 格 0→1，1 格（`gid 30382`）因超出 800 m 圆、只在方框内而**正确保持原值** —— 这正是双层夹逼生效的证据。

**测试脚本自身也会犯错**：第一次「插入后」的查询被写在 `ROLLBACK` 之后，读到的是回滚后状态，看起来像「增量没生效」。顺序错了要重测，不要急着改正式脚本。

## 5. 能力边界（已写进 README）

| 操作 | 03b 能否检测 |
|---|---|
| `INSERT` 新 POI | ✅ |
| `DELETE` POI | ⚠️ 行数变少 → `RAISE EXCEPTION` 拦住，让人去跑全量 |
| `UPDATE` 改 POI 经纬度 | ❌ **检测不到，静默漏算** |

第三行最危险：`gid` 不变 → 脚本认为无新增 → 旧格子数字不减少、新格子数字不增加 → 热力图悄悄错了。**改坐标必须跑 `03` 全量。**

## 6. 两个脚本的一致性契约

`03`（全量）末尾也会 upsert 标记表：

```sql
INSERT INTO grid_500m_refresh_state (id, last_max_gid, poi_count, refreshed_at)
SELECT 1, max(gid), count(*), now() FROM poi
ON CONFLICT (id) DO UPDATE SET ...
```

所以 03 与 03b 可以任意交替使用，标记始终表示「已完整反映到哪一条」。缺这一步就会出现「跑过全量之后 03b 把全部 POI 当新增再算一遍」或相反的漏算。

## 7. 当前状态

后端 B1–B5 固化完毕，`BE/db/` 六个文件：`01_ddl`、`02_build`、`03_refresh`（含标记同步）、`03b_refresh_incremental`、`04_verify`、`README`。临时测试脚本已清理，库中测试数据确认清零、标记表未被创建（全部回滚）。下一步是 GeoServer：G1 发布 `wuhan:grid_500m`（EPSG:4326），G2 写 `grid_total` SLD，阈值 `[0.2, 1, 3, 10]`，第 1 档透明（0.2 恰等于零值格边界）。
