---
id: "9cf2539b-5c5f-4a92-a4a7-e6c92428803f"
title: "DSH 周备份定时从任务看板迁到 schedule 插件（2026-11-07 迁移记录与机制差异）"
description: "记录 2026-11-07 把 DSH 配置周备份（周日 22:00）从任务看板卡 ead69e05 迁到 schedule 插件任务 schedule-d248da8c 的完整过程：看板 ledger 存储位置与「禁插件只停调度不删数据」结论、两种载体的补发/会话绑定机制差异、双调度冲突必须停一边、60 秒 after 任务实测投递链路、回滚方式与仍待执行的插件禁用项。"
status: "active"
created_at: "2026-11-07T12:23:11.526Z"
updated_at: "2026-11-07T12:23:11.526Z"
content_hash: "bf3256ec9d6ecc938cfc6e0e0d5790b5fad592941a68de9892e5a5121d18cd27"
source_paths:
  - "dsh-migration/publish-dsh.ps1"
session_ids:
  - "82368f2c-1a26-4948-a98b-d8638ff3e7a8"
memory_body_ids:
  []
---

# DSH 周备份定时：看板卡 → schedule 插件（2026-11-07 迁移记录）

起点问题：用户问「把任务看板插件关掉，我看板上的 DSH 周备份任务会消失吗」。结论是**数据不丢、调度会静默停**；用户随后选择「先迁到 schedule 插件、验证一次后再关看板」。

相关文档：`3a43c83f`（看板卡 prompt 冻结与 tag.promptPrefix 补丁，卡 `ead69e05` 的来历）、`284e4a5f`（备份发布流水线 publish-dsh.ps1 与 token/代理细节）、`727cfe91`（三种定时载体能力边界对比，本文是其结论在真实备份任务上的落地）。

## 1. 关键结论：关看板插件，任务不消失但不再自动跑

| 层面 | 结果 |
|---|---|
| 数据 | 不丢。任务定义在 `~/.dsh/task-board/ledger-v2.json`（schemaVersion 5，另有 `scheduler-v2.json` 只存 `lastTickAt`），**不在插件目录内**；禁插件/重装/升级都不动它 |
| 调度 | 停。跑 cron 的是看板插件的 host 侧（`@linxin666/dsh-client-ui-task-board` 0.4.5，内含 `setInterval` + cron tick + `armSchedule`）。插件关掉后没有任何代码读台账里的 `schedule`，**静默停止、无提示** |

据此推翻了先前「为省 token 关掉 web-ui-task-board」的建议（该插件 8 个工具只用 3 次，但它同时是周备份的唯一调度器）。

## 2. 看板实现上的一个硬伤：错过的触发永不补跑

读 `lib` 内实现得证：`recoverSchedule()` 启动时调 `skipMissed(now)`，把已过期的 `nextRunAt` 直接滚到下一个未来目标；源码注释明写契约 *"missed triggers are skipped, never replayed"*。也就是**周日 22:00 那一刻 DSH Desktop 没开着，那周的备份就永久漏掉**，且无任何提醒。迁移前三次（10-18、10-25、11-01）都准点成功，是因为三个周日桌面都在跑。

## 3. 迁移结果

| 项 | 值 |
|---|---|
| 新任务 id | `schedule-d248da8c-61bb-4e52-aa8c-cdab52c905ac` |
| 类型 / 时间 | `weekly`，weekdays `[7]`，`22:00:00` Asia/Shanghai，`state: scheduled`，`deliveryMode: host` |
| 持久化 | `C:\Users\林先语\.dsh\storages\schedule.json`（unit `schedule` v1，约 2.8 KB，records 里带 `sessionId` + `record` + `status` + `deliveryHistory`） |
| prompt | 看板原 prompt + tag「含提炼与剪枝」的 promptPrefix 文案合并写入（zip 约 11 MB 属正常、需额外核对 distill/ 与 session-trash/） |
| 下次触发 | 2026-11-08 22:00 +08:00，与看板原 `nextRunAt` 一秒不差 |
| 旧看板卡 | `ead69e05-d364-4703-bce7-90dda8467e4e` → `schedule.enabled = false`，卡、prompt、3 次执行历史全部保留，可 `enabled=true` 回滚 |

验证用的临时 `after` 任务（60 秒后触发）到期后 `status` 由 `scheduled` 转 `inactive`、`deliveryHistory.records` 记 1 条，并真的以 followup 形式投进了会话 —— 证明「到点 → 恢复冷会话 → 追加 followup → 记回执」整链可用。该测试任务随后已删除。

## 4. 两种载体的机制差异（迁移后的真实代价）

| 维度 | 任务看板卡 | schedule 插件 |
|---|---|---|
| 错过后 | `skipMissed`，永不补 | 只补**最近一次** |
| 会话关系 | 独立，每次起新会话执行 | **绑定创建它的会话**（本次为 `session-e2ba3bc9-c4dc-4214-90e1-ddbbb77357a9`），该会话因「仍有活动提醒」无法归档，删任务后才能归档 |
| 宿主要活 | 需要 | 需要（到点靠恢复冷会话 + 投递 followup） |
| 配额 | 真消耗（起真实会话） | 极低（一条 user 消息） |

**必须只留一边**：两个载体同一时刻（周日 22:00）都会跑同一个 `publish-dsh.ps1`，会在 git 提交与 force push 上打架，所以迁移后立刻把看板卡的 `enabled` 置 false。

## 5. 后续待办

1. 2026-11-08 22:00 观察 schedule 是否真的投递并跑通备份；跑成之后再关看板插件才安全。
2. 与备份无关、可随时关省 token 的插件：`web-ui-task-board-github`（省约 1,800，未配仓库）、`code-index`（省约 1,543，code_* 7 个工具 0 次调用）；`web-ui-task-board` 全族约 5,231、`@deepseek-ai/dsh-experimental-schedule-bundle` 约 1,425 —— 迁移落地后看板可关、schedule 必须留。
3. 想彻底摆脱「宿主进程必须在跑」的约束，只能上 Windows 任务计划程序（`schtasks /sc weekly /d SUN /st 22:00` → `pwsh -File publish-dsh.ps1`），代价是脱离 DSH 的会话记录与执行历史回写。
4. 改 `cordis.patch.yml` 前先备份台账：`Copy-Item ~\.dsh\task-board\ledger-v2.json ...backup-20261107.json`（防插件重装后 schema 版本对不上）。

## 6. 源文件

- `dsh-migration/publish-dsh.ps1` — schedule 任务到点实际执行的发布脚本（`D:\dsh-migration\` 下另有 `publish-YYYYMMDD-2200.log` 与 `publish-state.json` 作为历史验收依据）
- 只读参考：`D:\DSH\dsh_data\DSH Desktop\resources\app\node_modules\@linxin666\dsh-client-ui-task-board`（`skipMissed` / `recoverSchedule` / `armSchedule`）、同目录 `@deepseek-ai\dsh-schedule`（README.zh.md 的已知限制、`lib/types/domain.js`）
- 台账：`C:\Users\林先语\.dsh\task-board\ledger-v2.json`
