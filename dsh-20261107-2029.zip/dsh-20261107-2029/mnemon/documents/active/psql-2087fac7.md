---
id: "2087fac7-b9b7-479d-8a8e-aaf48a198420"
title: "叠加分析补「重叠度图例 + 设施明细面板预览」+ 各度面积和与并集的显示自相矛盾修法（先 psql 验恒等式再改格式化）"
description: "叠加分析收尾三件事的落地记录：MapLegend 第三种 mode='degree'（档位由实际出现的 byDegree 生成、不写死）、三图例互斥的优先级判定、OverlayPanel 可折叠设施明细（默认收起，展开才拉 withItems:true，4KB↔26KB）、结果一换立即清空 overlayItems 的一致性原则、「各度相加 4.28 ≠ 并集 4.27」的定位过程（psql 证差 0 m² → 纯显示问题）与改法（比格式化后的字符串而非容差），以及 roadmap §2.4.14 F5 八/九节结构。关联 ba6de451、90fb3267。"
status: "active"
created_at: "2026-11-02T13:30:41.637Z"
updated_at: "2026-11-02T13:30:41.637Z"
content_hash: "9e62e5a4d57372cf821c62af6341924bd770eddc782ee5c1ef3bea1ffa817166"
source_paths:
  - "FE/src/components/MapLegend.vue"
  - "FE/src/components/OverlayPanel.vue"
  - "FE/src/stores/analysis.js"
  - "FE/src/App.vue"
  - "FE/docs/roadmap.md"
session_ids:
  - "1c15b350-aa27-42f1-a9be-9b16a97eb9d6"
memory_body_ids:
  []
---

# 叠加分析收尾：重叠度图例 + 明细预览 + 面积显示矛盾

前置：`ba6de451-a7df-45f6-a031-d8f4a2ca66d9`（overlay 平面细分实现，其「遗留」里写着
「图例仍是 POI 类别图例」「roadmap 尚未补这节」——本文正是收这两条）、
`90fb3267-5347-44a3-bf1b-002e53308b6a`（`withItems` 载荷门控与 CSV 明细，本文复用其载荷口径）。

## 1. 图例第三种模式：`mode="degree"`

`MapLegend.vue` 原有两套（`poi` 类别色点 / `heat` 数值色带），新增第三套：

```
poi     类别色点（学校蓝 / 医院红 / …）
heat    数值色带（热力图，含「无覆盖」虚线空心档）
degree  重叠度色阶（1 重 / 2 重 / 3 重 …）
```

**三种模式必须互斥、不能并排**。POI 图例是「类别→颜色」，重叠度图例是「层数→颜色」，
同时出现会让人以为「红 = 医院」和「红 = 三层重叠」是同一回事。App 里用一条 computed 仲裁：

```js
const legendMode = computed(() => {
  if (analysis.active && analysis.overlay) return 'degree'   // 叠加优先
  return store.visible.heat ? 'heat' : 'poi'
})
```

**档位不写死，从实际结果推**：

```js
const overlayDegrees = computed(() =>
  (analysis.overlayResult?.byDegree ?? []).map((d) => ({
    deg: d.deg,
    color: DEGREE_COLORS[Math.min(d.deg, DEGREE_COLORS.length) - 1],
  })),
)
```

理由：画 3 个面不一定产生三重重叠区（可能两两相交但无公共核）。凭空补满一档会让
图例列出地图上不存在的颜色。配色仍取自 `analysis.js` 导出的 `DEGREE_COLORS`，
和地图结果图层同源，不另立一套。无结果（不足 2 个面）时显示「叠满 2 个面后显示」，
而不是留一个空图例框。

## 2. 面板里的设施明细预览（默认收起）

`OverlayPanel.vue` 增加可折叠段：`设施明细 [展开 N 条]`，列表每行「彩色 deg 徽标 + 名称 + 类别」。

- 面板**主请求仍 `withItems:false`**（实测 ≈4 KB）；只有展开时才补一次 `withItems:true`（≈26 KB）。
- 收起再展开复用已拉到的数据，不重复打接口。
- 面板最多渲染 60 条（卡片列宽 288px，165 条没人会滚），其余走「导出 CSV」；
  末尾给「还有 N 条，导出 CSV 查看全部」。

**一致性铁律：结果一换，明细立刻作废。**

```js
setOverlayResult(result, ms) {
  this.overlayResult = result
  this.overlayError = null
  this.overlayMs = ms
  this.clearOverlayItems()   // ← 不清就会出现「列表还是旧的 165 条，统计已换成另一组面」
}
```

面增删（`addShape` / `removeShape` / `clearShapes`）同样经 `clearOverlayItems()`。
清空后若面板还处于展开态，显示「点击加载设施明细」——不假装手上有数据。
两块信息对不上比不显示更糟。

注：这与「拖半径滑杆时**不**清 `overlayResult`」是两种取舍，不要混为一谈
（见 `29c3b714-0c26-4c43-a9e9-8b6cd26a6a6b`：改半径仍是同一组面，可以留旧数字等 260 ms 去抖覆盖）。

## 3. 一个真 bug：「各度面积相加 4.28 ≠ 并集 4.27」

面板底部写着恒等式「重叠区互不重复，各度面积相加 4.28 km² = 并集」，而上方并集显示 4.27。

**先证明不是数据问题**，直接在 psql 里量，不猜：

```
 union_m2 | sum_atom_m2 | diff_m2 |   sum_shapes_m2   |        by_deg_m2
----------+-------------+---------+-------------------+--------------------------
  4353065 |     4353065 |       0 | 5052447.096781768 | 1:1826855 1:1826827 2:699382
```

差 **0 m²**，恒等式精确成立 → 纯显示问题：后端把「各度面积」和「并集面积」分别四舍五入到
3 位，前端再各自按 2 位显示，两次独立取整正好落在 4.27 / 4.28 两侧。

**改法：比格式化之后的字符串，不用数值容差。**

```js
const sText = fmtKm2(degreeSum.value)
const uText = fmtKm2(union.value.areaKm2)
return `${sText} ${sText === uText ? '=' : '≈'} 并集`
```

容差没用——容差算得再细也挡不住「两次独立四舍五入分别落在边界两侧」。
判定口径与展示口径必须同一个（都是 `fmtKm2` 的输出），这是通用教训。

## 4. roadmap 文档

`FE/docs/roadmap.md` 1759 → 2105 行：

- 新增 **§2.4.14 F5：叠加分析**（约 240 行）：① 三个定死的决策  ② 为什么不能两两求交
  （21 vs 15 的容斥数字）③ SQL 七步 + 三个写法坑（`PointOnSurface` / 面积门槛 / `::geography`）
  ④ 三个运行时坑（`full` 保留字 / `GeometryCollection` / withItems 载荷）⑤ 前端结构
  （两个 Source、`kind='shape'`、`activeShapeId`、六条 watcher）⑥ 实测基线（7 块维恩 + 三条恒等式）
  ⑦ 接口与坐标系四道关  ⑧ 图例与明细预览（本文新增两块）⑨ 还没做的
- §5 后端接口契约从「7 个接口」改为 **8 个**，加 `POST /api/poi/overlay`；新增 **§5.6** 完整响应结构。

## 5. 改动文件

| 文件 | 改动 |
|---|---|
| `FE/src/components/MapLegend.vue` | 新增 `mode='degree'` 分支、`items` 从 `degrees` 生成、标题「重叠度 / 越深覆盖越多」 |
| `FE/src/App.vue` | `legendMode` 优先级 computed、`overlayDegrees` 映射、给 `MapLegend` 传 `degrees` |
| `FE/src/components/OverlayPanel.vue` | 可折叠设施明细、展开时拉 `withItems:true`、最多 60 条、面积和/并集比较改字符串 |
| `FE/src/stores/analysis.js` | `overlayItems` / `overlayItemsTotal` 状态、`clearOverlayItems()`，在 `setOverlayResult` 与增删面路径调用 |
| `FE/docs/roadmap.md` | §2.4.14 F5 + §5.6 |

验证：`vite build` 通过（271 modules，约 320 ms）；dev server 编译产物里确认
`MapLegend` 收到的 `degrees` 绑定正是 `overlayDegrees`、`items` 确实读 `props.degrees`；
psql 恒等式实测差 0 m²。

**未肉眼验证**：浏览器桥不能在地图画布上作画，刷新后叠加状态被清空，无法重建「2 个面 + 结果」
的界面态——图例档位与明细列表只做了代码/编译层核对，需人工画两个面确认。

## 6. 遗留

- 组合明细表（「A∩B 是多少」）仍未做；后端 `members` 已返回，面数 ≤ 4 时可加。
- 明细列表未翻页，只截 60 条 + 导出兜底。
- 明细按全类别返回，不受面板类别勾选影响（与面板统计同口径；要按勾选过滤需改 SQL）。
