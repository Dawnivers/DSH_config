---
id: "de888790-a1ee-45f8-b4c5-b871629c6849"
title: "等时圈 SQL 性能定稿：poi 几何 GiST 索引、CTE MATERIALIZED 陷阱与缓冲调优（2026-11-04）"
description: "PoiMapper.xml 等时圈查询从 3.3 s/挂死到 2.5 s 的实测定位：poi 表缺 gist(geom) 导致 ST_Within 分钟级、同名索引被 scratch 表占用的改名绕法、PostgreSQL 12+ CTE 内联把缓冲流水线逐行重算（>120 s）与 MATERIALIZED 修法、geography buffer 的 simplify/quad_segs 调优对比；并给出 snap 口径的形心偏移实测与 status 档位收敛建议。"
status: "active"
created_at: "2026-11-04T07:16:52.397Z"
updated_at: "2026-11-04T07:16:52.397Z"
content_hash: "5c82d112ff3f33b4665433b319d9743d2cf2444eac5a199bb743b1f969e3edb0"
source_paths:
  - "serviceAnalysis/BE/src/main/resources/mapper/PoiMapper.xml"
  - "serviceAnalysis/BE/src/main/java/com/dawnivers/be/service/PoiService.java"
session_ids:
  - "a5600c46-8cbc-49ae-8096-a01d7efb3385"
memory_body_ids:
  []
---

# 等时圈 SQL 性能定稿（2026-11-04）

承接 `f78bfce5-cc32-4588-bb68-4d63fde36288`（单条 SQL 定稿/50 m 口径）、
`d074d50b-ac35-4549-b51a-61b20a18b9f5`（B1 吸附 SQL 与三层几何）、
`5ca9ab7a-f15a-4956-a70a-320314090a89`（pgr_* 契约与几何性能）。
本篇只记**本轮新增的性能病因与吸附口径实测**，不重述 SQL 全文。

## 0. 结论速览

| 问题 | 病因 | 修法 | 实测 |
|---|---|---|---|
| `?` 700 ms 看似尚可，campus 3,275 ms | `poi` 表无 `gist(geom)`，`ST_Within` 全表 16,016 行逐个做多边形内测试 | `CREATE INDEX idx_poi_geom_gist ON poi USING GIST (geom); ANALYZE poi;` | 建索引 611 ms / 648 kB |
| 拆简后的查询挂死 >120 s | PG12+ **CTE 内联**：`surf` 被逐行重算 | 给 `dd` / `skel` / `surf` 加 `MATERIALIZED` | >120 s → 2,489 ms |
| 缓冲段 2,996–3,052 ms 占大头 | `ST_Buffer(::geography, 50)` 默认 `quad_segs=8` | `ST_Simplify(0.00005)` 后 buff + `quad_segs=2` | 5,434 → 3,768 ms（−30%），面积差 1.4% |
| 想用 3857 投影缓冲替代 | 二次投影开销 | **放弃** | 15,196 ms，反而更慢 |

## 1. 索引：`gist(geom)` 缺失与命名冲突

现状（诊断）：

```
idx_poi_adcode     btree(adcode)
idx_poi_category   btree(category)
idx_poi_geog       gist((geom::geography))   ← 表达式索引，ST_Within(p.geom, ...) 用不上
poi_amap_id_key    btree(amap_id)
poi_pkey1          btree(gid)
```

- 表达式索引只匹配**完全相同的表达式**；查询写的是 `p.geom`，不是 `p.geom::geography`，优化器不会采用。
  与 roadmap §10.1 记的“`GIST(geom)` 用不上 `geom::geography`”是同一原理的反向案例。
- **踩到的坑**：`CREATE INDEX IF NOT EXISTS idx_poi_geom ...` 报“已存在”却不出现——索引名在 schema 内唯一，
  该名字已被 `poi_scratch_20261025` 占用（8192 bytes）。改名 `idx_poi_geom_gist` 后成功。
  诊断语句：查 `pg_indexes` join `pg_class` 看同名索引落在哪张表。

## 2. CTE 内联陷阱（比索引更致命的性能坑）

```
CTE 只被引用一次 → PG 内联成子查询
  → 执行计划把「整条 skel+buffer 流水线」当参数化子查询
  → 16,016 行 poi × 每行一次 Dijkstra+缓冲 ≈ 永远跑不完
```

- 原完整 SQL 侥幸没踩到：`surf.p` 被多处引用（面积/GeoJSON/POI/骨架），PG 见多处引用自动物化。
  **把 SQL 拆简单反而触发**——这是重构时最危险的一类回归。
- 修法：`surf AS MATERIALIZED (...)`，建议 `dd`、`skel`、`surf` 三个必加；
  `snap`/`used` 很小，加不加无所谓但加上更稳。

## 3. 缓冲调优对比（campus, 50 m, 面积基准 1.084 km²）

| 方案 | 耗时 | 面积 | 点数 |
|---|---|---|---|
| geography buffer 默认 | 5,458 ms | 1.084 | 999 |
| 3857 投影 buffer | 15,196 ms | 1.084 | 1004 |
| `quad_segs=2` | 5,882 ms | 1.070 | 569 |
| 先 simplify 后 buffer | 4,168 ms | 1.084 | 867 |
| **simplify + `quad_segs=2`（选此）** | **3,768 ms** | 1.069 | 421 |

要点：缓冲半径单位必须是地面米 → 必须 `::geography`（在 4326 上直接 buffer，50 会被当“度”）；
`ST_Simplify(g, 0.00005)` ≈ 5 m，面积只差 1.4% 但省 30% 时间，同时减小后续 `ST_Within` 的点数。

## 4. 最终分段耗时（索引 + MATERIALIZED 之后）

| 阶段 | 耗时 | 产出 |
|---|---|---|
| snap（KNN top5 再按米重排） | 21 ms | node_id / snap_m |
| dd（Dijkstra） | ~600 ms | 2,951 边 |
| collect + merge | ~2,000 ms | 7,060 → 5,370 点 |
| buffer（surf） | ~1,700–2,600 ms | 1.069 km² / 421 点 / ~6.6 KB |
| pois（点面判断，走新 GiST） | ~100 ms | 74 个（圆口径 83） |
| **合计** | **~2.5 s** | JSON 6,639 B |

交互补救方向：按 `(nodeId, budget)` 做结果缓存（Spring `@Cacheable` / Caffeine），
前端复用 `SqlHintBar` 的耗时栏做 loading 反馈。

## 5. 吸附口径：算法永远从节点起算

实测（同一 SQL，两种预算口径，东湖 154 m 吸附）：

| 口径 | 到达节点 | max_cost |
|---|---|---|
| 扣吸附（800−154=646） | 41 | 612.4 m |
| 不扣（800） | 50 | 779.9 m |

差 22%。**扣预算是把“从路口出发”改写成“从你点的位置出发”的唯一手段，且必须无条件扣**
（近：11 m 只差 1.4% 无感；远：154 m 差 22% 就是错的），不要为“远近”再拍阈值。

### 5.1 面不会“看着在点击点”——形心偏移是另一回事

| 点 | snap_m | 形心偏移 | 面到点击点最近距离 | 面积 |
|---|---|---|---|---|
| 武大 campus | 11 | 79.2 m | 0 m（点在面内） | 1.084 km² |
| 东湖 east-lake | 154 | 167.0 m | 93.2 m（点在面**外**） | 0.179 km² |

- 扣预算只改半径，**不改圆心**；面的生长中心始终是吸附节点。
- 形心偏移 ≠ snap_m：面沿街生长、有缺口，形状不对称会额外拉偏形心。两个数含义不同，都值得返回。
- 推论（写进 README 的一句话）：同一 800 m 预算，路网口径面积可从 0.18 km²（湖边）变到 1.08 km²（校园），
  相差 6 倍；直线圆恒为 2.01 km²。

### 5.2 status 档位收敛建议

四档（ok/far/too_far/no_network）被否：400 m 分界无依据，且无场景用到 `too_far`。
最终建议三档，且**只影响提示文案，不影响计算**：

```sql
CASE WHEN snap_m > budget THEN 'no_network'   -- 预算内摸不到路网
     WHEN snap_m > 100    THEN 'far'          -- 起点被挪动，需提示
     ELSE                      'ok' END
```

- 文案要改：不是“该点附近无路网”，而是**“最近的可步行路网在 1,901 m 外，超出 800 m 搜索范围”**。
- `snapM` 必须在 `no_network` 时也返回（即使 surface/skeleton 为 null），否则前端只会看到红圈、以为后端挂了。
- 可选增强：`snap` CTE 已含节点坐标，直接输出 `nearestNode {nodeId, lon, lat}`，前端画一条“到最近路网”的虚线。

### 5.3 边界实测（snap_m 与状态）

| 点位 | 最近节点 | 吸附距离 | 状态 |
|---|---|---|---|
| 武大校园 | 26086 | 11 m | ok |
| 东湖中心 | 116681 | 154 m | far |
| 长江中心 | 14667 | 116 m | far |
| 黄陂北部山区 | 170921 | 1,901 m | no_network |
| 武汉东北 60 km | 29081 | 57,094 m | no_network |
| 杭州（600 km 外） | 11559 | 438,827 m | no_network |

**每次都能找到最近节点**（哪怕 438 km 外），所以 `no_network` 从来不是“找不到路网”，
而是“最近路网在搜索预算之外”——加上 bbox 护栏前，`lon=0,lat=0` 也会安静返回武汉某节点。

## 6. 复现要点（脚本层面）

- `psql -c "\timing"` 与 SQL 混写会被解析坏（`extra argument ... ignored`），计时改用 stopwatch 包住 psql 调用。
- 分段计时把 SQL 拆成 7 段分别执行能定位瓶颈，但**拆分版务必加 MATERIALIZED**，否则你不是在测原查询。
- 在 Windows 终端给 psql 传中文标签会触发 `无效的 "UTF8" 编码字节顺序`，测试点用英文 tag。
