---
id: "4f35d84c-bb00-4f7c-8a7a-da737fcb6567"
title: "剪枝跨卷 EXDEV bug：rename 静默失败数周，改为复制→删源（2026-11-01 修复与首轮真搬实测）"
description: "2026-11-01 周备份发现 prune-sessions.mjs 用 fs.renameSync 跨卷搬会话必抛 EXDEV、而 publish-dsh.ps1 只警告便继续，导致剪枝自 10-28 起从未真搬；记录根因、moveTo 修复与降级语义（失败不中断、manifest 照写、exit 1 报警）、修复后 71 会话 59.78 MB 真搬与 0 异常校验，以及当轮推送的端到端哈希验收与两个遗留风险（仓库仍 public、PAT 无到期日）。"
status: "active"
created_at: "2026-11-01T14:10:32.155Z"
updated_at: "2026-11-01T14:10:32.155Z"
content_hash: "a600e997becbf7e653841c84d786016e8a26f16eb5825c204ec67b0ad1d81d8a"
source_paths:
  - "dsh-migration/prune-sessions.mjs"
  - "dsh-migration/publish-dsh.ps1"
session_ids:
  - "41663fa7-029c-4706-b718-66a13da3b581"
memory_body_ids:
  []
---

# 剪枝跨卷 EXDEV bug 与 2026-11-01 首轮真搬

承接三份既有文档：`b023afe4-1280-4350-ac26-b45bfed9813a`（prune-sessions.mjs 的四条剪枝判据与回收站设计）、`284e4a5f-9725-4a26-bd8c-7ad334658199`（publish-dsh.ps1 单提交 force push 链路）、`4f697022-3973-415e-83e6-61435101a435`（包体从 97.07 → 10.94 MiB 的瘦身）。本文只记**这一轮新发现并修掉的失败模式 + 修复后的首轮实测**，不重复上述内容。

## 1. 根因：跨卷 rename 必抛 EXDEV，且失败被吞掉

- 会话在 `C:\Users\<user>\.dsh\sessions\…`，回收站在 `D:\dsh-migration\session-trash\…`。
- 旧代码用 `fs.renameSync(p.dir, dstDir)` 搬会话目录和 projcache json。**Windows 上跨卷 rename 必然失败**：`EXDEV: cross-device link not permitted`。
- 更关键的是调用方语义：`publish-dsh.ps1` 里剪枝是「非致命步骤」——`if ($LASTEXITCODE -ne 0) { Write-Warn "剪枝失败（exit N），继续打包" }`。于是整条流水线每次都「成功」，日志里只有一行黄色警告。
- 实测后果：**从 2026-10-28 那轮起，剪枝只生成了空的日期目录，一个会话都没搬走**；打包/推送一直正常（会话本来就不进包），所以问题被完美掩盖。判断依据：`D:\dsh-migration\session-trash\20261101-2200\sessions` 下只有空目录、manifest 不存在。

教训：把「非致命步骤」和非零退出码配在一起时，必须在日志里留下可 grep 的**结果摘要**（搬了几个、跳过几个），否则连续数周的空跑无人发现。

## 2. 修复：`moveTo()` 降级为复制→删源

在 `prune-sessions.mjs` 中新增统一的搬移函数（约 L53 起，替换原来两处直接 `fs.renameSync`）：

- 先尝试 `fs.renameSync`（同卷最快、原子）；
- 捕获 `EXDEV` 后退化成 `fs.cpSync(src, dst, { recursive: true })` → `fs.rmSync(src, { recursive: true, force: true })`，并累计计数，结束时打印 `（其中 N 个跨卷，用 复制→删源 完成）`——这行是下次判断「降级路径是否真的走到」的抓手；
- **单个会话失败不再抛出中断整轮**：记入失败列表、继续下一个；`manifest.json` 照写（含成功项与每个会话的 sha256）；只要有失败就以 exit 1 收尾，让外层警告变成有意义的信号。

调用点两处都改为 `moveTo`：会话目录 `moveTo(p.dir, dstDir)`、projcache `moveTo(srcPc, …)`（projcache 同名 json 一并搬，避免残留死数据）。

## 3. 修复后首轮实测（2026-11-01 22:09）

| 指标 | 结果 |
|---|---|
| 搬移会话 | 71 个 + 71 个 projcache，共 59.78 MB |
| 跨卷降级 | 71 个全部走「复制→删源」 |
| manifest 校验 | moved=71 / failures=0 / items=71，逐项 sha256 复核 **0 异常** |
| 回收站目录数 | sessions 71、projcache 71 |
| C 盘 sessions | 136.31 MB / 339 文件 → **76.61 MB / 268 文件** |
| 跳过统计 | 摘要里没有 238、摘要还太新 27、摘要后又改过 3 |

回收站 `D:\dsh-migration\session-trash\20261101-2209`，30 天后才 `--purge`。上一轮失败残留的空目录已在真搬前清掉。

## 4. 同轮推送的端到端验收（可复用的验收套路）

不只看脚本自报 `pushed`，而是四路对齐：

1. `publish-state.json`：`result=pushed`、`pack=dsh-20261101-2200.zip`、`sizeMB=11.28`、`sha256`、`seconds=482.3`。
2. 本地 zip 实测大小与 `Get-FileHash` = state 里的 sha256。
3. 远端 HEAD commit message 与 force-push 日志中的 `old...new` 一致（`c47d06e`），`LATEST.json` 的 sha256 与本地一致。
4. **把远端 zip 下载回来重算哈希**，与本地字节级相同（11.28 MB / 同一 sha256）——这是唯一能证明「推送内容没被截断/替换」的证据。

远端保留策略照常：2 个 zip（本周 11.28 MB + 上周 11.04 MB）+ `LATEST.json` + `README.md`；旧包只从远端历史清理，本地 `D:\dsh-migration` 里的历史 zip 一个没删。
包内密钥自检：`home\` 下无 `.credentials.yaml` / `.env`，有 `SECRETS_WITHHELD.txt` 声明；zip 里 `token*` 命中全部是 bridge-browser 插件源码，非密钥。`distill/` 含 5 份摘要（含当周）。

## 5. 两个仍未解决的风险

- **仓库仍为 public**：`private=false`，103.83 MB。包内含 `~/.mnemon` 记忆、会话标题、项目绝对路径——等于一份对外可浏览的个人配置仓。脚本每次都警告但从未阻断；改私有只需改仓库可见性，脚本不变。
- **PAT 无到期时间**：fine-grained token 放在 `%USERPROFILE%\.dsh-config-publish\token`（2026-10-18 建立），API 不返回 `github-authentication-token-expiration` 头 ⇒ 不会收到失效提醒，被撤销后备份会以 401 静默失败。每周跑完应顺带看一次 `publish-state.json` 的 `result` 与卡片日志，而不是假定 cron 一定成功。

## 6. 下次的观察点

下一轮（11-08）是修复后第一次由 cron 触发，确认日志里出现 `（其中 N 个跨卷，用 复制→删源 完成）` 与回收站 manifest 的 `failures=0`；若 N=0 则说明 `D:\dsh-migration` 与 `~/.dsh` 已经同卷，可再简化。
