---
id: "f44684ab-1d9d-4247-808c-3e1b832c9132"
title: "F1 热力图配置层：FE/src/map/heatmap.js 单一真源（5 类别色带 + 图例推导）＋ 五个 SLD 透明档 XSD 修正与像素级验收"
description: "前端热力图配置模块的 API、设计取舍（阈值/色值各存一份、图例标签推导）、与 SLD 的机器交叉校验方法、透明档统一为「白 Fill + opacity 0 且无 Stroke」后的像素级验证结果，以及此时仓库已是 monorepo 的事实与 F1 剩余步骤清单。承接 SLD 相关文档 b0122682 / e54b31f6。"
status: "active"
created_at: "2026-11-01T10:44:23.449Z"
updated_at: "2026-11-01T10:44:23.449Z"
content_hash: "1122a77e86c1e082a0899aaba60c73c9608943841cfee8465a8c64519a3e3991"
source_paths:
  - "FE/src/map/heatmap.js"
  - "BE/styles/grid_total.sld"
  - "BE/styles/grid_school.sld"
  - "BE/styles/grid_hospital.sld"
  - "BE/styles/grid_mall.sld"
  - "BE/styles/grid_park.sld"
  - "FE/src/map/basemaps.js"
  - "FE/docs/roadmap.md"
  - ".gitignore"
session_ids:
  - "55626b0a-af9f-49b2-95f6-75211e516368"
memory_body_ids:
  []
---

# F1 热力图配置层（2026-11-01）

承接：格网分析口径 `7e3e84a2-3ab6-4682-9580-62fa711654a3`；
`grid_total` SLD 初版与三个渲染坑 `b0122682-e16e-45ff-b016-93a348f4ef9e`；
**透明档必须带 Symbolizer 的 XSD 更正** `e54b31f6-6154-42fc-b6e1-e4793913612f`（本文按其结论执行）。

## 1. 产物：`FE/src/map/heatmap.js`

约 150 行，纯配置 + 3 个派生工具，无副作用、无 import 依赖（可直接 `node` 跑）。定位与 `map/basemaps.js` 同级：**样式/色带这类"单一真源"单独成文件，不塞进 `map/wms.js`**（wms.js 管图层工厂，配置管数据）。

```js
HEAT_LAYER              // 'wuhan:grid_500m'
HEAT_DEFAULT_CATEGORY   // 'total'
HEAT_CATEGORIES         // 5 项：label / field / style / unit / thresholds / colors
heatCategory(key)       // 取配置，错 key 兜底回 total
heatStyleName(key)      // → 'wuhan:grid_school'（图层名:样式名）
heatLegend(key)         // → [{ label, color|null }]，直接喂图例组件
heatLegendSubtitle(key) // → '相对全市平均的倍数' / '800m 步行圈内个数'
```

### 设计取舍（关键，改动时别退化）

- **`thresholds` 与 `colors` 各存一份数组，图例文字由 `heatLegend()` 推导**，不手写标签。这样阈值一改，图例自动跟着变，永远不会出现"图例写 10–25、SLD 实际 3–10"的漂移。
- `unit: 'ratio'` 输出 `0.2–1 倍 / ≥25 倍`；`unit: 'count'` 输出 `0 个 / ≥4 个`。`grid_park` 必须用 `count`——公园仅 1,163 条，1 个就等于全市平均 3.67 倍，按倍数分档会让该区间整体空掉。
- 透明档在图例里用 `color: null` 表示，渲染成"(透明)"而非某个色块。

### 五类色带（逐字取自 SLD，已验证一致）

| 类别 | 样式名 | 字段 | 色带（自低到高） |
|---|---|---|---|
| total | `wuhan:grid_total` | `r_total` | `#fecc5c` `#fd8d3c` `#f03b20` `#bd0026` `#67000d`（YlOrRd 5 级） |
| school | `wuhan:grid_school` | `r_school` | `#c6dbef` `#6baed6` `#4292c6` `#2171b5` `#08306b`（Blues） |
| hospital | `wuhan:grid_hospital` | `r_hospital` | `#fcbba1` `#fb6a4a` `#ef3b2c` `#cb181d` `#67000d`（Reds） |
| mall | `wuhan:grid_mall` | `r_mall` | `#fee391` `#fec44f` `#fe9929` `#d95f0e` `#993404`（Oranges） |
| park | `wuhan:grid_park` | `park` | `#c7e9c0` `#74c476` `#31a354` `#006d2c`（Greens，**只有 4 档**） |

阈值统一 `[0.2, 1, 3, 10, 25]`（park 用个数 `[1, 2, 3, 4]`）。

## 2. 顺手抓到的真问题：四个分类 SLD 违反 XSD

写配置时用机器交叉校验，发现 `grid_total` 与另外四个不一致：

```
✗ total    SLD 色: #ffffff #ffffff #fecc5c ...   JS 色: #fecc5c ...
✓ school / hospital / mall / park
```

根因不是配色，而是**两种透明档写法混用**：`grid_total` 用"白 + `fill-opacity` 0"，另外四个用**空 Rule（无任何 Symbolizer）**。后者能渲染、REST 也能存，但过不了 SLD 1.0.0 的 XSD（`cvc-complex-type.2.4.b: Rule 内容不完整`），GeoServer 界面点「验证」会报错。

**修法（与 `e54b31f6` 的"写法 B"一致）**：每个 Rule 都给一个透明 `PolygonSymbolizer`，**不写 `<Stroke>`**。

```xml
<PolygonSymbolizer>
  <Fill>
    <CssParameter name="fill">#ffffff</CssParameter>
    <CssParameter name="fill-opacity">0</CssParameter>
  </Fill>
</PolygonSymbolizer>
```

五个文件统一成这一种写法，共补 10 个 Symbolizer。中途曾走反过方向（先按旧注释"不写 symbolizer 才透明"反而删掉了 Fill），是 SLD 内注释里那句 XSD 事实把方向纠回来的——**注释里的事实比"看起来像草稿的代码"更可信，改之前先读注释**。

同时删掉了已过时的注释文字（"Fill + opacity 0 缺一不可"那类），并改动 `_fix_sld_xsd.py` 这类一次性脚本后即清理，不留临时脚本在仓库。

## 3. 像素级验收（最硬的证据，可复现）

改完上传（5 个 `PUT` 全 200）后，取两个已知位置的格子中心 400 像素平均 alpha：

| 位置 | 应有 | 实测 |
|---|---|---|
| 西南角零覆盖格 | 全透明 | `alpha = 0`，非透明像素 `0/400` |
| 江汉路高密度格 | 半透明填充 | `alpha = 199`，非透明 `400/400` |

`199 ≈ 255 × 0.78`，正好是 `fill-opacity: 0.78`。**这个测试同时证明没有描边**：若还残留"`stroke-width=0` 被当发丝线"的情况，零覆盖格的边缘会出现 alpha>0 的像素，而实测 0/400。

最终交叉校验：五类「色 5/5 或 4/4、阈值全一致、所有 Rule 均含 Symbolizer」全绿。

**可复用做法**：色值/阈值这类"两处都得对"的常量，不靠肉眼对比——写个脚本把 SLD 解析出来与 JS 配置逐项比，只有透明档允许不参与色值比对（因它在图例里是 `null`）。改色流程 = 两边一起改 → 跑一次校验 → 跑一次像素抽查。

## 4. 当时的仓库状态（重要，别再按"三个独立仓"操作）

项目已在当日 17:44 变成 **monorepo**：`FE/`、`BE/`、`etl/` 下的 `.git` 全部消失，根目录 `.git` 成为唯一仓库，用 `git subtree` 合并，35 个提交历史保留。

- 根 remote：`https://github.com/Dawnivers/ServiceAvailable.git`（另有 `ServiceAvailable-etl` 曾单独推送过，最终并入 monorepo）
- 根 `.gitignore` 只挡根层杂项：`.dsh-code-index/`、`mock/`（早期设计稿与调试截图）、`data/`（`wuhan.json` 等零散数据，待整理）；子目录各带自己的 `.gitignore`。
- 症状：在 `FE/` 里跑 `git status` 会看到 `../BE/styles/...` 这种越界路径——**这是正常现象**（toplevel 已是根目录），不是仓库错乱。

当次待提交 6 项：5 个 `BE/styles/grid_*.sld`（M）+ `FE/src/map/heatmap.js`（新文件）。

## 5. 交接：F1 剩余的 6 个文件（用户自己写，评审把关）

| 步 | 文件 | 干什么 | 验收 |
|---|---|---|---|
| 2 | `map/wms.js` | 加 `createHeatLayer()`，先写死 `grid_total` | 地图上出现热力图 |
| 3 | `view/mapView.vue` | 建图层挂进 layers | 能看到、能调透明度 |
| 4 | `map/layers.js` | 注册表加 `heat` 行 | 图层控制里出现勾选 |
| 5 | `stores/layers.js` + `mapView.vue` | 加 `heatCategory` + `updateParams` | 点「学校」1 秒变蓝 |
| 6 | `components/MapLegend.vue` | 加 `mode` prop 渲染色带 | 图例颜色与地图一致 |

第 5 步只需换 style 名（`wuhan:grid_school`），**不必重建图层**——`heatmap.js` 的 `heatStyleName()` 就是为此准备的。
