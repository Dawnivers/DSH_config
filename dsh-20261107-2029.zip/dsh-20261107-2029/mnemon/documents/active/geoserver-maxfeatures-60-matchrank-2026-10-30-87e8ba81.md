---
id: "87e8ba81-0476-4de4-92b0-ae39e4020647"
title: "搜索相关性修正：GeoServer 只按字段排序，精确匹配会被 maxFeatures 截掉（候选池 60 + 前端 matchRank，2026-10-30）"
description: "D12 搜索的后续修正：用户搜「武汉大学」看不到本体，根因是 GeoServer 不支持相关度排序（sortBy=name A 是字典序），精确匹配排到第 10 位被 maxFeatures 截断；对策是 CANDIDATE_LIMIT=60 多取候选 + 前端 matchRank（完全相同/前缀/包含分级，同级按名字长度）+ PROPERTYNAME 裁剪（4870B→943B）把体积压回原量级，附实测与剩余限制（常见词候选池、拼音、CQL LIKE 大小写敏感）。"
status: "active"
created_at: "2026-10-30T15:23:00.197Z"
updated_at: "2026-10-30T15:23:00.197Z"
content_hash: "dae8b8e5d60f13154a452d077673ad32e214f571fa8c76c614b7e3785e5a385f"
source_paths:
  - "FE/src/map/searchPoi.js"
  - "FE/src/components/SearchBox.vue"
  - "FE/src/App.vue"
  - "FE/src/components/TopBar.vue"
session_ids:
  - "a2828077-be2c-4956-882d-f0afe1f2b01e"
memory_body_ids:
  []
---

# 搜索相关性修正：精确匹配为什么「搜不到」

承接 D12 搜索实现 `7c6fa1da-6ad8-429d-b649-1584e973371f` 与 WFS 瘦身/分工 `e5776c47-3da0-4fd0-bdd1-b2015966d6cb`。**本文更正那篇里的一处策略**：`maxFeatures=8` + `sortBy='name A'` 会让精确匹配掉出窗口。

## 1. 症状：搜「武汉大学」列表里没有「武汉大学」

不是没命中。库里 `name = '武汉大学'` 确实存在（1 条，`category=school`），名称模糊命中总数 278。问题在**排序后的位置**：

```
sortBy=name A（字典序，数字 < 中文，拼音 guo/hu/jiao/kuang/luo < wu）
 1. 7-ELEVEn(武汉大学店)        ← 数字开头排最前
 2. Today今天便利店(武汉大学店)
 3. 国立武汉大学农学院
 ...
10. 武汉大学                     ← 用户要找的，正好被切掉
```

`maxFeatures=8`，第 10 位就是不可见。

## 2. 根因：GeoServer 不算相关度

WFS 的 `sortBy` 只能按**字段值**排序，没有「相关度」概念。对搜索而言，`name A` 的字典序**没有意义**——它只适合让候选集顺序稳定。任何「取前 N 条」的搜索都必须自己保证 N 条里包含本体。

## 3. 修复：多取候选 → 前端重排 → 再截断

`FE/src/map/searchPoi.js`：

```
① 取 CANDIDATE_LIMIT = 60 条（不是直接取 8）
② 前端 matchRank(name, kw) 分级：
     0 = 完全相同   （武汉大学）
     1 = 前缀命中   （武汉大学党办 / 武汉大学财务部）
     2 = 包含命中   （7-ELEVEn(武汉大学店) / 国立武汉大学农学院）
   同级按名字长度升序（短的更可能是本体）
③ 截前 MAX_FEATURES = 8 条给下拉列表
```

体积用 `PROPERTYNAME` 补回来：

| | 2 条 | 单条 |
|---|---|---|
| 不裁剪 | 4870 B | ~2.4 KB（带 `raw` 高德原始 JSON） |
| `PROPERTYNAME=name,address,category,lon,lat` | **943 B** | **~470 B** |

60 条约 28 KB，与原来 8 条（~19 KB）同量级。注意参数名大小写都生效（`PROPERTYNAME` / `propertyName` 等价）。

## 4. 修复后实测

```
武汉大学     → 武汉大学 / 武汉大学党办 / 武汉大学财务部 / 武汉大学当代楼
解放公园     → 解放公园 / 解放公园-兰园 / 解放公园-游划 / 解放公园鸽子广场
华中科技大学 → 华中科技大学 / 华中科技大学东校区 / 华中科技大学法学院
公园         → 白玉公园 / 宝岛公园 / 朝露公园 / 船厂公园
黄鹤楼       → 黄鹤楼公园商店 / 小黄鹤楼口袋公园 / …（库里没有名字正好是「黄鹤楼」的 POI，ETL 只采 school/hospital/mall/park 四类 —— 数据覆盖问题，不是排序问题）
```

前三条全部精确匹配排第一。

## 5. 仍然存在的限制与下一步

| 限制 | 说明 | 可选解法 |
|---|---|---|
| 常见词仍可能找不到本体 | 命中数千条时（如「店」），60 条候选里可能全是泛匹配 | 三段式查询：`name = kw` → `name LIKE kw%` → `name LIKE %kw%`，各取一次；代价约 300ms / 3 请求 |
| 无拼音/首字母 | `whdx` 搜不到「武汉大学」 | 需 PG 加 `name_pinyin` / `name_initials` + `pg_trgm`，属后端+ETL |
| 大小写敏感 | CQL 的 `LIKE` 非 `ILIKE`，`wuhan` 搜不到 `Wuhan` | `strToLowerCase(name) LIKE strToLowerCase('%wuhan%')` |
| `category` 未参与匹配 | 搜「学校」不会列出全部 `school` | 需中文→类目映射后再拼 `category = 'school'` |

## 6. 匹配与排序是两件事（读代码时最容易混）

```
匹配（GeoServer/SQL 层）  name LIKE '%kw%'  → 278 条，取回 60 条
排序（前端）              matchRank 分级 + 长度升序 → 截 8 条
地址兜底（SQL 层）        address LIKE '%kw%' AND name NOT LIKE '%kw%'（名称不足 8 条时补齐，避免重复）
```

`AND name NOT LIKE '%kw%'` 是为了不与第一轮结果重复；`maxFeatures=0` 会被当成「不限」，只想取计数时给 1。
