---
id: "ba6de451-a7df-45f6-a031-d8f4a2ca66d9"
title: "叠加分析（overlay）实施记录：PostGIS 平面细分求「按重叠度」原子面 + 两个真 bug（FULL 保留字、ST_MakeValid 返回 GeometryCollection）"
description: "2–6 个面/圆叠加分析的完整落地记录：平面细分四步 SQL（noded→faces→tagged→atom）与 byDegree 统计、并集/交集/单面三组指标、POST+JSON 契约与校验、前端累积绘制模式与结果图层接线、两个只有真跑才炸的 SQL bug 及修法、实测维恩 7 块与面积恒等式、6 条设计决定理由、遗留 TODO。"
status: "active"
created_at: "2026-11-02T08:34:38.772Z"
updated_at: "2026-11-02T08:34:38.772Z"
content_hash: "43d6d2e04a87b82dd5f56e8da7ec339f75afa4b31dcf5f049932a9c13590542f"
source_paths:
  - "BE/src/main/java/com/dawnivers/be/dto/OverlayReq.java"
  - "BE/src/main/java/com/dawnivers/be/controller/PoiController.java"
  - "BE/src/main/java/com/dawnivers/be/service/PoiService.java"
  - "BE/src/main/java/com/dawnivers/be/mapper/PoiMapper.java"
  - "BE/src/main/resources/mapper/PoiMapper.xml"
  - "FE/src/components/OverlayPanel.vue"
  - "FE/src/stores/analysis.js"
  - "FE/src/map/drawing.js"
  - "FE/src/composables/useBufferAnalysis.js"
  - "FE/src/components/AnalysisToolbar.vue"
  - "FE/src/view/mapView.vue"
  - "FE/src/App.vue"
session_ids:
  - "d953b35a-2f21-4657-a75e-5613bd461894"
memory_body_ids:
  []
---

# 叠加分析（overlay）实施记录

目标：用户在分析模式里连续画 **2–6 个面**（框选 / 自由绘制 / 点选缓冲圈），右侧面板给出
**并集 / 交集 / 按重叠度（1 重、2 重、3 重…）** 三组面积与 POI 计数，并在图上按重叠度着色。

核心诉求是用户原话里的那句：**「画多个面」不能和「用哪种工具画」耦合**——开着叠加时换工具
（框选 ↔ 自由绘制 ↔ 点选）**不能清掉已画的图形**。旧行为是 `setTool` 一律 `clear()`。

## 1. 后端：一套 SQL 平面细分（不是反复 `ST_Intersection`）

`PoiMapper.xml` 里 `overlay` 单条语句完成全部计算，CTE 五段：

```
src     入参 JSON 数组 → 每个面一行
        circle 走 ST_Buffer(ST_SetSRID(ST_MakePoint(lon,lat),4326)::geography, radius)
        area   走 ST_GeomFromText(wkt, 4326)
valid   归一化：ST_IsValid 先判、非法才修
cfg     n = 面数
noded   ST_Node(ST_Collect(ST_Boundary(geom)))          -- 边界 → 打节点
faces   ST_Dump(ST_Polygonize(g))                        -- 面化
tagged  ARRAY(SELECT v.id ... WHERE ST_Contains(v.geom, ST_PointOnSurface(f.g)))
atom    只留 members 非空 且 ST_Area(g::geography) > 1 ㎡
```

后续四个输出块都从 `atom` 派生：

| 字段 | 算法 |
|---|---|
| `union` | `ST_Union(atom.g)` 的面积 + POI 计数 + `byCategory` |
| `intersect` | `deg = n` 的原子面合并（全部 N 个面共同覆盖），可为空 |
| `byDegree` | `GROUP BY deg`：`faceCnt / areaKm2 / poi`（真正的输出） |
| `shapes` | 每个原始面各自的面积与 POI（面板列表） |
| `geometry` | FeatureCollection，`properties = {deg, members}`，`ST_SimplifyPreserveTopology(g, 0.00001)`（≈1.1 m，低于任何缩放级的视觉分辨率，只减体积不变形状） |

关键点：**用「包含严格内部点」判定归属**（`ST_PointOnSurface` + `ST_Contains`），而不是
`ST_Intersects`/`ST_Within`。相邻原子面共享边界，用边界判定会抖动/重复归属。

这条恒等式就是功能正确性的判据，面板底部直接显示：
`Σ byDegree.areaKm2 == union.areaKm2`。成立即证明重叠区**没有被重复计数**。

## 2. 两个只有真跑 SQL 才会炸的 bug

### ① `full` 是 SQL 保留字

第一版把并集 CTE 命名为 `full`：`full AS (SELECT ST_Union(g) ...)` →
`错误: 语法错误 在 "full" 或附近的`（`FULL JOIN` 的保留字）。改名 `common`。
编译期、类型检查和前端构建都发现不了，**必须真连库跑一次**。

### ② `ST_MakeValid` 返回 `GeometryCollection` → `ST_Node` 报错 → HTTP 500

用户画一个自相交的「8」字（领结面）：

```
ST_MakeValid(bowtie)            → MultiPolygon / GeometryCollection
ST_Collect(LineString, MultiLineString)  → GeometryCollection   ← ST_Collect 不合并类型
ST_Node(GeometryCollection)     → lwgeom_collect_endpoints: invalid type GeometryCollection
```

实测确认（psql）：`plain_polygon → ST_Polygon`，`bowtie → ST_MultiPolygon`，
`ST_CollectionExtract(...,3) → ST_MultiPolygon`，退化面 → 空几何 `t`。

两处修法：

```sql
-- ① 修完只留面
CASE WHEN ST_IsValid(g) THEN g
     ELSE ST_CollectionExtract(ST_MakeValid(g), 3) END
-- ② 收边界时压平成 MultiLineString（ST_Node 不接受 GeometryCollection）
ST_Node(ST_CollectionExtract(ST_Collect(ST_Boundary(geom)), 2))
```

可迁移结论：**`ST_Collect` 不会统一几何类型**；只要有一个面被拆成多块，
下游所有期待单一类型的函数（`ST_Node`、`ST_Polygonize`）都会在运行时炸。
修 `MakeValid` 的输出后一律 `ST_CollectionExtract` 收口。

## 3. 接口契约与校验

`POST /api/poi/overlay`，请求体 `OverlayReq`：`shapes[2..6]`，每个元素是
`area`（`wkt`）或 `circle`（`lon`/`lat`/`radius`）。`PoiService` 校验面数、`kind` 枚举、
经纬度范围、半径区间后把 JSON 原样透传给 Mapper。

实测的四类拒绝：

| 用例 | 响应 |
|---|---|
| 1 个面 | 400 `at least 2 shapes are required` |
| `kind:'polygon'` | 400 `shapes[1].kind must be 'area' or 'circle', got 'polygon'` |
| 7 个面 | 400 `at most 6 shapes are allowed, got 7` |
| 两圆不相交 | 200，`intersect.empty=true`，`byDegree` 只有 1 重 |

## 4. 实测数据（8095 临时实例，未动 8094 上的旧进程）

**3 个圆两两相交**：并集 3.728、交集 0.615；
`byDegree` = 1 重 2.08 / 2 重 1.03 / 3 重 0.61；**原子面 7 个 = 2³−1**，
`members` 依次为 `s1 | s2 | s3 | s1+s3 | s1+s2 | s2+s3 | s1+s2+s3`——维恩图 7 块全齐，
面积相加精确等于并集。

**原始 3 面用例**：`shapeCount=3`，union 4.087 km² / 165 POI，
`byCategory` school=37 hospital=68 mall=54 park=6，intersect 0.968 / 54。

**领结面回归**：修后 `ok=true`，union 3.034，`s2 area 2.13 km² / 100 POI`，Σ=3.034 与并集一致。
（修复前这一例是 HTTP 500。）

## 5. 前端改动与三条设计决定

新增 `OverlayPanel.vue`（右侧面板：面列表 + 并集 + 交集 + 按重叠度）；
`analysis.js` 增加 `overlay / shapes / shapeSelected` 状态与 action；
`drawing.js` 增加**累积模式**与结果图层；`useBufferAnalysis.js` 增加第三条取数分支（POST）；
`AnalysisToolbar.vue` 增加叠加开关与面数提示；`mapView.vue` / `App.vue` 接线 + 4 个 watcher。

| 决定 | 理由 |
|---|---|
| 叠加是**开关**，不是第 5 个工具 | 「画多个」与「用哪种方式画」是两个正交维度，塞进工具组会互相打架 |
| 圆传 `lon/lat/radius` 而非 WKT | 后端 `ST_Buffer(::geography, r)` 得**地面正圆**，与 `nearby` 的 `ST_DWithin` 同口径；前端那个圆只是 3857 投影近似 |
| `POST + JSON` 而非 GET | 6 个面 × 几百顶点会撞 Tomcat 8 KB 请求行；WKT 里的 `+` 在 query string 会被解成空格 |
| 叠加的面用 `kind:'shape'` | 复用 `'circle'`/`'polygon'` 会被 `paintCircle`/`removeByKind` 当单图形清掉 |
| 叠加模式下类别勾选置灰 | 结果按重叠度分，四类别只出合计；留着可点就是假开关 |
| 删中间一个面后**重排字母/配色** | 否则面板出现「区域 A、区域 C」，用户以为 B 丢了 |
| 配色只在 `analysis.js` 定义一份 | `drawing.js` 直接 import 常量按重叠度改透明度，地图与面板不会走散 |

注意：叠加结果图层与普通分析结果图层是两套（`kind:'shape'` 自成一路），
`removeByKind` 的品类清空逻辑不能波及它们。

## 6. 验证方式（可复用）

用 `.chk` 目录做前端构建产物检查、`psql -f` 直接跑 SQL、另起 8095 临时 Spring Boot 实例做
接口冒烟，**全程不碰 8094 上正在服务的旧进程**；测完 kill 并确认 `8095 listening: False`。
前后端契约用 curl 跑 7 个用例（1 面 / 错 kind / 领结 / 7 面 / 不相交 / 三重重叠 / 原用例回归）。

## 7. 遗留（等用户看效果后定）

- 叠加结果**导出 CSV**（现在导出按钮只在普通分析面板上）
- **组合明细表**（「A∩B 是多少」）：后端 `members` 已返回，面数 ≤ 4 时可加列表
- 地图左下角**图例**仍是 POI 类别图例，重叠度配色只出现在面板里
- roadmap 文档尚未补这节的算法说明与坑

## 相关文档

- `564a4172-29af-4a5a-a5a8-87b0a8821d51`：3857 缓冲圈偏小 14% + 面-面叠加必须 `ST_Intersection` 而非 `ST_Union`（本文的计量口径前置）
- `31981a03-2218-473a-8c8d-e7cf6d256d6f`：D13 分析模式交互（`setTool` 清空、OL `Draw` 双击、`abortDrawing`）——本文「换工具不清图形」正是对它的改写
