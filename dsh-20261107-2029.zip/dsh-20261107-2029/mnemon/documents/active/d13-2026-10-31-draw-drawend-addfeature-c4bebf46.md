---
id: "c4bebf46-a1f6-4e75-86bc-00c43548edb2"
title: "D13 绘制工具交互改版（2026-10-31 晚）：点击式语义取代拖拽式、缓冲圈看不见的真因是像素尺寸、Draw drawend 与 addFeature 的时序坑"
description: "按用户要求把自由绘制/框选从\"按住拖\"改成\"逐点点击 + 鼠标移动实时预览\"，并记录由此暴露的三条根因：①非手绘模式拖拽必放手（点击式与拖拽式在 OL 里互斥，二选一）②800m 缓冲圈在 zoom 9 只有 2.6 像素——不是样式问题，改为自动拉镜头到 14 级 ③Draw 先 dispatch drawend 再 addFeature，导致 drawend 里清理清不掉、圆心重复，改 setTimeout 推迟一拍。含 CDP 双击事件派发陷阱与实测数据。纠正 af40cfc5 中已过时的拖拽语义描述。"
status: "active"
created_at: "2026-10-31T08:50:46.128Z"
updated_at: "2026-10-31T08:50:46.128Z"
content_hash: "330d09e609eec95740ea75ae66ddb7d6c389fff40248f0d7d58105c855df5d99"
source_paths:
  - "FE/src/map/drawing.js"
  - "FE/src/view/mapView.vue"
  - "FE/docs/roadmap.md"
  - "FE/src/stores/analysis.js"
session_ids:
  - "5837eed5-44a8-46d8-ba14-30b08407cc7d"
memory_body_ids:
  []
---

# D13 绘制工具交互改版（2026-10-31 晚）

**这篇纠正 `af40cfc5-8af4-4ba1-ac1f-ea2990af3a42`。** 该文的源码根因分析（非手绘模式一拖动就放手）仍然正确且更有价值，但它据此得出的**解法与交互语义已作废**：当时把自由绘制和框选都改成 `freehand: true` 让用户"按住拖"，用户明确否掉了这个手感，要求改回点击式。阅读时以本文的工具表为准。

## 1. 用户要的交互与最终实现的对照

| 工具 | 用户要求的交互 | 实现 | 实测产出 |
|---|---|---|---|
| 点选 `point` | 单击选中心 | 单击 + 自动拉镜头到 14 级 + 红虚线缓冲圈 | `center {lon:114.36866, lat:30.63157}`，要素 `[circle r=800, center]` |
| 自由绘制 `freehand` | **点击新增折点、双击完成并封闭** | `type: 'Polygon'`，去掉 `freehand` | 4 次单击 + 双击 → `POLYGON, 1.69 km²` |
| 框选 `rect` | **点击定角、移动鼠标实时改长宽、再点击完成** | `type: 'Circle' + createBox()`（非手绘） | 单击(600,350) → 悬停 → 单击(800,470) → `POLYGON, 1.62 km²` |
| 测距 `measure` | 连点、双击结束 | `type: 'LineString'`，双击收尾 | 连点 + 双击 → `1836 m` |

框选面积的交叉验算（可用于快速判断是否画偏）：200×120 px 在 zoom 14（分辨率约 9.5 m/px）≈ 1910×1146 m，3857 投影按纬度 30.6 折算 ×0.861 → 1.65×0.99 km ≈ **1.62 km²**，与实测吻合。

## 2. ★ 点击式与拖拽式在 OL Draw 里互斥，只能二选一

根因仍是 `ol/interaction/Draw.js` 的 `handlePointerMove_`：

```js
this.shouldHandle_ = this.freehand_
  ? squaredDistance > this.squaredClickTolerance_    // 手绘：移动就接管
  : squaredDistance <= this.squaredClickTolerance_;  // 非手绘：移动超容差就主动放手
```

推论（这次是反着用）：

- `freehand: true` → 拖拽能画，但**代价是必须按住**，无法做"点击加点 → 移动预览 → 再点击"。
- `freehand: false`（默认） → 支持多次单击成图，但**按住拖会被判定为拖地图**，事件落到 `DragPan`。

所以用户的诉求（点击式框选）与上一版实现（拖拽式框选）在机制层面不可共存，不是参数调优问题。**用户否决的是交互范式，不是实现细节**——再遇到"手感不对"的反馈，先判断用户要的是哪一类接管方式，再去调 `geometryFunction` 或样式都是白费。

同理，`createBox()` 在这里是**正确的**：它是"两次单击定对角＋中间鼠标移动实时预览"的官方写法，正是用户想要的效果；上一版判定它不可用，是因为当时在测拖拽。

## 3. ★ 缓冲圈"看不见"是像素尺寸问题，不是样式问题

用户反馈"点选后无法看见圆"。实测换算：

```
zoom  9 → 约 305 m/px → 800 m 半径 ≈  2.6 px   ← 画出来就是几个红点
zoom 14 → 约 9.5  m/px → 800 m 半径 ≈ 84   px   ← 一眼看清范围
```

几何、样式、坐标系全部正常，纯粹是不可分辨。修法在 `mapView.vue`：`BUFFER_ZOOM = 14`，`watch(analysis.center)` 里点选后自动把镜头拉到 14 级，**且只在当前 zoom 比 14 更远时才动镜头**（用户已放大到 16 就不该被拉回来）。

可迁移的判断：**地图上的绝对尺寸要素（缓冲圈、比例尺符号、点符号）在低缩放级别不可见，几乎永远是"物理像素"问题而非渲染问题**。先算 `半径 / 该级分辨率`，再决定是改样式还是改视野。

## 4. ★ Draw 的 `drawend` 早于 `addFeature`，导致圆心重复

现象：点选后要素列表里出现两个 `center` 点（`[circle, center, center]`）。

根因：`Draw.finishDrawing()` 里**先 `dispatchEvent('drawend')`，之后才 `addFeature`**。所以在 `drawend` 回调里立刻清理 source，清的是"上一个"要素，本拍刚画的那个点还没进 source，清不掉，于是叠出一个。

解法：`setTimeout(paintCircle, 0)` 把清理+重绘推到下一拍，等 OL 把要素加进 source 再动手。修复后实测 `要素: [circle r=800, center]`。

推广：**在 `drawend` 里操作 source 都属于"抢在 OL 之前"**，凡需要看到本次新要素的收尾动作都应推迟一拍。

## 5. CDP 派发双击的陷阱（一次"功能失败"的误判）

测距第一版"失败"，查出来是**测试写法错**：真实双击必须是**两对 down/up，第二对的 `clickCount: 2`**。只发一对 `clickCount: 2` 浏览器不会产生 `dblclick`，`Draw` 自然收不了尾。改对后 1836 m 正常。

排错脚本一律用 `FE/_test-*.mjs` / `FE/_diag-*.mjs` 临时文件，跑完删净，并确认 `mapView.vue` 无 `__dbg` / `window.__dbg` 残留。

## 6. 构建与文件

`vite build` 254 modules、497 KB、退出码 0。

| 文件 | 改了什么 |
|---|---|
| `FE/src/map/drawing.js` | `freehand` 去掉 `freehand: true` 与自定义 `createBoxFromDrag`；`rect` 用回 `createBox()`；点选 `drawend` 延后一拍清理；删掉无用的 `boundingExtent` / `Polygon` 引用 |
| `FE/src/view/mapView.vue` | 新增 `BUFFER_ZOOM = 14` 与 `watch(analysis.center)` 自动拉镜头；分析模式下 `singleclick` 直接 return（不打开 POI 详情） |
| `FE/docs/roadmap.md` | §2.4.0 改写为点击式语义，补"圆心重复"坑与像素尺寸结论 |

`drawing.js` 的对外形态未变，仍是 5 方法纯回调（`setTool / setRadius / setCenter / getPolygon / destroy`），不 import store。

## 7. 下一步（未变）

绘制能出几何但**画完没有任何数据反馈**：地图上有红框，右侧没有结果卡。

- Step A `useBufferAnalysis.js`：画完/半径变化 → 自动调 `/nearby` 或 `/within` → 写 `stores/analysis.js`
- Step B `AnalysisResult.vue`：覆盖数、分类占比条、最近设施、导出

建议先 B：用已有 `within` 真实数据把卡片架子搭出来，接数据只差一次 fetch。

## 相关文档

- `af40cfc5-8af4-4ba1-ac1f-ea2990af3a42` —— 拖拽版实现与 OL 源码根因、CDP probe 排错套路、within 端到端校验（交互表已过时）
- `81c93b00-c684-4f65-a859-87e533a10776` —— 四工具对齐后端口径（圆 → nearby，任意多边形/矩形 → within）、className 构造参数需强刷
- `c8394c90-f05c-4973-bb3e-be44d6f1e3bf` —— 双入口接线、地图灰化的 className 做法
