---
id: "633dbb79-9211-4c7a-aadf-3615c2361d2a"
title: "POI 详情卡统计块接入 /api/poi/nearby（800m 内设施 / 同类最近，含三个坑与实测）"
description: "FE 侧把 /api/poi/{gid} 与 /api/poi/nearby 串起来的落地记录：字段映射表、count 含自身 / nearest[0] 距离 0 / limit 默认 5 三个坑的解法、summarizeNearby 纯函数与 store/卡片/App 三处改动、真实接口与边界实测结果、仍待用户决定的两项。"
status: "active"
created_at: "2026-10-31T02:43:55.916Z"
updated_at: "2026-10-31T02:43:55.916Z"
content_hash: "d7e981349b93dbb2d0508a6778777d05b952bddf056ba1a4cda9f10089b970f0"
source_paths:
  - "FE/src/stores/selection.js"
  - "FE/src/components/PoiDetailCard.vue"
  - "FE/src/App.vue"
  - "BE/src/main/java/com/dawnivers/be/dto/NearbyDto.java"
session_ids:
  - "95c1cf3d-7287-4407-a31c-63da43a75860"
memory_body_ids:
  []
---

# POI 详情卡统计块接入 nearby（D13 前置）

承接 PoI 详情卡实现文档 `11d91f88-c85e-4e1a-a606-8c05580fba27`（其中统计块三格当时是 `null` 占位，注释写着"来自 /api/poi/nearby 的 count / byCategory，需要圆心"）、nearby 的 SQL/契约勘察 `d7826a4a-c9bb-4fbe-bccc-7cacfd399421`、以及总设计 `266aea70-7a25-4d94-8359-39555b8b651f`。

用户诉求：**「同类最近」渲染成带单位 m，且「800m 内设施」排除自身**；纯调接口的机械活由助手直接实现，不再逐问。

## 1. 三格与后端字段的真实映射

| 卡片字段 | 后端有无 | 取值 | 实测（武汉成丰学校 114.268971/30.489197） |
|---|---|---|---|
| 800m 内设施 | ✅ | `count`（= Σ`byCategory`）再 `-1` 排自身 | 28 → **27** |
| 同类最近 | ✅ | `nearest` 中第一条 `category === poi.category` 且 `distanceM > 0` 的 `distanceM` | **191 m**（武汉鸿蒙幼儿园） |
| 可达性指数 | ❌ | 后端无任何对应字段 | 仍是 `—` |

`NearbyDto`（BE）：`count(Long)`、`center{lon,lat}`、`radiusM(Double)`、`byCategory(Map<String,Long>)`、`nearest(List<NearestDto>)`。注意序列化名是 `radiusM` 而非 `radius_m`。参数校验：`radius` ∈ (0,5000]，`limit` ∈ (0,50]，越界 400。

## 2. 三个必须处理的坑（均为实测，非理论）

1. **`count` 包含 POI 自身**：圆心即该 POI，`ST_DWithin` 必然把自身计入。前端做 `Math.max(0, count - 1)`。
2. **`nearest[0]` 就是它自己且 `distanceM = 0`**：取"同类最近"必须排除自身，判据用 `distanceM > 0`，**不要比 name**（重名 POI 真实存在）。
3. **`limit` 默认只有 5**：`nearest` 按距离排、不分类，医院扎堆处可能全为 hospital 而同类缺失 → 误显示 `—`。故 `limit` 传 50（后端上限），再前端 filter；若仍取不到等同类的，返回 `null` 显示 `—`，**不编造 0**。

## 3. 落点与改动（3 个文件）

- `FE/src/stores/selection.js`：`setPoi(gid)` 先 `GET /api/poi/{gid}` 拿 `lon/lat/category`，成功后串 `GET /api/poi/nearby?lon=..&lat=..&radius=800&limit=50`。新增独立 action `loadNearby`，**失败不写 `this.error`**——卡片主体已拿到，次要请求失败只让三格留 `—` 降级即可。请求开始处先 `this.poi = null`，防连点时新 POI 顶着上一个的坐标；两段请求共用同一个 `reqSeq` 做竞态保护。算法抽成文件顶部纯函数 `summarizeNearby()`，三个坑各有注释。
- `FE/src/components/PoiDetailCard.vue`：新增 `nearby` prop，只负责显示——`statCount()` 带千分位、`statSame()` 输出 `"191 m"`、`statSameTitle()` 悬停显示「武汉鸿蒙幼儿园 · 191 m」；`.stat-num` 加 `nowrap + ellipsis`，因为 "191 m" 比纯数字长。组件仍保持不 fetch、不碰 map 的定位（`/api/areas` 反查是唯一的合理例外：静态常量 + 模块级缓存只拉一次）。
- `FE/src/App.vue`：多传一行 `:nearby="selection.nearby"`。

## 4. 验证结果

| 验证 | 结果 |
|---|---|
| 真实接口 + 算法（成丰学校 800m，`byCategory` school 11/hospital 9/mall 7/park 1） | count 28 → **27**；自身被滤掉 → 武汉鸿蒙幼儿园 **191 m** ✅ |
| 边界：东湖水域中心（周边 0 条） | 0 / null → 显示 `0` 与 `—` ✅ |
| 边界：800m 内只有自己 | 0 / null ✅ |
| 边界：同类不在前 50 条 | null（`—`，不编造 0）✅ |
| `vite build` | 221 modules，229 ms，退出码 0 ✅ |
| dev server 模块编译 | `selection.js` / `PoiDetailCard.vue` / `App.vue` 全 200 ✅ |

（性能：800m nearby 查询带索引约 20 ms，每次点 POI 多一个请求可忽略。截图级浏览器验证因桌面被占用 `USER_CONTROL` 未做，需用户手动刷新确认。）

## 5. 仍待用户决定

1. **标签与数字口径不一**：「800m 内设施」显示的是排除自身后的 27，标签仍说"800m 内设施"。二选一：标签改「周边设施」/ 加 `title` 说明不含自身。
2. **「可达性指数」口径未定**，仍是 `—`。可选：删掉 / 同类占比 `byCategory[cat]/count`（本例 39%）/ 设施密度 `count/(π×0.8²)`（本例约 13.9 个/km²）。真正的可达性（等时圈、路网距离）本项目无路网数据，硬凑指数在投递时是减分项。
