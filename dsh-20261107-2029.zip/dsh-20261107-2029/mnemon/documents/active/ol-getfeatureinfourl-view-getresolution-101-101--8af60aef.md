---
id: "8af60aef-8742-4d45-a743-efdbecbc6ca8"
title: "OL getFeatureInfoUrl 与 view.getResolution() 的准确语义（更正：自建 101×101 查询窗口、与出图 bbox 和 source ratio 无关）"
description: "源码级更正记录：getResolution() 是 map-units-per-pixel 汇率，getFeatureInfoUrl 以点击点为中心现场构造 101×101 窗口并用 resolution 换算像素坐标（x/y 恒为 50,50），完全不读 source 缓存 bbox、也与 ratio 1.5 无关；含 ImageWMS 的投影换算分支、图层可见性判断应保留但理由改为产品决定、提交 cf517f2。"
status: "active"
created_at: "2026-11-01T12:16:31.725Z"
updated_at: "2026-11-01T12:16:31.725Z"
content_hash: "0de570252c0c9039975331e03acacef3f6dc5e67515771c99511881d6befee12"
source_paths:
  - "FE/node_modules/ol/source/wms.js"
  - "FE/node_modules/ol/source/ImageWMS.js"
  - "FE/src/map/gridInfo.js"
  - "FE/src/view/mapView.vue"
session_ids:
  - "26b465ee-6b2c-48d5-bb2d-346c35a440e7"
memory_body_ids:
  []
---

# `getFeatureInfoUrl` 与 `view.getResolution()`：一次源码级更正

> **本文是更正，不是重复。** 既有文档 `b4346af9-bbcb-47b6-b128-5f360391455d`（F4 点格弹窗实现）把
> 「`getFeatureInfoUrl` 依赖出图那次 bbox / `ratio` 会放大像素坐标」写成了前提，**这两条是错的**。
> 该文档不可修改，故在此单列更正；F4 的分层、分叉逻辑、零覆盖语义仍以该文档为准。
> 相关：`da1967ee-48c7-4bea-a9b9-e8a2e803d61e`（heat↔poi 互斥、className）、
> `02506967-ac28-421f-886e-e0cc13e39d9f`（`wuhan:grid_500m` 的 GetFeatureInfo 返回体）。

## 0. 结论先行

- `view.getResolution()` = **一个屏幕像素代表多少地图单位**（mpu），随缩放动态变化，**不能初始化时缓存**。
- `getFeatureInfoUrl` 以点击点为中心**现场构造** 101×101 像素窗口，**不读 source 缓存、不依赖 GetMap 的 bbox**。
- 该窗口内点击点恒为 `(x, y) = (50, 50)`；`resolution` 在其中的**唯一作用**是「米 → 像素」换算。
- `source` 的 `ratio`（本项目 1.5）只影响 **GetMap 出图尺寸**，对 `GetFeatureInfo` 的 `WIDTH/HEIGHT=101×101` 无影响。

## 1. 证据（OL 源码，行号为当前 node_modules 版本）

`FE/node_modules/ol/source/wms.js`

```js
const GETFEATUREINFO_IMAGE_SIZE = [101, 101];                  // L24

export function getFeatureInfoUrl(options, coordinate, resolution) {   // L208
  if (options.url === undefined) return undefined;                     // L209-211 ← 唯一 undefined 条件
  const extent = getForViewAndSize(coordinate, resolution, 0, GETFEATUREINFO_IMAGE_SIZE);  // L218
  const x = floor((coordinate[0] - extent[0]) / resolution, DECIMALS); // L232
  const y = floor((extent[3]     - coordinate[1]) / resolution, DECIMALS); // L233
}
```

- 窗口以 `coordinate` 为中心、按传入 `resolution` 反推尺寸 ⇒ `x = y = 50` 恒成立。
- 函数体内**没有任何** source 缓存 / 上次出图 bbox 的读取；返回 `undefined` **只**发生在 `options.url` 未配置时。

`FE/node_modules/ol/source/ImageWMS.js`（L138-169）：`imageWMS.getFeatureInfoUrl(coordinate, resolution, projection, params)` 里，只有当 **source 投影 ≠ view 投影**时才

```js
resolution = calculateSourceResolution(sourceProjectionObj, projectionObj, coordinate, resolution);
coordinate = transform(coordinate, projectionObj, sourceProjectionObj);
```

然后才把 `{...this.params_}` 与 `url_` 交给底层函数。→ 投影一致（本项目均为 EPSG:3857）时是纯透传；存在跨投影时分辨率必须换算，否则像素坐标错。

## 2. 两条曾写错的判断

| 旧说法 | 实际 | 影响的代码 |
|---|---|---|
| 「自动带上出图那次的 BBOX/WIDTH/HEIGHT，所以图层不可见时 `getFeatureInfoUrl` 返回 undefined」 | 窗口是现场造的，与出图无关；只有 `url` 缺失才 undefined | `pickGrid` 里的 `!heatLayer || !heatLayer.getVisible()` 提前返回**保留**，但注释里的**技术理由改为产品理由**（看不见格子就别弹卡片），不能写成「否则 URL 为 undefined」 |
| 「`ratio` 1.5 会让像素坐标要乘 1.5」 | `ratio` 只影响 GetMap 出图分辨率；GetFeatureInfo 恒 101×101 | 手算 URL 时**不要**乘 ratio |

## 3. `resolution` 的量纲与常见用途

- 单位取决于 **view 投影**：EPSG:3857 → 名义米；EPSG:4326 → 度。本项目 `new View({ center: fromLonLat(...) })` 未显式指定投影 ⇒ 3857 名义米。
- 公式（256px 瓦片）：`resolution = 156543.0339 / 2^zoom`；`zoom 9 → ≈305.7`，`zoom 14 → ≈9.55`。
- 3857 的「米」是赤道名义米：武汉纬度 30.5° 处真实地面米 ≈ × cos(30.5°) ≈ 0.86。z9 下 800 地面米 ≈ 3.0 px（名义 2.6 px）。
  这正是 `mapView` 里 `BUFFER_ZOOM = 14` 的由来——z9 时 800 m 缓冲圈只有几个像素，**不是样式问题而是物理尺寸不足**。
- 其它用途：判断要素在当前缩放下是否过小、按像素做点击容差（`像素 × resolution = 地图单位`）、比例尺分母（`getLegendUrl` 内部 `SCALE = resolution * mpu / pixelSize`，见 wms.js L258-277）。

## 4. 落点（改这些文件时别退化）

| 文件 | 与本主题相关的点 |
|---|---|
| `FE/src/map/gridInfo.js` | `pickGrid` 用 `map.getView().getResolution()` **在 singleclick 回调内现取**；注释已按本文更正（提交 `cf517f2`） |
| `FE/src/view/mapView.vue` | 热力优先分叉中的可见性判断同为产品决定，注释已同步 |
| `FE/src/map/heatmap.js` 等 | 任何「像素 ↔ 地图单位」换算都必须现取 resolution，不得缓存 |

构建验证：`vite build` ✓ 265 modules / 306ms；提交 `cf517f2 08 修正 GetFeatureInfo 的注释错误`（仅 2 文件、注释与说明，无行为变更）。
