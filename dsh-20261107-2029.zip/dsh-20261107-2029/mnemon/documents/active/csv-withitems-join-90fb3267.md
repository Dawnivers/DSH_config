---
id: "90fb3267-5347-44a3-bf1b-002e53308b6a"
title: "叠加分析 CSV 导出设施明细：withItems 载荷门控 + JOIN 原子面取「重叠度」（无需去重）+ 三处计数恒等式自检"
description: "叠加分析（overlay）从「只回计数」扩展到可回 POI 明细的落地记录：OverlayReq.withItems 契约、PoiMapper.xml 用 CASE 门控 items/itemsTotal、JOIN atom 让每个 POI 的 deg 唯一（原子面互不重叠故无需去重）、面板 4.1KB vs 导出 26.6KB 的载荷取舍、ΣbyDegree=union=items.length 的自检判据、CSV【设施明细】段格式与三个边界情况、前端 overlayShapes getter 统一载荷。关联 ba6de451。"
status: "active"
created_at: "2026-11-02T13:18:53.152Z"
updated_at: "2026-11-02T13:18:53.152Z"
content_hash: "e1c205cb3d1462505f5fe14b7105ff084b821f903dcb7678f77129e3c080b6fa"
source_paths:
  - "BE/src/main/java/com/dawnivers/be/dto/OverlayReq.java"
  - "BE/src/main/java/com/dawnivers/be/mapper/PoiMapper.java"
  - "BE/src/main/resources/mapper/PoiMapper.xml"
  - "BE/src/main/java/com/dawnivers/be/service/PoiService.java"
  - "BE/src/main/java/com/dawnivers/be/controller/PoiController.java"
  - "FE/src/stores/analysis.js"
  - "FE/src/composables/useBufferAnalysis.js"
  - "FE/src/App.vue"
  - "FE/src/components/OverlayPanel.vue"
session_ids:
  - "0bdd25bd-dc87-4981-8a60-ac5692ccccd1"
memory_body_ids:
  []
---

# 叠加分析 CSV 导出「设施明细」

用户原话：**「csv 中需要包含具体的 poi 点」**。此前 `POST /api/poi/overlay` 只回计数
（面板底部当时写着「注：叠加接口只返回计数，不含设施明细」），CSV 里没有任何具体设施。
本文记录把明细打通的做法与判据。整体叠加（平面细分 SQL、原子面、API 校验）见
`ba6de451-a7df-45f6-a031-d8f4a2ca66d9`，本文只记**增量**。

## 1. 契约变更：一个 `withItems` 开关，而不是两个接口

```
{ "shapes": [...], "withItems": false }   // 面板取数：数字 + 几何
{ "shapes": [...], "withItems": true  }   // 导出：额外带 items[] / itemsTotal
```

实测同一组 3 个面：

| 模式 | 响应体 | 耗时 |
|---|---|---|
| `withItems:false` | 4,151 字节 | 486 ms |
| `withItems:true` | 26,624 字节 | 92 ms |

**6.5 倍差**。面板每拖一次半径滑杆就发一次请求（50 m 步长、260 ms 防抖合并），
那几百条 POI 每次都用不上，纯浪费带宽和序列化。

**为什么不做成 `/overlay` + `/overlay/items` 两个接口**：两者只差一个输出块，
SQL 里加一个 `CASE ... WHEN cast(#{withItems} as boolean)` 就够；
拆两个接口意味着那段 60 行平面细分 SQL（`noded → faces → tagged → atom`）要抄两遍，
迟早抄漏一处，两份统计就会开始互相矛盾。

## 2. SQL：从 `atom` JOIN 出明细，`deg` 天然唯一

```sql
FROM poi p
JOIN atom a ON ST_Contains(a.g, p.geom)
```

**原子面互不重叠**（平面细分的定义就是「边界打节点后碎成互不相交的面」），
所以每个 POI 至多匹配一个原子面，`deg` 由那一个原子面直接确定。
**不需要任何 DISTINCT / 去重 / GROUP BY 兜底** —— 这是细分本身给的保证，不是运气。

排序 `ORDER BY deg DESC, gid`：撞到 5000 条上限被截断时，丢的是边缘 1 重的设施，
核心区（3 重）永远不会被截掉。

明细字段：`gid, name, category, lon, lat, deg, members[]`
（`members` 是 `["s1","s2","s3"]`，前端渲染成 `A·B·C`）。

## 3. 自检判据：三处计数必须相等

```
Σ(byDegree.poi) = 165   vs   union.poi = 165          ✅
items.length    = 165   vs   union.poi = 165          ✅
明细按 deg 计数  {"1":52,"2":59,"3":54}
byDegree 统计    {"1":52,"2":59,"3":54}                ✅ 完全一致
```

最后一条是最强的正确性信号：**每个 POI 恰好落在一个原子面里**，
所以「明细按度分组的计数」与「汇总按度统计」必然相等。
两边差一个数就说明细分出现了重叠或空洞 —— 这条比面积恒等式
（`Σ byDegree.areaKm2 == union.areaKm2`）更灵敏，因为面积恒等式在小面积错位上会四舍五入掩盖。

改 SQL 后建议照抄这个对照表当回归检查，成本几行脚本。

## 4. 前端：载荷拼装收进 store getter

- `analysis.js` 新增 getter `overlayShapes`：**请求载荷的唯一来源**。
  原来 `useBufferAnalysis` 里手拼一份、导出时再拼一份，漏个字段（例如忘带 `radius`）
  就会两边各错各的。
- `useBufferAnalysis.js` 改用该 getter + 固定 `withItems: false`。
- `App.vue`：`onExportOverlayCsv` 改成 **async**，导出前先补拉一次
  `withItems: true` 的明细，再拼 CSV；新增 `overlayExporting` 态。
- `OverlayPanel.vue`：导出按钮带「导出中…」态（明细请求是额外一次往返）。

## 5. CSV 结构（新增最后一段）

```csv
【设施明细】
序号,名称,类别,经度,纬度,重叠度,覆盖区域
1,湖北中医药大学昙华林校区,学校,114.307201,30.552886,3 重,A·B·C
...
165,中华优秀传统文化主题公园,公园,114.303528,30.543618,1 重,A
```

实测 200 行 / 14,217 字节。`覆盖区域` 把 `members` 的 `s1/s2/s3` 翻成 `A·B·C`，
与地图/面板上的字母一致。

沿用既有约定：**面积不补 `toFixed(2)`**，保留后端三位小数 —— 面板底部
「各重叠度面积相加 = 并集」是恒等式，两位小数会破（实测 2.056+0.968=3.024，
显示成 2.06+0.97=3.03 而并集 3.02，看起来像 bug）。导出给人做数据处理，精度优先。

## 6. 三个边界情况

| 情况 | CSV 行为 |
|---|---|
| 补拉明细失败（后端挂 / 网络断） | 退回屏幕上那份统计，明细段写「（明细获取失败，仅导出统计）」——不假装有 |
| 范围内没有设施 | 明细段写「（范围内没有设施）」，而不是留一段空白表头 |
| 超 `MAX_ITEM_LIMIT = 5000` 被截断 | 末尾写「注：设施共 N 条，此处仅导出前 5000 条」 |

## 7. 改动文件

| 文件 | 改动 |
|---|---|
| `BE/.../dto/OverlayReq.java` | 加 `Boolean withItems` |
| `BE/.../mapper/PoiMapper.java` | `overlay(shapesJson, withItems, itemLimit)` |
| `BE/.../resources/mapper/PoiMapper.xml` | 新增 `items` / `itemsTotal` 两块，`CASE WHEN cast(#{withItems} as boolean)` 门控 |
| `BE/.../service/PoiService.java` | `MAX_ITEM_LIMIT = 5000`，参数透传 |
| `BE/.../controller/PoiController.java` | `Boolean.TRUE.equals(req.withItems())` |
| `FE/src/stores/analysis.js` | 新增 getter `overlayShapes` |
| `FE/src/composables/useBufferAnalysis.js` | 改用 getter + `withItems:false` |
| `FE/src/App.vue` | `onExportOverlayCsv` 改 async、补拉明细、`overlayExporting` |
| `FE/src/components/OverlayPanel.vue` | 按钮「导出中…」态 |

验证：`vite build` 通过（271 modules，373 ms）；后端重新编译并重启（旧的 8094 进程 kill，
新 pid 29572）后接口返回上述数字。

## 8. 遗留

- 明细只带 `gid/name/category/lon/lat`，不含地址、电话等 POI 其它字段；
  若导出要给业务方直接看，需再补列。
- 明细未按前端勾选的类别过滤（后端只按几何归属算），面板类别开关不影响 CSV 明细 ——
  当前视为一致（面板统计同理走全类别），如要改成「只导勾选类别」需在 SQL 的 `poi` 段加条件。
