---
id: "dce923b3-33da-420b-a8f1-eeb8bf7f2d2a"
title: "BE 8094「进程被杀」实为端口已被占用：Spring Boot Maven 插件的误判排查记录（2026-10-30）"
description: "排查 openlayers 平台 BE 8094 反复报 `spring-boot-maven-plugin Process terminated with exit code: -1` 的经过与结论：真实原因是从 `mvn spring-boot:run` 启动的 maven+子 java 进程仍在运行，重复启动撞端口；含识别父子进程、确认服务真实存活、以及 `-1` 退出码的正确解读与误判代价。补充 Step 2 selection store 前端语义要点（详见 D12 文档）。"
status: "active"
created_at: "2026-10-30T08:46:41.778Z"
updated_at: "2026-10-30T08:46:41.778Z"
content_hash: "6dfc24dc60c51f3469a3f8093e7584c9b2835b47be8907c6361429924c87c66c"
source_paths:
  - "BE/pom.xml"
  - "BE/src/main/resources/application.yml"
  - "FE/src/stores/selection.js"
  - "FE/docs/roadmap.md"
session_ids:
  - "95bf82c4-46c0-4562-8866-289d261774f5"
memory_body_ids:
  []
---

# BE 8094「进程被杀」误判排查记录（2026-10-30）

前置文档：D12 点击查询骨架契约见 `e6e821b8-8ad6-4a4a-a43b-28efd3409221`；Step 1 watchController 验收与 Pinia 时序坑见 `97dfeb05-26ab-49f1-b8e4-47147bc2a429`。

## 1. 现象序列（三次完全一致）

每次启动 BE（`mvn spring-boot:run`），日志都正常跑到 HikariPool 建连完成、接口被请求并返回后，Maven 侧输出：

```
[ERROR] Failed to execute goal ...spring-boot-maven-plugin:3.5.16:run (default-cli) on project be:
        Process terminated with exit code: -1
[status: completed, exit code: 1]
```

期间 8094 一度探测为**未监听**（`/api/hello` 报 `HttpClient.Timeout of 3 seconds`），于是先按「JVM 被外部杀掉」处理，连续尝试了三种补救：

1. 按后台作业方式重启 → 约 15 秒后仍 200，看似正常；
2. `mvn package -DskipTests` 后 `java -jar target/be-0.0.1-SNAPSHOT.jar` 独立启动 → 启动 ~1.5s 通，但 12 秒后又不通；
3. 再次后台重启 → 这次日志里出现明确报错：

```
APPLICATION FAILED TO START
Web server failed to start. Port 8094 was already in use.
```

## 2. 真实原因

**端口 8094 早就有实例在跑，退出码 -1 是被重复启动/父子进程关系制造的假象，不是业务代码崩溃。**

证据链：

- `Get-NetTCPConnection -LocalPort 8094` 显示占用者 `pid=38428`（java，启动于较早时刻），其**父进程 `13364` 是 `D:\java\bin\java.exe -classpath ...maven... m2.conf`**，即 Maven 本体；
- `38428` 的命令行为 `java -XX:TieredStopAtLevel=1 -cp @...Temp\spring-boot-*.argfile com.dawnivers.be.BeApplication` —— Spring Boot Maven 插件 fork 出来的**子 JVM**；
- 前台 `mvn spring-boot:run` 会话结束（或作业被回收）时，Maven 父进程退出 → 插件上报 `exit code: -1` 并 return 1，**但子 JVM 仍留在后台继续监听 8094**；
- 连续 20 秒探测（每 4s 一次）全部 200，证明服务实际是稳定的。

所以之前「8094 未监听」的时刻，是旧实例恰好已随某个父进程清理退出、新实例尚未起来的窗口，而不是正在运行的实例被杀。

## 3. 正确解读与排查顺序

- `Process terminated with exit code: -1` 在 spring-boot-maven-plugin 里表示**它 fork 的子进程被终止或无法纳管**，不等于应用抛异常。判断是否真挂，要看日志里有没有 Java 异常栈 —— 本例最后的日志是 Hikari 建连成功，无任何异常。
- **任何一次「进程没了」都先查端口占用与进程父子关系**，再看代码：
  ```powershell
  Get-NetTCPConnection -LocalPort 8094 -State Listen | Select OwningProcess
  Get-CimInstance Win32_Process -Filter "ProcessId=<pid>" | Select ProcessId,ParentProcessId,CommandLine
  ```
  父进程是 maven、子进程是 `BeApplication` 的配对，说明是插件 fork 模式；此时再启一次必然撞端口。
- 重复启动前先做一次存活探测（`/api/hello` 200 + 连续多次探测），避免把「已经在跑」误判为「需要重启」。
- 诊断期间曾被误导的方向（后来均排除）：机器内存压力（31.2 GB 中可用 11.2 GB、使用率 64%）、Windows 系统/应用日志里的进程终止事件（无相关记录）、残留 java 进程泄漏（`11888` 实为 GeoServer，属正常）。

## 4. 当天的服务拓扑（供对照）

| 服务 | 端口 | 身份 |
|---|---|---|
| PostgreSQL | 5432 | 本地已在跑 |
| GeoServer | 8080 | java，`pid=11888`，12:16 启动 |
| BE | 8094 | java 子进程（父进程为 maven），profile `local` |
| FE | 5173 | Vite `pid=33188` |

## 5. 与 Step 2 的关系

排查结束后确认 `FE/src/stores/selection.js` 仍是空骨架（`state: () => ({ ... })` 占位），后端 `/api/poi/1` 200、`/api/poi/999999999` 404，Step 2 可直接继续。

`selectByGid` 的关键纪律（取号在 fetch 前并存局部变量、`if (!res.ok)` 后必须 return 否则会把 Spring 错误体 `{timestamp,status,error,path}` 当 POI 存下、`loading=false` 只在号匹配时执行、`clear()` 也要 `reqSeq += 1` 以作废在途请求）见 D12 文档对应行，本文不重复。

## 6. 一句话结论

`exit code: -1` 是**假死信号**；8094 反复「消失又出现」的根因是 maven fork 出的子 JVM 在父进程退出后继续存活，重复启动撞端口。以后见到这个退出码，先查端口占用与父子进程，而不是先怀疑代码。
