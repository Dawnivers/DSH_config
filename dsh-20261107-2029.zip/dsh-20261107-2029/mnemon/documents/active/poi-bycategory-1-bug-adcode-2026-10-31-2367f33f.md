---
id: "2367f33f-16bf-4bb1-9117-5c2058a830b5"
title: "POI 详情卡第三格落地：相对密度「密度倍数」算法选型、byCategory-1 负值 bug 修复与 adcode 字段补齐（2026-10-31）"
description: "承接 nearby 接入文档 633dbb79 的后续：以现有 5 个接口为原料对比 5 个候选可达性/密度算法并用真实 POI 实测，确定「密度倍数 = 800m 密度 ÷ 本区 perKm2，封顶 10」；修复 byCategory[cat]-1 得 -1 的 bug（改为 nearest[] 滤自身后再分类计数）；PoiDto 增补 adcode 及 nullif/btrim 转换；含三级请求链路、真实 POI 结果表、验证清单、以及为什么不能用 2SFCA 的边界说明。"
status: "active"
created_at: "2026-10-31T02:49:55.475Z"
updated_at: "2026-10-31T02:49:55.475Z"
content_hash: "0fe97725622b5cad0bb323191489499796e194322765288ddc3774d571c6e354"
source_paths:
  - "FE/src/stores/selection.js"
  - "FE/src/components/PoiDetailCard.vue"
  - "FE/src/App.vue"
  - "FE/src/docs/roadmap.md"
  - "BE/src/main/java/com/dawnivers/be/dto/PoiDto.java"
  - "BE/src/main/resources/mapper/PoiMapper.xml"
session_ids:
  - "692bb70e-ccf4-423d-82b3-04a748d812ee"
memory_body_ids:
  []
---

# 第三格「密度倍数」落地 + nearby 负值 bug 修复

承接 `633dbb79-9211-4c7a-aadf-3615c2361d2a`（nearby 三格接入，当时第三格仍是 `—`，且列出两个待用户决定项），用户答复：**「使用相对密度，并修复bug」**。总设计见 `266aea70-7a25-4d94-8359-39555b8b651f`；数据层采样与 adcode 口径见 `8d2fc1c9-4493-4ece-88e1-59e02ad49c43`。

## 1. Bug：`byCategory[cat] - 1` 会算出 **-1**

- 触发条件：圆心不在半径内（例：用东湖水体坐标调 `/api/poi/nearby`），四个分类计数全为 0，再减一得 `-1`。
- 上一版只给 `count` 加了 `Math.max(0, …)`，**分类计数没有兜底**。
- 正确认识：**「减一」只对 `count` 安全**（圆心必在半径内，`count ≥ 1` 恒成立）；`byCategory` 的分类计数**不能减**，因为 `byCategory` 不保证自身归属该类别、也不保证自身在圆内。
- 修法不是补 `Math.max`，而是**取消这个减法**：同类数改用 `nearest[]` 按 `distanceM > 0` 滤掉自身后按 `category` 计数。
- 回归实测：东湖水体 `count=0` → 周边 `0`（旧实现 −1）、同类 `null`、密度 `0.0 倍`，不再出现负数。

## 2. 候选算法对比（全部用真实数据实跑后再选）

原料：现有 5 个接口 —— `/api/hello`、`/api/ping-db`、`/api/areas`、`/api/poi/{gid}`、`/api/poi/nearby`、`/api/stats/coverage?adcode=`（后者返回 `total/areaKm2/perKm2/byCategory`，如武昌 1681 条 / 100.06 km² / 16.8 perKm²）。

| # | 算法 | 公式 | 成丰学校 | 解放公园 | 东湖孤点 | 评级 |
|---|---|---|---|---|---|---|
| A | 同类就近度 | `1/(1 + d/800)` | 0.807 | 0.822 | 0.376 | ⭐⭐⭐⭐ |
| B | 供给冗余比 | `(同类+1)/(总数+1)` | 0.379 | 0.176 | 0 | ⭐⭐ |
| C | **相对密度** | `(count-1)/2.0106 ÷ 本区perKm2` | 3.56 | 1.43 | 0.72 | ⭐⭐⭐⭐⭐ 采用 |
| D | 同类均值距离 | 前 3 个同类距离均值 | 268 m | 184 m | — | ⭐⭐⭐ |
| E | 类别均衡度 | 信息熵 `H/Hmax` | 0.864 | 0.984 | 0 | ⭐⭐ |

选 C 的理由：只复用两个已写好的接口；自带基准不用拍阈值（“是区均的 3.6 倍”比 “13.4 个/km²”好读）；与左边「周边设施」的绝对数形成绝对/相对呼应。

## 3. 最终公式与参数

```
周边     = count - 1                       // 圆心必含自身
本地密度 = 周边 / 2.0106 km²                // π × 0.8² = 2.010603
密度倍数 = 本地密度 / 本区 perKm2           // 封顶 RATIO_MAX = 10
```

边界：`count=0` → 0.0 倍；`perKm2 = 0` 或 coverage 无效 → `null`（÷0 已挡）；比值超 10 → 封顶 10。

## 4. 链路与改动

前端 `FE/src/stores/selection.js` 串成三级请求，后两级失败**静默降级、不写 `this.error`**：

```
GET /api/poi/{gid}               → lon/lat/category/adcode
GET /api/poi/nearby?...radius=800&limit=50 → 周边 / 同类最近
GET /api/stats/coverage?adcode=  → 本区 perKm2 → 密度倍数
```

后端小改（`/api/poi/{gid}` 原本没有 `adcode`，前端拿不到区号就无法查本区密度）：

- `BE/src/main/java/com/dawnivers/be/dto/PoiDto.java`：record 末尾追加第 12 个字段 `adcode`。
- `BE/src/main/resources/mapper/PoiMapper.xml`：`selectByGid` 增加 `nullif(btrim(adcode),'')::integer as adcode`（`poi.adcode` 是 text，直接 `::integer` 遇到空串/空格会炸）。加转换前先查过数据：16016 条全是 6 位数字、0 个 NULL、0 个非 6 位。`resultMap` 用 constructor 注入，新增参数需与 record 顺序一致。
- `FE/src/components/PoiDetailCard.vue`：只做显示。标签改为「周边设施」（数字已排除自身，原「800m 内设施」会误导）、第三格「可达性指数」→「密度倍数」；悬停文案「800m 内 24.4 个/km² ÷ 江岸区全区平均 17.1 个/km²」。
- `FE/src/App.vue`：多传 `:nearby`。
- `FE/docs/roadmap.md` 增 §4.2，记录“只有 count 能减一”和“perKm2 是全域平均”两条口径性质。

## 5. 真实 POI 实测（2026-10-31）

| POI | 周边 | 同类最近 | 本区 | 本地密度 | 密度倍数 |
|---|---|---|---|---|---|
| 解放公园 (gid=1) | 49 | 解放公园-中心广场 173 m | 江岸 17.1/km² | 24.4/km² | **1.4 倍** |
| 汉口江滩2期 (gid=2) | 28 | 汉口江滩-五福广场 164 m | 江岸 17.1/km² | 13.9/km² | **0.8 倍** |
| 政和广场 (gid=39) | 148 | 珞园 384 m | 江岸 17.1/km² | 73.6/km² | **4.3 倍** |
| 武汉成丰学校（此前算的） | 27 | 武汉鸿蒙幼儿园 191 m | 洪山 3.77/km² | 13.4/km² | 3.6 倍 |

同区对比说明倍数确实比绝对值有信息量：同在江岸区，政和广场周边是区均 4.3 倍、汉口江滩只有 0.8 倍。

## 6. 验证清单

| 验证 | 结果 |
|---|---|
| `/api/poi/1` 返回 12 字段、`adcode: 420102` | ✅ |
| 端到端三步链路（3 个真实 POI） | ✅ 见上表 |
| 边界：东湖水体 0 条 | 周边 0 / 同类 null / 密度 0.0 ✅ |
| 边界：`perKm2 = 0` | 密度 null ✅ |
| 边界：比值超大（count=1000） | 封顶 10 ✅ |
| 后端 `mvn test`（PoiApiTest） | 3 用例全绿，6.6 s ✅ |
| 前端 `vite build` | 221 modules，退出码 0 ✅ |
| 产物含新逻辑 | 「密度倍数」「周边设施」`/api/stats/coverage` `adcode=` 均在 ✅ |
| dev server 模块编译 | `selection.js` / `PoiDetailCard.vue` / `App.vue` 全 200 ✅ |

环境注意：后端 8094 由助手以后台任务重启加载新 jar；用户自行启动前需先停掉，否则端口冲突。本机 psql 实际在 `D:\PostgreSQL18.4\data\18\bin\psql.exe`（不在 PATH，`D:\PostgreSQL18.4\bin` 下没有）。

## 7. 口径边界（答辩时要说清）

- 这不是真可达性。`perKm2` 是**全域平均**，含水域与山地（洪山区 514 km²、区均仅 3.77，因东湖占大片），因此比值普遍偏高——这是口径性质，不是 bug；极端低密度区（汉南 0.69/km²）会让比值剧烈放大，故封顶 10。
- 2SFCA 需要每个设施的服务能力 `S_j`（床位数/学位数）与需求点人口分布，两者都没有；网络等时圈需要路网拓扑与阻抗，也没有（`ST_DWithin` 只是球面直线距离）。**硬凑假 `S_j` 会在答辩被问来源时露馅**，所以不叫「可达性指数」，叫「密度倍数」/「周边密度指数」。
- 数据本身是高德采样级（见 `8d2fc1c9`），密度只能说「采集到的设施密度」，不能说绝对真值。
