---
id: "a4c58cb0-af7f-4413-ac80-42aaaa4f2111"
title: "dsh-see-now 插件音频能力调查：只「看」不「听」，音频位在采集层被写死（v0.0.7）"
description: "对 dsh-see-now（DSH 实时视觉插件，v0.0.7）音频能力的源码级调查：采集层固定 -an、macOS avfoundation 音频位写 none、say/TTS 属输出侧、麦克风仅浮窗示例 mic.py 且缺 aec.py 依赖；含证据文件行号、结论、浮窗路径/锁的坑与扩展建议。"
status: "active"
created_at: "2026-11-07T08:11:47.334Z"
updated_at: "2026-11-07T08:11:47.334Z"
content_hash: "23cc19e1d7d3d6262ebbd923a7bb3123a58f294539febf8b1488ec2b8153932f"
source_paths:
  []
session_ids:
  - "eab25e25-8a72-419e-a64d-028de2797f89"
memory_body_ids:
  []
---

# dsh-see-now 插件音频能力调查（v0.0.7）

日期：2026-11-06 / 07。起因：用户想知道 dsh-see-now 这个「让 AI 实时看见屏幕」的插件**能不能听见声音**。
调查方式：克隆源码逐文件核对。仓库克隆在 `D:\temp\dsh-see-now`（工作区之外的临时目录），上游主仓 `SAOS-3624/dsh-see-now`，用户当时看的 `linkete` 是其 fork。下文路径均相对该仓库根。

## 结论一句话

**See Now = 眼睛 + 嘴，没有耳朵。** 不是「没做」，而是在采集层**刻意把音频关掉**；README 里的「声音」章节方向是反的——那是 **AI 说给用户听**（TTS 输出），不是 AI 听用户说。

## 三条链路对照

| 链路 | 方向 | 是否具备 |
|---|---|---|
| ffmpeg 采屏幕 / 摄像头 / 视频文件 | 画面 → 模型 | ✅ 有，且 `-an` 强制无音轨 |
| `say` 参数 + 悬浮窗（TTS） | 模型 → 用户 | ⚠️ 可选，需自配 voice adapter |
| 麦克风 → ASR → 文字 | 用户 → 模型 | 🔸 仅存在于打包的浮窗示例，且有依赖缺口 |

## 证据：音轨被显式禁掉

- `src/capture.js:147` 拼完采集参数后固定追加 `args.push('-an', '-sn')` —— `-an` 即 no audio，任何源都不许带声音进入。
- `src/capture.js:85`（macOS）设备写成 `` `${s.device ?? DEFAULT_SCREEN_DEVICE}:none` ``：`avfoundation` 语法是 `视频设备:音频设备`，音频位直接 `none`；摄像头分支 `capture.js:68` 同理。
- `CHANGELOG.md` 0.0.6 明说取舍理由：*「音频写 `none`，否则某些系统会去开麦克风、多弹一次权限」* —— 宁可不启动也不碰麦克风。
- 回归测试守着这条：`test/live.test.mjs:142` 断言命令行含 `Capture screen 0:none`，注释为「屏幕设备名 + 音频 none，避免开麦克风」。
- 交给模型的载荷只有图：`src/index.js:124-132` 为 `saveImage({ data: sheet.png, mediaType: 'image/png' })` + `images: [ref]`，纯 PNG 拼图。
- `source:"file"` 回放视频同样吃 `-an`：放一段有人说话的 mp4，也只有画面帧，台词进不来。

## 「声音」章节其实是输出侧（TTS）

- README「声音」（约 L160 起）：核心**不内置任何 TTS 引擎**，只按 `~/.dsh/voice.json` 的 `adapter` 路径 dynamic import 一个模块。
- macOS 自带示例 `examples/voice-say-mac.mjs`，本质是调系统 `say`；音色/语速读 `~/.dsh/tts.json`（与 dsh-watch-together 共用）。
- `src/speech.js:2` / `src/voice.js:2` 自述：核心只发事件、永不发声；按路径挂外部适配器。
- **不配 `voice.json` 就完全没有声音**，AI 只往悬浮窗写字。
- 适配器约定两条硬要求：串行（两个 `say` 抢音频设备会像结巴）与 `spoken` 在出声瞬间上报（展示层「字跟着声音走」）。配置指纹每次调用前比对，改音色下一句即生效，无需重启。

## 唯一「能听」的角落：examples/floating-chat/mic.py

浮窗 🎤 按钮启动的 Python 进程，麦克风 → 本地 sherpa-onnx ASR → 文字写进 `chat.jsonl` → 模型收到的是**文字**，仍非音频流。几个必须知道的坑：

1. **它主动不要电脑的声音。** 文件头标题即「一个必须挡住的坑：它不能听见自己」——TTS 念台词 → 音箱出声 → 麦克风听见 → 转成「用户说的话」→ 无限自激。两道闸：`quiet-until.json` 静音窗口（`mic.py:104` `tts_busy()`）与 `aec.py` 回声消除（`mic.py:61`，把电脑外放声音从麦克风里减掉）。因此系统音频/视频里的声音它不听，只听麦克风。
2. **非开箱可用（依赖缺口）。** `mic.py:61` 是顶层 `from aec import FdafAec, find_loopback_device`，无 try 兜底；而本仓库**不含 `aec.py`**，`scripts/sync-window.mjs:149` 的同步清单 `['mic-dsh.png','mic.py','window_protocol.py']` 也不含它。没装作者另一个项目 `dsh-watch-together`，点 🎤 直接 `ModuleNotFoundError: aec`。另需 `pip install sounddevice numpy` + 一份 sherpa 模型（注释实测 ≈284MB 工作集、加载 1.8–2.6s），且必须用 ASR 那个 Python 解释器启动（`window.py:132-139` `asr_python()`，依次找 `DSH_ASR_PYTHON` / `DSH_FLOAT_PYTHON`）。
3. **默认模型目录写死作者路径**（`mic.py` 约 L232 指向 `D:/asr-local/models-sherpa`），要与本机 ASR 环境（同一作者体系）对齐才顺。
4. 默认 `--engine local` 的取舍有实测依据：单实例 ≈284MB，同实例并发转写几乎不排队（45s 长音频转写时 3s 短句仅 0.14s），且现有 HTTP 服务把解码写在 `async def` 里会堵事件循环，故宁可让麦克风自带模型；`--engine http` 可省 284MB 但要等长音频转完。
5. 另一个易踩的坑（`window.js` / `window.py` 侧）：浮窗脚本默认复用已装的 `dsh-watch-together/examples/floating-chat/window.py`，按 `DSH_SEE_WINDOW` → `~/.dsh/see-window.json` → `~/.dsh/watch-window.json` → profile 里装的那份 → 开发仓库那份依次查找；但**聊天记录目录**（`DSH_VIDEO_CACHE_DIR` → `~/.dsh/see-now`）与 **pid 锁**（`~/.dsh/see-now-window.pid`）必须独立，否则消息会串进陪看那个窗、陪看窗开着时本插件不敢开窗。

## 若要真让它「听见声音」，需另起一条链

- 系统正在播放的声音 → Windows 采「立体声混音」/ WASAPI loopback（`aec.py` 的 `find_loopback_device` 干的就是这个，但只当消回声参考信号，**不送转写**）；
- 用户说话 → 麦克风 + ASR（即 `mic.py` 那条路），先补齐 `aec` 依赖；
- 转出的**文字**再喂模型；音频本体进不了当前多模态通道，除非换原生支持音频输入的模型接口。

## 环境备注（影响复用此仓库）

本机 git 直连 GitHub 报 `OpenSSL SSL_connect: SSL_ERROR_SYSCALL in connection to github.com:443`；需挂代理 `git -c http.proxy=http://127.0.0.1:7897` 才能 clone（7890 端口拒绝连接，未设代理时同样失败）。
