---
id: "da1967ee-48c7-4bea-a9b9-e8a2e803d61e"
title: "F1 热力图前端接入：图层开关 + 五类单选 + 图例联动（className 真 bug、建层顺序、heat↔poi 互斥）"
description: "把 wuhan:grid_500m 热力图接进 OpenLayers 前端的实现结论：ImageWMS 的 className 被静默忽略导致分析模式不变灰、同 zIndex 下靠加入顺序决定压盖（热力面必须先于 POI 点建）、heat 与 poi 互斥、类别切换只 updateParams、图例必须切换而非并排、无覆盖档虚线；含浏览器实测链路与提交 d4e6f3f。"
status: "active"
created_at: "2026-11-01T10:57:11.728Z"
updated_at: "2026-11-01T10:57:11.728Z"
content_hash: "c42420032f1924bd8c09ea1a20176acd28a514e8a77a4a42b779667212020841"
source_paths:
  - "FE/src/map/wms.js"
  - "FE/src/map/layers.js"
  - "FE/src/stores/layers.js"
  - "FE/src/view/mapView.vue"
  - "FE/src/components/LayerPanel.vue"
  - "FE/src/components/MapLegend.vue"
  - "FE/src/App.vue"
  - "FE/src/map/heatmap.js"
  - "FE/docs/roadmap.md"
session_ids:
  - "81fb736e-1e71-4a16-96c2-724980881384"
memory_body_ids:
  []
---

# F1 热力图前端接入（2026-11-01）

承接：
- 热力图配置层 `heatmap.js` 单一真源（5 类别色带 / 图例推导 / SLD XSD 修正）：`f44684ab-1d9d-4247-808c-3e1b832c9132`
- park 必须按个数分档、`updateParams` 换样式、charset 坑：`ac533754-9c9f-4b60-a2a1-d073f50a0648`
- FE 侧 WMS 接入的分层纪律（工厂 + 注册表 + Pinia 只存标量 + watch immediate）：`563ae7f5-4d89-40d3-af0b-fc24c1f473cc`

本文只记「把已发布的热力图真正接进 UI」这一段，不重复上述配置与 SLD 结论。

提交：`d4e6f3f 03 F1 热力图接入：图层开关 + 五类单选 + 图例联动`（7 files, +261/−21，已 push）。
上一提交 `4b10f1d` 是配置层 + SLD 修正。

## 1. 改动面（7 个文件）

| 文件 | 职责 |
|---|---|
| `FE/src/map/wms.js` | `createHeatLayer(map, url, layer, id, style, className)` 工厂 |
| `FE/src/map/layers.js` | 注册表加 `heat` 行，带 `options`（五类） |
| `FE/src/stores/layers.js` | `visible.heat` / `opacity.heat` / `heatCategory` / `setHeatCategory` / heat↔poi 互斥 |
| `FE/src/view/mapView.vue` | 建热力层（在 POI **之前**）、`watch(heatCategory) → updateParams` |
| `FE/src/components/LayerPanel.vue` | 可点类别单选行 + `option-pick` 事件 |
| `FE/src/components/MapLegend.vue` | `mode='poi'|'heat'` 双模式，热力色带 + 虚线「无覆盖」块 |
| `FE/src/App.vue` | 装配类别切换与图例模式联动 |

## 2. 真 bug：`className` 写在 source 上会被静默忽略

原始写法（不在 `ImageLayer` 上）：

```js
source: new ImageWMS({
  ...
  className: 'ol-layer-base',   // ❌ ImageWMS 不认识这个键
})
```

**`className` 是 `ImageLayer` 的选项，`ImageWMS`（source）没有该配置项**，多传的键不报错、直接被忽略——后果是热力图在「分析模式」下**不会跟着变灰**（`ol-layer-base` 那套灰度滤镜挂不上）。

已移到 layer 层，与其他图层一致：

```js
new ImageLayer({ source, className, opacity, visible, zIndex })
```

> 可推广判据：OL 的选项「错层」是**静默失败**，构建、运行、HTTP 都不会报。凡是同一语义在两个对象上都有同名键时，改动后必须用**可观测行为**验证（这里靠「进分析模式看是否变灰」），不能靠"代码看起来对"。

顺带把 `opacity` 由 `1.0` 调到 `0.8`：热力图是**面**，1.0 会把天地图底图完全盖死。

## 3. 三条设计约束（改代码别退化）

### ① 热力层必须建在 POI **之前**

```js
heatLayer = createHeatLayer(...)   // 先
poiLayer  = createPOILayer(...)    // 后
```

同 `zIndex` 时 OpenLayers 按**加入顺序**决定压盖，后加的在上。热力图是面、POI 是点，**点必须浮在面之上**，否则图钉被半透明色块压暗。这条与注册表顺序也相关——仅调 `zIndex` 不够，因为多层用同一 `zIndex` 依赖顺序。

### ② heat 与 poi 互斥

```js
toggle(id, next) {
  this.visible[id] = next
  if (id === 'heat' && next) this.visible.poi = false
  if (id === 'poi'  && next) this.visible.heat = false
}
```

两层是同一批数据的两种表达（面 vs 点），同时开会互相糊。互斥写在 store 的 `toggle` 里，而不是组件事件里——这样任何入口（面板、快捷键、以后的地图内控件）都自动一致。

### ③ 图例必须**切换**而不是并排

POI 图例是「类别 → 颜色」，热力图例是「数值 → 颜色」。两个同时出现，用户会以为「红 = 医院」和「红 = 密度高」是同一套语义。因此 `MapLegend` 用 `mode='poi'|'heat'` 互斥渲染，而不是追加一段。

配套：「无覆盖」档用**虚线空心块**。67.3% 的格子为空，不画这一条，用户会以为地图没加载完。

## 4. 验证方式（无截图条件下仍可证链）

桌面被用户占用（截图返回 `USER_CONTROL`），因此放弃截图，改用**图例文本快照**作为可证伪信号：

| 步骤 | 观测 | 结论 |
|---|---|---|
| 打开热力图 | 面板出现 `[全部][学校][医院][商场][公园]`；图例变「可达性热力图 / 相对全市平均的倍数 / 虚线 无覆盖 / 5 个倍数档」 | 层 + 单选 + 图例 heat 模式通 |
| 点「公园」 | 图例自动变「800m 步行圈内个数 / 0 个 / 1 个 / 2 个 / 3 个 / ≥4 个」 | store→图例链路通，`unit:'count'` 分支生效 |
| 关闭热力图 | 图例回到「学校 / 医院 / 诊所 / 商场 / 超市 / 公园」，类别按钮消失 | 双模式互斥正确 |
| `vite build` | `✓ 261 modules transformed`，`built in 295ms`（仅 500 kB chunk 体积告警） | 无编译回归 |

**面板里的原生 checkbox 因 `opacity:0; width:0` 无法被浏览器工具直接点击**。临时把 `visible.heat` 默认值改成 `true`（HMR 自动刷新）完成验证，**验证后立刻改回 `false`**。这类"改默认值绕过 UI 不可点"的手法必须成对执行，否则会漏改回。

## 5. 收尾状态

- `.chk` 构建产物已被 `FE/.gitignore:44` 忽略（构建输出到 `.chk/`，不入库）。
- 提交推送成功；Git 提示 `LF will be replaced by CRLF`（Windows 换行告警，非问题）。

## 6. 尚未做（F4 可选）

热力图**点格弹窗**未实现：点任意格子显示「本格 800m 内：学校 19 / 医院 53 / 商场 96 / 公园 8」。
数据现成（`GetFeatureInfo` 返回全部字段），实现点是 `mapView` 的 `singleclick`：热力图可见时不查 POI，改查热力图。

需要调整时的入口：分档阈值/配色 → `heatmap.js` + `BE/styles/grid_*.sld`（**两边一起改**）；默认透明度 → `stores/layers.js` 的 `opacity.heat`；默认类别 → `heatmap.js` 的 `HEAT_DEFAULT_CATEGORY`；面板按钮样式 → `LayerPanel.vue` 的 `.lp-opt`；图例宽度/色块 → `MapLegend.vue` 的 `.legend.is-heat`。
