---
id: "e54b31f6-6154-42fc-b6e1-e4793913612f"
title: "G2 更正与补充：透明档必须带 Symbolizer（XSD 校验）＋ SLD 上传必须声明 charset=UTF-8（否则存成 GBK、预览 500）"
description: "对 G2 文档 b0122682 的三点更正与新坑：空 Rule 能渲染但过不了 SLD 1.0.0 XSD（REST PUT 不校验、界面「验证」才拦）；三组 SLD_BODY 单变量对照证明 fill-opacity=0 一直有效，灰网真凶是 stroke-width=0 被当发丝线；中文 SLD 上传缺 charset=UTF-8 会按平台默认 GBK 存盘导致图层预览 500，附诊断与复查命令、注释会被 GeoServer 丢弃。"
status: "active"
created_at: "2026-11-01T09:23:24.475Z"
updated_at: "2026-11-01T09:23:24.475Z"
content_hash: "f52e51d8d972f12916620e01eb835c42173f71681345e6666e84aabd73c2e4bd"
source_paths:
  - "styles/grid_total.sld"
  - "FE/docs/roadmap.md"
session_ids:
  - "2ba491a9-d535-4ede-b906-bafc80efcc6a"
memory_body_ids:
  []
---

# G2 更正与补充（2026-11-01 当日实测推翻前文结论）

前置实施记录：`b0122682-e16e-45ff-b016-93a348f4ef9e`（G2 的 7 条 Rule、分档、
REST 发布步骤、验收判据）。**其中「坑 1」的因果判断与「正解」是被本文否定的**，
请以本文为准；分档设计、配色、拆档逻辑、发布命令仍按前文执行。
分档口径（相对全市均值、800m 圆 vs 格子面积 8 倍陷阱）见
`7e3e84a2-3ab6-4682-9580-62fa711654a3`。
仓库文档 `FE/docs/roadmap.md` §2.4.11 已同步为更正后的版本。

## 1. 更正一：空 `<Rule>` 能渲染，但过不了 SLD 1.0.0 的 XSD

「该档 Rule 里一个 Symbolizer 都不写」在前文被当作真透明正解。实际：

```
line 55: cvc-complex-type.2.4.b: 元素 'Rule' 的内容不完整。
         应为 '{MinScaleDenominator, MaxScaleDenominator, Symbolizer}' 之一
```

**XSD 要求每条 Rule 至少含一个 Symbolizer。** 空 Rule 只是恰好被渲染器容忍。

| 操作 | 是否校验 XSD |
|---|---|
| REST `PUT/POST` 上传样式 | **不校验** → 能存、能渲染，问题被掩盖 |
| 界面「验证」按钮 | **校验** → 直接拦下 |

**教训：REST 上传成功 ≠ 样式合法。** 只验渲染会在用户点「验证」时才暴露。

## 2. 更正二：`fill-opacity=0` 一直是有效的；灰网真凶是 `stroke-width=0`

前文归因为「只给 fill-opacity 不给 fill 色 → GeoServer 回退默认灰」。用 WMS 的
`SLD_BODY` 参数做**三组单变量对照**（不污染已发布样式），抽格子中心像素 alpha：

| 变体 | 写法 | 中心像素 |
|---|---|---|
| A | 空 Rule（无 Symbolizer） | `(255,255,255,0)` 透明 |
| B | Fill 有色 + `fill-opacity=0`，无 Stroke | `(255,255,255,0)` 透明 |
| C | Fill 只给 `fill-opacity=0` + `Stroke width=0` | `(255,255,255,0)` 透明 |

三组全透明 → 填充从来不是问题。**灰网格来自 `stroke-width=0`：渲染器当成「发丝线」**，
39,820 个格子各描一圈，格子只有约 3 px 宽 → 视觉上是一层灰网。

**现行正解（合法 + 透明 + 不变色）**：给一个真透明 Symbolizer，**绝不写 `<Stroke>`**。

```xml
<PolygonSymbolizer>
  <Fill>
    <CssParameter name="fill">#ffffff</CssParameter>
    <CssParameter name="fill-opacity">0</CssParameter>
  </Fill>
</PolygonSymbolizer>
```

改后重渲染与原图 **sha256 相同**（131,216 bytes）→ 视觉零变化，只是 Schema 合法了。
本地自检脚本输出应为：每条 Rule `symbolizers=1 stroke=0`，「缺 symbolizer 的 Rule 数: 0」。

## 3. 新坑：中文 SLD 上传缺 `charset=UTF-8` → 存成 GBK → 图层预览 500

症状（图层预览打不开，返回 WMS 异常 XML）：

```
java.lang.reflect.UndeclaredThrowableException
org.xml.sax.SAXParseException; lineNumber: 3; columnNumber: 18;
1 字节的 UTF-8 序列的字节 1 无效。
```

**一条命令定性**：下载服务器上那份 SLD，分别按 GBK 与严格 UTF-8 解码。

- 盘上源文件 9,207 字节，**严格 UTF-8 解码通过**；
- 服务器上的 8,639 字节，严格 UTF-8 失败，**按 GBK 解码中文完全正常** → 内容没错，编码标签对不上；
- 对照组 `poi_icons` 存在服务器上**是合法 UTF-8** → 排除「GeoServer 不支持中文」。

**根因**：`Content-Type` 只写 `application/vnd.ogc.sld+xml`，没带 `charset`，GeoServer 用
**平台默认编码**（中文 Windows = GBK）解码请求体。XML 头声明 `encoding="UTF-8"` 而字节是 GBK，
解析器读到第 3 行第一条中文注释就崩（正是报错里的 lineNumber 3）。

**修复**：上传/更新一律显式声明 charset（认证按本机实际值填，凭据不入仓库）。

```powershell
Invoke-WebRequest "http://localhost:8080/geoserver/rest/workspaces/wuhan/styles/grid_total" `
  -Method PUT -Headers @{ Authorization = "Basic $b" } `
  -ContentType "application/vnd.ogc.sld+xml; charset=UTF-8" `
  -Body ([IO.File]::ReadAllBytes("<repo>\styles\grid_total.sld"))
```

**改完立刻复查编码**（能提前发现 GBK 问题，别等到预览 500）：

```powershell
Invoke-WebRequest ".../rest/workspaces/wuhan/styles/grid_total.sld" -Headers @{ Authorization = "Basic $b" } -OutFile "$env:TEMP\chk.sld"
$bytes = [IO.File]::ReadAllBytes("$env:TEMP\chk.sld")
$enc = New-Object Text.UTF8Encoding($false, $true)
try { $null = $enc.GetString($bytes); "UTF-8 OK" } catch { "存成别的编码了" }
```

**通用化**：Windows 上任何「含中文 + 上传到服务端」的请求（SLD、JSON、XML）都显式写
`charset=UTF-8`；本地测好换台机器就炸，通常就是平台默认编码变了。界面「保存」这条
multipart 路径可能同样落成 GBK → **界面只用来看和验证，改动走 REST**。

## 4. 附带结论

- **GeoServer 不保留 SLD 注释**：存储版 6,255 字节 vs 源文件 9,207 字节，解析后重新序列化，
  中文注释全丢。**仓库里的 `styles/grid_total.sld` 是唯一可读真源**，服务器上那份是编译产物；
  改样式要改仓库文件再 PUT。
- **定位渲染问题的方法论**：一次只改一个变量；用 `SLD_BODY` 做对照实验避免污染已发布样式；
  抽像素 alpha 判透明，不靠肉眼看图猜测。本次因同时改了 fill 色与 stroke 宽，导致错误归因、白改一轮。
- G3 四个分类样式（`grid_school` / `grid_hospital` / `grid_mall` / `grid_park`）换字段名即可，
  但 `r_park` 分布不同（全市零值率高、max 明显偏低）**必须单独定阈值**，直接套
  `[0.2, 1, 3, 10, 25]` 会一片深绿。
