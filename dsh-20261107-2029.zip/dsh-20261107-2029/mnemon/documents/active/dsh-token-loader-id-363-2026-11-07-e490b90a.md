---
id: "e490b90a-8378-40bc-b4e5-5bc7969c1302"
title: "DSH 工具 token 预算审计：工具→插件 loader id 归属表与闲置工具实测（363 会话，2026-11-07）"
description: "对 DSH Desktop 当前 111 个工具做 token 成本 × 使用频次审计的完整方法与结果：从会话历史 JSONL 统计调用次数（363 会话 / 24,721 次调用），把 111 个工具逐个映射到 loader id，得出「零使用工具占 47.8% token」的结论；含 web-ui-task-board / code-index / dsh-experimental-schedule-bundle / dsh-base 内置行 的 id 对照、按行 disabled 的粒度差异、以及 mcp-windows --exclude-tools 的待验证点。"
status: "active"
created_at: "2026-11-07T12:13:00.865Z"
updated_at: "2026-11-07T12:13:00.865Z"
content_hash: "07981be69d66400184c4cda3ef07e380b88446e7ee701890f0c0e85e39eb7b43"
source_paths:
  - "tmp_report.mjs"
  - "tmp_owner.mjs"
  - "tmp_ana.mjs"
session_ids:
  - "b3fd5009-96d5-4462-8afc-6cac5506e1db"
memory_body_ids:
  []
---

# DSH 工具 token 预算审计（2026-11-07）

目的：回答「哪些插件/内置行值得留」。做法是把**工具的真实调用频次**和**每步注入的 schema token**对齐，而不是按插件数量或主观印象裁。


## 1. 方法（可复用）

1. 解析本机会话历史 JSONL（`~/.dsh` 下 profiles/sessions），统计工具名 → 调用次数、最后使用日期、近 7 天次数。本次样本：**363 个会话（2026-10-06 起）、24,721 次工具调用**。
2. 取当前工具列表并估算每个工具的 schema token 成本，得到「每步注入总量」。
3. 把工具名映射回 **loader id**（`cordis.patch.yml` 里的 `- id:`），才能知道「关哪一行、少哪些工具、丢什么 UI」。
4. 交叉对比：零调用 + 高 token 的是候选；高频 + 高 token 的是绝不能动的。

结论：**111 个工具 ≈ 23,735 token/步；其中一次没被调用过的工具合计 11,345 token ≈ 47.8%。**


## 2. 工具 → 插件归属实测结果

| loader id | 工具数 | token | 近 7 天 | 备注 |
|---|---|---|---|---|
| `mcp-windows`（patch insert 的 MCP server） | 21 | 4,055 | 543 | 高频，天天用 |
| `dsh-mnemon` | 17 | 3,698 | 310 | 高频 |
| `web-ui-task-board` | 8 | 3,431 | 0 | 总调用 3 次，最后 10-28 |
| `web-ui-task-board-github` | 9 | 1,800 | 0 | **0 次调用** |
| `code-index`（`dsh-code-index`） | 7 | 1,543 | 0 | **0 次调用** |
| `schedule`（实验 bundle） | 4 | 1,425 | 0 | 总调用 1 次 |
| `bridge-browser` | 15 | 1,286 | 420 | 高频 |
| `tool-subagent*`（内置） | 5 | 952 | 0 | 6 次，全在 10-28 前 |
| `tool-pwsh`（内置） | 1 | 888 | 4,092 | 11,756 次，工作流命脉 |
| `tool-workflow`（内置） | 1 | 876 | 0 | **0 次** |
| `tool-fs`（内置） | 4 | 698 | 3,383 | 10,170 次 |
| `dsh-context7` | 2 | 480 | 5 | |
| `tool-goal`（内置） | 3 | 447 | 0 | 2 次，10-06 |
| `tool-fs-search`（内置） | 2 | 375 | 167 | 241 次 |
| `tool-ask-user`（内置） | 1 | 323 | 13 | |
| `tool-jobs`（内置） | 3 | 298 | 82 | |
| `modlens`（`@liustack/modlens`） | 1 | 239 | 1 | 给纯文本模型补视觉 |
| `tool-todo`（内置） | 1 | 221 | 20 | |
| `present`（UI 工具） | 1 | 201 | 17 | |
| `tool-web`（内置） | 2 | 146 | 11 | |
| `plan-mode`（内置） | 1 | 122 | 0 | `exit_plan_mode` 0 次 |
| `tool-skill`（内置） | 1 | 86 | 0 | 11 次 |

单工具最贵的（全部零使用）：`task_board_create` 933、`workflow` 876、`schedule_create` 692、`schedule_update` 617、`task_board_github_repositories` 484、`task_board_manage` 432、`code_change_context` 394。


## 3. 各类插件的 loader id 从哪来

- **聚合包子路径**：`@linxin666/dsh-web-all` 的 `cordis.patch.yml`（`scripts/aggregate.mjs` 生成）一次插入 19 条子行，`web-ui-task-board` / `web-ui-task-board-github` 就在其中。插件页显示成 `web-all/task-board` 这种子行。
- **实验 bundle**：`@deepseek-ai/dsh-experimental-schedule-bundle/cordis.patch.yml` 插入三行 —— `time-context`（`@deepseek-ai/dsh-time-context`）、`schedule`（`@deepseek-ai/dsh-schedule`）、`ui-schedule`（`@deepseek-ai/dsh-client-ui-schedule`）。该文件注释说明 Schedule 服务自己拥有任务存储，并把每次到点投递成原 Session 的 follow-up。
- **DSH 自己装的包**：`node_modules/dsh-schedule/lib/index.js` 影响的是另一处；profile 的 `cordis.patch.yml` 才是本层写 `disabled: true` 的地方。
- **内置行**：`tool-workflow`、`tool-subagent`、`tool-subagent-fork`、`plan-mode`、`tool-goal`、`tool-skill` 这些 id 都在 `@deepseek-ai/dsh-base` 的 `cordis.patch.yml` 里（实测 id 存在），内置工具默认随 bundle 全量加载。
- **Desktop 宿主层**：`app/cordis.patch.yml` 插入 `desktop-shell`（`mode: compatibility`）、`desktop-terminal`（linux 下 `!!js` 禁用）、`desktop-diagnostics`、`desktop-notifications`、`desktop-pnpm`、`desktop-profiles`、`desktop-updates`，并把 `web-runtime` 的 `openBrowser` / `printUrl` 关掉、`surfaceContext: true`。
- `dsh-mnemon` 的工具分两处注册：`index.js` 12 个 js 里注册 17 个工具（含 `mnemon_memory_body_*`、`mnemon_forget`、`mnemon_link`），`client.js` 里另有 7 个（`mnemon_document_*` / `mnemon_recall` / `mnemon_related` / `mnemon_runtime_memory` / `mnemon_status`）。


## 4. 粒度陷阱（关之前必读）

- `schedule` 与 `ui-schedule` 是**两行**：只关 `schedule` 会保留侧栏「自动化任务」页面，但模型侧 `schedule_*` 工具消失。
- `tool-subagent` 一行同时带走 `subagent` 和 `subagent_fork`，关掉后并行干活只能串行。
- `code-index`（`dsh-code-index`）没有侧栏页，只有设置卡，`code_*` 7 个工具零使用，是「关掉不损失 UI」的一类。
- `web-ui-task-board` 关掉会消失侧栏「任务看板」入口（本人只点过 3 次，10-28 之后没碰）。
- `dsh-context`（UI 入口）、`dsh-better-sidebar`（UI 入口）与 `dsh-code-index` / `dsh-context7` / `modlens` / `dsh-cost-meter`（纯工具/设置）是两种东西，判断时要区分有没有界面收益。


## 5. mcp-windows 的进一步压缩（待验证）

启动参数当前是 `args: ['serve', '--exclude-tools', 'PowerShell,Registry,FileSystem']`。21 个工具里 9 个零使用（Scrape 242 / WaitFor 207 / MultiSelect 168 / Notification 152 / MultiEdit 135 / Clipboard 112 / read_mcp_resource 91 / list_mcp_resource_templates 89 / list_mcp_resources 82），理论上追加约省 1,016 token。

**但这个必须实测**：`--exclude-tools` 认的是 windows-mcp 上游的原始工具名，名字写错可能启动失败或静默无效。建议一次只加一个（如 `Notification`），重启后核对工具表是否真的少了。


## 6. 状态

以上为分析与建议，**用户尚未确认执行**。此前已关闭的 anysearch / video / agnes（≈11,262 token）属于同一条优化线。若按「零使用即关」全量执行，本步 token 可从 23,735 压到 ~13,347 量级。

相关文档：
- `b553f318-107d-447d-b48c-ac9962002c70` —— task_board / windows 为何不出现在插件页与插件市场，及三条 `disabled: true` 接线
- `629e2f6a-92c3-400d-ba7f-777d7d432f4b` —— Windows-MCP 接入实录：patch 层必须用 `- insert:`、`--exclude-tools` 裁剪、遥测双保险
