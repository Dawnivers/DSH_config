---
id: "564a4172-29af-4a5a-a5a8-87b0a8821d51"
title: "缓冲圈在 3857 下画小 14%（投影米≠地面米）+ 面-面叠加必须 ST_Intersection 而非 ST_Union（含格网分析为何用 Union）"
description: "两条 GIS 计量口径的根因与修法：①OpenLayers 缓冲圈 new Circle 用投影米，须除 cos(纬度) 才等于 ST_DWithin(geography) 的地面米（武汉 φ30.6° 偏小14%，哈尔滨偏小30%，提交 b84f352）②叠加分析求重合必须 ST_Intersection，ST_Union 是并集；同时解释 02_build_grid_500m.sql 用 ST_Union(admin_area) 只为合并成整体再 ST_Intersects 留格、ST_Extent 取外包框（Union 冗余），附 geography/面积/索引四个坑。"
status: "active"
created_at: "2026-11-02T07:52:30.195Z"
updated_at: "2026-11-02T07:52:30.195Z"
content_hash: "0690689430013a2cdcc1f157504b971257f5eb4fa51b263ad5b7e1060b4362d8"
source_paths:
  - "FE/src/map/drawing.js"
  - "FE/src/map/probe.js"
  - "FE/src/map/hover.js"
  - "FE/src/view/mapView.vue"
  - "02_build_grid_500m.sql"
session_ids:
  - "688f8974-e5a8-4787-b979-4dfbca785349"
memory_body_ids:
  []
---

# 两个「米」的口径问题：缓冲圈画小 与 Union/Intersection 之辨

提交：`275525c → b84f352  14 修缓冲圈画小了`。

相关文档（勿重复实现，只引用）：

- `c4bebf46-a1f6-4e75-86bc-00c43548edb2`：D13 绘制工具改版，缓冲圈「看不见」的真因（像素尺寸）+ 自动拉镜头到 z14，本文是它的续篇（圈画小了≠圈看不见）。
- `b4346af9-bbcb-47b6-b128-5f360391455d`：F4 点格弹窗，分析/热力互斥、进分析关热力亮 POI。

## 1. 缓冲圈：Web Mercator 的「米」不是地面米

**症状**：半径 650 m 的附近分析，后端返回的若干设施（地面距离 606 m、626 m）在列表里命中，却落在画出来的圆外。

**根因**：

```
后端 ST_DWithin(geom::geography, 圆心, 650)  → 地面米（球面真实距离）
前端 new Circle(center, 650)                  → 投影米（EPSG:3857 单位）
```

等角投影局部缩放因子恒为 `1/cos(φ)`，故 `地面半径 = 投影半径 × cos(φ)`：

| 城市 | φ | cos φ | 旧代码 650 m 圈的真实半径 | 偏差 |
|---|---|---|---|---|
| 武汉 | 30.6° | 0.861 | ≈ 560 m | 小 14% |
| 哈尔滨 | 45.8° | 0.697 | — | 小 30% |
| 三亚 | 18° | 0.951 | — | 小 5% |

用截图里 4 个设施反算（地面距离 → 投影距离），完全对上：406 m→471.4（内）、519 m→602.7（内）、606 m→703.7（外）、626 m→726.9（外）——「前两个在圈里、后两个在圈外」正是截图所见。**后端从来没有算错**。

**修法**（`FE/src/map/drawing.js` 的 `paintCircle`）：

```js
// ★ 3857 是等角投影：地图上的 1 米 ≠ 地面 1 米，差 1/cos(纬度)
const mapRadius = radius / Math.cos((center.lat * Math.PI) / 180);
geometry: new Circle(c, mapRadius)   // 754.8 投影米 × 0.8612 = 650.0 地面米
```

仍是正圆而非椭圆：等角投影在一点上各方向比例相同。若换等积投影就必须改用测地线多边形。

**为何长期没被发现**：半径小时肉眼无感（200 m 画成 172 m）；只有贴近边缘的要素才露馅；后端数字、列表、CSV 全是地面米，只有那张图偏了。**排查心法：地图上画的距离与 geography 算的距离混用时，一律先问「这个米是哪个米」。**

**同批核查结论**：只有缓冲圈踩坑。测距 `getLength`、面积 `getArea`（均来自 `ol/sphere`）是球面米，正确；点击/悬停容差是像素，与投影无关。

## 2. 面-面叠加：叠 = 求交，不是求并

用户曾问「面-面叠加用的是 ST_Union 吗」——**不是**。`ST_Union` 是并集（「至少被一个圈覆盖」），叠加分析要的是交集（「同时被两个圈覆盖」）。以 A 覆盖 {1,2,3,4,5}、B 覆盖 {4,5,6,7} 为例：

| 算子 | 结果 | 回答 |
|---|---|---|
| `ST_Union` | {1..7} | 任一圆覆盖，面积变大（花生形） |
| `ST_Intersection` | {4,5} | **都覆盖**，面积变小 ← 叠加 |
| `ST_Difference` | {1,2,3} | 只被 A 覆盖 |
| `ST_SymDifference` | {1,2,3,6,7} | 只被一个覆盖 |

### 标准三步（本项目 `wuhan:admin_area` 为面）

```sql
WITH c1 AS (SELECT ST_Buffer(ST_SetSRID(ST_MakePoint(:lon1,:lat1),4326)::geography, :r1)::geometry AS geom),
     c2 AS (SELECT ST_Buffer(ST_SetSRID(ST_MakePoint(:lon2,:lat2),4326)::geography, :r2)::geometry AS geom),
     ov AS (SELECT ST_Intersection(c1.geom, c2.geom) AS geom FROM c1, c2)
SELECT a.name,
  round((ST_Area(ST_Intersection(a.geom, ov.geom)::geography)/1e6)::numeric, 3) AS overlap_km2,
  round((ST_Area(a.geom::geography)/1e6)::numeric, 3)                           AS area_km2,
  round((ST_Area(ST_Intersection(a.geom, ov.geom)::geography)
       / NULLIF(ST_Area(a.geom::geography),0) * 100)::numeric, 1)               AS pct,
  (SELECT count(*) FROM poi p WHERE ST_Contains(ST_Intersection(a.geom, ov.geom), p.geom)) AS poi_cnt
FROM admin_area a, ov
WHERE ST_Intersects(a.geom, ov.geom)
ORDER BY overlap_km2 DESC;
```

`圆1 ∩ 圆2 = 叠加区域` 这一步不能省：若分别做 `圆1∩街区`、`圆2∩街区` 再按 id 求交，一个街区一半在圆 1、一半在圆 2（两半并不重合）也会被误判为「在两个圈里」，且算不出真正的重合面积。写成 `ST_Union` 则结果几乎命中全部街区、比例恒为 1.0，等于功能没做。

### 四个必踩的坑

1. `ST_Area(geom)` 单位是「平方度」，必须 `::geography`；且返回 `double precision`，`round(dp,int)` 不存在，要 `::numeric`。
2. `ST_Buffer` 在 4326 下半径单位是**度**（800 度包住地球），必须 `geom::geography`。与 §1 是同一个病。
3. 先 `WHERE ST_Intersects(a.geom, ov.geom)` 走 bbox 索引再算 `ST_Intersection`；相交为空时 `ST_Intersection` 还会返回空 GEOMETRYCOLLECTION。
4. 结果可能是 MultiPolygon 或空几何：渲染前 `ST_IsEmpty` 过滤、`ST_CollectionExtract(...,3)` 只取 Polygon。

### Union 的正用：服务覆盖合并、外轮廓、避免重复计数

`ST_Union` 后 `ST_Boundary` 画整体外轮廓；四所学校合并覆盖范围；先 Union 再 `ST_Area` 避免重叠区被算两遍。

## 3. 那格网分析为何第一步 `ST_Union(admin_area)`？

用户追问：既然 Union 是并集，`02_build_grid_500m.sql` 为何 `ST_Union` 后求外接矩形？——**它算的仍是并集**，能用是因为「并集的包络框 ≡ 所有元素的包络框」：`min/max` 对并集封闭，所以 `ST_Extent(ST_Union(区)) ≡ ST_Extent(区)`，**这一步的 Union 是冗余的**（且贵）。

脚本骨架与各步定位：

```
WITH area AS (SELECT ST_Union(geom) FROM admin_area),        -- ① 13 区合成一个整体（纯合并）
     ext  AS (SELECT ST_XMin(ST_Extent(geom)) … FROM area),  -- ② 外包框，决定格网铺多大
     grid AS (ST_MakeEnvelope(x, y, x+0.0045, y+0.0045, 4326) 密铺)
SELECT … FROM grid g
WHERE ST_Intersects(g.geom, (SELECT geom FROM area));        -- ④ 这里才是「求交」
```

- ③/④ 的 `ST_Intersects(格, 合并面)` 是求交，用来滤掉落在武汉外与区界空隙的格子。39,820 格 × 13 区 = 517,660 次判断，合并后 39,820 次——**这才是 Union 不可省的理由**。
- 对 13 个互不重叠的区逐个求交，结果是空几何，所以「用交集求外包框」根本不成立：交集输出的是**面**，`ST_Extent` 输出的是**框**，是两个不同运算。
- 注意 `ST_Extent` 返回 `box2d` 而非 geometry，不能直接喂 `ST_MakeEnvelope`，故脚本里要拆 `ST_XMin/ST_YMin/ST_XMax/ST_YMax`。

**一句话**：Union 是「先合成整体」的原料，Intersects 才是答案；叠加分析里要重合面积，就用 Intersection。

## 4. 待办

上述 §1 的换算表与教训，用户被问过「要不要补进 `FE/docs/roadmap.md`」，尚未确认落笔；若写入，建议同时补一个「第三个图层渲染重合区（`ST_Intersection` 结果可直接作 WMS 图层）+ 面积/占比/POI 数统计表」的展示方案。
