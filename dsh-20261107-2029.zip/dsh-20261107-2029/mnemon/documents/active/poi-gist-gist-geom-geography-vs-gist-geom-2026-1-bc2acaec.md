---
id: "bc2acaec-977c-4d6e-bd0d-f898e351ff5e"
title: "poi 表两套 GiST 索引的分工：表达式索引 GIST((geom::geography)) vs 列索引 GIST(geom)（2026-11-04 修正）"
description: "修正旧文档「GIST(geom) 用不上已删除」的错误结论：同一 poi 表按谓词形态需要两个互不替代的空间索引（ST_DWithin 用表达式索引、ST_Within/ST_Contains 用列索引），含实测收益、验证方法与 roadmap/README 的落点。"
status: "active"
created_at: "2026-11-04T11:08:01.935Z"
updated_at: "2026-11-04T11:08:01.935Z"
content_hash: "a7ad6a3552f957ac65316ce63406e109523a67ffbbf2df8887927284b2adb174"
source_paths:
  - "serviceAnalysis/FE/docs/roadmap.md"
  - "serviceAnalysis/README.md"
  - "serviceAnalysis/BE/src/main/resources/mapper/PoiMapper.xml"
session_ids:
  - "f04f76c2-510a-4420-b72b-71dde23bdf8a"
memory_body_ids:
  []
---

# poi 表两套 GiST 索引的分工（2026-11-04 修正）

## 1. 被推翻的旧结论

项目 roadmap 原先写着：

> 「早先误建的 `idx_poi_geom_gist ON poi USING GIST (geom)` **用不上**，已删除。」

2026-11-04 接入路网等时圈（isochrone）与面级叠加（overlay）时**又把 `GIST(geom)` 建回来了**。
旧结论只对一半：它成立的范围仅是「`/nearby` 那条用 `geom::geography` 做距离筛选的查询」，被误推广成了「所有查询」。

## 2. 正确结论：按谓词形态选索引，二者互不替代

| 索引 | 定义 | 服务哪个谓词 / 接口 | 单位 |
|---|---|---|---|
| `idx_poi_geog` | `GIST ((geom::geography))` | `ST_DWithin(geom::geography, …)` → `/api/poi/nearby` | 米（geography） |
| `idx_poi_geom_gist` | `GIST (geom)` | `ST_Within(p.geom, 面)` / `ST_Contains(面, p.geom)` → `/api/poi/isochrone`、`/api/poi/overlay*` | 度（4326 平面） |

关键点是 PG 的索引匹配**看表达式而不是看列**：`ST_DWithin(geom::geography, …)` 里的几何已经被转成 geography 表达式，
`GIST(geom)` 在这个谓词上用不上；反过来面内筛选用的是原始 `geom`，`GIST((geom::geography))` 同样用不上。
所以「一个表一个空间索引」在这个 schema 上不成立。

写法注意事项（roadmap §10.1 已记录）：

- 表达式索引必须写成双括号 `((geom::geography))`，少一层直接语法错。
- 列索引就是普通 `GIST (geom)`，不要照抄双括号。

## 3. 实测收益（poi 16016 行，2026-10-27 / 11-04 两次测量）

`/nearby` 口径（圆心 `114.36, 30.54`，800 m，`order by "distanceM" limit 5`）：

| 指标 | 建 `idx_poi_geog` 前 | 建后 |
|---|---|---|
| 执行计划 | `Parallel Seq Scan` | `Bitmap Index Scan on idx_poi_geog` |
| 执行时间 | 88.4 ms | **23.9 ms** |
| `Buffers` | 4758 | **200** |
| `cost` | 88388 | 1629 |

面内筛（isochrone / overlay 里 `ST_Within` 那一层）从**分钟级降到毫秒级**——这是 11-04 复建 `GIST(geom)` 的直接动因。

## 4. 为什么必须把这段修正掉，而不是留旧文

文档写「`GIST(geom)` 用不上、已删除」，下一个接手的人会照着文档把索引删掉，
结果等时圈与叠加分析重新退回分钟级，而且**没有任何报错**（只是慢），极难归因。
凡是「某索引没用」这类结论，必须连谓词一起写，否则就是把一次局部测量的结论当成了全局事实。

## 5. 验证方法（换机器部署后照此自查）

```sql
-- 1) 两个索引都在
SELECT indexname FROM pg_indexes WHERE tablename = 'poi';

-- 2) 谓词是否真的走索引：EXPLAIN 里应出现对应索引名
EXPLAIN ANALYZE SELECT gid FROM poi
  WHERE ST_DWithin(geom::geography, ST_Point(114.36,30.54)::geography, 800);   -- 期望 idx_poi_geog
-- 面内筛的 EXPLAIN 期望 idx_poi_geom_gist（surface 为任意 WKT 面）
```

## 6. 记录落点

- 权威表述在仓库内：`serviceAnalysis/FE/docs/roadmap.md` §10.1（表达式索引）+ **§10.1b（2026-11-04 补，`GIST(geom)` 索引，等时圈/叠加必需）**，另有一张「索引 ↔ 谓词」对照表。
- 面向读者的能力说明在 `serviceAnalysis/README.md`（第 3 节路网等时圈、第 6 节 overlay-network）。
- 索引改动随 commit `1f49768`（接入路网等时圈）落地；文档修正随 `54d92cd` 到远端 `origin/main`（`https://github.com/Dawnivers/ServiceAvailable.git`）。

## 7. 关联文档

- `8559b1b5-4a02-4f6c-b55c-2c6fa692c1dc`：overlay-network 改为路网口径的实现细节（本索引服务于它的面内筛）。
- `acb716e0-90da-4a84-a8a3-36a77603a58c`：等时圈 vs 全城格网的口径取舍与 pgRouting 环境核对。
- `266aea70-7a25-4d94-8359-39555b8b651f`：项目整体架构设计（其中 §3 数据层当时只写「三张表均建 GiST(geom)」，与本修正不冲突但不够细）。
