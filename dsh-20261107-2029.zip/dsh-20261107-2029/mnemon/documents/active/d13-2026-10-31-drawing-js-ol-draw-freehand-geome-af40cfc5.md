---
id: "af40cfc5-8af4-4ba1-ac1f-ea2990af3a42"
title: "D13 绘制工具落地（2026-10-31）：drawing.js 四工具、OL Draw「非手绘模式拖拽必放手」源码根因与 freehand+geometryFunction 解法、WKT 端到端验证"
description: "框选画不出框且地图被拖走的根因（ol/interaction/Draw.js handlePointerMove_ 中非手绘分支 squaredDistance <= tolerance 才接管）与解法（freehand:true + geometryFunction 压外接矩形）；drawing.js 的 5 方法纯回调 API、四种工具的交互与产出、CDP probe 排错套路、端到端 within 校验数据、后续 AnalysisResult 待办。"
status: "active"
created_at: "2026-10-31T08:15:44.391Z"
updated_at: "2026-10-31T08:15:44.391Z"
content_hash: "1ee6615a1266e7fb426aaee81a94e50c9e8222d5f9b85515f761fd9b6b96ea8d"
source_paths:
  - "FE/src/map/drawing.js"
  - "FE/src/view/mapView.vue"
  - "FE/src/stores/analysis.js"
  - "FE/src/components/AnalysisToolbar.vue"
  - "FE/src/map/wms.js"
  - "FE/docs/roadmap.md"
session_ids:
  - "837ffde6-38fc-4a38-a251-a720b80ed391"
memory_body_ids:
  []
---

# D13 绘制工具落地（2026-10-31）

承接 D13 分析模式的入口/灰化/口径三项（见 `81c93b00`、`c8394c90`、`b14cafea`）。本文只记录**绘制交互**这一层的实现、一个必须记住的 OpenLayers 行为坑，以及端到端校验数据。

## 1. 产出与接口形态

新增 `FE/src/map/drawing.js`（约 330 行），对外仅 5 个方法：

```
setTool(tool, callbacks)   setRadius(m)   setCenter({lon, lat})   getPolygon()   destroy()
```

设计约束：**不 import 任何 store**，只通过 `onPoint / onPolygon / onMeasure` 回调上报；与 `LayerPanel` 的"纯展示"思路一致，地图对象与业务状态解耦。`mapView.vue` 负责把回调接到 `stores/analysis.js`。

| 工具 | 交互 | 产出 |
|---|---|---|
| 点选 `point` | 单击 | 中心点 + 红色虚线缓冲圈，圈上标注「缓冲区 800 m」 |
| 自由绘制 `freehand` | 按住拖 | 任意多边形，标注面积 |
| 框选 `rect` | 按住拖 | 外接矩形，标注面积 |
| 测距 `measure` | 连点、双击结束 | 折线，标注长度 |

统一红色 `#d93025` + 半透明填充，标签红底白字。

## 2. ★ 核心坑：`type: 'Circle'` + `createBox()` 拖拽画不出框，还会把地图拖走

这是 OL 官方文档教的"拖拽画矩形"写法。实测现象：框不出现，地图被平移，`store.geometry` 始终为 `null`，且**没有任何异常**。

根因在 `ol/interaction/Draw.js` 的 `handlePointerMove_`：

```js
this.shouldHandle_ = this.freehand_
  ? squaredDistance > this.squaredClickTolerance_    // 手绘：移动就接管
  : squaredDistance <= this.squaredClickTolerance_;  // 非手绘：移动超容差就主动放手
```

即**非手绘模式下，指针一移动超过点击容差，Draw 就把事件让出去**，落到 `DragPan` → 表现为平移地图。官方示例能成立是因为它的交互是"点一下、再点一下"（两次单击定对角），而不是按住拖。

### 解法：让框选也走手绘通道，再用 geometryFunction 把轨迹压成矩形

```js
new Draw({
  source,
  type: 'Polygon',
  freehand: true,
  freehandCondition: () => true,
  geometryFunction: createBoxFromDrag(), // boundingExtent → 5 点闭环
})
```

手绘模式一定接管拖拽，几何则由 `geometryFunction` 决定，视觉上仍是"拖出一个框"，符合直觉。自定义的 `createBoxFromDrag` 只取首末两个坐标做 `boundingExtent`，比 OL 自带 `createBox()`（同样取首末坐标）更适合连续拖拽。

**可迁移的判据**：凡"按住拖"的绘制（框选、擦除、手绘）都应走 `freehand: true`；凡"多次单击"的绘制才用非手绘模式。想在非手绘模式下改 `geometryFunction` 是绕不过去的，问题不在几何函数而在接管条件。

## 3. 排错路线（这类"无异常、无产出"的问题可复用）

1. **先确认模块与状态层正常**：`import { createBox }` 可解析、`typeof` 为 function；`store.analysis` 字段随工具切换正常变化 → 排除 store/构建问题。
2. **确认交互是否挂上**：列表化 `map.getInteractions()` 的 `constructor.name` / `type` / `freehand` / `freehandCondition` / `active` / 是否有 `geometryFunction`。结论：切到框选后确实有 `Draw + type:"Circle" + active:true + geomFn:"yes"` → 交互在，问题在内部判定。
3. **注入 probe 读私有字段**：读 `drawing.mode_ / downPx_ / shouldHandle_ / sketchCoords_ / finishCoordinate_`。关键观测：按下后 `shouldHandle_` 变 `true`，**第一次移动后变回 `false`** —— 直接指向接管条件，再回源码即可定位。
4. 排错脚本一律放 `FE/_diag-*.mjs` 之类临时文件，**用完删净**，并检查 `mapView.vue` 无 `__dbg` 残留。

附注两处观察：`Draw` 实例的 `overlay_` 在无草绘时 `getElement` 不是函数，探针不要碰它；`Draw.handleMoveEvent` 是空的，拖动逻辑实际在 `handlePointerMove_`，别去 `handleMoveEvent` 里找。

## 4. 验证数据（CDP 派发真实鼠标事件）

```
① 点选  → center {lon:114.368665, lat:30.631569}
② 手绘  → POLYGON, areaKm2=1208.6
③ 框选  → POLYGON, areaKm2=1216.3     ← 修复前为 null
④ 测距  → measure=42486 m
⑤ 半径拖到 1500 → store.radius=1500，圆实时重画
⑥ 切到测距 → center/geometry 自动清空
```

⑤ 与 ① 的坐标完全一致（114.368665），佐证**框选不再把地图拖走**（若仍被拖，view center 会变，映射出的经纬度就会不同）。

### 端到端：画框 → WKT → 后端

```
框选画出 areaKm2=663.61
WKT: POLYGON((114.20386962890623 30.48966566600751, ...))   已是 EPSG:4326
GET /api/poi/within?wkt=... → 200 / 255ms
count 8162 = school 2107 + hospital 3032 + mall 2406 + park 617   ✓ 自洽
后端 ST_Area 662.94 km²（与前端差 0.1%，球面近似所致，非 bug）
```

这条链路跑通意味着**接结果面板时不需要再动绘制代码**，前端只需消费已有的 WKT。

## 5. 顺手处理的三件事（都容易复发，记下来）

1. **分析模式下点地图不再打开 POI 详情卡**：那一下点击是"选分析中心"，不是"看设施"。
2. **切工具自动清掉上一个工具的图形**（`analysis.clearSketch()`），避免地图上叠加残留要素。
3. **拖半径滑杆时圆实时重画**：先删旧的 `circle` / `center` 要素再画新的，否则会叠出一堆同心圆。

另：分析图形层**故意不挂 `ol-layer-base`**（灰化类），所以 D13 的"底图+注记+区划去色"不会波及分析图形与标签——新增图层时不要顺手统一挂类名。

## 6. 构建与清理

`vite build` 254 modules（较上一轮 +43，引入 Draw/Vector/format 等依赖），496.94 KB，退出码 0。临时脚本 `_diag-rect.mjs` / `_diag-interactions.mjs` / `_diag-draw-probe.mjs` / `_draw-test.mjs` / `_e2e-within.mjs` 已全部删除，`mapView.vue` 无 `__dbg` 残留。

## 7. 遗留与下一步

绘制有了，但**画完还没有任何数据反馈**——地图上有红框，右侧没有结果卡。

- **Step A** `composables/useBufferAnalysis.js`：画完 / 半径变化 → 自动调 `/api/poi/nearby`（点选）或 `/api/poi/within`（多边形）→ 写 `store.analysis.result`。
- **Step B** `components/AnalysisResult.vue`：右侧结果卡（覆盖数 / 分类占比 / 最近设施列表 / 导出）。

建议顺序：**先 B 后 A**。用 `within` 接口的真实数据先把结果卡架子搭出来，接数据只差一次 fetch；反之 A 做完没有落点，只能翻控制台。导出 CSV 仍受"接口只返回 count/byCategory/nearest"限制（见 `b14cafea` §6），未解决。

## 相关文档

- `81c93b00-c684-4f65-a859-87e533a10776` —— D13 四项优化修正（className 构造参数、灰化量化、CDP 三陷阱）；本篇的"自由绘制"即在该篇补齐
- `c8394c90-f05c-4973-bb3e-be44d6f1e3bf` —— 分析模式进入逻辑落地与 ST_Within 边界口径实测
- `b14cafea-9e0d-4037-97df-74891bdb4b59` —— 入口设计与导出能力遗留
- `FE/docs/roadmap.md` §2.4.0「绘制工具」—— 仓库内的进度版本
