---
id: "aac88bd9-69ac-4d43-8d3e-21de64c49f18"
title: "D13 范围分析选型实测：PostGIS ST_Within vs GeoServer WFS CQL INTERSECTS（2026-10-31）"
description: "为「分析模式」绘制不规则多边形查询范围内 POI 做的两路实测记录：geometry 与 geography 的函数差异、125 条结果三函数一致、小表全表扫描的原因判读、WFS INTERSECTS + resultType=hits 的耗时与传输量、GeoServer 图层缺 gid 主键导致的详情断链，以及 /api/poi/within 接口设计与前端 Draw 的 3857→4326 坑。"
status: "active"
created_at: "2026-10-31T03:17:04.631Z"
updated_at: "2026-10-31T03:17:04.631Z"
content_hash: "c45a738bcf9e7938885d283e9d8877a2c99e6199aac4f2f83cc0417113b4135f"
source_paths:
  - "FE/src/components/PoiDetailCard.vue"
  - "FE/src/components/TopBar.vue"
  - "FE/src/App.vue"
  - "FE/docs/roadmap.md"
  - "FE/src/map/searchPoi.js"
session_ids:
  - "03cd2c9e-bf3a-46a8-a0c0-7b575d9c5b13"
memory_body_ids:
  []
---

## 背景与结论速览

D13 分析模式要支持「地图上画不规则多边形 → 统计范围内的设施」。两条路都实测通过，**建议走 PostGIS 自建接口，不用 GeoServer WFS**。

| | PostGIS 自建接口 | GeoServer WFS |
|---|---|---|
| 改动量 | 新增 mapper/service/controller | 0 改动，前端拼 URL |
| 任意多边形过滤 | ✅ | ✅（CQL `INTERSECTS`） |
| 只要数量 | `select count(*)`，极小 | `resultType=hits` → 512 B / **1249 ms（冷启动，最慢）** |
| 全部数据 | 自己设计结构 | 125 条含几何 = **258.3 KB / 117 ms** |
| 按类别分组 | ✅ SQL `group by` | ❌ 前端自己遍历 |
| 与详情卡 `nearby` 口径一致 | ✅ 同一批 SQL | ❌ 两套数据源 |
| gid 可用 | ✅ | ❌ 见下文陷阱 |

核心理由是**口径一致性**：详情卡「周边设施 27 / 同类最近 191 m / 密度倍数 1.4」全来自后端 SQL；分析模式若换 WFS，会出现「卡片说 27、分析说 125」的现场对质。其次是分组统计与复用 `PoiMapper.xml` 已有写法。

## 1. 函数选择：ST_Within / ST_Contains / ST_Intersects

poi 表有 `geom geometry(Point,4326)`。同一三角形多边形实测三者**结果完全一致，都是 125 条**（点是零面积，Within 与 Contains 同义）。

```sql
select count(*) from poi
where ST_Within(geom, ST_GeomFromText(#{wkt}, 4326));
```

坑：最初写 `ST_Within(geom::geography, poly::geography)` 报 **`函数 st_within(geography, geography) 不存在`**——`ST_Within/ST_Contains/ST_Intersects` 只有 geometry 版本；`::geography` 是 `ST_DWithin` 求米制距离才用的。**多边形判断别加 `::geography`。**

## 2. 性能实测与判读（不要误判为索引坏了）

- `ST_Within` 执行计划为 `Parallel Seq Scan on poi`，Buffers 3876 页，**69 ms**；加 `geom && poly` 粗筛约 54 ms，仍全扫。
- 现有索引：`poi_pkey1(gid)`、`poi_amap_id_key`、`idx_poi_category`、`idx_poi_adcode`、`idx_poi_geog (((geom)::geography))`；另有 `idx_poi_geom`，在 `pg_class` 里 relkind=`i`、`pg_index` 里 indisvalid=true，但 **`pg_indexes` 视图查不到它**（像是事务内建了又回滚/残留）。
- `SET enable_seqscan=off` 后仍 seq scan，小范围 bbox 也仍 seq scan。
- **结论**：表仅 16016 行 / 3876 页，全表扫描比索引回表更快，优化器主动放弃索引，**不是 bug**；几十万行时会自然切换。无需为此改动。

## 3. GeoServer 侧：WFS + CQL INTERSECTS

```
http://localhost:8080/geoserver/wuhan/ows?
  service=WFS&version=1.1.0&request=GetFeature&typeName=wuhan:poi&
  outputFormat=application/json&
  CQL_FILTER=INTERSECTS(geom,SRID=4326;POLYGON((114.35 30.53,114.38 30.52,114.37 30.56,114.35 30.53)))
```

- GetCapabilities 200 / 24559 B，含 `wuhan:poi` 与 `Intersects`；实测 `totalFeatures = 125`，与 PostGIS 一致。
- 只取数量：追加 `resultType=hits` → 512 B 响应体，含 `numberOfFeatures="125"`。

**★ 关键陷阱**：`wuhan:poi` **没有 `gid` 字段**。指定 `propertyName=gid,name,category` 报错：

> Requested property: gid is not available for wuhan:poi. The possible propertyName values are: [amap_id, name, category, typecode, address, adcode, tel, lon, lat, geom, raw, detail, detail_fetched_at, source, fetched_at]

数据库里 `poi` 主键确实是 `gid`（`poi_pkey1 PRIMARY KEY (gid)`），但 GeoServer 建图层时没把它识别成主键。**走 WFS 拿不到 gid 就无法再点开详情**（`/api/poi/{gid}` 只认 gid），需去 GeoServer 后台补主键配置。另：`propertyName` 精简请求返回 0 条 feature（坐标写法有误），排错时先看 XML 里的 `ows:ExceptionReport`。

## 4. 接口设计建议

与现有 `nearby` 并列新增，不替换：

```
GET /api/poi/within?wkt=POLYGON((...))&limit=50
→ { count, byCategory: {school,hospital,mall,park}, nearest: [...] }   // 与 nearby 对齐便于前端复用
```

- MyBatis 必须用 `#{}` 参数化，**绝不用 `${}`**；
- service 层校验以 `POLYGON(` / `MULTIPOLYGON(` 开头，并用 `ST_IsValid()` 预检坏几何；
- `nearby` 只支持圆（`ST_DWithin`），**框选/多边形必须走这条新路径**。

## 5. 前端绘制

`ol/interaction/Draw`（`type: 'Polygon'`），`drawend` 里用 `ol/format/WKT` 写出几何，**必须指定 `dataProjection: 'EPSG:4326'` + `featureProjection: map.getView().getProjection()`**。坑：画布是 3857、后端 geom 是 4326，不转换时 `ST_Within` **返回 0 条且不报错**——最容易卡死在这里。

## 6. 同轮的两处 UI 结论

- `PoiDetailCard.vue` 的「查看详情」按钮已删除（模板 + `.btn.primary`/`:hover` 样式 + 「两个按钮」注释），原因是第一层卡片已直接展示 `raw` 里的详情级字段，按钮唯一用途消失；保留「附近分析」按钮与 `.btn` 基础样式。全仓库无 `查看详情` 残留，`vite build` 208 modules 退出码 0，CSS 17.64→17.50 KB。另记：`detail` / `detail_fetched_at` 两列因 `extensions=all` 已成死字段。
- 分析工具栏「点选 / 框选 / 缓冲区 / 测距」中，**「缓冲区」按钮与下方半径滑杆语义重复，应删按钮留滑杆**；状态只需 `tool: 'point'|'rect'|'measure'`、`radius`、`categories`。`TopBar.vue` 的「分析工具」按钮目前 disabled，`App.vue` 里 `onTool` 只打日志。

## 关联

- 项目总体设计：`266aea70-7a25-4d94-8359-39555b8b651f`
- POI 数据基线 / 几何落区统计须用 ST_Within：`8d2fc1c9-4493-4ece-88e1-59e02ad49c43`
- D12 WFS+CQL 搜索选型与实测：`7c6fa1da-6ad8-429d-b649-1584e973371f`
