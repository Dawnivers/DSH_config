---
id: "23751c42-105d-4f8a-87e0-c697cc184d9a"
title: "双仓库拓扑落地：styles/ 迁入 BE、ServiceAvailable-BE 建仓推送、公开前密钥体检与相对链接层级坑（2026-11-01）"
description: "openlayers 服务平台开发的版本控制结构决策与操作记录：为何 styles/（GeoServer SLD）归属后端仓库、无 gh CLI 时用 GCM 凭证调 GitHub API 建仓的流程、master→main 改名、推公开仓库前的密钥体检清单与结果、FE/docs 到项目根是两层的链接层级坑及全链接验证方法、etl/mock/data 仍未版本化的三个待选方案。承接 SLD 实现文档 b0122682 / ac533754。"
status: "active"
created_at: "2026-11-01T09:37:35.089Z"
updated_at: "2026-11-01T09:37:35.089Z"
content_hash: "ff47b79485360f9d113e37ccb58b9de5288e322fc2f507c1e24fbc2f7220d813"
source_paths:
  - "BE/styles/README.md"
  - "FE/docs/roadmap.md"
  - "BE/.gitignore"
session_ids:
  - "1dab97b4-e0d6-4c3b-8c55-43d35dde6864"
memory_body_ids:
  []
---

# 双仓库拓扑落地（2026-11-01）

定位：项目（WebGIS 服务平台）版本控制结构从「一堆散目录」收敛为**两个 Git 仓库**的操作记录与决策依据。SLD 内容本身的坑见 `b0122682`（G2 grid_total）与 `ac533754`（G3 四分类 + charset），本文件只记结构、建仓流程与链接。

## 1. 最终拓扑

```
项目根/D:\WebGIS\web二维开发\openlayers服务平台开发\
├── BE/.git        → https://github.com/Dawnivers/ServiceAvailable-BE   （public，main）
│   ├── db/        6 个 SQL 脚本
│   ├── src/       Spring Boot 后端
│   └── styles/    20 文件：5 个格网 SLD + 4 个 POI 样式 + 4 张图标 PNG + README
├── FE/.git        → https://github.com/Dawnivers/ServiceAvailable      （main，含 docs/roadmap.md）
├── etl/           87 文件 22.4 MB   ❌ 仍未版本化
├── mock/          19 文件 6.41 MB   ❌
└── data/          2 文件 0.13 MB    ❌
```

两仓库均 `git status` 干净、与远程 `0 0`。

## 2. 决策：`styles/` 归 BE（而非 FE、也不建第三仓）

**理由（可复用判据）**：SLD 是 GeoServer 的**服务侧配置**，与后端同属服务端资产；`poi_icons*` 等旧样式本来也是服务端资源，收进 BE 后一处齐备。放 FE 语义错（不是前端资产）；根目录 `git init` 第三仓会造成三仓库嵌套、clone 易漏。

代价：需改 `FE/docs/roadmap.md` 里的相对链接（实际改了 3 处路径 + 1 处层级，见 §5）。

**执行**：`styles/` 整体移动 → `git add styles` 收 20 文件、1,683 行插入 → 新提交 `631e2d6`（BE #12）。
同时新写 `BE/styles/README.md`，把三条渲染坑固化进仓库（charset=UTF-8 必带、想透明就不给 symbolizer、注释会被 GeoServer 丢弃 → 仓库文件才是可读真源）。

**踩空提醒**：`roadmap.md` 里还有 `src/styles/`（前端 CSS 目录），与根目录 SLD 目录同名但无关，迁移时**不要动**。

## 3. 建仓流程（本机无 gh CLI）

- 环境事实：**未安装 `gh`**，无 `GITHUB_TOKEN` 等环境变量；但 Windows **GCM（Git Credential Manager）** 已存有可用 OAuth 凭证（用户名 `Dawnivers`，token 前缀 `gho_`、长度 40）。
- 做法：从 GCM 取凭证后调 `POST /user/repos` 建仓 → **HTTP 201**，`https://github.com/Dawnivers/ServiceAvailable-BE.git`，public。
- 分支统一：BE 原默认 `master` → `git branch -m main`（与 FE 一致）→ `git remote add origin` → `git push -u origin main`（`* [new branch]`）。
- 密钥全程只在管道内使用，未打印到输出。

## 4. 推公开仓库前的密钥体检（建议固化成习惯）

检查项与实际结果：

| 检查 | 结果 |
|---|---|
| `application-local.properties` 是否被追踪 | 未追踪 ✅，仓库只有 `.example`（`.gitignore` 已列 `application-local.properties`） |
| 全历史 grep `password=` / 真实口令 / `ghp_` / `sk-` 模式 | 4 处命中，**全部是占位符**（`<密码>` / `你的密码` / `...` / `CHANGE_ME`）✅ |
| 工作区 properties 敏感项 | 只有 `localhost:5432/Spatial` + `username=postgres`，无明文口令 ✅ |

要点：「历史里有 `password=`」本身不是问题，**要逐条看命中的值是不是占位符**；数据库连接串只含主机/库名/用户名则可以公开。

## 5. 链接层级坑：`FE/docs` 到项目根只有两层

`roadmap.md:739` 原写 `../../../styles/grid_total.sld`。从 `FE/docs/` 上溯三层会**越过项目根**，落点 `D:\WebGIS\web二维开发\styles\`——即**该链接在 styles 还在根目录时就已经是坏的**（迁移只是让它暴露）。

- 正确写法：`../../BE/styles/grid_total.sld`（提交 `fb12117`）。
- **验证方法（值得复用）**：把 markdown 里所有 `../` 链接抓出来，逐个按所在目录解析后测存在性，全部打印 OK/缺失。本次 6 个链接最后全部 OK（含 3 张新截图 `grid-heatmap-city/zoom/categories.png` 与 `img/preview-browse/analysis.png`）。
- 教训：搬迁目录后**不要只看改了几处字符串**，要做一次全量相对链接存在性校验。

## 6. 提交台账（本次）

FE（Dawnivers/ServiceAvailable，已推 `7f74a78..fb12117`）：
```
fb12117  17 docs：修正 SLD 链接层级（../../../ → ../../BE/styles/）
0fec0b5  16 docs：styles 目录迁入 BE 仓库，修正三处相对路径引用
da90c9d  15 docs：roadmap 补 G1-G3（图层发布 / SLD 两个渲染坑 / 四类热力图 + 公园改用个数分档）+ 3 张截图
```
BE（Dawnivers/ServiceAvailable-BE，已推 main）：
```
631e2d6  12 收入 GeoServer 样式源文件：5 个格网热力图 SLD + POI 图标样式 + 三个渲染坑说明
c685a4c  11 D16 格网热力图表：建表 + 生成 39820 格 + 全量/增量刷新 + 9 项验收脚本
e36d850  10 错误响应带 message
44a6cd8  09 D13 分析能力：/api/poi/within + nearby 补 lon/lat
8306266  08 POI 详情字段扩到 17 个
```

## 7. 遗留待决：`etl/` `mock/` `data/`

| 方案 | 说明 |
|---|---|
| **A（倾向）** | `etl/` 单独建仓 `ServiceAvailable-etl`——干净，22 MB 不污染 BE |
| B | 塞进 BE 仓库——与 Java 代码混杂且变重 |
| C | 等 D19–D20 写 README 时再说——但那时可能已引用里面路径 |

`etl/` 优先级最高：它是「数据从哪来」的证据（采集脚本 + spec），README/面试必被追问。`data/` 0.13 MB 可直接进；`mock/` 需先看内容性质。

## 8. 环境备注

- 本机 `git` 输出常有 `warning: unable to find all commit-graph files` 与 LF→CRLF 提示，属正常噪声，不影响提交/推送结果判定。
- 推送 FE 时曾担心代理，实测当时**无代理环境变量、直连成功**。
