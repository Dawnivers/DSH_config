---
id: "b6e7be56-6c61-4aa2-adba-2f5dcaf43a2c"
title: "PBF→OSM XML 的实测可行路径与本机工具盘点：Geofabrik/官方 planet/BBBike/Overpass + osmconvert/osmium 下载实测（2026-11-03）"
description: "承接文档 6dbb05cc（osm2pgrouting 3.0.0 只吃 .osm XML）。实测记录：Geofabrik 各区域 .osm.bz2 全部 404（只有 pbf）；官方 planet.openstreetmap.org 确实提供 planet-latest.osm.bz2 但约 90 GB；BBBike 格式下拉确有 osm.xz/osm.gz；GDAL OSM 驱动为 rov 只读不可写 .osm；osmconvert 站点 m.m.i24.cc SSL 握手失败、osmium-tool v1.19.0 release 零资产；本机 Python 有 protobuf 7.35.1 + lxml 6.1.1 但无 osmium/pyosmium/fiona/shapely/pyproj。含 PBF 自写转换器的三个技术要点与难度评估。"
status: "active"
created_at: "2026-11-03T11:57:35.454Z"
updated_at: "2026-11-03T11:57:35.454Z"
content_hash: "5faa2fdda9fcdf0aff20c2bf0b43e7f9f68e5d237c4460316eb66194c6dbef96"
source_paths:
  - "serviceAnalysis/data"
session_ids:
  - "b6301385-e0fc-4b7a-8fa7-c84f68437658"
memory_body_ids:
  []
---

# PBF→OSM XML：能拿到 XML 的地方，与"本机转不了"的实测证据

承接 `6dbb05cc-bcfb-49f6-b3d3-dcab56a79723`（《osm2pgrouting 3.0.0 只吃 .osm XML》）与 `1baeb05d-1168-4e1d-b25a-3a5975f4c857`（OSM 获取→导入→验收）。前两篇结论不变，本篇只补两件事：**哪些源真的能给出 `.osm` XML**，以及 **本机为什么转不了 pbf**。

## 1. 数据源格式供应：实测结果

| 源 | 是否给 `.osm` XML | 实测依据 |
|---|---|---|
| `planet.openstreetmap.org/planet/` | ✅ 但只给全球一整份 | 目录列表里确实有 `planet-latest.osm.bz2`（还有 `planet-latest.osm.pbf`、`.md5`、`.torrent`）；XML 约 **90 GB**，解压超 1 TB → 对武汉市域不可用 |
| Geofabrik | ❌ 只有 pbf | `asia/china/hubei-latest.osm.bz2`、`asia/china-latest.osm.bz2`、`asia-latest.osm.bz2`、`europe-latest.osm.bz2` **全部 404**；只有 `hubei-latest.osm.pbf` 可用（53.6 MB） |
| BBBike Extract | ✅ | 抓 `extract.bbbike.org` 页面，格式下拉确有 `osm.xz  OSM XML 7z (xz)` 与 `osm.gz  OSM XML gzip`（另有 `osm.pbf`、`opl.xz`、`geojson.xz`、`sqlite.xz`、`garmin-osm.zip`、`obf.zip`、`mapsforge-osm.zip` 等） |
| Overpass API | ✅ | `[out:xml]` 直接返回 XML；必须带 `(._;>;)` 否则 way 无坐标 |

要点：

- **"官方不提供 .osm"是错的**——官方提供，但只有全球全量；切片站（Geofabrik/BBBike/Overpass）都不是官方。
- Geofabrik 只切 pbf 是成本选择：XML 体积是 pbf 的 5–10 倍（湖北 ~400 MB XML vs 53 MB pbf），全球所有切片并存不划算。
- BBBike 能给 XML 是因为**按需生成**（提交任务 → 临时切片转格式 → 邮件通知），代价是排队十几分钟。
- BBBike 的 bbox 顺序是**经度在前**（`Lng / lat` 各填一对），与 Overpass 的「南,西,北,东」相反——写错会静默拿到空结果。

## 2. 本机转换能力盘点（实测）

```
osmium / osmconvert / osmfilter / osm2pgsql / pyosmium / libosmium  → 全部未安装
GDAL(3.9.2) OSM 驱动:  OSM -vector- (rov)  → read-only，能读 .osm/.pbf，不能写 .osm
Python (D:\python):    protobuf 7.35.1 ✅  lxml 6.1.1 ✅
                       osmium ✗  osm ✗  shapely ✗  fiona ✗  pyproj ✗  geopandas ✗
```

下载侧的两个"经典答案"都不可用：

| 工具 | 实测 |
|---|---|
| `osmconvert64.exe`（`m.m.i24.cc`） | SSL 握手失败（`Invoke-WebRequest` 报 `The SSL connection could not be established`，`curl -k` 也拿不到文件）；HEAD 请求直接被拒 |
| `osmium-tool` GitHub releases | 最新 `v1.19.0`，**资产数 0**——只有源码，无 Windows 预编译包 |

推论：**当前唯一"零安装"拿到 XML 的路是 BBBike 或 Overpass**，不存在"下个 exe 就转完"的现成方案。

## 3. 若坚持自己写转换器（方案可行但有前提）

本机的 `protobuf 7.35.1` + `lxml 6.1.1` 让自写 `pbf2osm.py` 技术上成立（PBF 的 `.proto` 定义公开：`osmformat.proto` / `fileformat.proto`）。三个必须处理的环节：

1. **容器层**：PBF 是 `BlobHeader + Blob` 块序列，每块 zlib 解压后是 `HeaderBlock` 或 `PrimitiveBlock`。
2. **stringtable**：`PrimitiveBlock` 内的全局字符串池，tag 的 k/v 都是索引。
3. **delta 编码（最大的坑）**：`DenseNodes` 的 `id / lat / lon / keys_vals` 四组都是相对上一个值的增量，需累加还原；`lat/lon` 还要按 `granularity`（默认 100）缩放再乘 1e-9。

**不要走"GDAL 读 lines 再拼 XML"**：`lines` 图层的几何已经把节点压成坐标，**原始 node id 丢失**，拼出的 `<nd ref>` 无法还原拓扑，`osm2pgrouting` 建不出正确的 `source/target`。

难度评估：3–5 小时，且必须逐行 diff 校验（拿 BBBike 的 XML 当基准）。价值在学习 PBF 格式本身，不在省事。

## 4. 结论

- 要武汉/湖北路网进 `walk_ways`：**先让 BBBike 出 `osm.gz`（填 bbox、选 XML 格式）**，或 Overpass `[out:xml]`；不要试图在本机转换现有 pbf。
- 若必须用现成的湖北 pbf（53.6 MB，可复现）：只能等外部工具（osmconvert 站点恢复 / 自建 osmium / 自写转换器）。
- Geofabrik 的 `.osm.bz2` 404 是常态，不要写成"链接可能挂错"。
