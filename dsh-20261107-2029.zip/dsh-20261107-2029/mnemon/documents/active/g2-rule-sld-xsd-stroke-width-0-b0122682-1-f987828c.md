---
id: "f987828c-7864-4b59-9f9d-d06d0e8d4071"
title: "G2 修正：空 Rule 过不了 SLD XSD 校验，灰网真凶是 stroke-width=0（推翻 b0122682 坑 1 的结论）"
description: "对 G2 文档 b0122682 的勘误：GeoServer「验证」按钮走 XSD 校验而 REST PUT 不校验，故空 Rule（只写 Filter 不写 Symbolizer）能存能渲染却验证报错；三组 SLD_BODY 单变量对照 + 抽像素 alpha 证明 fill-opacity=0 一直生效，灰色网格由 stroke-width=0 被当发丝线导致；给出既合法又透明的写法与「别一次改两个变量」的定位方法。"
status: "active"
created_at: "2026-11-01T09:13:54.938Z"
updated_at: "2026-11-01T09:13:54.938Z"
content_hash: "160edf6c01c12db58b8bc7de09774b974ac6319f6fbab8b37b8c5a455b81ebe8"
source_paths:
  - "styles/grid_total.sld"
  - "FE/docs/roadmap.md"
session_ids:
  - "0668b393-4be2-4e3f-8148-1d9eae5b0bb8"
memory_body_ids:
  []
---

# G2 勘误：透明档的正确写法与灰色网格的真因

**本文修正** G2 实施记录 `b0122682-e16e-45ff-b016-93a348f4ef9e` 中「坑 1」的结论。那份文档写的是「该档 Rule 一个 Symbolizer 都不给，才是真透明」——**该结论是错的，会导致 GeoServer 验证报错**。其余内容（7 档分档、YlOrRd 配色、0.78 填充透明度、在 25 处拆档、REST 发布/更新命令、看图验收判据）仍然有效。

## 1. 事实：空 Rule 通过 REST 存得进，但过不了「验证」

用户在 GeoServer 样式编辑页点「验证」报：

```
line 55: cvc-complex-type.2.4.b: 元素 'Rule' 的内容不完整。
         应为 '{MinScaleDenominator, MaxScaleDenominator, Symbolizer}' 之一
line 67: 同上
```

两处正好是 `no_data`（`r_total IS NULL`）与 `band1_none`（`< 0.2`）——即当时被删掉 `PolygonSymbolizer` 的两个「不画」规则。

| 通道 | 是否校验 XSD | 结果 |
|---|---|---|
| REST `POST/PUT`（`application/vnd.ogc.sld+xml`） | 否 | HTTP 201/200，能存、能渲染 |
| 界面「验证」按钮 | 是 | 直接拦下 |

**教训**：经 REST 上传成功 ≠ SLD 合法。以后改样式必须两条都过——本地解析 XML + 在 GeoServer 界面点一次「验证」。

## 2. 真因：灰网格来自 `stroke-width=0`，不是 fill 缺色

原判断说「`<Fill>` 只给 `fill-opacity` 不给 `fill` 色 → 回退默认灰填充」。为验证，用 WMS `SLD_BODY` 参数（不污染已发布样式）对单个 band1 格子做**三组单变量对照**，抽出格子中心像素 alpha：

| 变体 | 写法 | 中心像素 |
|---|---|---|
| A | 空 Rule（无 symbolizer） | `(255,255,255,0)` 透明 |
| B | Fill 有色 + `fill-opacity=0`，无 Stroke | `(255,255,255,0)` 透明 |
| C | Fill 只有 `fill-opacity=0` + `Stroke width=0` | `(255,255,255,0)` 透明 |

三组中心像素**全透明** → 填充从来不是问题。`stroke-width=0` 被渲染器当成「发丝线」（仍画 1px），而 500m 格子在 900px 图上只有约 3px 宽，边框吃掉两像素，39,820 个格子叠起来就是一层灰网。

## 3. 既合法又透明的写法（当前 `styles/grid_total.sld` 采用）

```xml
<Rule>
  <Name>band1_none</Name>
  <Title>无覆盖（800m 内 0 个）</Title>
  <ogc:Filter>
    <ogc:PropertyIsLessThan>
      <ogc:PropertyName>r_total</ogc:PropertyName>
      <ogc:Literal>0.2</ogc:Literal>
    </ogc:PropertyIsLessThan>
  </ogc:Filter>
  <PolygonSymbolizer>
    <Fill>
      <CssParameter name="fill">#ffffff</CssParameter>
      <CssParameter name="fill-opacity">0</CssParameter>
    </Fill>
  </PolygonSymbolizer>
</Rule>
```

两个要点：

| 要点 | 原因 |
|---|---|
| 必须有 `<PolygonSymbolizer>`，透明靠 `fill-opacity = 0` | XSD 要求每条 Rule 至少一个 Symbolizer |
| **绝对不写 `<Stroke>`**（`width=0` 也不行） | 0 宽 = 发丝线，n 个格子就是黑网 |

修复后用 REST PUT 更新，渲染产物与改前 **sha256 完全相同**（131,216 bytes）——说明只补回了 Schema 合法性，视觉零变化。校验清单：7 条 Rule 每条 `symbolizers=1`、`stroke=0`、缺 symbolizer 数 0。

## 4. 可复用的定位方法

1. **渲染问题别靠看图猜**，先抽像素：`System.Drawing`（PowerShell）或 Python `PIL`，取格子中心与角落的 RGBA，alpha=0 才算真透明。
2. **单变量对照**用 WMS `SLD_BODY` 内联变体，一次只改一个属性，避免「同时改 fill 色和 stroke 宽」导致归因错误（本次就白改了一轮）。
3. 构造只含目标格的 bbox（取该格中心 + 极小范围），才能干净地读到单格像素。

## 5. 相关记录

- 分档设计与实现细节：`b0122682-e16e-45ff-b016-93a348f4ef9e`（G2，**坑 1 结论以本文为准**）
- 图层发布与 `geometry_name=geom`：`02506967-ac28-421f-886e-e0cc13e39d9f`（G1）
- 分档口径与实测基准：`7e3e84a2-3ab6-4682-9580-62fa711654a3`（D16）
- 仓库内文档已同步更正：`FE/docs/roadmap.md` §2.4.11（「坑 1：透明档有两种写法，只有一种能存进 GeoServer」）
