---
id: "6dbb05cc-bcfb-49f6-b3d3-dcab56a79723"
title: "osm2pgrouting 3.0.0 只吃 .osm XML（不支持 .pbf）+ --attributes 需 hstore：实测纠错与替代路径（2026-11-03）"
description: "对 1baeb05d / 86e8a0ed 两份导入文档的实测纠错：本机 osm2pgrouting 3.0.0 用 expat 只解析 OSM XML，直接喂 .pbf 会报 not well-formed (invalid token)；官方最新 release 就是 v3.0.0（无 3.1/4.x，早前“3.1+ 支持 pbf”是臆测）；--attributes 依赖 PostgreSQL hstore 扩展需先 CREATE EXTENSION；替代路径为 Overpass [out:xml] 取 XML 或 osmconvert 转换，GDAL OSM 驱动只读不能写 .osm。含正确的 Windows 命令与验收顺序。"
status: "active"
created_at: "2026-11-03T11:50:05.738Z"
updated_at: "2026-11-03T11:50:05.738Z"
content_hash: "39c484f0e9b216976488bae2ce24b14b6f510c2875d47bb18431239c0663e836"
source_paths:
  - "serviceAnalysis/data"
  - "serviceAnalysis/BE/src/main/resources/application-local.properties"
session_ids:
  - "1702448c-db01-4db8-9d7a-e65265fa712e"
memory_body_ids:
  []
---

# osm2pgrouting 3.0.0 不支持 .pbf —— 实测纠错与替代路径

承接《OSM 路网数据获取 → osm2pgrouting 导入 → 验收》(id `1baeb05d-1168-4e1d-b25a-3a5975f4c857`) 与《pgRouting 启用 → 步行网导入 → 验收》(id `86e8a0ed-6aa3-46c3-bdfd-833910a9724d`)。

**本篇修正前两篇的核心假设**：那两篇给的是 `osm2pgrouting -f hubei.osm.pbf ...` 的命令，并默认 pbf 可直接导入。实测**导入必然失败**，必须先把 pbf 变成 `.osm` XML。旧文档不改动，以本篇为准。

## 1. ★ 结论：3.0.0 只认 OSM XML，不认 pbf

导入时的实际输出（表已建好、配置已解析完，卡在解析数据）：

```
Opening configuration file: ...\mapconfig_for_pedestrian.xml
    Parsing configuration
Exporting configuration ... - Done
    Parsing data
not well-formed (invalid token) at line 1Failed to open / parse data file D:\QGIS\Test\Wuhan\hubei.osm.pbf
```

`not well-formed (invalid token)` 是 expat（XML 解析器）的原话 —— 它把二进制当 XML 读了。

两条独立证据：

| 证据 | 内容 |
|---|---|
| 文件头（前 16 字节） | `00 00 00 0E 0A 09 4F 53 4D 48 65 61 64 65 72 18` → protobuf `OSMHeader` 块，确认是二进制 PBF |
| 官方 README 依赖清单 | `you will need boost, libpqxx, expat and cmake` —— **只有 expat，没有 protobuf/osmium**；示例全是 `--f your-OSM-XML-File.osm`；提到 pbf 的那行是让人先跑 `osmconvert output_data.osm.pbf --out-osm -o=xxx.osm` |

**版本核实（重要纠错）**：GitHub `pgRouting/osm2pgrouting` releases 共 20 个，最新就是 **v3.0.0（2025-11-01）**，其后是 v2.3.9 / v2.3.8 …。**不存在 3.1.x / 4.x**。「3.1+ 开始支持 pbf」是按 pgRouting 4.0.1 的版本号做的臆测，不成立；用户查 release 页发现后纠正，此结论已删。

## 2. `--attributes` 依赖 hstore（先装扩展，否则第二道墙）

pbf 问题解决后（或之前）还会撞到：

```
database connection successful: Spatial
ERROR: hstore not found
   HINT: CREATE EXTENSION hstore
```

`--attributes` 把 OSM 全部标签塞进一个 `hstore` 列，而不是每个标签建一列。检查顺序是：连库 → 查 hstore → 建表 → 导入 ways → 建拓扑，所以**在"导入"这一步才报**。

`hstore` 来自 PostgreSQL 本体 contrib（不需要额外下载），但仍要**按库**显式启用：

```sql
CREATE EXTENSION IF NOT EXISTS hstore;
```

本机执行后实测：`hstore 1.8`、`pgrouting 4.0.1`（提示"已存在，跳过"）、`postgis 3.6.2`。

> 建库初始化 SQL 必须是三条，顺序上 pgrouting 放最后（依赖 PostGIS）：
> ```sql
> CREATE EXTENSION IF NOT EXISTS postgis;
> CREATE EXTENSION IF NOT EXISTS hstore;
> CREATE EXTENSION IF NOT EXISTS pgrouting;
> ```
> 少 hstore → 导入时立刻报错（好定位）；少 pgrouting → 要到 `pgr_*` 查询才报 `function does not exist`（错误晚出现，更难定位）。
> 区分两张表：`pg_extension` = 本库已装；`pg_available_extensions` = 盘上有。两者对照可判断"没装"还是"压根没文件"。

## 3. 三条替代路径（按推荐度）

### A. Overpass 直接要 XML（零安装，推荐首选）

```
https://overpass-api.de/api/interpreter?data=[out:xml][timeout:600];(way["highway"](30.28,113.68,31.37,114.65););(._;>;);out body;
```

- `[out:xml]` 明确要 XML；`(._;>;)` 必须带上，否则只有 way 无节点 → 空壳无坐标。
- 天然解决"先裁武汉"的诉求（按 bbox 取，XML 体积远小于全省）。
- 风险：公共实例对「大 bbox + 全 highway」可能超时/504，失败就缩到主城区 `113.89,30.33,114.64,30.79` 或分块。

### B. osmconvert 转换（单文件 exe，符合"少装东西、放 D 盘"）

```
https://wiki.openstreetmap.org/wiki/Osmconvert
```

```powershell
& 'D:\osmconvert\osmconvert64.exe' 'D:\QGIS\Test\Wuhan\hubei.osm.pbf' `
  -o='D:\QGIS\Test\Wuhan\hubei.osm'
```

53 MB pbf → 约 300–500 MB XML（XML 冗余大）。

### C. 自己写脚本转换 —— 不可行

GDAL 的 OSM 驱动是 `rov`（read-only vector，`ogrinfo` 显示 `OSM -vector- (rov)`），**只能读不能写 `.osm`**；而且 GDAL 的 `lines` 图层已把节点压成坐标，**原始 node id 丢失**，无法还原 `<nd ref="...">` 引用 → 拼出的 XML 建不出正确拓扑。本机也确认 `osmium` / `osmconvert` / `osmfilter` / `pyosmium` 均未安装。

## 4. 修正后的可执行命令序列

```powershell
# ① 变量区 + 自检（PowerShell 变量不跨窗口，必须与下面的命令同一个窗口）
$BIN  = 'D:\PostgreSQL18.4\data\18\bin'
$OSM  = 'D:\QGIS\Test\Wuhan\wuhan.osm'      # 注意：XML，不是 pbf
$TMPD = 'D:\QGIS\Test\Wuhan\tmp'
$env:TMP = $TMPD; $env:TEMP = $TMPD; $env:GDAL_TMPDIR = $TMPD
$BIN; Test-Path "$BIN\osm2pgrouting.exe"; $env:TMP    # 第二行必须 True

# ② 密码走环境变量（-W 在 osm2pgrouting 是取参选项，不会交互提示）
$env:PGPASSWORD = Read-Host 'Postgres password'

# ③ 导入（不带 -W）
& "$BIN\osm2pgrouting.exe" `
  -f $OSM `
  -c "$BIN\mapconfig_for_pedestrian.xml" `
  -d Spatial -U postgres -h localhost -p 5432 `
  --clean --prefix walk_ --attributes
```

成功标志：`Ways processed: <接近 highway 非空线数>`，随后 `Vertices processed: xxx,xxx`。湖北全省 highway 非空约 **275,840** 条（GDAL `lines` 层计数），可作量级参照。

## 5. 顺序建议（避免白跑）

1. `CREATE EXTENSION IF NOT EXISTS hstore;`（+ postgis / pgrouting）
2. 取到 `.osm` XML（Overpass 或 osmconvert），存**纯英文路径**
3. 同窗口设 `TMP/TEMP/GDAL_TMPDIR` → 导入
4. 验收：表存在 → `length_m`/`cost` 单位体检（`avg_cost/avg_len_m ≈ 1` 说明都是米）→ `pgr_connectedComponents` 最大分量占比 → `highway` 构成统计 → 单点 `pgr_drivingDistance` 800 m 试跑

## 6. 待办

- [ ] 选定 A 或 B 拿到 `wuhan.osm`，跑通导入并记录 `Ways processed`
- [ ] 记录连通性最大分量占比与步行网构成表
