---
id: "11d91f88-c85e-4e1a-a606-8c05580fba27"
title: "POI 详情卡 PoiDetailCard 实现与验证（Step 4：A 照片插槽、前端反查所属区、统计块占位）"
description: "FE/src/components/PoiDetailCard.vue 的落地记录：纯展示组件四态、9 字段映射与降级规则（=== 而非 ||）、/api/areas 13 区 EPSG:3857 缓存 + intersectsCoordinate 反查所属区（带竞态 seq）、照片 A 位插槽与死链兜底、stats 占位留给 D13；含跨区实测、已知字段缺口与待决事项。"
status: "active"
created_at: "2026-10-30T11:04:13.277Z"
updated_at: "2026-10-30T11:04:13.277Z"
content_hash: "d82dbb9705df25decf568ad741417e317937a7f6f5e41bd7cd6330a10dd169cd"
source_paths:
  - "FE/src/components/PoiDetailCard.vue"
  - "FE/src/App.vue"
  - "FE/src/view/mapView.vue"
  - "FE/src/map/wms.js"
  - "FE/src/components/LayerPanel.vue"
  - "FE/src/stores/selection.js"
session_ids:
  - "4e88df3e-f526-482f-b875-1acac46a8392"
memory_body_ids:
  []
---

# POI 详情卡 `PoiDetailCard.vue` 实现与验证（Step 4）

落稿位置：`FE/src/components/PoiDetailCard.vue`（新建） + `FE/src/App.vue`（接线）。
验收图：`FE/docs/img/card-render.png`（360×620 → 340×620，临时图，是否入库待定）。

## 1. 定位与接口

与 `LayerPanel.vue` 同风格：**纯展示组件**，不 import store、不 fetch、不碰 map 实例。

```
props: { poi: Object|null, loading: Boolean, error: String|null }
emit:  ['close']
```

`App.vue` 中挂在 `<mapView />` 之后（同级，绝对定位不冲突）：

```vue
<PoiDetailCard :poi="selection.poi" :loading="selection.loading"
               :error="selection.error" @close="onCloseCard" />
```

注意：`selection.poi` 是普通对象可安全传 props；**`map` 实例绝不能作为 props**（会进 Vue Proxy）。

## 2. 四个状态（根级判断）

| 状态 | 条件 | 渲染 |
|---|---|---|
| 加载中 | `loading === true`（优先级最高） | 转圈 + 「正在读取…」 |
| 出错 | `error !== null` | 红字错误文案，字段行全部不渲染 |
| 有数据 | `poi !== null` | 正常内容 |
| 全空 | 三者皆否 | **整张卡不渲染** |

第四态最容易漏：只写 `v-if` 分支会在页面上留下一个空的白边框。

## 3. 字段映射（以 `/api/poi/{gid}` 实际返回的 9 个字段为准）

| 位置 | 数据 | 缺失时 |
|---|---|---|
| 头部右 | `poi.amapId`（如 `#B001B0IZT0`） | `—` |
| 名称 | `poi.name` | `—` |
| 类别标签 | `poi.category` → 中文 + 颜色 | 未知类别显示原文，灰 `#8aa0b4` |
| 地址 | `poi.address` | `—` |
| 所属区 | 前端反查结果 `district` | `—`（反查失败/未完成不阻断卡片） |
| 坐标 | `poi.lon` / `poi.lat`，6 位小数 | 任一为空 → `—`，不出现 `NaN` |
| 电话 | `poi.tel`（**约 45% 为 null**） | `—` |
| 照片 | `poi.photos`（可能空数组） | 空数组 → 整块不渲染 |
| 统计块 | `stats.{nearby, sameType, accessibility}` | 全部占位 `—`，待 D13 |

类别色板（与 `map/layers.js` 的 chips 保持一致）：`school #1565C0` / `hospital #C62828` / `mall #EF6C00` / `park #2E7D32`。

## 4. 降级规则

1. **空值函数必须显式判断**：`v === null || v === undefined || v === '' ? '—' : v`。
   `v || '—'` 会吃掉数字 `0`——将来 D13 的 `stats.nearbyCount = 0`（800m 内确实没有设施）会错显成 `—`。
2. **坐标**：`toFixed(6)` 保留信息（设计稿 4 位只是显示精简）。
3. **未知类别**：显示原文而非 `undefined`。
4. **照片死链**：高德图床确有 404，`@error` 里把该张图 `display:none`，不留破图标。

## 5. 所属区反查（用户要求：不单独拆 js，直接内嵌在组件里）

- 数据源 `/api/areas`：13 个区，全部 `MultiPolygon`，响应约 85 KB。
- **模块级缓存** `areasGeom`，并用 `areasPromise` 把并发请求合并成一个：只拉一次。
- 解析时直接 `new GeoJSON().readFeature(f, { featureProjection: 'EPSG:3857' })`，与 View 坐标系对齐，查询时无需再转换。
- 判定用 OL 内置 `feature.getGeometry().intersectsCoordinate(coord)`；`MultiPolygon` 同样支持。**不装 turf**。
- **竞态保护**：`districtSeq` 自增序号，与 `selection.js` 的 `reqSeq` 同一思路——快速连点两个 POI 时，先发的反查晚回不会覆盖后点的结果。
- 触发方式：`watch(() => props.poi, ..., { immediate: true })`（computed 不能 async）。
- 边界：点在所有区外 / `lon lat` 为空 / `/api/areas` 失败 → 返回 `null` → 显示 `—`；反查失败不得让整张卡挂掉。

## 6. 布局（A 方案）与样式

```
设施详情                     #B001B0IZT0  ✕
名称 解放公园 [公园]  地址 …  所属区 …  坐标 …  电话 …
[照片横向滑动条]        ← A 位：正文下方、统计块上方
[ — ][ — ][ — ]        ← 800m 内 / 同类最近 / 可达性（占位）
[查看详情] [附近分析]    ← 占位，未绑事件
```

字段行用 `dl/dt/dd`（语义正确、天然对齐，标签列定宽、值列自适应）。

视觉语言照抄 `LayerPanel.vue`：圆角 12、边框 `1px solid #dde5ec`、阴影 `0 6px 20px rgba(16,42,67,.12)`、背景 `rgba(255,255,255,.95)`、`backdrop-filter: blur(6px)`、`'Microsoft YaHei'`、主色 `#1565C0`、正文 `#2b4359`、次要 `#8aa0b4`、标签 `#9aaec1`。
定位 `position:absolute; right:16px; top:72px`（与 LayerPanel 的 `left:16px; top:72px` 对称）；**宽度 288px 左右**——设计稿 309px 里 `114.3622, 30.5386` 那行已快贴边，再宽会把卡片顶出窄窗口。

## 7. 实测结果（真实浏览器 + 真实库数据）

主路径（gid=1 解放公园）：照片数 3、电话 `027-82421760`、所属区**江岸区**、坐标 `114.292598, 30.610841`。

| # | 用例 | 结果 |
|---|---|---|
| ② | gid=2 汉口江滩2期（tel=NULL） | 电话显示 `—`，不是 null/空白 ✅ |
| ③ | gid=39 政和广场（photos=0） | 照片区整块不渲染，无空白 ✅ |
| ④ | 不存在 gid（404） | 显示「该设施不存在」红字，字段行消失 ✅ |
| ⑤ | `selection.clear()` | 整张卡消失，不留空框 ✅ |

反查准确性（5 个跨区样本，全部命中）：解放公园→江岸区、竹叶海公园(114.177392,30.626166)→硚口区、武汉动物园→汉阳区、武昌江滩→武昌区、洪山江滩→洪山区。
**东湖水域落在洪山区**——不是查错，那片水面确在洪山区边界内，原「期望 null」的预期不准。

可用测试样本（库内）：有电话+照片 gid=1/4/8；**无电话** gid=2/3/5；**无照片** gid=39/46/73；跨区 gid=4472(硚口)/5683(汉阳)/6806(武昌)/9250(洪山)。

SFC 编译检查：`SFC OK — 26 bindings`。

## 8. 已知缺口与待决

- **所属区 `adname`**：`/api/poi/{gid}` 不返回，故走前端反查（另一条路是后端 `PoiMapper.xml` JOIN `admin_area` 补列）。
- **187 / 3 两个数字**：来自 `/api/poi/nearby` 的 `count` / `byCategory`，而 nearby 需要圆心坐标，属于 **D13** 缓冲区分析的事，现做硬编码只会被拆掉 → 占位。
- **可达性指数 0.62**：后端根本没有定义，先占位。
- **两个按钮**：未绑事件；「查看详情」应跳详情页，「附近分析」是 D13 入口。
- `stats` 对象是 D13 的唯一改动点（`stats.nearby / sameType / accessibility`），D13 只填值，模板不动。
- `detailFetched` 字段当前恒为 `false`，卡片可考虑显示「未抓取」标记或干脆不显示。

## 9. 相关文档

- `1f15e7d4-0d2b-4c51-84a3-23c019ed1792` — POI 详情的展示契约（固定列 vs 动态列、三级降级、`detail_fetched` 布尔），本卡片的「缺失降级、缺就藏」原则来源。
- `2ec44b4f-ce9b-4705-b5e0-8c1aea0c4cef` — 高德详情缓存成本模型与二维 WMS 容量预算。
