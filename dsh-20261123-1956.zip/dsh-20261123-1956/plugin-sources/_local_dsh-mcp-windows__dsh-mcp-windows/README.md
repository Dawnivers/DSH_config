# dsh-mcp-windows

把 [CursorTouch/Windows-MCP](https://github.com/CursorTouch/Windows-MCP) 接入 DeepSeek Harness 的纯配置 bundle。

## 它是什么

一个 MCP 桥接包，自身不含可执行代码，只往挂载树里插一行
`@deepseek-ai/dsh-mcp-client`，指向本机 uv 装的 `windows-mcp.exe`。

接入后工具以 `mcp__windows__*` 出现：`Snapshot`、`Screenshot`、`Click`、
`Type`、`Scroll`、`Move`、`Shortcut`、`Wait`、`WaitFor`、`App`、`Clipboard`、
`Process`、`Notification`、`DisplayInventory`、`ControlStatus` 等。

## 为什么排除 PowerShell / Registry / FileSystem

`pwsh` 工具已经以完全相同的权限覆盖了这三样。重复挂载只会扩大攻击面，
不增加任何能力。所以本插件保留的是**只有它才能做**的部分：UI 层。

这条边界是刻意的——想动文件或注册表，走 `pwsh` / `read` / `edit` / `write`，
权限与审计都集中在那一处。

## 控制闸门

Windows-MCP 自带的桌面所有权机制，本插件沿用默认配置：

- `relaxed` 策略：只有直接输入类（`Click`/`Type`/`Scroll`/`Shortcut`/`App switch`）
  需要桌面所有权；`Snapshot`/`Screenshot`/`Process list`/`Clipboard get` 等后台工具不占用。
- 抢桌面之前屏幕边缘变琥珀色，弹倒计时对话框；你动鼠标键盘就保住桌面。
- 物理移动鼠标累计到阈值（默认 500 device units），或按
  `Ctrl+Alt+Shift+Backspace`，立即夺回控制权。
- `ControlStatus` 随时可查当前归属；AI 侧可 `release=true` 主动交还。

## 二进制与遥测

```
C:\Users\林先语\.local\bin\windows-mcp.exe    uv tool v0.8.8 的 shim
```

换版本或换路径，改 `cordis.patch.yml` 里的 `command` 即可。

遥测默认全关：`ANONYMIZED_TELEMETRY=false` + `POSTHOG_API_KEY=''`
（后者是双保险，服务端内置了硬编码 project key 作默认值，空串会直接跳过初始化）。

## 历史

本插件在 2026-11-15 之前是一条直接写死在 profile `cordis.patch.yml` 里的
`- insert:` 条目。搬进独立包后获得插件面板可见、可开关两个属性，
排除项与遥测设置原样迁移。原条目备份见 `~/.dsh/profiles/desktop/`
下的 `cordis.patch.yml.bak-*-pre-windows-mcp-plugin`。
