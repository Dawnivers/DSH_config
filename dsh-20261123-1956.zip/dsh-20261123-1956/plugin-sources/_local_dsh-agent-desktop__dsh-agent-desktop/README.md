# dsh-agent-desktop

把 [vercel-labs/agent-desktop](https://github.com/vercel-labs/agent-desktop) 接入 DeepSeek Harness 的纯配置 bundle。

## 它是什么

一个 MCP 桥接包。自身不含任何可执行代码，只做两件事：往挂载树里插一行
`@deepseek-ai/dsh-mcp-client`，指向本机解包的 agent-desktop 原生二进制。

接入后工具以 `mcp__agentdesktop__*` 出现，对应 CLI 的同名命令：
`snapshot` / `find` / `get` / `is` / `click` / `set-value` / `select` /
`toggle` / `scroll` / `press` / `launch` / `list-apps` / `list-notifications` 等。

## 与 windows-mcp 的分工

| | agent-desktop | windows-mcp |
|---|---|---|
| 点按钮 | 语义调用，不动指针、不抢焦点 | 坐标点击，需夺桌面（有闸门） |
| 读界面 | UI Automation 树 + ref 编号 | UIA 树 + 坐标 + 截图 |
| 文件 / 注册表 / 命令 | **没有** | 有（本机已在 profile 里排除） |

两者可共存，工具名不冲突。

## 依赖的外部落盘

```
D:\tools\agent-desktop\agent-desktop.exe   v1.3.1，官方 x86_64-pc-windows-msvc
D:\tools\agent-desktop\home\               AGENT_DESKTOP_HOME，状态根（勿手动预建）
```

换版本或换路径，只改 `cordis.patch.yml` 里的 `command` 与 `env.AGENT_DESKTOP_HOME`。

## 已知限制

- 无头模式下 `type`、`right-click`、`double-click`、`drag`、`hover` 会返回
  `POLICY_DENIED`；写文字用 `set-value`，真要敲键盘得加 `--headed`（那时就会抢焦点）。
- ref 跟快照绑定，界面一变就 `STALE_REF`，必须重新 snapshot 再点。
- Chromium / Electron 冷启动要 10–25 秒才建出完整树，可调 `--timeout-ms`。
- 管理员权限的窗口读得到、点不了（UIPI 拦截），需同级权限运行。
