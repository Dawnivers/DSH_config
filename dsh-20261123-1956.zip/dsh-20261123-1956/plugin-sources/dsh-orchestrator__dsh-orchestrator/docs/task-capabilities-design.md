# 按任务分配工具与 Skills：编排插件设计

状态：设计定稿，待实现。目标版本：v0.3；当前运行的 v0.2.0 保持不变。本轮没有运行新的模型实验。

## 1. 已确定的分工

用户在 GUI 中限定候选工具、技能和项目范围；planner 在这个范围内为每项任务选择工具、技能，给出具体指令；worker 加载选定技能，决定实际工具调用顺序；宿主验证并执行所有边界。Reviewer 按验收条件只读复核，主会话承担构建、后台浏览器验证以及未交给 worker 的动作。

共享的是候选目录与固定版本的技能来源，不共享一个可随意扩张的工具权限集合，也不共享 planner 的全部对话历史。Planner 的技能加载结果不会自动进入 worker 上下文，worker 必须获得自己任务需要的完整正文。

基本规则：

- 任务实际工具集合必须是用户允许池的子集。
- 任务技能集合必须是用户允许技能池的子集。
- 技能依赖必须能由该任务已分配工具满足；技能文字不能增加权限。
- 工具可见、技能加载、文件读写范围是三件分别校验的事。
- 原有文件互斥、接口签名一致、修改前读取、快照及基线检查继续生效。
- 工具、技能或适配器缺失时，返回具体原因，不静默换工具、替换技能或调整模型。

## 2. GUI 与操作流程

在现有编排窗口增加“工具与技能”区域。先显示分类文件夹，再进入类别选择，避免把所有项目铺成一张长表。

工具分类建议：项目文件、文档与检索、后台验证、命令与构建、其他插件。技能按来源文件夹/插件分类，支持搜索、分类计数、展开后开关；名称之外显示用途、依赖工具、当前是否可执行。

常用流程：

1. 填任务、项目根、模型及档位。
2. 选择 worker 可用工具池与技能池；planner/reviewer 默认维持只读角色，可展开高级配置查看其能力。
3. 保存不可变任务，宿主生成能力目录快照。保存默认值只保存选择意图，下一次新任务重新解析实际可用项。
4. 启动前根据执行会话的真实作用域再次校验，再发第一笔 planner 请求。
5. Planner 给出逐任务分配；宿主校验通过后，worker 先加载技能，再执行。
6. 展示每个任务实际分配、技能加载状态、工具调用记录、修改文件与复核结果。

不增加例行的逐工具确认弹窗。已选择的清单和已有用户授权在整个任务内持续有效；不能满足时明确报错，不利用重试自动扩大清单。

工具卡片必须区分：可直接分配、仅可交给主会话/受限执行器、尚无范围适配器。技能卡片必须区分：可执行、依赖未选择、依赖未声明、来源不可用。用户能看到不可执行原因。

当前会话启用的工具与全局已安装工具不同。GUI 的候选目录需要标记作用域；不能通过猜测 sessionId 绕过宿主会话权限。如果 HTTP 设置页暂时拿不到准确 agent scope，先展示宿主公共候选项，并明确标记“启动前按执行会话校验”；涉及代理私有能力的展示需复用宿主已有会话鉴权接口后再开放。

## 3. 配置与计划格式

保留原有任务、模型、文件和接口字段，增加有版本号的能力配置。下面的名称与哈希仅用于说明格式；实际条目由宿主从注册表生成，不让模型编造。

```json
{
  "capabilities": {
    "version": 1,
    "roles": {
      "planner": { "tools": ["read", "glob", "grep"] },
      "worker": { "toolPool": ["read", "glob", "grep", "write", "edit"] },
      "reviewer": { "tools": ["read", "glob", "grep"] }
    },
    "skillPool": [
      {
        "key": "skill-001",
        "name": "example-skill",
        "provider": "filesystem",
        "contentSha256": "<由宿主解析并计算>",
        "requirementsId": "requirements-001"
      }
    ],
    "skillLoading": "required-before-actions",
    "onUnavailable": "reject"
  }
}
```

Planner 的单项任务增加 `tools`、`skillKeys`。原有 `id`、`files`、`instruction`、`provides`、`consumes` 和全局 `acceptance` 保留。

```json
{
  "id": "speed-control",
  "files": ["src/main.js", "styles.css"],
  "tools": ["read", "grep", "edit"],
  "skillKeys": ["skill-001"],
  "instruction": "先加载分配技能，读取现有控件和样式，再按接口契约实施；发现不符须报告。",
  "provides": [],
  "consumes": [
    {
      "name": "setSwimSpeed",
      "from": "swim-clock",
      "signature": "setSwimSpeed(multiplier: number): number"
    }
  ]
}
```

`tools` 使用宿主注册表的真实名称，不使用界面展示名或模型猜测的别名。技能 key 由宿主映射到确定的 name/provider/正文版本；模型不能提供路径、URL 或替代正文。

工具绑定快照记录名称、schema 哈希、能力适配器及其版本；执行期固定实际解析到的工具定义，防止同名覆盖在运行中悄悄改变含义。进程重启后需重新校验保存的元数据，不能把旧对象身份当作仍然有效。

## 4. Planner 与 reviewer 的行为

Planner 获得允许池的名称、摘要、工具用途、技能依赖及不可执行原因。默认只加载与任务有关的技能正文，避免把所有技能全文放进每个请求。

Planner 可以指定“先读哪些位置”“只用 edit 原位修改”“某接口签名必须一致”等具体做法；worker 仍负责实际工具参数和调用顺序。

Planner 通过只读的技能入口查看用户已允许的技能，不执行技能中的写入、命令或发布步骤。Reviewer 只查看本轮已分配技能和实施结果；不默认继承 worker 的写权限。

宿主的计划校验包括：

- 工具和技能均存在于快照中，任务工具不超出 worker 池。
- 所选技能的必需工具全部列在该任务 tools 中；不由宿主偷偷补齐。
- 文件写工具的任务具备必要读取能力，并保留精确文件分配。
- 现有文件互斥和接口闭合规则仍满足。
- 实际工具的范围适配器可覆盖该任务需要的参数和副作用。

拒绝的计划按已配置的规划重试次数处理；错误包含任务、能力和缺失项，不暴露敏感配置。

## 5. Skill 的读取与执行

采用“每个子代理专属的受控加载入口”。对模型可继续呈现 `skill(name)`，但实现是该代理作用域内的受控包装；不修改全局原工具。

- Planner 可查看 GUI 允许池中的技能；worker 只能加载自己 task.skillKeys 指向的技能；reviewer 只能查看本轮任务技能。
- 调用宿主技能服务，用当前 agent 的 scope、任务项目 cwd 和取消信号解析；检查 modelInvocable、provider、正文哈希与冻结版本。
- 正文以宿主统一的技能渲染方式返回。只返回名称、路径或摘要不算加载完成。
- 加载成功后才记录 loaded；加载失败、超时或取消不能伪造回执。
- worker 的必要技能全部加载前，宿主拒绝项目业务工具；加载入口与结构化失败报告仍可用。
- 成功加载后允许既定工具调用；技能文字不得覆盖角色、文件、网络或外部写入边界。

任务生命周期：pending → loading-skills → executing → reviewing → needs-validation → validated；无技能任务直接进入 executing。加载失败进入 blocked，并报告具体缺失内容。这里的 blocked 是任务状态，不冒用会话 Goal 工具的阻塞协议。

宿主原生技能目录仅在原生 skill 工具对代理可见时发布；同名 scoped 包装会让原目录不再发布。插件必须自己发布经过过滤的目录，不能放开全量目录再靠模型自觉。

## 6. 技能依赖与引用资源

已核对的原生技能服务没有可直接用来完成本设计的、统一可信的 requiredTools 声明。因此插件需要独立的依赖登记表，不能把技能正文里出现的工具名自动当成授权。

依赖登记表区分 requiredTools、optionalTools、资源读取方式及适配器版本。它可以由插件内置、能力包提供或管理员配置，并记录来源。依赖未知的技能显示“依赖待配置”；v1 不自动派给 worker。只读查看正文仍可用于了解用途。

技能引用的模板、文档、示例脚本常在项目根之外。增加专属 `orchestrate_skill_resource` 只读工具，参数使用已分配技能 key 与相对资源名，宿主映射真实路径：

- 仅允许已分配技能登记的资源边界；不接受模型提供的新根目录。
- 校验真实路径、路径穿越与链接逃逸；资源读取不扩大项目写权限。
- 首版读取有限大小的文本资源，提供内容、相对来源与哈希；图片/二进制按后续适配器处理。
- URL 或 opaque provider 的资源必须有对应读取适配器；没有适配器则给出不支持原因。
- 读脚本与执行脚本分开授权。脚本可被作为文本读取，不意味着允许运行。

v1 不提供“遍历任意技能目录”“运行技能里所有脚本”的权限。技能依赖另一个未分配技能时，同样返回缺失项，不自动扩权。

## 7. 工具边界与扩展方式

维持两层执行控制：工具可见性筛选，加上每次调用的 guard。前者减小模型可见 schema，后者校验真实调用及参数。

有效权限同时满足：父会话可用能力、用户为任务选择的允许池、角色范围、planner 的逐任务分配、实际调用的参数边界。Scoped 专属工具也必须经 guard，不能因为是本插件注册的就绕过检查。

现有文件工具沿用项目根、真实路径、无越界链接、worker 精确写入集合等规则。外部插件工具按能力适配器接入，不能只把工具名加入 allow 后便宣称仍有完整文件隔离。

首版接入范围：

| 能力 | v1 处理 |
| --- | --- |
| 原有文件工具 | 保持现有边界，允许按任务收窄 |
| 技能正文与登记资源 | 代理专属只读入口 |
| 文档/检索插件工具 | 有已审计参数与副作用适配器后可选 |
| 后台浏览器验证 | 默认由主会话承担；有独立上下文及域范围适配器后可分配 |
| 通用 shell、任意脚本 | 默认留给主会话/受限执行器；没有真实进程与文件边界时不可交给 worker |
| 外部消息、发布、删除等写入 | 不随技能自动开放，继续要求对应用户授权和能力适配 |
| 新建其他代理 | 首版 worker 不开放 |
| 桌面鼠标、录屏和可见浏览器接管 | 不作为默认能力，遵守既有后台操作约束 |

`structured_output` 属于交付通道；`run_code` 若由宿主 PTC 呈现则属于传输通道，不视为用户业务工具。必须验证传输中的每个嵌套工具调用仍经过同一 guard，不能因通道已允许而跳过业务权限。

## 8. 与当前 DSH 接口的对应

已核对本机源码，而非假设接口存在：

- 当前 [runner](<D:/Users/林先语/Documents/deepseek-harness/default-workspace/dsh-orchestrator/src/runner.js#L75>) 已逐角色传 toolFilter，并在首笔请求前完成代理绑定。
- 当前 [bindings](<D:/Users/林先语/Documents/deepseek-harness/default-workspace/dsh-orchestrator/src/bindings.js#L26>) 已有执行 guard 与项目/文件检查。
- [技能服务](<D:/DSH/dsh_data/DSH Desktop/resources/app/node_modules/@deepseek-ai/dsh-skill/lib/index.js#L224>) 支持 list/snapshot/get，接受 cwd、scope 和 signal。
- [原生技能工具](<D:/DSH/dsh_data/DSH Desktop/resources/app/node_modules/@deepseek-ai/dsh-tool-skill/lib/index.js#L138>) 已示范调用策略、正文读取和 resourceBase；可复用其公开服务及 renderSkillContent，不复制其私有历史逻辑。
- [原生目录发布](<D:/DSH/dsh_data/DSH Desktop/resources/app/node_modules/@deepseek-ai/dsh-tool-skill/lib/index.js#L207>) 会检查该代理解析到的是否为原生 skill 定义，故 scoped 包装后需要插件自己的过滤目录。
- [工具服务](<D:/DSH/dsh_data/DSH Desktop/resources/app/node_modules/@deepseek-ai/dsh-tools/lib/types/index.js#L481>) 的 restrict 只筛选继承工具；作用域专属注册仍可见。不能把 scope-local loader 或保留的 run_code 名称直接塞进继承工具 restrict。应按 SDK 实际注册顺序处理，并由 guard 覆盖专属工具。

上述操作在目标 agent 创建阶段完成，延续当前“先绑定，再请求”的时序。运行任务的 role、files、tools、skills 一次性冻结；不修改已运行代理的上限。

## 9. 费用与执行记录

保留现有精确 child sessionId 绑定、provider/model/effort 和真实 usage 账本统计。

新增记录：候选快照摘要、任务实际工具集合、技能 key/provider/正文哈希、成功加载时间、引用资源哈希、适配器版本、工具拒绝原因及复核发现。

必须区分：代理数量、模型 API 请求次数、工具调用次数、skill 加载次数。读取一次技能本身不能直接当成一次模型 API 请求；正文进入后续上下文产生的 token 计入该子会话实际 usage。

默认只向 planner 提供目录摘要，worker 只得到分配内容，reviewer 按需读。避免把全部技能全文、主会话历史和无关工具 schema 注入每个子代理。价格仍标明账本估算与统计范围。

私有运行快照可保留复现需要的正文；普通报告只导出标识、摘要、哈希与用量，不自动附带整套技能或敏感资源。

## 10. 兼容、实现顺序与验收

缺少 capabilities 的旧任务保持当前模式：planner/reviewer 只读，worker 五种文件工具，无技能；不自动继承当前主会话全部插件。不重写旧任务和旧实验记录。

建议实现顺序：

1. 能力目录、技能依赖登记与版本快照；完善启动前缺失项诊断。
2. 扩展配置与计划 schema，增加集合、依赖、精确名称及作用域校验。
3. agent 创建时注册 scoped loader、资源入口、过滤目录和执行 guard。
4. GUI 分类选择、逐任务分配展示与运行状态。
5. 用量与审计字段、兼容测试、客户端构建与打包。

预计改动位置：现有 [policy](<D:/Users/林先语/Documents/deepseek-harness/default-workspace/dsh-orchestrator/src/policy.js>)、[runner](<D:/Users/林先语/Documents/deepseek-harness/default-workspace/dsh-orchestrator/src/runner.js>)、[bindings](<D:/Users/林先语/Documents/deepseek-harness/default-workspace/dsh-orchestrator/src/bindings.js>)、[settings](<D:/Users/林先语/Documents/deepseek-harness/default-workspace/dsh-orchestrator/src/settings.js>) 与 UI；新增能力目录、技能加载/资源适配模块及对应测试。此文不修改上述运行代码。

关键验收用例：

- 旧任务在原权限下继续运行，新任务不能继承未选择工具。
- Planner 编造工具、选未允许技能、漏列必需依赖时，worker 启动前被拒。
- Worker 加载非分配技能失败；必须技能未加载时不能写文件。
- Planner 的加载结果不被误算为 worker 已加载；每个 worker 的内容与版本可追溯。
- 技能同名覆盖、正文变化、工具替换、插件卸载以及作用域不可用能被明确检出。
- 项目外资源只能按登记范围只读，路径穿越、链接逃逸和任意资源根被拒。
- 工具的外部写入、shell 与嵌套调用不能绕过文件及参数边界。
- 两个 worker 仍不能写对方文件，接口签名校验继续生效。
- 取消、加载失败和 HMR 后不残留授权、目录注入或持有中的代理。
- 分类界面可完成选择与查看原因；无手写 JSON、命令复制或逐工具重复确认。
- 实际报告能分别核对模型请求、工具调用、技能加载和费用口径。

交付边界：这是按已确认分工形成的实现规格。配置格式为拟新增协议，不宣称当前 orchestrate_task 已接受这些字段；现有插件尚未升级为本设计。
