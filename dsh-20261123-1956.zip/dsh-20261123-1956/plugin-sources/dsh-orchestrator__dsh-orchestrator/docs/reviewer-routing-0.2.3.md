# 独立 reviewer 与模型适配验收：v0.2.3

日期：2026-11-12（Asia/Shanghai）

已实现 planner、worker、reviewer 各自独立的 provider / model / effort。方向为 Claude 规划、Claude / DeepSeek / Qwen 实施、GPT 复核；角色不按品牌限制。这里只完成插件功能和本地验收，没有调用远程付费模型，没有增加此次实现所需的子代理，也没有自动运行用户项目。

## 配置与执行

- 配置工具、设置 API、三张模型卡、默认设置、独立任务及执行入口均使用三套模型路由。
- reviewer 实际使用 `job.reviewer` 启动独立只读会话；feasibility 继续使用 worker。正常完整流程仍为 N+3 个子会话，规划重试另计。
- 在第一次 planner 请求前检查三条路由；每个子会话启动前再次检查。显式配置的模型或档位不受支持时停止，不替换模型、不降低档位，也不回退到 planner。
- reviewer 只有 read / glob / grep，保留项目范围、父子归属及工具创建屏障；不能写文件、执行 shell 或继续委派。

## 旧配置

仅缺少整个 reviewer 配置时，复制原 planner 路由及档位以保持旧行为。显式 null、空对象、部分字段或不支持的档位均不是缺省，不能触发回退。

支持嵌套 reviewer 对象，也支持 `reviewerProvider / reviewerModel / reviewerEffort` 平铺形式。历史任务和执行记录保持原样；读取旧任务时在内存中规范化。设置页对旧默认值显示迁移提示；用户可显式选定 GPT 等 reviewer 后保存。

全新默认表单从已配置目录优先选择相应系列，不猜模型版本或思考档位。已有默认值即使目录暂不可用也原样保留。没有匹配系列时，首次表单建议使用目录可用项；这不是运行时故障回退。

## 适配边界

插件只向原生 spawn 传 provider、model 及显式选定的 reasoningEffort。各家协议、思考参数及工具转换由现有 DSH 适配器负责；不自行加入 thinking、temperature、reasoning_effort 或 response_format。

档位取自各条精确路由的 `resolveModelInfo`；创建及运行使用宿主 `resolveCallConfig` 检查。没有思考元数据时不杜撰 off/low/high/max/xhigh。「不指定」保留宿主原有默认/继承语义，不代表关闭思考。

手填模型可通过有 token 和来源校验的 `/model` API 查询精确能力；不要求模型出现在目录中。单条模型能力读取失败不会隐藏同供应商后续模型。切换模型清除旧档位，刷新时保留原档位；不再受支持的旧档位会显示提示并阻止提交。异步能力查询与当前路由绑定，旧请求不能把档位应用到已经切换的模型。

这不保证远端凭据有效、服务可用、工具调用实现正确或某个实际模型版本已经验收。当前宿主元数据不能完整证明远端工具能力。独立子会话使用宿主结构化结果工具；没有把纯文本 JSON 猜测为有效结构化结果。

## 已完成验证

1. 最终发布包逐字节匹配源码；解包执行 **76/76** 回归测试，0 失败、0 跳过。包含真实宿主 defineTool / JSON-schema 校验、旧配置继承、独立 reviewer 路由、不同 worker 系列、不同档位、不支持模型/档位在规划前拒绝、复核路由中途失效不回退、持久化、权限与取消等。
2. 真实已安装的 pi-ai 适配器连接本地模拟 HTTP SSE 接口，覆盖 Anthropic Messages、OpenAI Completions 和 Responses。验证工具 schema 的核心结构、结构化工具结果回传、Claude 思考参数及 GPT reasoning 字段；非思考模型不接收前一个模型的档位。虚构模型名不作为真实模型支持声明。
3. 真实已安装的 DeepSeek 专用适配器连接本地模拟 Messages 接口，逐项验证 off / low / high / max 到 thinking / output_config 的映射，确认 xhigh 被拒绝，结构化工具结果正常回传。
4. 协议测试共 8 个本地模拟 HTTP 请求，远程 API 请求为 0。某些协议会规范化工具 schema 的 strict 提示，最终权威 schema 校验仍由宿主结构化工具执行。
5. 无头浏览器检查三张模型卡、独立保存/刷新、手填能力读取、模型切换清理、不支持旧档位保留并拒绝提交、记录展示、报告文本安全与 390px 页面宽度；通过。
6. 嵌入会话的无头浏览器检查准确会话投递、重复提交、伪造确认、忙碌队列、不确定接纳和移动宽度；通过。
7. 客户端构建、语法检查、bundle 与源码一致性；通过。测试仅使用既有浏览器，无可见桌面操作，无安装。

## 发布与生效

- 版本：0.2.3。
- 发布包：[dsh-orchestrator-0.2.3.tgz](<dsh-orchestrator/dist/dsh-orchestrator-0.2.3.tgz>)。
- 大小：79,245 字节，31 个文件。
- SHA-256：`c60e7334f7f17e71cf51831e820d7f48b3601461598d5213accd0cda7b538b50`。
- [发布包验收记录](<dsh-orchestrator/local-validation/package-results-0.2.3.json>)；[设置页验收记录](<dsh-orchestrator/test-artifacts/browser-results.json>)；[嵌入会话验收记录](<dsh-orchestrator/local-validation/session-browser-results.json>)。

已核对已安装插件 Junction 指向这份源码，磁盘 manifest 为 0.2.3。运行中的 DSH 模块可能仍被缓存；需要停止活动编排、完整退出并重启 DSH 后生效。没有自动重启应用，也没有将现有保存的模型路线改成新系列。重启后应在设置页分别选择实际 provider、model 和该模型提供的档位。
