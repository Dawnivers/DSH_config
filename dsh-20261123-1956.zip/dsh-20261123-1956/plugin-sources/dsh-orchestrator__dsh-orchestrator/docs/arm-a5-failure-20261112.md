# arm-a5 编排失败诊断与 v0.2.4 修复

## 结论

本次动画编排在 planner 阶段失败，未进入实施。日志证实供应商返回 `503 No available accounts: no available accounts`，也存在连接错误、无停止原因的流结束和 300000ms 空闲超时。后一次尝试在首次工具调用之前已经发生连接/超时问题，因此不能将全部故障归因为工具结果回传。

本地发现并修复了四项问题：模型运行失败被当作计划内容不合格而重复开 planner；原生 spawn 返回值缺少 diagnostic 时丢失实际错误；已绑定子会话长期持久化为 starting；任务创建 config 只声明任意 JSON，误传序列化字符串时无法在工具参数层明确拒绝。

修复已落地到实际安装目录 junction 指向的插件源码，版本 0.2.4。它修复本地故障处理，不能恢复供应商的账户池，也不能保证真实远端网关已恢复。

## 事故范围

原任务 `e0befaf2-78dd-4a5b-a013-de2ff1fc6383`，运行 `6eb5a91a-d4c6-4c73-9988-28e811799ec5`；同配置重试任务 `2b2bd58c-f9f1-4489-92b1-edf0bae0091a`，运行 `959d113a-1f24-4a8f-8d4d-cce9f2ebd3f2`。

planner 是 worldcode2 / claude-opus-5-5 / high；worker 是 wordcode3 / qwen3.8-flash / low。任务、模型路由、档位、文件范围和已存历史报告均未因本补丁改变。arm-a5 动画目标尚未实现，本次故障修复没有修改其源码。

## 本地实现

- [runner.js](../src/runner.js)：只有已完成的结构化计划不通过 validatePlan 时才使用 maxPlanRetries；模型运行/创建失败直接返回。宿主已有的请求重试策略保持原样，避免在其外面叠加新的 planner 会话。
- [diagnostics.js](../src/diagnostics.js)：优先读取原生 result.diagnostic；缺少时，从绑定 localAgent 的 session.snapshotEvents() 读取最后 turn/end 的错误。终态确实缺失时才读取最近 llm/retry。已成功终止但无 structured_output 的情形给出明确原因。错误查找异常不会遮蔽原错误；输出先做 key/Bearer 脱敏。
- [runner.js](../src/runner.js)：创建回调中即持久化 running 和 startedAt；创建或运行失败均记录 failed、error、endedAt；最终后台进度明确报告失败原因，失败日志写入异常仍释放锁。
- [index.js](../src/index.js)：config 是明确的 object schema，包含 task、项目路径、三角色路由及文件边界字段，旧平铺角色及 adapter 字段继续允许。直接传对象，不支持将对象编码为 JSON 字符串。此次历史调用中，助手实际提交的是字符串；没有证据表明宿主把对象自动转换成了字符串。
- 兼容检查及新报告增加 implementationVersion，在模块加载时读取包版本。这样磁盘上的版本更新不会被误认为正在运行的旧模块已经刷新。

## 协议复核

原有 [native-adapters.test.mjs](../test/native-adapters.test.mjs) 只覆盖单个 user 请求和首次工具调用，没有验证工具完成后的第二次请求。

新增 [anthropic-replay.test.mjs](../test/anthropic-replay.test.mjs) 使用实际安装的 DSH pi-ai 适配器、loopback HTTP SSE 服务和假凭据，验证：

1. 首响应顺序为 reasoning、text、tool-call、reasoning。
2. 第二次请求保留两处 thinking signature、工具调用 ID 与紧邻 user tool_result 的对应关系。
3. 第二响应可正常交付 structured_output，且无 replay degradation warning。
4. 503 No available accounts 被保留为 SERVER 错误。
5. message_start + message_stop 但无 stop_reason 被识别为 TRANSPORT / without a stop reason。
6. message_start 后直接断流被识别为 TRANSPORT / before message_stop。

这些测试未发现本地序列化丢失。但日志没有真实第二次 HTTP 请求体及原始 SSE，因此本地模拟不能排除远端网关对真实签名、continuation 或账户亲和性的额外限制。不对其做推测性配置修改。

## 验证记录

[新增失败路径回归](../test/failure-diagnostics.test.mjs) 在修复前 5/5 失败，能够复现本地问题；修复后针对性 31 项全部通过。随后含实际安装宿主校验与适配器的完整测试为 82 项通过、0 失败、0 跳过。

已执行：

```powershell
$env:DSH_APP_ROOT='D:\DSH\dsh_data\DSH Desktop\resources\app'
node --test test/*.test.mjs
```

修复后打包并从包中解压再运行全部 82 项测试、语法检查和客户端构建一致性检查，全部通过；包内 34 个文件与源码逐字节一致。

- [修复包](../dist/dsh-orchestrator-0.2.4.tgz)：84,860 字节。
- SHA-256：`543af918ce097f70bf42e1c1dd6142668c5252d33e739428f0ab820f71348204`。
- [包验证回执](../local-validation/package-results-0.2.4.json)：exactSourceMatch=true，excludesLocalDataAndCredentials=true。

所有新增协议测试使用本机模拟服务，没有额外付费远端模型探测。

## 生效条件

实际安装路径是 junction，指向本插件工作区，无需在本机重装修复包。但当前 DSH 进程仍保留旧服务端模块：补丁写入后再调用 orchestrate_settings，compatibility 仍只有 ready 和 issues，没有新版 implementationVersion。由此不能宣称新实现已在当前进程生效。

需要完整退出并重启 DSH；仅刷新页面不更新服务端 ESM 模块。重启后 orchestrate_settings 的 compatibility.implementationVersion 应为 0.2.4，新编排报告也应包含相同字段。此处没有重启正在承载本会话的进程，没有启动替代 Web 服务，也没有再次运行付费远端编排。

后续若仍出现 503，需要供应商恢复对应模型账户池；若需要继续定位仅远端可见的第二轮问题，应在供应商恢复后做有界的真实双轮工具验收，不能凭一次 say OK 成功就宣布服务恢复。
