import test from 'node:test';
import assert from 'node:assert/strict';
import { existsSync, readFileSync, writeFileSync } from 'node:fs';
import path from 'node:path';
import { jobConfig, plan, runnerFixture } from './harness.mjs';
import { planWaves, validatePlan, validateJob } from '../src/policy.js';

const ORIGINAL_A = 'export const a = 1;\n';
const ORIGINAL_B = 'export const b = 1;\n';
const workerCalls = f => f.calls.filter(call => call.label.includes(':worker:')).map(call => call.label.split(':')[3]);
const roles = f => f.calls.map(call => call.label.split(':')[2]);

test('planWaves puts consumers after providers and rejects cycles', () => {
  assert.deepEqual(planWaves(plan().tasks), [['a'], ['b']]);
  assert.deepEqual(planWaves(plan().tasks.map(task => ({ ...task, consumes: [] }))), [['a', 'b']]);

  const cyclic = plan().tasks.map(task => structuredClone(task));
  cyclic[0].provides = [{ name: 'a', signature: 'number' }];
  cyclic[0].consumes = [{ name: 'b', from: 'b', signature: 'number' }];
  cyclic[1].provides = [{ name: 'b', signature: 'number' }];
  cyclic[1].consumes = [{ name: 'a', from: 'a', signature: 'number' }];
  assert.throws(() => planWaves(cyclic), /成环/);

  const f = { root: process.cwd() };
  const config = validateJob({ task: 'cycle', projectRoot: f.root, planner: { provider: 'a', model: 'b' }, worker: { provider: 'a', model: 'b' }, allowedGlobs: ['**'] });
  assert.throws(() => validatePlan({ status: 'ready', blockers: [], acceptance: ['x'], tasks: cyclic }, config), /成环/);
});

test('a consumer worker only starts after the provider wrote its file', async () => {
  let sawFreshProvider = false;
  const f = runnerFixture({ beforeResult({ role, task }) {
    if (role === 'worker' && task === 'b') sawFreshProvider = readFileSync(path.join(f.root, 'src/a.js'), 'utf8') === 'export const a = 2;\n';
  } });
  try {
    const job = f.store.create(jobConfig(f.root));
    const report = await f.runner.run(job.id, f.parent, new AbortController().signal).result;
    assert.equal(report.status, 'needs_validation', report.error);
    assert.ok(sawFreshProvider, 'consumer must observe the provider output, not the stale file');
    assert.deepEqual(workerCalls(f), ['a', 'b']);
    assert.deepEqual(report.tasks.map(task => task.status), ['completed', 'completed']);
  } finally { await f.bindings.dispose(); }
});

test('a failed provider skips its consumers and never starts them', async () => {
  const f = runnerFixture({ failWorker: 'a' });
  try {
    const job = f.store.create(jobConfig(f.root));
    const report = await f.runner.run(job.id, f.parent, new AbortController().signal).result;
    assert.equal(report.status, 'failed');
    assert.deepEqual(workerCalls(f), ['a']);
    assert.deepEqual(roles(f), ['planner', 'feasibility', 'worker']);
    assert.deepEqual(report.tasks, [
      { taskId: 'a', status: 'failed', error: report.tasks[0].error },
      { taskId: 'b', status: 'skipped' },
    ]);
    assert.equal(report.review, undefined);
    assert.equal(readFileSync(path.join(f.root, 'src/a.js'), 'utf8'), ORIGINAL_A);
  } finally { await f.bindings.dispose(); }
});

test('a failed task rolls back only its own files while the sibling keeps its work', async () => {
  const independent = plan();
  independent.tasks = [
    { ...independent.tasks[0], consumes: [] },
    { ...independent.tasks[1], id: 'c', files: ['src/b.js'], consumes: [], provides: [] },
  ];
  const f = runnerFixture({
    getPlan: () => independent,
    failWorker: 'c',
    // 让失败任务先真的写盘，才能验证「只回滚它自己的文件」。
    beforeResult({ role, task, fire }) {
      if (role !== 'worker' || task !== 'c') return;
      fire('write', { file_path: path.join(f.root, 'src/b.js') });
      writeFileSync(path.join(f.root, 'src/b.js'), 'export const c = 9; // partial write\n');
    },
  });
  try {
    const job = f.store.create(jobConfig(f.root));
    const report = await f.runner.run(job.id, f.parent, new AbortController().signal).result;
    assert.equal(report.status, 'failed');
    assert.equal(readFileSync(path.join(f.root, 'src/a.js'), 'utf8'), 'export const a = 2;\n', 'sibling work must survive');
    assert.equal(readFileSync(path.join(f.root, 'src/b.js'), 'utf8'), ORIGINAL_B, 'failed task files must be rolled back');
    assert.deepEqual(report.rollback.files.map(item => [item.file, item.action]), [['src/b.js', 'restored']]);
    assert.equal(report.rollback.conflicts, 0);
  } finally { await f.bindings.dispose(); }
});

test('the feasibility route is independent from the worker route and honoured exactly', async () => {
  const f = runnerFixture();
  try {
    const job = f.store.create(jobConfig(f.root, {
      feasibility: { provider: 'cheap', model: 'worker', effort: 'low' },
      worker: { provider: 'cheap', model: 'worker', effort: 'low' },
    }));
    const report = await f.runner.run(job.id, f.parent, new AbortController().signal).result;
    assert.equal(report.status, 'needs_validation', report.error);
    const call = f.calls.find(item => item.label.includes(':feasibility:'));
    assert.deepEqual(call.agentOptions, { provider: 'cheap', model: 'worker', reasoningEffort: 'low' });
    // 显式路由不跟随 planner：只改 planner 不影响复核路由。
    assert.equal(validateJob(jobConfig(f.root, { feasibility: { provider: 'x', model: 'y' } })).feasibility.model, 'y');
  } finally { await f.bindings.dispose(); }
});

const repairPlan = {
  status: 'ready', blockers: [], acceptance: ['clamp is applied'], tasks: [{
    id: 'fix', files: ['src/a.js'], goal: 'apply the clamp', constraints: ['keep the export name'],
    suggestedSteps: [], provides: [], consumes: [],
    feasibility: { status: 'ready', summary: 'the clamp belongs in the existing assignment', evidence: ['src/a.js: read the assignment'], questions: [] },
  }],
};
const issues = { assessment: 'issues_found', summary: 'clamp missing', checks: [{ id: 'clamp', kind: 'static', statement: 'value is clamped', command: '', expected: 'Math.min applied' }] };
const clean = { assessment: 'verified_statically', summary: 'fixed', checks: [{ id: 'run-tests', kind: 'build', statement: '项目测试通过', command: 'npm test', expected: '全部用例通过' }] };

test('reviewer issues trigger one targeted repair round, then a second review', async () => {
  const f = runnerFixture({ getPlan: count => count === 1 ? plan() : repairPlan, getReview: count => count === 0 ? issues : clean });
  try {
    const job = f.store.create(jobConfig(f.root));
    const report = await f.runner.run(job.id, f.parent, new AbortController().signal).result;
    assert.equal(report.status, 'needs_validation', report.error);
    assert.equal(report.children.filter(child => child.role === 'planner').length, 2);
    assert.equal(report.children.filter(child => child.role === 'reviewer').length, 2);
    assert.equal(report.repair.round, 1);
    assert.deepEqual(report.repair.workers.map(worker => worker.status), ['completed']);
    assert.equal(report.repair.review.assessment, 'verified_statically');
    assert.equal(report.review.assessment, 'verified_statically');
    assert.ok(report.repair.snapshot.directory.endsWith('repair-1'));
    assert.ok(existsSync(path.join(report.repair.snapshot.directory, 'manifest.json')));
    assert.equal(readFileSync(path.join(f.root, 'src/a.js'), 'utf8'), 'export const fix = 2;\n');
    assert.ok(report.events.some(event => event.stage === 'repair'));
    // 修复阶段的快照记录在报告里，回滚时也按阶段逆序处理。
    assert.equal(report.snapshots.length, 2);
  } finally { await f.bindings.dispose(); }
});

test('arm-a13 回归：修复轮复核里的主会话计费条目不再把整轮判死', async () => {
  // 真实事故形状：修复轮的 reviewer 把用户目标里的「记录各模型调用与费用」写成
  // kind=data 且 command=""（它确实只能由主会话做）。旧契约直接抛错，整轮 19 分钟的
  // 成果被判 failed；现在只降级那一条，结论与文件都保留。
  const billingReview = {
    assessment: 'verified_statically', summary: '修复有效；计费记录归主会话',
    checks: [
      { id: 'swim-sign', kind: 'static', statement: '符号已翻转', command: '', expected: 'p.x +=', owner: 'main' },
      { id: 'billing-board', kind: 'data', statement: '记录各模型调用与费用', command: '', expected: '主会话从计费板核对' },
    ],
  };
  const f = runnerFixture({ getPlan: count => count === 1 ? plan() : repairPlan, getReview: count => count === 0 ? issues : billingReview });
  try {
    const job = f.store.create(jobConfig(f.root));
    const report = await f.runner.run(job.id, f.parent, new AbortController().signal).result;
    assert.equal(report.status, 'needs_validation', report.error);
    assert.equal(report.repair.status, 'completed');
    assert.equal(report.repair.error, undefined, '不该再落 repair 失败');
    assert.equal(report.repair.review.checks.length, 2, '降级不能丢条目');
    assert.deepEqual(report.repair.review.checks.map(check => check.status), ['ok', 'unverifiable']);
    assert.equal(report.repair.review.checks[0].owner, 'main', '显式 owner="main" 的条目完全合法');
    assert.equal(report.repair.review.degraded.length, 1);
    assert.ok(report.events.some(event => event.stage === 'review-degraded'));
    // 修复轮的哈希必须进最终清单：修复失败时清单会停在首轮哈希。
    const mergedA = report.files.find(item => item.file === 'src/a.js');
    const repairA = report.repair.files.find(item => item.file === 'src/a.js');
    assert.ok(mergedA && repairA, '最终清单与修复阶段都要有 src/a.js');
    assert.notEqual(mergedA.after, mergedA.before, '清单必须反映修复后的磁盘内容');
    assert.equal(mergedA.after, repairA.after, '最终清单与修复阶段哈希一致');
    assert.equal(mergedA.changed, true);
    assert.equal(readFileSync(path.join(f.root, 'src/a.js'), 'utf8'), 'export const fix = 2;\n');
  } finally { await f.bindings.dispose(); }
});

test('a repair plan that reports blocked keeps the review result and stops', async () => {
  const blocked = { status: 'blocked', blockers: ['需要实测才能判定'], acceptance: ['clamp is applied'], tasks: [] };
  const f = runnerFixture({ getPlan: count => count === 1 ? plan() : blocked, getReview: () => issues });
  try {
    const job = f.store.create(jobConfig(f.root));
    const report = await f.runner.run(job.id, f.parent, new AbortController().signal).result;
    assert.equal(report.status, 'review_failed');
    assert.equal(report.repair.status, 'blocked');
    assert.deepEqual(report.repair.blockers, ['需要实测才能判定']);
    assert.equal(report.children.filter(child => child.role === 'reviewer').length, 1);
    assert.ok(report.events.some(event => event.stage === 'repair-skipped'));
  } finally { await f.bindings.dispose(); }
});

test('an invalid repair plan keeps the reviewed work and only marks the repair as failed', async () => {
  const illegal = structuredClone(repairPlan);
  illegal.tasks[0].files = ['node_modules/evil.js'];   // 越出 allowedGlobs 与内部目录禁令
  const f = runnerFixture({ getPlan: count => count === 1 ? plan() : illegal, getReview: () => issues });
  try {
    const job = f.store.create(jobConfig(f.root));
    const report = await f.runner.run(job.id, f.parent, new AbortController().signal).result;
    assert.equal(report.status, 'review_failed');
    assert.equal(report.repair.status, 'failed');
    assert.match(report.repair.error, /允许范围|内部目录|文件名/);
    assert.ok(report.events.some(event => event.stage === 'repair-failed'));
    // 第一次实施与复核的成果保留在盘上。
    assert.equal(readFileSync(path.join(f.root, 'src/a.js'), 'utf8'), 'export const a = 2;\n');
    assert.equal(report.snapshots.length, 1);
  } finally { await f.bindings.dispose(); }
});

test('a failing repair task rolls back only the repair writes and fails the run', async () => {
  const f = runnerFixture({
    getPlan: count => count === 1 ? plan() : repairPlan,
    getReview: () => issues,
    failWorker: 'fix',
    beforeResult({ role, task, fire }) {
      if (role !== 'worker' || task !== 'fix') return;
      fire('write', { file_path: path.join(f.root, 'src/a.js') });
      writeFileSync(path.join(f.root, 'src/a.js'), 'export const fix = 9; // partial repair\n');
    },
  });
  try {
    const job = f.store.create(jobConfig(f.root));
    const report = await f.runner.run(job.id, f.parent, new AbortController().signal).result;
    assert.equal(report.status, 'failed');
    assert.deepEqual(report.repair.workers.map(worker => worker.status), ['failed']);
    // 第一阶段成果保留，修复阶段写了一半的内容被回滚。
    assert.equal(readFileSync(path.join(f.root, 'src/a.js'), 'utf8'), 'export const a = 2;\n');
    assert.deepEqual(report.rollback.files.map(item => [item.file, item.action]), [['src/a.js', 'restored']]);
  } finally { await f.bindings.dispose(); }
});

test('maxRepairRounds=0 keeps the old single-review behaviour', async () => {
  const f = runnerFixture({ getReview: () => issues });
  try {
    const job = f.store.create(jobConfig(f.root, { maxRepairRounds: 0 }));
    const report = await f.runner.run(job.id, f.parent, new AbortController().signal).result;
    assert.equal(report.status, 'review_failed');
    assert.equal(report.repair, undefined);
    assert.equal(report.children.filter(child => child.role === 'reviewer').length, 1);
    assert.equal(report.children.filter(child => child.role === 'planner').length, 1);
  } finally { await f.bindings.dispose(); }
});

test('job config defaults maxRepairRounds to 1 and bounds it to 0..2', () => {
  const f = runnerFixture();
  assert.equal(jobConfig(f.root).maxRepairRounds, 1);
  assert.throws(() => jobConfig(f.root, { maxRepairRounds: 3 }), /定向修复轮数/);
  assert.throws(() => jobConfig(f.root, { maxRepairRounds: -1 }), /定向修复轮数/);
});
