import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import { page } from '../src/ui.js';

// Execute the actual serialized renderer with a minimal text-only DOM harness.
// No browser dependency or client build is needed for these diagnostics.
function runtimeView(runtime) {
  const html = page();
  const source = html.slice(html.indexOf('  function renderRuntime('), html.indexOf('  async function loadState('));
  class Node {
    constructor(tag, text = '', className = '') { this.tag = tag; this.textContent = String(text); this.className = className; this.children = []; }
    append(...nodes) { this.children.push(...nodes); }
    replaceChildren(...nodes) { this.textContent = ''; this.children = nodes; }
    get text() { return this.textContent + this.children.map(node => node.text).join('\n'); }
  }
  const host = new Node('div');
  const el = (tag, text, className) => new Node(tag, text, className);
  const kv = (list, label, value) => list.append(el('dt', label), el('dd', value));
  vm.runInNewContext(source + '\nrenderRuntime(runtime);', {
    runtime, el, kv, $: id => { assert.equal(id, 'runtimeCode'); return host; },
  });
  return { host, source };
}

const identity = {
  buildId: 'build-123', loadedAt: '2026-11-19T08:00:00.000Z', pid: 1234,
  sourceMatches: true, staleModules: [], features: { reviewRetry: true }, modules: [],
};

test('settings runtime diagnostics are wired to the state compatibility identity', () => {
  const html = page();
  assert.match(html, /id="runtimeTitle">运行时代码/);
  assert.match(html, /id="runtimeCode"[^>]*>当前实例未提供运行时标识，无法确认/);
  assert.match(html, /renderRuntime\(state\.compatibility && state\.compatibility\.runtime\)/);
  new vm.Script(html.match(/<script>([\s\S]*)<\/script>/)[1]);
});

test('missing or partial identity is explicitly unknown, never assumed latest or supported', () => {
  for (const runtime of [undefined, null, {}, { ...identity, buildId: undefined }, { ...identity, sourceMatches: undefined }, { ...identity, features: undefined }]) {
    const { host } = runtimeView(runtime);
    assert.match(host.text, /当前实例未提供运行时标识，无法确认/);
    assert.doesNotMatch(host.text, /最新/);
  }
  const { host } = runtimeView({ ...identity, sourceMatches: undefined, features: {} });
  assert.match(host.text, /磁盘一致性\n未提供，无法确认/);
  assert.match(host.text, /reviewRetry\n未提供，无法确认/);
  assert.doesNotMatch(host.text, /reviewRetry\n支持/);
});

test('loaded identity displays exact build, module load time, PID, consistency and feature support', () => {
  const { host } = runtimeView(identity);
  for (const value of ['build-123', identity.loadedAt, '1234', '磁盘一致性\n一致', 'reviewRetry\n支持']) assert.ok(host.text.includes(value));
  assert.doesNotMatch(host.text, /无法确认|完整退出/);
  assert.match(runtimeView({ ...identity, features: { reviewRetry: false } }).host.text, /reviewRetry\n不支持/);
});

test('source mismatch advises complete host exit and restart without blaming prior restarts', () => {
  const { host } = runtimeView({ ...identity, sourceMatches: false, staleModules: ['runner.js', 'ui.js'] });
  assert.match(host.text, /磁盘一致性\n不一致/);
  assert.match(host.text, /完整退出宿主（包括后台进程）后重新启动/);
  assert.match(host.text, /再刷新此处确认运行时标识与磁盘一致性/);
  assert.match(host.text, /不一致模块：runner\.js、ui\.js/);
  assert.doesNotMatch(host.text, /没有重启|未重启|自动重启/);
});

test('runtime rendering uses text-only nodes and excludes unrelated token properties', () => {
  const attack = '<img src=x onerror=alert(1)>';
  const { host, source } = runtimeView({ ...identity, buildId: attack, sourceMatches: false, staleModules: [attack], token: 'do-not-show-secret', features: { reviewRetry: true, token: 'feature-secret' }, modules: [{ token: 'module-secret' }] });
  assert.ok(host.text.includes(attack), 'untrusted values remain literal text');
  assert.doesNotMatch(host.text, /do-not-show-secret|feature-secret|module-secret/);
  assert.doesNotMatch(source, /innerHTML|outerHTML|insertAdjacentHTML|\btoken\b|JSON\.stringify|fetch\(|api\(/);
});
