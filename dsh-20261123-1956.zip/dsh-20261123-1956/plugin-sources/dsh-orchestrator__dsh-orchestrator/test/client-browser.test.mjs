import test from 'node:test';
import assert from 'node:assert/strict';
import { randomUUID } from 'node:crypto';
import { clientFactory } from '../src/client.js';

test('session button opens only scoped external URLs, reuses configuration and monitor bridges, and disposes owners',async()=>{
 const original={window:globalThis.window,fetch:globalThis.fetch};
 const states=[],slots=[],opens=[],requests=[];let cursor=0,created=0;
 const origin='http://127.0.0.1:64260',settingsToken='admin-secret',taskId=randomUUID();
 const React={Fragment:'fragment',createElement:(type,props,...children)=>({type,props:props||{},children:children.flat().filter(Boolean)}),useState:value=>{const key=cursor++;if(!(key in states))states[key]=value;return[states[key],next=>{states[key]=next}]},useRef:value=>({current:value}),useEffect() {}};
 const client=clientFactory(()=>React,()=> '');
 globalThis.window={location:{href:origin+'/',origin},__DSH_ORCHESTRATOR_SETTINGS__:{url:origin+'/dsh-orchestrator/settings?token='+settingsToken},open:(...args)=>opens.push(args)};
 globalThis.fetch=async(url,options)=>{
  const route=new URL(url).pathname.split('/').slice(-2).join('/'),input=JSON.parse(options.body);requests.push({route,input});
  let data;
  if(route==='bridge/open'){created++;const bridgeId=randomUUID();data={bridgeId,ownerToken:'owner-'+created,browserToken:'browser-'+created,expiresAt:new Date(Date.now()+3600000).toISOString(),url:origin+'/dsh-orchestrator/settings?token=browser-'+created+'&bridge='+bridgeId};}
  else if(route==='bridge/poll')data={sessionId:'session-a',requests:[],expiresAt:new Date(Date.now()+3600000).toISOString()};
  else if(route==='bridge/close')data={closed:true};else throw Error('unexpected '+route);
  return{ok:true,json:async()=>data};
 };
 const dispose=client.apply({slots:{inject:(_name,fn)=>fn(),register:(spec,component)=>slots.push({spec,component})},sessions:{binding:()=>({session:{prompt:async()=>({ok:true})}}),list:{getSnapshot:()=>({byId:{'session-a':{displayTitle:'A',cwd:'D:/project-a'}}})}}});
 const props={...slots[1].spec.inject('session-a'),sessionId:'session-a',useSession:()=>false};
 const render=()=>{cursor=0;return client.SessionAction(props)};
 try{
  let view=render();assert.equal(opens.length,0);assert.equal(created,0);
  await view.children.find(n=>n.type==='button').props.onClick();
  view=render();await view.children.find(n=>n.type==='button').props.onClick();assert.equal(created,1);assert.equal(opens.length,2);
  for(const [url,target,features] of opens){assert.ok(!url.includes(settingsToken));assert.equal(new URL(url).searchParams.get('token'),'browser-1');assert.equal(target,'_blank');assert.match(features,/noopener/)}
  states[3]=taskId;view=render();await view.children.find(n=>n.type==='button'&&n.props.title.includes('本会话运行')).props.onClick();
  view=render();await view.children.find(n=>n.type==='button'&&n.props.title.includes('本会话运行')).props.onClick();assert.equal(created,2,'same task monitor reuses one owner');
  view=render();await view.children.find(n=>n.props['aria-label']==='断开浏览器连接').props.onClick();
  assert.equal(requests.filter(r=>r.route==='bridge/close').length,2);assert.ok(requests.filter(r=>r.route==='bridge/open').every(r=>r.input.sessionId==='session-a'));
 }finally{dispose();for(const [key,value]of Object.entries(original)){if(value===undefined)delete globalThis[key];else globalThis[key]=value}}
});
