// 复核契约的回归：结论三档语义、checks 结构化、旧记录兼容、状态映射。
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { REVIEW_SCHEMA, ASSESSMENTS, REVIEWER_ASSESSMENTS, CHECK_KINDS, CHECK_OWNERS, COMMAND_KINDS, validateReview, reviewStatus, checkLines } from '../src/review.js';
import { reviewerPrompt } from '../src/prompts.js';

const job = { projectRoot: '/tmp/p', task: 't', allowedGlobs: ['src/**'], protectedFiles: [], allowProtected: false };
const plan = { tasks: [], acceptance: [] };
const check = (over = {}) => ({ id: 'c1', kind: 'build', statement: '构建通过', command: 'npm run build', expected: 'exit 0', ...over });

test('reviewer 只能下三档结论；断言放行与数据阻塞由插件下', () => {
  assert.deepEqual(REVIEWER_ASSESSMENTS, ['verified_statically', 'issues_found', 'unable_to_verify']);
  assert.deepEqual(ASSESSMENTS, [...REVIEWER_ASSESSMENTS, 'passed_by_assertions', 'blocked_by_data']);
  // 关键：模型不能自称断言放行，否则可以绕过实测直接给出通过结论。
  assert.ok(!REVIEW_SCHEMA.properties.assessment.enum.includes('passed_by_assertions'));
  assert.ok(!REVIEW_SCHEMA.properties.assessment.enum.includes('blocked_by_data'));
  assert.ok(!REVIEW_SCHEMA.properties.assessment.enum.includes('ready_for_validation'));
  const legacy = validateReview({ assessment: 'ready_for_validation', summary: 's', checks: [check()] });
  assert.equal(legacy.assessment, 'verified_statically');
  assert.equal(legacy.legacyAssessment, 'ready_for_validation');
});

test('新结论不回填 legacyAssessment，历史值不被改写', () => {
  const fresh = validateReview({ assessment: 'verified_statically', summary: 's', checks: [check()] });
  assert.equal(fresh.legacyAssessment, null);
});

test('非法或缺失的 assessment 直接拒绝，不猜', () => {
  for (const assessment of [undefined, null, '', 'ok', 'passed', 'ISSUES_FOUND', 1]) {
    assert.throws(() => validateReview({ assessment, summary: 's', checks: [check()] }), /复核结论无效/);
  }
});

test('summary 必填且不能只给空白', () => {
  assert.throws(() => validateReview({ assessment: 'issues_found', checks: [check()] }), /缺少 summary/);
  assert.throws(() => validateReview({ assessment: 'issues_found', summary: '   ', checks: [check()] }), /缺少 summary/);
  assert.throws(() => validateReview({ assessment: 'issues_found', summary: 'x'.repeat(4001), checks: [check()] }), /过长/);
});

test('verified_statically 仍须列出待验证项，避免伪装成万事俱备', () => {
  assert.throws(() => validateReview({ assessment: 'verified_statically', summary: 's', checks: [] }), /仍需列出主会话待验证项/);
  assert.throws(() => validateReview({ assessment: 'verified_statically', summary: 's' }), /仍需列出主会话待验证项/);
});

test('issues_found 至少要给出一个可定位条目', () => {
  assert.throws(() => validateReview({ assessment: 'issues_found', summary: 's', checks: [] }), /至少要给出一个具体问题条目/);
  const ok = validateReview({ assessment: 'issues_found', summary: 's', checks: [check({ kind: 'static', command: '' })] });
  assert.equal(ok.checks.length, 1);
});

test('unable_to_verify 允许空 checks，因为它表达的就是无法判定', () => {
  const result = validateReview({ assessment: 'unable_to_verify', summary: '需要宿主环境才能确认', checks: [] });
  assert.equal(result.assessment, 'unable_to_verify');
  assert.deepEqual(result.checks, []);
});

test('checks 的 kind 未知或带多余字段时降级保留，不再整轮失败', () => {
  const unknownKind = validateReview({ assessment: 'issues_found', summary: 's', checks: [check({ kind: 'smoke' })] });
  assert.equal(unknownKind.checks[0].status, 'unverifiable');
  assert.match(unknownKind.checks[0].issue, /kind 无效/);
  assert.equal(unknownKind.checks[0].kind, 'smoke', '保留模型原话，不猜测成别的 kind');

  const extra = validateReview({ assessment: 'issues_found', summary: 's', checks: [{ ...check(), note: 'x' }] });
  assert.equal(extra.checks[0].status, 'unverifiable');
  assert.match(extra.checks[0].issue, /未知字段 note/);
  assert.equal(extra.checks[0].command, 'npm run build', '多余字段被丢弃，其余字段照常可用');
  assert.deepEqual(CHECK_KINDS, ['build', 'runtime', 'visual', 'static', 'data', 'process']);
  assert.deepEqual(CHECK_OWNERS, ['run', 'main']);
  assert.deepEqual(COMMAND_KINDS, ['build', 'runtime', 'data']);
});

test('build / runtime / data 缺 command 时降级为 unverifiable，不再让整轮失败', () => {
  for (const kind of ['build', 'runtime', 'data']) {
    const missing = validateReview({ assessment: 'issues_found', summary: 's', checks: [check({ kind, command: '' })] });
    assert.equal(missing.assessment, 'issues_found', '结论不变，只有条目降级');
    assert.equal(missing.checks[0].status, 'unverifiable');
    assert.match(missing.checks[0].issue, /没有可执行 command/);
    assert.equal(missing.degraded.length, 1);
    assert.equal(missing.degraded[0].id, 'c1');

    const undefinedCommand = validateReview({ assessment: 'issues_found', summary: 's', checks: [{ ...check({ kind }), command: undefined }] });
    assert.equal(undefinedCommand.checks[0].status, 'unverifiable');
  }
  // visual / static / process 允许人工执行，command 可空且不算降级
  for (const kind of ['visual', 'static', 'process']) {
    const ok = validateReview({ assessment: 'issues_found', summary: 's', checks: [check({ kind, command: '' })] });
    assert.equal(ok.checks[0].command, '');
    assert.equal(ok.checks[0].status, 'ok');
    assert.deepEqual(ok.degraded, []);
  }
});

test('owner="main" 的条目允许没有 command，这是如实标注而不是缺陷', () => {
  const own = validateReview({
    assessment: 'issues_found', summary: 's',
    checks: [check({ id: 'billing-board', kind: 'data', command: '', owner: 'main' })],
  });
  assert.equal(own.checks[0].status, 'ok');
  assert.equal(own.checks[0].owner, 'main');
  assert.deepEqual(own.degraded, []);
  // 不填 owner 时按 run 处理，历史输出不受影响
  const implicit = validateReview({ assessment: 'issues_found', summary: 's', checks: [check({ kind: 'static', command: '' })] });
  assert.equal(implicit.checks[0].owner, 'run');
  // 乱填 owner 降级并回落到 run
  const bad = validateReview({ assessment: 'issues_found', summary: 's', checks: [check({ kind: 'data', command: '', owner: 'reviewer' })] });
  assert.equal(bad.checks[0].owner, 'run');
  assert.equal(bad.checks[0].status, 'unverifiable');
  assert.match(bad.checks[0].issue, /owner 无效/);
});

test('id 缺失或重复时自动编号并降级，statement / expected 为空也不抛错', () => {
  const noId = validateReview({ assessment: 'issues_found', summary: 's', checks: [check({ id: '  ' })] });
  assert.equal(noId.checks[0].id, 'check-1');
  assert.equal(noId.checks[0].status, 'unverifiable');
  assert.match(noId.checks[0].issue, /缺少 id/);

  const dup = validateReview({ assessment: 'issues_found', summary: 's', checks: [check(), check()] });
  assert.equal(dup.checks[1].id, 'c1-2');
  assert.equal(dup.checks[1].status, 'unverifiable');
  assert.match(dup.checks[1].issue, /id 重复/);

  for (const key of ['statement', 'expected']) {
    const empty = validateReview({ assessment: 'issues_found', summary: 's', checks: [check({ [key]: '   ' })] });
    assert.equal(empty.checks[0].status, 'unverifiable');
    assert.match(empty.checks[0].issue, new RegExp(`${key} 为空`));
    assert.ok(empty.checks[0][key], `${key} 必须有占位文案，否则界面会显示空白`);
  }
});

test('信封级错误仍然失败关闭：结论无效、缺 summary、checks 不是数组', () => {
  assert.throws(() => validateReview({ assessment: 'passed', summary: 's', checks: [check()] }), /复核结论无效/);
  assert.throws(() => validateReview({ assessment: 'issues_found', summary: '', checks: [check()] }), /缺少 summary/);
  assert.throws(() => validateReview({ assessment: 'issues_found', summary: 's', checks: 'x' }), /checks 必须是数组/);
  assert.throws(() => validateReview({ assessment: 'issues_found', summary: 's', checks: Array.from({ length: 41 }, (_, i) => check({ id: 'c' + i })) }), /超过 40 项/);
});

test('arm-a13 回归：修复轮把「计费记录」写成 data + 空 command 时，整轮不再失败', () => {
  // 真实事故条目，字段原样照抄。
  const billing = {
    id: 'billing-board', kind: 'data', command: '',
    statement: '补齐用户要求的模型调用与耗费金额记录，并确认其不被错误写入目标页面或源码。',
    expected: '主会话从 DSH 计费板读取本轮各模型调用、token 与金额并完成记录；源码和页面不得新增计费/token/模型统计功能。本轮无法从项目文件验证计费板数据。',
  };
  const result = validateReview({ assessment: 'issues_found', summary: 's', checks: [billing] });
  assert.equal(result.assessment, 'issues_found', '结论本身有效，不能被一条格式问题吃掉');
  assert.equal(result.checks.length, 1);
  assert.equal(result.checks[0].status, 'unverifiable');
  // 同一个条目在补上 owner="main" 后应当是完全合法的
  const declared = validateReview({ assessment: 'issues_found', summary: 's', checks: [{ ...billing, owner: 'main' }] });
  assert.equal(declared.checks[0].status, 'ok');
  assert.deepEqual(declared.degraded, []);
});

test('degraded 汇总与 issue 文案：降级不改变条目顺序，也不丢条目', () => {
  const result = validateReview({
    assessment: 'issues_found', summary: 's',
    checks: [check({ id: 'a' }), check({ id: 'b', kind: 'data', command: '' }), check({ id: 'c', kind: 'static', command: '' })],
  });
  assert.deepEqual(result.checks.map(item => item.id), ['a', 'b', 'c']);
  assert.deepEqual(result.checks.map(item => item.status), ['ok', 'unverifiable', 'ok']);
  assert.equal(result.degraded.length, 1);
  assert.match(result.degraded[0].issue, /data/);
});

test('checks 数量上限与类型校验', () => {
  const many = Array.from({ length: 41 }, (_, i) => check({ id: 'c' + i }));
  assert.throws(() => validateReview({ assessment: 'issues_found', summary: 's', checks: many }), /超过 40 项/);
  assert.throws(() => validateReview({ assessment: 'issues_found', summary: 's', checks: 'x' }), /checks 必须是数组/);
  // 不是对象的那一项占位保留，不牵连其余条目
  const junk = validateReview({ assessment: 'issues_found', summary: 's', checks: ['x', check({ id: 'good' })] });
  assert.deepEqual(junk.checks.map(item => item.id), ['check-1', 'good']);
  assert.equal(junk.checks[0].status, 'unverifiable');
  assert.equal(junk.checks[1].status, 'ok');
  assert.match(junk.checks[0].issue, /不是对象/);
});

test('校验是纯归一，不改动调用方对象', () => {
  const input = { assessment: 'issues_found', summary: ' s ', checks: [check({ statement: ' 构建通过 ' })] };
  const snapshot = JSON.parse(JSON.stringify(input));
  const result = validateReview(input);
  assert.deepEqual(input, snapshot);
  assert.equal(result.summary, 's');
  assert.equal(result.checks[0].statement, '构建通过');
});

test('状态映射：只有 issues_found 判复核失败，其余都需要项目验证', () => {
  assert.equal(reviewStatus({ assessment: 'issues_found' }), 'review_failed');
  for (const assessment of ['verified_statically', 'unable_to_verify']) {
    assert.equal(reviewStatus({ assessment }), 'needs_validation');
  }
});

test('checkLines 输出扁平清单，含 kind / 预期 / 命令', () => {
  const lines = checkLines(validateReview({ assessment: 'issues_found', summary: 's', checks: [check()] }).checks);
  assert.equal(lines.length, 1);
  assert.match(lines[0], /^c1 \[build\] 构建通过/);
  assert.match(lines[0], /预期：exit 0/);
  assert.match(lines[0], /命令：npm run build/);
});

test('checkLines 标出主会话专用与已降级条目，主会话不必自己猜', () => {
  const result = validateReview({
    assessment: 'issues_found', summary: 's',
    checks: [
      check({ id: 'billing', kind: 'data', command: '', owner: 'main' }),
      check({ id: 'broken', kind: 'data', command: '' }),
    ],
  });
  const lines = checkLines(result.checks);
  assert.match(lines[0], /归属：主会话（不可自动执行）/);
  assert.match(lines[1], /已降级：.*没有可执行 command/);
});

test('reviewer 提示词要求三档语义、禁止把静态复核说成已验证、command 复用现有脚本', () => {
  const text = reviewerPrompt(job, plan, [], []);
  for (const token of ['verified_statically', 'issues_found', 'unable_to_verify', 'checks', 'kind', 'expected', 'command']) {
    assert.ok(text.includes(token), `提示词缺少 ${token}`);
  }
  assert.match(text, /不能运行构建、shell、浏览器或网络/);
  assert.match(text, /不要把静态复核说成已验证/);
  assert.match(text, /不要编造不存在的脚本名/);
  // owner 契约与 schema 原文必须真的进提示词，否则模型只能靠猜
  assert.ok(text.includes('owner'), '提示词缺少 owner 契约');
  assert.match(text, /只有主会话能做/);
  assert.match(text, /"owner":\{"type":"string","enum":\["run","main"\]\}/, '提示词必须内嵌含 owner 的 schema 原文');
  assert.match(text, /降级成 unverifiable/);
  // 旧提示词里那套模糊口径必须消失
  assert.ok(!text.includes('checksNeeded'), '不应再要求旧的 checksNeeded 字段');
});
