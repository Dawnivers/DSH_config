import test from 'node:test';
import assert from 'node:assert/strict';
import { randomUUID } from 'node:crypto';
import { createBrowserBridge, secretEquals } from '../src/browser-bridge.js';
import { clientFactory } from '../src/client.js';

function fixture(options={}) {
 let time=1000;const statuses=new Map(),tasks=new Map();
 const store={status:id=>statuses.get(id)||{},get:id=>tasks.get(id)};
 const bridge=createBrowserBridge({store,now:()=>time,...options});
 const a=bridge.open({sessionId:'session-a',sessionTitle:'A',workspaceRoot:'D:/project-a'});
 const b=bridge.open({sessionId:'session-b',sessionTitle:'B',workspaceRoot:'D:/project-b'});
 const create=async(id=a.bridgeId,config={task:'safe'})=>bridge.createJob(id,config,()=>{const job={id:randomUUID(),...config};tasks.set(job.id,job);statuses.set(job.id,{status:'queued'});return job});
 return {bridge,a,b,create,statuses,advance:n=>{time+=n}};
}

test('browser boot/status never expose the original-session receipt secret',()=>{
 const f=fixture();const boot=f.bridge.boot(f.a.bridgeId),state=f.bridge.status(f.a.bridgeId);
 assert.equal(boot.detached,true);assert.equal(boot.sessionId,'session-a');
 assert.equal(boot.workspaceRoot,'D:/project-a');assert.equal(state.connected,false);
 assert.ok(!JSON.stringify({boot,state}).includes(f.a.ownerToken));
 assert.equal(secretEquals('汉'.repeat(64),f.a.ownerToken),false);
});

test('a browser can submit only its own created task and needs a live original page',async()=>{
 const f=fixture(),task=await f.create();
 assert.throws(()=>f.bridge.submit(f.a.bridgeId,task.id),/原 DSH 会话页面暂未连接/);
 f.bridge.poll(f.a.bridgeId,f.a.ownerToken);
 assert.throws(()=>f.bridge.submit(f.b.bridgeId,task.id),/只能提交此浏览器连接创建的任务/);
 assert.throws(()=>f.bridge.submit(f.a.bridgeId,'../other'),/只能提交/);
 assert.equal(f.bridge.submit(f.a.bridgeId,task.id).deliveries[0].status,'pending');
 assert.throws(()=>f.bridge.poll(f.a.bridgeId,f.b.ownerToken),/凭据无效/);
 f.advance(120001);assert.equal(f.bridge.status(f.a.bridgeId).connected,false);
});

test('lost creation responses and concurrent clicks create exactly one task per configuration',async()=>{
 const f=fixture();let creates=0;const run=()=>f.bridge.createJob(f.a.bridgeId,{task:'same'},async()=>{creates++;await Promise.resolve();const id=randomUUID();return{id}});
 const [one,two]=await Promise.all([run(),run()]);assert.equal(one.id,two.id);assert.equal(creates,1);assert.equal((await run()).id,one.id);
});

test('only owner-confirmed rejections can retry; sent/uncertain requests never enqueue again',async()=>{
 const f=fixture(),task=await f.create();f.bridge.poll(f.a.bridgeId,f.a.ownerToken);
 f.bridge.submit(f.a.bridgeId,task.id);const claimed=f.bridge.poll(f.a.bridgeId,f.a.ownerToken);
 assert.equal(claimed.requests[0].attempt,1);
 assert.throws(()=>f.bridge.settle(f.a.bridgeId,'fake',task.id,{ok:true},1),/凭据无效/);
 f.bridge.settle(f.a.bridgeId,f.a.ownerToken,task.id,{ok:false,error:'conversation.send failed: closed'},1);
 f.bridge.submit(f.a.bridgeId,task.id);assert.equal(f.bridge.poll(f.a.bridgeId,f.a.ownerToken).requests[0].attempt,2);
 assert.throws(()=>f.bridge.settle(f.a.bridgeId,f.a.ownerToken,task.id,{ok:true},1),/尚未交给原会话/);
 f.bridge.settle(f.a.bridgeId,f.a.ownerToken,task.id,{ok:true,queued:true},2);
 assert.equal(f.bridge.submit(f.a.bridgeId,task.id).deliveries[0].status,'sent');
 assert.deepEqual(f.bridge.poll(f.a.bridgeId,f.a.ownerToken).requests,[]);
 assert.throws(()=>f.bridge.settle(f.a.bridgeId,f.a.ownerToken,task.id,{ok:false},2),/拒绝覆盖/);
 const task2=await f.create(f.a.bridgeId,{task:'uncertain'});f.bridge.submit(f.a.bridgeId,task2.id);f.bridge.poll(f.a.bridgeId,f.a.ownerToken);
 f.bridge.settle(f.a.bridgeId,f.a.ownerToken,task2.id,{ok:false,uncertain:true},1);
 assert.equal(f.bridge.submit(f.a.bridgeId,task2.id).deliveries.find(d=>d.taskId===task2.id).status,'uncertain');
 assert.deepEqual(f.bridge.poll(f.a.bridgeId,f.a.ownerToken).requests,[]);
});

test('expiry, admission caps, invalid targets, foreign monitor tasks, and disposal fail closed',async()=>{
 const f=fixture({maxBridges:2,ttlMs:100});
 assert.throws(()=>f.bridge.open({sessionId:'session-c'}),/上限/);
 assert.throws(()=>f.bridge.open({sessionId:'../escape'}),/有效目标会话/);
 f.advance(101);assert.throws(()=>f.bridge.boot(f.a.bridgeId),/已失效/);
 const c=f.bridge.open({sessionId:'session-c'}),id=randomUUID();f.statuses.set(id,{parentSession:'session-other'});
 assert.throws(()=>f.bridge.open({sessionId:'session-c',monitorTaskId:id}),/不属于目标会话/);
 f.bridge.dispose();assert.throws(()=>f.bridge.status(c.bridgeId),/已失效/);
});

test('actual browser relay round-trip sends once to exact original session even after lost acknowledgements',async()=>{
 const f=fixture(),task=await f.create();let sends=0,loseAck=true;
 const client=clientFactory(()=>({createElement(){}}),()=>'');
 const request=async(route,input)=>{
  if(route==='bridge/poll')return f.bridge.poll(input.bridgeId,input.ownerToken);
  if(route==='bridge/result'){if(loseAck){loseAck=false;throw Error('ack transport lost')}return f.bridge.settle(input.bridgeId,input.ownerToken,input.taskId,input.result,input.attempt)}
  throw Error('unexpected route');
 };
 const owner=client.createDetachedOwner({sessionId:'session-a',bridgeId:f.a.bridgeId,ownerToken:f.a.ownerToken,request,ledger:new Map(),send:async(prompt,id)=>{sends++;assert.equal(id,task.id);assert.match(prompt,/orchestrate_run/);assert.match(prompt,new RegExp(task.id))}});
 await owner.pollOnce();f.bridge.submit(f.a.bridgeId,task.id);
 await assert.rejects(owner.pollOnce(),/ack transport lost/);
 await owner.pollOnce();await owner.pollOnce();
 assert.equal(sends,1);assert.equal(f.bridge.status(f.a.bridgeId).deliveries[0].status,'sent');owner.stop();
});

test('a repeated explicit rejection is not resent until browser deliberately requests another attempt',async()=>{
 const f=fixture(),task=await f.create();let sends=0,loseAck=true;
 const client=clientFactory(()=>({createElement(){}}),()=> '');
 const request=async(route,i)=>{if(route==='bridge/poll')return f.bridge.poll(i.bridgeId,i.ownerToken);if(loseAck){loseAck=false;throw Error('lost receipt')}return f.bridge.settle(i.bridgeId,i.ownerToken,i.taskId,i.result,i.attempt)};
 const owner=client.createDetachedOwner({sessionId:'session-a',bridgeId:f.a.bridgeId,ownerToken:f.a.ownerToken,request,ledger:new Map(),send:async()=>{sends++;throw Object.assign(Error('conversation.send failed: session/closed'), { definitelyRejected: true })}});
 await owner.pollOnce();f.bridge.submit(f.a.bridgeId,task.id);await assert.rejects(owner.pollOnce(),/lost receipt/);await owner.pollOnce();assert.equal(sends,1);
 f.bridge.submit(f.a.bridgeId,task.id);await owner.pollOnce();assert.equal(sends,2);owner.stop();
});

test('relay refuses a forged response for another session and plugin disposal stops all timers',async()=>{
 const client=clientFactory(()=>({createElement(){}}),()=> '');let sent=0;
 const owner=client.createDetachedOwner({sessionId:'session-a',bridgeId:randomUUID(),ownerToken:'owner',request:async()=>({sessionId:'session-b',requests:[{taskId:randomUUID(),attempt:1}]}),send:async()=>{sent++}});
 await assert.rejects(owner.pollOnce(),/目标与原会话不一致/);assert.equal(sent,0);owner.stop();
});
