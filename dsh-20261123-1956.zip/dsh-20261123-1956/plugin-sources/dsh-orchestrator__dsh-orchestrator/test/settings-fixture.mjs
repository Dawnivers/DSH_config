import { createServer } from 'node:http';
import { once } from 'node:events';
import { createSettings } from '../src/settings.js';
import { fixture, mockContext } from './harness.mjs';

export async function serverFixture() {
  const f = fixture();
  const { ctx } = mockContext({ root: f.root });
  let handler;
  const server = createServer((req, res) => handler(req, res));
  server.listen(0, '127.0.0.1');
  await once(server, 'listening');
  const origin = `http://127.0.0.1:${server.address().port}`;
  ctx.webServer = { register(route) { handler = route.handler; return () => {}; }, getOrigin() { return origin; } };
  const settings = createSettings(ctx, f.store);
  const token = new URL(settings.url).searchParams.get('token');
  const call = (action, body, options = {}) => fetch(origin + '/dsh-orchestrator/settings/api/' + action, {
    method: body === undefined ? 'GET' : 'POST', headers: { 'x-settings-token': token, ...(body === undefined ? {} : { 'content-type': 'application/json' }), ...(options.headers || {}) },
    ...(body === undefined ? {} : { body: JSON.stringify(body) }),
  });
  return { ...f, ctx, origin, settings, token, call, async close() { settings.dispose(); server.close(); server.closeAllConnections(); await once(server, 'close'); } };
}
