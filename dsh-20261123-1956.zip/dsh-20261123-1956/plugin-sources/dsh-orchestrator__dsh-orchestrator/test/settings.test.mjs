import test from 'node:test';
import assert from 'node:assert/strict';
import path from 'node:path';
import { fixture, jobConfig, mockContext } from './harness.mjs';
import { serverFixture } from './settings-fixture.mjs';

test('settings API protects state, saves defaults, creates separate tasks without running models', async () => {
  const f = await serverFixture();
  try {
    assert.equal((await fetch(f.origin + '/dsh-orchestrator/settings')).status, 403);
    assert.equal((await f.call('state', undefined, { headers: { 'x-settings-token': 'invalid' } })).status, 401);
    assert.equal((await f.call('state', undefined, { headers: { origin: 'https://outside.example' } })).status, 403);
    const state = await (await f.call('state')).json();
    assert.equal(state.compatibility.ready, true);
    assert.equal(state.models.length, 2);
    const config = jobConfig(f.root);
    const saved = await (await f.call('save', config)).json();
    assert.equal(saved.planner.effort, 'max');
    assert.equal(saved.worker.effort, 'low');
    assert.equal('task' in saved, false);
    assert.equal('projectRoot' in saved, false);
    const one = await (await f.call('job', config)).json();
    const two = await (await f.call('job', config)).json();
    assert.notEqual(one.id, two.id);
    assert.equal(f.store.list().length, 2);
    assert.equal(f.store.status(one.id).status, 'queued');
    const detail = await (await f.call('task?id=' + one.id)).json();
    assert.equal(detail.job.id, one.id);
    assert.equal(detail.runs.length, 0);
    assert.equal((await f.call('job', { ...config, worker: { ...config.worker, effort: 'invalid' } })).status, 400);
    assert.equal((await f.call('task?id=../outside')).status, 400);
  } finally { await f.close(); }
});

test('native host defineTool accepts every plugin schema', async t => {
  const appRoot = process.env.DSH_APP_ROOT;
  if (!appRoot) return t.skip('Set DSH_APP_ROOT to verify against an installed DSH');
  const { createRequire } = await import('node:module');
  const { pathToFileURL } = await import('node:url');
  const installed = createRequire(path.join(appRoot, 'package.json'));
  const { defineTool, validateJsonSchemaValue } = await import(pathToFileURL(installed.resolve('@deepseek-ai/dsh-tools')));
  const { toolSpecs } = await import('../src/index.js');
  const f = fixture(), { ctx } = mockContext();
  for (const spec of toolSpecs(ctx, f.store, {}, () => null)) {
    const defined = defineTool(spec);
    assert.equal(defined.name, spec.name);
    assert.equal(validateJsonSchemaValue(defined.output.schema, { ok: true }, '').length, 0);
    if (spec.name === 'orchestrate_task') {
      const config = jobConfig(f.root);
      assert.equal(validateJsonSchemaValue(defined.parameters, { action: 'create', config }, '').length, 0);
      assert.ok(validateJsonSchemaValue(defined.parameters, { action: 'create', config: JSON.stringify(config) }, '').length > 0);
      const old = { task: 'legacy', projectRoot: f.root, strongProvider: 'strong', strongModel: 'planner', cheapProvider: 'cheap', cheapModel: 'worker' };
      assert.equal(validateJsonSchemaValue(defined.parameters, { action: 'create', config: old }, '').length, 0);
      assert.equal(validateJsonSchemaValue(defined.parameters, { action: 'get', task_id: 'fixture' }, '').length, 0);
    }
  }
});
