// 断言"可像模型一样选择"这件事必须自己被测到：
// 目录能列出来、非法选择当场报错、选择能真正进提示词、没选时提示词不变。

import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, mkdtempSync, writeFileSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

import { assertionCatalog, validateAssertionSelection, renderAssertionRule, expandSelection, executeAssertions, nodeBin } from '../src/assertions.js';
import { validateJob } from '../src/policy.js';
import { plannerPrompt, workerPrompt, reviewerPrompt, repairPrompt } from '../src/prompts.js';

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..');

function job(overrides = {}) {
  return validateJob({
    task: '断言测试任务',
    projectRoot: ROOT,
    allowedGlobs: ['src/**'],
    planner: { provider: 'p', model: 'm' },
    worker: { provider: 'p', model: 'm' },
    reviewer: { provider: 'p', model: 'm' },
    ...overrides,
  });
}

const plan = {
  acceptance: ['静态检查通过'],
  tasks: [
    {
      id: 't1',
      files: ['src/a.js'],
      goal: '改一点东西',
      constraints: [],
      suggestedSteps: [],
      provides: [],
      consumes: [],
      feasibility: { status: 'ok', summary: '', evidence: [], questions: [] },
    },
  ],
};

test('断言目录可枚举，且覆盖包 / 组 / 单条三种粒度', async () => {
  const catalog = await assertionCatalog();
  assert.equal(catalog.available, true, catalog.reason || '断言库应可用');
  assert.ok(catalog.total >= 12, `应有至少 12 条断言，实际 ${catalog.total}`);
  const pack = catalog.packs.find((p) => p.id === 'geo.vector');
  assert.ok(pack, '应存在 geo.vector 包');
  assert.ok(pack.groups.length > 1, '包内应有多个组');
  assert.ok(catalog.bySelection.has('geo.vector'));
  assert.ok(catalog.bySelection.has('geo.vector/geojson'));
  assert.ok(catalog.bySelection.has('geom.ring.closed'));
});

test('合法选择被接受并去重', async () => {
  const { selection, warnings } = await validateAssertionSelection(['geo.vector', 'geo.vector', ' geo.vector/geojson ']);
  assert.deepEqual(selection, ['geo.vector', 'geo.vector/geojson']);
  assert.equal(warnings.length, 1, '子项被整包覆盖时应给出提示但不丢弃');
});

test('未知断言必须当场报错，不能静默丢弃', async () => {
  await assert.rejects(() => validateAssertionSelection(['geo.vector/not-a-group']), /未知断言/);
  await assert.rejects(() => validateAssertionSelection(['geo.nothing']), /未知断言/);
});

test('格式非法与超量选择被拒', async () => {
  await assert.rejects(() => validateAssertionSelection(['../etc/passwd']), /格式不合法/);
  await assert.rejects(() => validateAssertionSelection(['a'.repeat(300)]), /格式不合法|未知断言/);
  await assert.rejects(() => validateAssertionSelection(new Array(101).fill('geo.vector')), /最多 100 项/);
});

test('任务配置拒绝非数组与非字符串的断言选择', () => {
  assert.throws(() => job({ assertions: 'geo.vector' }), /必须是数组/);
  assert.throws(() => job({ assertions: [42] }), /1–200 字符的字符串/);
  assert.throws(() => job({ assertions: ['  '] }), /1–200 字符的字符串/);
});

test('任务配置保留断言选择并去重', () => {
  const j = job({ assertions: ['geo.vector', 'geo.vector', 'geom.ring.closed'] });
  assert.deepEqual(j.assertions, ['geo.vector', 'geom.ring.closed']);
});

test('未选择断言时提示词不发生变化', () => {
  const j = job({ assertions: [] });
  for (const text of [plannerPrompt(j), workerPrompt(j, plan, plan.tasks[0]), reviewerPrompt(j, plan, [], [])]) {
    assert.ok(!text.includes('数据/地理断言'), '未启用断言不应出现断言段落');
    assert.ok(!text.includes('not_applicable'), '未启用断言不应出现断言判定规则');
  }
});

test('选择断言后 planner / worker / reviewer 都拿到可执行规则', () => {
  const j = job({ assertions: ['geo.vector/geojson'] });

  const planner = plannerPrompt(j);
  assert.match(planner, /已启用数据断言：geo\.vector\/geojson/);
  assert.match(planner, /主会话待运行验证/, 'planner 要被告知这是待运行验证而不是源码任务');

  for (const text of [workerPrompt(j, plan, plan.tasks[0]), reviewerPrompt(j, plan, [], [])]) {
    assert.match(text, /数据\/地理断言/);
    assert.match(text, /--only "geo\.vector\/geojson"/);
    assert.match(text, /not_applicable 表示/, '必须写明不适用不等于通过');
    assert.match(text, /不得为了让断言变绿而放宽阈值/, '必须禁止为了让断言变绿而改阈值');
  }
});

test('渲染出的命令指向插件内的执行器与真实项目根', () => {
  const rule = renderAssertionRule({ selection: ['geo.vector'], projectRoot: 'D:\\proj' });
  assert.match(rule, /assertions[\\/]run\.mjs/);
  assert.match(rule, /--root "D:\\proj"/);
  assert.match(rule, /--json/);
  assert.match(rule, /退出码 0 且 status 为 pass 或 not_applicable/);
});

test('父项覆盖子项时命令只保留最粗粒度', async () => {
  assert.deepEqual(await expandSelection(['geo.vector', 'geo.vector/geojson', 'geom.ring.closed']), ['geo.vector']);
  // geom.ring.closed 属 geojson 组，被组选择覆盖
  assert.deepEqual(await expandSelection(['geo.vector/geojson', 'geom.ring.closed']), ['geo.vector/geojson']);
  // 不同组的单条与组选择并存
  assert.deepEqual(await expandSelection(['geo.vector/geojson', 'schema.required-properties']), ['geo.vector/geojson', 'schema.required-properties']);
});

// —— 断言闸门：放行条件必须严格，否则"没查"会被读成"过了" ——

function scaffold(contents) {
  const dir = mkdtempSync(join(tmpdir(), 'geo-gate-'));
  for (const [name, text] of Object.entries(contents)) writeFileSync(join(dir, name), text);
  return dir;
}
const fixture = (name) => readFileSync(new URL(`../assertions/fixtures/${name}`, import.meta.url), 'utf8');

test('reviewMode 只接受两档，默认 always', () => {
  assert.equal(job({}).reviewMode, 'always');
  assert.equal(job({ reviewMode: 'on_failure' }).reviewMode, 'on_failure');
  assert.throws(() => job({ reviewMode: 'never' }), /reviewMode/);
});

test('断言通过时放行，并记录真实退出码与执行条数', async () => {
  const dir = scaffold({ 'clean.geojson': fixture('good/clean.geojson') });
  try {
    const gate = await executeAssertions(job({ projectRoot: dir, assertions: ['geo.vector/geojson'], allowedGlobs: ['*.geojson'] }), { ownedFiles: new Set(['clean.geojson']) });
    assert.equal(gate.pass, true, gate.record.reason);
    assert.equal(gate.record.exit_code, 0);
    assert.equal(gate.record.status, 'pass');
    assert.equal(gate.record.counts.checks_run, 4);
  } finally { rmSync(dir, { recursive: true, force: true }); }
});

test('断言失败时给出退出码与非空 findings，并按归属标记 owner', async () => {
  const dir = scaffold({ 'bad.geojson': fixture('bad/out-of-range.geojson') });
  try {
    const gate = await executeAssertions(job({ projectRoot: dir, assertions: ['geo.vector'], allowedGlobs: ['*.geojson'] }), { ownedFiles: new Set(['bad.geojson']) });
    assert.equal(gate.pass, false);
    assert.equal(gate.record.exit_code, 1);
    assert.ok(gate.record.findings.length > 0, '应有具体失败项');
    assert.ok(gate.record.findings.every((finding) => finding.owner === 'worker'), '归属内文件应标 worker');
  } finally { rmSync(dir, { recursive: true, force: true }); }
});

test('归属外的失败项标记 external，不能进修复轮', async () => {
  const dir = scaffold({ 'bad.geojson': fixture('bad/out-of-range.geojson') });
  try {
    const gate = await executeAssertions(job({ projectRoot: dir, assertions: ['geo.vector'], allowedGlobs: ['*.geojson'] }), { ownedFiles: new Set() });
    assert.equal(gate.pass, false);
    assert.ok(gate.record.findings.length > 0);
    assert.ok(gate.record.findings.every((finding) => finding.owner === 'external'));
  } finally { rmSync(dir, { recursive: true, force: true }); }
});

test('not_applicable 绝不放行——退出码 0 不等于通过', async () => {
  const dir = scaffold({ 'config.json': '{"a":1}' });
  try {
    const gate = await executeAssertions(job({ projectRoot: dir, assertions: ['geo.vector'], allowedGlobs: ['*.json'] }));
    assert.equal(gate.record.exit_code, 0, '这种情况下退出码确实是 0');
    assert.equal(gate.record.status, 'not_applicable');
    assert.equal(gate.record.counts.checks_run, 0);
    assert.equal(gate.pass, false, '没执行任何断言就不能放行');
    assert.match(gate.record.reason, /不算通过/);
  } finally { rmSync(dir, { recursive: true, force: true }); }
});

test('未启用断言时不产生放行依据', async () => {
  const gate = await executeAssertions(job({ assertions: [] }));
  assert.equal(gate.pass, false);
  assert.equal(gate.record.status, 'not_run');
});

// 修复轮的 planner 必须拿到失败项原件，否则它不知道要修哪个文件的哪个位置。
test('修复轮提示词带上断言实测原件', () => {
  const record = {
    status: 'issues_found', exit_code: 1, counts: { checks_run: 7 },
    findings: [{ id: 'geom.ring.closed', severity: 'error', path: 'data/a.geojson', locator: { feature: 1 }, message: '环未闭合' }],
  };
  const text = repairPrompt(job({ assertions: ['geo.vector'] }), { tasks: [], acceptance: [] }, [], [], { assessment: 'issues_found', summary: 's', checks: [] }, record);
  assert.match(text, /geom\.ring\.closed/);
  assert.match(text, /data\/a\.geojson/);
  assert.match(text, /环未闭合/);
});

// 修复轮的复核只拿到本轮增量 diff 时，会把首轮已修好的地方判成"漏做"。
test('修复轮复核知道自己在第几轮、上一轮发现了什么', () => {
  const context = {
    round: 1,
    triggerFindings: [{ id: 'geom.ring.closed', path: 'data/a.geojson', locator: { feature: 1 }, message: '环未闭合' }],
  };
  const text = reviewerPrompt(job({ assertions: ['geo.vector'] }), { tasks: [], acceptance: [] }, [], [], null, context);
  assert.match(text, /第 1 轮定向修复/);
  assert.match(text, /两轮累计/);
  assert.match(text, /geom\.ring\.closed/);
  assert.match(text, /环未闭合/);
  // 首轮复核不该出现这段，否则会干扰正常判断。
  assert.ok(!reviewerPrompt(job({}), { tasks: [], acceptance: [] }, [], [], null).includes('轮定向修复'));
});

// 这条是真机踩出来的：DSH Desktop 是 Electron，process.execPath 指向应用本身。
// 用它跑 .mjs 会退出码 0 但 stdout 只有一个换行，表现为"跑了但没输出"。
test('Electron 宿主下不能拿 process.execPath 跑断言脚本', () => {
  assert.equal(nodeBin(), process.execPath, '普通 node 环境就该用自己的可执行文件');

  const descriptor = Object.getOwnPropertyDescriptor(process.versions, 'electron');
  Object.defineProperty(process.versions, 'electron', { value: '35.0.0', configurable: true });
  try {
    assert.equal(nodeBin(), process.env.DSH_NODE_EXECPATH || 'node', 'Electron 下应退回 PATH 里的 node');
  } finally {
    if (descriptor) Object.defineProperty(process.versions, 'electron', descriptor);
    else delete process.versions.electron;
  }
});
