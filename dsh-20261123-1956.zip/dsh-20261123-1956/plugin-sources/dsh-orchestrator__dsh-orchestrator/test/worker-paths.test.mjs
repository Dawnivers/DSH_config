import test from 'node:test';
import assert from 'node:assert/strict';
import { runnerFixture, jobConfig } from './harness.mjs';
test('absolute changedFiles from real worker normalize to exact owned relative files', async () => {
  const f = runnerFixture({ absoluteChangedFiles: true });
  const job = f.store.create(jobConfig(f.root));
  const report = await f.runner.run(job.id, f.parent, new AbortController().signal).result;
  assert.equal(report.status, 'needs_validation');
  assert.deepEqual(report.workers.flatMap(worker => worker.changedFiles), ['src/a.js', 'src/b.js']);
  await f.bindings.dispose();
});
