import test from 'node:test';
import assert from 'node:assert/strict';
import { clientFactory } from '../src/client.js';
const taskId = '11111111-2222-4333-8444-555555555555';
function fixture(send = async () => {}, isBusy = () => false) {
  const received = [];
  const source = { postMessage: (data, origin) => received.push({ data, origin }) };
  const client = clientFactory(() => ({ createElement() {} }), () => '');
  const args = { sessionId: 'session-a', bridgeId: 'private-nonce', origin: 'http://127.0.0.1:29972', source, send, isBusy, ledger: new Map() };
  const receive = client.createSessionBridge(args);
  const event = { origin: args.origin, source, data: { type: 'dsh-orchestrator:start', sessionId: args.sessionId, bridgeId: args.bridgeId, taskId } };
  return { client, args, receive, event, received };
}

test('only the bound same-origin iframe can submit into its captured session', async () => {
  let sent = 0;
  const f = fixture(async () => { sent++; });
  for (const event of [
    { ...f.event, origin: 'https://outside.example' },
    { ...f.event, source: {} },
    { ...f.event, data: { ...f.event.data, bridgeId: 'forged' } },
    { ...f.event, data: { ...f.event.data, sessionId: 'session-b' } },
    { ...f.event, data: { ...f.event.data, taskId: '../other' } },
    { ...f.event, data: { ...f.event.data, taskId: [taskId] } },
  ]) await f.receive(event);
  assert.equal(sent, 0);
  assert.equal(f.received.length, 0);
  await f.receive(f.event);
  assert.equal(sent, 1);
  assert.equal(f.received[0].origin, f.args.origin);
});

test('concurrent clicks and lost acknowledgements share one Host admission', async () => {
  let finish, count = 0;
  const pending = new Promise(resolve => { finish = resolve; });
  const f = fixture(async (prompt, requestId) => {
    count++;
    assert.equal(requestId, taskId);
    assert.match(prompt, /orchestrate_run/);
    assert.match(prompt, /run_in_background=true/);
    await pending;
  }, () => true);
  const one = f.receive(f.event), two = f.receive(f.event);
  assert.equal(count, 1);
  finish();
  await Promise.all([one, two]);
  await f.receive(f.event);
  assert.equal(count, 1);
  assert.equal(f.received.length, 3);
  assert.equal(f.received[0].data.queued, true);
});

test('an explicit Host rejection allows retry, uncertain transport admission stays latched', async () => {
  let calls = 0;
  const rejected = fixture(async () => { calls++; throw Object.assign(new Error('conversation.send failed: session/removed'), { definitelyRejected: true }); });
  await rejected.receive(rejected.event);
  await rejected.receive(rejected.event);
  assert.equal(calls, 2);
  assert.equal(rejected.received[0].data.uncertain, false);
  calls = 0;
  const uncertain = fixture(async () => { calls++; throw new Error('connection lost'); });
  await uncertain.receive(uncertain.event);
  await uncertain.receive(uncertain.event);
  assert.equal(calls, 1);
  assert.equal(uncertain.received[0].data.uncertain, true);
});

test('a run opens the flow panel once; a new run reopens it and other sessions are ignored', () => {
  const f = fixture();
  const { discoverRun } = f.client;
  const seen = new Map();
  const running = (id, runId, session = 'session-a') => ({ id, runId, parentSession: session, status: 'running' });

  assert.equal(discoverRun('session-a', [running(taskId, 'run-1')], seen).runId, 'run-1');
  assert.equal(discoverRun('session-a', [running(taskId, 'run-1')], seen), null, 'the same run must not reopen after the user closes it');
  const second = '22222222-3333-4444-8555-666666666666';
  assert.equal(discoverRun('session-a', [running(taskId, 'run-1'), running(second, 'run-2')], seen).runId, 'run-2');
  assert.equal(discoverRun('session-a', [running(taskId, 'run-1', 'session-b')], seen), null);
  assert.equal(discoverRun('session-a', [{ ...running(taskId, 'run-3'), status: 'needs_validation' }], seen), null, 'finished runs do not pop up');
  assert.equal(discoverRun('session-a', [{ id: '../escape', runId: 'run-4', parentSession: 'session-a', status: 'running' }], seen), null);
});

test('native slots cover blank sessions and send through the exact bound Session with queue and requestId', async () => {
  const f = fixture(), slots = [], sent = [];
  const binding = { session: { prompt: async (...args) => { sent.push(args); return { ok: true, value: { accepted: true } }; } } };
  const ctx = { slots: { inject: (_name, fn) => fn(), register: (spec, component) => slots.push({ spec, component }) }, sessions: {
    binding: id => id === 'session-a' ? binding : undefined,
    list: { getSnapshot: () => ({ byId: { 'session-a': { displayTitle: 'A', cwd: 'D:/project-a' } } }) },
  } };
  f.client.apply(ctx);
  assert.deepEqual(slots.map(row => row.spec.name), ['plugins.bundle.config', 'conversation.session.header.actions', 'conversation.input.left']);
  const props = slots[1].spec.inject('session-a');
  assert.equal(props.getSessionInfo().cwd, 'D:/project-a');
  await props.sendMessage('start', taskId);
  assert.deepEqual(sent, [[[{ type: 'text', text: 'start' }], 'queue', undefined, taskId]]);
  await assert.rejects(slots[1].spec.inject('session-b').sendMessage('start', taskId), /会话已关闭/);
  assert.equal(sent.length, 1);
});


test('actual Session prompt result faults stay uncertain and never permit automatic retry',async()=>{
 for(const code of ['gateway/internal','gateway/cancelled','unknown-future-code']) {
  const slots=[];let calls=0;
  const client=clientFactory(()=>({createElement(){}}),()=> '');
  const dispose=client.apply({slots:{inject:(_name,fn)=>fn(),register:(spec,component)=>slots.push({spec,component})},sessions:{binding:()=>({session:{prompt:async()=>{calls++;return {ok:false,error:{code,message:'lost response after acceptance'}}}}}),list:{getSnapshot:()=>({byId:{}})}}});
  const send=slots[1].spec.inject('session-a').sendMessage,ledger=new Map();
  const args={sessionId:'session-a',taskId,send,ledger};
  assert.equal((await client.deliverBoundTask(args)).uncertain,true);
  assert.equal((await client.deliverBoundTask(args)).uncertain,true);
  assert.equal(calls,1,code);dispose();
 }
});

test('owner stops scheduling on terminal HTTP errors and start is idempotent',async()=>{
 const client=clientFactory(()=>({createElement(){}}),()=> '');let calls=0,schedules=0,stops=0;
 const owner=client.createDetachedOwner({sessionId:'session-a',bridgeId:'bridge',ownerToken:'owner',request:async()=>{calls++;throw Object.assign(Error('expired'),{status:400})},send:async()=>{},setTimer:()=>{schedules++;},clearTimer:()=>{},onStop:()=>{stops++}});
 owner.start();owner.start();await new Promise(resolve=>setImmediate(resolve));
 assert.equal(calls,1);assert.equal(schedules,0);assert.equal(stops,1);owner.stop();assert.equal(stops,1);
});
