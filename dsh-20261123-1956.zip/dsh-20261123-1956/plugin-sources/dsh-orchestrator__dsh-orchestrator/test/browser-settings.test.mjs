import test from 'node:test';
import assert from 'node:assert/strict';
import { serverFixture } from './settings-fixture.mjs';
import { jobConfig } from './harness.mjs';

async function json(response,status=200){assert.equal(response.status,status);return response.json()}

test('external browser HTTP routes bind boot and task creation without leaking owner token',async()=>{
 const f=await serverFixture();
 try {
  const opened=await json(await f.call('bridge/open',{sessionId:'session-a',sessionTitle:'Session A',workspaceRoot:f.root}));
  assert.ok(opened.ownerToken);const page=await fetch(opened.url);assert.equal(page.status,200);
  const html=await page.text();assert.ok(html.includes('"detached":true'));assert.ok(html.includes('"sessionId":"session-a"'));
  assert.ok(!html.includes(opened.ownerToken));
  const opts={headers:{'x-orchestrator-bridge':opened.bridgeId}},config=jobConfig(f.root);
  const [one,two]=await Promise.all([f.call('job',config,opts).then(r=>json(r)),f.call('job',config,opts).then(r=>json(r))]);
  assert.equal(one.id,two.id);assert.equal(f.store.list().length,1);
  await json(await f.call('bridge/submit',{bridgeId:opened.bridgeId,taskId:one.id}),400);
  const pulse=await json(await f.call('bridge/poll',{bridgeId:opened.bridgeId,ownerToken:opened.ownerToken}));assert.equal(pulse.sessionId,'session-a');
  await json(await f.call('bridge/submit',{bridgeId:opened.bridgeId,taskId:one.id}));
  const poll=await json(await f.call('bridge/poll',{bridgeId:opened.bridgeId,ownerToken:opened.ownerToken}));assert.deepEqual(poll.requests,[{taskId:one.id,attempt:1}]);
  await json(await f.call('bridge/result',{bridgeId:opened.bridgeId,ownerToken:opened.ownerToken,taskId:one.id,attempt:1,result:{ok:true}}));
  const status=await json(await f.call('bridge/status?bridgeId='+opened.bridgeId));assert.equal(status.deliveries[0].status,'sent');assert.ok(!JSON.stringify(status).includes(opened.ownerToken));
  assert.equal(f.store.status(one.id).status,'queued','HTTP relay never executes a model or task');
 }finally{await f.close()}
});

test('foreign origins, invalid auth, unbound jobs and forged receipt owner fail closed over HTTP',async()=>{
 const f=await serverFixture();
 try {
  await json(await f.call('bridge/open',{sessionId:'session-a'},{headers:{origin:'https://evil.example'}}),403);
  await json(await f.call('bridge/open',{sessionId:'session-a'},{headers:{'x-settings-token':'invalid'}}),401);
  const a=await json(await f.call('bridge/open',{sessionId:'session-a'})),b=await json(await f.call('bridge/open',{sessionId:'session-b'}));
  const task=await json(await f.call('job',jobConfig(f.root)));
  await json(await f.call('bridge/submit',{bridgeId:a.bridgeId,taskId:task.id}),400);
  await json(await f.call('bridge/poll',{bridgeId:a.bridgeId,ownerToken:b.ownerToken}),400);
  await json(await f.call('bridge/result',{bridgeId:a.bridgeId,taskId:task.id,attempt:1,result:{ok:true}}),400);
  const stale=new URL(f.settings.url);stale.searchParams.set('bridge','missing');assert.equal((await fetch(stale)).status,403);
  assert.equal(f.store.status(task.id).status,'queued');
 }finally{await f.close()}
});


test('browser-scoped token cannot access other sessions, global settings, or owner operations',async()=>{
 const f=await serverFixture();
 try {
  const a=await json(await f.call('bridge/open',{sessionId:'session-a',workspaceRoot:f.root}));
  const b=await json(await f.call('bridge/open',{sessionId:'session-b',workspaceRoot:f.root}));
  const browserToken=new URL(a.url).searchParams.get('token');assert.notEqual(browserToken,f.token);
  const external=(route,body,extra={})=>f.call(route,body,{headers:{'x-settings-token':browserToken,...extra}});
  const own=await json(await external('job',jobConfig(f.root),{'x-orchestrator-bridge':a.bridgeId}));
  const foreign=await json(await f.call('job',{...jobConfig(f.root),task:'private task for B'},{headers:{'x-orchestrator-bridge':b.bridgeId}}));
  const state=await json(await external('state'));assert.deepEqual(state.jobs.map(j=>j.id),[own.id]);
  await json(await external('task?id='+foreign.id),403);
  await json(await external('activity?session=session-b'),403);
  await json(await external('bridge/status?bridgeId='+b.bridgeId),403);
  await json(await external('bridge/submit',{bridgeId:b.bridgeId,taskId:foreign.id}),403);
  await json(await external('bridge/open',{sessionId:'session-c'}),403);
  await json(await external('bridge/poll',{bridgeId:a.bridgeId,ownerToken:a.ownerToken}),403);
  await json(await external('bridge/close',{bridgeId:a.bridgeId,ownerToken:a.ownerToken}),403);
  await json(await external('job',jobConfig(f.root)),403);
  const before=f.store.defaults();
  await json(await external('save',jobConfig(f.root)),403);
  const draft=await json(await external('bridge/draft',{bridgeId:a.bridgeId,config:{...jobConfig(f.root),maxWorkers:3}}));
  assert.equal(draft.maxWorkers,3);assert.deepEqual(f.store.defaults(),before);
  assert.equal((await json(await external('state'))).defaults.maxWorkers,3);
  assert.ok(!(await (await fetch(a.url)).text()).includes(f.token));
  await json(await f.call('bridge/close',{bridgeId:a.bridgeId,ownerToken:a.ownerToken}));
  await json(await external('state'),401);assert.equal((await fetch(a.url)).status,403);
  assert.equal(f.store.status(own.id).status,'queued');
 }finally{await f.close()}
});
