// runner 与复核契约的接线：确认报告里的 review / nextAction 真的过了校验，
// 并且模型输出畸形时**不再销毁已写入的成果**——复核失败降级为 review_failed 并留下原因。
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import path from 'node:path';
import { runnerFixture, jobConfig } from './harness.mjs';

const goodCheck = { id: 'build', kind: 'build', statement: '构建通过', command: 'npm run build', expected: 'exit 0' };

async function run(reviewResult, overrides = {}, options = { reviewResult }) {
  const f = runnerFixture(options);
  const job = f.store.create(jobConfig(f.root, overrides));
  const report = await f.runner.run(job.id, f.parent, new AbortController().signal).result;
  await f.bindings.dispose();
  return { f, job, report };
}

test('结构化复核结果写入报告，nextAction 同时给出扁平清单与原始条目', async () => {
  const { report } = await run({ assessment: 'verified_statically', summary: '静态复核通过', checks: [goodCheck] });
  assert.equal(report.status, 'needs_validation', report.error);
  assert.equal(report.review.assessment, 'verified_statically');
  assert.equal(report.review.checks.length, 1);
  assert.equal(report.review.checks[0].kind, 'build');
  // 旧消费方仍能读到 checksNeeded 字符串数组
  assert.equal(report.nextAction.checksNeeded.length, 1);
  assert.match(report.nextAction.checksNeeded[0], /\[build\]/);
  assert.equal(report.nextAction.checks[0].command, 'npm run build');
  assert.match(report.nextAction.note, /静态复核/);
});

test('合法问题条目按 review_failed 收尾，但仍把 checks 交给主会话', async () => {
  // maxRepairRounds=0：这里只验「问题结论本身」，自动返工由 pipeline 的定向修复用例覆盖。
  const { report } = await run({
    assessment: 'issues_found', summary: '发现遮罩未覆盖真实点云',
    checks: [{ id: 'mask', kind: 'data', statement: '鳍遮罩覆盖', command: 'node tools/mask.mjs', expected: '命中点 > 0' }],
  }, { maxRepairRounds: 0 });
  assert.equal(report.status, 'review_failed');
  assert.equal(report.review.checks[0].id, 'mask');
});

test('unable_to_verify 不会伪装成通过，也不会算复核失败', async () => {
  const { report } = await run({ assessment: 'unable_to_verify', summary: '需要宿主环境', checks: [] });
  assert.equal(report.status, 'needs_validation');
  assert.equal(report.review.assessment, 'unable_to_verify');
  assert.deepEqual(report.nextAction.checks, []);
});

test('回顾旧值 ready_for_validation 时归一，历史字段不被改写', async () => {
  const { report } = await run({ assessment: 'ready_for_validation', summary: '旧口径', checks: [goodCheck] });
  assert.equal(report.review.assessment, 'verified_statically');
  assert.equal(report.review.legacyAssessment, 'ready_for_validation');
});

test('畸形复核输出标记为 review_error：保留成果、留下原因、不静默当通过', async () => {
  for (const [label, reviewResult] of [
    ['空结论', { summary: 's', checks: [goodCheck] }],
    ['未知结论', { assessment: 'looks_good', summary: 's', checks: [goodCheck] }],
    ['伪造已验证', { assessment: 'verified_statically', summary: 's', checks: [] }],
    ['问题但无条目', { assessment: 'issues_found', summary: 's', checks: [] }],
  ]) {
    const { f, report } = await run(reviewResult);
    assert.equal(report.status, 'review_error', `${label} 应为复核异常`);
    assert.equal(report.review, undefined, `${label} 不应写入 review`);
    assert.ok(report.reviewError, `${label} 必须留下失败原因`);
    // 复核失败不再回滚代码：文件、哈希、快照都要留在主会话手里。
    assert.equal(report.rollback, undefined, `${label} 不应触发回滚`);
    assert.equal(readFileSync(path.join(f.root, 'src/a.js'), 'utf8'), 'export const a = 2;\n', `${label} 应保留写入`);
    assert.ok(report.files.some(file => file.changed), `${label} 文件清单应仍可见`);
    assert.deepEqual(report.nextAction.checks, [], `${label} 不应伪造待验证项`);
    assert.match(report.nextAction.note, /复核未产出可用结论/);
  }
});

test('构建类缺命令不再算复核失败：条目与被写入成果都保留，只降级那一条', async () => {
  const { f, report } = await run({
    assessment: 'verified_statically', summary: '静态复核通过',
    checks: [{ ...goodCheck, command: '' }, { id: 'visual', kind: 'visual', statement: '目视确认', command: '', expected: '无越框' }],
  });
  assert.equal(report.status, 'needs_validation', report.error);
  assert.equal(report.reviewError, undefined, '不该走复核失败通道');
  assert.equal(report.review.checks.length, 2, '降级不能丢条目');
  assert.equal(report.review.checks[0].status, 'unverifiable');
  assert.match(report.review.checks[0].issue, /没有可执行 command/);
  assert.equal(report.review.checks[1].status, 'ok');
  assert.equal(report.review.degraded.length, 1);
  assert.ok(report.events.some(event => event.stage === 'review-degraded'), '降级必须留事件');
  assert.match(report.nextAction.note, /降级为 unverifiable/);
  assert.equal(readFileSync(path.join(f.root, 'src/a.js'), 'utf8'), 'export const a = 2;\n');
});

test('报告里的 reviewer 路由被记录下来，便于审计谁复核的', async () => {
  const { report } = await run({ assessment: 'unable_to_verify', summary: '需实测', checks: [] });
  assert.ok(report.review.route.provider);
  assert.ok(report.review.route.model);
});
