import test from 'node:test';
import assert from 'node:assert/strict';
import path from 'node:path';
import { readFileSync, existsSync } from 'node:fs';
import { PLAN_SCHEMA, validatePlan } from '../src/policy.js';
import { FEASIBILITY_SCHEMA, validateFeasibility } from '../src/feasibility.js';
import { plannerPrompt, feasibilityPrompt, workerPrompt, reviewerPrompt } from '../src/prompts.js';
import { page } from '../src/ui.js';
import { toolSpecs } from '../src/index.js';
import { fixture, jobConfig, plan, feasibility, runnerFixture } from './harness.mjs';

const source = f => ['a', 'b'].map(name => readFileSync(path.join(f.root, 'src', name + '.js'), 'utf8'));
const roles = f => f.calls.map(call => call.label.split(':')[2]);
function unresolved(kind = 'needs_clarification') {
  const result = feasibility(); result.status = kind;
  Object.assign(result.tasks[1], {
    status: kind, summary: 'the target value is ambiguous for export b',
    evidence: ['src/b.js exports b=1; the requested upper bound is not defined'],
    questions: kind === 'needs_clarification' ? ['Should b be clamped to 2 or rejected above 2?'] : [],
  });
  return result;
}

// These checks exercise host gates and permissions; they do not pretend to test model judgement.
test('layered tasks replace instruction and reject missing, malformed or oversized fields', () => {
  const f = fixture(), job = jobConfig(f.root), candidate = plan();
  const fields = PLAN_SCHEMA.properties.tasks.items;
  for (const name of ['goal', 'constraints', 'suggestedSteps']) assert.ok(fields.required.includes(name));
  assert.equal('instruction' in fields.properties, false);
  assert.deepEqual(validatePlan(candidate, job), candidate);
  const invalid = [
    task => { delete task.goal; }, task => { task.goal = ' '; }, task => { task.goal = 'x'.repeat(6001); },
    task => { delete task.constraints; }, task => { task.constraints = 'not an array'; },
    task => { task.constraints = ['']; }, task => { task.suggestedSteps = [42]; },
    task => { task.suggestedSteps = Array(51).fill('step'); },
    task => { task.constraints = Array(6).fill('x'.repeat(4000)); },
    task => { task.instruction = 'legacy mixed instruction'; },
  ];
  for (const mutate of invalid) { const bad = plan(); mutate(bad.tasks[0]); assert.throws(() => validatePlan(bad, job)); }
  candidate.tasks[0].constraints = []; candidate.tasks[0].suggestedSteps = [];
  assert.equal(validatePlan(candidate, job).tasks[0].constraints.length, 0);
});

test('planner, feasibility, worker and reviewer consistently treat suggestions as advisory', () => {
  const f = fixture(), job = jobConfig(f.root), candidate = plan();
  for (const text of [plannerPrompt(job), feasibilityPrompt(job, candidate), workerPrompt(job, candidate, candidate.tasks[0]), reviewerPrompt(job, candidate, [], [])]) {
    assert.match(text, /goal 是必须实现的目标/); assert.match(text, /constraints 是必须遵守的约束/);
    assert.match(text, /suggestedSteps 只是建议步骤，不是强制流程/);
    assert.match(text, /不得.*绕过任何硬约束/);
  }
  assert.match(plannerPrompt(job), /不要输出 instruction/);
  assert.match(workerPrompt(job, candidate, candidate.tasks[0]), /重要方法调整写入 summary/);
  assert.match(reviewerPrompt(job, candidate, [], []), /不得仅因 worker 未照 suggestedSteps 执行就报错/);
  assert.match(feasibilityPrompt(job, candidate), /计划新建文件时检查其现有调用方或相邻结构/);
});

test('feasibility validator demands exact task coverage, evidence, actionable questions and consistent status', () => {
  const candidate = plan();
  assert.equal(validateFeasibility(feasibility(), candidate).status, 'ready');
  assert.equal(validateFeasibility(unresolved(), candidate).status, 'needs_clarification');
  assert.equal(validateFeasibility(unresolved('blocked'), candidate).status, 'blocked');
  const invalid = [
    result => { result.tasks.pop(); }, result => { result.tasks[1].taskId = 'a'; },
    result => { result.tasks[1].taskId = 'unknown'; }, result => { result.tasks[0].evidence = []; },
    result => { result.tasks[0].evidence = [' ']; }, result => { result.tasks[0].questions = ['unresolved']; },
    result => { result.tasks[0].status = 'needs_clarification'; result.status = 'needs_clarification'; },
    result => { result.status = 'blocked'; }, result => { result.tasks[0].status = 'maybe'; },
    result => { result.tasks[0].summary = ''; }, result => { result.tasks[0].questions = null; },
  ];
  for (const mutate of invalid) { const bad = feasibility(); mutate(bad); assert.throws(() => validateFeasibility(bad, candidate)); }
  const mixed = unresolved(); mixed.status = 'blocked'; mixed.tasks[0].status = 'blocked';
  assert.equal(validateFeasibility(mixed, candidate).status, 'blocked');
});

test('one independent read-only session gates every writer, remains scoped, and passes task evidence forward', async () => {
  let checked = false;
  const f = runnerFixture({ beforeResult({ role, request, fire }) {
    if (role !== 'feasibility') return;
    checked = true;
    assert.deepEqual(request.toolFilter.allow, ['read', 'glob', 'grep']);
    // 复核走自己的路由，缺省继承 planner；这里也用 planner 的档位。
    assert.deepEqual(request.agentOptions, { provider: 'strong', model: 'planner', reasoningEffort: 'max' });
    for (const tool of ['write', 'edit']) assert.match(fire(tool, { file_path: path.join(f.root, 'src/a.js') }), /只允许读取/);
    for (const tool of ['subagent', 'pwsh', 'browser_snapshot']) assert.match(fire(tool, {}), /禁止调用/);
    assert.match(fire('read', { file_path: path.join(f.dir, 'outside.js') }), /越出/);
    assert.equal(fire('read', { file_path: path.join(f.root, 'src/a.js') }), undefined);
    assert.deepEqual(source(f), ['export const a = 1;\n', 'export const b = 1;\n']);
    assert.equal(existsSync(path.join(f.store.directory(job.id), 'snapshots')), false);
  } });
  const job = f.store.create(jobConfig(f.root));
  try {
    const report = await f.runner.run(job.id, f.parent, new AbortController().signal).result;
    assert.equal(report.status, 'needs_validation', report.error); assert.ok(checked);
    assert.deepEqual(roles(f), ['planner', 'feasibility', 'worker', 'worker', 'reviewer']);
    assert.equal(report.feasibility.tasks.length, 2);
    assert.equal(report.children.filter(child => child.role === 'feasibility').length, 1);
    for (const call of f.calls.filter(call => call.label.includes(':worker:'))) {
      const taskId = call.label.split(':')[3];
      assert.match(call.prompt[0].text, /执行前只读确认/);
      assert.ok(call.prompt[0].text.includes(`src/${taskId}.js: existing numeric export`));
    }
    const agent = f.ctx.children.get(report.children[1].childId).agent;
    assert.match(f.ctx.check({ agent, name: 'read', arguments: { file_path: path.join(f.root, 'src/a.js') } }), /已关闭/);
    assert.equal(f.disposed.length, 5);
  } finally { await f.bindings.dispose(); }
});

for (const kind of ['needs_clarification', 'blocked']) test(`${kind} stops the whole batch before snapshots or writers and persists evidence`, async () => {
  const f = runnerFixture({ getFeasibility: () => unresolved(kind) });
  try {
    const before = source(f), job = f.store.create(jobConfig(f.root, { maxPlanRetries: 2 }));
    const report = await f.runner.run(job.id, f.parent, new AbortController().signal).result;
    assert.equal(report.status, 'blocked'); assert.equal(report.feasibility.status, kind);
    assert.deepEqual(roles(f), ['planner', 'feasibility']); assert.equal(report.planAttempts, 1);
    assert.equal(report.snapshot, undefined); assert.equal(report.workers, undefined); assert.equal(report.review, undefined);
    assert.match(report.error, /src\/b.js exports b=1/); assert.match(report.nextAction.note, /不会自动重规划/);
    assert.equal(report.nextAction.questions.length, kind === 'needs_clarification' ? 1 : 0);
    assert.deepEqual(source(f), before);
    assert.deepEqual(f.store.runs(job.id)[0].feasibility, report.feasibility);
    assert.equal(f.store.status(job.id).status, 'blocked'); assert.equal(f.disposed.length, 2);
    // The lock is released; a separate planning-only task can run after the blocked result.
    const next = f.store.create(jobConfig(f.root));
    assert.equal((await f.runner.run(next.id, f.parent, new AbortController().signal, undefined, { planOnly: true }).result).status, 'planned');
  } finally { await f.bindings.dispose(); }
});

test('plan_only does not pay for or claim an independent feasibility check', async () => {
  const f = runnerFixture({ getFeasibility() { throw new Error('must not run'); } });
  try {
    const job = f.store.create(jobConfig(f.root));
    const report = await f.runner.run(job.id, f.parent, new AbortController().signal, undefined, { planOnly: true }).result;
    assert.equal(report.status, 'planned'); assert.deepEqual(roles(f), ['planner']);
    assert.equal(report.feasibility, undefined); assert.equal(report.snapshot, undefined);
  } finally { await f.bindings.dispose(); }
});

for (const defect of ['missing-task', 'contradictory-status', 'model-error']) test(`invalid feasibility ${defect} degrades to the planner self-check instead of failing the run`, async () => {
  const f = runnerFixture({
    getFeasibility() { const result = defect === 'contradictory-status' ? unresolved() : feasibility(); if (defect === 'missing-task') result.tasks.pop(); else result.status = 'ready'; return result; },
    beforeResult({ role }) { if (role === 'feasibility' && defect === 'model-error') throw new Error('feasibility model unavailable'); },
  });
  try {
    const before = source(f), job = f.store.create(jobConfig(f.root));
    const report = await f.runner.run(job.id, f.parent, new AbortController().signal).result;
    // 运行故障降级：不判死整条 run，但必须在报告里留下痕迹，且不伪造复核结论。
    assert.equal(report.status, 'needs_validation', report.error);
    assert.ok(report.feasibilityDegraded, 'degradation must be recorded');
    assert.equal(report.feasibility, undefined);
    assert.ok(report.events.some(event => event.stage === 'feasibility-degraded'));
    assert.deepEqual(roles(f), ['planner', 'feasibility', 'worker', 'worker', 'reviewer']);
    assert.notDeepEqual(source(f), before);
  } finally { await f.bindings.dispose(); }
});

test('external cancellation during confirmation prevents every writer and closes child permissions', async () => {
  const controller = new AbortController();
  const f = runnerFixture({ beforeResult({ role }) { if (role === 'feasibility') controller.abort('stop during confirmation'); } });
  try {
    const before = source(f), job = f.store.create(jobConfig(f.root));
    const report = await f.runner.run(job.id, f.parent, controller.signal).result;
    assert.equal(report.status, 'cancelled'); assert.deepEqual(roles(f), ['planner', 'feasibility']);
    assert.equal(report.snapshot, undefined); assert.deepEqual(source(f), before); assert.equal(f.disposed.length, 2);
  } finally { await f.bindings.dispose(); }
});

test('background result retains clarification questions while reporting blocked as failed', async () => {
  const f = runnerFixture({ getFeasibility: () => unresolved() });
  try {
    const job = f.store.create(jobConfig(f.root)); let outcome;
    f.ctx.jobs = { start(spec) { outcome = spec.run({ updateProgress() {}, append() {} }).done; return 'confirmation-job'; } };
    const spec = toolSpecs(f.ctx, f.store, f.runner, () => null).find(tool => tool.name === 'orchestrate_run');
    assert.equal((await spec.execute({ task_id: job.id, run_in_background: true }, { agent: f.parent })).jobId, 'confirmation-job');
    const result = await outcome, report = JSON.parse(result.result);
    assert.equal(result.status, 'failed'); assert.equal(report.status, 'blocked');
    assert.match(report.nextAction.questions[0], /Should b be clamped/); assert.match(result.detail, /src\/b.js/);
  } finally { await f.bindings.dispose(); }
});

test('settings distinguish planner self-check from conditional independent review', () => {
  const html = page(); assert.match(html, /按实际计划形状决定/);
  assert.match(html, /单任务且无跨任务依赖时使用 planner 自检/);
  assert.match(html, /多任务或跨任务依赖时，额外有 1 个只读可行性确认会话/);
  assert.match(html, /planner 源码可行性自检/); assert.match(html, /未取得独立复核结论/);
  assert.match(html, /任务分层/); assert.match(html, /建议步骤（可调整）/); assert.match(html, /待主会话澄清/);
});

test('native host schema validator accepts layered plans and feasibility and rejects legacy or extra fields', async t => {
  if (!process.env.DSH_APP_ROOT) return t.skip('Set DSH_APP_ROOT to verify against an installed DSH');
  const { createRequire } = await import('node:module'); const { pathToFileURL } = await import('node:url');
  const installed = createRequire(path.join(process.env.DSH_APP_ROOT, 'package.json'));
  const { validateJsonSchemaValue } = await import(pathToFileURL(installed.resolve('@deepseek-ai/dsh-tools')));
  assert.equal(validateJsonSchemaValue(PLAN_SCHEMA, plan(), '').length, 0);
  const missingCheck = plan(); delete missingCheck.tasks[0].feasibility;
  assert.ok(validateJsonSchemaValue(PLAN_SCHEMA, missingCheck, '').length);
  const extraCheckField = plan(); extraCheckField.tasks[0].feasibility.taskId = 'b';
  assert.ok(validateJsonSchemaValue(PLAN_SCHEMA, extraCheckField, '').length);
  assert.equal(validateJsonSchemaValue(FEASIBILITY_SCHEMA, feasibility(), '').length, 0);
  assert.equal(validateJsonSchemaValue(FEASIBILITY_SCHEMA, unresolved(), '').length, 0);
  const bad = plan(); bad.tasks[0].instruction = 'old';
  assert.ok(validateJsonSchemaValue(PLAN_SCHEMA, bad, '').length);
  assert.ok(validateJsonSchemaValue(FEASIBILITY_SCHEMA, { ...feasibility(), changedFiles: [] }, '').length);
});
