import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import path from 'node:path';
import { jobConfig, runnerFixture, plan } from './harness.mjs';
import { serverFixture } from './settings-fixture.mjs';
import { validateJob } from '../src/policy.js';
import { defaultConfig, validateModelRoutes } from '../src/models.js';
import { normalizeReviewLevel, reviewPolicy } from '../src/review-policy.js';
import { plannerPrompt, workerPrompt, reviewerPrompt, receiptPrompt } from '../src/prompts.js';
import { toolSpecs } from '../src/index.js';

const roleCalls = (f, role) => f.calls.filter(call => call.label.split(':')[2] === role);
function dataFixture(f, name) {
  mkdirSync(path.join(f.root, 'data'), { recursive: true });
  writeFileSync(path.join(f.root, 'checks.config.mjs'), "export default { packs: ['geo.vector'], include: ['data/**/*.geojson'] };\n");
  if (name) writeFileSync(path.join(f.root, 'data', 'sample.geojson'), readFileSync(new URL('../assertions/fixtures/' + name, import.meta.url)));
}
async function runCase(t, overrides = {}, options = {}, data) {
  const f = runnerFixture(options);
  t.after(() => f.bindings.dispose());
  if (data !== undefined) dataFixture(f, data);
  const job = f.store.create(jobConfig(f.root, overrides));
  const report = await f.runner.run(job.id, f.parent, new AbortController().signal).result;
  return { f, job, report };
}

test('reviewLevel is strict enum, preserves legacy standard defaults and adapter input', () => {
  assert.equal(normalizeReviewLevel(), 'standard');
  for (const level of ['exploratory', 'standard', 'strict']) assert.equal(normalizeReviewLevel(' ' + level + ' '), level);
  for (const value of ['off', 'never', 'low', 0, false, {}, []]) assert.throws(() => normalizeReviewLevel(value), /reviewLevel/);
  const root = path.resolve('.');
  assert.equal(jobConfig(root).reviewLevel, 'standard');
  assert.equal(jobConfig(root, { adapter: { reviewLevel: 'exploratory' } }).reviewLevel, 'exploratory');
  assert.equal(defaultConfig([]).reviewLevel, 'standard');
  assert.equal(defaultConfig([], { reviewLevel: 'strict' }).reviewLevel, 'strict');
  assert.equal(defaultConfig([], { adapter: { reviewLevel: 'exploratory' } }).reviewLevel, 'exploratory', 'adapter level must survive settings defaults projection');
  assert.equal(validateJob(defaultConfig([], { ...jobConfig(root), reviewLevel: undefined, adapter: { reviewLevel: 'strict' } })).reviewLevel, 'strict');
  assert.deepEqual(reviewPolicy({ reviewLevel: 'strict', reviewMode: 'on_failure' }), { level: 'strict', modelReview: true, assertionBypass: false, autoRepair: true, runtimeVerified: false });
});

test('exploratory validates active models only; an inactive unsupported effort does not block creation', async () => {
  const calls = [];
  const ctx = { llm: { async resolveCallConfig(route) { calls.push(route); if (route.reasoningEffort === 'stale') throw Error('stale capability'); return route; } } };
  const config = jobConfig(path.resolve('.'), { reviewLevel: 'exploratory', reviewer: { provider: 'removed', model: 'old', effort: 'stale' } });
  await validateModelRoutes(ctx, config);
  assert.equal(calls.length, 3);
  assert.ok(calls.every(route => route.provider !== 'removed'));
  await assert.rejects(validateModelRoutes(ctx, { ...config, reviewLevel: 'standard' }), /reviewer 模型配置不可用/);
  await assert.rejects(validateModelRoutes(ctx, { ...config, reviewLevel: 'strict' }), /reviewer 模型配置不可用/);
});

test('exploratory implements with no reviewer/recovery/repair calls and explicit runtime-unverified outcome', async t => {
  const { f, report } = await runCase(t, { reviewLevel: 'exploratory', maxRepairRounds: 2, verifyHint: 'Run the existing minimal smoke check', reviewer: { provider: 'unused', model: 'stale', effort: 'invalid' } });
  assert.equal(report.status, 'needs_validation', report.error);
  assert.equal(report.verdict, 'exploratory_unreviewed');
  assert.equal(report.review, null);
  assert.deepEqual(report.reviewSkipped, { reason: 'exploratory', level: 'exploratory' });
  assert.equal(report.reviewPolicy.runtimeVerified, false);
  assert.equal(report.nextAction.runtimeVerified, false);
  assert.match(report.nextAction.note, /未经模型复核/);
  assert.match(report.nextAction.note, /未执行构建/);
  assert.ok(report.nextAction.checksNeeded.includes('Run the existing minimal smoke check'));
  assert.equal(report.reviewAttempts, undefined);
  assert.equal(report.repair, undefined);
  assert.equal(roleCalls(f, 'planner').length, 1);
  assert.equal(roleCalls(f, 'worker').length, 2);
  assert.equal(roleCalls(f, 'feasibility').length, 1, 'independent feasibility safety policy is preserved');
  assert.equal(roleCalls(f, 'reviewer').length, 0);
  assert.equal(roleCalls(f, 'receipt').length, 0);
  assert.equal(readFileSync(path.join(f.root, 'src/a.js'), 'utf8'), 'export const a = 2;\n');
});

test('a single exploratory task without dependencies uses only planner and worker', async t => {
  const candidate = plan(); candidate.tasks = [candidate.tasks[0]]; candidate.tasks[0].provides = [];
  const { f, report } = await runCase(t, { reviewLevel: 'exploratory' }, { getPlan: () => candidate });
  assert.equal(report.status, 'needs_validation', report.error);
  assert.equal(roleCalls(f, 'feasibility').length, 0);
  assert.deepEqual(f.calls.map(call => call.label.split(':')[2]), ['planner', 'worker']);
});

test('exploration still executes selected assertions and never upgrades data pass to code approval', async t => {
  const { f, report } = await runCase(t, { reviewLevel: 'exploratory', assertions: ['geo.vector/geojson'] }, {}, 'good/clean.geojson');
  assert.equal(report.status, 'needs_validation', report.error);
  assert.equal(report.verdict, 'exploratory_unreviewed');
  assert.equal(report.assertions.status, 'pass');
  assert.ok(report.assertions.counts.checks_run > 0);
  assert.equal(report.assertions.exit_code, 0);
  assert.equal(roleCalls(f, 'reviewer').length, 0);
});

for (const [label, data, selection, expectedStatus] of [
  ['error', 'bad/unclosed.geojson', ['geom.ring.closed'], 'issues_found'],
  ['warning', 'bad/cw-exterior.geojson', ['geom.ring.winding'], 'pass_with_warnings'],
  ['not applicable', null, ['geom.ring.closed'], 'not_applicable'],
]) test('exploratory selected assertion ' + label + ' blocks without hidden model calls or auto repair', async t => {
  const { f, report } = await runCase(t, { reviewLevel: 'exploratory', assertions: selection, maxRepairRounds: 2 }, {}, data);
  assert.equal(report.status, 'blocked', report.error);
  assert.equal(report.verdict, 'blocked_by_data');
  assert.equal(report.assertions.status, expectedStatus);
  assert.ok(report.blockers.length);
  assert.equal(report.review, null);
  assert.equal(report.reviewSkipped.reason, 'exploratory');
  assert.equal(report.repair, undefined);
  assert.equal(roleCalls(f, 'reviewer').length, 0);
  assert.equal(roleCalls(f, 'planner').length, 1);
  assert.equal(report.rollback, undefined, 'assertion findings preserve files for explicit next action, not silent cleanup');
  assert.match(report.nextAction.note, /不能作为通过交付/);
});

test('exploration keeps worker failure and task-local rollback semantics', async t => {
  const { f, report } = await runCase(t, { reviewLevel: 'exploratory' }, { failWorker: 'a' });
  assert.equal(report.status, 'failed');
  assert.equal(roleCalls(f, 'reviewer').length, 0);
  assert.equal(readFileSync(path.join(f.root, 'src/a.js'), 'utf8'), 'export const a = 1;\n');
});

test('exploration does not bypass protected-file plan validation', async t => {
  const { f, report } = await runCase(t, { reviewLevel: 'exploratory', protectedFiles: ['src/a.js'], maxPlanRetries: 0 });
  assert.equal(report.status, 'failed');
  assert.equal(roleCalls(f, 'worker').length, 0);
  assert.match(report.error, /保护/);
});

test('legacy standard on_failure still skips only after actual assertion success', async t => {
  const { f, report } = await runCase(t, { reviewMode: 'on_failure', assertions: ['geo.vector/geojson'] }, {}, 'good/clean.geojson');
  assert.equal(report.reviewLevel, 'standard');
  assert.equal(report.verdict, 'passed_by_assertions');
  assert.equal(roleCalls(f, 'reviewer').length, 0);
});

test('strict reviews despite successful data assertions and on_failure timing', async t => {
  const { f, report } = await runCase(t, { reviewLevel: 'strict', reviewMode: 'on_failure', assertions: ['geo.vector/geojson'] }, {}, 'good/clean.geojson');
  assert.equal(report.status, 'needs_validation', report.error);
  assert.equal(report.assertions.status, 'pass');
  assert.equal(report.review.assessment, 'verified_statically');
  assert.equal(report.reviewSkipped, undefined);
  assert.equal(roleCalls(f, 'reviewer').length, 1);
  assert.match(roleCalls(f, 'reviewer')[0].prompt[0].text, /验收档位：严格/);
});

test('level prompts limit exploration scope without overriding user constraints and expand strict scrutiny', () => {
  const exploratory = jobConfig(path.resolve('.'), { reviewLevel: 'exploratory' });
  const p = plan();
  for (const text of [plannerPrompt(exploratory), workerPrompt(exploratory, p, p.tasks[0])]) {
    assert.match(text, /验收档位：探索/);
    assert.match(text, /保留用户明确要求/);
    assert.match(text, /不能声称运行不报错/);
  }
  assert.doesNotMatch(receiptPrompt(exploratory, p.tasks[0], {}), /独立 reviewer 仍会复核/);
  const strict = reviewerPrompt({ ...exploratory, reviewLevel: 'strict' }, p, [], []);
  assert.match(strict, /输入边界、错误处理/);
  assert.match(strict, /静态结论与待实测结论分开/);
});

test('HTTP defaults, scoped browser draft and creation persist reviewLevel without validating inactive reviewer', async t => {
  const f = await serverFixture(); t.after(() => f.close());
  const staleReviewer = { provider: 'unused', model: 'old', effort: 'invalid' };
  const config = jobConfig(f.root, { reviewLevel: 'exploratory', reviewer: staleReviewer });
  const savedResponse = await f.call('save', config);
  assert.equal(savedResponse.status, 200); assert.equal((await savedResponse.json()).reviewLevel, 'exploratory');
  const raw = { ...config }; delete raw.reviewer;
  assert.equal((await f.call('save', raw)).status, 200);
  assert.deepEqual(f.store.defaults().reviewer, staleReviewer, 'inactive stale default retained across save');
  const opened = await (await f.call('bridge/open', { sessionId: 'review-levels', workspaceRoot: f.root })).json();
  const headers = { 'x-settings-token': opened.browserToken };
  const draftResponse = await f.call('bridge/draft', { bridgeId: opened.bridgeId, config: raw }, { headers });
  assert.equal(draftResponse.status, 200);
  const draft = await draftResponse.json(); assert.deepEqual(draft.reviewer, staleReviewer);
  const state = await (await f.call('state', undefined, { headers })).json();
  assert.equal(state.defaults.reviewLevel, 'exploratory');
  assert.deepEqual(state.defaults.reviewer, staleReviewer);
  const response = await f.call('job', raw, { headers: { ...headers, 'x-orchestrator-bridge': opened.bridgeId } });
  assert.equal(response.status, 200); assert.equal((await response.json()).job.reviewLevel, 'exploratory');
  const legacy = { ...raw, reviewerProvider: 'legacy-route', reviewerModel: 'legacy-model', reviewerEffort: 'low' };
  const legacySave = await f.call('save', legacy); assert.equal(legacySave.status, 200);
  assert.deepEqual((await legacySave.json()).reviewer, { provider: 'legacy-route', model: 'legacy-model', effort: 'low' }, 'preserved inactive defaults cannot override an explicit legacy route');
  const legacyDraft = await f.call('bridge/draft', { bridgeId: opened.bridgeId, config: legacy }, { headers });
  assert.equal(legacyDraft.status, 200); assert.equal((await legacyDraft.json()).reviewer.provider, 'legacy-route');
  assert.equal((await f.call('save', { ...config, reviewLevel: 'strict' })).status, 400, 'reactivation validates stale effort again');
  assert.equal((await f.call('job', { ...raw, reviewLevel: 'off' })).status, 400);
});

test('orchestrate_task schema and actual tool creation support exploratory reviewLevel', async t => {
  const f = await serverFixture(); t.after(() => f.close());
  const specs = toolSpecs(f.ctx, f.store, {}, () => f.settings);
  const tool = specs.find(spec => spec.name === 'orchestrate_task');
  assert.deepEqual(tool.parameters.config.properties.reviewLevel.enum, ['exploratory', 'standard', 'strict']);
  const config = jobConfig(f.root, { reviewLevel: 'exploratory', reviewer: { provider: 'unused', model: 'old', effort: 'invalid' } });
  const created = await tool.execute({ action: 'create', config });
  assert.equal(created.job.reviewLevel, 'exploratory');
  const loaded = validateJob(f.store.get(created.job.id));
  assert.equal(loaded.reviewLevel, 'exploratory');
});

for (const level of ['exploratory', 'standard']) test(level + ' cancellation during assertion await cannot report completion', async t => {
  const f = runnerFixture(); t.after(() => f.bindings.dispose());
  const controller = new AbortController(), originalDiff = f.store.diff;
  let fullManifestDiffs = 0;
  f.store.diff = (...args) => {
    const result = originalDiff(...args);
    if (args[1].length === 2 && ++fullManifestDiffs === 2) {
      queueMicrotask(() => controller.abort(new Error('cancel during assertion await')));
    }
    return result;
  };
  const job = f.store.create(jobConfig(f.root, { reviewLevel: level }));
  const report = await f.runner.run(job.id, f.parent, controller.signal).result;
  assert.equal(controller.signal.aborted, true);
  assert.equal(report.status, 'cancelled');
  assert.equal(report.verdict, undefined);
  assert.equal(report.reviewSkipped, undefined);
  assert.equal(roleCalls(f, 'reviewer').length, 0);
  assert.ok(report.rollback);
  assert.equal(readFileSync(path.join(f.root, 'src/a.js'), 'utf8'), 'export const a = 1;\n');
});

test('exploratory cancellation from assertion evidence progress is also honored', async t => {
  const f = runnerFixture(); t.after(() => f.bindings.dispose()); dataFixture(f, 'good/clean.geojson');
  const controller = new AbortController();
  const job = f.store.create(jobConfig(f.root, { reviewLevel: 'exploratory', assertions: ['geom.ring.closed'] }));
  const report = await f.runner.run(job.id, f.parent, controller.signal, stage => {
    if (stage === 'assertions') controller.abort(new Error('cancel from assertion progress'));
  }).result;
  assert.equal(report.status, 'cancelled');
  assert.equal(report.assertions.status, 'pass');
  assert.equal(report.verdict, undefined);
  assert.equal(roleCalls(f, 'reviewer').length, 0);
});

test('cancellation from exploration delivery event removes stale successful nextAction wording', async t => {
  const f = runnerFixture(); t.after(() => f.bindings.dispose());
  const controller = new AbortController();
  const job = f.store.create(jobConfig(f.root, { reviewLevel: 'exploratory' }));
  const report = await f.runner.run(job.id, f.parent, controller.signal, stage => {
    if (stage === 'review-skipped') controller.abort(new Error('cancel at delivery event'));
  }).result;
  assert.equal(report.status, 'cancelled');
  assert.equal(report.verdict, undefined);
  assert.match(report.nextAction.note, /未交付待试用结果/);
  assert.ok(report.rollback);
  assert.equal(readFileSync(path.join(f.root, 'src/a.js'), 'utf8'), 'export const a = 1;\n');
});

test('worker-owned assertion failure cannot trigger exploratory automatic repair', async t => {
  const candidate = plan(); candidate.tasks = [candidate.tasks[0]];
  candidate.tasks[0].files = ['src/owned.geojson']; candidate.tasks[0].provides = [];
  const bad = readFileSync(new URL('../assertions/fixtures/bad/unclosed.geojson', import.meta.url), 'utf8');
  const f = runnerFixture({ getPlan: () => candidate, afterWorkerWrite: ({ file }) => writeFileSync(file, bad) });
  t.after(() => f.bindings.dispose());
  writeFileSync(path.join(f.root, 'checks.config.mjs'), "export default { packs:['geo.vector'], include:['src/**/*.geojson'] };\n");
  const job = f.store.create(jobConfig(f.root, { reviewLevel: 'exploratory', assertions: ['geom.ring.closed'], maxRepairRounds: 2 }));
  const report = await f.runner.run(job.id, f.parent, new AbortController().signal).result;
  assert.equal(report.status, 'blocked', report.error);
  assert.ok(report.assertions.findings.some(finding => finding.owner === 'worker'));
  assert.equal(report.repair, undefined);
  assert.equal(roleCalls(f, 'planner').length, 1);
  assert.equal(roleCalls(f, 'worker').length, 1);
  assert.equal(roleCalls(f, 'reviewer').length, 0);
  assert.equal(readFileSync(path.join(f.root, 'src/owned.geojson'), 'utf8'), bad);
});

test('exploratory obsolete selection cannot silently bypass an unexecuted assertion', async t => {
  // Creation rejects unknown selections; this exercises an old saved task after catalog changes.
  const { f, report } = await runCase(t, { reviewLevel: 'exploratory', assertions: ['geo.vector/removed-check'] });
  assert.equal(report.status, 'blocked', report.error);
  assert.equal(report.assertions.status, 'not_applicable');
  assert.equal(report.verdict, 'blocked_by_data');
  assert.equal(roleCalls(f, 'reviewer').length, 0);
  assert.match(report.nextAction.note, /不能作为通过交付/);
});

test('exploratory assertion runner configuration error cannot become successful delivery', async t => {
  const f = runnerFixture(); t.after(() => f.bindings.dispose());
  writeFileSync(path.join(f.root, 'checks.config.mjs'), "throw new Error('fixture config failure');\n");
  const job = f.store.create(jobConfig(f.root, { reviewLevel: 'exploratory', assertions: ['geom.ring.closed'] }));
  const report = await f.runner.run(job.id, f.parent, new AbortController().signal).result;
  assert.equal(report.status, 'blocked', report.error);
  assert.equal(report.assertions.status, 'error');
  assert.equal(report.verdict, 'blocked_by_data');
  assert.equal(roleCalls(f, 'reviewer').length, 0);
  assert.match(report.nextAction.note, /不能作为通过交付/);
});

test('omitted exploratory reviewer preserves legacy flat previous defaults in global and scoped saves', async t => {
  const f = await serverFixture(); t.after(() => f.close());
  const raw = jobConfig(f.root, { reviewLevel: 'exploratory' }); delete raw.reviewer;
  const previous = { ...raw, reviewerProvider: 'legacy-previous', reviewerModel: 'old-model', reviewerEffort: 'invalid' };
  f.store.saveDefaults(previous);
  const global = await f.call('save', raw); assert.equal(global.status, 200);
  assert.deepEqual((await global.json()).reviewer, { provider: 'legacy-previous', model: 'old-model', effort: 'invalid' });
  f.store.saveDefaults(previous);
  const opened = await (await f.call('bridge/open', { sessionId: 'legacy-preserved', workspaceRoot: f.root })).json();
  const draft = await f.call('bridge/draft', { bridgeId: opened.bridgeId, config: raw }, { headers: { 'x-settings-token': opened.browserToken } });
  assert.equal(draft.status, 200);
  assert.deepEqual((await draft.json()).reviewer, { provider: 'legacy-previous', model: 'old-model', effort: 'invalid' });
});

test('background wrapper preserves unreviewed metadata and maps blocked assertions to failure', async t => {
  const f = await serverFixture(); t.after(() => f.close());
  for (const status of ['needs_validation', 'blocked']) {
    const report = { status, review: null, reviewLevel: 'exploratory', verdict: status === 'blocked' ? 'blocked_by_data' : 'exploratory_unreviewed', reviewSkipped: { reason: 'exploratory', level: 'exploratory' }, nextAction: { runtimeVerified: false } };
    let pending;
    f.ctx.jobs = { start(spec) { pending = spec.run({ updateProgress() {}, append() {} }); return 'background-fixture'; } };
    const runner = { run() { return { id: 'run-fixture', result: Promise.resolve(report) }; } };
    const tool = toolSpecs(f.ctx, f.store, runner, () => f.settings).find(spec => spec.name === 'orchestrate_run');
    const started = await tool.execute({ task_id: 'fixture-task', run_in_background: true }, { agent: { session: { id: 'original-session' } } });
    assert.equal(started.kind, 'background');
    const result = await pending.done;
    assert.equal(result.status, status === 'blocked' ? 'failed' : 'completed');
    const nested = JSON.parse(result.result);
    assert.equal(nested.verdict, report.verdict);
    assert.equal(nested.reviewSkipped.reason, 'exploratory');
    assert.equal(nested.nextAction.runtimeVerified, false);
  }
});
