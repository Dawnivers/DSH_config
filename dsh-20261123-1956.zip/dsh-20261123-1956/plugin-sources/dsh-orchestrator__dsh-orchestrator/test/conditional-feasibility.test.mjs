import test from 'node:test';
import assert from 'node:assert/strict';
import path from 'node:path';
import { readFileSync, existsSync } from 'node:fs';
import { PLAN_SCHEMA, validatePlan } from '../src/policy.js';
import { plannerFeasibility, feasibilityPolicy } from '../src/feasibility.js';
import { plannerPrompt } from '../src/prompts.js';
import { toolSpecs } from '../src/index.js';
import { fixture, jobConfig, plan, runnerFixture } from './harness.mjs';

const roles = f => f.calls.map(call => call.label.split(':')[2]);
const source = f => ['a', 'b'].map(name => readFileSync(path.join(f.root, 'src', name + '.js'), 'utf8'));
function single() {
  const candidate = plan();
  candidate.tasks.splice(1); candidate.tasks[0].provides = [];
  candidate.acceptance = ['a is 2'];
  return candidate;
}

test('planner schema requires bounded source self-checks and rejects missing or malformed check structure', () => {
  const f = fixture(), job = jobConfig(f.root);
  const taskSchema = PLAN_SCHEMA.properties.tasks.items;
  assert.ok(taskSchema.required.includes('feasibility'));
  assert.equal(taskSchema.properties.feasibility.additionalProperties, false);
  const mutations = [
    task => { delete task.feasibility; },
    task => { task.feasibility = null; },
    task => { task.feasibility = []; },
    task => { task.feasibility.status = 'unknown'; },
    task => { task.feasibility.summary = ' '; },
    task => { task.feasibility.summary = 'x'.repeat(4001); },
    task => { task.feasibility.evidence = []; },
    task => { task.feasibility.evidence = ['']; },
    task => { task.feasibility.evidence = Array(21).fill('src/a.js: a'); },
    task => { task.feasibility.evidence = ['x'.repeat(4001)]; },
    task => { task.feasibility.questions = ['unresolved even though ready']; },
    task => { task.feasibility.status = 'needs_clarification'; },
    task => { task.feasibility.taskId = 'b'; },
  ];
  for (const mutate of mutations) {
    const candidate = single(); mutate(candidate.tasks[0]);
    assert.throws(() => validatePlan(candidate, job), /可行性|feasibility|澄清|可行任务/);
  }
  assert.equal(plannerFeasibility(validatePlan(single(), job)).status, 'ready');
  assert.match(plannerPrompt(job), /将可行性检查合并在本次规划内完成/);
  assert.match(plannerPrompt(job), /不要为了跳过复核强行合并任务/);
});

test('plan shape decides review independently of worker ceiling, file count and planner flags', () => {
  const one = single();
  one.tasks[0].files.push('src/b.js'); one.skipFeasibility = false;
  assert.deepEqual(feasibilityPolicy(one), { required: false, taskCount: 1, crossTaskDependencies: 0, reason: '单任务且无跨任务依赖，采用 planner 源码自检，跳过独立 worker 模型复核。' });
  const several = plan(); several.skipFeasibility = true;
  assert.equal(feasibilityPolicy(several).required, true);
  assert.equal(feasibilityPolicy(several).crossTaskDependencies, 1);
  several.tasks.forEach(task => { task.provides = []; task.consumes = []; });
  assert.equal(feasibilityPolicy(several).required, true);
  assert.equal(feasibilityPolicy(several).crossTaskDependencies, 0);
});

for (const multipleFiles of [false, true]) test(`single task uses planner evidence with no extra model session; multipleFiles=${multipleFiles}`, async () => {
  const f = runnerFixture({
    getPlan() { const candidate = single(); if (multipleFiles) candidate.tasks[0].files.push('src/new.js'); return candidate; },
    getFeasibility() { throw new Error('single-task independent review must never run'); },
    beforeResult({ role, request, fire }) {
      if (role !== 'worker') return;
      assert.ok(request.prompt[0].text.includes('src/a.js: planner read the numeric export'));
      assert.match(request.prompt[0].text, /独立 worker 模型；null 表示未运行/);
      assert.equal(fire('read', { file_path: path.join(f.root, 'src/a.js') }), undefined);
      assert.match(fire('write', { file_path: path.join(f.root, 'src/b.js') }), /不属于此 worker/);
    },
  });
  try {
    const job = f.store.create(jobConfig(f.root, { maxWorkers: 6 }));
    const report = await f.runner.run(job.id, f.parent, new AbortController().signal).result;
    assert.equal(report.status, 'needs_validation', report.error);
    assert.deepEqual(roles(f), ['planner', 'worker', 'reviewer']);
    assert.equal(report.plannerFeasibility.status, 'ready');
    assert.equal(report.feasibility, undefined);
    assert.equal(report.feasibilityPolicy.required, false);
    assert.equal(report.feasibilityPolicy.taskCount, 1);
    assert.ok(report.events.some(event => event.stage === 'feasibility-skipped'));
    assert.ok(!report.events.some(event => event.stage === 'feasibility-ready'));
    assert.equal(report.snapshot.files.length, multipleFiles ? 2 : 1);
    assert.deepEqual(report.workers[0].changedFiles, ['src/a.js']);
    assert.deepEqual(source(f), ['export const a = 2;\n', 'export const b = 1;\n']);
    assert.deepEqual(f.store.runs(job.id)[0].plannerFeasibility, report.plannerFeasibility);
    assert.equal(f.disposed.length, 3);
  } finally { await f.bindings.dispose(); }
});

for (const dependencies of [false, true]) test(`multiple tasks still require independent worker review; dependencies=${dependencies}`, async () => {
  const f = runnerFixture({ getPlan() {
    const candidate = plan();
    if (!dependencies) candidate.tasks.forEach(task => { task.provides = []; task.consumes = []; });
    return candidate;
  } });
  try {
    const job = f.store.create(jobConfig(f.root));
    const report = await f.runner.run(job.id, f.parent, new AbortController().signal).result;
    assert.equal(report.status, 'needs_validation', report.error);
    assert.deepEqual(roles(f), ['planner', 'feasibility', 'worker', 'worker', 'reviewer']);
    assert.equal(report.feasibilityPolicy.required, true);
    assert.equal(report.feasibilityPolicy.crossTaskDependencies, dependencies ? 1 : 0);
    assert.equal(report.plannerFeasibility.status, 'ready');
    assert.equal(report.feasibility.status, 'ready');
    assert.ok(report.events.findIndex(event => event.stage === 'feasibility-ready') < report.events.findIndex(event => event.stage === 'snapshot'));
    for (const call of f.calls.filter(call => call.label.includes(':worker:'))) {
      assert.match(call.prompt[0].text, /planner read the numeric export/);
      assert.match(call.prompt[0].text, /existing numeric export is initialized/);
    }
  } finally { await f.bindings.dispose(); }
});

for (const kind of ['needs_clarification', 'blocked']) for (const several of [false, true]) test(`planner ${kind} stops before all extra sessions and snapshots; multipleTasks=${several}`, async () => {
  const f = runnerFixture({ getPlan() {
    const candidate = several ? plan() : single();
    Object.assign(candidate.tasks[0].feasibility, { status: kind, summary: 'src/a.js has an unresolved target requirement', questions: kind === 'needs_clarification' ? ['Should a be 2 or 3?'] : [] });
    return candidate;
  } });
  try {
    const before = source(f), job = f.store.create(jobConfig(f.root, { maxPlanRetries: 2 }));
    const report = await f.runner.run(job.id, f.parent, new AbortController().signal).result;
    assert.equal(report.status, 'blocked', report.error);
    assert.equal(report.plannerFeasibility.status, kind);
    assert.equal(report.feasibility, undefined);
    assert.equal(report.snapshot, undefined);
    assert.equal(report.workers, undefined);
    assert.equal(report.review, undefined);
    assert.equal(report.planAttempts, 1);
    assert.deepEqual(roles(f), ['planner']);
    assert.equal(existsSync(path.join(f.store.directory(job.id), 'snapshots')), false);
    assert.equal(report.nextAction.questions.length, kind === 'needs_clarification' ? 1 : 0);
    assert.match(report.nextAction.note, /不会自动重规划/);
    assert.deepEqual(source(f), before);
    assert.equal(f.store.status(job.id).status, 'blocked');
  } finally { await f.bindings.dispose(); }
});

test('missing planner evidence uses only existing bounded plan-validation retry', async () => {
  const f = runnerFixture({ getPlan(attempt) { const candidate = single(); if (attempt === 1) delete candidate.tasks[0].feasibility; return candidate; } });
  try {
    const job = f.store.create(jobConfig(f.root));
    const report = await f.runner.run(job.id, f.parent, new AbortController().signal).result;
    assert.equal(report.status, 'needs_validation', report.error);
    assert.equal(report.planAttempts, 2);
    assert.deepEqual(roles(f), ['planner', 'planner', 'worker', 'reviewer']);
    assert.match(f.calls[1].prompt[0].text, /上次计划或请求被拒原因：.*feasibility/);
  } finally { await f.bindings.dispose(); }
});

test('exhausted evidence validation cannot silently become a simple ready plan', async () => {
  const f = runnerFixture({ getPlan() { const candidate = single(); candidate.tasks[0].feasibility.evidence = []; return candidate; } });
  try {
    const before = source(f), job = f.store.create(jobConfig(f.root));
    const report = await f.runner.run(job.id, f.parent, new AbortController().signal).result;
    assert.equal(report.status, 'failed');
    assert.deepEqual(roles(f), ['planner', 'planner']);
    assert.match(report.error, /证据/);
    assert.equal(report.snapshot, undefined); assert.deepEqual(source(f), before);
  } finally { await f.bindings.dispose(); }
});

test('a single task cannot bypass interface validation with an unresolved external consumer', async () => {
  const f = runnerFixture({ getPlan() { const candidate = single(); candidate.tasks[0].consumes = [{ name: 'external', from: 'not-a-task', signature: 'number' }]; return candidate; } });
  try {
    const job = f.store.create(jobConfig(f.root, { maxPlanRetries: 0 }));
    const report = await f.runner.run(job.id, f.parent, new AbortController().signal).result;
    assert.equal(report.status, 'failed'); assert.match(report.error, /接口不闭合/);
    assert.deepEqual(roles(f), ['planner']); assert.equal(report.snapshot, undefined);
  } finally { await f.bindings.dispose(); }
});

test('cancellation on the single-task shortcut still stops before snapshots and writes', async () => {
  const controller = new AbortController(), f = runnerFixture({ getPlan: single });
  try {
    const before = source(f), job = f.store.create(jobConfig(f.root));
    const report = await f.runner.run(job.id, f.parent, controller.signal, stage => { if (stage === 'feasibility-skipped') controller.abort('cancel shortcut'); }).result;
    assert.equal(report.status, 'cancelled'); assert.deepEqual(roles(f), ['planner']);
    assert.equal(report.snapshot, undefined); assert.deepEqual(source(f), before);
  } finally { await f.bindings.dispose(); }
});

test('plan_only cancellation after planner self-check is reported as cancelled, not planned', async () => {
  const controller = new AbortController(), f = runnerFixture({ getPlan: single });
  try {
    const job = f.store.create(jobConfig(f.root));
    const report = await f.runner.run(job.id, f.parent, controller.signal, stage => { if (stage === 'planner-feasibility-ready') controller.abort('cancel plan-only'); }, { planOnly: true }).result;
    assert.equal(report.status, 'cancelled'); assert.deepEqual(roles(f), ['planner']);
    assert.equal(report.snapshot, undefined); assert.equal(report.feasibility, undefined);
  } finally { await f.bindings.dispose(); }
});

test('plan_only keeps planner evidence but does not claim independent review', async () => {
  const f = runnerFixture();
  try {
    const job = f.store.create(jobConfig(f.root));
    const report = await f.runner.run(job.id, f.parent, new AbortController().signal, undefined, { planOnly: true }).result;
    assert.equal(report.status, 'planned'); assert.deepEqual(roles(f), ['planner']);
    assert.equal(report.plannerFeasibility.status, 'ready'); assert.equal(report.feasibilityPolicy.required, true);
    assert.equal(report.feasibility, undefined); assert.equal(report.snapshot, undefined);
  } finally { await f.bindings.dispose(); }
});

test('worker mismatch on the shortcut is still failure and never reaches reviewer', async () => {
  const f = runnerFixture({ getPlan: single, workerResult() { return { status: 'mismatch', summary: 'source changed after planning', changedFiles: [] }; } });
  try {
    const job = f.store.create(jobConfig(f.root));
    const report = await f.runner.run(job.id, f.parent, new AbortController().signal).result;
    assert.equal(report.status, 'failed'); assert.match(report.error, /mismatch/);
    assert.deepEqual(roles(f), ['planner', 'worker']); assert.equal(report.review, undefined);
    assert.equal(report.feasibility, undefined); assert.deepEqual(source(f), ['export const a = 1;\n', 'export const b = 1;\n']);
  } finally { await f.bindings.dispose(); }
});

test('background planner clarification preserves concrete questions without any extra model', async () => {
  const f = runnerFixture({ getPlan() { const candidate = single(); candidate.tasks[0].feasibility.status = 'needs_clarification'; candidate.tasks[0].feasibility.questions = ['Should a be 2 or 3?']; return candidate; } });
  try {
    const job = f.store.create(jobConfig(f.root)); let outcome;
    f.ctx.jobs = { start(spec) { outcome = spec.run({ updateProgress() {}, append() {} }).done; return 'planner-check-job'; } };
    const tool = toolSpecs(f.ctx, f.store, f.runner, () => null).find(spec => spec.name === 'orchestrate_run');
    await tool.execute({ task_id: job.id, run_in_background: true }, { agent: f.parent });
    const result = await outcome, report = JSON.parse(result.result);
    assert.equal(result.status, 'failed'); assert.equal(report.status, 'blocked');
    assert.match(report.nextAction.questions[0], /Should a be 2 or 3/); assert.deepEqual(roles(f), ['planner']);
  } finally { await f.bindings.dispose(); }
});
