import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import { page } from '../src/ui.js';
import { renderPageExpression } from '../src/bundle.js';
import { serverFixture } from './settings-fixture.mjs';

// Tiny dependency-free DOM for the actual serialized page script. Selects, events,
// details and form ownership are exercised, not copied UI implementations.
class Node {
  constructor(doc, tag = '#text', text = '') { this.doc = doc; this.tagName = tag.toUpperCase(); this.children = []; this.attrs = {}; this.listeners = {}; this.dataset = {}; this._text = text; this._value = ''; this.hidden = false; this.checked = false; this.disabled = false; this.open = false; this.style = {}; }
  set id(value) { this.attrs.id = value; } get id() { return this.attrs.id || ''; }
  set className(value) { this.attrs.class = value; } get className() { return this.attrs.class || ''; }
  set textContent(value) { this._text = String(value); this.children = []; } get textContent() { return this._text + this.children.map(n => n.textContent).join(''); }
  get parentElement() { return this.parentNode; } get isConnected() { return !!this.parentNode; }
  get options() { return this.children.filter(n => n.tagName === 'OPTION'); }
  set value(value) { this._value = String(value); } get value() { if (this.tagName === 'SELECT') return this.options.some(n => n.value === this._value) ? this._value : (this.options[0]?.value || ''); return this._value; }
  set innerHTML(value) { this.replaceChildren(); parse(this.doc, this, value); } get innerHTML() { return this._html || ''; }
  append(...nodes) { for (let n of nodes) { if (typeof n === 'string') n = this.doc.createTextNode(n); n.parentNode = this; this.children.push(n); } }
  replaceChildren(...nodes) { this.children.forEach(n => { n.parentNode = null; }); this.children = []; this._text = ''; this.append(...nodes); }
  remove() { if (this.parentNode) { this.parentNode.children = this.parentNode.children.filter(n => n !== this); this.parentNode = null; } }
  setAttribute(key, value) { this.attrs[key] = String(value); if (key === 'value') this.value = value; if (key.startsWith('data-')) this.dataset[key.slice(5)] = String(value); if (['hidden','checked','disabled','open','required'].includes(key)) this[key] = true; }
  getAttribute(key) { if (key.startsWith('data-')) return this.dataset[key.slice(5)] ?? null; if (['type','name','value'].includes(key)) return this[key] ?? this.attrs[key] ?? null; return this.attrs[key] ?? null; }
  addEventListener(type, fn) { (this.listeners[type] ||= []).push(fn); }
  dispatch(type, extra = {}) { const event = { target: this, preventDefault() { this.defaultPrevented = true; }, ...extra }; for (let n = this; n; n = n.parentNode) for (const fn of n.listeners[type] || []) fn(event); return event; }
  click() { this.dispatch('click'); } focus() { this.doc.activeElement = this; } scrollIntoView() {}
  contains(node) { return node === this || this.children.some(n => n.contains(node)); }
  matches(selector) {
    if (selector.endsWith(':checked') && !this.checked) return false;
    selector = selector.replace(':checked', '');
    const tag = selector.match(/^[a-z]+/i)?.[0]; if (tag && this.tagName !== tag.toUpperCase()) return false;
    const id = selector.match(/#([\w-]+)/)?.[1]; if (id && this.id !== id) return false;
    const cls = selector.match(/\.([\w-]+)/)?.[1]; if (cls && !this.className.split(' ').includes(cls)) return false;
    for (const [, name, value] of selector.matchAll(/\[([^=\]]+)(?:="([^"]*)")?\]/g)) if (value === undefined ? this.getAttribute(name) === null : this.getAttribute(name) !== value) return false;
    return true;
  }
  querySelectorAll(selector) { const parts = selector.split(/\s+/); const result = []; const visit = node => { for (const child of node.children) { if (child.matches(parts.at(-1))) { let parent = child.parentNode; let index = parts.length - 2; while (index >= 0 && parent) { if (parent.matches(parts[index])) index--; parent = parent.parentNode; } if (index < 0) result.push(child); } visit(child); } }; visit(this); return result; }
  querySelector(selector) { return this.querySelectorAll(selector)[0] || null; }
  closest(selector) { for (let n = this; n; n = n.parentNode) if (n.matches(selector)) return n; return null; }
}
function decode(text) { return text.replaceAll('&quot;', '"').replaceAll('&#39;', "'").replaceAll('&lt;', '<').replaceAll('&gt;', '>').replaceAll('&amp;', '&'); }
function parse(doc, host, html) {
  host._html = html; const stack = [host];
  for (const piece of html.match(/<[^>]+>|[^<]+/g) || []) {
    if (piece.startsWith('</')) { if (stack.length > 1) stack.pop(); continue; }
    if (piece.startsWith('<!')) continue;
    if (piece.startsWith('<')) { const tag = piece.match(/^<([\w-]+)/)?.[1]; if (!tag) continue; const n = new Node(doc, tag); for (const [, key, value] of piece.slice(tag.length + 1, -1).matchAll(/([\w-]+)(?:="([^"]*)")?/g)) n.setAttribute(key, decode(value ?? '')); stack.at(-1).append(n); if (!['input','meta','br','hr','link'].includes(tag)) stack.push(n); }
    else { const value = decode(piece); if (stack.at(-1).tagName === 'TEXTAREA') stack.at(-1).value += value; else stack.at(-1).append(doc.createTextNode(value)); }
  }
}
function dom(html) {
  const doc = new Node(null, 'document'); doc.doc = doc;
  doc.createElement = tag => new Node(doc, tag); doc.createTextNode = text => new Node(doc, '#text', text);
  doc.getElementById = id => doc.querySelector('#' + id);
  parse(doc, doc, html.slice(html.indexOf('<body>'), html.indexOf('<script>'))); return doc;
}
async function flush() { for (let i = 0; i < 5; i++) await new Promise(setImmediate); }
function controlledClock() {
  let id = 0; const pending = new Map();
  return { setTimeout(fn, ms) { pending.set(++id, {fn,ms}); return id; }, clearTimeout(id) { pending.delete(id); },
    async fire(ms) { const entry = Array.from(pending).find(([, timer]) => timer.ms === ms); assert.ok(entry, 'expected pending timer ' + ms); pending.delete(entry[0]); entry[1].fn(); await flush(); }, pending };
}
function deferred() { let resolve, reject; const promise = new Promise((yes,no) => { resolve = yes; reject = no; }); return {promise,resolve,reject}; }
const jsonResponse = data => ({ok:true,status:200,json:async () => data});
async function studio(state, saveTransform = value => value, options = {}) {
  const html = page(options.boot); const document = dom(html); const sent = [];
  const window = { origin: 'http://localhost', addEventListener() {} }; window.parent = window;
  let current = state;
  const context = { document, window, parent: window, location: { origin: window.origin, search: '?token=test-token' }, URL, URLSearchParams, AbortController, setTimeout:options.clock?.setTimeout || setTimeout, clearTimeout:options.clock?.clearTimeout || clearTimeout, queueMicrotask, navigator: {}, console,
    fetch: async (url, request) => { const parsed = new URL(url), route = parsed.pathname.split('/settings/api/')[1] + parsed.search; const body = request.body && JSON.parse(request.body); const call = {route,body,headers:request.headers,url}; sent.push(call); if (options.fetch) { const result = await options.fetch(call); if (result !== undefined) return result; } return jsonResponse(route === 'save' ? saveTransform(body) : current); } };
  const source = html.match(/<script>([\s\S]*)<\/script>/)[1].replace('})();', 'window.ui = { cards, defaultsValue, fillDefaults, renderAssertions, selectedAssertions, loadState, renderConfigCanvas, renderRunDetails, revealField, fail, deliver, settleDelivery, currentSubmission, syncSubmitState, getActiveDelivery: function(){return activeDelivery;}, getBound: function(){return {bound:bound,bridgeReady:bridgeReady,detached:detached};} };\n})();');
  vm.runInNewContext(source, context);
  await flush();
  return { html, document, window, sent, ui: window.ui, $: id => document.getElementById(id), setState(next) { current = next; } };
}
let serverState;
test.before(async () => { const server = await serverFixture(); try { const response = await server.call('state'); assert.equal(response.status, 200); serverState = await response.json(); } finally { await server.close(); } });

test('production serialized page uses real state catalog and exact effort in clickable model drawers', async () => {
  const view = await studio(serverState); const { $, ui } = view;
  assert.equal($('configDrawer').hidden, true);
  assert.deepEqual($('configPipeline').children.slice(0,5).map(n => n.dataset.open), ['planner','feasibility','worker','assertions','reviewer']);
  for (const key of ['planner','feasibility','worker','reviewer']) {
    const route = serverState.defaults[key] || serverState.defaults.planner;
    const entry = serverState.models.find(m => m.provider === route.provider && m.model === route.model);
    assert.ok(entry, 'defaults resolve against actual settings state directory');
    assert.equal(ui.cards[key].box.hidden, true);
    assert.equal(ui.cards[key].select.options.length, serverState.models.length + 2);
    $('node-' + key).click();
    assert.equal($('configDrawer').hidden, false); assert.equal(ui.cards[key].box.hidden, false);
    assert.equal($('workerCapacity').hidden, key !== 'worker');
    assert.deepEqual(Array.from(ui.cards[key].effort.options, n => n.value), ['', ...entry.efforts.map(e => e.id)]);
    assert.ok($('node-' + key).textContent.includes(entry.label || entry.model));
    $('drawerClose').click(); assert.equal($('configDrawer').hidden, true); assert.equal(view.document.activeElement, $('node-' + key));
  }
  const worker = ui.cards.worker;
  const other = serverState.models.find(m => m.provider !== worker.provider.value || m.model !== worker.model.value);
  worker.select.value = JSON.stringify([other.provider, other.model]); worker.select.dispatch('change');
  assert.equal(worker.provider.value, other.provider); assert.equal(worker.model.value, other.model);
  assert.deepEqual(Array.from(worker.effort.options, n => n.value), ['', ...other.efforts.map(e => e.id)]);
  assert.equal(worker.effort.value, '');
  worker.effort.value = other.efforts[0].id; worker.effort.dispatch('change');
  assert.equal(ui.defaultsValue().worker.effort, other.efforts[0].id);
});

test('assertion package and group are collapsed before leaves, using the real scanned directory', async () => {
  const { $, ui } = await studio(serverState);
  assert.ok(serverState.assertions.packs.length);
  $('node-assertions').click(); assert.equal($('pane-assertions').hidden, false);
  const packs = $('assertGroups').querySelectorAll('.assert-pack');
  assert.equal(packs.length, serverState.assertions.packs.length);
  for (const pack of packs) { assert.equal(pack.tagName, 'DETAILS'); assert.equal(pack.open, false); }
  const group = $('assertGroups').querySelector('.assert-group'); assert.equal(group.open, false);
  const packData = serverState.assertions.packs[0], groupData = packData.groups[0];
  const values = [packData.id, packData.id + '/' + groupData.id, groupData.checks[0].id];
  ui.fillDefaults({...serverState.defaults, assertions: values});
  assert.deepEqual(Array.from(ui.selectedAssertions()), values);
  assert.doesNotMatch($('assertNotice').textContent, /不在编排内部执行|不会.*执行/);
});

test('missing selected package, group and check survive refresh, unavailable directory and explicit deselection', async () => {
  const view = await studio(serverState); const { $, ui } = view;
  const pack = serverState.assertions.packs[0];
  const values = [pack.id, pack.id + '/removed-group', 'removed.check', '__proto__'];
  ui.fillDefaults({...serverState.defaults, assertions: values});
  assert.deepEqual(new Set(ui.selectedAssertions()), new Set(values));
  assert.match($('unknownAssertions').textContent, /完整保留|不会静默清除/);
  await ui.loadState(false); assert.deepEqual(new Set(ui.selectedAssertions()), new Set(values));
  ui.renderAssertions({ available: false, reason: 'offline', packs: [] });
  assert.deepEqual(new Set(ui.selectedAssertions()), new Set(values));
  assert.equal($('unknownAssertions').querySelectorAll('input').length, values.length);
  ui.renderAssertions(serverState.assertions); assert.deepEqual(new Set(ui.selectedAssertions()), new Set(values));
  const unknown = $('unknownAssertions').querySelectorAll('input').find(n => n.value === 'removed.check'); unknown.checked = false;
  assert.ok(!ui.selectedAssertions().includes('removed.check'));
  assert.deepEqual(new Set(ui.defaultsValue().assertions), new Set(values.filter(v => v !== 'removed.check')));
});

test('drawer controls never submit; hidden invalid fields reveal their editor and retain all advanced config', async () => {
  const view = await studio(serverState); const { $, ui, document } = view;
  assert.equal($('drawerClose').getAttribute('type'), 'button'); assert.equal($('drawerDone').getAttribute('type'), 'button');
  for (const [id,key] of [['task','task'],['allowedGlobs','task'],['projectRoot','task'],['maxWorkers','worker'],['maxPlanRetries','limits'],['maxRepairRounds','limits']]) {
    $('drawerClose').click(); $(id).validationMessage = 'required ' + id;
    $(id).dispatch('invalid'); await new Promise(setImmediate);
    assert.equal($('configDrawer').hidden, false); assert.equal(document.activeElement, $(id));
    assert.equal($('drawerTitle').textContent, key === 'task' ? '任务与文件范围' : key === 'worker' ? '实施 · Workers' : '限额与高级配置');
  }
  ui.fillDefaults({...serverState.defaults, maxWorkers:3, maxPlanRetries:2, maxRepairRounds:2, rollbackOnFailure:false, protectedFiles:['secret.json'],allowProtected:true});
  const value = ui.defaultsValue();
  assert.equal(value.maxWorkers,3); assert.equal(value.maxPlanRetries,2); assert.equal(value.maxRepairRounds,2); assert.equal(value.rollbackOnFailure,false);
  assert.match($('repairLimitNotice').textContent, /当前执行器最多一次/);
  assert.match($('policySummary').textContent, /历史配置 2 已保留，不会执行两轮/);
  assert.deepEqual(Array.from(value.protectedFiles), ['secret.json']); assert.equal(value.allowProtected,true);
  $('maxRepairRounds').value = '3'; assert.throws(() => ui.defaultsValue(), /小于等于 2/);
  $('maxRepairRounds').value = '1'; ui.cards.reviewer.fill({...serverState.defaults.reviewer, effort:'removed-effort'});
  try { ui.defaultsValue(); assert.fail('unsupported effort must not submit'); } catch (error) { ui.fail(error); }
  assert.equal($('configDrawer').hidden, false); assert.equal(document.activeElement, $('reviewerEffort'));
  document.dispatch('keydown',{key:'Escape'}); assert.equal($('configDrawer').hidden,true);
  assert.equal(view.sent.filter(n => n.route === 'job').length,0);
});

test('default saving submits unknown values and keeps them visible when the server omits them', async () => {
  const view = await studio(serverState, value => ({...value, assertions:[]}));
  view.ui.fillDefaults({...serverState.defaults, assertions:['retired.assertion'], maxRepairRounds:1, rollbackOnFailure:false});
  view.$('saveDefaults').click();
  for (let i=0;i<3;i++) await new Promise(setImmediate);
  const saved = view.sent.find(item => item.route === 'save');
  assert.deepEqual(saved.body.assertions, ['retired.assertion']);
  assert.equal(saved.body.maxRepairRounds,1); assert.equal(saved.body.rollbackOnFailure,false);
  assert.deepEqual(Array.from(view.ui.selectedAssertions()), ['retired.assertion']);
  assert.match(view.$('message').textContent, /服务端未保存以下断言/);
  assert.match(view.$('node-assertions').textContent, /1 项目录缺失/);
});

const detachedBoot = {detached:true,bridgeId:'browser-bridge',sessionId:'original-session',sessionTitle:'原会话',workspaceRoot:'C:/prepared-project',token:'browser-token',parentOrigin:'http://localhost'};
function deliveryReceipt(taskId, status, result) { return {connected:true,deliveries:[{taskId,attempt:1,status,result}]}; }
async function browserStudio(fetch) {
  const clock = controlledClock();
  const view = await studio(serverState, value => value, {boot:detachedBoot,clock,fetch});
  view.$('task').value = 'Bound task A'; view.$('task').dispatch('input');
  return {...view,clock};
}

test('detached top-level page submits once with bridge header and recovers a lost submit HTTP receipt as sent', async () => {
  const view = await browserStudio(call => {
    if (call.route === 'job') return jsonResponse({id:'bound-task-a'});
    if (call.route === 'bridge/submit') throw new Error('HTTP response lost after enqueue');
    if (call.route.startsWith('bridge/status?')) return jsonResponse(deliveryReceipt('bound-task-a','sent',{ok:true,queued:true}));
  });
  assert.equal(view.window.parent,view.window);
  assert.deepEqual({...view.ui.getBound()}, {bound:true,bridgeReady:true,detached:true});
  assert.equal(view.$('createJob').disabled,false);
  assert.match(view.$('sessionTarget').textContent,/original-session/);
  view.$('configForm').dispatch('submit'); await flush();
  assert.equal(view.ui.currentSubmission().status,'sent'); assert.equal(view.$('createJob').disabled,true);
  const job = view.sent.find(c => c.route === 'job');
  assert.equal(job.headers['x-orchestrator-bridge'],detachedBoot.bridgeId); assert.equal(job.headers['x-settings-token'],detachedBoot.token);
  const submit = view.sent.find(c => c.route === 'bridge/submit');
  assert.deepEqual(submit.body,{bridgeId:detachedBoot.bridgeId,taskId:'bound-task-a'});
  assert.equal(submit.headers['x-orchestrator-bridge'],detachedBoot.bridgeId);
  view.$('configForm').dispatch('submit'); await flush();
  assert.equal(view.sent.filter(c => c.route === 'job').length,1);
  assert.equal(view.sent.filter(c => c.route === 'bridge/submit').length,1);
  assert.equal(view.sent.filter(c => c.route.startsWith('bridge/status?')).length,1);
  assert.match(view.$('message').textContent,/投递已确认/);
});

test('detached uncertain receipt locks the same configuration against re-creation or re-delivery', async () => {
  const view = await browserStudio(call => {
    if (call.route === 'job') return jsonResponse({id:'uncertain-task'});
    if (call.route === 'bridge/submit') return jsonResponse(deliveryReceipt('uncertain-task','uncertain',{ok:false,uncertain:true,error:'receipt unknown'}));
  });
  view.$('configForm').dispatch('submit'); await flush();
  assert.equal(view.ui.currentSubmission().status,'uncertain'); assert.equal(view.$('createJob').disabled,true);
  assert.match(view.$('message').textContent,/禁止重试发送/);
  view.$('configForm').dispatch('submit'); await flush();
  assert.equal(view.sent.filter(c => c.route === 'job').length,1); assert.equal(view.sent.filter(c => c.route === 'bridge/submit').length,1);
  assert.equal(view.ui.getActiveDelivery(),null);
});

test('a sent receipt arriving after two-minute timeout cannot unlock its uncertain configuration', async () => {
  const late = deferred();
  const view = await browserStudio(call => {
    if (call.route === 'job') return jsonResponse({id:'late-task-a'});
    if (call.route === 'bridge/submit') return late.promise;
  });
  view.$('configForm').dispatch('submit'); await flush();
  const record = view.ui.currentSubmission(); assert.equal(record.status,'pending');
  await view.clock.fire(120000);
  assert.equal(record.status,'uncertain'); assert.equal(view.$('createJob').disabled,true);
  const timeoutMessage = view.$('message').textContent; assert.match(timeoutMessage,/2 分钟/);
  late.resolve(jsonResponse(deliveryReceipt(record.id,'sent',{ok:true}))); await flush();
  assert.equal(record.status,'uncertain'); assert.equal(view.$('createJob').disabled,true);
  assert.equal(view.$('message').textContent,timeoutMessage); assert.equal(view.ui.getActiveDelivery(),null);
});

test('a timed-out old delivery cannot confirm another newly submitted task with its late sent receipt', async () => {
  const first = deferred(), second = deferred(); let jobs = 0;
  const view = await browserStudio(call => {
    if (call.route === 'job') return jsonResponse({id:++jobs === 1 ? 'old-task-a' : 'new-task-b'});
    if (call.route === 'bridge/submit') return call.body.taskId === 'old-task-a' ? first.promise : second.promise;
  });
  view.$('configForm').dispatch('submit'); await flush(); const old = view.ui.currentSubmission();
  await view.clock.fire(120000); assert.equal(old.status,'uncertain');
  view.$('task').value = 'New distinct task B'; view.$('task').dispatch('input');
  assert.equal(view.$('createJob').disabled,false);
  view.$('configForm').dispatch('submit'); await flush(); const next = view.ui.currentSubmission();
  assert.equal(next.id,'new-task-b'); assert.equal(next.status,'pending');
  first.resolve(jsonResponse(deliveryReceipt('old-task-a','sent',{ok:true}))); await flush();
  assert.equal(old.status,'uncertain'); assert.equal(next.status,'pending');
  assert.equal(view.ui.getActiveDelivery().record,next); assert.doesNotMatch(view.$('message').textContent,/投递已确认/);
  second.resolve(jsonResponse(deliveryReceipt('new-task-b','sent',{ok:true}))); await flush();
  assert.equal(next.status,'sent'); assert.equal(old.status,'uncertain');
  assert.equal(view.sent.filter(c => c.route === 'job').length,2); assert.equal(view.sent.filter(c => c.route === 'bridge/submit').length,2);
  view.$('task').value = 'Bound task A'; view.$('task').dispatch('input');
  assert.equal(view.ui.currentSubmission(),old); assert.equal(view.$('createJob').disabled,true);
});

test('detached defaults save the bridge-scoped draft, never global save or a task', async () => {
  const view = await browserStudio(call => call.route === 'bridge/draft' ? jsonResponse(call.body.config) : undefined);
  view.$('maxWorkers').value = '3'; view.$('rollbackOnFailure').checked = false;
  view.$('saveDefaults').click(); await flush();
  const draft = view.sent.find(c => c.route === 'bridge/draft'); assert.ok(draft);
  assert.equal(draft.headers['x-orchestrator-bridge'],detachedBoot.bridgeId);
  assert.equal(draft.body.bridgeId,detachedBoot.bridgeId); assert.equal(draft.body.config.maxWorkers,3); assert.equal(draft.body.config.rollbackOnFailure,false);
  assert.ok(!('task' in draft.body.config)); assert.ok(!('projectRoot' in draft.body.config));
  assert.equal(view.sent.filter(c => ['save','job','bridge/submit'].includes(c.route)).length,0);
  assert.match(view.$('message').textContent,/不影响 DSH 全局默认/);
});

test('validation level is top-level, legacy standard and switches without losing timing, repair or reviewer state', async () => {
  const { $, ui, document } = await studio(serverState);
  assert.equal($('reviewLevel').value, 'standard'); assert.equal(ui.defaultsValue().reviewLevel, 'standard');
  assert.deepEqual(Array.from($('reviewLevel').options, n => n.textContent), ['探索','标准','严格']);
  assert.ok(!('adapter' in ui.defaultsValue()));
  ui.fillDefaults({...serverState.defaults, reviewMode:'on_failure', maxRepairRounds:2});
  const modes = document.querySelectorAll('input[name="reviewMode"]');
  $('reviewLevel').value = 'strict'; $('reviewLevel').dispatch('change');
  assert.equal(ui.defaultsValue().reviewLevel, 'strict'); assert.equal(ui.defaultsValue().reviewMode, 'on_failure');
  assert.ok(modes.every(n => n.disabled)); assert.equal($('bypassWire').hidden, true);
  assert.match($('node-reviewer').textContent, /严格.*总是复核/);
  assert.match($('reviewLevelNotice').textContent, /不会自动执行运行时检查/);
  ui.cards.reviewer.fill({...serverState.defaults.reviewer, effort:'removed-effort'});
  $('reviewLevel').value = 'exploratory'; $('reviewLevel').dispatch('change');
  assert.equal(ui.defaultsValue().reviewLevel, 'exploratory'); assert.ok(!('reviewer' in ui.defaultsValue()));
  assert.equal(ui.cards.reviewer.routeFields.disabled, true); assert.equal($('maxRepairRounds').disabled, true);
  assert.equal(ui.defaultsValue().maxRepairRounds, 2); assert.equal(ui.defaultsValue().reviewMode, 'on_failure');
  assert.equal($('repairWire').hidden, true); assert.equal($('bypassWire').hidden, false);
  assert.match($('bypassWire').textContent, /跳过模型复核.*不自动修复/);
  assert.match($('node-reviewer').textContent, /探索.*停用/);
  assert.match($('reviewLevelNotice').textContent, /断言仍实际执行.*不适用/);
  $('node-reviewer').click(); assert.equal(ui.cards.reviewer.box.hidden, false); assert.equal($('configDrawer').hidden, false);
  $('reviewLevel').value = 'standard'; $('reviewLevel').dispatch('change');
  assert.equal(ui.cards.reviewer.effort.value, 'removed-effort'); assert.throws(() => ui.defaultsValue(), /当前档位/);
  assert.equal(ui.cards.reviewer.routeFields.disabled, false); assert.equal($('maxRepairRounds').disabled, false);
  assert.ok(modes.every(n => !n.disabled)); assert.equal($('maxRepairRounds').value, '2');
  assert.equal(document.querySelector('input[name="reviewMode"]:checked').value, 'on_failure');
});

test('exploratory defaults persist level and valid reviewer, while invalid inactive effort never blocks saving', async () => {
  const view = await studio(serverState); const { $, ui } = view;
  ui.fillDefaults({...serverState.defaults, reviewLevel:'exploratory', reviewMode:'on_failure', maxRepairRounds:2});
  assert.ok(ui.defaultsValue().reviewer, 'valid inactive route is persisted for reload');
  ui.cards.reviewer.fill({...serverState.defaults.reviewer, effort:'unsupported-saved-effort'});
  $('saveDefaults').click(); await flush();
  const saved = view.sent.find(c => c.route === 'save');
  assert.equal(saved.body.reviewLevel, 'exploratory'); assert.equal(saved.body.reviewMode, 'on_failure');
  assert.equal(saved.body.maxRepairRounds, 2); assert.ok(!('reviewer' in saved.body));
  assert.equal($('reviewLevel').value, 'exploratory'); assert.equal(ui.cards.reviewer.effort.value, 'unsupported-saved-effort');
  assert.equal($('message').className, 'banner ok');
  await ui.loadState(false); assert.equal($('reviewLevel').value, 'exploratory');
  assert.equal(ui.cards.reviewer.effort.value, 'unsupported-saved-effort');
  ui.fillDefaults({...serverState.defaults, reviewLevel:'strict'}); assert.equal($('reviewLevel').value, 'strict');
  ui.fillDefaults({...serverState.defaults}); assert.equal($('reviewLevel').value, 'standard');
});

test('an empty reviewer catalog and invalid unused route do not block exploratory create', async () => {
  const manual = {provider:'manual-provider', model:'manual-model'};
  const view = await studio({...serverState, models:[], defaults:{...serverState.defaults, planner:manual, worker:manual, feasibility:manual, reviewer:{}, reviewLevel:'exploratory'}}, value => value, {fetch: call => call.route === 'job' ? jsonResponse({id:'explore-job'}) : undefined});
  assert.equal(view.$('createJob').disabled, false);
  view.$('projectRoot').value = 'C:/prepared-project'; view.$('task').value = 'Make a draft without unused review calls';
  view.$('configForm').dispatch('submit'); await flush();
  const created = view.sent.find(c => c.route === 'job'); assert.ok(created);
  assert.equal(created.body.reviewLevel, 'exploratory'); assert.ok(!('reviewer' in created.body));
  assert.match(view.$('message').textContent, /尚未执行/);
  view.$('reviewLevel').value = 'standard'; view.$('reviewLevel').dispatch('change');
  assert.throws(() => view.ui.defaultsValue(), /复核模型选择模型/);
});

test('detached exploratory save retains bridge draft scope and disabled values', async () => {
  const view = await browserStudio(call => call.route === 'bridge/draft' ? jsonResponse(call.body.config) : undefined);
  view.ui.fillDefaults({...serverState.defaults, reviewLevel:'exploratory', reviewMode:'on_failure', maxRepairRounds:2});
  view.ui.cards.reviewer.fill({});
  view.$('saveDefaults').click(); await flush();
  const draft = view.sent.find(c => c.route === 'bridge/draft');
  assert.equal(draft.body.bridgeId, detachedBoot.bridgeId); assert.equal(draft.body.config.reviewLevel, 'exploratory');
  assert.equal(draft.body.config.reviewMode, 'on_failure'); assert.equal(draft.body.config.maxRepairRounds, 2);
  assert.ok(!('reviewer' in draft.body.config)); assert.equal(view.$('reviewLevel').value, 'exploratory');
  assert.equal(view.sent.filter(c => ['save','job','bridge/submit'].includes(c.route)).length, 0);
});

test('textual exploration report distinguishes intentional skip, assertion block and reviewer errors', async () => {
  const { ui, document } = await studio(serverState);
  for (const status of ['needs_validation','blocked']) {
    const card = document.createElement('div');
    ui.renderRunDetails(card, {status, endedAt:'2026-11-22T09:00:00Z', verdict:status === 'blocked' ? 'blocked_by_data' : 'exploratory_unreviewed', review:null, reviewSkipped:{reason:'exploratory',level:'exploratory'}, assertions:{status:status === 'blocked' ? 'not_applicable' : 'pass',exit_code:0,counts:{checks_run:status === 'blocked' ? 0 : 1}}});
    assert.match(card.textContent, /reviewer 已跳过.*跳过原因：exploratory/);
    assert.match(card.textContent, /运行时尚未验证/); assert.doesNotMatch(card.textContent, /复核没有交出可用结论/);
    assert.match(card.textContent, status === 'blocked' ? /探索受阻.*not_applicable.*实际执行 0 条/ : /探索完成·待试用.*实际执行 1 条/);
  }
});

test('page remains self-contained through bundle toString serialization', () => {
  const bundled = vm.runInNewContext(renderPageExpression(), {});
  const html = bundled({ token:'opaque', workspaceRoot:'C:/project' });
  new vm.Script(html.match(/<script>([\s\S]*)<\/script>/)[1]);
  for (const id of ['jobRows','detailBody','flowGraph','runtimeCode','projectRoot','task','allowedGlobs','verifyHint','protectedFiles','allowProtected','maxWorkers','maxPlanRetries','maxRepairRounds','rollbackOnFailure']) assert.match(html, new RegExp('id="' + id + '"'));
  assert.doesNotMatch(html, /demo\.|worldcode4|qwen3\.8|claude-opus-5-5/);
});
