import test from 'node:test';
import assert from 'node:assert/strict';
import { createServer } from 'node:http';
import { once } from 'node:events';
import { createRequire } from 'node:module';
import { pathToFileURL } from 'node:url';
import path from 'node:path';
import { WORKER_SCHEMA } from '../src/policy.js';

// Exercise the installed adapter, not a replica of its serializer. All requests
// stay on loopback and resolve a synthetic key; no user credentials are read.
test('native Anthropic replay preserves two thinking signatures and tool results; upstream failures stay explicit', { timeout: 20000 }, async t => {
  if (!process.env.DSH_APP_ROOT) return t.skip('Set DSH_APP_ROOT to verify the installed adapter');
  const installed = createRequire(path.join(process.env.DSH_APP_ROOT, 'package.json'));
  const { apply } = await import(pathToFileURL(installed.resolve('@deepseek-ai/dsh-llm-pi-ai')));
  const { createUserMessage } = await import(pathToFileURL(installed.resolve('@deepseek-ai/dsh-llm')));
  const provider = 'loopback-replay', model = 'claude-opus-5-5';
  const signatures = ['fixture-thinking-signature-one', 'fixture-thinking-signature-two'];
  const final = { status: 'completed', summary: 'local replay verified', changedFiles: ['src/a.js'] };
  const received = [], warnings = [];
  let scenario = 'replay';
  const server = createServer(async (req, res) => {
    try {
      let raw = ''; for await (const chunk of req) raw += chunk;
      const body = JSON.parse(raw); received.push(body);
      if (scenario === 'unavailable') {
        res.writeHead(503, { 'content-type': 'application/json', 'retry-after': '0' });
        res.end(JSON.stringify({ type: 'error', error: { type: 'api_error', message: 'No available accounts: no available accounts' } }));
        return;
      }
      res.writeHead(200, { 'content-type': 'text/event-stream', connection: 'close' });
      const event = (name, data) => res.write(`event: ${name}\ndata: ${JSON.stringify(data)}\n\n`);
      event('message_start', { type: 'message_start', message: { id: 'msg_fixture', type: 'message', role: 'assistant', model, content: [], stop_reason: null, stop_sequence: null, usage: { input_tokens: 8, output_tokens: 0 } } });
      if (scenario === 'no-message-stop') { res.end(); return; }
      if (scenario === 'no-stop-reason') {
        event('message_stop', { type: 'message_stop' }); res.end(); return;
      }
      const block = (index, content_block, delta) => {
        event('content_block_start', { type: 'content_block_start', index, content_block });
        if (delta) event('content_block_delta', { type: 'content_block_delta', index, delta });
        event('content_block_stop', { type: 'content_block_stop', index });
      };
      if (body.messages.length === 1) {
        block(0, { type: 'thinking', thinking: '', signature: signatures[0] }, { type: 'thinking_delta', thinking: 'Inspect the existing source.' });
        block(1, { type: 'text', text: '' }, { type: 'text_delta', text: 'Read the project.' });
        block(2, { type: 'tool_use', id: 'tooluse_fixture', name: 'glob', input: {} }, { type: 'input_json_delta', partial_json: JSON.stringify({ path: 'D:/fixture', pattern: '**/*.js' }) });
        block(3, { type: 'thinking', thinking: '', signature: signatures[1] }, { type: 'thinking_delta', thinking: 'Continue after the tool result.' });
      } else {
        block(0, { type: 'tool_use', id: 'tooluse_final', name: 'structured_output', input: {} }, { type: 'input_json_delta', partial_json: JSON.stringify(final) });
      }
      event('message_delta', { type: 'message_delta', delta: { stop_reason: 'tool_use', stop_sequence: null }, usage: { output_tokens: 20 } });
      event('message_stop', { type: 'message_stop' });
      res.end();
    } catch (error) { res.destroy(error); }
  });
  server.listen(0, '127.0.0.1'); await once(server, 'listening');
  const baseURL = `http://127.0.0.1:${server.address().port}`;
  let adapter;
  const host = {
    fiber: { entry: { options: { id: 'local-replay-test' } } }, inject() {}, on() {},
    logger: { warn(...args) { warnings.push(args); }, error() {} },
    get(key) { if (key === 'credentials') return { async resolve() { return { value: 'fixture-key-only' }; }, async readRecord() {}, async listRecords() { return []; } }; },
    llm: { registerConfigurableProviders() { return { replace() {} }; }, registerModelDiscovery() {}, registerAdapter(_routes, value) { adapter = value; return { replace() {} }; } },
  };
  try {
    apply(host, { providers: { get: () => ({ [provider]: { api: 'anthropic-messages', baseURL, apiKeyEnv: 'FIXTURE_KEY_ONLY', streamIdleTimeoutMs: 2000,
      models: [{ id: model, contextWindow: 65536, maxTokens: 2048, reasoningEfforts: { low: 'low', medium: 'medium', high: 'high' } }],
    } }) } });
    const user = createUserMessage({ source: { kind: 'user' }, content: [{ type: 'text', text: 'Inspect the local fixture and return structured output.' }] });
    const tools = [
      { name: 'glob', description: 'Read fixture files', parameters: { type: 'object', properties: { path: { type: 'string' }, pattern: { type: 'string' } }, required: ['path', 'pattern'] } },
      { name: 'structured_output', description: 'Return result', parameters: WORKER_SCHEMA },
    ];
    const stream = async messages => {
      const chunks = [];
      for await (const chunk of adapter.stream({ provider, model, reasoningEffort: 'high', messages, tools, signal: AbortSignal.timeout(5000) })) chunks.push(chunk);
      return chunks;
    };
    const first = await stream([user]);
    const content = first.filter(chunk => chunk.type === 'block-end').map(chunk => chunk.block);
    assert.deepEqual(content.map(block => block.type), ['reasoning', 'text', 'tool-call', 'reasoning']);
    const finish = first.find(chunk => chunk.type === 'finish');
    assert.ok(finish.replayState);
    const assistant = { id: 'assistant-fixture', role: 'assistant', content, source: { kind: 'model', provider, model, replayState: finish.replayState } };
    const tool = { id: 'tool-fixture', role: 'tool', source: { kind: 'tool', callId: 'tooluse_fixture' }, toolCallId: 'tooluse_fixture', content: [{ type: 'text', text: 'src/a.js' }], isError: false };
    const second = await stream([user, assistant, tool]);
    assert.equal(second.some(chunk => chunk.type === 'finish' && chunk.reason.kind === 'error'), false);
    const result = second.find(chunk => chunk.type === 'block-end' && chunk.block.name === 'structured_output');
    assert.deepEqual(JSON.parse(result.block.arguments), final);
    const wire = received[1].messages;
    const index = wire.findIndex(message => message.role === 'assistant');
    const replayed = wire[index].content;
    assert.deepEqual(replayed.map(block => block.type), ['thinking', 'text', 'tool_use', 'thinking']);
    assert.equal(replayed[0].signature, signatures[0]);
    assert.equal(replayed[3].signature, signatures[1]);
    const toolResult = wire[index + 1].content[0];
    assert.equal(wire[index + 1].role, 'user');
    assert.equal(toolResult.type, 'tool_result');
    assert.equal(toolResult.tool_use_id, replayed[2].id);
    assert.equal(toolResult.content, 'src/a.js');
    assert.equal(toolResult.is_error, false);
    assert.equal(warnings.length, 0);

    for (const [mode, code, message] of [
      ['unavailable', 'SERVER', /No available accounts/],
      ['no-stop-reason', 'TRANSPORT', /without a stop reason/],
      ['no-message-stop', 'TRANSPORT', /before message_stop/],
    ]) {
      scenario = mode;
      const chunks = await stream([user]);
      const failure = chunks.find(chunk => chunk.type === 'finish' && chunk.reason.kind === 'error')?.reason.failure;
      assert.ok(failure, JSON.stringify(chunks));
      assert.equal(failure.code, code);
      assert.match(failure.message, message);
    }
  } finally {
    server.closeAllConnections();
    await new Promise(resolve => server.close(resolve));
  }
});
