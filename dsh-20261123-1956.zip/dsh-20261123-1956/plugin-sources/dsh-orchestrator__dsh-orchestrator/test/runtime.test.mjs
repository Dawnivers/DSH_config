import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, mkdirSync, writeFileSync, rmSync } from 'node:fs';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { createRuntimeTracker, runtimeIdentity, captureModule } from '../src/runtime.js';
import { compatibility } from '../src/runner.js';
import { runnerFixture, jobConfig } from './harness.mjs';

function setup() {
 const base=path.resolve('test-artifacts');mkdirSync(base,{recursive:true});
 const root=mkdtempSync(path.join(base,'runtime-'));
 const tracker=createRuntimeTracker(root);
 const file=path.join(root,'src','runner.js');mkdirSync(path.dirname(file),{recursive:true});
 writeFileSync(file,'export const generation = 1;');
 return {root,file,url:pathToFileURL(file),tracker};
}

test('loaded hash stays old after disk edit and identifies exactly the stale module',()=>{
 const f=setup();
 f.tracker.capture(f.url,{reviewRetry:true});
 const loaded=f.tracker.identity();assert.equal(loaded.sourceMatches,true);
 assert.equal(loaded.features.reviewRetry,true);
 writeFileSync(f.file,'export const generation = 2;');
 const current=f.tracker.identity();
 assert.equal(current.buildId,loaded.buildId);
 assert.notEqual(current.diskBuildId,current.buildId);
 assert.equal(current.sourceMatches,false);
 assert.deepEqual(current.staleModules,['src/runner.js']);
 assert.equal(current.modules[0].loadedHash,loaded.modules[0].loadedHash);
});

test('re-evaluating a module updates loaded identity, while missing files never count as current',()=>{
 const f=setup();f.tracker.capture(f.url);const before=f.tracker.identity();
 writeFileSync(f.file,'export const generation = 3;');f.tracker.capture(f.url);
 const updated=f.tracker.identity();assert.equal(updated.sourceMatches,true);assert.notEqual(updated.buildId,before.buildId);
 // Exact known fixture path created by setup, not a user project.
 assert.ok(f.file.startsWith(f.root+path.sep));rmSync(f.file);
 const missing=f.tracker.identity();assert.equal(missing.sourceMatches,false);assert.equal(missing.modules[0].diskHash,null);
});

test('identity ordering is stable and contains no file contents',()=>{
 const f=setup();const other=path.join(f.root,'other.js');writeFileSync(other,'const secretMarker = 123;');
 const a=createRuntimeTracker(f.root),b=createRuntimeTracker(f.root);
 a.capture(f.url);a.capture(pathToFileURL(other));b.capture(pathToFileURL(other));b.capture(f.url);
 assert.equal(a.identity().buildId,b.identity().buildId);
 assert.ok(!JSON.stringify(a.identity()).includes('secretMarker'));
});

test('ESM cached dependency is detected even when only its entry is cache-busted',async()=>{
 const f=setup();
 const runtimeUrl=pathToFileURL(path.resolve('src/runtime.js')).href;
 const registry=path.join(f.root,'registry.mjs');
 writeFileSync(registry,`import {createRuntimeTracker} from ${JSON.stringify(runtimeUrl)}; export const tracker=createRuntimeTracker(${JSON.stringify(f.root)});`);
 const dep=path.join(f.root,'dep.mjs');
 writeFileSync(dep,"import {tracker} from './registry.mjs'; tracker.capture(import.meta.url); export const generation=1;");
 const entry=path.join(f.root,'entry.mjs');writeFileSync(entry,"export {generation} from './dep.mjs'; export {tracker} from './registry.mjs';");
 const first=await import(pathToFileURL(entry).href+'?first');assert.equal(first.generation,1);
 writeFileSync(dep,"import {tracker} from './registry.mjs'; tracker.capture(import.meta.url); export const generation=2;");
 const second=await import(pathToFileURL(entry).href+'?second');
 assert.equal(second.generation,1,'normal ESM dependency import is still cached');
 assert.equal(second.tracker.identity().sourceMatches,false);
 assert.deepEqual(second.tracker.identity().staleModules,['dep.mjs']);
});

test('settings compatibility exposes runtime identity without starting model sessions',async()=>{
 const f=runnerFixture();
 try {
  const identity=compatibility(f.ctx).runtime;
  assert.equal(identity.sourceMatches,true);
  assert.equal(identity.features.reviewRetry,true);
  assert.equal(identity.features.runtimeVerification,true);
  assert.equal(identity.pid,process.pid);
  assert.ok(identity.modules.some(m=>m.name==='src/runner.js'));
  assert.equal(f.calls.length,0);
 } finally {await f.bindings.dispose();}
});

test('stale loaded code blocks before any model request and leaves the task queued',async()=>{
 const f=runnerFixture();const fixture=setup();
 captureModule(fixture.url);
 try {
  const j=f.store.create(jobConfig(f.root));
  writeFileSync(fixture.file,'export const generation = 999;');
  assert.throws(()=>f.runner.run(j.id,f.parent,new AbortController().signal),/已加载代码与磁盘不一致/);
  assert.equal(f.calls.length,0);
  assert.equal(f.store.status(j.id).status,'queued');
 } finally {
  writeFileSync(fixture.file,'export const generation = 1;');captureModule(fixture.url);
  await f.bindings.dispose();
 }
});

test('each real runner report carries the runtime identity even for plan-only execution',async()=>{
 const f=runnerFixture();
 try {
  const j=f.store.create(jobConfig(f.root));
  const r=await f.runner.run(j.id,f.parent,new AbortController().signal,undefined,{planOnly:true}).result;
  assert.equal(r.runtime.buildId,runtimeIdentity().buildId);
  assert.equal(r.runtime.sourceMatches,true);
  assert.equal(r.runtime.features.reviewRetry,true);
  assert.equal(r.status,'planned');
 } finally {await f.bindings.dispose();}
});
