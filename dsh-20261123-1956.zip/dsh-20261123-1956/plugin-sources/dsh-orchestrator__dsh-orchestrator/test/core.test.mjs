import test from 'node:test';
import assert from 'node:assert/strict';
import path from 'node:path';
import { mkdirSync, symlinkSync, readFileSync } from 'node:fs';
import { relativeFile, globMatch, safeTarget, validatePlan } from '../src/policy.js';
import { fixture, jobConfig, plan, runnerFixture } from './harness.mjs';

for (const name of ['../x', '/abs/x', 'C:\\temp\\x', 'a//b', 'a/./b', 'a/../b', 'a/b.', 'a/b ', 'a/con.txt', '.git/config', 'node_modules/a.js', 'a:stream', 'src/*.js']) {
  test(`reject unsafe filename ${name}`, () => assert.throws(() => relativeFile(name)));
}
test('glob directory boundary and nested matching', () => {
  assert.equal(globMatch('src/a.js', 'src/**'), true);
  assert.equal(globMatch('src2/a.js', 'src/**'), false);
  assert.equal(globMatch('src/a.js', 'src/*.js'), true);
  assert.equal(globMatch('src/nested/a.js', 'src/*.js'), false);
  assert.equal(globMatch('src/a.js', '**/*.js'), true);
  assert.equal(globMatch('a.js', '**/*.js'), true);
});
test('symbolic links and junctions are rejected', () => {
  const f = fixture();
  mkdirSync(path.join(f.dir, 'outside'));
  symlinkSync(path.join(f.dir, 'outside'), path.join(f.root, 'linked'), process.platform === 'win32' ? 'junction' : 'dir');
  assert.throws(() => safeTarget(f.root, 'linked/payload.js'));
});
test('disjoint files and exact contract signatures are validated', () => {
  const f = fixture(), job = jobConfig(f.root);
  assert.equal(validatePlan(plan(), job).tasks.length, 2);
  const duplicate = plan(); duplicate.tasks[1].files = ['src/a.js'];
  assert.throws(() => validatePlan(duplicate, job), /重复分配/);
  const wrongFrom = plan(); wrongFrom.tasks[1].consumes[0].from = 'missing';
  assert.throws(() => validatePlan(wrongFrom, job), /签名不匹配/);
  const wrongSignature = plan(); wrongSignature.tasks[1].consumes[0].signature = 'string';
  assert.throws(() => validatePlan(wrongSignature, job), /签名不匹配/);
  assert.throws(() => validatePlan(plan(), jobConfig(f.root, { protectedFiles: ['src/a.js'] })), /受保护/);
});
test('full run keeps model efforts separate, binds before tools, snapshots original bytes', async () => {
  const f = runnerFixture({ beforeResult({ role, task, fire }) {
    if (role === 'planner') assert.match(fire('write', { file_path: path.join(f.root, 'src/a.js') }), /只允许读取/);
    if (role === 'worker') {
      assert.match(fire('pwsh', { command: 'forbidden' }), /禁止调用/);
      assert.match(fire('write', { file_path: path.join(f.root, 'src', (task === 'a' ? 'b' : 'a') + '.js') }), /不属于/);
      assert.match(fire('glob', { file_path: path.join(f.root, 'src/a.js'), path: f.dir }), /越出/);
      assert.match(fire('grep', { file_path: path.join(f.root, 'src/a.js'), path: f.dir }), /越出/);
      assert.match(fire('read', { file_path: '../outside' }), /绝对路径/);
    }
  } });
  const job = f.store.create(jobConfig(f.root));
  const report = await f.runner.run(job.id, f.parent, new AbortController().signal).result;
  assert.equal(report.status, 'needs_validation', report.error);
  assert.equal(report.children.length, 5);
  assert.ok(report.children.every(c => c.boundBeforeRequest));
  assert.deepEqual(f.calls.map(c => c.agentOptions.reasoningEffort), ['max', 'max', 'low', 'low', 'max']);
  assert.deepEqual(f.calls.map(c => c.agentOptions.provider), ['strong', 'strong', 'cheap', 'cheap', 'strong']);
  assert.equal(f.disposed.length, 5);
  assert.equal(readFileSync(path.join(report.snapshot.directory, '0.bin'), 'utf8'), 'export const a = 1;\n');
  assert.equal(report.files.filter(file => file.changed).length, 2);
  assert.equal(f.store.status(job.id).status, 'needs_validation');
  await f.bindings.dispose();
});
test('planning rejection retries with the strong route and performs no early worker write', async () => {
  const f = runnerFixture({ getPlan(attempt) { const p = plan(); if (attempt === 1) p.tasks[1].files = ['src/a.js']; return p; } });
  const job = f.store.create(jobConfig(f.root));
  const report = await f.runner.run(job.id, f.parent, new AbortController().signal, undefined, { planOnly: true }).result;
  assert.equal(report.status, 'planned', report.error);
  assert.equal(report.planAttempts, 2);
  assert.equal(f.calls.length, 2);
  assert.ok(f.calls.every(call => call.agentOptions.reasoningEffort === 'max'));
  assert.equal(readFileSync(path.join(f.root, 'src/a.js'), 'utf8'), 'export const a = 1;\n');
  await f.bindings.dispose();
});
test('invalid worker effort rejects before any planner request', async () => {
  const f = runnerFixture();
  const job = f.store.create(jobConfig(f.root, { worker: { provider: 'cheap', model: 'worker', effort: 'invalid' } }));
  const report = await f.runner.run(job.id, f.parent, new AbortController().signal).result;
  assert.equal(report.status, 'failed');
  assert.match(report.error, /unsupported effort/);
  assert.equal(f.calls.length, 0);
  await f.bindings.dispose();
});
test('missing creation binding fails closed before first write', async () => {
  let firstDenial;
  const f = runnerFixture({ skipCreated: true, beforeResult({ fire }) { firstDenial = fire('write', { file_path: path.join(f.root, 'src/a.js') }); } });
  const job = f.store.create(jobConfig(f.root, { maxPlanRetries: 0 }));
  const report = await f.runner.run(job.id, f.parent, new AbortController().signal).result;
  assert.equal(report.status, 'failed');
  assert.match(firstDenial, /未在创建阶段绑定/);
  assert.match(report.error, /创建阶段绑定/);
  await f.bindings.dispose();
});
test('overlapping project locks reject concurrent runs and release after completion', async () => {
  const f = runnerFixture({ delay: 20 });
  const one = f.store.create(jobConfig(f.root));
  const two = f.store.create(jobConfig(f.root));
  const signal = new AbortController().signal;
  const run = f.runner.run(one.id, f.parent, signal, undefined, { planOnly: true });
  assert.throws(() => f.runner.run(two.id, f.parent, signal), /正在运行/);
  assert.equal((await run.result).status, 'planned');
  assert.equal((await f.runner.run(two.id, f.parent, signal, undefined, { planOnly: true }).result).status, 'planned');
  assert.throws(() => f.runner.run(two.id, f.parent, signal), /已经启动/);
  await f.bindings.dispose();
});
test('worker failure is failure, never a successful null result', async () => {
  const f = runnerFixture({ failWorker: 'a' });
  const job = f.store.create(jobConfig(f.root));
  const report = await f.runner.run(job.id, f.parent, new AbortController().signal).result;
  assert.equal(report.status, 'failed');
  assert.match(report.error, /运行未完成/);
  assert.equal(report.children.some(child => child.role === 'reviewer'), false);
  await f.bindings.dispose();
});
test('other agents are unaffected and bound permissions remain closed after disposal', async () => {
  const f = runnerFixture();
  assert.equal(f.ctx.check({ agent: { session: { id: 'unrelated' } }, name: 'pwsh', arguments: {} }), undefined);
  const job = f.store.create(jobConfig(f.root));
  const report = await f.runner.run(job.id, f.parent, new AbortController().signal, undefined, { planOnly: true }).result;
  const agent = f.ctx.children.get(report.children[0].childId).agent;
  assert.match(f.ctx.check({ agent, name: 'read', arguments: { file_path: path.join(f.root, 'src/a.js') } }), /权限已关闭/);
  await f.bindings.dispose();
});
