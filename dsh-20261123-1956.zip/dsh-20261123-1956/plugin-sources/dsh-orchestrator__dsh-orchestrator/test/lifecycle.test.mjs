import test from 'node:test';
import assert from 'node:assert/strict';
import { jobConfig, runnerFixture } from './harness.mjs';

test('logging failure never leaks a project lock', async () => {
  const f = runnerFixture();
  const job = f.store.create(jobConfig(f.root));
  const original = f.store.report;
  f.store.report = () => { throw new Error('simulated disk failure'); };
  const report = await f.runner.run(job.id, f.parent, new AbortController().signal).result;
  assert.equal(report.status, 'failed');
  assert.match(report.recordError, /disk failure/);
  f.store.report = original;
  const next = f.store.create(jobConfig(f.root));
  assert.equal((await f.runner.run(next.id, f.parent, new AbortController().signal, undefined, { planOnly: true }).result).status, 'planned');
  await f.bindings.dispose();
});
test('status write failure still releases locks and active runs', async () => {
  const f = runnerFixture();
  const job = f.store.create(jobConfig(f.root));
  const original = f.store.setStatus;
  f.store.setStatus = () => { throw new Error('status disk failed'); };
  await assert.rejects(f.runner.run(job.id, f.parent, new AbortController().signal).result, /status disk failed/);
  f.store.setStatus = original;
  const next = f.store.create(jobConfig(f.root));
  assert.equal((await f.runner.run(next.id, f.parent, new AbortController().signal, undefined, { planOnly: true }).result).status, 'planned');
  await f.bindings.dispose();
});
test('plugin teardown aborts and drains pending child creation', async () => {
  const f = runnerFixture();
  let release;
  let entered;
  const waiting = new Promise(resolve => { entered = resolve; });
  const original = f.ctx.subagents.start;
  f.ctx.subagents.start = async (...args) => {
    entered();
    await new Promise(resolve => { release = resolve; });
    return original(...args);
  };
  const job = f.store.create(jobConfig(f.root, { maxPlanRetries: 0 }));
  const run = f.runner.run(job.id, f.parent, new AbortController().signal);
  await waiting;
  let finished = false;
  const disposal = f.runner.dispose().then(() => { finished = true; });
  await Promise.resolve();
  assert.equal(finished, false);
  release();
  await disposal;
  assert.equal((await run.result).status, 'cancelled');
  await f.bindings.dispose();
  assert.throws(() => f.runner.run(job.id, f.parent, new AbortController().signal), /正在停止/);
});
