import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import { buildClient, renderPageExpression } from '../src/bundle.js';

// The browser does not import src/flow.js: the bundle serializes page() and binds the
// variables it interpolates by name. Executing that exact expression is the only way to
// catch a missing binding (0.2.9 shipped without flowStyles and the panel rendered blank).
test('the serialized page runs with only the bindings the bundle provides', () => {
  const page = vm.runInNewContext(renderPageExpression(), {});
  const html = page({ embedded: true, sessionId: 'session-a', bridgeId: 'b', token: 't' });
  assert.match(html, /id="flowPanel"/);
  assert.match(html, /id="flowGraph"/);
  assert.match(html, /flow-connectors/);
  assert.match(html, /createCard\('feasibility'/);
  assert.match(html, /monitorTaskId/);
});

test('the generated bundle is loadable and wires the client factory to that page', () => {
  const source = buildClient();
  let loaded;
  const window = { __ModuleLoader__: { load: spec => { loaded = spec; } } };
  vm.runInNewContext(source, { window });
  assert.equal(loaded.id, 'dsh-orchestrator');
  assert.equal(typeof loaded.factory, 'function');

  const React = { createElement: () => null, useState: v => [v, () => {}], useEffect: () => {}, useRef: v => ({ current: v }), Fragment: 'fragment' };
  const module = loaded.factory(name => { assert.equal(name, 'react'); return React; });
  assert.equal(typeof module.SessionAction, 'function');
  assert.equal(typeof module.SettingsPage, 'function');
  assert.equal(typeof module.createSessionBridge, 'function');
  assert.equal(typeof module.discoverRun, 'function');
});
