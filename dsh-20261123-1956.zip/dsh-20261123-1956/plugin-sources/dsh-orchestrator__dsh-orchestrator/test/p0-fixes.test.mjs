// 本次两项 P0 改动的回归测试（走真实 runner + bindings 路径）：
// 1) planner prompt 必须讲清 consumes.from 只能是另一任务的 id
// 2) 只读角色（planner/feasibility/reviewer）有工具调用预算，worker 没有
import test from 'node:test';
import assert from 'node:assert/strict';
import path from 'node:path';
import { plannerPrompt } from '../src/prompts.js';
import { jobConfig, runnerFixture } from './harness.mjs';

const BUDGET = 40;
const capMessage = new RegExp(`工具调用超过上限 ${BUDGET} 次`);

test('planner prompt states consumes.from must be another task id', () => {
  const p = plannerPrompt(jobConfig(process.cwd()));
  assert.match(p, /consumes\[\]\.from 必须填另一任务的 id/);
  assert.match(p, /不要用模块名、文件名或外部依赖名充当 from/);
  assert.match(p, /也不要在 consumes 里申报项目现有或外部已有的函数/);
  assert.match(p, /provides 与 consumes 都应输出空数组/);
  // 原有约束必须保留
  assert.match(p, /跨任务签名逐字一致/);
  assert.match(p, /文件互斥/);
  assert.match(p, /区分静态检查和主会话待运行验证/);
});

test('planner allows exactly the budget then denies the next call', async () => {
  const seen = { allowed: 0, denied: '' };
  let root;
  const f = runnerFixture({
    beforeResult({ role, fire }) {
      if (role !== 'planner') return;
      const file = path.join(root, 'src/a.js');
      for (let i = 0; i < BUDGET; i++) if (!fire('read', { file_path: file })) seen.allowed++;
      seen.denied = fire('read', { file_path: file }) || '';
    },
  });
  root = f.root;
  const job = f.store.create(jobConfig(f.root));
  const report = await f.runner.run(job.id, f.parent, new AbortController().signal, undefined, { planOnly: true }).result;
  assert.equal(report.status, 'planned', report.error);
  assert.equal(seen.allowed, BUDGET, `前 ${BUDGET} 次应放行`);
  assert.match(seen.denied, capMessage, `第 ${BUDGET + 1} 次应被拒`);
  await f.bindings.dispose();
});

test('read-only role exceeding budget fails closed before any write', async () => {
  let root;
  const f = runnerFixture({
    beforeResult({ role, fire }) {
      if (role !== 'feasibility') return;
      const file = path.join(root, 'src/a.js');
      for (let i = 0; i < BUDGET + 5; i++) fire('read', { file_path: file });
    },
  });
  root = f.root;
  const job = f.store.create(jobConfig(f.root));
  const report = await f.runner.run(job.id, f.parent, new AbortController().signal).result;
  // 超预算必须整体失败关闭，且没有产生任何快照外的写入
  assert.equal(report.status, 'failed', '超预算应失败关闭');
  assert.match(report.error || '', capMessage);
  assert.ok(!report.files, '失败关闭时不应有文件 diff 结果');
  await f.bindings.dispose();
});

test('worker reads are not capped by the read-only budget', async () => {
  let allowedReads = 0;
  let root;
  const f = runnerFixture({
    beforeResult({ role, fire }) {
      if (role !== 'worker') return;
      const file = path.join(root, 'src/a.js');
      for (let i = 0; i < 60; i++) if (!fire('read', { file_path: file })) allowedReads++;
    },
  });
  root = f.root;
  const job = f.store.create(jobConfig(f.root));
  const report = await f.runner.run(job.id, f.parent, new AbortController().signal).result;
  assert.equal(report.status, 'needs_validation', report.error);
  assert.equal(allowedReads, 120, '两个 worker 任务各 60 次读取都应放行');
  await f.bindings.dispose();
});
