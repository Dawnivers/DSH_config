import test from 'node:test';
import assert from 'node:assert/strict';
import { flowModel, flowStyles } from '../src/flow.js';
import { page } from '../src/ui.js';

const job = {
  id: 'job-1', task: 'make the koi swim', status: 'running',
  planner: { provider: 'p', model: 'planner-m' }, worker: { provider: 'w', model: 'worker-m' },
  feasibility: { provider: 'f', model: 'feas-m' }, reviewer: { provider: 'r', model: 'review-m' },
};
const task = (id, files, consumes = []) => ({ id, files, consumes, provides: [], goal: id, constraints: [], suggestedSteps: [] });

function runningReport(overrides = {}) {
  return {
    runId: 'run-1', jobId: 'job-1', status: 'running', startedAt: '2026-11-14T10:00:00.000Z', events: [], children: [],
    plan: { tasks: [task('a', ['src/a.js'])] },
    ...overrides,
  };
}

test('a running report shows pending workers and no invented files', () => {
  const model = flowModel(job, runningReport({ flowPhases: [{ id: 'initial', plan: { tasks: [task('a', ['src/a.js'])] }, tasks: [{ taskId: 'a', status: 'pending', assignedFiles: ['src/a.js'] }] }] }));
  const worker = model.nodes.find(node => node.role === 'worker');
  assert.equal(worker.status, 'pending');
  assert.deepEqual(worker.assignedFiles, ['src/a.js']);
  assert.equal(worker.actualChangedFiles, undefined);
  assert.equal(model.terminal, false);
  assert.ok(model.nodes.some(node => node.id === 'result' && node.status === 'pending'));
});

test('a completed worker separates planned files from verified changes', () => {
  const model = flowModel({ ...job, status: 'needs_validation' }, runningReport({
    status: 'needs_validation', endedAt: '2026-11-14T10:05:00.000Z',
    children: [{ role: 'planner', status: 'completed' }, { role: 'feasibility', status: 'completed' }, { role: 'worker', taskId: 'a', status: 'completed', output: { status: 'completed', changedFiles: ['src/a.js'] } }, { role: 'reviewer', status: 'completed' }],
    flowPhases: [{ id: 'initial', plan: { tasks: [task('a', ['src/a.js'])] }, tasks: [{ taskId: 'a', status: 'completed', assignedFiles: ['src/a.js'], actualChangedFiles: ['src/a.js'] }] }],
    review: { assessment: 'verified_statically', checks: [] },
  }));
  const worker = model.nodes.find(node => node.role === 'worker');
  assert.equal(worker.status, 'completed');
  assert.deepEqual(worker.actualChangedFiles, ['src/a.js']);
  assert.equal(model.terminal, true);
  assert.equal(model.nodes.at(-1).status, 'completed');
});

test('a failed worker lights its own card and the downstream path, not the healthy branch', () => {
  const tasks = [task('a', ['src/a.js']), task('b', ['src/b.js']), task('c', ['src/c.js'], [{ name: 'a', from: 'a', signature: 'x' }])];
  const model = flowModel({ ...job, status: 'failed' }, runningReport({
    status: 'failed', endedAt: '2026-11-14T10:06:00.000Z',
    children: [{ role: 'planner', status: 'completed' }, { role: 'feasibility', status: 'completed' }, { role: 'worker', taskId: 'a', status: 'failed', error: 'boom' }, { role: 'worker', taskId: 'b', status: 'completed' }],
    plan: { tasks },
    flowPhases: [{ id: 'initial', plan: { tasks }, tasks: [
      { taskId: 'a', status: 'failed', error: 'boom', assignedFiles: ['src/a.js'] },
      { taskId: 'b', status: 'completed', assignedFiles: ['src/b.js'], actualChangedFiles: ['src/b.js'] },
      { taskId: 'c', status: 'skipped', reason: '上游未完成：a', assignedFiles: ['src/c.js'] },
    ] }],
    error: '任务失败：a',
  }));
  const byTask = id => model.nodes.find(node => node.taskId === id && node.role === 'worker');
  assert.equal(byTask('a').status, 'failed');
  assert.equal(byTask('b').status, 'completed');
  assert.equal(byTask('c').status, 'skipped');
  assert.equal(byTask('c').affected, true);
  assert.equal(byTask('b').affected, false);
  const edge = (from, to) => model.edges.find(item => item.from === from && item.to === to);
  assert.equal(edge(byTask('a').id, byTask('c').id).status, 'failed');
  assert.equal(edge(byTask('a').id, byTask('b').id), undefined, 'independent branches stay unlinked');
  assert.equal(model.nodes.at(-1).status, 'failed');
});

test('a degraded or blocked check is visible instead of pretending to pass', () => {
  const degraded = flowModel(job, runningReport({ feasibilityDegraded: { reason: 'bad frame' }, children: [{ role: 'planner', status: 'completed' }, { role: 'feasibility', status: 'failed', error: 'bad frame' }] }));
  const check = degraded.nodes.find(node => node.role === 'feasibility');
  assert.equal(check.status, 'degraded');
  assert.equal(check.error, 'bad frame');

  const blocked = flowModel({ ...job, status: 'blocked' }, runningReport({ status: 'blocked', endedAt: '2026-11-14T10:02:00.000Z', feasibility: { status: 'needs_clarification', tasks: [] }, nextAction: { questions: ['which file?'] } }));
  assert.equal(blocked.nodes.find(node => node.role === 'feasibility').status, 'blocked');
  assert.equal(blocked.nodes.at(-1).status, 'blocked');
});

test('a repair round renders as a second column with its own workers', () => {
  const first = [task('a', ['src/a.js'])];
  const repair = [task('fix', ['src/a.js'])];
  const model = flowModel({ ...job, status: 'needs_validation' }, runningReport({
    status: 'needs_validation', endedAt: '2026-11-14T10:20:00.000Z',
    children: [
      { role: 'planner', status: 'completed' }, { role: 'feasibility', status: 'completed' },
      { role: 'worker', taskId: 'a', status: 'completed' }, { role: 'reviewer', status: 'completed' },
      { role: 'planner', phase: 'repair-1', status: 'completed' }, { role: 'worker', phase: 'repair-1', taskId: 'fix', status: 'completed' },
      { role: 'reviewer', phase: 'repair-1', status: 'completed' },
    ],
    plan: { tasks: first },
    flowPhases: [{ id: 'initial', plan: { tasks: first }, tasks: [{ taskId: 'a', status: 'completed', actualChangedFiles: ['src/a.js'] }] }],
    repair: { round: 1, status: 'completed', plan: { tasks: repair }, workers: [{ taskId: 'fix', status: 'completed' }], files: [], review: { assessment: 'verified_statically' } },
    review: { assessment: 'verified_statically', checks: [] },
  }));
  assert.ok(model.nodes.some(node => node.taskId === 'fix' && node.phase === 'repair'), 'repair worker has its own card');
  assert.ok(model.nodes.filter(node => node.role === 'planner').length >= 2);
  assert.ok(model.nodes.filter(node => node.role === 'reviewer').length >= 2);
});

test('style contract: failure glow and dashed affected path exist', () => {
  assert.match(flowStyles, /\.flow-card\[data-status=failed\]/);
  assert.match(flowStyles, /flow-red:#e44763/);
  assert.match(flowStyles, /stroke-dasharray/);
  assert.match(flowStyles, /prefers-reduced-motion/);
});

test('the settings page embeds a hidden flow panel with the real renderer', () => {
  const html = page();
  assert.match(html, /id="flowPanel"/);
  assert.match(html, /id="flowGraph"/);
  assert.match(html, /flow-connectors/);
  assert.match(html, /function createFlowView/);
  assert.match(html, /function flowModel/);
  assert.match(html, /boot\.monitorTaskId/);
});

test('review errors are terminal exceptions, never successful results', () => {
  const reviewError = { message: 'review transport disconnected' };
  const model = flowModel({ ...job, status: 'review_error' }, runningReport({
    status: 'review_error', endedAt: '2026-11-14T10:05:00.000Z', reviewError,
    error: 'generic error must not hide review error',
    children: [
      { role: 'worker', taskId: 'a', status: 'completed' },
      { role: 'reviewer', status: 'failed', error: reviewError.message },
    ],
  }));
  const result = model.nodes.find(node => node.id === 'result');
  assert.equal(model.terminal, true);
  assert.equal(result.status, 'review_error');
  assert.equal(result.statusLabel, '复核异常');
  assert.deepEqual(result.error, reviewError);
  assert.equal(model.edges.find(edge => edge.to === 'result').status, 'failed');
  assert.equal(flowModel({ ...job, status: 'review_error' }, null).terminal, true);
  assert.equal(flowModel({ ...job, status: 'review_error' }, runningReport({ status: 'review_error' })).terminal, false);
  assert.match(flowStyles, /\.flow-card\[data-status=review_error\]/);
  const html = page();
  assert.match(html, /review_error:'复核异常'/);
  assert.match(html, /retrying:'重试中'/);
  assert.match(html, /if \(run\.reviewError\)/);
});

test('reviewer retries select the latest attempt independently in each phase', () => {
  const initialAttempts = [
    { role: 'reviewer', phase: 'initial', status: 'failed', error: 'first failure' },
    { role: 'reviewer', phase: 'initial', status: 'completed', childId: 'initial-latest', output: { assessment: 'issues_found' } },
  ];
  const repairAttempts = [
    { role: 'reviewer', phase: 'repair-1', status: 'failed', error: 'repair first failure' },
    { role: 'reviewer', phase: 'repair-1', status: 'completed', childId: 'repair-latest', output: { assessment: 'verified_statically' } },
  ];
  const report = runningReport({
    status: 'needs_validation', endedAt: '2026-11-14T10:20:00.000Z',
    children: [
      { role: 'planner', phase: 'initial', status: 'completed' }, ...initialAttempts,
      { role: 'planner', phase: 'repair-1', status: 'completed' }, ...repairAttempts,
    ],
    initialReview: { assessment: 'issues_found' },
    repair: { status: 'completed', plan: { tasks: [] }, review: { assessment: 'verified_statically' } },
  });
  const model = flowModel(job, report);
  const reviewers = model.nodes.filter(node => node.role === 'reviewer');
  assert.deepEqual(reviewers.map(node => node.childId), ['initial-latest', 'repair-latest']);
  assert.deepEqual(reviewers.map(node => node.status), ['issues', 'completed']);
  assert.deepEqual(reviewers[0].reviewerAttempts, initialAttempts);
  assert.deepEqual(reviewers[1].reviewerAttempts, repairAttempts);
  assert.equal(reviewers[0].error, undefined);
  assert.equal(reviewers[1].error, undefined);
  assert.equal(report.children.length, 6, 'projection preserves original child history');
});

test('a running reviewer retry is not overwritten by an earlier assessment', () => {
  const model = flowModel(job, runningReport({
    review: { assessment: 'issues_found' },
    children: [
      { role: 'reviewer', status: 'completed', output: { assessment: 'issues_found' } },
      { role: 'reviewer', status: 'running', childId: 'latest' },
    ],
  }));
  const reviewer = model.nodes.find(node => node.role === 'reviewer');
  assert.equal(reviewer.childId, 'latest');
  assert.equal(reviewer.status, 'running');
  assert.equal(model.terminal, false);
});

// 真机踩出来的：修复轮运行中 job.status 会短暂停在上一轮复核写下的 review_failed，
// 拿它判终态会把「还在跑」渲染成「已失败」，而前端 keepPolling=!terminal 会直接停掉轮询。
test('a repair round still running is not terminal even when job.status says review_failed', () => {
  const inflight = flowModel(
    { ...job, status: 'review_failed' },
    runningReport({ status: 'running', children: [{ role: 'planner', phase: 'repair-1', status: 'starting' }] }),
  );
  assert.equal(inflight.terminal, false, '运行中的报告没有 endedAt，就不能算结束');
  assert.ok(inflight.nodes.some(node => node.id === 'result' && node.status === 'pending'));

  // 同一份 job.status，报告一旦写上 endedAt 才算结束。
  const settled = flowModel(
    { ...job, status: 'review_failed' },
    runningReport({ status: 'review_failed', endedAt: '2026-11-14T10:05:00.000Z', children: [{ role: 'planner', phase: 'repair-1', status: 'completed' }] }),
  );
  assert.equal(settled.terminal, true);

  // 完全没有报告时才退回 job.status 兜底（runner 崩溃没留报告的情况）。
  assert.equal(flowModel({ ...job, status: 'review_failed' }, null).terminal, true);
  assert.equal(flowModel({ ...job, status: 'running' }, null).terminal, false);
});

const endedAt = '2026-11-22T09:00:00.000Z';
const passingAssertions = {selection:['data.check'], status:'pass', exit_code:0, counts:{checks_run:1}};

test('exploration explicitly skips reviewer and ends awaiting trial, never reviewed or runtime verified', () => {
  const report = runningReport({status:'needs_validation', endedAt, verdict:'exploratory_unreviewed', review:null, reviewSkipped:{reason:'exploratory',level:'exploratory'}, assertions:passingAssertions});
  const model = flowModel({...job, reviewLevel:'exploratory', assertions:['data.check']}, report);
  const reviewer = model.nodes.find(n => n.role === 'reviewer');
  assert.equal(reviewer.status, 'skipped'); assert.equal(reviewer.reason, 'exploratory');
  assert.deepEqual(reviewer.output.reviewSkipped, report.reviewSkipped); assert.match(reviewer.statusLabel, /exploratory/);
  assert.equal(model.nodes.find(n => n.role === 'assertions').status, 'completed');
  const result = model.nodes.at(-1);
  assert.equal(model.terminal, true); assert.equal(model.status, 'needs_validation');
  assert.equal(result.status, 'needs_validation'); assert.equal(result.statusLabel, '探索完成·待试用');
  assert.equal(result.runtimeVerified, false); assert.equal(result.reportVerdict, 'exploratory_unreviewed');
  assert.equal(report.review, null); assert.equal(model.nodes.some(n => n.id === 'repair-planner'), false);
});

test('an ended exploratory verdict infers an explicit skip but active children keep terminal guard sacred', () => {
  const ended = runningReport({status:'needs_validation', endedAt, verdict:'exploratory_unreviewed'});
  const inferred = flowModel(job, ended);
  assert.equal(inferred.nodes.find(n => n.role === 'reviewer').reason, 'exploratory');
  assert.equal(inferred.nodes.at(-1).statusLabel, '探索完成·待试用');
  const working = flowModel({...job, reviewLevel:'exploratory', status:'needs_validation'}, {...ended, children:[{role:'worker',taskId:'a',status:'running'}]});
  assert.equal(working.terminal, false); assert.equal(working.nodes.at(-1).status, 'pending');
  assert.equal(working.nodes.find(n => n.role === 'reviewer').status, 'pending', 'do not infer an ended skip while children remain active');
});

test('all selected assertion nonpass states block exploration without pretending reviewer approval', () => {
  for (const assertions of [
    {status:'fail',exit_code:1,counts:{checks_run:1},reason:'bad geometry'},
    {status:'warn',exit_code:2,counts:{checks_run:1}},
    {status:'pass_with_warnings',exit_code:2,counts:{checks_run:1}},
    {status:'pass_with_warnings',exit_code:0,counts:{checks_run:1}},
    {status:'not_run',reason:'selected assertions not executed'},
    {status:'not_applicable',exit_code:0,counts:{checks_run:0}},
    {status:'pass',exit_code:0,counts:{checks_run:0}},
    {status:'pass',exit_code:2,counts:{checks_run:1}},
    {status:'error',reason:'execution unavailable'},
    undefined,
  ]) {
    const model = flowModel({...job, reviewLevel:'exploratory', assertions:['data.check']}, runningReport({status:'blocked', endedAt, verdict:'blocked_by_data', review:null, reviewSkipped:{reason:'exploratory',level:'exploratory'}, assertions}));
    assert.equal(model.status, 'blocked'); assert.equal(model.nodes.at(-1).status, 'blocked');
    assert.notEqual(model.nodes.find(n => n.role === 'assertions').status, 'completed');
    assert.equal(model.nodes.find(n => n.role === 'reviewer').status, 'skipped');
    assert.equal(model.nodes.find(n => n.role === 'reviewer').reason, 'exploratory');
    assert.ok(!model.nodes.some(n => n.artifactType === 'rollback'));
  }
  const staleSuccess = flowModel({...job, reviewLevel:'exploratory', assertions:['data.check']}, runningReport({status:'needs_validation', endedAt, verdict:'exploratory_unreviewed', assertions:{status:'not_applicable',exit_code:0,counts:{checks_run:0}}}));
  assert.equal(staleSuccess.nodes.at(-1).status, 'blocked', 'missing real execution may never greenwash exploratory selected assertions');
});

test('review skips retain their exact reason and strict never infers conditional bypass from passing assertions', () => {
  const skipped = flowModel(job, runningReport({status:'needs_validation', endedAt, reviewSkipped:{reason:'assertions_passed',level:'standard'}, assertions:passingAssertions}));
  assert.equal(skipped.nodes.find(n => n.role === 'reviewer').reason, 'assertions_passed');
  const strict = flowModel({...job, reviewLevel:'strict', reviewMode:'on_failure', assertions:['data.check']}, runningReport({assertions:passingAssertions}));
  assert.equal(strict.nodes.find(n => n.role === 'assertions').status, 'completed');
  assert.equal(strict.nodes.find(n => n.role === 'reviewer').status, 'pending');
  assert.equal(strict.nodes.find(n => n.role === 'reviewer').reason, undefined);
  const reviewed = flowModel({...job, reviewLevel:'strict', reviewMode:'on_failure'}, runningReport({status:'needs_validation', endedAt, children:[{role:'reviewer',status:'completed',output:{assessment:'verified_statically'}}],review:{assessment:'verified_statically'}}));
  assert.equal(reviewed.nodes.find(n => n.role === 'reviewer').status, 'completed');
  assert.notEqual(reviewed.nodes.at(-1).statusLabel, '探索完成·待试用');
});
