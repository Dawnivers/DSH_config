// 韧性回归：结构化输出缺失的只读补交、复核失败不销毁成果、报告契约（修复计划进复核、
// 修复文件进 files、worker 声明与实际对齐）、以及 repair 提示词的证据裁剪。
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import path from 'node:path';
import { runnerFixture, jobConfig, plan, feasibility } from './harness.mjs';
import { repairPrompt, compactChecks, compactPlan } from '../src/prompts.js';

const ISSUES = {
  assessment: 'issues_found', summary: 'clamp missing',
  checks: [{ id: 'clamp', kind: 'static', statement: 'value is clamped', command: '', expected: 'Math.min applied' }],
};
const CLEAN = {
  assessment: 'verified_statically', summary: 'fixed',
  checks: [{ id: 'run-tests', kind: 'build', statement: '项目测试通过', command: 'npm test', expected: '全部用例通过' }],
};
const repairPlan = goal => ({
  status: 'ready', blockers: [], acceptance: ['clamp is applied'],
  tasks: [{
    id: 'fix', files: ['src/a.js'], goal, constraints: ['keep the export name'], suggestedSteps: [], provides: [], consumes: [],
    feasibility: { status: 'ready', summary: 'the clamp belongs in the existing assignment', evidence: ['src/a.js: read'], questions: [] },
  }],
});
const promptOf = call => (call.prompt ?? []).map(part => part.text ?? '').join('');

test('planner 用正文收尾时，同路由只读补交一次后继续跑', async () => {
  const f = runnerFixture({ plannerProseOnly: nth => nth === 1 });
  try {
    const job = f.store.create(jobConfig(f.root));
    const report = await f.runner.run(job.id, f.parent, new AbortController().signal).result;
    assert.equal(report.status, 'needs_validation', report.error);
    assert.equal(report.plan.tasks.length, 2, '应采用补交回来的计划');
    assert.deepEqual(report.structuredRecoveries.map(item => [item.role, item.status]), [['planner', 'completed']]);
    const receipt = f.calls.find(call => call.label.includes(':receipt:'));
    assert.ok(receipt, '应有一次 receipt 会话');
    assert.match(promptOf(receipt), /只读补交，不是重做任务/);
    assert.match(promptOf(receipt), /```json/);
    const planner = report.children.find(child => child.role === 'planner');
    assert.equal(planner.recovered, true);
    assert.ok(planner.rawOutput, '原始正文要留在报告里');
  } finally { await f.bindings.dispose(); }
});

test('reviewer 用正文收尾时同样补交，不因此回滚或失败', async () => {
  const f = runnerFixture({ reviewProseOnly: () => true });
  try {
    const job = f.store.create(jobConfig(f.root, { maxRepairRounds: 0 }));
    const report = await f.runner.run(job.id, f.parent, new AbortController().signal).result;
    assert.equal(report.status, 'needs_validation', report.error);
    assert.equal(report.review.assessment, 'verified_statically');
    assert.deepEqual(report.structuredRecoveries.map(item => [item.role, item.status]), [['reviewer', 'completed']]);
    assert.equal(readFileSync(path.join(f.root, 'src/a.js'), 'utf8'), 'export const a = 2;\n');
  } finally { await f.bindings.dispose(); }
});

test('修复轮 planner 用正文收尾时同样能补交，修复继续跑完', async () => {
  // 这正是 arm-a11 那次失败的形态：首轮正常，修复轮只交正文。
  const f = runnerFixture({
    getPlan: nth => (nth === 1 ? plan() : repairPlan('把 clamp 加进赋值表达式')),
    getReview: nth => (nth === 0 ? ISSUES : CLEAN),
    plannerProseOnly: nth => nth === 2,
    plannerProseText: '四条修法见正文：换相位、改符号、实时读速度、改注释。',
    getReceipt: () => repairPlan('把 clamp 加进赋值表达式'),
  });
  try {
    const job = f.store.create(jobConfig(f.root));
    const report = await f.runner.run(job.id, f.parent, new AbortController().signal).result;
    assert.equal(report.status, 'needs_validation', report.error);
    assert.ok(report.repair, '修复轮应当跑完');
    assert.equal(report.repair.review.assessment, 'verified_statically');
    assert.deepEqual(report.structuredRecoveries.map(item => [item.role, item.status]), [['planner', 'completed']]);
    const repairPlanner = report.children.findLast(child => child.role === 'planner' && child.phase === 'repair-1');
    assert.equal(repairPlanner.recovered, true);
    assert.ok(repairPlanner.rawOutput, '修复轮的原始正文要留下');
    assert.match(repairPlanner.rawOutput, /四条修法见正文/);
  } finally { await f.bindings.dispose(); }
});

test('补交也失败时按原语义失败，但正文与补交记录都留在报告里', async () => {
  const f = runnerFixture({
    plannerProseOnly: () => true,
    plannerProseText: '我把计划写在正文里：改 a 和 b。',
    getReceipt: () => { throw new Error('补交会话也没交结果'); },
  });
  try {
    const job = f.store.create(jobConfig(f.root));
    const report = await f.runner.run(job.id, f.parent, new AbortController().signal).result;
    assert.equal(report.status, 'failed');
    assert.match(report.error, /缺少结构化结果|运行未完成/);
    const planner = report.children.find(child => child.role === 'planner');
    assert.match(planner.rawOutput, /我把计划写在正文里/);
    assert.ok(report.structuredRecoveries.some(item => item.status === 'failed'));
    assert.equal(readFileSync(path.join(f.root, 'src/a.js'), 'utf8'), 'export const a = 1;\n', '规划阶段不该有写入');
  } finally { await f.bindings.dispose(); }
});

test('修复轮复核看到的是修复计划，不是首轮计划', async () => {
  const f = runnerFixture({ getPlan: nth => (nth === 1 ? plan() : repairPlan('把 clamp 加进赋值表达式')), getReview: nth => (nth === 0 ? ISSUES : CLEAN) });
  try {
    const job = f.store.create(jobConfig(f.root));
    const report = await f.runner.run(job.id, f.parent, new AbortController().signal).result;
    assert.equal(report.status, 'needs_validation', report.error);
    const reviews = f.calls.filter(call => call.label.includes(':reviewer:')).map(promptOf);
    assert.equal(reviews.length, 2);
    assert.match(reviews[0], /change a to 2/, '首次复核看首轮计划');
    assert.match(reviews[1], /把 clamp 加进赋值表达式/, '修复轮复核必须看修复计划');
    assert.doesNotMatch(reviews[1], /change a to 2/, '不能拿首轮计划的 goal 冒充修复计划');
  } finally { await f.bindings.dispose(); }
});

test('修复轮新建的文件也进 report.files', async () => {
  const created = {
    status: 'ready', blockers: [], acceptance: ['helper exists'],
    tasks: [{
      id: 'helper', files: ['src/c.js'], goal: 'add helper', constraints: [], suggestedSteps: [], provides: [], consumes: [],
      feasibility: { status: 'ready', summary: 'new file', evidence: ['src/a.js: read'], questions: [] },
    }],
  };
  const f = runnerFixture({ getPlan: nth => (nth === 1 ? plan() : created), getReview: nth => (nth === 0 ? ISSUES : CLEAN) });
  try {
    const job = f.store.create(jobConfig(f.root));
    const report = await f.runner.run(job.id, f.parent, new AbortController().signal).result;
    assert.equal(report.status, 'needs_validation', report.error);
    assert.ok(report.files.some(file => file.file === 'src/c.js' && file.changed), '修复阶段新建的文件必须出现在最终清单');
    assert.ok(report.files.some(file => file.file === 'src/a.js'), '首阶段文件不能被覆盖掉');
  } finally { await f.bindings.dispose(); }
});

test('worker 声称改了却没落盘 → 该任务失败，报错点明文件', async () => {
  const single = () => ({
    status: 'ready', blockers: [], acceptance: ['a is 2'],
    tasks: [{ id: 'a', files: ['src/a.js'], goal: 'change a to 2', constraints: [], suggestedSteps: [], provides: [], consumes: [],
      feasibility: { status: 'ready', summary: 'ok', evidence: ['src/a.js: read'], questions: [] } }],
  });
  // workerResult 只返回回执、不写盘：这正是「声称完成但没写」。
  const f = runnerFixture({ getPlan: single, workerResult: task => ({ status: 'completed', summary: '改好了', changedFiles: [single().tasks[0].files[0]] }) });
  try {
    const job = f.store.create(jobConfig(f.root));
    const report = await f.runner.run(job.id, f.parent, new AbortController().signal).result;
    assert.equal(report.status, 'failed');
    assert.match(report.error, /没有实际变化/);
    assert.equal(report.tasks[0].status, 'failed');
    assert.equal(readFileSync(path.join(f.root, 'src/a.js'), 'utf8'), 'export const a = 1;\n');
  } finally { await f.bindings.dispose(); }
});

test('worker 改了没申报 → 按磁盘并入 changedFiles 并留事件', async () => {
  const single = () => ({
    status: 'ready', blockers: [], acceptance: ['a and b'],
    tasks: [{ id: 'a', files: ['src/a.js', 'src/b.js'], goal: 'change a and b', constraints: [], suggestedSteps: [], provides: [], consumes: [],
      feasibility: { status: 'ready', summary: 'ok', evidence: ['src/a.js: read'], questions: [] } }],
  });
  // 只写 files[0]，回执只报 files[1]：一个真改没报、一个报了没改。
  const f = runnerFixture({ getPlan: single, workerChangedFiles: () => ['src/b.js'] });
  try {
    const job = f.store.create(jobConfig(f.root));
    const report = await f.runner.run(job.id, f.parent, new AbortController().signal).result;
    assert.equal(report.status, 'needs_validation', report.error);
    assert.deepEqual(report.workers[0].changedFiles, ['src/a.js'], '以磁盘为准并入真实改动');
    assert.ok(report.events.some(event => event.stage === 'worker-unchanged-claims'), '应记录「声称但未变」');
  } finally { await f.bindings.dispose(); }
});

test('repair 提示词只带 id/kind/statement/expected，不再内联 command', () => {
  const bigReview = {
    assessment: 'issues_found', summary: '多处问题',
    checks: Array.from({ length: 12 }, (_, i) => ({
      id: `c${i}`, kind: 'runtime', statement: `第 ${i} 项要确认`,
      command: `node tools/check-${i}.mjs --verbose --json`, expected: `第 ${i} 项通过且输出为空`,
    })),
  };
  const before = repairPrompt({ projectRoot: 'D:/p', allowedGlobs: ['src/**'], protectedFiles: [], allowProtected: false, maxWorkers: 3, task: 'x' },
    plan(), { 'src/a.js': 'h' }, [{ taskId: 'a', status: 'completed', summary: 's', changedFiles: ['src/a.js'] }], bigReview);
  assert.match(before, /c0/);
  assert.match(before, /第 0 项要确认/);
  assert.doesNotMatch(before, /tools\/check-0\.mjs/, 'command 不该进修复规划');
  assert.match(before, /command 由主会话执行/);
  // feasibility 证据也不再随上一轮计划重复注入
  assert.doesNotMatch(before, /planner read the numeric export/);
  // 交付协议仍在最后
  assert.ok(before.trimEnd().endsWith('只用正文回复等于本轮失败。'));
});

test('repair 提示词比整段内联小得多（同输入 A/B）', () => {
  const job = { projectRoot: 'D:/p', allowedGlobs: ['src/**'], protectedFiles: [], allowProtected: false, maxWorkers: 3, task: 'x' };
  // 贴近真实体量：长 statement / expected / command，planner 证据也长。
  const checks = Array.from({ length: 14 }, (_, i) => ({
    id: `check-${i}`, kind: 'runtime',
    statement: `第 ${i} 项要确认运行时行为，覆盖 ${i} 号路径并排除相邻分支的误报`,
    command: `node tools/check-${i}.mjs --verbose --json --window ${i}`,
    expected: `第 ${i} 项通过：退出码 0，输出为空，且相邻分支 ${i + 1} 不被改动；若出现回退则记录为失败并保留现场`,
  }));
  const heavy = plan();
  for (const task of heavy.tasks) task.feasibility.evidence = Array.from({ length: 3 }, () => 'src/a.js: '.concat('已读的实现细节与观察'.repeat(18)));
  const review = { assessment: 'issues_found', summary: 's', checks };
  const workers = [{ taskId: 'a', status: 'completed', summary: 's'.repeat(400), changedFiles: ['src/a.js'] }];
  const nowPrompt = repairPrompt(job, heavy, { 'src/a.js': 'h' }, workers, review);
  // 同一条提示词，只把两个证据字段换回旧实现的内联形状。
  const legacyPrompt = nowPrompt
    .replace(JSON.stringify(compactChecks(checks)), JSON.stringify(checks))
    .replace(JSON.stringify(compactPlan(heavy)), JSON.stringify(heavy));
  assert.ok(legacyPrompt.length > nowPrompt.length, '对照串应当更长');
  assert.ok(nowPrompt.length < legacyPrompt.length * 0.8, `裁剪后应明显更短：${nowPrompt.length} vs ${legacyPrompt.length}`);
});

