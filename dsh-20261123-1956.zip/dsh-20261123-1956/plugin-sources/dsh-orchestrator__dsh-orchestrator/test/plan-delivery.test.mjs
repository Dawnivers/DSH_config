// 计划类交付协议的回归测试：arm-a11（2026-11-15）的 repair planner 把修复计划写成
// 正文就收尾、没有调用 structured_output，宿主判「未提交有效的 structured_output」整轮失败。
// 钉住四件事：planner/repair 两条计划提示词末尾都复述工具要求、内嵌 schema 与校验器同源、
// 重试轮（带 rejection）同样以交付协议收尾、各自原有的要求不丢。
import test from 'node:test';
import assert from 'node:assert/strict';
import { repairPrompt, plannerPrompt, planDelivery } from '../src/prompts.js';
import { jobConfig, runnerFixture, plan as harnessPlan } from './harness.mjs';
import { PLAN_SCHEMA } from '../src/policy.js';

const job = {
  projectRoot: 'D:/proj',
  allowedGlobs: ['src/**'],
  protectedFiles: [],
  allowProtected: false,
  maxWorkers: 3,
  task: '把鲸鱼游动改成真实巡航感',
};
const plan = { tasks: [{ id: 'swim', files: ['src/koi.js'], goal: 'g', constraints: [], suggestedSteps: [] }], acceptance: ['构建通过'], status: 'ready', blockers: [] };
const files = { 'src/koi.js': 'd3d13cac' };
const workers = [{ taskId: 'swim', status: 'completed', summary: 'done' }];
const review = { assessment: 'issues_found', summary: '半频回绕跳变', checks: [{ id: 'heave-phase-wrap', kind: 'static' }] };

const prompt = repairPrompt(job, plan, files, workers, review);

test('repairPrompt 末尾复述必须调用 structured_output', () => {
  assert.ok(prompt.includes(planDelivery), '尾部交付协议应整块拼入');
  const tail = prompt.trimEnd();
  assert.ok(tail.endsWith('只用正文回复等于本轮失败。'), '最后一句应是收尾重申');
  assert.match(prompt, /本轮必须调用 structured_output 提交计划，不能用普通正文结束/);
  assert.match(prompt, /宿主按「未提交有效的 structured_output」判本轮失败，一个文件也不会写入/);
  // 重申必须排在 schema 之后（近因效应：最后一屏仍看到要求）
  assert.ok(tail.indexOf('末尾重申') > prompt.indexOf('```json'), '重申应位于 schema 代码块之后');
});

test('repairPrompt 内嵌的 schema 与 PLAN_SCHEMA 同源', () => {
  const block = prompt.match(/```json\n([\s\S]*?)\n```/);
  assert.ok(block, '应有一块可机器校验的 schema 代码块');
  const embedded = JSON.parse(block[1]);
  assert.deepEqual(embedded, PLAN_SCHEMA, '内嵌 schema 必须逐字等于校验器用的 PLAN_SCHEMA');
  assert.deepEqual(embedded.required, ['tasks', 'acceptance', 'status', 'blockers']);
});

test('repairPrompt 已把必填字段形状说清', () => {
  const task = PLAN_SCHEMA.properties.tasks.items;
  for (const key of PLAN_SCHEMA.required) assert.ok(prompt.includes(key), `顶层字段 ${key} 应出现`);
  for (const key of task.required) assert.ok(prompt.includes(key), `任务字段 ${key} 应出现`);
  for (const key of task.properties.feasibility.required) assert.ok(prompt.includes(key), `feasibility 字段 ${key} 应出现`);
  assert.ok(prompt.includes('from 必须是另一任务的 id'), 'consumes.from 的口径要复述');
});

test('repairPrompt 原有五条修复要求不丢', () => {
  assert.match(prompt, /这是一次定向修复规划/);
  assert.match(prompt, new RegExp(`只输出修复这些问题所需的最小任务集合（1 到 ${job.maxWorkers} 个）`));
  assert.match(prompt, /每个任务仍必须带 feasibility\{status,summary,evidence,questions\}/);
  assert.match(prompt, /那些仍留给主会话；只修静态可定位的代码问题/);
  assert.match(prompt, /输出 status=blocked、tasks=\[\]、非空 blockers/);
  assert.match(prompt, /不得借本次修复重构架构、替换资产或改动用户硬约束之外的内容/);
  // review 证据仍原样带上
  assert.match(prompt, /heave-phase-wrap/);
});

/* ------------------------------ planner 轮（首轮 + 重试轮） ------------------------------ */

const firstPlan = plannerPrompt(job);
const retryPlan = plannerPrompt(job, 'consumes[].from 填成了文件名，且任务文件重复分配');

test('plannerPrompt 首轮也以交付协议收尾', () => {
  assert.ok(firstPlan.includes(planDelivery), '首轮计划提示词应整块拼入交付协议');
  const tail = firstPlan.trimEnd();
  assert.ok(tail.endsWith('只用正文回复等于本轮失败。'), '最后一句应是收尾重申');
  assert.match(firstPlan, /本轮必须调用 structured_output 提交计划，不能用普通正文结束/);
  assert.equal(firstPlan.split(planDelivery).length - 1, 1, '交付协议只能出现一次，避免重复注入');
  assert.ok(tail.indexOf('末尾重申') > firstPlan.indexOf('```json'), '重申应位于 schema 代码块之后');
});

test('plannerPrompt 重试轮同样收尾在交付协议，且保留被拒原因', () => {
  const tail = retryPlan.trimEnd();
  assert.ok(tail.endsWith('只用正文回复等于本轮失败。'), '重试轮也必须以收尾重申结束');
  assert.match(retryPlan, /上次计划或请求被拒原因：consumes\[\]\.from 填成了文件名/);
  assert.equal(retryPlan.split(planDelivery).length - 1, 1, '重试轮也只拼一次');
  // 被拒原因必须排在交付协议之前，否则重试上下文会被挤到模型最后看不到的位置
  assert.ok(retryPlan.indexOf('上次计划或请求被拒原因') < retryPlan.indexOf(planDelivery));
});

test('plannerPrompt 与 repairPrompt 内嵌同一份 schema', () => {
  for (const [name, text] of [['planner', firstPlan], ['repair', prompt]]) {
    const block = text.match(/```json\n([\s\S]*?)\n```/);
    assert.ok(block, `${name} 应有一块可机器校验的 schema 代码块`);
    assert.deepEqual(JSON.parse(block[1]), PLAN_SCHEMA, `${name} 内嵌 schema 必须等于 PLAN_SCHEMA`);
  }
});

test('plannerPrompt 原有规划要求不丢', () => {
  assert.match(firstPlan, /给出源码实施计划，而不是只读研究任务/);
  assert.match(firstPlan, /将可行性检查合并在本次规划内完成/);
  assert.match(firstPlan, /不要输出 instruction/);
  assert.match(firstPlan, /consumes\[\]\.from 必须填另一任务的 id/);
  assert.match(firstPlan, /不要为了跳过复核强行合并任务/);
  assert.match(firstPlan, /输出 status=blocked、tasks=\[\]、非空 blockers/);
  assert.match(firstPlan, /仅名称\/物种\/术语不同，不自动等于资产版本不符/);
  // 无 rejection 时不能凭空塞一行被拒原因
  assert.doesNotMatch(firstPlan, /上次计划或请求被拒原因/);
});

/* ------------------------------ 走真实 runner 的接线检查 ------------------------------ */
// 单元断言只证明函数拼了；这里证明宿主真的把这段发给了子会话（runner → bindings → spawn）。

const ISSUES = {
  assessment: 'issues_found',
  summary: 'clamp missing',
  checks: [{ id: 'clamp', kind: 'static', statement: 'value is clamped', command: '', expected: 'Math.min applied' }],
};
const CLEAN = {
  assessment: 'verified_statically',
  summary: 'fixed',
  checks: [{ id: 'run-tests', kind: 'build', statement: '项目测试通过', command: 'npm test', expected: '全部用例通过' }],
};
const repairPlanFixture = {
  status: 'ready',
  blockers: [],
  acceptance: ['clamp is applied'],
  tasks: [{
    id: 'fix',
    files: ['src/a.js'],
    goal: 'apply the clamp',
    constraints: ['keep the export name'],
    suggestedSteps: [],
    provides: [],
    consumes: [],
    feasibility: { status: 'ready', summary: 'the clamp belongs in the existing assignment', evidence: ['src/a.js: read the assignment'], questions: [] },
  }],
};
const promptText = (call) => (call.prompt ?? []).map((part) => part.text ?? '').join('');

test('真实 runner 发给 planner 的首轮提示词以交付协议收尾', async () => {
  const f = runnerFixture();
  try {
    const job = f.store.create(jobConfig(f.root));
    const report = await f.runner.run(job.id, f.parent, new AbortController().signal, undefined, { planOnly: true }).result;
    assert.equal(report.status, 'planned', report.error);
    const planners = f.calls.filter((call) => call.label.includes(':planner:'));
    assert.equal(planners.length, 1);
    const sent = promptText(planners[0]);
    assert.ok(sent.trimEnd().endsWith('只用正文回复等于本轮失败。'), '实际发出的提示词必须以收尾重申结束');
    assert.match(sent, /```json/);
  } finally {
    await f.bindings.dispose();
  }
});

test('真实 runner 的修复轮提示词同样以交付协议收尾，并带着复核证据', async () => {
  const f = runnerFixture({ getPlan: (count) => (count === 1 ? harnessPlan() : repairPlanFixture), getReview: (count) => (count === 0 ? ISSUES : CLEAN) });
  try {
    const job = f.store.create(jobConfig(f.root));
    const report = await f.runner.run(job.id, f.parent, new AbortController().signal).result;
    assert.equal(report.status, 'needs_validation', report.error);
    const planners = f.calls.filter((call) => call.label.includes(':planner:'));
    assert.equal(planners.length, 2, '应有初始规划与修复规划两次 planner 调用');
    const [initial, repair] = planners.map(promptText);
    assert.ok(initial.trimEnd().endsWith('只用正文回复等于本轮失败。'));
    assert.ok(repair.trimEnd().endsWith('只用正文回复等于本轮失败。'), '修复轮实际发出的提示词也必须以收尾重申结束');
    assert.match(repair, /这是一次定向修复规划/);
    assert.match(repair, /clamp missing/, '复核摘要要带进修复轮');
    assert.match(repair, /```json/);
  } finally {
    await f.bindings.dispose();
  }
});


