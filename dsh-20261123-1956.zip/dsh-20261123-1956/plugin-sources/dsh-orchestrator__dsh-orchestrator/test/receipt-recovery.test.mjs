import test from 'node:test';
import assert from 'node:assert/strict';
import path from 'node:path';
import { readFileSync, writeFileSync } from 'node:fs';
import { runnerFixture, jobConfig, plan } from './harness.mjs';
import { workerPrompt, workerDelivery } from '../src/prompts.js';

function setup(mode = 'success') {
  const f = runnerFixture({ getPlan() { const p = plan(); p.tasks = [p.tasks[0]]; return p; } });
  const start = f.ctx.subagents.start;
  let writes = 0;
  f.ctx.subagents.start = async (provider, request) => {
    const run = await start(provider, request);
    const role = request.label.split(':')[2];
    if (role === 'worker') {
      const normal = await run.result;
      writes++;
      if (mode === 'no-change') writeFileSync(path.join(f.root, 'src/a.js'), 'export const a = 1;\n');
      const kind = ['network', 'cancel', 'max-tokens', 'refusal'].includes(mode) ? ({ network: 'error', cancel: 'aborted', 'max-tokens': 'max-tokens', refusal: 'blocked' })[mode] : 'completed';
      run.localAgent.session.snapshotEvents = () => [{ type: 'turn/end', data: { reason: { kind, error: { message: '503 upstream unavailable' } } } }];
      return { ...run, result: Promise.resolve({ stopReason: mode === 'cancel' ? 'aborted' : mode === 'max-tokens' ? 'max-tokens' : mode === 'refusal' ? 'refusal' : 'error', output: [{ type: 'text', text: 'Done; this prose is not a receipt. sk-abcdefgh123456789' }], ...(mode === 'diagnostic' ? { diagnostic: 'upstream failure' } : {}) }) };
    }
    if (role === 'receipt') {
      assert.deepEqual(request.toolFilter.allow, ['read', 'glob', 'grep']);
      assert.equal(f.ctx.check({ agent: run.localAgent, name: 'write', arguments: { file_path: path.join(f.root, 'src/a.js') } }), '规划 / 复核代理只允许读取');
      assert.equal(f.ctx.check({ agent: run.localAgent, name: 'edit', arguments: { file_path: path.join(f.root, 'src/a.js') } }), '规划 / 复核代理只允许读取');
      assert.equal(f.ctx.check({ agent: run.localAgent, name: 'read', arguments: { file_path: path.join(f.root, 'src/a.js') } }), undefined);
      assert.equal(f.ctx.check({ agent: run.localAgent, name: 'structured_output', arguments: {} }), undefined);
      assert.match(request.prompt[0].text, /唯一一次只读补交回执/);
      assert.doesNotMatch(request.prompt[0].text, /sk-abcdefgh123456789/);
      assert.equal(readFileSync(path.join(f.root, 'src/a.js'), 'utf8'), 'export const a = 2;\n');
      await run.result;
      run.localAgent.session.snapshotEvents = () => [{ type: 'turn/end', data: { reason: { kind: 'completed' } } }];
      if (mode === 'recovery-fails') return { ...run, result: Promise.resolve({ stopReason: 'error', output: [] }) };
      if (mode === 'file-changes') writeFileSync(path.join(f.root, 'src/a.js'), 'external edit\n');
      return { ...run, result: Promise.resolve({ stopReason: 'completed', structured: { status: mode === 'mismatch' ? 'mismatch' : 'completed', summary: 'Read current file; build not run', changedFiles: mode === 'foreign-file' ? ['src/b.js'] : ['src/a.js'] }, output: [] }) };
    }
    return run;
  };
  return { ...f, get writes() { return writes; } };
}
async function execute(f, signal = new AbortController().signal) {
  const config = jobConfig(f.root);
  const job = f.store.create(config);
  const report = await f.runner.run(job.id, f.parent, signal).result;
  assert.deepEqual(f.store.get(job.id).worker, config.worker);
  return report;
}

test('worker prompt repeats the structured delivery contract at both ends', () => {
  const p = plan();
  const text = workerPrompt({ projectRoot: 'D:/fixture', allowedGlobs: ['src/**'], protectedFiles: [], allowProtected: false, task: 'test' }, p, p.tasks[0]);
  assert.ok(text.startsWith(workerDelivery));
  assert.ok(text.endsWith(workerDelivery));
  assert.match(workerDelivery, /completed 或 mismatch/);
  assert.match(workerDelivery, /不能用普通正文结束/);
});

test('one read-only same-route receipt recovers written work and still runs reviewer', async () => {
  const f = setup();
  try {
    const r = await execute(f);
    assert.equal(r.status, 'needs_validation', r.error);
    assert.equal(f.writes, 1);
    assert.deepEqual(r.children.map(c => c.role), ['planner', 'worker', 'receipt', 'reviewer']);
    assert.equal(r.children[1].status, 'failed');
    assert.equal(r.receiptRecoveries[0].sourceChildId, r.children[1].childId);
    assert.equal(r.receiptRecoveries[0].status, 'completed');
    const original = f.calls.find(c => c.label.includes(':worker:'));
    const receipt = f.calls.find(c => c.label.includes(':receipt:'));
    assert.deepEqual(receipt.agentOptions, original.agentOptions);
    assert.deepEqual(receipt.outputSchema, original.outputSchema);
    assert.match(r.workers[0].summary, /只读补交回执/);
    assert.equal(f.disposed.length, 4);
  } finally { await f.bindings.dispose(); }
});

for (const mode of ['network', 'cancel', 'max-tokens', 'refusal', 'diagnostic', 'no-change']) {
  test(`${mode} does not trigger receipt recovery`, async () => {
    const f = setup(mode);
    try {
      const r = await execute(f);
      assert.equal(r.status, 'failed');
      assert.equal(f.calls.filter(c => c.label.includes(':receipt:')).length, 0);
      assert.equal(f.calls.filter(c => c.label.includes(':reviewer:')).length, 0);
    } finally { await f.bindings.dispose(); }
  });
}
for (const mode of ['recovery-fails', 'mismatch', 'foreign-file', 'file-changes']) {
  test(`${mode} stops after a single receipt attempt without reviewer or rewriting`, async () => {
    const f = setup(mode);
    try {
      const r = await execute(f);
      assert.equal(r.status, 'failed');
      assert.equal(f.calls.filter(c => c.label.includes(':receipt:')).length, 1);
      assert.equal(f.calls.filter(c => c.label.includes(':reviewer:')).length, 0);
      assert.equal(f.writes, 1);
    } finally { await f.bindings.dispose(); }
  });
}

test('cancellation before the receipt start prevents the additional model call', async () => {
  const f = setup();
  const controller = new AbortController();
  try {
    const job = f.store.create(jobConfig(f.root));
    const report = await f.runner.run(job.id, f.parent, controller.signal, stage => {
      if (stage === 'receipt-recovery') controller.abort('user cancelled');
    }).result;
    assert.equal(report.status, 'cancelled');
    assert.equal(f.calls.filter(c => c.label.includes(':receipt:')).length, 0);
    assert.equal(f.calls.filter(c => c.label.includes(':reviewer:')).length, 0);
    assert.equal(report.receiptRecoveries[0].status, 'failed');
    assert.equal(f.writes, 1);
  } finally { await f.bindings.dispose(); }
});

test('receipt creation failure does not retry implementation or lose the original failure', async () => {
  const f = setup();
  const start = f.ctx.subagents.start;
  f.ctx.subagents.start = async (...args) => {
    if (args[1].label.includes(':receipt:')) throw new Error('receipt creation unavailable');
    return start(...args);
  };
  try {
    const r = await execute(f);
    assert.equal(r.status, 'failed');
    assert.match(r.error, /receipt creation unavailable/);
    assert.equal(r.children.filter(c => c.role === 'receipt').length, 1);
    assert.equal(r.children.find(c => c.role === 'worker').status, 'failed');
    assert.equal(f.writes, 1);
    assert.equal(r.receiptRecoveries[0].status, 'failed');
  } finally { await f.bindings.dispose(); }
});

test('normal completion without any write calls never launches a receipt', async () => {
  const f = runnerFixture({ getPlan() { const p = plan(); p.tasks = [p.tasks[0]]; return p; }, workerResult: () => ({}) });
  const start = f.ctx.subagents.start;
  f.ctx.subagents.start = async (...args) => {
    const run = await start(...args);
    if (!args[1].label.includes(':worker:')) return run;
    await run.result;
    run.localAgent.session.snapshotEvents = () => [{ type: 'turn/end', data: { reason: { kind: 'completed' } } }];
    return { ...run, result: Promise.resolve({ stopReason: 'error', output: [] }) };
  };
  try {
    const r = await execute(f);
    assert.equal(r.status, 'failed');
    assert.equal(f.calls.length, 2);
  } finally { await f.bindings.dispose(); }
});
