import { mkdtempSync, mkdirSync, writeFileSync } from 'node:fs';
import path from 'node:path';
import { randomUUID } from 'node:crypto';
import { createBindings } from '../src/bindings.js';
import { createRunner } from '../src/runner.js';
import { makeStore } from '../src/store.js';
import { validateJob } from '../src/policy.js';

export function fixture() {
  const base = path.resolve('test-artifacts');
  mkdirSync(base, { recursive: true });
  const dir = mkdtempSync(path.join(base, 'case-'));
  const root = path.join(dir, 'project');
  mkdirSync(path.join(root, 'src'), { recursive: true });
  writeFileSync(path.join(root, 'src', 'a.js'), 'export const a = 1;\n');
  writeFileSync(path.join(root, 'src', 'b.js'), 'export const b = 1;\n');
  return { dir, root, store: makeStore(path.join(dir, 'state')) };
}
export function jobConfig(root, overrides = {}) {
  return validateJob({ task: 'Change a and b to 2', projectRoot: root,
    planner: { provider: 'strong', model: 'planner', effort: 'max' }, worker: { provider: 'cheap', model: 'worker', effort: 'low' },
    allowedGlobs: ['src/**'], maxWorkers: 2, maxPlanRetries: 1, ...overrides });
}
export function plan() {
  const candidate = { status: 'ready', blockers: [], tasks: [
    { id: 'a', files: ['src/a.js'], goal: 'change a to 2', constraints: ['preserve export a'], suggestedSteps: ['inspect the current initializer'], provides: [{ name: 'a', signature: 'number' }], consumes: [] },
    { id: 'b', files: ['src/b.js'], goal: 'change b to 2', constraints: ['preserve export b'], suggestedSteps: [], provides: [], consumes: [{ name: 'a', from: 'a', signature: 'number' }] },
  ], acceptance: ['a and b are 2'] };
  for (const task of candidate.tasks) task.feasibility = { status: 'ready', summary: 'the existing numeric export can be changed within its assigned file', evidence: [`${task.files[0]}: planner read the numeric export initialized to 1`], questions: [] };
  return candidate;
}
export function feasibility(candidate = plan()) {
  return { status: 'ready', summary: 'all task goals are implementable within their assigned files', tasks: candidate.tasks.map(task => ({
    taskId: task.id, status: 'ready', summary: 'existing export can retain its name and change value',
    evidence: [`${task.files[0]}: existing numeric export is initialized to 1`], questions: [],
  })) };
}
export function mockContext(options = {}) {
  const listeners = new Map();
  const guards = [];
  const calls = [];
  const disposed = [];
  let latestPlan;
  let reviewCount = 0;
  const ctx = {
    on(event, listener) {
      const list = listeners.get(event) || [];
      list.push(listener); listeners.set(event, list);
      return () => { const i = list.indexOf(listener); if (i >= 0) list.splice(i, 1); };
    },
    async emitCreated(agent) { for (const listener of listeners.get('agent/created') || []) await listener({ agent }); },
    tools: {
      guard(fn) { guards.push(fn); return () => guards.splice(guards.indexOf(fn), 1); },
    },
    agents: { isOwnedBy(id, parent) { return ctx.children.get(id)?.parent === parent; } },
    children: new Map(),
    llm: {
      listProviders() { return [{ id: 'strong' }, { id: 'cheap' }]; },
      async listModels(provider) { return [{ provider, id: provider === 'strong' ? 'planner' : 'worker', name: provider }]; },
      async resolveModelInfo(provider, model) { return { provider, id: model, reasoning: { efforts: [{ id: 'low', name: 'Low' }, { id: 'max', name: 'Max' }] } }; },
      async resolveCallConfig(config, signal) { signal?.throwIfAborted(); if (config.reasoningEffort === 'invalid') throw new Error('unsupported effort'); return config; },
    },
    subagents: {
      getProvider() { return { capabilities: { agentOptions: true, toolFilter: true, outputSchema: true, depthLimit: true, persona: true } }; },
      async start(provider, request) {
        const id = randomUUID();
        const agent = { id, session: { id, header: { origin: 'subagent', parentSession: request.parent.session.id } }, ctx };
        ctx.children.set(id, { agent, parent: request.parent });
        calls.push(request);
        if (!options.skipCreated) await ctx.emitCreated(agent);
        let role = request.label.split(':')[2];
        const task = request.label.split(':')[3];
        const execute = async () => {
          if (options.delay) await new Promise(resolve => setTimeout(resolve, options.delay));
          request.signal.throwIfAborted();
          const fire = (name, args) => ctx.check({ agent, name, arguments: args });
          options.beforeResult?.({ role, task, request, fire, agent });
          // 只回正文、不调用 structured_output：复现「模型用散文收尾」的失败形态。
          const proseOnly = text => ({ stopReason: 'completed', output: [{ type: 'text', text }] });
          if (role === 'reviewer' && options.reviewerFailure) {
            const nth = calls.filter(call => call.label.includes(':reviewer:')).length;
            const diagnostic = options.reviewerFailure(nth);
            if (diagnostic) return { stopReason: 'error', diagnostic, output: [] };
          }
          let structured;
          if (role === 'planner') {
            const nth = calls.filter(x => x.label.includes(':planner:')).length;
            if (options.plannerProseOnly?.(nth)) return proseOnly(options.plannerProseText || '我的修复计划：改 koi.js 的三处。');
            structured = latestPlan = options.getPlan ? options.getPlan(nth) : plan();
          } else if (role === 'feasibility') {
            for (const task of latestPlan.tasks) {
              const denial = fire('read', { file_path: path.join(options.root, task.files[0]) });
              if (denial) throw new Error(denial);
            }
            structured = options.getFeasibility ? options.getFeasibility(latestPlan) : feasibility(latestPlan);
          } else if (role === 'worker') {
            const spec = latestPlan.tasks.find(item => item.id === task);
            if (options.workerResult) return { stopReason: 'completed', structured: options.workerResult(task), output: [] };
            if (options.failWorker === task) return { stopReason: 'error', diagnostic: 'simulated worker failure', output: [] };
            const file = path.join(options.root, spec.files[0]);
            const denial = fire('write', { file_path: file });
            if (denial) throw new Error(denial);
            writeFileSync(file, `export const ${task} = 2;\n`);
            // 写完之后再炸：用于验证「已写入后失败」的回滚路径。
            options.afterWorkerWrite?.({ task, file, fire, agent });
            structured = options.workerChangedFiles
              ? { status: 'completed', summary: 'changed', changedFiles: options.workerChangedFiles(task, spec.files[0]) }
              : { status: 'completed', summary: 'changed', changedFiles: [options.absoluteChangedFiles ? file : spec.files[0]] };
          } else if (role === 'receipt') {
            // 结构化补交会话：按请求 schema 的形状返回，模拟「把正文压回去」。
            const needs = request.outputSchema?.required ?? [];
            const nth = calls.filter(x => x.label.includes(':receipt:')).length;
            structured = options.getReceipt?.(nth, needs) ?? (needs.includes('tasks') ? plan()
              : needs.includes('assessment') ? {
                assessment: 'verified_statically', summary: '补交的复核结论',
                checks: [{ id: 'run-tests', kind: 'build', statement: '项目测试通过', command: 'npm test', expected: '全部用例通过' }],
              }
                : feasibility(latestPlan));
            // 补交回来的是计划时，后续 worker 应当按这份计划执行（等价于 planner 正常交付）。
            if (needs.includes('tasks') && Array.isArray(structured?.tasks)) latestPlan = structured;
          } else if (options.getReview) structured = options.getReview(reviewCount++);
          else if (options.reviewProseOnly?.(reviewCount)) { reviewCount += 1; return proseOnly(options.reviewProseText || '复核走查完毕，结论见正文。'); }
          else if (options.reviewResult) structured = options.reviewResult;
          else structured = {
            assessment: 'verified_statically', summary: 'reviewed',
            checks: [{ id: 'run-tests', kind: 'build', statement: '项目测试通过', command: 'npm test', expected: '全部用例通过' }],
          };
          return { stopReason: 'completed', structured, output: [] };
        };
        return { id, localAgent: agent, result: execute().catch(error => ({ stopReason: request.signal.aborted ? 'aborted' : 'error', diagnostic: error.message, output: [] })), async dispose() { disposed.push(id); } };
      },
    },
    get(key) { return ctx[key]; },
    logger: { warn() {} },
    check(exec) { for (const guard of guards) { const denial = guard(exec); if (denial !== undefined) return denial; } },
  };
  return { ctx, calls, guards, disposed };
}
export function runnerFixture(options = {}) {
  const fixtureState = fixture();
  const mock = mockContext({ root: fixtureState.root, ...options });
  const parent = { id: 'parent', session: { id: 'parent' } };
  const bindings = createBindings(mock.ctx);
  const runner = createRunner(mock.ctx, fixtureState.store, bindings);
  return { ...fixtureState, ...mock, parent, bindings, runner };
}
