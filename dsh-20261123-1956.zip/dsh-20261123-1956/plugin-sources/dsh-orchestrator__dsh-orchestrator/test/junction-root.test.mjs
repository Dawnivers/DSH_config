// 回归测试：项目根经由 junction 别名访问时，编排不应误判为「路径越出项目根」。
// 同时锁死安全边界：项目根【内部】的符号链接必须继续被拒绝。
//
// 注意：本文件必须能在「从 junction 路径运行」的场景下通过，
// 所以断言一律用 realpathSync 比较，不能假设 fixture 的 root 已是真实路径。
import test from 'node:test';
import assert from 'node:assert/strict';
import path from 'node:path';
import { mkdirSync, writeFileSync, symlinkSync, realpathSync } from 'node:fs';
import { validateJob, within, rebaseToRealRoot, safeTarget } from '../src/policy.js';
import { fixture, jobConfig } from './harness.mjs';

const junction = (target, link) => symlinkSync(target, link, process.platform === 'win32' ? 'junction' : 'dir');
const real = value => realpathSync(value);

test('project root reached through a junction alias still resolves into itself', () => {
  const f = fixture();
  const aliasRoot = path.join(f.dir, 'alias-root');
  junction(f.root, aliasRoot);

  // 用别名作为 projectRoot：canonicalRoot 会解析成真实路径
  const job = validateJob({
    task: 'x', projectRoot: aliasRoot,
    planner: { provider: 'p', model: 'm' }, worker: { provider: 'p', model: 'm' },
    allowedGlobs: ['src/**'], maxWorkers: 2, maxPlanRetries: 1,
  });
  assert.equal(job.projectRoot, real(f.root), '项目根应被解析为真实路径');

  // 调用方若仍用别名前缀拼路径，必须能归一到真实根，而不是报越界
  const viaAlias = path.join(aliasRoot, 'src', 'a.js');
  const rebased = rebaseToRealRoot(job.projectRoot, viaAlias);
  assert.equal(rebased, path.join(real(f.root), 'src', 'a.js'));
  assert.equal(within(job.projectRoot, rebased), true);
  // 归一后 safeTarget 必须通过（说明 guard 不会误拒）
  assert.equal(safeTarget(job.projectRoot, 'src/a.js'), path.join(real(f.root), 'src', 'a.js'));
});

test('rebase keeps not-yet-existing files inside the real root', () => {
  const f = fixture();
  const aliasRoot = path.join(f.dir, 'alias-root');
  junction(f.root, aliasRoot);
  const job = jobConfig(f.root);
  const ghost = path.join(aliasRoot, 'src', 'brand-new.js');
  assert.equal(rebaseToRealRoot(job.projectRoot, ghost), path.join(real(f.root), 'src', 'brand-new.js'));
});

test('rebase never accepts paths outside the real root', () => {
  const f = fixture();
  const aliasRoot = path.join(f.dir, 'alias-root');
  junction(f.root, aliasRoot);
  const job = jobConfig(f.root);
  mkdirSync(path.join(f.dir, 'outside'));
  writeFileSync(path.join(f.dir, 'outside', 'evil.js'), 'x\n');
  assert.throws(() => rebaseToRealRoot(job.projectRoot, path.join(f.dir, 'outside', 'evil.js')), /越出项目根/);
  // 经由别名跳出到项目外也必须拒绝
  assert.throws(() => rebaseToRealRoot(job.projectRoot, path.join(aliasRoot, '..', 'outside', 'evil.js')), /越出项目根/);
});

test('links inside the project root are still refused (security boundary unchanged)', () => {
  const f = fixture();
  mkdirSync(path.join(f.dir, 'inner-target'));
  writeFileSync(path.join(f.dir, 'inner-target', 'payload.js'), 'x\n');
  junction(path.join(f.dir, 'inner-target'), path.join(f.root, 'src', 'inner-link'));
  const job = jobConfig(f.root);
  // 根内部出现链接：即便客户端传入真实路径，也必须被 safeTarget 逐段拒绝
  const inner = path.join(real(f.root), 'src', 'inner-link', 'payload.js');
  const rel = path.relative(job.projectRoot, inner).replaceAll('\\', '/');
  assert.throws(() => safeTarget(job.projectRoot, rel), /符号链接|junction/);
  // guard 侧同样不能放行：rebase 后仍需 safeTarget 拒绝
  assert.throws(() => safeTarget(job.projectRoot, 'src/inner-link/payload.js'), /符号链接|junction/);
});
