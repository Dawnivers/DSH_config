import test from 'node:test';
import assert from 'node:assert/strict';
import path from 'node:path';
import { readFileSync } from 'node:fs';
import { normalizeRoutes, agentOptions, validateModelRoute, models, modelEntry, defaultConfig } from '../src/models.js';
import { validateJob } from '../src/policy.js';
import { toolSpecs } from '../src/index.js';
import { fixture, jobConfig, runnerFixture, plan } from './harness.mjs';
import { serverFixture } from './settings-fixture.mjs';

const routes = {
  planner: { provider: 'anthropic-route', model: 'claude-planner', effort: 'high' },
  worker: { provider: 'deepseek-route', model: 'deepseek-worker', effort: 'off' },
  reviewer: { provider: 'openai-route', model: 'gpt-reviewer', effort: 'xhigh' },
};
const entries = [
  { provider: 'anthropic-route', model: 'claude-planner', efforts: [{ id: 'high', name: 'High' }] },
  { provider: 'deepseek-route', model: 'deepseek-worker', efforts: [{ id: 'off', name: 'Off' }] },
  { provider: 'qwen-route', model: 'qwen-worker', efforts: [] },
  { provider: 'openai-route', model: 'gpt-reviewer', efforts: [{ id: 'xhigh', name: 'Extra high' }] },
];
function familyHost(ctx) {
  const resolved = [];
  ctx.llm.resolveModelInfo = async (provider, model) => {
    const entry = entries.find(item => item.provider === provider && item.model === model);
    if (!entry) throw new Error('exact model not configured');
    return { provider, id: model, name: model, ...(entry.efforts.length ? { reasoning: { efforts: entry.efforts } } : {}) };
  };
  ctx.llm.resolveCallConfig = async (config, signal) => {
    signal?.throwIfAborted(); resolved.push({ ...config });
    const info = await ctx.llm.resolveModelInfo(config.provider, config.model);
    if (config.reasoningEffort !== undefined && !info.reasoning?.efforts.some(item => item.id === config.reasoningEffort)) throw new Error('unsupported exact effort');
    return config;
  };
  return resolved;
}

test('independent reviewer normalizes object/flat config; only an absent reviewer inherits planner', () => {
  const f = fixture(), input = { ...jobConfig(f.root), ...routes };
  const job = validateJob(input); assert.deepEqual(job.reviewer, routes.reviewer);
  const legacy = { task: input.task, projectRoot: f.root, strongProvider: 'a', strongModel: 'claude', plannerEffort: 'high', cheapProvider: 'b', cheapModel: 'qwen' };
  const fallback = validateJob(legacy); assert.deepEqual(fallback.reviewer, fallback.planner); assert.notEqual(fallback.reviewer, fallback.planner);
  assert.deepEqual(validateJob({ ...legacy, reviewerProvider: 'c', reviewerModel: 'gpt', reviewerEffort: 'xhigh' }).reviewer, { provider: 'c', model: 'gpt', effort: 'xhigh' });
  for (const reviewer of [null, false, '', [], {}, { provider: 'c' }, { model: 'gpt' }, { provider: 'c', model: 'gpt', effort: 42 }]) assert.throws(() => validateJob({ ...input, reviewer }), /reviewer/);
  const absent = { ...input }; delete absent.reviewer;
  assert.deepEqual(validateJob(absent).reviewer, routes.planner);
  assert.throws(() => validateJob({ ...absent, reviewerEffort: 'high' }), /reviewer/);
  assert.throws(() => normalizeRoutes({ ...input, reviewer: { provider: 'c', model: 'gpt', effort: 'bad\n' + 'value' } }), /reviewer/);
});

test('fresh defaults prefer Claude planner and GPT reviewer without guessing efforts; saved choices never switch', () => {
  const defaults = defaultConfig(entries);
  assert.equal(defaults.planner.model, 'claude-planner'); assert.equal(defaults.reviewer.model, 'gpt-reviewer');
  for (const role of ['planner', 'worker', 'reviewer']) assert.equal('effort' in defaults[role], false);
  const saved = { planner: { provider: 'missing-route', model: 'claude-old', effort: 'custom' }, worker: routes.worker };
  assert.deepEqual(defaultConfig(entries, saved).reviewer, saved.planner);
  assert.deepEqual(defaultConfig(entries, { ...saved, reviewer: routes.reviewer }).reviewer, routes.reviewer);
  assert.deepEqual(defaultConfig(entries, { ...saved, reviewer: null }).reviewer, null);
  assert.deepEqual(defaultConfig([], saved).planner, saved.planner);
  const flat = { strongProvider: 'legacy', strongModel: 'old', plannerEffort: 'max', cheapProvider: 'other', cheapModel: 'worker' };
  assert.deepEqual(defaultConfig(entries, flat).reviewer, { provider: 'legacy', model: 'old', effort: 'max' });
  const partial = defaultConfig(entries, { ...saved, reviewerEffort: 'high' });
  assert.equal(partial.reviewer.provider, undefined); assert.equal(partial.reviewer.effort, 'high');
  assert.throws(() => validateJob({ ...jobConfig(fixture().root), ...partial }), /reviewer/);
});

for (const worker of [routes.worker, { provider: 'anthropic-route', model: 'claude-planner', effort: 'high' }, { provider: 'qwen-route', model: 'qwen-worker' }]) test(`three independent routes keep exact efforts with ${worker.model} workers`, async () => {
  const f = runnerFixture({ beforeResult({ role, fire }) {
    if (role === 'reviewer') {
      assert.match(fire('write', { file_path: path.join(f.root, 'src/a.js') }), /只允许读取/);
      assert.match(fire('subagent', {}), /禁止调用/);
    }
  } });
  const resolved = familyHost(f.ctx);
  try {
    const job = f.store.create(jobConfig(f.root, { ...routes, worker }));
    const report = await f.runner.run(job.id, f.parent, new AbortController().signal).result;
    assert.equal(report.status, 'needs_validation', report.error);
    assert.deepEqual(f.calls.map(call => call.agentOptions), [agentOptions(routes.planner), agentOptions(routes.planner), agentOptions(worker), agentOptions(worker), agentOptions(routes.reviewer)]);
    assert.deepEqual(resolved.slice(0, 4), [agentOptions(routes.planner), agentOptions(worker), agentOptions(routes.planner), agentOptions(routes.reviewer)]);
    assert.equal(report.children.length, 5); assert.equal(report.children.at(-1).role, 'reviewer');
    assert.deepEqual(report.children.at(-1).requested, agentOptions(routes.reviewer));
    for (const call of f.calls) {
      assert.ok(call.outputSchema); assert.equal('thinking' in call.agentOptions, false); assert.equal('temperature' in call.agentOptions, false);
      assert.equal('reasoning_effort' in call.agentOptions, false); assert.equal('response_format' in call, false);
    }
  } finally { await f.bindings.dispose(); }
});

for (const reviewer of [{ ...routes.reviewer, effort: 'high' }, { provider: 'missing', model: 'gpt-reviewer' }]) test(`bad reviewer ${reviewer.provider}/${reviewer.effort || 'default'} rejects before planning and writes`, async () => {
  const f = runnerFixture(); familyHost(f.ctx);
  try {
    const job = f.store.create(jobConfig(f.root, { ...routes, reviewer }));
    const report = await f.runner.run(job.id, f.parent, new AbortController().signal).result;
    assert.equal(report.status, 'failed'); assert.match(report.error, /reviewer 模型配置不可用/);
    assert.equal(f.calls.length, 0); assert.equal(report.snapshot, undefined);
    assert.equal(readFileSync(path.join(f.root, 'src/a.js'), 'utf8'), 'export const a = 1;\n');
  } finally { await f.bindings.dispose(); }
});

test('old stored job without reviewer preserves historical planner review route without mutating history', async () => {
  const f = runnerFixture(); familyHost(f.ctx);
  try {
    const config = jobConfig(f.root, routes); delete config.reviewer;
    const job = f.store.create(config), before = f.store.get(job.id);
    const report = await f.runner.run(job.id, f.parent, new AbortController().signal).result;
    assert.equal(report.status, 'needs_validation', report.error); assert.deepEqual(f.calls.at(-1).agentOptions, agentOptions(routes.planner));
    assert.deepEqual(f.store.get(job.id), before); assert.equal('reviewer' in before, false);
  } finally { await f.bindings.dispose(); }
});

test('reviewer availability is rechecked after implementation; no failover to planner', async () => {
  const f = runnerFixture(); familyHost(f.ctx);
  let reviewerChecks = 0; const original = f.ctx.llm.resolveCallConfig;
  f.ctx.llm.resolveCallConfig = async (config, signal) => {
    if (config.provider === routes.reviewer.provider && ++reviewerChecks > 1) throw new Error('review route removed during run');
    return original(config, signal);
  };
  try {
    const job = f.store.create(jobConfig(f.root, routes));
    const report = await f.runner.run(job.id, f.parent, new AbortController().signal).result;
    // 复核路由在写入后被撤掉：不回退到 planner，也不销毁已写入的成果。
    assert.equal(report.status, 'review_error');
    assert.match(report.reviewError, /reviewer.*removed during run/);
    assert.equal(f.calls.length, 4); assert.equal(report.review, undefined); assert.ok(report.files.some(file => file.changed));
  } finally { await f.bindings.dispose(); }
});

test('exact route validation rejects a host that aliases explicit route or effort', async () => {
  const f = runnerFixture();
  try {
    for (const patch of [{ provider: 'other' }, { model: 'other' }, { reasoningEffort: 'low' }]) {
      f.ctx.llm.resolveCallConfig = async config => ({ ...config, ...patch });
      await assert.rejects(validateModelRoute(f.ctx, 'reviewer', routes.reviewer), /改变了显式模型路由或档位/);
    }
  } finally { await f.bindings.dispose(); }
});

test('one broken catalog entry does not hide other models and exact metadata need not be listed', async () => {
  const f = runnerFixture();
  try {
    f.ctx.llm.listProviders = () => [{ id: 'catalog' }, { id: 'offline' }];
    f.ctx.llm.listModels = async provider => { if (provider === 'offline') throw new Error('offline'); return [{ id: 'broken' }, { id: 'qwen-good', name: 'Qwen' }]; };
    f.ctx.llm.resolveModelInfo = async (provider, model) => {
      if (model === 'broken') throw new Error('bad metadata');
      return { provider, id: model, name: model, ...(model.includes('claude') ? { reasoning: { efforts: [{ id: 'high', name: 'High' }], defaultEffort: 'high' } } : {}) };
    };
    const result = await models(f.ctx); assert.equal(result.catalog.length, 1); assert.equal(result.warnings.length, 2);
    assert.equal(result.catalog[0].model, 'qwen-good'); assert.deepEqual(result.catalog[0].efforts, []);
    const entry = await modelEntry(f.ctx, 'manual', 'claude-unlisted'); assert.equal(entry.defaultEffort, 'high'); assert.equal(entry.efforts[0].id, 'high');
    f.ctx.llm.resolveModelInfo = async () => ({ provider: 'other', id: 'other' });
    await assert.rejects(modelEntry(f.ctx, 'manual', 'gpt'), /身份/);
  } finally { await f.bindings.dispose(); }
});

test('settings persist independent reviewer, reject bad settings before saving, and protect exact model probe', async () => {
  const f = await serverFixture(); familyHost(f.ctx);
  try {
    const config = jobConfig(f.root, routes);
    const saved = await (await f.call('save', config)).json(); assert.deepEqual(saved.reviewer, routes.reviewer);
    assert.deepEqual((await (await f.call('job', config)).json()).job.reviewer, routes.reviewer);
    const count = f.store.list().length;
    for (const action of ['save', 'job']) {
      assert.equal((await f.call(action, { ...config, reviewer: { ...routes.reviewer, effort: 'unsupported' } })).status, 400);
    }
    assert.deepEqual(f.store.defaults().reviewer, routes.reviewer); assert.equal(f.store.list().length, count);
    assert.equal((await f.call('model', routes.reviewer, { headers: { 'x-settings-token': 'invalid' } })).status, 401);
    assert.equal((await f.call('model', routes.reviewer, { headers: { origin: 'https://outside.example' } })).status, 403);
    assert.equal((await f.call('model', { provider: 'missing' })).status, 400);
    const metadata = await (await f.call('model', routes.reviewer)).json(); assert.equal(metadata.model.efforts[0].id, 'xhigh');
  } finally { await f.close(); }
});

test('tool creation validates reviewer before persistence and supports old config explicitly', async () => {
  const f = runnerFixture(); familyHost(f.ctx);
  try {
    const spec = toolSpecs(f.ctx, f.store, f.runner, () => null).find(item => item.name === 'orchestrate_task');
    await assert.rejects(spec.execute({ action: 'create', config: jobConfig(f.root, { ...routes, reviewer: { ...routes.reviewer, effort: 'unsupported' } }) }), /reviewer/);
    assert.equal(f.store.list().length, 0);
    const old = jobConfig(f.root, routes); delete old.reviewer;
    const created = await spec.execute({ action: 'create', config: old }); assert.deepEqual(created.job.reviewer, routes.planner);
    assert.equal(f.calls.length, 0);
  } finally { await f.bindings.dispose(); }
});
