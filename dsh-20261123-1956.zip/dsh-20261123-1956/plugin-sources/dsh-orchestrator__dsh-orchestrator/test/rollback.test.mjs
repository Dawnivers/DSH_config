import test from 'node:test';
import assert from 'node:assert/strict';
import { existsSync, readFileSync, writeFileSync } from 'node:fs';
import path from 'node:path';
import { randomUUID } from 'node:crypto';
import { fixture, jobConfig, runnerFixture, plan } from './harness.mjs';

const ORIGINAL_A = 'export const a = 1;\n';
const ORIGINAL_B = 'export const b = 1;\n';

function snapshotFiles(f, files, jobId = randomUUID(), runId = randomUUID()) {
  const manifest = f.store.snapshot(jobId, runId, f.root, files);
  return { manifest, runDir: path.join(f.store.directory(jobId), 'snapshots', runId), jobId, runId };
}

test('restore rewrites changed bytes, deletes files created by the run, and skips untouched files', () => {
  const f = fixture();
  const { manifest, runDir } = snapshotFiles(f, ['src/a.js', 'src/b.js', 'src/new.js']);

  writeFileSync(path.join(f.root, 'src/a.js'), 'export const a = 2;\n');
  writeFileSync(path.join(f.root, 'src/new.js'), 'export const created = true;\n');
  const expected = f.store.diff(f.root, manifest);

  const results = f.store.restore(f.root, manifest, runDir, { expected });

  assert.equal(readFileSync(path.join(f.root, 'src/a.js'), 'utf8'), ORIGINAL_A);
  assert.equal(existsSync(path.join(f.root, 'src/new.js')), false);
  assert.deepEqual(results.map(item => [item.file, item.action, item.ok]), [
    ['src/a.js', 'restored', true],
    ['src/b.js', 'unchanged', true],
    ['src/new.js', 'removed', true],
  ]);
});

test('restore refuses a tampered backup instead of writing wrong bytes', () => {
  const f = fixture();
  const { manifest, runDir } = snapshotFiles(f, ['src/a.js']);

  writeFileSync(path.join(f.root, 'src/a.js'), 'export const a = 2;\n');
  const expected = f.store.diff(f.root, manifest);
  writeFileSync(path.join(runDir, manifest[0].backup), 'tampered backup\n');

  const [result] = f.store.restore(f.root, manifest, runDir, { expected });

  assert.equal(result.ok, false);
  assert.equal(result.action, 'failed');
  assert.match(result.error, /备份哈希/);
  assert.equal(readFileSync(path.join(f.root, 'src/a.js'), 'utf8'), 'export const a = 2;\n');
});

test('an external edit after the run is never overwritten', () => {
  const f = fixture();
  const { manifest, runDir } = snapshotFiles(f, ['src/a.js']);

  writeFileSync(path.join(f.root, 'src/a.js'), 'export const a = 2;\n');
  const expected = f.store.diff(f.root, manifest);
  // 运行结束后用户自己改了同一个文件
  writeFileSync(path.join(f.root, 'src/a.js'), 'export const a = 99; // hand edited\n');

  const [result] = f.store.restore(f.root, manifest, runDir, { expected });

  assert.equal(result.action, 'conflict');
  assert.equal(result.ok, false);
  assert.match(result.error, /又被改动/);
  assert.equal(readFileSync(path.join(f.root, 'src/a.js'), 'utf8'), 'export const a = 99; // hand edited\n');
});

test('without a post-run hash baseline nothing is touched', () => {
  const f = fixture();
  const { manifest, runDir } = snapshotFiles(f, ['src/a.js']);
  writeFileSync(path.join(f.root, 'src/a.js'), 'export const a = 2;\n');

  const [result] = f.store.restore(f.root, manifest, runDir);

  assert.equal(result.action, 'skipped');
  assert.equal(readFileSync(path.join(f.root, 'src/a.js'), 'utf8'), 'export const a = 2;\n');
});

test('dry run reports the plan without touching the disk', () => {
  const f = fixture();
  const { manifest, runDir } = snapshotFiles(f, ['src/a.js']);

  writeFileSync(path.join(f.root, 'src/a.js'), 'export const a = 2;\n');
  const expected = f.store.diff(f.root, manifest);
  const results = f.store.restore(f.root, manifest, runDir, { apply: false, expected });

  assert.deepEqual(results.map(item => item.action), ['would-restore']);
  assert.equal(readFileSync(path.join(f.root, 'src/a.js'), 'utf8'), 'export const a = 2;\n');
});

test('restoreRun reads the post-run baseline from that run report', () => {
  const f = fixture();
  const { manifest, runDir, jobId, runId } = snapshotFiles(f, ['src/a.js']);
  writeFileSync(path.join(f.root, 'src/a.js'), 'export const a = 2;\n');
  f.store.report(jobId, runId, { runId, files: f.store.diff(f.root, manifest) });

  const report = f.store.restoreRun(jobId, runId);
  assert.equal(report.applied, true);
  assert.equal(report.failed, 0);
  assert.equal(readFileSync(path.join(f.root, 'src/a.js'), 'utf8'), ORIGINAL_A);
  assert.ok(existsSync(path.join(runDir, 'manifest.json')));
  assert.throws(() => f.store.restoreRun(jobId, randomUUID()), /没有快照/);
});

test('a run that fails after writing restores the failed task files and keeps the snapshot', async () => {
  // 复核失败已改为「保留成果」，所以这里用「worker 写完再炸」制造写入之后的确定性失败。
  // 单任务计划：任务级失败只回滚该任务自己的文件，快照保留供事后核对。
  const single = () => ({
    status: 'ready', blockers: [], acceptance: ['a is 2'],
    tasks: [{ id: 'a', files: ['src/a.js'], goal: 'change a to 2', constraints: [], suggestedSteps: [], provides: [], consumes: [],
      feasibility: { status: 'ready', summary: 'ok', evidence: ['src/a.js: read'], questions: [] } }],
  });
  const f = runnerFixture({ getPlan: single, afterWorkerWrite() { throw new Error('写完之后模拟宿主故障'); } });
  try {
    const job = f.store.create(jobConfig(f.root));
    const report = await f.runner.run(job.id, f.parent, new AbortController().signal).result;

    assert.equal(report.status, 'failed');
    assert.ok(report.snapshot, 'snapshot must exist before writes');
    assert.equal(report.rollback.reason, 'failed');
    assert.equal(report.rollback.failed, 0);
    assert.equal(report.rollback.conflicts, 0);
    assert.equal(report.rollback.changed, 1);
    assert.deepEqual(report.rollback.files.map(item => [item.file, item.action]), [['src/a.js', 'restored']]);
    assert.equal(readFileSync(path.join(f.root, 'src/a.js'), 'utf8'), ORIGINAL_A);
    assert.ok(report.events.some(event => event.stage === 'rollback'));
    assert.ok(existsSync(path.join(report.snapshot.directory, 'manifest.json')), 'backup stays available');
  } finally { await f.bindings.dispose(); }
});

test('rollbackOnFailure=false keeps the attempted changes for inspection', async () => {
  const single = () => ({
    status: 'ready', blockers: [], acceptance: ['a is 2'],
    tasks: [{ id: 'a', files: ['src/a.js'], goal: 'change a to 2', constraints: [], suggestedSteps: [], provides: [], consumes: [],
      feasibility: { status: 'ready', summary: 'ok', evidence: ['src/a.js: read'], questions: [] } }],
  });
  const f = runnerFixture({ getPlan: single, afterWorkerWrite() { throw new Error('写完之后模拟宿主故障'); } });
  try {
    const job = f.store.create(jobConfig(f.root, { rollbackOnFailure: false }));
    assert.equal(f.store.get(job.id).rollbackOnFailure, false);
    const report = await f.runner.run(job.id, f.parent, new AbortController().signal).result;

    assert.equal(report.status, 'failed');
    assert.equal(report.rollback, undefined);
    assert.equal(readFileSync(path.join(f.root, 'src/a.js'), 'utf8'), 'export const a = 2;\n');
  } finally { await f.bindings.dispose(); }
});

test('a failure before the write gate leaves no rollback record and never touches files', async () => {
  const f = runnerFixture();
  const start = f.ctx.subagents.start;
  f.ctx.subagents.start = async (...args) => {
    const run = await start(...args);
    return { ...run, result: Promise.resolve({ stopReason: 'error', diagnostic: 'planner down', output: [] }) };
  };
  try {
    const job = f.store.create(jobConfig(f.root));
    const report = await f.runner.run(job.id, f.parent, new AbortController().signal).result;
    assert.equal(report.status, 'failed');
    assert.equal(report.snapshot, undefined);
    assert.equal(report.rollback, undefined);
    assert.equal(readFileSync(path.join(f.root, 'src/a.js'), 'utf8'), ORIGINAL_A);
  } finally { await f.bindings.dispose(); }
});

test('job config defaults rollbackOnFailure to true and accepts an explicit opt-out', () => {
  const f = fixture();
  assert.equal(jobConfig(f.root).rollbackOnFailure, true);
  assert.equal(jobConfig(f.root, { rollbackOnFailure: false }).rollbackOnFailure, false);
  assert.ok(plan().tasks.every(task => task.feasibility.status === 'ready'));
});
