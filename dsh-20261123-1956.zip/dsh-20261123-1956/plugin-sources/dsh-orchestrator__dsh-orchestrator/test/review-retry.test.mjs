import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import path from 'node:path';
import { runnerFixture, jobConfig, plan } from './harness.mjs';

const malformed = { code: 'MALFORMED_RESPONSE', message: 'tool input is invalid JSON' };
const clean = { assessment: 'verified_statically', summary: 'reviewed', checks: [{ id:'build', kind:'build', statement:'build passes', command:'npm test', expected:'exit 0' }] };

test('internal cancellation during reviewer stops before retry and reports cancelled', async () => {
 let active;
 const f=runnerFixture({reviewerFailure:()=>malformed,beforeResult({role}){
  if(role==='reviewer') active.cancel('user cancelled review');
 }});
 try {
  const j=f.store.create(jobConfig(f.root));
  active=f.runner.run(j.id,f.parent,new AbortController().signal);
  const r=await active.result;
  assert.equal(r.status,'cancelled');
  assert.equal(r.reviewAttempts.length,1);
  assert.ok(!r.events.some(e=>e.stage==='review-retry'));
 } finally {await f.bindings.dispose();}
});

test('reviewer structured recovery preserves safety refusal instead of downgrading it', async () => {
 const f=runnerFixture({ reviewProseOnly:()=>true, beforeResult({role}) {
  if(role==='receipt') throw new Error('编排任务权限拒绝：补交只读预算已耗尽');
 }});
 try {
  const j=f.store.create(jobConfig(f.root));
  const r=await f.runner.run(j.id,f.parent,new AbortController().signal).result;
  assert.equal(r.status,'failed');
  assert.match(r.error,/编排任务权限拒绝/);
  assert.equal(r.reviewAttempts.length,1);
 } finally {await f.bindings.dispose();}
});

test('malformed reviewer retries once on exactly the same route without rerunning workers', async () => {
 const f=runnerFixture({ reviewerFailure: n=>n===1?malformed:null, reviewResult:clean });
 try {
  const j=f.store.create(jobConfig(f.root));
  const r=await f.runner.run(j.id,f.parent,new AbortController().signal).result;
  assert.equal(r.status,'needs_validation',r.reviewError);
  const reviews=f.calls.filter(c=>c.label.includes(':reviewer:'));
  assert.equal(reviews.length,2);
  assert.deepEqual(reviews[0].agentOptions,reviews[1].agentOptions);
  assert.deepEqual(reviews[0].toolFilter,reviews[1].toolFilter);
  assert.equal(f.calls.filter(c=>c.label.includes(':worker:')).length,2);
  assert.deepEqual(r.reviewAttempts.map(a=>a.status),['error','completed']);
  assert.equal(r.reviewAttempts[0].code,'MALFORMED_RESPONSE');
  assert.ok(r.events.some(e=>e.stage==='review-retry'));
  assert.equal(r.reviewError,undefined);
 } finally {await f.bindings.dispose();}
});

test('exhausted malformed retries produce review_error and preserve written files', async () => {
 const f=runnerFixture({reviewerFailure:()=>malformed});
 try {
  const j=f.store.create(jobConfig(f.root));
  const r=await f.runner.run(j.id,f.parent,new AbortController().signal).result;
  assert.equal(r.status,'review_error');
  assert.equal(r.reviewAttempts.length,2);
  assert.equal(r.reviewFailure.code,'MALFORMED_RESPONSE');
  assert.equal(r.review,undefined);
  assert.equal(r.rollback,undefined);
  assert.equal(readFileSync(path.join(f.root,'src/a.js'),'utf8'),'export const a = 2;\n');
  assert.match(r.nextAction.note,/复核未产出可用结论/);
 } finally {await f.bindings.dispose();}
});

test('non-protocol reviewer failures do not retry', async () => {
 const f=runnerFixture({reviewerFailure:()=>({code:'AUTH_FAILED',message:'credential unavailable'})});
 try {
  const j=f.store.create(jobConfig(f.root));
  const r=await f.runner.run(j.id,f.parent,new AbortController().signal).result;
  assert.equal(r.status,'review_error');
  assert.equal(r.reviewAttempts.length,1);
 } finally {await f.bindings.dispose();}
});

test('repair implementation success plus final review failure cannot reuse initial issues as final review', async () => {
 const issues={assessment:'issues_found',summary:'fix a',checks:[{id:'a',kind:'static',statement:'a wrong',command:'',expected:'fixed'}]};
 const repair=plan(); repair.tasks=[{...repair.tasks[0], id:'fix',provides:[],consumes:[]}];
 const f=runnerFixture({getPlan:n=>n===1?plan():repair,getReview:()=>issues,reviewerFailure:n=>n>1?malformed:null});
 try {
  const j=f.store.create(jobConfig(f.root));
  const r=await f.runner.run(j.id,f.parent,new AbortController().signal).result;
  assert.equal(r.status,'review_error');
  assert.equal(r.initialReview.assessment,'issues_found');
  assert.equal(r.review,null);
  assert.equal(r.repair.status,'review_error');
  assert.equal(r.repair.implementationStatus,'completed');
  assert.deepEqual(r.reviewAttempts.map(a=>a.phase),['initial','repair-1','repair-1']);
  assert.equal(r.rollback,undefined);
  assert.equal(readFileSync(path.join(f.root,'src/a.js'),'utf8'),'export const fix = 2;\n');
  assert.equal(r.nextAction.checks.length,0,'no stale initial checks as final review');
 } finally {await f.bindings.dispose();}
});

test('safety refusal never retries or downgrades into review_error',async()=>{
 const f=runnerFixture({reviewerFailure:()=>({code:'MALFORMED_RESPONSE',message:'编排任务权限拒绝'})});
 try {
  const j=f.store.create(jobConfig(f.root));
  const r=await f.runner.run(j.id,f.parent,new AbortController().signal).result;
  assert.equal(r.status,'failed');
  assert.equal(r.reviewAttempts.length,1);
 } finally {await f.bindings.dispose();}
});
