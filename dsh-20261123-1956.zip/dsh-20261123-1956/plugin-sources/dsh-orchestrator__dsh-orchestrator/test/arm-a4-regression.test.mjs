import test from 'node:test';
import assert from 'node:assert/strict';
import path from 'node:path';
import { mkdirSync, rmSync, readFileSync, writeFileSync, symlinkSync, existsSync } from 'node:fs';
import { fixture, jobConfig, plan, runnerFixture } from './harness.mjs';
import { validatePlan } from '../src/policy.js';
import { filePolicy, plannerPrompt, workerPrompt, reviewerPrompt } from '../src/prompts.js';
import { inspectProject } from '../src/preflight.js';
import { toolSpecs } from '../src/index.js';
import { page } from '../src/ui.js';

const blocked = () => ({ status: 'blocked', tasks: [], acceptance: [], blockers: ['已读源码缺少任务所需接口；需要提供确切版本后才能安全修改。'] });
const removeFixtureSources = f => {
  // fixture() creates these two exact files; never operate on a user project.
  for (const name of ['a.js', 'b.js']) rmSync(path.join(f.root, 'src', name));
};

test('arm-a4: protected override false is not a global implementation prohibition', async () => {
  const f = runnerFixture();
  try {
    const job = f.store.create(jobConfig(f.root, { task: '增强现有主体游动，记录本次模型调用费用', protectedFiles: [], allowProtected: false }));
    const report = await f.runner.run(job.id, f.parent, new AbortController().signal).result;
    assert.equal(report.status, 'needs_validation', report.error);
    assert.equal(report.files.filter(file => file.changed).length, 2);
    for (const call of f.calls) {
      const text = call.prompt[0].text;
      assert.ok(!text.includes('允许修改：false'));
      assert.match(text, /允许覆盖受保护文件（allowProtected）：false/);
      assert.match(text, /清单为空时此开关不产生额外限制/);
      assert.match(text, /planner\/reviewer 角色本身只读/);
      assert.match(text, /构建、后台浏览器.*费用统计由主会话负责/);
      if (call.label.includes(':worker:')) assert.ok(call.toolFilter.allow.includes('edit'));
    }
    assert.match(f.calls[0].prompt[0].text, /不要把要求实现的目标降级成只读方案/);
  } finally { await f.bindings.dispose(); }
});

test('protected override true never overrides allowed ranges or exact file policy', () => {
  const f = fixture(), candidate = plan();
  assert.throws(() => validatePlan(candidate, jobConfig(f.root, { protectedFiles: ['src/a.js'], allowProtected: false })), /受保护文件/);
  assert.equal(validatePlan(candidate, jobConfig(f.root, { protectedFiles: ['src/a.js'], allowProtected: true })).tasks.length, 2);
  assert.throws(() => validatePlan(candidate, jobConfig(f.root, { allowedGlobs: ['src/b.js'], protectedFiles: ['src/a.js'], allowProtected: true })), /允许范围/);
  const duplicate = plan(); duplicate.tasks[1].files = ['src/a.js'];
  assert.throws(() => validatePlan(duplicate, jobConfig(f.root, { allowProtected: true })), /重复分配/);
  for (const flag of [true, false]) assert.match(filePolicy(jobConfig(f.root, { allowProtected: flag })), /不能突破允许路径/);
});

for (const planOnly of [false, true]) test(`empty project stops before model resolution, including planOnly=${planOnly}`, async () => {
  const f = runnerFixture();
  try {
    removeFixtureSources(f);
    for (const directory of ['.git', 'node_modules', 'empty/deeper']) mkdirSync(path.join(f.root, directory), { recursive: true });
    writeFileSync(path.join(f.root, 'node_modules', 'dependency.js'), 'not a project baseline');
    writeFileSync(path.join(f.root, '.git', 'config'), 'not a project baseline');
    let resolves = 0; const original = f.ctx.llm.resolveCallConfig;
    f.ctx.llm.resolveCallConfig = async (...args) => { resolves++; return original(...args); };
    const job = f.store.create(jobConfig(f.root));
    const report = await f.runner.run(job.id, f.parent, new AbortController().signal, undefined, { planOnly }).result;
    assert.equal(report.status, 'blocked'); assert.equal(report.preflight.code, 'project_not_prepared');
    assert.equal(resolves, 0); assert.equal(f.calls.length, 0); assert.equal(report.children.length, 0);
    assert.equal(report.snapshot, undefined); assert.equal(report.plan, undefined);
    assert.match(report.error, /先确认并准备用户指定蓝本/);
    assert.equal(f.store.runs(job.id)[0].status, 'blocked');
    assert.equal(f.store.status(job.id).status, 'blocked');
    // A new task can proceed once the caller has explicitly prepared a baseline.
    writeFileSync(path.join(f.root, 'README.md'), 'existing root-layout baseline');
    const next = f.store.create(jobConfig(f.root));
    const ready = await f.runner.run(next.id, f.parent, new AbortController().signal, undefined, { planOnly: true }).result;
    assert.equal(ready.status, 'planned', ready.error);
    assert.equal(ready.snapshot, undefined);
    assert.equal(existsSync(path.join(f.root, 'src/a.js')), false);
  } finally { await f.bindings.dispose(); }
});

test('project presence check does not follow junctions, mistake limits for empty, or infer glob matches', () => {
  const f = fixture(); removeFixtureSources(f);
  const outside = path.join(f.dir, 'outside'); mkdirSync(outside); writeFileSync(path.join(outside, 'source.js'), 'outside');
  symlinkSync(outside, path.join(f.root, 'linked'), process.platform === 'win32' ? 'junction' : 'dir');
  assert.equal(inspectProject(f.root).code, 'project_not_prepared');
  mkdirSync(path.join(f.root, 'empty/deeper'), { recursive: true });
  assert.equal(inspectProject(f.root, { maxDepth: 0 }).code, 'project_scan_limit');
  assert.equal(inspectProject(f.root, { maxEntries: 0 }).code, 'project_scan_limit');
  writeFileSync(path.join(f.root, 'index.html'), '<main>root layout</main>');
  assert.equal(inspectProject(f.root).status, 'ready');
  assert.equal(validatePlan(plan(), jobConfig(f.root)).status, 'ready'); // New src files are legitimate assignments.
  const controller = new AbortController(); controller.abort(new Error('cancel presence scan'));
  assert.throws(() => inspectProject(f.root, { signal: controller.signal }), /cancel presence scan/);
});

for (const planOnly of [false, true]) test(`explicit blocked plan has no workers, retries or snapshots, planOnly=${planOnly}`, async () => {
  const f = runnerFixture({ getPlan: blocked });
  try {
    const before = readFileSync(path.join(f.root, 'src/a.js'), 'utf8');
    const job = f.store.create(jobConfig(f.root, { maxPlanRetries: 2 }));
    const report = await f.runner.run(job.id, f.parent, new AbortController().signal, undefined, { planOnly }).result;
    assert.equal(report.status, 'blocked'); assert.equal(report.planAttempts, 1);
    assert.equal(f.calls.length, 1); assert.equal(report.snapshot, undefined); assert.equal(report.review, undefined);
    assert.deepEqual(report.blockers, blocked().blockers); assert.match(report.error, /确切版本/);
    assert.equal(readFileSync(path.join(f.root, 'src/a.js'), 'utf8'), before);
  } finally { await f.bindings.dispose(); }
});

test('directory scanning stops incremental reads at the budget and always closes its handle', () => {
  const f = fixture(); let reads = 0, closed = 0;
  const openDirectory = () => ({
    readSync() { reads++; if (reads > 4) throw new Error('unbounded enumeration'); return { name: `empty-${reads}`, isSymbolicLink: () => false, isFile: () => false, isDirectory: () => true }; },
    closeSync() { closed++; },
  });
  assert.equal(inspectProject(f.root, { maxEntries: 3, openDirectory }).code, 'project_scan_limit');
  assert.equal(reads, 4); assert.equal(closed, 1);
  let readyClosed = 0;
  const ready = inspectProject(f.root, { openDirectory: () => ({ readSync: () => ({ name: 'source.js', isSymbolicLink: () => false, isFile: () => true }), closeSync() { readyClosed++; } }) });
  assert.equal(ready.status, 'ready'); assert.equal(readyClosed, 1);
});

test('malformed plan states cannot fake blocked or silently downgrade to a read-only outcome', () => {
  const f = fixture(), job = jobConfig(f.root);
  for (const status of [undefined, 'read-only', 'proposal-only', 'analysis']) {
    const candidate = plan(); candidate.status = status;
    assert.throws(() => validatePlan(candidate, job), /status=ready 或 blocked/);
  }
  const withTasks = blocked(); withTasks.tasks = plan().tasks;
  assert.throws(() => validatePlan(withTasks, job), /受阻计划/);
  assert.throws(() => validatePlan({ ...blocked(), blockers: [] }, job), /受阻计划/);
  assert.throws(() => validatePlan({ ...blocked(), blockers: [' '] }, job), /blockers/);
  assert.throws(() => validatePlan({ ...plan(), blockers: ['not ready'] }, job), /可实施计划/);
  assert.throws(() => validatePlan({ ...plan(), tasks: [] }, job), /任务数/);
});

test('bad disposition is retried with its rejection reason before any worker starts', async () => {
  const f = runnerFixture({ getPlan(attempt) { const candidate = plan(); if (attempt === 1) candidate.status = 'read-only'; return candidate; } });
  try {
    const job = f.store.create(jobConfig(f.root));
    const report = await f.runner.run(job.id, f.parent, new AbortController().signal, undefined, { planOnly: true }).result;
    assert.equal(report.status, 'planned'); assert.equal(report.planAttempts, 2);
    assert.equal(f.calls.length, 2); assert.match(f.calls[1].prompt[0].text, /上次计划或请求被拒原因：计划须明确/);
  } finally { await f.bindings.dispose(); }
});

test('alias guidance keeps concrete interface/asset/version mismatch and unperformed verification distinct', () => {
  const f = fixture(), job = jobConfig(f.root);
  for (const prompt of [plannerPrompt(job), workerPrompt(job, plan(), plan().tasks[0]), reviewerPrompt(job, plan(), [], [])]) {
    assert.match(prompt, /仅名称\/物种\/术语不同，不自动等于资产版本不符/);
    assert.match(prompt, /真实接口、版本、基线不符，则仍应停止/);
    assert.match(prompt, /未执行的验证应列为主会话待办/);
    assert.match(prompt, /必需.*安全实施确实不可能/);
  }
  assert.match(reviewerPrompt(job, plan(), [], []), /不局限于 planner 验收清单/);
  assert.match(page(), /不会把整个任务设成只读/);
  assert.match(page(), /空目录会在模型调用前停止/);
});

test('pre-aborted run never starts a child and releases project lock', async () => {
  const f = runnerFixture();
  try {
    const controller = new AbortController(); controller.abort(new Error('cancelled before start'));
    const job = f.store.create(jobConfig(f.root));
    const report = await f.runner.run(job.id, f.parent, controller.signal).result;
    assert.equal(report.status, 'cancelled'); assert.equal(f.calls.length, 0);
    const next = f.store.create(jobConfig(f.root));
    assert.equal((await f.runner.run(next.id, f.parent, new AbortController().signal, undefined, { planOnly: true }).result).status, 'planned');
  } finally { await f.bindings.dispose(); }
});

test('real worker mismatch still fails and cancels siblings without reviewer or rollback', async () => {
  const f = runnerFixture({ workerResult(task) { return { status: 'mismatch', summary: `observed incompatible API in src/${task}.js; expected a number export`, changedFiles: [] }; } });
  try {
    const job = f.store.create(jobConfig(f.root));
    const report = await f.runner.run(job.id, f.parent, new AbortController().signal).result;
    assert.equal(report.status, 'failed'); assert.match(report.error, /mismatch.*incompatible API/);
    assert.equal(report.children.some(child => child.role === 'reviewer'), false);
    assert.ok(report.snapshot); assert.ok(report.files.every(file => !file.changed));
    assert.equal(readFileSync(path.join(f.root, 'src/a.js'), 'utf8'), 'export const a = 1;\n');
  } finally { await f.bindings.dispose(); }
});

test('all unchanged worker completions remain failure rather than a fake implementation', async () => {
  const f = runnerFixture({ workerResult() { return { status: 'completed', summary: 'proposal only; no edits', changedFiles: [] }; } });
  try {
    const job = f.store.create(jobConfig(f.root));
    const report = await f.runner.run(job.id, f.parent, new AbortController().signal).result;
    assert.equal(report.status, 'failed'); assert.match(report.error, /没有实际变化/);
    assert.equal(report.review, undefined);
  } finally { await f.bindings.dispose(); }
});

test('background wrapper preserves blocked explanation without reporting completed', async () => {
  const f = runnerFixture(); removeFixtureSources(f);
  try {
    const job = f.store.create(jobConfig(f.root)); let outcome;
    f.ctx.jobs = { start(spec) { const activity = spec.run({ updateProgress() {}, append() {} }); outcome = activity.done; return 'fixture-background-job'; } };
    const spec = toolSpecs(f.ctx, f.store, f.runner, () => null).find(tool => tool.name === 'orchestrate_run');
    const started = await spec.execute({ task_id: job.id, run_in_background: true }, { agent: f.parent });
    assert.equal(started.jobId, 'fixture-background-job');
    const result = await outcome;
    assert.equal(result.status, 'failed'); assert.match(result.detail, /项目根中未发现/);
    assert.equal(JSON.parse(result.result).status, 'blocked'); assert.equal(f.calls.length, 0);
  } finally { await f.bindings.dispose(); }
});
