import test from 'node:test';
import assert from 'node:assert/strict';
import { createServer } from 'node:http';
import { once } from 'node:events';
import path from 'node:path';
import { WORKER_SCHEMA } from '../src/policy.js';
import { modelEntry, validateModelRoute } from '../src/models.js';

// Real installed adapter + real protocol serializers. Only the loopback HTTP endpoint is simulated.
// No user configuration, credentials, external API, browser, or installed packages are changed.
test('installed pi-ai and native DeepSeek adapters preserve tools and per-protocol reasoning mappings', { timeout: 20000 }, async t => {
  if (!process.env.DSH_APP_ROOT) return t.skip('Set DSH_APP_ROOT to test the installed adapter against local simulated endpoints');
  const { createRequire } = await import('node:module'); const { pathToFileURL } = await import('node:url');
  const installed = createRequire(path.join(process.env.DSH_APP_ROOT, 'package.json'));
  const { apply } = await import(pathToFileURL(installed.resolve('@deepseek-ai/dsh-llm-pi-ai')));
  const { createUserMessage } = await import(pathToFileURL(installed.resolve('@deepseek-ai/dsh-llm')));
  const result = { status: 'completed', summary: 'local protocol fixture', changedFiles: ['src/a.js'] };
  const args = JSON.stringify(result), received = [];
  const server = createServer(async (req, res) => {
    try {
      let raw = ''; for await (const chunk of req) raw += chunk;
      const body = JSON.parse(raw); received.push({ url: req.url, body });
      res.writeHead(200, { 'content-type': 'text/event-stream', 'cache-control': 'no-cache', connection: 'close' });
      const event = (name, data) => res.write(`event: ${name}\ndata: ${JSON.stringify(data)}\n\n`);
      if (req.url.startsWith('/claude') || req.url.startsWith('/native-deepseek')) {
        event('message_start', { type: 'message_start', message: { id: 'msg_local', type: 'message', role: 'assistant', model: body.model, content: [], stop_reason: null, stop_sequence: null, usage: { input_tokens: 8, output_tokens: 0 } } });
        event('content_block_start', { type: 'content_block_start', index: 0, content_block: { type: 'tool_use', id: 'call_local', name: 'structured_output', input: {} } });
        event('content_block_delta', { type: 'content_block_delta', index: 0, delta: { type: 'input_json_delta', partial_json: args } });
        event('content_block_stop', { type: 'content_block_stop', index: 0 });
        event('message_delta', { type: 'message_delta', delta: { stop_reason: 'tool_use', stop_sequence: null }, usage: { output_tokens: 20 } });
        event('message_stop', { type: 'message_stop' });
      } else if (req.url.startsWith('/gpt')) {
        const item = { type: 'function_call', id: 'fc_local', call_id: 'call_local', name: 'structured_output', arguments: args, status: 'completed' };
        const response = { id: 'resp_local', object: 'response', created_at: 1, model: body.model, status: 'in_progress', output: [] };
        event('response.created', { type: 'response.created', sequence_number: 0, response });
        event('response.output_item.added', { type: 'response.output_item.added', sequence_number: 1, output_index: 0, item: { ...item, arguments: '', status: 'in_progress' } });
        event('response.function_call_arguments.delta', { type: 'response.function_call_arguments.delta', sequence_number: 2, item_id: item.id, output_index: 0, delta: args });
        event('response.function_call_arguments.done', { type: 'response.function_call_arguments.done', sequence_number: 3, item_id: item.id, output_index: 0, arguments: args });
        event('response.output_item.done', { type: 'response.output_item.done', sequence_number: 4, output_index: 0, item });
        event('response.completed', { type: 'response.completed', sequence_number: 5, response: { ...response, status: 'completed', output: [item], usage: { input_tokens: 8, output_tokens: 20, total_tokens: 28, input_tokens_details: { cached_tokens: 0 }, output_tokens_details: { reasoning_tokens: 0 } } } });
      } else {
        const chunk = (delta, finish_reason = null) => res.write('data: ' + JSON.stringify({ id: 'chat_local', object: 'chat.completion.chunk', created: 1, model: body.model, choices: [{ index: 0, delta, finish_reason }] }) + '\n\n');
        chunk({ role: 'assistant', tool_calls: [{ index: 0, id: 'call_local', type: 'function', function: { name: 'structured_output', arguments: '' } }] });
        chunk({ tool_calls: [{ index: 0, function: { arguments: args } }] }); chunk({}, 'tool_calls'); res.write('data: [DONE]\n\n');
      }
      res.end();
    } catch (error) { res.destroy(error); }
  });
  server.listen(0, '127.0.0.1'); await once(server, 'listening');
  const origin = `http://127.0.0.1:${server.address().port}`;
  const definitions = [
    { provider: 'local-claude', prefix: 'claude', api: 'anthropic-messages', model: 'claude-local', efforts: { low: 'low', high: 'high' } },
    { provider: 'local-deepseek', prefix: 'deepseek', api: 'openai-completions', model: 'deepseek-local', efforts: false },
    { provider: 'local-qwen', prefix: 'qwen', api: 'openai-completions', model: 'qwen-local', efforts: false },
    { provider: 'local-gpt', prefix: 'gpt', api: 'openai-responses', model: 'gpt-local', efforts: { high: 'high', xhigh: 'xhigh' } },
  ];
  const providers = Object.fromEntries(definitions.map(def => [def.provider, { api: def.api, baseURL: origin + '/' + def.prefix + '/v1', apiKeyEnv: 'ORCHESTRATOR_LOCAL_TEST_KEY', streamIdleTimeoutMs: 5000,
    models: [{ id: def.model, contextWindow: 65536, maxTokens: 2048, reasoningEfforts: def.efforts }] }]));
  let adapter;
  const host = {
    fiber: { entry: { options: { id: 'local-adapter-test' } } }, inject() {}, on() {}, logger: { warn() {}, error() {} },
    get(key) { if (key === 'credentials') return { async resolve() { return { value: 'local-fixture-key' }; }, async readRecord() { return undefined; }, async listRecords() { return []; } }; },
    llm: { registerConfigurableProviders() { return { replace() {} }; }, registerModelDiscovery() {}, registerAdapter(_routes, value) { adapter = value; return { replace() {} }; } },
  };
  try {
    apply(host, { providers: { get: () => providers } }); assert.ok(adapter);
    const ctx = { llm: { resolveModelInfo: (...input) => adapter.resolveModel(...input), async resolveCallConfig(config) {
      const info = await adapter.resolveModel(config.provider, config.model);
      if (config.reasoningEffort && !info.reasoning?.efforts.some(effort => effort.id === config.reasoningEffort)) throw new Error('unsupported exact effort');
      return config;
    } } };
    for (const def of definitions) {
      const entry = await modelEntry(ctx, def.provider, def.model);
      if (def.efforts === false) assert.deepEqual(entry.efforts, []);
      else assert.ok(entry.efforts.some(effort => effort.id === 'high'));
      await assert.rejects(validateModelRoute(ctx, 'reviewer', { provider: def.provider, model: def.model, effort: 'made-up' }), /unsupported exact effort/);
      await assert.rejects(async () => {
        for await (const _chunk of adapter.stream({ provider: def.provider, model: def.model, reasoningEffort: 'made-up', messages: [], signal: AbortSignal.timeout(5000) })) {}
      }, /does not support reasoning effort/);
      const chunks = [];
      for await (const chunk of adapter.stream({ provider: def.provider, model: def.model, ...(def.efforts === false ? {} : { reasoningEffort: 'high' }),
        messages: [createUserMessage({ source: { kind: 'user' }, content: [{ type: 'text', text: 'Return the local structured fixture.' }] })],
        tools: [{ name: 'structured_output', description: 'Return the final structured result', parameters: WORKER_SCHEMA }],
        signal: AbortSignal.timeout(5000),
      })) chunks.push(chunk);
      const tool = chunks.find(chunk => chunk.type === 'block-end' && chunk.block.type === 'tool-call' && chunk.block.name === 'structured_output');
      assert.ok(tool, JSON.stringify(chunks));
      assert.deepEqual(JSON.parse(tool.block.arguments), result);
      assert.ok(!chunks.some(chunk => chunk.type === 'finish' && chunk.reason.kind === 'error'), JSON.stringify(chunks));
    }
    assert.equal(received.length, 4);
    assert.equal(received[0].body.thinking?.type, 'enabled');
    assert.equal(received[3].body.reasoning?.effort, 'high');
    for (const request of [received[1], received[2]]) {
      assert.equal('thinking' in request.body, false); assert.equal('reasoning_effort' in request.body, false);
    }
    for (const [index, request] of received.entries()) {
      assert.equal(request.body.model, definitions[index].model);
      assert.equal('response_format' in request.body, false);
      const tool = request.body.tools[0];
      assert.equal(tool.name || tool.function?.name, 'structured_output');
      const parameters = tool.input_schema || tool.parameters || tool.function?.parameters;
      assert.deepEqual(parameters.properties, WORKER_SCHEMA.properties);
      assert.deepEqual(parameters.required, WORKER_SCHEMA.required);
      assert.equal(parameters.type, 'object');
      // Some wire protocols omit strict schema hints. The scoped host tool still validates the authoritative schema.
      assert.ok(parameters.additionalProperties === undefined || parameters.additionalProperties === false);
    }
    const { DeepSeekAdapter, resolveAdapterOptions } = await import(pathToFileURL(installed.resolve('@deepseek-ai/dsh-llm-deepseek')));
    const connection = resolveAdapterOptions({ baseURL: origin + '/native-deepseek', streamIdleTimeoutMs: 5000,
      models: [{ id: 'deepseek-native-local', contextWindow: 65536, maxTokens: 2048 }] });
    const deepseek = new DeepSeekAdapter({ options: () => connection, resolveFiles: () => ({}),
      resolveAuth: async () => ({ headers: { authorization: 'Bearer local-fixture-key' } }), resolveUserId: () => 'local-adapter-fixture',
      prepareExtensions: async () => ({ fields: {}, async accept() {} }) });
    const info = await deepseek.resolveModel('deepseek-official-local', 'deepseek-native-local');
    assert.deepEqual(info.reasoning.efforts.map(effort => effort.id), ['off', 'low', 'high', 'max']);
    for (const effort of ['off', 'low', 'high', 'max']) {
      const chunks = [];
      for await (const chunk of deepseek.stream({ provider: 'deepseek-official-local', model: 'deepseek-native-local', reasoningEffort: effort,
        messages: [createUserMessage({ source: { kind: 'user' }, content: [{ type: 'text', text: 'Return the local fixture.' }] })],
        tools: [{ name: 'structured_output', description: 'Return the final result', parameters: WORKER_SCHEMA }], signal: AbortSignal.timeout(5000) })) chunks.push(chunk);
      const tool = chunks.find(chunk => chunk.type === 'block-end' && chunk.block.type === 'tool-call');
      assert.ok(tool, JSON.stringify(chunks)); assert.deepEqual(JSON.parse(tool.block.arguments), result);
      const body = received.at(-1).body;
      assert.equal(body.thinking.type, effort === 'off' ? 'disabled' : 'enabled');
      assert.equal(body.output_config?.effort, effort === 'off' ? undefined : effort);
      assert.deepEqual(body.tools[0].input_schema, WORKER_SCHEMA);
      assert.equal('reasoning_effort' in body, false);
    }
    await assert.rejects(async () => {
      for await (const _chunk of deepseek.stream({ provider: 'deepseek-official-local', model: 'deepseek-native-local', reasoningEffort: 'xhigh', messages: [], signal: AbortSignal.timeout(5000) })) {}
    }, /does not support reasoning effort/);
    assert.equal(received.length, 8);
  } finally { server.close(); server.closeAllConnections(); await once(server, 'close'); }
});
