import test from 'node:test';
import assert from 'node:assert/strict';
import path from 'node:path';
import { readFileSync } from 'node:fs';
import { runnerFixture, jobConfig } from './harness.mjs';
import { toolSpecs } from '../src/index.js';

function failingPlanner(options = {}) {
  const f = runnerFixture();
  const start = f.ctx.subagents.start;
  f.ctx.subagents.start = async (...args) => {
    if (options.startError) throw new Error(options.startError);
    const run = await start(...args);
    run.localAgent.session.snapshotEvents = () => options.events || [];
    return { ...run, result: Promise.resolve(options.result || { stopReason: 'error', output: [] }) };
  };
  return f;
}

test('upstream planner failure preserves terminal cause and never consumes a plan retry', async () => {
  const message = '503 No available accounts: no available accounts';
  const f = failingPlanner({ events: [
    { type: 'llm/retry', data: { failure: { code: 'TIMEOUT', message: 'old timeout' } } },
    { type: 'turn/end', data: { reason: { kind: 'error', error: { code: 'SERVER', message } } } },
  ] });
  try {
    const config = jobConfig(f.root, { maxPlanRetries: 2 });
    const job = f.store.create(config);
    const report = await f.runner.run(job.id, f.parent, new AbortController().signal).result;
    assert.equal(report.status, 'failed');
    assert.equal(report.implementationVersion, JSON.parse(readFileSync(new URL('../package.json', import.meta.url), 'utf8')).version);
    assert.equal(report.children.length, 1);
    assert.equal(f.calls.length, 1);
    assert.match(report.error, /503 No available accounts/);
    assert.equal(report.children[0].diagnostic.code, 'SERVER');
    assert.equal(report.children[0].diagnostic.source, 'session');
    assert.equal(report.children[0].status, 'failed');
    assert.ok(report.children[0].endedAt);
    assert.equal(report.snapshot, undefined);
    assert.equal(readFileSync(path.join(f.root, 'src/a.js'), 'utf8'), 'export const a = 1;\n');
    assert.deepEqual(f.store.get(job.id).planner, config.planner);
    assert.deepEqual(f.store.get(job.id).allowedGlobs, config.allowedGlobs);
    assert.ok(report.events.some(event => event.stage === 'failed'));
  } finally { await f.bindings.dispose(); }
});

test('native result diagnostic takes precedence and credentials are removed from persisted errors', async () => {
  const f = failingPlanner({ result: { stopReason: 'error', diagnostic: { code: 'SERVER', message: '503 key sk-abcdefgh123456789 Authorization: Bearer abc.def.ghi' } } });
  try {
    const job = f.store.create(jobConfig(f.root));
    const report = await f.runner.run(job.id, f.parent, new AbortController().signal).result;
    assert.equal(report.children.length, 1);
    assert.match(report.error, /503/);
    assert.equal(report.children[0].diagnostic.source, 'result');
    const saved = JSON.stringify(f.store.runs(job.id));
    assert.doesNotMatch(saved, /sk-abcdefgh123456789|abc\.def\.ghi/);
  } finally { await f.bindings.dispose(); }
});

test('child creation failures are recorded and do not trigger model replanning', async () => {
  const f = failingPlanner({ startError: 'connection failed during creation' });
  try {
    const job = f.store.create(jobConfig(f.root));
    const report = await f.runner.run(job.id, f.parent, new AbortController().signal).result;
    assert.equal(report.status, 'failed');
    assert.equal(report.children.length, 1);
    assert.equal(report.children[0].status, 'failed');
    assert.match(report.children[0].error, /connection failed during creation/);
    assert.equal(report.plan, undefined);
  } finally { await f.bindings.dispose(); }
});

test('bound children are persisted as running before the first request finishes', async () => {
  const f = runnerFixture({ delay: 15 });
  let observed;
  try {
    const job = f.store.create(jobConfig(f.root));
    const report = await f.runner.run(job.id, f.parent, new AbortController().signal, stage => {
      if (stage === 'planner') queueMicrotask(() => { observed = f.store.runs(job.id)[0]?.children?.[0]?.status; });
    }, { planOnly: true }).result;
    assert.equal(report.status, 'planned');
    assert.equal(report.children[0].status, 'completed');
    assert.ok(report.children[0].startedAt);
    assert.ok(report.children[0].endedAt);
    assert.equal(observed, 'running');
  } finally { await f.bindings.dispose(); }
});

test('task creation schema explicitly requires an object configuration rather than arbitrary JSON', () => {
  const f = runnerFixture();
  const spec = toolSpecs(f.ctx, f.store, f.runner, () => null).find(tool => tool.name === 'orchestrate_task');
  assert.equal(spec.parameters.config.type, 'object');
  assert.equal(spec.parameters.config.properties.planner.type, 'object');
  assert.equal(spec.parameters.config.properties.worker.type, 'object');
});
