// 打印 repairPrompt 的实际尾部，便于人工复核措辞（不参与 npm test）
import { repairPrompt } from "../src/prompts.js";

const job = {
  projectRoot: "D:/DSH_test_lab2",
  allowedGlobs: ["arm-a11/**"],
  protectedFiles: [],
  allowProtected: false,
  maxWorkers: 3,
  task: "优化鲸鱼动效",
};
const plan = { tasks: [{ id: "swim-motion", files: ["arm-a11/src/koi.js"] }], acceptance: ["构建通过"], status: "ready", blockers: [] };
const p = repairPrompt(
  job,
  plan,
  { "arm-a11/src/koi.js": "d3d13cac" },
  [{ taskId: "swim-motion", status: "completed" }],
  { assessment: "issues_found", summary: "半频回绕跳变", checks: [{ id: "heave-phase-wrap", kind: "static" }] },
);
const i = p.indexOf("交付协议");
console.log(`总长 ${p.length} 字符；交付协议块 ${p.length - i} 字符`);
console.log("====================== 尾部原文 ======================");
console.log(p.slice(i));
