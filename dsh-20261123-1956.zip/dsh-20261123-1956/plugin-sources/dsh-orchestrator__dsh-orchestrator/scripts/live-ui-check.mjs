import assert from 'node:assert/strict';
import { existsSync, writeFileSync, mkdirSync } from 'node:fs';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
const url = new URL(process.env.DSH_ORCHESTRATOR_SETTINGS_URL);
const token = url.searchParams.get('token');
const response = await fetch(new URL('/dsh-orchestrator/settings/api/state', url), { headers: { 'x-settings-token': token } });
assert.equal(response.status, 200, 'Live settings API should respond successfully');
const state = await response.json();
assert.equal(state.compatibility.ready, true);
const planner = state.models.find(model => model.provider === 'worldcode' && model.model === 'gpt-6.1-sol');
const worker = state.models.find(model => model.provider === 'deepseek-official' && model.model === 'deepseek-flash');
assert.ok(planner?.efforts.some(e => e.id === 'max'));
assert.ok(worker?.efforts.some(e => e.id === 'low'));
const { chromium, findChromiumExecutable } = await import(pathToFileURL(process.env.ORCHESTRATOR_PLAYWRIGHT_HELPER));
const executable = await findChromiumExecutable() || ['C:/Program Files/Google/Chrome/Application/chrome.exe', 'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe'].find(existsSync);
mkdirSync('local-validation', { recursive: true });
const browser = await chromium.launchPersistentContext(path.resolve('local-validation/live-headless-profile'), { executablePath: executable, headless: true, viewport: { width: 1280, height: 1100 } });
try {
  const tab = await browser.newPage();
  const errors = [];
  tab.on('pageerror', error => errors.push(error.message));
  await tab.goto(url.href);
  await tab.locator('#fields:not([disabled])').waitFor();
  assert.equal(await tab.inputValue('#plannerEffort'), 'max');
  assert.equal(await tab.inputValue('#workerEffort'), 'low');
  await tab.screenshot({ path: path.resolve('local-validation/live-settings-preview.png'), fullPage: false });
  assert.deepEqual(errors, []);
  const report = { status: 'passed', origin: url.origin, path: url.pathname, compatibility: state.compatibility, modelsAdvertised: state.models.length,
    planner: { provider: planner.provider, model: planner.model, efforts: planner.efforts.map(e => e.id) }, worker: { provider: worker.provider, model: worker.model, efforts: worker.efforts.map(e => e.id) },
    defaultPlannerEffort: state.defaults.planner.effort, defaultWorkerEffort: state.defaults.worker.effort, pageErrors: errors, visibleBrowser: false, modelCompletionsStartedByThisCheck: 0 };
  writeFileSync('local-validation/live-ui-results.json', JSON.stringify(report, null, 2));
  console.log(JSON.stringify(report, null, 2));
} finally { await browser.close(); }
