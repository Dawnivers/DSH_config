import { readFileSync, writeFileSync } from 'node:fs';
import { zstdDecompressSync } from 'node:zlib';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import assert from 'node:assert/strict';
const taskId = process.env.ORCHESTRATOR_NATIVE_TASK_ID || 'b4e8c20d-ed8d-4868-a338-cb342ffb2a40';
const runId = process.env.ORCHESTRATOR_NATIVE_RUN_ID || '5efd1815-35c2-4644-9327-4e533df0432d';
const postRestart = process.env.ORCHESTRATOR_POST_RESTART === '1';
const report = JSON.parse(readFileSync(`../orchestration/plugin-data/jobs/${taskId}/runs/${runId}.json`));
const sessionsRoot = process.env.ORCHESTRATOR_NATIVE_SESSIONS_ROOT;
const evidence = [];
for (const child of report.children) {
  const file = path.join(sessionsRoot, child.childId, 'session.v4.jsonl.zstd');
  const compressed = readFileSync(file);
  let offset = 0;
  const chunks = [];
  while (offset < compressed.length) {
    const decoded = zstdDecompressSync(compressed.subarray(offset), { info: true });
    const consumed = decoded.engine.bytesWritten;
    if (!(consumed > 0)) throw new Error('Zstd decoder did not consume a frame');
    chunks.push(decoded.buffer);
    offset += consumed;
  }
  const records = Buffer.concat(chunks).toString('utf8').trim().split('\n').map(line => JSON.parse(line));
  const found = [];
  function visit(value, location, kind) {
    if (!value || typeof value !== 'object') return;
    const ownKind = value.kind || value.type || kind;
    if (value.provider && value.model && value.reasoningEffort) found.push({ location, kind: ownKind, provider: value.provider, model: value.model, reasoningEffort: value.reasoningEffort });
    for (const [key, item] of Object.entries(value)) if (item && typeof item === 'object') visit(item, location + '.' + key, ownKind);
  }
  records.forEach((record, index) => visit(record, String(index), undefined));
  const requests = found.filter(value => String(value.kind).includes('request'));
  if (!requests.length) throw new Error('No request route found: ' + JSON.stringify({ session: child.childId, firstRecordKeys: records.slice(0, 3).map(Object.keys), found }));
  for (const route of requests) {
    assert.equal(route.provider, child.requested.provider);
    assert.equal(route.model, child.requested.model);
    assert.equal(route.reasoningEffort, child.requested.reasoningEffort);
  }
  evidence.push({ role: child.role, taskId: child.taskId, sessionId: child.childId, boundBeforeRequest: child.boundBeforeRequest, actualRequestRoutes: requests });
}
assert.equal(report.status, 'needs_validation');
if (postRestart) {
  const worker = report.children.find(child => child.role === 'worker');
  assert.ok(path.isAbsolute(worker.output.changedFiles[0]));
  assert.deepEqual(report.workers[0].changedFiles, ['src/speed.js']);
  assert.equal(report.review.assessment, 'ready_for_validation');
  const snapshotFile = report.snapshot.files[0];
  const original = readFileSync(path.join(report.snapshot.directory, snapshotFile.backup));
  const current = readFileSync(path.join(report.projectRoot, snapshotFile.file));
  const oldText = 'clampSpeed expects a finite number (post-restart check)';
  const newText = 'clampSpeed expects a finite number (verified after restart)';
  assert.equal(original.toString('utf8').split(oldText).length, 2);
  assert.deepEqual(current, Buffer.from(original.toString('utf8').replace(oldText, newText)));
  const { clampSpeed } = await import(pathToFileURL(path.join(report.projectRoot, 'src/speed.js')));
  for (const invalid of [NaN, Infinity, -Infinity, '2', null, undefined]) assert.throws(() => clampSpeed(invalid), { name: 'TypeError', message: newText });
}
const result = { status: 'passed', scope: postRestart ? 'Post-restart native absolute changedFiles normalization, persisted role routes and behavioral tests' : 'Native planner + two workers + reviewer, persisted request routes and independently run behavioral tests', taskId: report.jobId, runId: report.runId,
  regressionTests: { passed: 29, failed: 0 }, behavioralTests: { passed: 3, failed: 0 }, sessions: evidence,
  ...(postRestart ? { absolutePathNormalizationVerified: true, exactMessageOnlyChangeVerified: true, reviewerAssessment: report.review.assessment } : {}),
  deploymentNote: postRestart ? 'The restarted DSH process accepted an actual worker absolute changedFiles report and normalized it to the exact owned relative path. Final normalization patch verified natively.' : 'This successful run used the initially loaded module graph with explicit relative changedFiles. The final absolute-path normalization fix is covered by regression; restart DSH to load it before another native run.' };
writeFileSync(postRestart ? 'local-validation/post-restart-results.json' : 'local-validation/native-results.json', JSON.stringify(result, null, 2));
console.log(JSON.stringify(result, null, 2));
