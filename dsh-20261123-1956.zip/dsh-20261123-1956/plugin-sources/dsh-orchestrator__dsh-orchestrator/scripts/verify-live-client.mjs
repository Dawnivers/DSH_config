import assert from 'node:assert/strict';
import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
const origin = process.env.DSH_ORCHESTRATOR_ORIGIN || 'http://127.0.0.1:29972';
const response = await fetch(origin + '/plugins/events', { signal: AbortSignal.timeout(10000) });
assert.equal(response.status, 200, 'Current DSH must expose its active client graph');
const reader = response.body.getReader();
const decoder = new TextDecoder();
let text = '', graph;
try {
  while (!graph) {
    const part = await reader.read();
    if (part.done) break;
    text += decoder.decode(part.value, { stream: true });
    for (const line of text.split('\n')) {
      if (!line.startsWith('data:')) continue;
      try { const event = JSON.parse(line.slice(5)); if (event.type === 'graph') graph = event.graph; } catch { /* incomplete SSE line */ }
    }
  }
} finally { await reader.cancel(); }
assert.ok(graph);
const row = graph.entries.find(entry => entry.id === 'dsh-orchestrator');
assert.ok(row, 'Plugin missing from current client module graph');
const bundleResponse = await fetch(new URL(row.url, origin));
assert.equal(bundleResponse.status, 200);
const bundle = await bundleResponse.text();
const source = readFileSync('lib/client.js', 'utf8');
assert.ok(bundle.includes(source.trim()), 'Current DSH still serves an older client bundle');
for (const expected of ['conversation.session.header.actions', 'conversation.input.left', 'dsh-orchestrator:start', 'srcDoc']) assert.ok(bundle.includes(expected));
const result = { status: 'passed', origin, pluginId: row.id, revision: row.rev, graphRevision: graph.rev,
  actualServedSourceMatchesBuiltClient: true, backgroundHmrReceiverActive: true, clientSha256: createHash('sha256').update(source).digest('hex'), restartRequiredForThisClientUpdate: false };
writeFileSync('local-validation/live-client-results.json', JSON.stringify(result, null, 2));
console.log(JSON.stringify(result, null, 2));
