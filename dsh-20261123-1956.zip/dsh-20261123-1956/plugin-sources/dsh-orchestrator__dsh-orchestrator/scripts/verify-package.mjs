import { readFileSync, readdirSync, statSync, mkdirSync, mkdtempSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { spawnSync } from 'node:child_process';
import path from 'node:path';
import assert from 'node:assert/strict';
const manifest = JSON.parse(readFileSync('package.json', 'utf8'));
const archive = path.resolve(`dist/dsh-orchestrator-${manifest.version}.tgz`);
mkdirSync('local-validation', { recursive: true });
const directory = mkdtempSync(path.resolve('local-validation/package-extract-'));
mkdirSync(directory, { recursive: true });
const extracted = spawnSync('tar.exe', ['-xzf', archive, '-C', directory], { stdio: 'inherit' });
assert.equal(extracted.status, 0);
const root = path.join(directory, 'package');
const files = [];
function walk(dir) { for (const name of readdirSync(dir)) { const file = path.join(dir, name); if (statSync(file).isDirectory()) walk(file); else files.push(path.relative(root, file).replaceAll('\\', '/')); } }
walk(root);
const expected = new Set(['package.json']);
function sourceFiles(entry) {
  if (statSync(entry).isDirectory()) for (const name of readdirSync(entry)) sourceFiles(path.join(entry, name));
  else expected.add(entry.replaceAll('\\', '/'));
}
for (const entry of manifest.files) sourceFiles(entry);
assert.deepEqual([...files].sort(), [...expected].sort(), 'Archive must contain exactly the declared source files');
for (const file of files) {
  assert.ok(!/(^|\/)(node_modules|test-artifacts|local-validation|\.env)(\/|$)/.test(file));
  assert.ok(readFileSync(path.join(root, file)).equals(readFileSync(file)), 'Archive differs from current source: ' + file);
}
for (const args of [['--test', ...files.filter(file => /^test\/.*\.test\.mjs$/.test(file))], ['scripts/check.mjs'], ['scripts/build-client.mjs', '--check']]) {
  const checked = spawnSync(process.execPath, args, { cwd: root, stdio: 'inherit', env: process.env });
  assert.equal(checked.status, 0, 'Extracted package failed checks');
}
const sha256 = createHash('sha256').update(readFileSync(archive)).digest('hex');
writeFileSync(`dist/SHA256SUMS-${manifest.version}`, sha256 + `  dsh-orchestrator-${manifest.version}.tgz\n`);
const report = { status: 'passed', fileCount: files.length, size: statSync(archive).size, sha256, exactSourceMatch: true,
  regressionTests: 'passed', regressionTestFiles: files.filter(file => /^test\/.*\.test\.mjs$/.test(file)).length, syntaxCheck: 'passed', excludesLocalDataAndCredentials: true,
  workerPathNormalizationPresent: readFileSync(path.join(root, 'src/runner.js'), 'utf8').includes('const changedFiles = result.changedFiles.map') };
assert.equal(report.workerPathNormalizationPresent, true);
writeFileSync(`local-validation/package-results-${manifest.version}.json`, JSON.stringify(report, null, 2));
console.log(JSON.stringify(report, null, 2));
