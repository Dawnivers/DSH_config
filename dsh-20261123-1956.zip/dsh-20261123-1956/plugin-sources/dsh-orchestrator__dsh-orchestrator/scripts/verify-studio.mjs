import fs from 'node:fs';
import path from 'node:path';
import { spawn } from 'node:child_process';
import assert from 'node:assert/strict';
import { serverFixture } from '../test/settings-fixture.mjs';
import { jobConfig } from '../test/harness.mjs';
import { clientFactory } from '../src/client.js';

// Isolated fixture server and separate headless Chrome profile: no real DSH
// browser, desktop input, provider request or model execution is involved.
const dir=path.resolve('test-artifacts/studio-browser');fs.mkdirSync(dir,{recursive:true});
const profile=fs.mkdtempSync(path.join(dir,'headless-profile-'));
const f=await serverFixture();
const chrome=spawn('C:/Program Files/Google/Chrome/Application/chrome.exe',['--headless=new','--disable-gpu','--no-first-run','--no-default-browser-check','--disable-background-networking','--disable-sync','--remote-debugging-port=0','--user-data-dir='+profile,'about:blank'],{stdio:'ignore'});
let socket,owner,id=0;const pending=new Map(),errors=[],network=[];let tests=0,sends=0;
const delay=ms=>new Promise(r=>setTimeout(r,ms));
function send(method,params={}){const seq=++id;return new Promise((resolve,reject)=>{const timer=setTimeout(()=>{pending.delete(seq);reject(Error('CDP timeout '+method))},15000);pending.set(seq,{resolve:r=>{clearTimeout(timer);resolve(r)},reject:e=>{clearTimeout(timer);reject(e)}});socket.send(JSON.stringify({id:seq,method,params}))})}
async function evaluate(expression){const r=await send('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true,userGesture:true});if(r.exceptionDetails)throw Error(JSON.stringify(r.exceptionDetails));return r.result.value}
async function waitFor(expression){for(let i=0;i<120;i++){if(await evaluate(expression))return;await delay(50)}throw Error('condition timed out: '+expression)}
async function check(name,expression){assert.equal(await evaluate(expression),true,name);tests++;console.log('PASS '+name)}
async function snap(name){await evaluate('new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)))');const r=await send('Page.captureScreenshot',{format:'png',captureBeyondViewport:false});fs.writeFileSync(path.join(dir,name+'.png'),Buffer.from(r.data,'base64'))}
try{
 const saved=await f.call('save',jobConfig(f.root,{assertions:['geom.ring.closed'],reviewMode:'on_failure'}));assert.equal(saved.status,200);
 const response=await f.call('bridge/open',{sessionId:'session-visual-test',sessionTitle:'隔离测试 · 无模型调用',workspaceRoot:f.root});const opened=await response.json();assert.equal(response.status,200);
 const client=clientFactory(()=>({createElement(){}}),()=> '');
 owner=client.createDetachedOwner({sessionId:'session-visual-test',bridgeId:opened.bridgeId,ownerToken:opened.ownerToken,ledger:new Map(),request:async(route,input)=>{const r=await f.call(route,input);const data=await r.json();if(!r.ok)throw Error(data.error);return data},send:async(prompt,taskId)=>{sends++;assert.match(prompt,/orchestrate_run/);assert.ok(f.store.get(taskId));}});
 await owner.pollOnce();
 let port;for(let n=0;n<100;n++){const active=path.join(profile,'DevToolsActivePort');if(fs.existsSync(active)){port=fs.readFileSync(active,'utf8').split('\n')[0];break}await delay(100)}if(!port)throw Error('Headless Chrome did not start');
 const targets=await (await fetch('http://127.0.0.1:'+port+'/json/list')).json();const target=targets.find(t=>t.type==='page');
 socket=new WebSocket(target.webSocketDebuggerUrl);await new Promise((resolve,reject)=>{socket.addEventListener('open',resolve,{once:true});socket.addEventListener('error',reject,{once:true})});
 socket.addEventListener('message',event=>{const data=JSON.parse(event.data);if(data.id){const p=pending.get(data.id);if(!p)return;pending.delete(data.id);data.error?p.reject(Error(JSON.stringify(data.error))):p.resolve(data.result)}else if(data.method==='Runtime.exceptionThrown')errors.push(data.params.exceptionDetails);else if(data.method==='Network.requestWillBeSent')network.push(data.params.request.url)});
 await send('Page.enable');await send('Runtime.enable');await send('Network.enable');await send('Emulation.setDeviceMetricsOverride',{width:1440,height:1040,deviceScaleFactor:1,mobile:false});
 await send('Page.navigate',{url:opened.url});
 await waitFor('document.getElementById("fields") && !document.getElementById("fields").disabled');
 await check('A canvas has five real configuration cards and bound session',`document.querySelectorAll('.config-node').length===5 && document.getElementById('sessionTarget').textContent.includes('session-visual-test')`);
 await check('diagnostics start collapsed, not in front of workflow',`!document.querySelector('.runtime-details').open && document.getElementById('configForm').getBoundingClientRect().top<document.querySelector('.runtime-details').getBoundingClientRect().top`);
 await check('parallel slots show capacity without independent model routes',`document.querySelectorAll('.worker-slots>span').length===2`);
 await snap('A-browser-canvas');
 await evaluate(`document.getElementById('node-planner').click()`);await check('model drawer opens against actual fixture catalog',`!document.getElementById('configDrawer').hidden && document.getElementById('plannerModel').options.length>=4`);await snap('B-model-drawer');
 await evaluate(`document.getElementById('drawerClose').click();document.getElementById('node-reviewer').click()`);
 await check('review level starts legacy-compatible standard',`document.getElementById('reviewLevel').value==='standard'`);
 await evaluate(`document.getElementById('reviewLevel').value='exploratory';document.getElementById('reviewLevel').dispatchEvent(new Event('change',{bubbles:true}))`);
 await check('exploration disables review and repair without claiming runtime verification',`document.getElementById('reviewerModel').matches(':disabled') && document.getElementById('maxRepairRounds').disabled && [...document.querySelectorAll('input[name="reviewMode"]')].every(n=>n.disabled) && document.getElementById('policySummary').textContent.includes('运行时待验证') && document.getElementById('repairWire').hidden`);
 await snap('F-exploratory-review');
 await evaluate(`document.getElementById('reviewLevel').value='strict';document.getElementById('reviewLevel').dispatchEvent(new Event('change',{bubbles:true}))`);
 await check('strict forces review and never shows assertion bypass',`!document.getElementById('reviewerModel').matches(':disabled') && !document.getElementById('maxRepairRounds').disabled && document.getElementById('bypassWire').hidden && document.getElementById('policySummary').textContent.includes('严格')`);
 await evaluate(`document.getElementById('reviewLevel').value='exploratory';document.getElementById('reviewLevel').dispatchEvent(new Event('change',{bubbles:true}));document.getElementById('saveDefaults').click()`);
 await waitFor(`!document.getElementById('saveDefaults').disabled`);
 await check('exploration level survives actual scoped draft save',`document.getElementById('reviewLevel').value==='exploratory' && document.getElementById('reviewerModel').matches(':disabled')`);
 const draftState=await (await f.call('state',undefined,{headers:{'x-settings-token':opened.browserToken}})).json();assert.equal(draftState.defaults.reviewLevel,'exploratory');
 await evaluate(`document.getElementById('drawerClose').click();document.getElementById('node-assertions').click()`);
 await check('assertions use real catalog with collapsed packages and groups',`document.querySelectorAll('.assert-pack').length>0 && [...document.querySelectorAll('.assert-pack,.assert-group')].every(n=>!n.open)`);
 await evaluate(`document.querySelector('.assert-pack').open=true;document.querySelector('.assert-group').open=true`);await snap('C-assertion-drawer');
 await evaluate(`document.getElementById('drawerClose').click();document.getElementById('taskScopeCard').click();document.getElementById('task').value='隔离验收：仅创建配置并回传固定指令，不启动模型';document.getElementById('task').dispatchEvent(new Event('input',{bubbles:true}));document.getElementById('drawerDone').click()`);
 await check('task card reflects form values as text',`document.getElementById('scopeTaskSummary').textContent.includes('隔离验收')`);
 await evaluate(`document.getElementById('createJob').click()`);
 await waitFor(`document.getElementById('message').textContent.includes('正在回传')`);
 assert.equal(f.store.list().length,1);assert.equal(f.store.get(f.store.list()[0].id).reviewLevel,'exploratory');await owner.pollOnce();await waitFor(`!document.getElementById('flowPanel').hidden`);
 await check('browser submit acknowledged and live report view opens',`document.getElementById('message').textContent.includes('投递已确认') && document.getElementById('flowTask').textContent.includes('隔离验收')`);
 assert.equal(sends,1);assert.equal(f.store.status(f.store.list()[0].id).status,'queued');
 await evaluate(`document.getElementById('flowConfig').click();document.getElementById('createJob').click()`);assert.equal(f.store.list().length,1);assert.equal(sends,1);tests++;console.log('PASS duplicate submit does not create or deliver again');
 await send('Emulation.setDeviceMetricsOverride',{width:390,height:844,deviceScaleFactor:1,mobile:true});await evaluate(`window.scrollTo(0,0)`);
 await check('mobile body remains within viewport',`document.documentElement.scrollWidth<=390`);await snap('D-mobile-canvas');
 await evaluate(`document.getElementById('node-worker').click()`);await check('mobile drawer fits viewport',`document.getElementById('configDrawer').getBoundingClientRect().width<=390`);await snap('E-mobile-drawer');
 assert.equal(errors.length,0,'no browser runtime errors');assert.equal(network.filter(u=>/^https?:/.test(u)&&!u.startsWith(f.origin+'/')).length,0,'no external network requests');
 const result={tests,passed:tests,runtimeErrors:errors.length,externalRequests:0,modelCalls:0,admissionMessages:sends,fixtureOnly:true,screenshots:['A-browser-canvas','B-model-drawer','C-assertion-drawer','D-mobile-canvas','E-mobile-drawer','F-exploratory-review']};
 fs.writeFileSync(path.join(dir,'validation.json'),JSON.stringify(result,null,2));console.log(JSON.stringify(result,null,2));
}finally{owner?.stop();if(socket?.readyState===WebSocket.OPEN){try{await send('Browser.close')}catch{}socket.close()}if(chrome.exitCode===null)chrome.kill();await f.close()}
