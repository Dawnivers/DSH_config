import { mkdirSync, readFileSync, writeFileSync, existsSync, lstatSync, realpathSync, symlinkSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
const plugin = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const profile = process.env.ORCHESTRATOR_PROFILE_DIR;
const app = process.env.DSH_APP_ROOT;
const data = process.env.DSH_ORCHESTRATOR_LOCAL_DATA;
if (![profile, app, data].every(value => value && path.isAbsolute(value))) throw new Error('Set absolute ORCHESTRATOR_PROFILE_DIR, DSH_APP_ROOT and DSH_ORCHESTRATOR_LOCAL_DATA');
const backup = path.join(plugin, 'local-validation', 'install-' + new Date().toISOString().replaceAll(':', '-'));
mkdirSync(backup, { recursive: true });
const manifestFile = path.join(profile, 'package.json');
const old = readFileSync(manifestFile, 'utf8');
const manifest = JSON.parse(old);
writeFileSync(path.join(backup, 'profile-package.json'), old, { mode: 0o600 });
function link(target, destination) {
  if (existsSync(destination)) {
    if (realpathSync(destination) !== realpathSync(target)) throw new Error(`Existing link points elsewhere: ${destination}`);
    return;
  }
  mkdirSync(path.dirname(destination), { recursive: true });
  symlinkSync(target, destination, process.platform === 'win32' ? 'junction' : 'dir');
}
// 开发链接只用于本机；分发 tgz 通过 DSH 插件管理器解析 peer dependency。
link(path.join(app, 'node_modules', '@deepseek-ai', 'dsh-tools'), path.join(plugin, 'node_modules', '@deepseek-ai', 'dsh-tools'));
link(plugin, path.join(profile, 'node_modules', 'dsh-orchestrator'));
mkdirSync(data, { recursive: true });
const dshHome = path.resolve(profile, '..', '..');
link(data, path.join(dshHome, 'storages', 'orchestrator'));
manifest.dependencies ||= {};
manifest.dependencies['dsh-orchestrator'] = 'link:' + plugin.replaceAll('\\', '/');
manifest.dsh ||= {}; manifest.dsh.profile ||= {}; manifest.dsh.profile.bundles ||= [];
manifest.dsh.profile.bundles = manifest.dsh.profile.bundles.filter(name => name !== 'dsh-fs-claims');
if (!manifest.dsh.profile.bundles.includes('dsh-orchestrator')) manifest.dsh.profile.bundles.push('dsh-orchestrator');
// 让旧插件已加载的 fs wrapper 立即停止全局认领；下次组合刷新时移除整个旧插件。
const claimsFile = path.join(dshHome, 'fs-claims.json');
if (existsSync(claimsFile)) {
  const originalClaims = readFileSync(claimsFile, 'utf8');
  writeFileSync(path.join(backup, 'fs-claims.json'), originalClaims, { mode: 0o600 });
  const claims = JSON.parse(originalClaims);
  claims.enabled = false;
  claims.strictUnbound = false;
  writeFileSync(claimsFile, JSON.stringify(claims, null, 2));
}
writeFileSync(manifestFile, JSON.stringify(manifest, null, 2) + '\n');
const receipt = { package: 'dsh-orchestrator', version: JSON.parse(readFileSync(path.join(plugin, 'package.json'))).version, source: plugin, profile, data, backup,
  oldProfileSha256: createHash('sha256').update(old).digest('hex'), status: 'linked-and-selected', legacyClaimsBundleRemoved: true, requiresRuntimeVerification: true };
writeFileSync(path.join(plugin, 'local-validation', 'install-receipt.json'), JSON.stringify(receipt, null, 2));
console.log(JSON.stringify(receipt, null, 2));
