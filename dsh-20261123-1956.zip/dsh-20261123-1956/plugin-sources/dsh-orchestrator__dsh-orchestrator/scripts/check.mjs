import { readdirSync, readFileSync } from 'node:fs';
import { join } from 'node:path';
import { spawnSync } from 'node:child_process';
import vm from 'node:vm';
function walk(dir) { return readdirSync(dir, { withFileTypes: true }).flatMap(item => item.isDirectory() ? walk(join(dir, item.name)) : /\.(?:m?js)$/.test(item.name) ? [join(dir, item.name)] : []); }
for (const file of [...walk('src'), ...walk('lib'), ...walk('scripts'), ...walk('test')]) {
  const result = spawnSync(process.execPath, ['--check', file], { stdio: 'inherit' });
  if (result.status !== 0) process.exit(result.status || 1);
}
const { page } = await import('../src/ui.js');
const html = page();
for (const [, source] of html.matchAll(/<script\b[^>]*>([\s\S]*?)<\/script>/gi)) new vm.Script(source);
JSON.parse(readFileSync('package.json', 'utf8'));
JSON.parse(readFileSync('dsh.plugin.json', 'utf8'));
console.log('Syntax and embedded page scripts OK');
