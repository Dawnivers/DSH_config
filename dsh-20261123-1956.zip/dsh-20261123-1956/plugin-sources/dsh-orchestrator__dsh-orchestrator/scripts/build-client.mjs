import { readFileSync, writeFileSync } from 'node:fs';
import { buildClient } from '../src/bundle.js';
const destination = new URL('../lib/client.js', import.meta.url);
if (process.argv.includes('--check')) {
  if (readFileSync(destination, 'utf8') !== buildClient()) throw new Error('Client bundle is stale: run npm run build');
} else {
  writeFileSync(destination, buildClient());
  console.log('Built dsh-orchestrator client bundle');
}
