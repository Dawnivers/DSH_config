/**
 * 手工还原一次编排运行的快照（自动回滚只覆盖 failed / cancelled）。
 *
 * 用途：review_failed 或 needs_validation 时改动留在盘上，如果决定不要了，
 * 用这个脚本把计划文件退回运行前的字节，而不是逐个手工改回。
 *
 *   node scripts/restore.mjs <jobId>                  # 该任务唯一有快照的运行
 *   node scripts/restore.mjs <jobId> <runId>          # 指定运行
 *   node scripts/restore.mjs <jobId> <runId> --dry-run # 只看会做什么
 *
 * 还原规则与自动回滚完全一致：哈希守卫（没改过的不写）、备份自证（sha256 校验）、
 * 运行期间新建的文件会被删除。退出码 1 表示有文件失败。
 */
import { existsSync, readdirSync } from 'node:fs';
import path from 'node:path';
import { makeStore } from '../src/store.js';

const argv = process.argv.slice(2);
const flags = new Set(argv.filter(item => item.startsWith('--')));
const positional = argv.filter(item => !item.startsWith('--'));
const [jobId, runIdArg] = positional;

if (!jobId) {
  console.error('用法: node scripts/restore.mjs <jobId> [runId] [--dry-run]');
  process.exit(2);
}
if (!/^[0-9a-f-]{36}$/.test(jobId)) {
  console.error(`任务 ID 无效：${jobId}（需要 36 位十六进制 UUID）`);
  process.exit(2);
}

const store = makeStore();
let runs;
try {
  runs = store.runs(jobId);
} catch (error) {
  console.error(`读不到任务 ${jobId} 的运行记录：${error.message}`);
  process.exit(2);
}

// 以磁盘上的快照为准发现可还原运行：报告字段缺失或被改写都不影响可用性。
const snapshotsDir = path.join(store.directory(jobId), 'snapshots');
const available = existsSync(snapshotsDir)
  ? readdirSync(snapshotsDir).filter(name => existsSync(path.join(snapshotsDir, name, 'manifest.json')))
  : [];
const statusOf = runId => runs.find(run => run.runId === runId)?.status ?? 'unknown';
if (!available.length) {
  console.error(`任务 ${jobId} 没有可用快照（运行 ${runs.length} 次）。未写入的运行不会有快照。`);
  process.exit(2);
}

let target = null;
if (runIdArg) {
  if (!available.includes(runIdArg)) {
    console.error(`运行 ${runIdArg} 没有快照。可选：${available.join(', ')}`);
    process.exit(2);
  }
  target = runIdArg;
} else if (available.length === 1) {
  [target] = available;
} else {
  console.error('该任务有多次带快照的运行，请指定 runId：');
  for (const runId of available) console.error(`  ${runId}  ${statusOf(runId)}`);
  process.exit(2);
}

const apply = !flags.has('--dry-run');
console.log(`job ${jobId}  run ${target}  status ${statusOf(target)}  ${apply ? '还原' : '预览（--dry-run）'}`);

const result = store.restoreRun(jobId, target, { apply });
let touched = 0;
for (const item of result.files) {
  if (item.action !== 'unchanged') touched += 1;
  console.log(`  ${item.ok ? 'OK  ' : 'SKIP'} ${item.action.padEnd(13)} ${item.file}${item.error ? '  ' + item.error : ''}`);
}
console.log(`${apply ? '已处理' : '将处理'} ${touched} 个文件，失败 ${result.failed} 个，跳过 ${result.conflicts} 个；快照目录 ${path.join(snapshotsDir, target)}`);
if (result.conflicts) console.log('跳过项表示运行结束后文件又被改动，或缺少运行后基线；确认后可手工改回。');
process.exit(result.failed ? 1 : 0);
