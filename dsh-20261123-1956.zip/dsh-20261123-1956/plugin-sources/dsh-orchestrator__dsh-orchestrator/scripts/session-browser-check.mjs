import assert from 'node:assert/strict';
import { createServer } from 'node:http';
import { once } from 'node:events';
import { writeFileSync, existsSync } from 'node:fs';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { fixture, mockContext } from '../test/harness.mjs';
import { createSettings } from '../src/settings.js';
import { clientFactory } from '../src/client.js';
import { page } from '../src/ui.js';
const { chromium, findChromiumExecutable } = await import(pathToFileURL(process.env.ORCHESTRATOR_PLAYWRIGHT_HELPER));
const f = fixture();
const { ctx } = mockContext({ root: f.root });
let settings, origin;
const safe = value => JSON.stringify(value).replaceAll('<', '\\u003c');
const server = createServer((req, res) => {
  if (req.url === '/session-test') {
    const token = new URL(settings.url).searchParams.get('token');
    const boot = { token, parentOrigin: origin, embedded: true, sessionId: 'session-a', sessionTitle: '测试会话 A', bridgeId: 'test-private-nonce', workspaceRoot: f.root };
    const html = '<!doctype html><meta charset="utf-8"><style>body{margin:0;background:#151515;color:white;font:14px system-ui}header{padding:12px}iframe{display:block;width:100%;height:1000px;border:0}button{padding:8px 14px}</style><header>测试会话 A <button id="open">✦ AI 编排</button></header><iframe id="config" title="AI 编排"></iframe><script>' +
      'window.sent=[];window.activeSession="session-a";window.mode="pending";const frame=document.getElementById("config");' +
      'const client=(' + clientFactory.toString() + ')(()=>({createElement(){}}),()=>"");' +
      'const receive=client.createSessionBridge({sessionId:"session-a",bridgeId:"test-private-nonce",origin:location.origin,source:frame.contentWindow,isBusy:()=>true,send:async(text,requestId)=>{window.sent.push({sessionId:"session-a",text,requestId});if(window.mode==="uncertain")throw Error("connection lost");await new Promise(resolve=>window.release=resolve);}});' +
      'addEventListener("message",receive);document.getElementById("open").onclick=()=>{frame.srcdoc=' + safe(page(boot)) + ';};</script>';
    res.writeHead(200, { 'content-type': 'text/html; charset=utf-8' }); res.end(html);
  } else settings.handler(req, res);
});
server.listen(0, '127.0.0.1'); await once(server, 'listening');
origin = 'http://127.0.0.1:' + server.address().port;
ctx.webServer = { register() { return () => {}; }, getOrigin: () => origin };
settings = createSettings(ctx, f.store);
let browser;
const errors = [];
try {
  const executablePath = await findChromiumExecutable() || ['C:/Program Files/Google/Chrome/Application/chrome.exe', 'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe'].find(existsSync);
  assert.ok(executablePath, 'No installed browser found; do not install one automatically');
  browser = await chromium.launchPersistentContext(path.join(f.dir, 'session-browser-profile'), { executablePath, headless: true, viewport: { width: 1200, height: 1100 } });
  const tab = await browser.newPage();
  tab.on('pageerror', error => errors.push(error.message));
  await tab.goto(origin + '/session-test');
  await tab.click('#open');
  const frame = tab.frameLocator('#config');
  await frame.locator('#fields:not([disabled])').waitFor();
  assert.equal(await frame.locator('#projectRoot').inputValue(), f.root);
  assert.match(await frame.locator('#sessionTarget').textContent(), /测试会话 A/);
  assert.equal(await frame.locator('#createJob').textContent(), '开始编排');
  assert.equal(await frame.locator('#copyCreated').isVisible(), false);
  await frame.locator('#task').fill('测试自动注入到会话 A，无需复制 JSON');
  // A simultaneous second submit must not create a second job or admission.
  await frame.locator('#configForm').evaluate(form => { form.dispatchEvent(new Event('submit', { bubbles: true, cancelable: true })); form.dispatchEvent(new Event('submit', { bubbles: true, cancelable: true })); });
  await tab.waitForFunction(() => window.sent.length === 1);
  assert.equal(f.store.list().length, 1);
  const id = f.store.list()[0].id;
  await tab.evaluate(id => {
    window.activeSession = 'session-b';
    const source = document.getElementById('config').contentWindow;
    source.postMessage({ type: 'dsh-orchestrator:result', ok: true, sessionId: 'session-a', bridgeId: 'forged', taskId: id }, location.origin);
  }, id);
  assert.equal(await frame.locator('#createJob').isDisabled(), true);
  await tab.evaluate(() => window.release());
  await frame.locator('#message').filter({ hasText: '已在本会话排队' }).waitFor();
  assert.equal(await frame.locator('#createJob').textContent(), '已发送到本会话');
  const sent = await tab.evaluate(() => window.sent);
  assert.equal(sent[0].sessionId, 'session-a');
  assert.equal(sent[0].requestId, id);
  assert.match(sent[0].text, /orchestrate_run/);
  await frame.locator('#configForm').evaluate(form => form.dispatchEvent(new Event('submit', { bubbles: true, cancelable: true })));
  assert.equal(f.store.list().length, 1);
  // The parent reports uncertain admission: the UI must latch this configuration.
  await tab.evaluate(() => { window.mode = 'uncertain'; });
  await frame.locator('#task').fill('第二次独立任务：验证网络不确定结果');
  await frame.locator('#createJob').click();
  await frame.locator('#message').filter({ hasText: '发送结果尚不确定' }).waitFor();
  assert.equal(await frame.locator('#createJob').isDisabled(), true);
  assert.equal(f.store.list().length, 2);
  await tab.setViewportSize({ width: 390, height: 900 });
  assert.equal(await frame.locator('html').evaluate(node => node.scrollWidth <= innerWidth), true);
  assert.deepEqual(errors, []);
  writeFileSync('local-validation/session-browser-results.json', JSON.stringify({ status: 'passed', modelRequests: 0, visibleBrowser: false,
    coverage: 'Real iframe DOM, settings API and delivery controller; native scoped Session and slot registration covered by client.test.mjs',
    checks: ['srcDoc origin and API resolution', 'workspace prefill', 'session target shown', 'no manual copy', 'double submit creates one job', 'forged acknowledgement ignored', 'bound session retained after selection change', 'busy queued acknowledgement', 'same task requestId admitted once', 'uncertain admission latched', 'mobile width fits', 'no page errors'] }, null, 2));
  console.log('Embedded session GUI passed all browser interaction checks; zero model requests');
} finally { await browser?.close(); settings.dispose(); server.close(); server.closeAllConnections(); await once(server, 'close'); }
