# DSH Orchestrator

多模型编码编排插件。planner 在同一只读规划会话内提供逐任务的源码可行性自检；宿主根据校验后的计划形状决定是否增加独立复核（独立路由，缺省沿用 planner），然后按依赖分波实施并交独立 reviewer。planner、worker、feasibility、reviewer 四套配置分别选择 provider、model 和 reasoning effort。

## v0.2.14：探索 / 标准 / 严格验收档位

- 配置新增 `reviewLevel: exploratory | standard | strict`，与每个模型的 reasoning effort 独立。旧任务及未填写时保持 `standard`；不改写历史任务和报告。Reviewer 卡片的“验收档位”可以直接切换。
- **探索**：面向先做出可试用版本的任务，不调用 reviewer、不校验其在线模型能力，也不进行自动定向修复；保留 Planner、自检、按计划形状决定的 Feasibility、权限/文件归属/接口校验与失败回滚。Planner/Worker 提示词要求最小实现，不为了未来扩展增加全面重构，但绝不能丢弃用户明确要求的功能、测试和硬约束。
- 探索档中，**选中的数据断言仍实际执行**。执行失败、警告、环境错误或全部不适用都不能放行，报告为 `blocked` / `blocked_by_data`，保留实施结果和原始证据供处理；不额外唤起 reviewer 或隐式重规划。不需要这类数据校验的项目可明确不选断言，不应勾选无关断言求通过。
- 探索正常交付为 `needs_validation` + `verdict: exploratory_unreviewed`，附 `review: null`、`reviewSkipped: {reason: exploratory, level: exploratory}`、`nextAction.runtimeVerified: false`。界面显示“探索完成·待试用”，不是“验证通过”。单任务无依赖的正常探索链路只有 Planner → Worker 两次模型会话；多任务仍保留独立 Feasibility（其路由可单独配置）。模型失败补交/规划重试等原有有界恢复不在此正常次数内。
- **标准**：完全沿用现有 `reviewMode`：`always` 总是复核；`on_failure` 仅在所选断言确实执行并通过时跳过。`maxRepairRounds` 按既有机制生效。
- **严格**：不论 `reviewMode` 如何都必须复核。扩大与本次改动相关的输入边界、错误处理、调用方兼容、回归、异步资源及安全边界的静态检查；不把风格偏好当缺陷，也不声称已实际执行测试。
- `reviewMode` 在探索/严格档不生效；自动返工在探索档停用，切回标准/严格保留原设置。默认配置和外部浏览器本窗口草稿均保存档位；探索保存时保留未启用的 reviewer 配置，切回其他档位必须重新校验能力。
- **范围边界**：此次没有增加任意 shell 命令或自动浏览器运行器。所有档位都不会自动执行项目构建、启动、单元测试或运行时冒烟；`verifyHint` 在报告中交给主会话，探索只建议本次改动所需的最小验证。“未报错”必须来自实际运行，不能用跳过复核或数据断言通过替代。
- 客户端需重新构建，服务端需完整退出并重启 DSH。加载后可通过 `compatibility.runtime.features.reviewLevels` 和磁盘一致性核对，不以磁盘版本号冒充在线已生效。

## v0.2.13：浏览器 A 方案流程工作台

- 在目标 DSH 会话点击「AI 编排 ↗」，通过系统默认浏览器打开正式 A 方案。桌面宿主决定交给默认浏览器，最终新标签/新窗口由浏览器策略决定；插件不承诺无地址栏原生窗，不修改 DSH 宿主。被拦截时可点击工具条的「浏览器入口 ↗」。后台运行只更新「查看流程」入口，不会自动弹出浏览器。
- 主界面按 Planner → Feasibility → Workers → Verifier → Reviewer 排列可点击卡片，右侧抽屉配置真实模型目录与精确 effort；断言按真实包/组/单条展开选择，目录缺失的已选项不会静默丢失。画布展示条件放行和证据返工路线；Worker 并行槽只是并发上限示意，任务与依赖仍由实际计划决定。当前执行器至多一次定向修复，历史 `maxRepairRounds=2` 会明确提示这一限制。
- 外部页面绑定打开时的原会话，不随 DSH 当前会话切换。浏览器创建授权范围内的配置后，由保留在原 DSH 客户端的独立 owner 凭据取回固定任务指令，再经该会话的 `Session.prompt(..., 'queue', ..., taskId)` 投递。浏览器 API 自身不会直接执行模型；打开/选模型/保存默认均不产生编排模型调用。
- 外部链接只持有独立 browserToken：仅能读取绑定会话任务、创建本桥任务并提交，不能读取其他会话、持有 ownerToken、调用 owner 操作或覆盖全局默认。完整 settingsToken 留在 DSH。链接仍是凭据，请勿分享；页面禁用 referrer、跨来源 API 与缓存。插件停止后凭据失效。
- 「保存本窗口默认」只保留该桥的内存配置，最长 8 小时，不覆盖 DSH 全局默认；需要全局持久化时使用 DSH 插件设置页的「保存为默认设置」。桥接草稿与投递记录在宿主重启后失效；已创建任务和运行报告仍在原存储目录。
- 原 DSH 页面须保持开启。刷新原 DSH 页面后需从原会话重新打开连接。关闭浏览器不会取消已启动任务；工具条 × 明确断开该会话所有浏览器桥，先停止本地接收，再撤销服务端连接，不撤销已在途或已启动任务。桥到期后原客户端停止轮询，重复打开同一任务监控会复用连接。
- 同桥相同配置的创建请求共用一份任务；重复提交、丢失回执均复用任务与投递账本。只有明确未接收的拒绝允许重试；`gateway/internal`、取消和未知网络结果以及等待确认超过两分钟均标为 uncertain，禁止自动再次投递，不以“没拿到回包”冒充“没启动”。
- `node scripts/verify-studio.mjs` 使用独立 headless Chrome 与隔离的实际 HTTP 设置接口、模拟模型目录进行桌面/窄屏交互验收；只模拟原会话指令接收，不执行模型。此项不是当前真实 DSH 实例已经加载新代码的证明。服务端代码需完整退出并重启 DSH，再检查运行时标识与磁盘一致性。

## 运行时加载确认（零模型调用）

- 使用 `orchestrate_settings` 检查 `compatibility.runtime`，或在设置页的“运行时代码”区查看。缺少此字段意味着该实例没有提供确认机制，不能当作最新。
- 核心模块在**求值时**捕获 SHA-256；查询时才读取磁盘作比较。`buildId` 是已加载模块集合的指纹，`diskBuildId` 是同一集合的磁盘指纹；`sourceMatches`、`staleModules` 明确是否混用了旧模块。不是只读磁盘的版本号来假装已加载。
- `features.reviewRetry=true` 由已加载的 runner 模块声明，另带加载时间、PID、模块根目录和逐模块哈希。此字段确认实现能力，不代表本次已经实际发生重试。
- 每次任务报告保存启动时的 `runtime`；若检测到已加载模块与磁盘不一致，在任何模型请求、快照和文件写入之前拒绝启动，任务仍保持 queued。
- 当前宿主 loader 的普通 ESM import 会缓存模块。插件实例重启不保证依赖模块重新求值；仅对入口追加 query 也不能解决静态依赖缓存。本补丁不修改宿主或自动杀进程。首次启用、或检测到不一致时，应完整退出宿主再启动，然后先用上述零调用检查确认。
- 指纹覆盖已接入捕获的插件核心模块和 manifest，不等于整个宿主、浏览器缓存或项目文件的完整性证明。

## 当前补丁：复核调用异常独立分类与有限重试

- `review_failed` 只表示拿到了有效的 `issues_found` 复核结论；`review_error` 表示复核调用或结果契约异常，未获得有效最终结论，不等于代码被判不合格，也不算通过。
- reviewer 子会话返回明确的 `MALFORMED_RESPONSE` 时，使用同 provider/model/effort、同只读权限重新复核一次；每个复核阶段最多两次调用，不重跑 worker、不切模型、不跳过审查。其他错误不自动重试，安全拒绝和取消仍照原规则停止。
- 报告新增 `reviewAttempts[{phase,attempt,route,status,code?,error?,childId?,startedAt,endedAt}]`，保留每次尝试；耗尽后写 `reviewError` 与 `reviewFailure{phase,code,message}`。
- 修复实施完成后若最终复核异常：`repair.status=review_error`、`repair.implementationStatus=completed`，文件、哈希与实测断言保留；首轮结论留在 `initialReview`，`review=null`，不能拿首轮的旧问题当最终复核结果。
- 历史报告不改写。此补丁提高对调用异常的容错和可辨识度，不修复模型供应商或宿主适配层的非法 JSON 根因。

## v0.2.12：单条 check 降级、主会话专用条目、复核提示词补契约

起因是 arm-a13：修复轮 reviewer 把用户目标里的「记录各模型调用与耗费金额」写成 `kind:"data"` + `command:""`——内容完全正确，只是按约定只能由主会话做。旧契约要求 data 类必须有可执行命令，`validateReview` 直接抛错，`report.repair.status=failed`，整轮落到 `review_failed / repair-failed`：代码在 2 分钟前就已修好（体长补偿符号翻转，哈希 `b9fa3952…` 留在盘上），却被一条格式问题判死，`repair.checks` 也随之全空。

- **单条 check 的格式问题改为降级，不再整轮失败**：`validateReview` 里逐条归一，出问题的条目保留下来并标 `status:"unverifiable"` + `issue`（原因），其余条目照常可用；结果多一个 `degraded:[{id,issue}]` 汇总，runner 发 `review-degraded` 事件。可降级的包括：`build`/`runtime`/`data` 缺命令、`kind` 不在枚举、`owner` 无效、未知字段、id 缺失/重复、`statement`/`expected` 为空、单条不是对象。**信封级错误仍然失败关闭**：结论无效、缺 `summary`、`checks` 不是数组、超过 40 项、以及两条反退化规则（`issues_found` 无条目、`verified_statically` 无待验证项）。
- **`owner` 归属字段**：`checks[].owner ∈ {run, main}`，可选，缺省 `run`。`main` 表示只有主会话能闭合这一项（计费/token/费用账本核对、人工目视、真实浏览器、需要用户决策），这类条目允许没有 `command`——如实标注不可自动化，而不是缺陷。不填 `owner` 的历史输出与旧模型行为不受影响。
- **reviewer 提示词补契约**：`reviewDelivery` 现在按 `REVIEW_SCHEMA`/`CHECK_KINDS`/`CHECK_OWNERS`/`COMMAND_KINDS` 现场派生形状摘要，并内嵌 schema 原文；同时明说"天然归主会话的条目照实写 `owner="main"`"与"单条格式问题会降级、不会拖垮整轮"。此前只有 planner 有等价的 `planDelivery`，reviewer 只能靠 system prompt 里距离很远的一句话。
- **失败时不再丢证据**：`report.repair` 改为边跑边记（`plan`/`snapshot`/`workers`/`files` 在任何一步失败时都保留），失败路径保留 `error` 与 planner 正文，并会用修复阶段的实际磁盘内容刷新 `report.files`（此前停在首轮哈希，主会话核对时容易误以为修复没落盘）。
- 界面：复核卡显示降级条数与逐条原因（琥珀色 `banner warn`），每条标注"主会话专用/已降级"；修复卡显示失败原因与已落盘文件。
- 本地验证（2026-11-15）：`npm test` 全量 **202 项：198 通过、4 跳过（`DSH_APP_ROOT` 原生协议项）、0 失败**（v0.2.11 为 195 项）。新增/改写覆盖：`review.test.mjs` 的降级矩阵、`owner` 语义、id 自动编号、信封级失败关闭、以及原样照抄 arm-a13 事故条目的回归；`review-wiring.test.mjs` 的"构建类缺命令不再算复核失败"（含 `review-degraded` 事件与 `nextAction.note`）；`pipeline.test.mjs` 的修复轮端到端回归（`repair.status=completed`、`degraded=1`、最终清单取到修复阶段哈希）。`npm run check` 与 `build-client --check` 通过。**服务端源码需完整重启 DSH 才会加载新代码。**

## v0.2.11：结构化输出兜底、复核失败不毁成果、报告契约修正

起因是一次真实编排（arm-a11）：修复轮的 planner 读完全程源码、把修法写成正文就收尾，没有调用 `structured_output`，宿主判「未提交有效的 structured_output」，`maxRepairRounds` 用完后整轮 `review_failed`。复盘时还发现复核失败会连带回滚已经写好并复核过的代码，以及三处报告契约错误。本版一起处理。

- **计划类交付协议**（`planDelivery`）：`plannerPrompt`（首轮与被拒重试）和 `repairPrompt` 末尾都复述一遍——必须调用 `structured_output`、正文不算交付，并内嵌与 `validatePlan` 同源的 `PLAN_SCHEMA` 原文。形状摘要与 schema 都从 `PLAN_SCHEMA` 现场派生，改 schema 不必手改提示词。这类复述只是概率修正，不是强制。
- **结构化结果的只读补交**：planner（含修复轮）/ feasibility / reviewer 正常结束但没交结构化结果时，宿主不再立刻判死，而是用**同路由只读子会话**（role `receipt`，只允许 read/glob/grep 与 structured_output）把上一轮正文压回 schema 形状，成功则继续，失败再按原语义报错。每次运行上限 3 次，记录在 `report.structuredRecoveries[{role,status,childId,error?}]`；被补交的子会话在 `report.children[].recovered=true`。worker 仍走既有的 receipt 通道，两者互不干扰。
- **复核失败不再回滚成果**：`reviewOnce` 抛错（复核模型用正文收尾、结构不合规、路由在写入后被撤）不再让整轮 `failed` 并逆序回滚；改为 `status=review_failed` + `report.reviewError`，文件、哈希、快照全部保留，`nextAction.note` 明说「复核未产出可用结论」。安全闸门（权限/预算/越界）仍然失败关闭。**行为变化：畸形复核输出此前会让整轮失败并还原文件，现在只降级并保留。**
- **失败也留正文**：子会话未交付或非正常结束时，`report.children[].rawOutput` 保存有界（4000 字符）、已脱敏的最终正文；修复轮失败时另存 `report.repair.rawOutput`。此前只能回原始会话日志里挖。
- **修复轮复核拿到修复计划**：`reviewOnce(files, workers, planForReview)`，修复阶段的复核传入 `repairPlan`。此前它一直拿首轮计划去套修复后的 diff，容易误判偏离或漏查扩权。
- **`report.files` 合并两个阶段**：修复轮新建的文件此前只存在于 `repair` 快照里、不进最终文件清单。现在按「首阶段条目优先」合并 manifest 后重算，主会话核对归属与哈希不再漏。
- **worker 声明与实际对齐**：`changedFiles` 事先只校验「是否属于自己」。现在还要与磁盘比对——一个文件都没变却声称完成 → 该任务失败并点名文件；部分声称未变 → 从清单移除并记 `worker-unchanged-claims`；真改了却没申报 → 以磁盘为准并入清单并记 `worker-unreported`。
- **repair 提示词证据裁剪**：checks 只保留 `id/kind/statement/expected`（`command` 由主会话执行，不需要复制成修复任务），上一轮计划去掉 `feasibility` 证据，worker 摘要截到 400 字符。真实体量下提示词约缩小 20–30%，减少长输入对交付要求的稀释。
- 界面补上 `reviewError`、`structuredRecoveries`、`repair.rawOutput` 的展示，复核失败不再看起来像「验证过」。
- 本地验证（2026-11-15）：`npm test` 全量 **195 项：191 通过、4 跳过（`DSH_APP_ROOT` 原生协议项）、0 失败**；新增 10 项 `test/resilience.test.mjs`（补交成功/补交失败/复核正文收尾/修复计划进复核/修复新建文件进清单/worker 声明与实际不符两个方向/repair 提示词裁剪与 A/B 体积）与 10 项 `test/plan-delivery.test.mjs`（含两条走真实 runner 的接线断言）。`npm run check` 与 `build-client --check` 通过。**服务端源码需完整重启 DSH 才会加载新代码。**

## 当前补丁：复核结论三档化与结构化待验证清单

- 复核结论从「通过/有问题」两档改为三档，把「静态复核通过」与「真的验证过」分开：`verified_statically`、`issues_found`、`unable_to_verify`。旧的 `ready_for_validation` 读取时归一为 `verified_statically` 并在报告里保留 `legacyAssessment`，历史记录不改写。
- 待验证项改为结构化条目 `checks[{id,kind,statement,command,expected}]`，不再是自由文本数组。`kind` 取 `build|runtime|visual|static|data|process`；`build`/`runtime`/`data` 必须给出可执行 `command`，否则整轮失败。（v0.2.12 起改为只降级该条目，见顶部）
- 反退化校验：`verified_statically` 必须列出待验证项（否则等于宣称万事俱备）；`issues_found` 必须给出至少一个可定位条目（否则只是把判断成本推回主会话）。`unable_to_verify` 允许清单为空，它表达的就是无法判定。
- 宿主只校验形状与可判定性，不执行 `command`，也不因为收到清单就认为验证已完成。`nextAction` 同时给出结构化 `checks` 与兼容用的扁平 `checksNeeded`。
- reviewer 路由写入 `report.review.route`，便于审计本轮由哪个 provider/model 复核。`issues_found` 在 `maxRepairRounds > 0`（默认 1）时触发一次定向修复（见 v0.2.8），修复后仍会再复核一次；`maxRepairRounds=0` 则直接置 `review_failed` 返回主会话。

## 上一版补丁：合并 planner 自检，按计划形状触发独立复核

- 每项任务新增必填 `feasibility: {status, summary, evidence, questions}`。planner 读取实现时同步给出证据，不另开一个 planner 会话；证据最多 20 条、每条最多 4000 字符。新建文件检查其调用方或相邻实现。宿主校验结构和边界，不能证明自然语言证据真实，也不能代替构建与测试。
- **单任务且无跨任务依赖**：planner 自检通过后直接保存快照并启动 worker；即使 `maxWorkers` 大于 1、任务涉及多个文件，也不会额外开可行性会话。正常链路为 planner → worker → reviewer，共 3 个子会话（规划重试另计）。
- **多任务或存在 `consumes` 跨任务依赖**：保留一个独立、只读的复核会话覆盖全部任务（v0.2.8 起走独立 `feasibility` 路由，缺省沿用 planner）；自检与独立复核都通过后才保存快照并启动写入。互不依赖的多任务同样触发。正常链路为 planner → feasibility → N worker → reviewer，共 N+3 个子会话。
- 触发规则由宿主计算，不读取 planner 的跳过标志；仍先检查互斥文件、权限范围及接口闭合。单任务伪报外部 `consumes` 会被拒绝，不能用它绕开检查。
- 能形成合规候选任务但仍有疑问时，顶层 `status=ready` 仅表示计划结构候选可用；每项自检可为 `needs_clarification` 或 `blocked`。宿主在任何额外复核、快照与写入之前返回 `report.status=blocked` 和 `nextAction.questions`，不重规划。无法形成合规任务时继续使用顶层 `status=blocked, tasks=[], blockers=[...]`。
- 缺失或畸形的自检证据按既有 `maxPlanRetries` 有界重试；有效的疑问或阻塞不重试。新生成的计划不允许缺少自检，旧任务配置会生成新格式计划；历史报告不改写。
- `report.plannerFeasibility` 保存自检，`report.feasibilityPolicy` 保存触发理由；仅实际独立复核才有 `report.feasibility`。跳过不伪报独立通过。两种来源分别传给 worker，仍要求 worker 自己读取现状并保留 mismatch 出口。
- `plan_only` 保留 planner 自检与触发理由，但不运行独立复核、快照和实施；有效的自检阻塞同样返回主会话。设置页区分两种来源并兼容显示旧记录。

验证记录（2026-11-12）：真实源码路径与已安装 junction 路径分别运行 108 项测试，均 108 通过、0 失败、0 跳过，包含已安装宿主的 schema 与协议适配测试。语法、嵌入页面脚本和生成客户端一致性检查通过；后台无窗口设置页测试覆盖两种证据来源、跳过原因、仅规划提示与旧记录显示。没有访问真实模型供应商；实际模型判断质量与净耗时收益尚待真实任务验收。服务端源文件更新不等于运行实例已加载，需完整重启 DSH 后使用新任务验证。

下列版本小节记录历史行为；本节的条件触发规则优先。

插件注册专用工具，新会话无需知道某份工作流脚本或临时 JSON 的路径。它不修改安装目录、不替换 workflowEngine，也不要求给内置 workflow 打 effort 补丁。

## v0.2.10：修复 0.2.9 的设置页空白

- **症状**：点击工具条上的「AI 编排」后没有任何界面出现（会话仍在，按钮仍在，但弹层渲染失败）。
- **根因**：设置页函数用三个注入变量（`flowModel`、`flowStyles`、`createFlowView`），而 `lib/client.js` 的序列化包装只绑定了两个，漏了 `flowStyles`；浏览器里 `page()` 一执行就 `ReferenceError`，React 渲染中断。服务端渲染走正常 `import`，所以 0.2.9 的 451 项断言全绿也没发现。
- **修复**：把序列化逻辑移到 `src/bundle.js`，`renderPageExpression()` 显式绑定全部三个变量；`scripts/build-client.mjs` 只做 CLI 包装。
- **回归测试**：新增 `test/bundle.test.mjs` 两项——在 `vm` 里执行**浏览器实际收到的那段表达式**并断言页面含 `flowPanel`、四个模型卡；再用假 `window.__ModuleLoader__` 加载整份 bundle，验证工厂能返回 `SessionAction`/`SettingsPage`/`discoverRun`。这类「服务端能跑、浏览器炸」的缺陷从此有测试兜住。
- 本地验证（2026-11-15）：`npm test` 全量 175 项，171 通过、4 跳过、0 失败；用 headless Chrome 加载真实序列化页面：0 pageerror，四张模型卡（01 规划 / 02 执行 / 03 写入前复核 / 04 复核）与流程面板均在。`npm run check` 通过。需完整重启 DSH 生效。

## v0.2.9：编排执行流程图

- **运行即弹图**：`orchestrate_run` 启动后台任务后，会话工具条上的编排按钮会读取 `GET /dsh-orchestrator/settings/api/activity?session=<id>`（按 `parentSession` 过滤、只认 `running`），发现本会话有**新的一次运行**就自动打开流程图面板。同一次运行（按 `runId` 去重）用户关闭后不再自动弹；新的运行会再弹一次；已结束的运行不弹。观察轮询是可选的，失败静默，不影响对话输入。
- **一卡一阶段**：环境检查 → Planner → Feasibility → 快照 → Worker（按 `consumes` 拓扑分列，每个任务一张卡）→ Reviewer →（可选）定向修复 → 回滚 → 运行结果。多 worker 是并排的多张卡，依赖关系直接画成连线；面板每 1.5 秒读取 `runs/<run-id>.json`，卡片状态实时变化（等待中 / 运行中 / 已完成 / 失败 / 已跳过 / 已降级 / 发现问题）。
- **点卡片看产物**：详情侧栏展示该阶段的模型路由、起止时间、计划分配文件、**已核验的实际修改文件**（宿主按快照哈希算出）、模型回执声明的文件、补交回执、跳过原因、失败原因与回滚结果。只读阶段（planner / feasibility / reviewer）明确标注「计划涉及的文件不代表已经改动」，不把计划当产出。
- **失败链路红光**：`failed` / `blocked` / `issues_found` 卡片加红光描边与投影；受上游失败牵连而被跳过的下游卡片用红色虚线边框，连到它们的边也是红色虚线；健康分支保持绿/灰。被降级的复核是琥珀色，和失败区分开。
- 报告侧新增最小字段：`flowPhases[{id,plan,snapshot,tasks[{taskId,status,assignedFiles,actualChangedFiles,error,reason}]}]`、`children[].phase`、`children[].assignedFiles`、`initialReview`。worker 每完成一个任务就落一次盘，因此运行中也能看到已完成任务的文件与状态；宿主另外用快照哈希核对真实改动，不轻信模型回执。
- 本地验证（2026-11-14）：`npm test` 全量 173 项，169 通过、4 跳过（`DSH_APP_ROOT` 原生协议项）、0 失败；新增 7 项覆盖投影（运行中待定、已完成文件区分、失败分支高亮、降级/受阻、修复轮双列、样式契约、设置页内嵌）与 1 项客户端 `discoverRun`（同 run 只弹一次、新 run 再弹、跨会话忽略、结束不弹、非法 id 忽略）。另用本机 headless Chrome 加载由同一份 `src/flow.js` 生成的离线演示页截图核对首屏与失败末端，`pageerror` 为 0。`npm run check` 通过，`lib/client.js` 已重新生成。服务端源码需完整重启 DSH 才会加载新代码。

## v0.2.8：独立复核路由、依赖分波与定向修复

- **第四套模型路由 `feasibility`**：写入前复核不再借用 worker。缺省继承 planner（判断力优先），可在设置页单独选择；换成另一家模型才有真正的「第三方视角」（误差不相关）。`validateModelRoutes` 现在校验四条路由，任一不可用仍在规划前失败。
- **复核故障降级**：结论性阻塞（`needs_clarification` / `blocked`）照旧在写入前停止并把问题交回主会话；复核会话本身没有产出可用结论时（坏帧、缺 `structured_output`、结构校验不过），降级为 planner 自检继续，记 `report.feasibilityDegraded{route,reason,at}` 与 `feasibility-degraded` 事件，不再让一次坏响应否决整条编排。权限、只读预算、路径越界这类**安全闸门拒绝仍然失败关闭**，不降级。
- **依赖分波执行**：`consumes` 现在决定执行顺序。任务按拓扑分层，同一波并行，消费方等提供方写完再启动，避免读到旧文件。成环或指向未排入任务的计划在 `validatePlan` 阶段就被拒绝（`planWaves()`），不再并发硬跑。
- **任务级失败语义**：单个任务失败只让它的**下游**任务跳过，同波兄弟任务继续；失败任务的归属文件单独回滚，成功任务的成果保留。`report.tasks[{taskId,status,error?}]` 记录每个任务的 `completed|failed|skipped`。复核阶段崩溃（无任务级失败）才整体回退。
- **定向修复**：reviewer 报 `issues_found` 且 `maxRepairRounds > 0`（默认 1，0–2）时，planner 带着复核证据做一次**定向修复规划**（`repairPrompt`）：必须是合规计划（互斥文件、接口闭合、每任务带自检），单独快照到 `snapshots/<run-id>/repair-1/`，执行后**再复核一次**。修复规划若返回 `blocked`，保留原复核结论并结束（`report.repair.status='blocked'`），不硬凑任务。
- **新增报告字段**：`feasibilityDegraded`、`tasks`、`snapshots[]`、`repair{round,plan,snapshot,workers,files,review?,status?,blockers?}`；`report.snapshot` 仍指第一阶段的快照，兼容既有消费方。
- **修复失败不连坐**：修复规划本身无效（越界文件、签名不闭合）、修复规划报 `blocked`、修复任务失败，都不会抹掉第一阶段已写好并复核过的成果；前两种保留原复核结论并把 `report.repair.status` 记为 `blocked`/`failed`，事件为 `repair-skipped`/`repair-failed`。安全类拒绝仍然上抛。
- 本地验证（2026-11-14）：`npm test` 全量 165 项，161 通过、4 跳过（`DSH_APP_ROOT` 原生协议项）、0 失败；新增 11 项覆盖分波顺序、成环拒绝、下游跳过、只回滚失败任务、独立复核路由、定向修复两轮、修复规划 blocked、无效修复计划、修复任务失败只回滚修复阶段、`maxRepairRounds=0` 与取值边界。设置页确认渲染四张模型卡、保存载荷与任务详情都包含 `feasibility`。`npm run check` 通过。服务端源码需完整重启 DSH 才会加载新代码。

## v0.2.7：失败回滚（只撤销自己的写入）

- 新增自动回滚：运行进入写入阶段后若以 `failed` 或 `cancelled` 收尾，把计划文件逐字节还原到快照状态，运行期间新建的文件删除。回滚发生在终止状态写入之前，事件流里 `rollback` 早于 `failed`/`cancelled`。
- 三方哈希守卫：只有「当前字节 == 本次运行记录的 after 哈希」才动手。运行结束后被用户、其他程序或其他插件改过的文件记为 `conflict` 并跳过；没有 after 基线（例如失败发生在生成哈希之前）记为 `skipped`。**回滚不会覆盖任何不是本插件写下的内容**，这是此前「不自动回滚」的主要顾虑。
- 备份自证：写回前用 `manifest.json` 里的 sha256 校验 `<n>.bin`，备份缺失或被改动记为 `failed`，绝不写回错字节。单文件失败不影响其他文件，全部结果留在 `report.rollback`。
- 结果契约：`report.rollback{reason,changed,conflicts,failed,files[{file,action,ok,error?}]}`，`action` 为 `restored|removed|unchanged|conflict|skipped|failed`（预览时是 `would-restore|would-remove`）。快照目录继续保留，便于事后核对。
- 手工还原：`node scripts/restore.mjs <task-id> [run-id] [--dry-run]`，按 `jobs/<task-id>/runs/<run-id>.json` 的 after 哈希做同样的三方校验，用于 `review_failed` / `needs_validation` 这类「不回滚」的终态。
- 关闭开关：任务配置 `rollbackOnFailure: false`（默认 `true`）保留失败现场，便于取证式排查。
- 本地验证（2026-11-14）：`npm test` 全量 154 项，150 通过、4 跳过（`DSH_APP_ROOT` 原生协议项，未设环境变量）、0 失败；其中新增 10 项覆盖还原/删除新建文件、备份被篡改、运行后外部改动跳过、无基线跳过、dry-run、按 runId 还原、写入后失败的整体回滚、关闭开关、写入前失败不产生回滚记录、默认值与显式关闭。另用临时 store 手工跑通 `scripts/restore.mjs` 四步（预览 → 还原 → 幂等再跑 → 外部改动跳过并退出码 1）。`npm run check` 通过。服务端源码需完整重启 DSH 才会加载新代码。

## v0.2.5：worker 缺回执的一次只读恢复

- worker 提示词首尾都明确要求调用 `structured_output({status, summary, changedFiles})`；正文摘要不算交付，证据与行号放入 `summary`。只允许 `completed` / `mismatch`，不改变已保存任务、模型与文件边界。
- 仅当准确绑定的 worker 正常结束、宿主返回 `error` 且未捕获结构化结果、没有上游诊断、存在写入调用且归属文件哈希确实变化时，尝试一次补交。网络错误、拒绝、超时、取消、创建失败、未写入或无实际变化均不恢复。
- 宿主 spawn 为一次性会话；因此补交不是续跑原 worker，而是同 provider/model/effort 的独立 **receipt** 子会话，只有 read/glob/grep 与 structured_output，guard 同时拒绝写入。它读取磁盘内容，根据原目标、约束、哈希及有界脱敏的旧正文补交；证据不足返回 mismatch。不会重新实施或自动切换模型。
- 原 worker 的失败记录保留；`report.receiptRecoveries` 记录来源、哈希及补交状态。补交仍走归属校验与独立 reviewer，不等于任务通过。补交再失败直接结束，不循环，也不消耗 `maxPlanRetries`。每个符合条件的 worker 最多增加一个有费用的子会话。
- 本补丁不引入自动回滚；失败写入与原始快照继续保留供人工判断，避免覆盖其他并发或外部修改（v0.2.7 起改为带去重的失败回滚，见上）。服务端源码需完整重启 DSH 才会加载；版本显示为 0.2.5 后方可验收真实模型效果。
- 本地验证（2026-11-13）：设置 `DSH_APP_ROOT` 指向已安装宿主后，全量 123 项测试通过、0 失败、0 跳过；其中新增 15 项覆盖首尾提示、只读同路由补交、无变化/无写入、网络/拒绝/超时/取消不重试、补交失败仅一次、越界结果、外部修改与创建失败。`npm run check` 通过。协议测试使用 loopback 模拟端点，不调用真实供应商；未声称当前运行进程已经加载补丁或真实模型恢复率已经验证。

## v0.2.4：失败原因与重试边界修复

- `maxPlanRetries` 只重试已完成但未通过计划内容校验的结果。模型运行/创建失败、拒绝、超时或取消直接结束；宿主内部已有网络重试，不再因同一故障额外开 planner 会话。不切换模型、不降低档位、不改历史任务或文件边界。
- 原生 spawn 未提供 `diagnostic` 时，从准确绑定子会话的 `turn/end` 读取错误码与消息；终态缺失时才使用最近的重试错误。原生结果已有诊断时优先使用。报告与后台进度保留具体失败原因，敏感 key/Bearer 内容先脱敏。
- 子代理在创建绑定时即记为 `running`，记录开始/结束时间；创建失败也记为 `failed`，不再留下长期 `starting` 的误导状态。
- `orchestrate_task.config` 明确声明配置对象及 planner/worker/reviewer 字段。请直接传 JSON 对象，不要将对象序列化成字符串；旧平铺角色和 adapter 参数继续支持。
- 兼容检查的 `implementationVersion` 和新运行报告中的同名字段记录模块加载时版本，便于区分磁盘文件已更新与当前进程是否已加载修复。服务端修改后须完整退出并重启 DSH；仅刷新页面不生效。
- 新增真实已安装 Anthropic 适配器的本地双轮回归：两处 thinking signature、工具结果关联、结构化交付，以及 503、缺 stop reason 和缺 message_stop 的错误传播。使用 loopback SSE 和假凭据，不访问供应商、不消耗远端模型额度。
- 本次 arm-a5 的日志已证实上游 `No available accounts` 与独立连接/流异常；本地双轮回归未发现签名或工具关联丢失。本补丁修复本地错误隐藏和重复规划，不能修复供应商账号池，也不能保证远端网关已恢复。

## v0.2.3：独立 reviewer 与模型适配

- 设置页提供 planner / worker / reviewer 三张模型卡，分别保存路由和档位（v0.2.8 起增加第四张 feasibility 卡，缺省沿用 planner）。建议方向为 Claude 规划、Claude / DeepSeek / Qwen 实施、GPT 复核，但不按品牌限制角色。
- 完整执行前、每个子会话启动前都按准确路由校验。三条路由中的任一显式档位不受支持或模型无法解析，均报角色明确的错误；不静默降低档位、不切换模型、不退回 planner。
- 旧任务和旧默认值未提供 reviewer 时，兼容为原 planner 路由及档位。只在缺少配置时继承；显式但无效的 reviewer 不继承。旧磁盘配置/报告不改写。设置页提示旧默认值，并可重新选择 GPT 等独立复核模型后保存。
- 全新且无历史默认值时，从现有目录优先选 Claude planner、Claude/DeepSeek/Qwen worker、GPT reviewer；没有对应系列时选目录中的可用项。这只是首次表单建议，名称匹配不作为能力判断，不会在运行失败时换路由；已保存的选择即使不在目录也原样保留。
- 档位仅来自每条精确路由的宿主能力声明，不假定 Claude/GPT 的 high、max、xhigh 或 DeepSeek/Qwen 的思考开关通用。旧档位不再被支持时保留显示并阻止提交，不能刷新后悄悄变成「不指定」。切换模型会清掉前一个模型的档位。
- 手动模型增加「校验此模型能力」，通过有鉴权的设置 API 查询精确 provider/model，即使不在目录也可以获取档位。不生成模型内容、不探测远程凭据可用性；能力查询失败不会改用其他模型。单一模型目录错误不会隐藏同供应商的其他可用模型。
- 插件继续使用宿主 `spawn`、普通工具调用和作用域内 `structured_output`，不自行拼各家 thinking/temperature/response_format 或签名重放。Anthropic Messages、OpenAI Completions / Responses 等线协议由已配置的 DSH 适配器处理。第三方网关仍须在宿主正确配置协议、模型、上下文、凭据与思考能力；模型名字不能证明接口兼容或支持工具调用。
- 所有角色都需实际支持工具调用；这里只读/写文件工具和结构化交付，不依赖某一家原生 JSON 响应模式。远端接口的工具能力无法由当前宿主元数据完全证明；最终仍需真实模型的小型验收。工具 schema 即使在线协议中被规范化，最终交付也由宿主的权威 schema 校验。

## v0.2.2：分层计划与执行前可行性确认

- planner 每项任务输出 `goal`（实施目标）、`constraints`（硬约束数组）、`suggestedSteps`（建议步骤数组），替代混合的 `instruction`。目标、约束、文件归属、接口及验收必须满足；建议步骤可由 worker 根据现有实现调整、替换或省略，重要偏离写进结果 `summary`。reviewer 不得仅因未照建议步骤执行就认定错误。
- 完整执行在计划校验后增加 **1 个** 只读 `feasibility` 会话（v0.2.8 起走独立路由，缺省沿用 planner），一次确认全部任务。每项必须给出具体文件/符号证据及 `ready`、`needs_clarification` 或 `blocked`。只有全部 `ready` 才保存快照、启动实施 worker。
- 任一任务待澄清或受阻，整批返回 `status=blocked`，未启动实施 worker、未修改项目。逐项证据保存在 `report.feasibility`，问题在 `nextAction.questions`；不自动重规划、猜答案、扩大权限或递归委派。解决问题后由主会话创建新任务；没有会话内继续执行或问答恢复机制。
- 确认输出缺项、重复任务、无证据、状态自相矛盾或模型异常时均在写入前失败，不自动重试确认。`plan_only` 跳过确认和实施，也不声称计划已经通过可行性确认。
- 正常完整执行的子会话数从 `N+2` 变为 `N+3`（1 planner + 1 feasibility + N worker + 1 reviewer；规划重试另计）。N 为计划任务数，最多 `maxWorkers`；新增的确认会话串行运行，不与写入重叠，也不是每个 worker 各开一个。
- 设置页说明两套模型的角色复用，执行记录展开显示目标、约束、建议步骤以及确认的证据与问题。历史配置不改写；旧任务配置仍可用于生成新计划，历史 `instruction` 记录仍能显示。新规划必须使用分层结构，不自动猜测旧文本中哪些内容是硬约束。
- 此版本未实现另行设计的工具/Skills 按任务分配机制。确认是模型基于读取内容的判断，不替代编译、测试或主会话验证；报告结构和工具权限由宿主校验，内容判断仍可能出错。

## v0.2.1：arm-a4 故障修复

- `allowProtected` 仅表示允许覆盖 `protectedFiles` 内的文件，不是全局修改开关。`false` 且保护清单为空时，仍可实施允许范围内的源码修改；`true` 也不会绕过允许路径和文件归属。
- 运行前有界检查项目普通文件，跳过依赖、Git 和链接。空项目 / 未准备基线返回 `blocked` 和准备说明，不调用模型、不自动复制蓝本。根目录布局及计划新建源码文件不因此被误拒。扫描上限未能确认文件时如实报告，不断言为空。
- 规划输出区分 `ready` 和 `blocked`。阻塞必须包含原因且不能夹带 worker 任务；不为同一个有效阻塞反复规划。`plan_only` 仅限制执行阶段，不把未来实施计划改成只读研究。
- 口头叫法差异不是自动 mismatch；真实接口、资产版本、用户硬要求或必需材料冲突仍需停止并说明证据。构建、参考页面获取和实际模型费用统计继续由主会话完成，不向子代理扩大权限。
- `blocked` 是未实施，不是成功交付。后台 jobs 显示失败并带具体原因，完整报告保留 `status=blocked`。历史配置和结果不改写，准备完成后的重试使用新任务 ID。
- 本版是故障修复，未实现工具/Skills 按任务分配设计；没有自动实施 arm-a4 的游动增强。

## 安装

运行环境：Node.js 22+；本版本在 DSH `0.2.0-rc.2` 上测试。宿主必须提供 `tools.guard`、`agent/created` 创建屏障、原生 `spawn` 子代理和精确模型能力解析接口。其他版本通过运行时能力检查后仍应先在测试项目验收。

从 DSH 插件管理器安装本地 `dsh-orchestrator-0.2.4.tgz`，并启用插件。也可使用 DSH 的插件命令：

```powershell
dsh plugin --profile desktop add ./dsh-orchestrator-0.2.4.tgz
```

Desktop 的命令行包管理请遵守宿主提示，在完全退出应用后操作；通过应用内插件管理器安装则由宿主管理生命周期。本包没有安装脚本，不安装浏览器、模型 SDK 或额外服务。正常包管理安装会从宿主环境解析 `@deepseek-ai/dsh-tools` peer dependency。安装后刷新 DSH 页面；若宿主未动态加载新增 bundle，重启一次 DSH。

服务端 JavaScript 更新后，请先停止活动编排，再完整退出并重启 DSH；仅刷新 GUI 不会更新已缓存的模块及其依赖。新安装或升级后，先在独立测试项目验收，再用于正式项目。

## 使用

1. 在目标 DSH 会话顶部或输入框旁点击「✦ AI 编排」。新空白会话也有输入区入口，不需要终端、外部启动器或手动打开地址。
2. 弹窗显示绑定的目标会话，并自动带入工作目录。分别设置 planner / worker / reviewer 的模型与档位、任务、允许修改路径和受保护文件。
3. 点击「开始编排」。插件保存独立任务，自动向打开弹窗的那个会话发送执行指令；无需复制 JSON 或任务 ID。
4. 空闲会话会自动开始处理。忙碌会话通过宿主原生 queue 排到本轮结束后执行，保持已有输入草稿和附件；投递确认不代表任务已经完成。
5. 关闭弹窗，回会话查看编排和后台任务。结束后主会话按返回的 `nextAction.checks` 逐条执行项目构建与测试；`needs_validation` 表示修改与只读复核完成，尚需项目验证，不代表复核者运行过任何东西。

会话切换会关闭旧弹窗。消息校验来源、确切 iframe、私有 nonce、目标会话和任务 UUID；重复提交复用任务，客户端及宿主请求 ID 防止重复接纳。发送结果不确定时锁住该配置，提示先查看会话。

插件列表里的配置页及 `orchestrate_settings` 仍可单独打开，用于保存默认值和查看记录。独立页面没有目标会话，保留「生成任务，不执行」和复制指令流程；日常直接从会话按钮启动即可。

客户端界面内嵌在插件 bundle，复用已有设置 API，不另起 GUI 服务。修改客户端源码后先执行 `npm run build`。宿主启用 client-hmr 时会读取新 bundle；没有该接收器时需要重新激活插件或重启宿主。普通页面刷新不能替代服务端模块重载。

同一实例的任意会话都能按 ID 查找任务。执行会绑定发起工具调用的会话；这不需要继承创建任务时的对话历史。任务只允许启动一次，重跑需生成新任务。同一项目或父子目录的编排不能同时运行。多个独立 DSH 进程不共享内存运行锁，请勿让它们同时编排同一工作副本。

设置页链接包含本机访问 token，勿分享给他人；重载插件后请重新获取链接。页面仅注册在 DSH 已有的 Web 服务，不启动第二个服务。没有 Web 服务的宿主可通过工具创建和查询任务。

## 工具

- `orchestrate_settings()`：返回可视化配置页入口、兼容状态和数据位置。
- `orchestrate_task({ action: "create", config })`：校验并保存新任务，不请求模型完成任务。`get` 加 `task_id` 查询配置和记录；`list` 列出任务。
- `orchestrate_run({ task_id, plan_only?, run_in_background? })`：执行已保存任务。`plan_only` 只规划，不修改项目。后台执行通过 `job_output` 查看、`job_kill` 取消。

任务配置示例，模型 ID 应替换为本机已配置的模型：

```json
{
  "task": "给现有速度设置添加边界检查，并保留现有导出接口",
  "projectRoot": "D:/projects/example",
  "planner": { "provider": "my-claude-route", "model": "configured-claude-model" },
  "worker": { "provider": "my-worker-route", "model": "configured-claude-deepseek-or-qwen-model" },
  "reviewer": { "provider": "my-gpt-route", "model": "configured-gpt-model" },
  "maxWorkers": 2,
  "maxPlanRetries": 1,
  "allowedGlobs": ["src/**"],
  "protectedFiles": ["src/core.js"],
  "allowProtected": false,
  "verifyHint": "使用项目已有的测试命令验证，不生成新锁文件"
}
```

也接受旧启动器的 `strongProvider/strongModel/cheapProvider/cheapModel`、`plannerEffort/workerEffort`，新增 `reviewerProvider/reviewerModel/reviewerEffort` 平铺形式，以及 `adapter` 文件范围字段。推荐使用三套嵌套角色对象；仅 reviewer 完全缺省时沿用 planner，部分填写 reviewer 不会触发兼容回退。旧任务文件本身不会自动导入：让助手读取它，再用 `orchestrate_task` 的 `create` 保存为独立任务即可。

档位只显示所选模型适配器声明的选项，创建任务和运行前都按精确路由校验。不支持的档位会报错，不会偷偷降级。选择「不指定」省略 effort，保留 DSH 的继承 / 默认语义：同路由可能继承父会话的 effort，换路由则由该模型默认行为决定。需要可重复配置时，请显式选择档位。

允许路径支持项目相对 glob：`*` 匹配单个路径段，`**` 匹配多层，`?` 匹配单个字符；不支持 brace、字符类或排除表达式。Worker 实际权限始终是计划中列出的确切文件，不会获得整条 glob 的写权限。

## 数据断言（本版新增）

除了源码编排，任务可以带一组「需实际执行」的数据校验。选择方式与选模型一致：

- 工具：`orchestrate_task` 的 `config.assertions`
- 设置页：模型面板下方的「数据断言」面板
- 粒度：包 `geo.vector` / 组 `geo.vector/geojson` / 单条 `geom.ring.closed`

选中后分两个阶段生效。

**① 提示词注入**

| 角色 | 拿到什么 |
|---|---|
| planner | 「已启用数据断言 + 命令」，并被告知这是主会话待运行验证，不要为它派发源码任务 |
| worker | 验收条件里的完整判定规则，含 `not_applicable ≠ pass`、禁止放宽阈值换绿 |
| reviewer | 实测结果原件（退出码、执行条数、findings 与归属），不是「主会话还没跑」这种模糊状态 |

**② worker 之后的断言闸门**

worker 全部结束后，插件自己执行一次断言（`run.mjs --profile=ci --json`），捕获退出码与 JSON，不经过任何模型转述。

放行必须同时满足三条：`exit_code === 0`、`status === 'pass'`、`checks_run > 0`。
`not_applicable` 的退出码也是 0，但它表示「范围内没有可检查的数据」，因此**绝不放行**——否则配置写错、路径配错都会静默跳过全部复核。

放行之后走哪条路由由 `reviewMode` 决定：

| reviewMode | 行为 |
|---|---|
| `always`（默认） | 无论断言是否通过，都做一次独立只读复核 |
| `on_failure` | 断言通过就放行（`verdict=passed_by_assertions`），失败或警告才交 reviewer 分析 |

失败项按归属分流：路径在某个 worker 的归属文件里 → 进定向修复轮；不在（数据文件、数据库）→ 标 `blocked_by_data` 直接交回主会话，不派修复任务去改它本来就改不了的文件。修复轮之后会再复验一次，reviewer 拿到的是修复后的实测结果。

**插件直接执行断言是这条路里唯一的破例**：命令由插件自己拼（参数取自创建时已校验的选择），只读、无副作用，超时 180s、输出上限 2 MB。它仍然不跑项目的构建和测试。选中的项在创建任务时就会对照断言目录校验，写错名字当场报错而不是运行时静默跳过。

断言实现住在 `assertions/`，12 条，覆盖 GeoJSON 结构、坐标范围、拓扑、属性契约、投影往返、数据库有效性与原始报文对账。自带样本自测：`node assertions/test/self-test.mjs`。

未选择任何断言时不产生提示词段落，行为与 0.2.12 一致。

## 执行与文件权限

- planner 先读取项目，明确返回可实施的 `ready` 计划或带原因的 `blocked`。纯代码校验任务 ID、互斥文件、允许路径、受保护文件、接口提供者及逐字一致的签名。无效计划可重试 0–2 次，有效阻塞直接返回主会话。
- planner 任务结构将实施目标、硬约束、建议步骤分开；宿主检查字段、长度与接口声明，但不声称能机械判断自然语言含义或证明实际代码满足接口。
- planner 随计划提供全部任务的源码自检；只有多任务或跨任务依赖计划才额外进行一次独立复核（独立路由，缺省沿用 planner）。宿主逐项验证 ID、状态、证据、问题与总体状态的一致性。待澄清/受阻返回主会话，不启动实施 worker；复核会话本身运行失败（坏帧、缺结构化结果、结构校验不过）降级为 planner 自检继续并在报告标注 `feasibilityDegraded`，权限/预算/路径类拒绝仍然失败关闭。
- 只有全部确认可行后，才保存计划文件原始字节和 SHA-256，并启动实施 worker；单文件上限 5 MiB，单次总量上限 50 MiB。超限会在写入前停止。
- 每次子代理启动使用独立 AsyncLocalStorage 记录；被 await 的 `agent/created` 阶段验证准确父子归属并绑定权限。没有成功绑定就拒绝工具执行。
- planner / feasibility / reviewer 只有 read、glob、grep；仅实施 worker 加 write、edit。shell、网络、浏览器、委派等能力不在白名单。工具 guard 按工具真实路径字段检查绝对路径、项目边界、符号链接 / junction 和 worker 文件归属。
- 权限按准确 Agent 引用与任务管理，其他插件或普通子代理不受本插件限制。没有全局 pending 认领表，也没有负责写权限 JSON 的 scribe。
- worker 失败、mismatch、缺少结构化结果或文件没有实际变化都会让任务失败。一个 worker 失败会取消同任务其他活动子代理；失败后可回滚（见下一条），取消同样回滚。
- **失败回滚**：进入写入阶段后（快照已保存），`failed` 与 `cancelled` 会把计划文件还原到运行前字节，并把新文件删除。还原只撤销「自己写下的内容」：先用 `before`/`after`/当前三方哈希确认磁盘仍是本次运行留下的样子，运行结束后被外部改过的文件会以 `conflict` 跳过、绝不覆盖；没有运行后基线的文件以 `skipped` 跳过。写回前校验备份 sha256，单个文件失败不影响其他文件。结果记在 `report.rollback{reason,changed,conflicts,failed,files}` 与事件流 `rollback`。`review_failed` 与 `needs_validation` 不回滚（改动需要人工查看），可用 `node scripts/restore.mjs <task-id> [run-id] [--dry-run]` 手工还原。`rollbackOnFailure: false` 可关闭自动回滚，保留失败现场。
- 修改完成后独立 reviewer 模型只读复核实际文件，列出仍需执行的验证；它没有运行测试的权限。接口声明校验不替代语言编译器或项目测试。
- 复核结论分三档：`verified_statically`（只读静态未发现冲突，且已列出待验证项）、`issues_found`（有具体缺陷，必须给出可定位条目）、`unable_to_verify`（材料不足或必须实测才能定论）。旧的 `ready_for_validation` 读取时归一为 `verified_statically`，历史报告不改写。
- 待验证项是结构化的 `checks[{id,kind,statement,command,expected,owner?}]`，`kind` 为 `build|runtime|visual|static|data|process`；`build`/`runtime`/`data` 应给出可执行 `command`，`owner:"main"` 的条目例外（见 v0.2.12）。宿主只校验形状与可判定性，不执行这些命令。`nextAction.checksNeeded` 仍保留扁平字符串数组，兼容既有消费方。

这是 DSH 工具层的约束，不是操作系统进程沙箱。不对其他程序并发改动项目、恶意第三方插件直接写磁盘或外部并发替换链接提供隔离保证。快照只覆盖计划文件，不包含整个仓库，也不能代替版本控制。

## 数据与卸载

默认保存在 `$DSH_ORCHESTRATOR_HOME`，未设置时使用 `$DSH_HOME/storages/orchestrator`（默认 `~/.dsh/storages/orchestrator`）。部署者也可在插件配置中提供绝对 `storageDir`。页面会显示当前路径。

```text
orchestrator/
  defaults.json
  jobs/<task-id>/
    job.json                 # 不可变配置
    status.json
    runs/<run-id>.json       # 阶段、子会话 ID、配置、结果、文件哈希
    snapshots/<run-id>/
      manifest.json          # 文件对应关系与修改前哈希
      0.bin                  # 原始字节，编号见 manifest
      repair-1/              # 定向修复阶段的快照（同样结构）
```

每次请求的真实 provider/model/effort 仍由 DSH 自身会话日志记录；插件报告中的 requested 是请求的配置，不能代替真实请求头。费用由已启用的 DSH 计费插件记录，本版本没有自己的费率估算或成本对照面板。

卸载 / 停用不会删除任务、报告或备份。请先停止编排任务，再通过插件管理器停用；不需要恢复任何安装目录补丁。若本机此前装有实验版 `dsh-fs-claims`，应停用旧插件，避免两套权限机制同时工作。正常用户安装不要求这个旧插件。

## 开发验证

```powershell
npm test
npm run check
```

`test` 使用隔离测试目录和子代理服务替身，不调用模型。测试覆盖路径、签名、并发、权限绑定、取消、持久化失败、API token、独立任务与默认设置。设置 `DSH_APP_ROOT` 可额外使用已安装 DSH 的真实 `defineTool` 验证 schema，并使用真实 pi-ai / DeepSeek 专用适配器、虚构模型路由及本地模拟 HTTP SSE 接口，检查 Anthropic Messages / OpenAI Completions / Responses 的工具结构、思考参数映射和结构化结果回传，以及 DeepSeek 专用适配器的 off/low/high/max。这不访问外部 API，也不证明某个真实供应商、模型版本或账户已验收。

`test-artifacts` 和 `local-validation` 是本机验收数据，不进入分发包；`node_modules`、测试浏览器 profile、任务数据和 token 均不打包。开发辅助脚本不属于发布包的运行依赖。
