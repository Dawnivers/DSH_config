// 必填属性：要素必须带齐项目声明的属性。
// 依据是"项目约定"，不是规范 —— 所以取值来自 checks.config.mjs 的 requiredProperties。
// 没配 requiredProperties 时这条断言不适用（applicable: false），而不是"通过"。

import { toFeatures } from '../../lib/geo.mjs';

export const meta = {
  id: 'schema.required-properties',
  pack: 'geo.vector',
  group: 'schema',
  spec: '项目约定',
  severity: 'error',
  appliesTo: ['**/*.geojson', '**/*.json'],
  description: '要素必须包含配置声明的必填属性',
};

export function run({ doc, config }) {
  const required = config.requiredProperties ?? [];
  if (required.length === 0) {
    return { applicable: false, reason: '配置未声明 requiredProperties' };
  }

  const issues = [];
  toFeatures(doc).forEach((feature, fi) => {
    const props = feature.properties ?? {};
    for (const key of required) {
      const v = props[key];
      if (v === undefined || v === null || v === '') {
        issues.push({
          locator: { feature: fi, property: key },
          message: `要素缺少必填属性 "${key}"`,
          hint: '要么补齐属性，要么把该字段从 requiredProperties 里移除（二选一，别留半套）',
        });
      }
    }
  });

  return { issues, skipped: [] };
}
