// 坐标往返：经 pyproj 投影到目标 CRS 再投回来，误差必须收敛。
// 这条断言真正能抓的是"值域与声明的 CRS 不一致"——
// 比如把米制坐标标成 EPSG:4326，往返会炸到几十公里。
//
// 依赖：python + pyproj。缺了会如实报"不适用"，不会假装通过。

import { iterPositions, toFeatures } from '../../lib/geo.mjs';
import { runPython } from '../../lib/py.mjs';

export const meta = {
  id: 'crs.roundtrip.pyproj',
  pack: 'geo.vector',
  group: 'crs',
  spec: 'EPSG / PROJ 往返一致性',
  severity: 'error',
  appliesTo: ['**/*.geojson', '**/*.json'],
  description: '坐标投影往返误差是否收敛',
};

const SCRIPT = `
import sys, json, math
cfg = json.load(sys.stdin)
try:
    from pyproj import Transformer
except ImportError:
    sys.stderr.write("No module named 'pyproj'\\n")
    sys.exit(3)

src = cfg.get('source') or 'EPSG:4326'
dst = cfg.get('target') or 'EPSG:3857'
fwd = Transformer.from_crs(src, dst, always_xy=True)
inv = Transformer.from_crs(dst, src, always_xy=True)

worst = 0.0
worst_pair = None
failures = 0
pts = cfg.get('points') or []
for p in pts:
    x, y = float(p[0]), float(p[1])
    try:
        x2, y2 = fwd.transform(x, y)
        x3, y3 = inv.transform(x2, y2)
    except Exception:
        failures += 1
        continue
    if x3 != x3 or y3 != y3:
        failures += 1
        continue
    d = math.hypot(x3 - x, y3 - y)
    if d > worst:
        worst = d
        worst_pair = [x, y, x3, y3]

R = 6371008.8
def meters(lon1, lat1, lon2, lat2):
    p1 = math.radians(lat1); p2 = math.radians(lat2)
    dp = p2 - p1; dl = math.radians(lon2 - lon1)
    a = math.sin(dp/2)**2 + math.cos(p1)*math.cos(p2)*math.sin(dl/2)**2
    return 2 * R * math.asin(min(1.0, math.sqrt(a)))

max_m = meters(worst_pair[0], worst_pair[1], worst_pair[2], worst_pair[3]) if worst_pair else 0.0
print(json.dumps({
    'max_error_deg': worst,
    'max_error_m': max_m,
    'worst': worst_pair,
    'failures': failures,
    'checked': len(pts),
    'source': src,
    'target': dst,
}))
`;

export function run({ doc, config }) {
  const crs = config.crs;
  if (!crs?.python) {
    return { applicable: false, reason: '未配置 crs.python（需要 python + pyproj）' };
  }

  const points = samplePositions(doc, crs.sample ?? 2000);
  if (points.length === 0) {
    return { applicable: false, reason: '几何里没有坐标' };
  }

  const res = runPython({
    python: crs.python,
    script: SCRIPT,
    input: { source: crs.source, target: crs.target, points },
    timeoutMs: crs.timeoutMs ?? 60000,
  });

  if (!res.ok) {
    if (res.missing.length) {
      return { applicable: false, reason: `python 缺包：${res.missing.join(', ')}` };
    }
    return {
      issues: [
        {
          severity: 'error',
          locator: {},
          message: `投影往返无法执行：${res.error}`,
          hint: '这是环境问题（python / pyproj / 脚本），不是数据问题；修好环境再跑',
        },
      ],
    };
  }

  const data = res.data;
  const limit = crs.maxRoundtripMeters ?? 1;
  const issues = [];

  if (data.failures > 0) {
    issues.push({
      severity: 'error',
      locator: {},
      message: `${data.failures}/${data.checked} 个坐标在 ${data.source} → ${data.target} 往返中失败（得到 NaN 或抛异常）`,
      hint: '通常是坐标值或其量级与声明的 CRS 不符',
    });
  }

  if (data.max_error_m > limit) {
    const idx = data.worst ? points.findIndex((p) => p[0] === data.worst[0] && p[1] === data.worst[1]) : -1;
    issues.push({
      severity: 'error',
      locator: { vertex: idx >= 0 ? idx : 0 },
      message:
        `投影往返误差 ${data.max_error_m.toFixed(3)} m 超过上限 ${limit} m` +
        (data.worst ? `，最差点 [${data.worst[0]}, ${data.worst[1]}] 往返后为 [${data.worst[2].toFixed(6)}, ${data.worst[3].toFixed(6)}]` : ''),
      hint: `确认数据实际是什么 CRS；现在是按 ${data.source} → ${data.target} 解释的`,
    });
  }

  return { issues };
}

/** 均匀抽样，避免只看到文件开头 */
function samplePositions(doc, limit) {
  const all = [];
  for (const feature of toFeatures(doc)) {
    for (const p of iterPositions(feature.geometry?.coordinates)) {
      all.push([p[0], p[1]]);
      if (all.length >= 200000) break;
    }
    if (all.length >= 200000) break;
  }
  if (all.length <= limit) return all;

  const stride = all.length / limit;
  const out = [];
  for (let i = 0; i < limit; i++) out.push(all[Math.floor(i * stride)]);
  return out;
}
