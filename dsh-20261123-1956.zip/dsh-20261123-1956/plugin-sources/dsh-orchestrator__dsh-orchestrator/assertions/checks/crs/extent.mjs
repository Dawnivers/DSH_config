// 坐标必须落在项目声明的范围内。
// 纯 JS，无外部依赖，是最便宜的一道回归闸门。
// 能抓：经纬度写反、混进 (0,0)、GCJ 与 WGS 混用导致整体偏移、误把别省数据塞进来。
//
// 范围由项目配置声明（extent），不是写死的"武汉"——
// 换个项目只改配置，不改断言。

import { iterPositions, toFeatures } from '../../lib/geo.mjs';

export const meta = {
  id: 'crs.extent.within',
  pack: 'geo.vector',
  group: 'coords',
  spec: '项目约定（AOI 范围）',
  severity: 'error',
  appliesTo: ['**/*.geojson', '**/*.json'],
  description: '坐标是否落在项目声明的范围内',
};

const MAX_ISSUES = 50;

export function run({ doc, config }) {
  const e = config.extent;
  if (!e || e.minLon == null || e.minLat == null || e.maxLon == null || e.maxLat == null) {
    return { applicable: false, reason: '未配置 extent（minLon/minLat/maxLon/maxLat）' };
  }

  const pad = e.buffer ?? 0;
  const minLon = e.minLon - pad;
  const minLat = e.minLat - pad;
  const maxLon = e.maxLon + pad;
  const maxLat = e.maxLat + pad;

  const issues = [];
  let outside = 0;

  toFeatures(doc).forEach((feature, fi) => {
    let vi = -1;
    for (const p of iterPositions(feature.geometry?.coordinates)) {
      vi += 1;
      if (p[0] >= minLon && p[0] <= maxLon && p[1] >= minLat && p[1] <= maxLat) continue;

      outside += 1;
      if (issues.length >= MAX_ISSUES) continue;

      issues.push({
        locator: { feature: fi, vertex: vi },
        message: `坐标 [${p[0]}, ${p[1]}] 超出项目范围 [${e.minLon}, ${e.minLat}, ${e.maxLon}, ${e.maxLat}]`,
        hint: hintFor(p, e),
      });
    }
  });

  if (outside > issues.length) {
    issues.push({
      locator: {},
      message: `另有 ${outside - issues.length} 个越界坐标未逐条列出（上限 ${MAX_ISSUES}）`,
      hint: '',
    });
  }

  return { issues };
}

function hintFor(p, e) {
  const [x, y] = p;

  // 经纬度写反：x 看起来像纬度、y 看起来像经度
  if (Math.abs(x) <= 90 && Math.abs(y) > 90) {
    return '看起来经纬度顺序反了：x 在 ±90 内而 y 超过 90，RFC 7946 要求 [经度, 纬度]';
  }
  if (x === 0 && y === 0) {
    return '是 (0,0) 空值哨兵：说明这条记录的坐标没取到，应移除或补真实坐标';
  }
  if (Math.abs(x) > 180 || Math.abs(y) > 90) {
    return '值域超出经纬度，可能不是 EPSG:4326（投影坐标？）';
  }
  const dx = Math.abs(x - (e.minLon + e.maxLon) / 2);
  if (dx > 0.02 && dx < 5) {
    return '离项目中心有 2 km 以上偏移，可能是 GCJ-02 与 WGS84 混用，或用了邻近区域的数据';
  }
  return '确认这份数据是否属于本项目范围';
}
