// 数据库里的几何必须通过 PostGIS 的 ST_IsValid。
//
// 为什么值得单独有一条：GEOS/PostGIS 的校验比纯 JS 版更全
// （环间嵌套、洞越界、各部分共边都能判）。纯 JS 版是快速闸门，
// 这条是权威判定——两者结论不一致时，以这条为准。
//
// 整项目级断言：不针对某个文件，整个项目跑一次。

import { ident, psqlAvailable, psqlQuery } from '../../lib/pg.mjs';

export const meta = {
  id: 'db.geom.invalid',
  pack: 'geo.vector',
  group: 'db',
  spec: 'OGC SFA / PostGIS ST_IsValid',
  severity: 'error',
  perProject: true,
  appliesTo: ['**/*'],
  description: '数据库中的几何是否通过 ST_IsValid',
};

export function run({ config, root }) {
  const db = config.db;
  if (!db?.table) {
    return { applicable: false, reason: '未配置 db.table' };
  }
  if (!psqlAvailable(db)) {
    return { applicable: false, reason: `找不到 psql 命令（配置 db.psql 可指定完整路径）` };
  }

  let table;
  let geomCol;
  let idCol;
  try {
    table = ident(db.table, 'table');
    geomCol = ident(db.geomColumn, 'geom');
    idCol = ident(db.idColumn, 'id');
  } catch (err) {
    return { issues: [{ severity: 'error', locator: {}, message: err.message, hint: 'db 配置里的表名/列名只允许字母数字下划线' }] };
  }

  let total;
  try {
    const rows = psqlQuery(db, `SELECT count(*) FROM ${table}`, { root });
    total = Number(rows[0]?.[0] ?? 0);
  } catch (err) {
    return {
      issues: [
        {
          severity: 'error',
          locator: { table },
          message: `连不上数据库或表不存在：${err.message}`,
          hint: '检查 db.host/port/user/database 与 PGPASSWORD（可用 db.envFile 指定 .env）',
        },
      ],
    };
  }

  if (total === 0) {
    return { applicable: false, reason: `表 ${table} 为空，无可校验的几何` };
  }

  let rows;
  try {
    rows = psqlQuery(
      db,
      `SELECT ${idCol}, ST_IsValidReason(${geomCol}) FROM ${table} ` +
        `WHERE ${geomCol} IS NOT NULL AND NOT ST_IsValid(${geomCol}) ORDER BY ${idCol}`,
      { root }
    );
  } catch (err) {
    return {
      issues: [{ severity: 'error', locator: { table }, message: `ST_IsValid 查询失败：${err.message}`, hint: '' }],
    };
  }

  const issues = rows.map(([id, reason]) => ({
    severity: 'error',
    locator: { table, [idCol]: id },
    message: `${table}.${idCol}=${id} 几何无效：${reason}`,
    hint: hintFor(reason),
  }));

  return { issues };
}

function hintFor(reason) {
  if (/Self-intersection/i.test(reason)) {
    return 'GEOS 报 Self-intersection 时，常见其实是 MultiPolygon 各部分共边；先确认是不是这种，再用 ST_Union 合并而不是挪顶点';
  }
  if (/Ring Self-intersection/i.test(reason)) {
    return '环自己穿过自己：需要拆分环或挪开交叉点';
  }
  if (/Hole lies outside shell/i.test(reason)) {
    return '洞落在外环外：环的归属关系错了，重新组织 polygon 的环列表';
  }
  if (/Nested shells/i.test(reason)) {
    return '两个外环嵌套：内层应作为洞处理，或者拆成独立要素';
  }
  if (/Too few points/i.test(reason)) {
    return '顶点太少：环至少要 4 个点且首末闭合';
  }
  return '用 ST_MakeValid 试修复，并对比修复前后面积差异是否可接受';
}
