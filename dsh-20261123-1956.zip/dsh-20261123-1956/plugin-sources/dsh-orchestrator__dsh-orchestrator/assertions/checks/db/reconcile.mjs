// 原始采集报文与数据库行数对账。
//
// 存在的理由：上游抓了多少、清洗后入库多少，这个差值必须有人看着。
// 差值不说话时是正常的口径差；差值突然变化时是抓取或清洗出了 bug。
//
// 抽取规则放在项目配置里（reconcile.extractIds 是一个函数），
// 因为"原始报文长什么样"是项目知识，不是断言库知识。

import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';

import { walkFiles } from '../../lib/engine.mjs';
import { createMatcher } from '../../lib/glob.mjs';
import { ident, psqlAvailable, psqlQuery } from '../../lib/pg.mjs';

export const meta = {
  id: 'db.reconcile.raw-vs-db',
  pack: 'geo.vector',
  group: 'reconcile',
  spec: '项目约定（数据口径）',
  severity: 'error',
  perProject: true,
  appliesTo: ['**/*'],
  description: '原始报文与数据库行数/去重数是否对得上',
};

export function run({ config, root }) {
  const rec = config.reconcile;
  if (!rec?.rawGlob || typeof rec.extractIds !== 'function') {
    return { applicable: false, reason: '未配置 reconcile.rawGlob / reconcile.extractIds' };
  }
  if (!config.db?.table && !rec.table) {
    return { applicable: false, reason: '未配置对账用的表（reconcile.table 或 db.table）' };
  }
  if (!psqlAvailable(config.db)) {
    return { applicable: false, reason: '找不到 psql 命令' };
  }

  // ---- 1. 扫原始报文 ----
  const match = createMatcher([rec.rawGlob]);
  const files = walkFiles(root, config.ignore ?? []).filter(match);
  if (files.length === 0) {
    return { applicable: false, reason: `没有匹配 ${rec.rawGlob} 的原始报文` };
  }

  let rawRows = 0;
  const rawIds = new Set();
  let parseFailures = 0;

  for (const rel of files) {
    let doc;
    try {
      doc = JSON.parse(readFileSync(resolve(root, rel), 'utf8'));
    } catch {
      parseFailures += 1;
      continue;
    }
    let ids;
    try {
      ids = rec.extractIds(doc) ?? [];
    } catch {
      parseFailures += 1;
      continue;
    }
    for (const id of ids) {
      rawRows += 1;
      if (id != null) rawIds.add(id);
    }
  }

  // ---- 2. 查数据库 ----
  const table = ident(rec.table ?? config.db?.table, 'table');
  const idCol = ident(rec.idColumn ?? config.db?.idColumn, 'id');

  let dbRows;
  let dbIds;
  try {
    dbRows = Number(psqlQuery(config.db, `SELECT count(*) FROM ${table}`, { root })[0]?.[0] ?? 0);
    dbIds = Number(psqlQuery(config.db, `SELECT count(DISTINCT ${idCol}) FROM ${table}`, { root })[0]?.[0] ?? 0);
  } catch (err) {
    return {
      issues: [
        {
          severity: 'error',
          locator: { table },
          message: `对账查询失败：${err.message}`,
          hint: '检查 db 配置与表是否存在',
        },
      ],
    };
  }

  // ---- 3. 比对 ----
  // 两种口径都支持：
  //   expected  —— 声明"差多少、为什么"，差值和声明不符就报错（推荐）
  //   tolerance —— 只允许小幅波动
  // 用 expected 的理由：差值本身是知识，写下来就变成回归闸门；
  // 只写容差等于把"为什么差"这件事丢掉了。
  const issueList = [];
  const rowsExp = rec.expected?.rowDelta;
  const idsExp = rec.expected?.idDelta;
  const why = rec.expected?.reason ? `；配置声明的原因：${rec.expected.reason}` : '';

  const rowDelta = dbRows - rawRows;
  const idDelta = dbIds - rawIds.size;

  const rowOk = rowsExp != null ? rowDelta === rowsExp : Math.abs(rowDelta) <= (rec.tolerance?.rows ?? 0);
  const idOk = idsExp != null ? idDelta === idsExp : Math.abs(idDelta) <= (rec.tolerance?.ids ?? 0);

  if (!rowOk) {
    issueList.push({
      severity: 'error',
      locator: { table },
      message:
        `行数对账不上：原始报文 ${rawRows} 行，库中 ${dbRows} 行，差 ${fmt(rowDelta)}` +
        (rowsExp != null ? `，配置声明应为 ${fmt(rowsExp)}` : `（容差 ±${rec.tolerance?.rows ?? 0}）`) +
        `；扫了 ${files.length} 个报文文件${parseFailures ? `，${parseFailures} 个解析失败` : ''}${why}`,
      hint: '先确认是不是抓取批次不全；再检查清洗阶段是否静默丢了行。差值变化说明口径变了，要重新解释而不是直接改期望值',
    });
  }

  if (!idOk) {
    issueList.push({
      severity: 'error',
      locator: { table },
      message:
        `去重 ID 对账不上：原始报文 ${rawIds.size} 个唯一 ID，库中 ${dbIds} 个，差 ${fmt(idDelta)}` +
        (idsExp != null ? `，配置声明应为 ${fmt(idsExp)}` : `（容差 ±${rec.tolerance?.ids ?? 0}）`) +
        why,
      hint:
        rowDelta !== 0 && Math.sign(idDelta) !== Math.sign(rowDelta)
          ? '行数与唯一 ID 的偏差方向不同，说明既有重复入库、也有丢行，要分开查'
          : '查是否有重复抓取，或清洗阶段的过滤条件变了',
    });
  }

  if (parseFailures > 0) {
    issueList.push({
      severity: 'warn',
      locator: {},
      message: `${parseFailures} 个原始报文解析失败或结构不符，未计入对账基数`,
      hint: '确认这些文件是残缺下载还是结构变更',
    });
  }

  return { issues: issueList };
}

function fmt(n) {
  return n >= 0 ? `+${n}` : String(n);
}
