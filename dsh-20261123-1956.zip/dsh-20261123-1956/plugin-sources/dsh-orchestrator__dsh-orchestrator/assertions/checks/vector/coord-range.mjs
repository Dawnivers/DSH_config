// 坐标范围：经度必须在 ±180、纬度必须在 ±90 之内。
// 依据 RFC 7946 §3.1.1（position 的 lon/lat 语义）与 RFC 7946 §4（WGS84）。
//
// 已知误报场景（务必注意）：
//   如果文件里是投影坐标（如 EPSG:3857，单位是米），这条会全红。
//   所以命中大数值时，提示语会直接指向"CRS 声明"，提醒这不是数据错而是坐标系错。

import { toFeatures, iterPositions } from '../../lib/geo.mjs';

export const meta = {
  id: 'geom.coord.range',
  pack: 'geo.vector',
  group: 'coords',
  spec: 'RFC 7946 §3.1.1, §4',
  severity: 'error',
  appliesTo: ['**/*.geojson', '**/*.json'],
  description: '经纬度必须在合法范围内',
};

const MAX_ISSUES = 200;

export function run({ doc }) {
  const issues = [];

  toFeatures(doc).forEach((feature, fi) => {
    let vertex = 0;
    for (const pos of iterPositions(feature.geometry?.coordinates)) {
      const [x, y] = pos;
      const bad = !Number.isFinite(x) || !Number.isFinite(y) || Math.abs(x) > 180 || Math.abs(y) > 90;
      if (bad) {
        if (issues.length >= MAX_ISSUES) return;
        const projected = Number.isFinite(x) && Math.abs(x) > 1000;
        issues.push({
          locator: { feature: fi, vertex },
          message:
            `坐标 [${x}, ${y}] 超出经纬度范围` +
            (projected ? '（数量级像投影坐标，不是度）' : ''),
          hint: projected
            ? '先确认 CRS：若为投影坐标，应在数据源转换到 EPSG:4326 再输出'
            : '检查是否混入了 (0,0)、空值或行列颠倒（lat/lon 写反）',
        });
      }
      vertex += 1;
    }
  });

  if (issues.length >= MAX_ISSUES) {
    issues.push({
      locator: {},
      message: `超出范围的坐标过多，仅列出前 ${MAX_ISSUES} 处`,
      hint: '这通常说明整份文件坐标系错了，先查 CRS 再逐点修',
    });
  }

  return issues;
}
