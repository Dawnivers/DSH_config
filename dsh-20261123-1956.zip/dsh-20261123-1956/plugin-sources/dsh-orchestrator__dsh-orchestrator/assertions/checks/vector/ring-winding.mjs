// 环方向：外环逆时针（CCW），内环顺时针（CW）。
// 依据 RFC 7946 §3.1.6 的 right-hand rule。
//
// 默认严重度是 warn 而不是 error，这是有意为之：
//   - 规范要求 so，但同一节也要求解析器 SHOULD NOT 因方向拒绝几何；
//   - 投影/渲染对方向不敏感，很多生产数据（含 Geofabrik 导出）不遵守；
//   - 自己产出的数据应该把这条提到 error，外部导入的数据保持 warn。
// 提升方式：配置里 severity: { 'geom.ring.winding': 'error' }

import { toFeatures, iterRings, signedArea } from '../../lib/geo.mjs';

export const meta = {
  id: 'geom.ring.winding',
  pack: 'geo.vector',
  group: 'geojson',
  spec: 'RFC 7946 §3.1.6',
  severity: 'warn',
  appliesTo: ['**/*.geojson', '**/*.json'],
  description: '外环应为逆时针、内环应为顺时针',
};

export function run({ doc }) {
  const issues = [];

  toFeatures(doc).forEach((feature, fi) => {
    for (const { ring, ringIndex, role } of iterRings(feature.geometry)) {
      const area = signedArea(ring);
      if (area === 0) continue; // 零面积由其他断言负责，这里不重复报

      const isCCW = area > 0;
      const wantCCW = role === 'exterior';
      if (isCCW !== wantCCW) {
        issues.push({
          locator: { feature: fi, ring: ringIndex, ringRole: role },
          message:
            `${role === 'exterior' ? '外环' : '内环'}方向为 ${isCCW ? '逆时针' : '顺时针'}，` +
            `规范要求 ${wantCCW ? '逆时针' : '顺时针'}（有向面积 ${area.toExponential(3)}）`,
          hint: '自己产出的数据应修正；第三方数据若渲染正常可加入 knownIssues',
        });
      }
    }
  });

  return issues;
}
