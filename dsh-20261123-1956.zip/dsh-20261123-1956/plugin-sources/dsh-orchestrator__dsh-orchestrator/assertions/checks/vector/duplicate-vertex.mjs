// 相邻重复顶点。
// 注意：这不是规范 MUST。OGC SFA 允许重复点，GEOS/PostGIS 也判 valid。
// 所以默认 warn：它几乎总是数据生成过程的小瑕疵，会拖慢渲染和空间索引，
// 但不会让几何失效。把它当 error 的项目应该在配置里显式提升。

import { toFeatures, iterRings, samePosition } from '../../lib/geo.mjs';

export const meta = {
  id: 'geom.vertex.duplicate-adjacent',
  pack: 'geo.vector',
  group: 'geojson',
  spec: '项目约定（非规范 MUST）',
  severity: 'warn',
  appliesTo: ['**/*.geojson', '**/*.json'],
  description: '环内不应出现相邻的重复顶点',
};

const MAX_ISSUES = 100;

export function run({ doc, tolerances }) {
  const eps = tolerances.coord;
  const issues = [];

  toFeatures(doc).forEach((feature, fi) => {
    for (const { ring, ringIndex, role } of iterRings(feature.geometry)) {
      if (!Array.isArray(ring)) continue;
      for (let i = 1; i < ring.length; i++) {
        if (!samePosition(ring[i - 1], ring[i], eps)) continue;
        if (issues.length >= MAX_ISSUES) return;
        issues.push({
          locator: { feature: fi, ring: ringIndex, ringRole: role, vertex: i },
          message: `第 ${i - 1} 与第 ${i} 个顶点重复：[${ring[i][0]}, ${ring[i][1]}]`,
          hint: '去掉重复点；若是闭合处理产生的，检查是否重复追加了首点',
        });
      }
    }
  });

  return issues;
}
