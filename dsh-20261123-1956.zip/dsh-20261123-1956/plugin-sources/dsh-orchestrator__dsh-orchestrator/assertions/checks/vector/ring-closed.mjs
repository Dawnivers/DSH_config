// 环必须闭合：首末坐标相等。
// 依据 RFC 7946 §3.1.6：linear ring 的 MUST —— 第一个和最后一个 position 必须是相同值。

import { toFeatures, iterRings, samePosition, isPosition } from '../../lib/geo.mjs';

export const meta = {
  id: 'geom.ring.closed',
  pack: 'geo.vector',
  group: 'geojson',
  spec: 'RFC 7946 §3.1.6',
  severity: 'error',
  appliesTo: ['**/*.geojson', '**/*.json'],
  description: '每个线性环的首末坐标必须相等',
};

export function run({ doc, tolerances }) {
  const eps = tolerances.coord;
  const issues = [];

  toFeatures(doc).forEach((feature, fi) => {
    for (const { ring, ringIndex, role } of iterRings(feature.geometry)) {
      if (!Array.isArray(ring) || ring.length < 2) {
        issues.push({
          locator: { feature: fi, ring: ringIndex, ringRole: role },
          message: `环只有 ${ring?.length ?? 0} 个坐标，无法闭合`,
          hint: '环至少要有 4 个坐标（3 个不同点 + 重复首点）',
        });
        continue;
      }
      const first = ring[0];
      const last = ring[ring.length - 1];
      if (!isPosition(first) || !isPosition(last)) {
        issues.push({
          locator: { feature: fi, ring: ringIndex, ringRole: role },
          message: '环的首末坐标不是合法的 [x, y] 数组',
        });
        continue;
      }
      if (!samePosition(first, last, eps)) {
        const d = Math.hypot(first[0] - last[0], first[1] - last[1]);
        issues.push({
          locator: { feature: fi, ring: ringIndex, ringRole: role, vertex: ring.length - 1 },
          message: `环未闭合：首点 ${fmt(first)} 与末点 ${fmt(last)} 相差 ${d.toExponential(2)} 度`,
          hint: '把末点改成与首点完全相同（不要"接近"）',
        });
      }
    }
  });

  return issues;
}

function fmt(p) {
  return `[${p[0].toFixed(6)}, ${p[1].toFixed(6)}]`;
}
