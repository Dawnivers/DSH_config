// 同一几何内不同环之间不得交叉、不得共边重叠。
// 依据 OGC SFA / ISO 19125：MultiPolygon 的各部分只能"在有限个点上接触"，
// 不允许共用一条边（无限个点）。共享边在 GEOS/PostGIS 里表现为
// ST_IsValid=false，reason 却是 "Self-intersection"，很容易误判成环内自交。
//
// 允许：点接触（两个多边形只在一个顶点处相接）—— 这是有效的。
// 禁止：真穿越（cross）、共线重叠（overlap，即共边）。

import { toFeatures, iterRings, segmentsConflict, samePosition } from '../../lib/geo.mjs';

export const meta = {
  id: 'geom.multipolygon.shared-edge',
  pack: 'geo.vector',
  group: 'topology',
  spec: 'OGC SFA / ISO 19125',
  severity: 'error',
  appliesTo: ['**/*.geojson', '**/*.json'],
  description: '同一几何的不同环之间不得交叉或共边',
};

const MAX_ISSUES_PER_FEATURE = 5;
const MAX_PAIR_OPS = 4_000_000;

export function run({ doc, limits, tolerances }) {
  const eps = tolerances.coord;
  const issues = [];
  const skipped = [];

  toFeatures(doc).forEach((feature, fi) => {
    const rings = [...iterRings(feature.geometry)];
    if (rings.length < 2) return; // 单环几何没有"环间关系"

    let reported = 0;

    for (let a = 0; a < rings.length && reported < MAX_ISSUES_PER_FEATURE; a++) {
      for (let b = a + 1; b < rings.length && reported < MAX_ISSUES_PER_FEATURE; b++) {
        const r1 = rings[a];
        const r2 = rings[b];
        if (!Array.isArray(r1.ring) || !Array.isArray(r2.ring)) continue;
        if (r1.ring.length < 4 || r2.ring.length < 4) continue;
        if (!bboxOverlap(r1.ring, r2.ring)) continue;

        const ops = (r1.ring.length - 1) * (r2.ring.length - 1);
        if (ops > MAX_PAIR_OPS) {
          skipped.push({ reason: `环对 ${a}/${b} 需 ${ops} 次比较，超过上限 ${MAX_PAIR_OPS}` });
          continue;
        }

        const hit = ringsConflict(r1.ring, r2.ring, eps);
        if (!hit) continue;

        reported += 1;
        const at = r1.ring[hit.i] ?? r1.ring[0];
        issues.push({
          locator: {
            feature: fi,
            ring: r1.ringIndex,
            ringRole: `${r1.role} vs ${r2.role}(poly ${r1.polygonIndex}/${r2.polygonIndex})`,
            vertex: hit.i,
          },
          message:
            `环之间${hit.kind === 'cross' ? '交叉' : '共边重叠'}：` +
            `多边形 ${r1.polygonIndex} 的环与多边形 ${r2.polygonIndex} 的环在 [${at[0].toFixed(6)}, ${at[1].toFixed(6)}] 附近` +
            `${hit.kind === 'overlap' ? '共用边' : '相交'}`,
          hint:
            hit.kind === 'overlap'
              ? '这不是环内自交，而是 MultiPolygon 各部分共边；用 ST_Union/ST_MakeValid 合并相邻部分，或拆成各自独立的要素'
              : '显式检查这两个多边形的拓扑，通常需要重算或合并',
        });
      }
    }
  });

  return { issues, skipped };
}

function bboxOverlap(r1, r2) {
  const b1 = bbox(r1);
  const b2 = bbox(r2);
  return !(b1[2] < b2[0] || b2[2] < b1[0] || b1[3] < b2[1] || b2[3] < b1[1]);
}

function bbox(ring) {
  let minx = Infinity;
  let miny = Infinity;
  let maxx = -Infinity;
  let maxy = -Infinity;
  for (const p of ring) {
    if (!Array.isArray(p)) continue;
    if (p[0] < minx) minx = p[0];
    if (p[0] > maxx) maxx = p[0];
    if (p[1] < miny) miny = p[1];
    if (p[1] > maxy) maxy = p[1];
  }
  return [minx, miny, maxx, maxy];
}

/** 只关心 cross 与 overlap；pinch（端点落在另一环的边上）按 OGC 允许的"点接触"处理 */
function ringsConflict(r1, r2, eps) {
  const closed1 = closeRing(r1, eps);
  const closed2 = closeRing(r2, eps);
  const m1 = closed1.length - 1;
  const m2 = closed2.length - 1;

  const deg1 = degenerates(closed1, m1, eps);
  const deg2 = degenerates(closed2, m2, eps);

  for (let i = 0; i < m1; i++) {
    if (deg1[i]) continue;
    for (let j = 0; j < m2; j++) {
      if (deg2[j]) continue;
      const kind = segmentsConflict(closed1[i], closed1[i + 1], closed2[j], closed2[j + 1], eps);
      if (kind === 'cross' || kind === 'overlap') return { i, j, kind };
    }
  }
  return null;
}

function closeRing(ring, eps) {
  return samePosition(ring[0], ring[ring.length - 1], eps) ? ring : [...ring, ring[0]];
}

function degenerates(closed, m, eps) {
  const out = new Array(m);
  for (let i = 0; i < m; i++) out[i] = samePosition(closed[i], closed[i + 1], eps);
  return out;
}
