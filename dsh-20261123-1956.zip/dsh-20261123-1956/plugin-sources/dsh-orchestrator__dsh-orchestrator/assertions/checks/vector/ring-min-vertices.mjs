// 环至少 4 个坐标。
// 依据 RFC 7946 §3.1.6：linear ring 是"4 个或更多 position"的闭合线串。

import { toFeatures, iterRings } from '../../lib/geo.mjs';

export const meta = {
  id: 'geom.ring.min-vertices',
  pack: 'geo.vector',
  group: 'geojson',
  spec: 'RFC 7946 §3.1.6',
  severity: 'error',
  appliesTo: ['**/*.geojson', '**/*.json'],
  description: '每个线性环至少包含 4 个坐标',
};

export function run({ doc }) {
  const issues = [];

  toFeatures(doc).forEach((feature, fi) => {
    for (const { ring, ringIndex, role } of iterRings(feature.geometry)) {
      const n = Array.isArray(ring) ? ring.length : 0;
      if (n < 4) {
        issues.push({
          locator: { feature: fi, ring: ringIndex, ringRole: role },
          message: `环只有 ${n} 个坐标，少于 4 个`,
          hint: '3 个不同点 + 重复首点才构成合法环；点数更少等价于空几何或线段',
        });
      }
    }
  });

  return issues;
}
