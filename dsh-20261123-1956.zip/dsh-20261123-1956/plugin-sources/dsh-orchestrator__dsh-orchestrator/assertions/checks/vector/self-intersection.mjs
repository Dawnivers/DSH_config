// 环自相交（含共线重叠与"捏点"）。
// 依据 OGC SFA / ISO 19125：polygon 的环不得自我相交。
// 这是纯 JS 实现，不依赖 GEOS —— 好处是零安装，坏处是只覆盖单环自交，
// 不检查环与环之间的嵌套关系（那是 L1 里 ST_IsValid 的活）。
//
// 复杂度 O(m^2)，m 是环的段数。用 limits.maxRingVertices 兜底，
// 超过就跳过并如实记录，不静默放行。

import { toFeatures, iterRings, segmentsConflict, samePosition } from '../../lib/geo.mjs';

export const meta = {
  id: 'geom.ring.self-intersection',
  pack: 'geo.vector',
  group: 'topology',
  spec: 'OGC SFA / ISO 19125',
  severity: 'error',
  appliesTo: ['**/*.geojson', '**/*.json'],
  description: '环不得自相交',
};

export function run({ doc, limits, tolerances }) {
  const eps = tolerances.coord;
  const maxV = limits.maxRingVertices ?? 20000;
  const issues = [];
  const skipped = [];

  toFeatures(doc).forEach((feature, fi) => {
    for (const { ring, ringIndex, role } of iterRings(feature.geometry)) {
      if (!Array.isArray(ring) || ring.length < 4) continue;

      // 段数定义在"闭合后的环"上：末点补首点，段数 = 顶点数 - 1
      const closed = samePosition(ring[0], ring[ring.length - 1], eps) ? ring : [...ring, ring[0]];
      const m = closed.length - 1;

      if (m < 3) continue;
      if (m > maxV) {
        skipped.push({ reason: `环 ${m} 段超过自相交检查上限 ${maxV}，已跳过` });
        continue;
      }

      const hit = findFirstSelfIntersection(closed, m, eps);
      if (!hit) continue;

      const at = closed[hit.i];
      issues.push({
        locator: { feature: fi, ring: ringIndex, ringRole: role, vertex: hit.i },
        message:
          `环自相交：段 #${hit.i} 与段 #${hit.j} ${KIND_LABEL[hit.kind] ?? hit.kind}，` +
          `位置约 [${at[0].toFixed(6)}, ${at[1].toFixed(6)}]`,
        hint: '用 ST_MakeValid 或移除交叉点；修完要核对面积变化与相邻面缝隙',
      });
    }
  });

  return { issues, skipped };
}

function findFirstSelfIntersection(closed, m, eps) {
  // 零长度线段（相邻顶点重复）没有方向，不能拿来判相交。
  // 否则"重复顶点"会连带触发自相交误报 —— 这个 bug 就是自测抓出来的。
  const degenerate = new Array(m);
  for (let i = 0; i < m; i++) degenerate[i] = samePosition(closed[i], closed[i + 1], eps);

  // 不按索引跳过"相邻段"：相邻与否是几何性质，不是索引性质。
  // 中间夹了零长度段时索引相邻会失效，所以交给 segmentsConflict 按几何判断。
  for (let i = 0; i < m; i++) {
    if (degenerate[i]) continue;
    for (let j = i + 1; j < m; j++) {
      if (degenerate[j]) continue;
      const kind = segmentsConflict(closed[i], closed[i + 1], closed[j], closed[j + 1], eps);
      if (kind) return { i, j, kind };
    }
  }
  return null;
}

const KIND_LABEL = { cross: '交叉', overlap: '共线重叠', pinch: '捏点/端点落在段内' };
