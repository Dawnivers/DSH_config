// 项目配置示例。复制到项目根目录并改名为 checks.config.mjs 即可生效。
// 这个文件回答"本项目适用什么"；--profile / --only / --skip 回答"这次跑什么"。
//
// 只保留实际用得到的段落。没配的断言会报"不适用"，不会报"通过"。

export default {
  // 启用哪些领域包。空数组 = 本项目不做地理校验（运行时报 not_applicable）
  packs: ['geo.vector'],

  // 按组开关，比逐条开关好维护。false 表示关闭该组
  groups: {
    geojson: true,
    coords: true,
    topology: true,
    schema: true,
    crs: true,
    db: true,
    reconcile: true,
  },

  // 只检查这些路径（白名单）。仓库里有一堆 json 但只有 data/ 是地理数据时用它。
  include: ['data/*.json', 'data/**/*.geojson'],

  // 按断言覆盖严重度：'error' | 'warn' | 'off'
  severity: {
    // 'geom.ring.winding': 'error',
  },

  // 数值容差
  tolerances: { coord: 1e-9 },

  // 必填属性；留空则该断言不适用（不是通过）
  requiredProperties: ['adcode', 'name'],

  // 项目范围。抓"整体跑偏"：经纬度写反、(0,0)、GCJ/WGS 混用。
  // 不要用 buffer 糊，要放宽就显式改这四个数。
  extent: {
    minLon: 113.65,
    minLat: 29.92,
    maxLon: 115.14,
    maxLat: 31.41,
  },

  // 投影往返。只证明"坐标值与声明的 CRS 不矛盾"，不证明该用哪个 CRS。
  crs: {
    python: 'D:\\python\\python.exe',
    source: 'EPSG:4326',
    target: 'EPSG:3857',
    maxRoundtripMeters: 1,
    sample: 2000,
  },

  // 数据库。连接信息不抄进来：复用已有 .env 里的 PG* 变量，
  // 密码只存在于子进程环境，不进报告。
  db: {
    envFile: 'etl/.env',
    table: 'admin_area',
    geomColumn: 'geom',
    idColumn: 'adcode',
  },

  // 原始报文对账。"原始报文长什么样"是项目知识，所以抽取规则写在这里。
  reconcile: {
    rawGlob: 'etl/data/raw/amap/*/*.json',
    table: 'poi',
    idColumn: 'amap_id',
    extractIds: (doc) => (Array.isArray(doc?.pois) ? doc.pois.map((p) => p.id) : []),
    // 声明期望差值 + 原因：差值变了就报错。
    // 比放宽容差有用——"为什么差"被写下来了，而不是被容差吞掉。
    expected: {
      rowDelta: 0,
      idDelta: 0,
      reason: '在这里写清楚差值是怎么来的',
    },
    // 只想允许小幅波动时用 tolerance 代替 expected
    // tolerance: { rows: 0, ids: 0 },
  },

  // 安全阈值：超过就跳过并如实报告，绝不静默通过
  limits: {
    maxFileBytes: 50 * 1024 * 1024,
    maxRingVertices: 20000,
  },

  // 忽略的路径
  ignore: [
    '**/node_modules/**',
    '**/.git/**',
    '**/.dsh-code-index/**',
    '**/dist/**',
    '**/build/**',
    '**/__pycache__/**',
  ],

  // 已知豁免：必须写原因和到期日。
  // 到期后豁免自动失效，问题重新计入（防止豁免变永久）。
  knownIssues: [
    // {
    //   id: 'geom.ring.winding',
    //   path: 'data/hubei/**',
    //   reason: 'Geofabrik 导出未保证环方向，渲染无影响',
    //   expires: '2027-03-01',
    // },
  ],
};
