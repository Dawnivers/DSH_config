// 自测：验证"坏样本必须红、好样本必须绿、无数据必须不适用"。
// 这是断言库本身的可信度来源——断言自己没被测过，就不能拿它去测数据。
//
// 跑法：node tools/geo-checks/test/self-test.mjs
// 退出码：0 全通过，1 有反例没通过

import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

import { discoverChecks, checksDirOf } from '../lib/registry.mjs';
import { execute } from '../lib/engine.mjs';
import { aggregate } from '../lib/report.mjs';
import { globToRegExp } from '../lib/glob.mjs';
import { loadConfig } from '../lib/config.mjs';

const HERE = dirname(fileURLToPath(import.meta.url));
const TOOL = resolve(HERE, '..');
const FIXTURES = join(TOOL, 'fixtures');

const BASE_CONFIG = {
  packs: ['geo.vector'],
  groups: {},
  severity: {},
  tolerances: { coord: 1e-9 },
  requiredProperties: ['adcode', 'name'],
  limits: { maxFileBytes: 50 * 1024 * 1024, maxRingVertices: 20000 },
  ignore: [],
  knownIssues: [],
};

const checks = await discoverChecks(checksDirOf(TOOL));
const results = [];

function record(name, ok, detail = '') {
  results.push({ name, ok, detail });
  console.log(`${ok ? '  ok  ' : ' FAIL '} ${name}${detail ? '  — ' + detail : ''}`);
}

async function runCase(files, configOverride = {}) {
  const config = { ...structuredClone(BASE_CONFIG), ...configOverride };
  const entries = await execute({
    root: FIXTURES,
    checks,
    config,
    allFiles: files,
    only: [],
    skip: [],
    changed: null,
  });
  return { summary: aggregate(entries, { strict: false, config }), entries };
}

async function expectIssue(label, file, issueId, { severity, exitCode, config } = {}) {
  const { summary } = await runCase([file], config ?? {});
  const hit = summary.results.find((r) => r.id === issueId);
  const okHit = Boolean(hit);
  const okSeverity = severity ? hit?.severity === severity : true;
  const okExit = exitCode === undefined ? true : summary.exit_code === exitCode;
  record(
    `${label}：${file} 必须命中 ${issueId}`,
    okHit && okSeverity && okExit,
    okHit
      ? `severity=${hit.severity} exit=${summary.exit_code} locator=${JSON.stringify(hit.locator)}`
      : `未命中，实际结果为 ${summary.results.map((r) => r.id).join(', ') || '(空)'}`
  );
  return summary;
}

console.log(`\n已注册断言 ${checks.length} 条：${checks.map((c) => c.meta.id).join(', ')}\n`);
console.log('【1】好样本必须全绿');
{
  const { summary } = await runCase(['good/clean.geojson']);
  record(
    'good/clean.geojson 应 pass 且 0 问题',
    summary.status === 'pass' && summary.results.length === 0,
    `status=${summary.status} issues=${summary.results.length} exit=${summary.exit_code}`
  );
}
{
  const { summary } = await runCase(['good/touching-point.geojson']);
  record(
    '两部分仅点接触应保持 pass（OGC 允许有限点接触）',
    summary.status === 'pass' && summary.results.length === 0,
    `status=${summary.status} issues=${summary.results.map((r) => r.id).join(',') || '(空)'}`
  );
}

console.log('\n【2】坏样本必须被对应断言抓到');
await expectIssue('未闭合', 'bad/unclosed.geojson', 'geom.ring.closed', { severity: 'error', exitCode: 1 });
await expectIssue('外环顺时针', 'bad/cw-exterior.geojson', 'geom.ring.winding', { severity: 'warn', exitCode: 2 });
await expectIssue('坐标越界', 'bad/out-of-range.geojson', 'geom.coord.range', { severity: 'error', exitCode: 1 });
await expectIssue('重复顶点', 'bad/dup-vertex.geojson', 'geom.vertex.duplicate-adjacent', { severity: 'warn', exitCode: 2 });
await expectIssue('自相交', 'bad/self-intersect.geojson', 'geom.ring.self-intersection', { severity: 'error', exitCode: 1 });
await expectIssue('两部分共边', 'bad/shared-edge.geojson', 'geom.multipolygon.shared-edge', { severity: 'error', exitCode: 1 });
await expectIssue('缺必填属性', 'bad/missing-prop.geojson', 'schema.required-properties', { severity: 'error', exitCode: 1 });
{
  const { summary } = await runCase(['bad/malformed.geojson']);
  const hit = summary.results.find((r) => r.id === 'file.json.parse');
  record(
    '坏 JSON：必须报 file.json.parse（error）且状态不能是 not_applicable',
    hit?.severity === 'error' && summary.status === 'issues_found' && summary.exit_code === 1,
    `status=${summary.status} exit=${summary.exit_code} issues=${summary.results.length}`
  );
}

console.log('\n【3】"不适用"必须和"通过"区分开');
{
  const { summary } = await runCase([]);
  record(
    '没有匹配文件时应为 not_applicable，不是 pass',
    summary.status === 'not_applicable' && summary.exit_code === 0,
    `status=${summary.status}`
  );
}
{
  const { summary } = await runCase(['good/clean.geojson'], { packs: [] });
  record(
    'packs 为空时应为 not_applicable',
    summary.status === 'not_applicable',
    `status=${summary.status} enabled=${summary.counts.checks_enabled}`
  );
}
{
  const { summary } = await runCase(['good/clean.geojson'], { requiredProperties: [] });
  const schemaEntry = summary.entries.find((e) => e.id === 'schema.required-properties');
  record(
    '未声明 requiredProperties 时该断言应 not_applicable',
    schemaEntry?.status === 'not_applicable',
    `status=${schemaEntry?.status} reason=${schemaEntry?.reason}`
  );
}

console.log('\n【4】组开关与严重度覆盖生效');
{
  const { summary } = await runCase(['bad/self-intersect.geojson'], { groups: { topology: false } });
  const topo = summary.entries.find((e) => e.group === 'topology');
  record('groups.topology=false 时拓扑组应 disabled', topo?.status === 'disabled', `status=${topo?.status}`);
}
{
  const { summary } = await runCase(['bad/cw-exterior.geojson'], {
    severity: { 'geom.ring.winding': 'error' },
  });
  const hit = summary.results.find((r) => r.id === 'geom.ring.winding');
  record(
    'severity 覆盖可把 warn 提升为 error（exit 应变 1）',
    hit?.severity === 'error' && summary.exit_code === 1,
    `severity=${hit?.severity} exit=${summary.exit_code}`
  );
}

console.log('\n【5】knownIssues 豁免与到期');
{
  const future = new Date(Date.now() + 86400000).toISOString().slice(0, 10);
  const past = '2000-01-01';
  const cfgFuture = {
    knownIssues: [
      { id: 'geom.ring.self-intersection', path: 'bad/**', reason: '测试豁免', expires: future },
    ],
  };
  const { summary: s1 } = await runCase(['bad/self-intersect.geojson'], cfgFuture);
  record(
    '未到期豁免应压掉问题，状态回 pass',
    s1.status === 'pass' && s1.counts.issues_suppressed === 1,
    `status=${s1.status} suppressed=${s1.counts.issues_suppressed}`
  );

  const cfgPast = {
    knownIssues: [
      { id: 'geom.ring.self-intersection', path: 'bad/**', reason: '过期豁免', expires: past },
    ],
  };
  const { summary: s2 } = await runCase(['bad/self-intersect.geojson'], cfgPast);
  record(
    '过期豁免应失效，问题重新计入并报告过期',
    s2.status === 'issues_found' && s2.expired_exemptions.length === 1,
    `status=${s2.status} expired=${s2.expired_exemptions.length}`
  );
}

console.log('\n【6】glob 与配置加载');
{
  const cases = [
    ['**/*.json', 'a/b/c.json', true],
    ['**/*.json', 'c.json', true],
    ['data/*.json', 'data/x.json', true],
    ['data/*.json', 'data/x/y.json', false],
    ['**/node_modules/**', 'x/node_modules/y.js', true],
    ['**/node_modules/**', 'node_modules/y.js', true],
  ];
  let ok = true;
  const detail = [];
  for (const [glob, path, want] of cases) {
    const got = globToRegExp(glob).test(path);
    if (got !== want) {
      ok = false;
      detail.push(`${glob} vs ${path} 期望 ${want} 实得 ${got}`);
    }
  }
  record('glob 匹配规则正确', ok, detail.join('; '));
}
{
  const { config, source } = await loadConfig({
    root: TOOL,
    explicitPath: 'checks.config.example.mjs',
  });
  record(
    '示例配置可被加载',
    source === 'project' && Array.isArray(config.packs) && config.packs.length > 0,
    `source=${source} packs=${config.packs.join(',')}`
  );
}

console.log('\n【7】L1 断言：范围 / 投影 / 数据库');
{
  const extent = { minLon: 0, minLat: 0, maxLon: 10, maxLat: 10 };
  const { summary } = await runCase(['bad/outside-extent.geojson'], { extent });
  const hit = summary.results.find((r) => r.id === 'crs.extent.within');
  record(
    '范围内断言：越界坐标必须被抓到',
    hit?.severity === 'error' && summary.exit_code === 1,
    `severity=${hit?.severity} exit=${summary.exit_code}`
  );
}
{
  const extent = { minLon: -1, minLat: -1, maxLon: 3, maxLat: 3 };
  const { summary } = await runCase(['good/clean.geojson'], { extent });
  const hit = summary.results.find((r) => r.id === 'crs.extent.within');
  record('范围内断言：范围内坐标不应误报', !hit, `issues=${summary.results.map((r) => r.id).join(',') || '(空)'}`);
}
{
  const { summary } = await runCase(['good/clean.geojson'], { extent: null });
  const entry = summary.entries.find((e) => e.id === 'crs.extent.within');
  record('未配置 extent 时应为 not_applicable', entry?.status === 'not_applicable', `status=${entry?.status} reason=${entry?.reason}`);
}
{
  const { summary } = await runCase(['good/clean.geojson']);
  const dbEntries = ['db.geom.invalid', 'db.reconcile.raw-vs-db'].map((id) => summary.entries.find((e) => e.id === id));
  record(
    '未配置 db 时 db.* 断言应为 not_applicable（不是失败，也不能算通过）',
    dbEntries.every((e) => e?.status === 'not_applicable'),
    dbEntries.map((e) => `${e?.id}=${e?.status}`).join(' ')
  );
}
{
  // 环境有 pyproj 就应该跑通；没装就应该如实报不适用。两种都不许报 error。
  const { summary } = await runCase(['good/clean.geojson'], {
    crs: {
      python: process.env.GEOCHECKS_PYTHON || 'python',
      source: 'EPSG:4326',
      target: 'EPSG:3857',
      maxRoundtripMeters: 1,
    },
  });
  const entry = summary.entries.find((e) => e.id === 'crs.roundtrip.pyproj');
  const ok = entry?.status === 'not_applicable' || (entry?.status === 'ran' && entry.issues.length === 0);
  record(
    'pyproj 往返：可用则通过，不可用则如实不适用',
    Boolean(ok),
    `status=${entry?.status} issues=${entry?.issues.length ?? 0} ${entry?.reason ?? ''}`
  );
}

const failed = results.filter((r) => !r.ok);
console.log(`\n———— 结果：${results.length - failed.length}/${results.length} 通过 ————`);
if (failed.length) {
  console.log('\n失败项：');
  for (const f of failed) console.log(`  - ${f.name}${f.detail ? '  # ' + f.detail : ''}`);
  process.exit(1);
}
process.exit(0);
