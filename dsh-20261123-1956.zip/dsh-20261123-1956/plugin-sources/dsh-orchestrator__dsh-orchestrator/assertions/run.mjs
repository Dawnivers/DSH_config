#!/usr/bin/env node
// 地理断言 CLI 入口。
//
// 退出码约定（给编排用，别改）：
//   0  通过，或"不适用"
//   1  有 error 级问题（阻塞）
//   2  只有 warn 级问题（不阻塞，但进报告）
//
// 用法：
//   node tools/geo-checks/run.mjs --root=<项目根> --profile=pr
//   node tools/geo-checks/run.mjs --root=. --only=geojson --skip=topology --json

import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { execFileSync } from 'node:child_process';

import { discoverChecks, summarizeCatalog, checksDirOf } from './lib/registry.mjs';
import { loadConfig } from './lib/config.mjs';
import { walkFiles, execute } from './lib/engine.mjs';
import { aggregate, toJSON, toHuman } from './lib/report.mjs';
import { createMatcher, normalizePath } from './lib/glob.mjs';

const BASE_DIR = dirname(fileURLToPath(import.meta.url));

const PROFILES = {
  // 每轮：只看改动的文件，快速反馈。
  // 整项目级断言（db / reconcile）描述的是"环境与库的状态"，不是这次改动引入的，
  // 所以 pr 里跳过——否则历史遗留问题会算到每次改动头上，很快就没人看了。
  pr: { strict: false, changedSince: 'HEAD', skipGroups: ['db', 'reconcile'] },
  // 提交前：全量跑，不提升严重度
  ci: { strict: false, changedSince: null, skipGroups: [] },
  // 发布前：全量 + warn 也算失败
  release: { strict: true, changedSince: null, skipGroups: [] },
};

function parseArgs(argv) {
  const opts = {
    root: process.cwd(),
    config: null,
    profile: null,
    changedSince: undefined, // undefined = 用 profile 的默认值；null = 明确不用
    only: [],
    skip: [],
    json: false,
    list: false,
    strict: undefined,
    quiet: false,
  };

  // 支持 --key=value 和 --key value 两种写法
  const VALUE_FLAGS = new Set(['--root', '--config', '--profile', '--changed-since', '--only', '--skip']);

  for (let i = 0; i < argv.length; i++) {
    let arg = argv[i];

    if (VALUE_FLAGS.has(arg)) {
      const next = argv[i + 1];
      if (next === undefined) throw new Error(`参数 ${arg} 缺少值`);
      arg = `${arg}=${next}`;
      i += 1;
    }

    if (arg === '--json') opts.json = true;
    else if (arg === '--list') opts.list = true;
    else if (arg === '--quiet') opts.quiet = true;
    else if (arg === '--strict') opts.strict = true;
    else if (arg.startsWith('--root=')) opts.root = resolve(arg.slice(7));
    else if (arg.startsWith('--config=')) opts.config = arg.slice(9);
    else if (arg.startsWith('--profile=')) opts.profile = arg.slice(10);
    else if (arg.startsWith('--changed-since=')) {
      const v = arg.slice(16);
      opts.changedSince = v === 'none' || v === '' ? null : v;
    } else if (arg.startsWith('--only=')) opts.only = splitList(arg.slice(7));
    else if (arg.startsWith('--skip=')) opts.skip = splitList(arg.slice(7));
    else if (arg === '--help' || arg === '-h') opts.help = true;
    else if (arg.startsWith('-')) throw new Error(`未知参数：${arg}`);
  }
  return opts;
}

function splitList(s) {
  return s
    .split(',')
    .map((x) => x.trim())
    .filter(Boolean);
}

/** 取 git 改动文件集合；拿不到就返回 null（调用方退回全量，并明确告知） */
function changedFiles(root, ref) {
  try {
    const top = execFileSync('git', ['-C', root, 'rev-parse', '--show-toplevel'], {
      encoding: 'utf8',
      stdio: ['ignore', 'pipe', 'ignore'],
    }).trim();
    if (normalizePath(top) !== normalizePath(root)) return { files: null, reason: `--root 不是 git 仓库根（实际根是 ${top}）` };

    const tracked = execFileSync('git', ['-C', root, 'diff', '--name-only', ref], {
      encoding: 'utf8',
      stdio: ['ignore', 'pipe', 'ignore'],
    });
    const untracked = execFileSync('git', ['-C', root, 'ls-files', '--others', '--exclude-standard'], {
      encoding: 'utf8',
      stdio: ['ignore', 'pipe', 'ignore'],
    });

    const files = new Set(
      [...tracked.split(/\r?\n/), ...untracked.split(/\r?\n/)].filter(Boolean).map(normalizePath)
    );
    return { files, reason: null };
  } catch (err) {
    return { files: null, reason: `git 不可用或不在仓库内：${err.message.split('\n')[0]}` };
  }
}

function printHelp() {
  console.log(`地理断言 CLI

  --root=<dir>           项目根目录（默认当前目录）
  --config=<file>        指定配置（默认 <root>/checks.config.mjs）
  --profile=pr|ci|release
                         pr      只看改动文件（默认）
                         ci      全量
                         release 全量 + warn 也算失败
  --changed-since=<ref>  指定基线 ref；--changed-since=none 关闭改动过滤
  --only=<a,b>           只跑指定 pack / group / id
  --skip=<a,b>           跳过指定 pack / group / id
  --strict               把 warn 提升为 error
  --json                 输出机器可读 JSON
  --list                 列出所有已注册断言
  --help                 显示本帮助

退出码：0 通过/不适用   1 有 error   2 仅 warn`);
}

async function main() {
  const opts = parseArgs(process.argv.slice(2));

  if (opts.help) {
    printHelp();
    return 0;
  }

  const root = opts.root;
  const checks = await discoverChecks(checksDirOf(BASE_DIR));

  if (opts.list) {
    const catalog = summarizeCatalog(checks);
    const perProject = new Set(checks.filter((c) => c.meta.perProject).map((c) => c.meta.id));
    console.log(`共 ${checks.length} 条断言\n`);
    for (const [pack, groups] of catalog) {
      console.log(`[${pack}]`);
      for (const [group, ids] of groups) {
        console.log(`  ${group}`);
        for (const id of ids) console.log(`    - ${id}${perProject.has(id) ? '  [整项目级]' : ''}`);
      }
    }
    return 0;
  }

  const profileName = opts.profile ?? 'pr';
  const profile = PROFILES[profileName];
  if (!profile) throw new Error(`未知 profile：${profileName}（可选 pr / ci / release）`);

  const { config, source: configSource, path: configPath, warnings } = await loadConfig({
    root,
    explicitPath: opts.config,
  });

  let allFiles = walkFiles(root, config.ignore);
  if (config.include?.length) {
    const includeMatch = createMatcher(config.include);
    const before = allFiles.length;
    allFiles = allFiles.filter(includeMatch);
    if (allFiles.length !== before) {
      warnings.push(`include 白名单过滤掉 ${before - allFiles.length} 个文件（只检查 ${allFiles.length} 个）`);
    }
  }

  // 决定要不要按改动过滤
  const changedSince = opts.changedSince === undefined ? profile.changedSince : opts.changedSince;
  let changed = null;
  const notes = [];
  if (changedSince) {
    const res = changedFiles(root, changedSince);
    if (res.files) {
      changed = res.files;
      notes.push(`只检查相对 ${changedSince} 有改动的文件（${changed.size} 个）`);
    } else {
      notes.push(`改动过滤不可用，已退回全量：${res.reason}`);
    }
  }

  const strict = opts.strict ?? profile.strict;

  // profile 自带的跳过项 + 命令行 --skip
  const skipGroups = profile.skipGroups ?? [];
  const skip = [...skipGroups, ...opts.skip];
  const skipReason = skipGroups.length ? `profile=${profileName}` : '--skip';

  const started = Date.now();
  const entries = await execute({
    root,
    checks,
    config,
    allFiles,
    only: opts.only,
    skip,
    skipReason,
    changed,
  });
  const elapsed = Date.now() - started;

  const summary = aggregate(entries, { strict, config });
  const context = {
    tool: 'geo-checks',
    version: 1,
    profile: profileName,
    strict,
    root: normalizePath(root),
    config_source: configSource,
    config_path: configPath ? normalizePath(configPath) : null,
    changed_since: changed ? changedSince : null,
    elapsed_ms: elapsed,
    notes: [...notes, ...warnings],
  };

  if (opts.json) {
    console.log(JSON.stringify(toJSON(summary, context), null, 2));
  } else if (!opts.quiet) {
    for (const n of context.notes) console.log(`注：${n}`);
    console.log(toHuman(summary, context));
  }

  return summary.exit_code;
}

main()
  .then((code) => process.exit(code))
  .catch((err) => {
    console.error(`\n地理断言运行失败：${err.message}\n`);
    process.exit(1);
  });
