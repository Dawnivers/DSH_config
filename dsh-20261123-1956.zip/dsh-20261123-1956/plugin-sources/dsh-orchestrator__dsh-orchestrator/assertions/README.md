# geo-checks

零依赖的地理断言工具，为"能进 CI / 能进 AI 编排"设计。

## 为什么会长成这样

编排对断言有五个硬约束，任何一条不满足就没法用：

| 约束 | 为什么 |
|---|---|
| 无头 CLI + 退出码 | 插件本身不执行任何构建/测试，只有 worker 能跑 |
| 确定性 | reviewer 要区分 `issues_found` 与 `unable_to_verify` |
| 秒级 | 每轮修复后都要重跑 |
| 失败可定位 | 输出必须带文件 + 要素/环/顶点，worker 才能改 |
| 不依赖运行中的服务 | 容器没起时不能变成 unverifiable |

所以官方 ETS（GeoPackage / WMS / KML）不在这里：它们的报告面向"端点"，定位不到要素，而且 WMS 要服务在线、耗时分钟级。那些适合 `release` 阶段由主会话跑，作为一次性证据。

## 三层选择模型

```
第一层  能力注册 —— 自动发现，不用配置
        checks/**/*.mjs  每个文件导出 meta + run
        丢一个文件进来就等于加了一条断言

第二层  项目配置 —— 随仓库走，回答"本项目适用什么"
        <project>/checks.config.mjs
        packs / groups / severity / requiredProperties / knownIssues

第三层  运行参数 —— 回答"这一次跑什么"
        --profile=pr|ci|release   --only=  --skip=  --changed-since=
```

**项目配置和运行参数不能合并**，否则换分支就丢配置。

选择粒度是**组**，不是单条断言。30 个开关没人维护得动；单条调试用 `--only` / `--skip`。

## 快速开始

```bash
# 列出所有断言
node dsh-orchestrator/assertions/run.mjs --list

# 每轮：只看改动文件，并跳过整项目级断言（db / reconcile）
node dsh-orchestrator/assertions/run.mjs --root=<项目根> --profile=pr

# 提交前：全量（含 db / reconcile）
node dsh-orchestrator/assertions/run.mjs --root=<项目根> --profile=ci

# 发布前：全量 + warn 也算失败
node dsh-orchestrator/assertions/run.mjs --root=<项目根> --profile=release

# 机器可读
node dsh-orchestrator/assertions/run.mjs --root=<项目根> --json

# 自测：坏样本必须红、好样本必须绿
node dsh-orchestrator/assertions/test/self-test.mjs
```

## 退出码（编排用，别改）

```
0   通过，或"不适用"
1   有 error 级问题（阻塞）
2   只有 warn 级问题（不阻塞，但进报告）
```

## 核心约定：不适用 ≠ 通过

```
✅  {"status": "not_applicable", "applicable": 0}
✅  {"status": "pass",           "applicable": 7}
❌  什么都没跑却报 pass
```

三种情形都归到 `not_applicable`，且**绝不**输出 `pass`：

- 没有任何 pack 启用（非 GIS 项目）
- 启用了但作用范围内没有匹配文件
- 匹配到的文件全都不是 GeoJSON（或超大小上限）

反过来，**文件坏了要报 error，不能降级成 not_applicable** —— 这个 bug 自测抓到过一次。

## JSON 输出契约

```json
{
  "status": "issues_found",
  "exit_code": 1,
  "counts": { "checks_applicable": 7, "issues_error": 6, "issues_warn": 0, "issues_suppressed": 0, "issues_deduped": 0 },
  "results": [
    {
      "id": "geom.multipolygon.shared-edge",
      "spec": "OGC SFA / ISO 19125",
      "severity": "error",
      "path": "data/wuhan.json",
      "locator": { "feature": 8, "ring": 0, "ringRole": "exterior vs exterior(poly 0/1)", "vertex": 3 },
      "message": "环之间共边重叠：…",
      "hint": "这不是环内自交，而是 MultiPolygon 各部分共边…"
    }
  ]
}
```

`locator` 是关键：它让 worker 直接从失败项跳到修改点，不用读完整份报告。**没有 locator 的断言在编排里价值很低**。

## 现有断言

| id | 组 | 严重度 | 依据 | 说明 |
|---|---|---|---|---|
| `geom.ring.closed` | geojson | error | RFC 7946 §3.1.6 | 环首末点必须相等 |
| `geom.ring.min-vertices` | geojson | error | RFC 7946 §3.1.6 | 环至少 4 个坐标 |
| `geom.vertex.duplicate-adjacent` | geojson | warn | 项目约定 | 相邻重复顶点（OGC 允许，故非 error） |
| `geom.ring.winding` | geojson | **warn** | RFC 7946 §3.1.6 | 外环 CCW / 内环 CW |
| `geom.coord.range` | coords | error | RFC 7946 §3.1.1, §4 | 经纬度范围 |
| `geom.ring.self-intersection` | topology | error | OGC SFA | 单环自交（含共线重叠、捏点） |
| `geom.multipolygon.shared-edge` | topology | error | OGC SFA | 同几何不同环共边/交叉 |
| `schema.required-properties` | schema | error | 项目约定 | 必填属性（未配置则 N/A） |
| `crs.extent.within` | coords | error | 项目约定（AOI） | 坐标是否在项目范围内（纯 JS，最快） |
| `crs.roundtrip.pyproj` | crs | error | EPSG / PROJ | 投影往返误差（需 python + pyproj） |
| `db.geom.invalid` | db | error | PostGIS ST_IsValid | 数据库几何是否有效（权威判定） |
| `db.reconcile.raw-vs-db` | reconcile | error | 项目约定（口径） | 原始报文与库中行数/去重数对账 |
| `file.json.parse` | — | error | JSON | 解析失败（由引擎产生，非独立断言） |

后四条是 **L1**：要么需要外部工具，要么需要项目知识。它们的共同约定是——**环境缺失就报"不适用"，不报"失败"，更不报"通过"**。

```
未配 db.table        → not_applicable（本项目没数据库）
配了但连不上          → error（配置或环境真的坏了）
python 缺 pyproj     → not_applicable（这台机器做不了这件事）
```

### 两个严重度的设计理由

**`geom.ring.winding` 默认 warn。** RFC 7946 要求右手定则，但同一节也要求解析器 SHOULD NOT 因方向拒绝几何；多数渲染与空间运算对方向不敏感。自己产出的数据应在配置里提到 `error`：

```js
severity: { 'geom.ring.winding': 'error' }
```

**`geom.vertex.duplicate-adjacent` 默认 warn。** OGC 允许重复点，GEOS 判 valid。它只会拖慢渲染和索引，不会让几何失效。

## 核对口径：expected 优于 tolerance

对账类断言不要只写容差。容差会把"为什么差"这件事吞掉，下次差 200 条也照样绿。

```js
reconcile: {
  rawGlob: 'etl/data/raw/amap/*/*.json',
  table: 'poi',
  idColumn: 'amap_id',
  extractIds: (doc) => doc.pois.map((p) => p.id),

  // 写清楚差多少、为什么，差值一变就报错
  expected: {
    rowDelta: -108,
    idDelta: -78,
    reason: '30 条原始重复 amap_id + 78 条 0604xx 家居建材族被分类码表过滤',
  },
}
```

## 白名单：include

仓库里 280 个 json、只有 1 个是地理数据时，靠 `ignore` 排除容易漏。用 `include` 正向声明：

```js
include: ['data/*.json', 'data/**/*.geojson'],
```

它是**第一道筛**：先按 include 收窄，再按各断言的 `appliesTo` 收窄。被 include 挡掉的文件数会写进报告，不会静默。

## 整项目级断言

数据库类断言不对应任何文件，声明 `perProject: true` 即可：整个项目跑一次，`ctx.file` 为 `null`，可以用 `ctx.root` 去查库。

```js
export const meta = { id: 'db.geom.invalid', perProject: true, appliesTo: ['**/*'], ... };
export function run({ config, root }) { /* 返回 { issues } 或 { applicable:false, reason } */ }
```

断言可以是 `async`（引擎会 await），所以调外部进程不需要额外机制。

## 加一条断言

在 `checks/<子目录>/` 下新建 `.mjs`：

```js
export const meta = {
  id: 'geom.xxx',            // 全局唯一
  pack: 'geo.vector',
  group: 'topology',
  spec: 'RFC 7946 §…',        // 写清依据，没有依据就写"项目约定"
  severity: 'error',          // error | warn
  appliesTo: ['**/*.geojson'],
  description: '一句话说明',
};

export function run({ doc, config, tolerances, limits }) {
  return [];                  // 或 { issues, skipped, applicable: false }
}
```

- 不需要改任何登记表，目录扫描自动注册
- `applicable: false` 表示"这份数据不适用"（如未配置 requiredProperties），引擎会记成 N/A 而不是通过
- 返回的每个 issue 尽量给 `locator`
- 加完之后**必须**在 `test/self-test.mjs` 里补一个坏样本，否则这条断言自己都没被验证过

## 已知边界

**L0（纯 JS，无外部依赖）做不到的**：

- 环与环的嵌套正确性（洞是否在外环内、洞是否互相嵌套）
- 跨要素拓扑（相邻区划是否重叠、有缝隙）

这两点由 L1 的 `db.geom.invalid` 用 PostGIS/GEOS 补上——权威判定。

**仍然没有任何断言覆盖的**：

- CRS 真实性：GCJ-02 数据标成 WGS84，往返照样收敛，范围照样在框内。
  这一层只能靠控制点比对或与已知 WGS 数据交叉验证，不在本工具内。
- 属性值的业务正确性（adcode 与 name 是否匹配、分类是否合理）

**性能边界**：自相交与共边检测是纯 JS 的 O(m²)；超过 `limits.maxRingVertices` / 内部环对上限会跳过并**如实记录** `skipped`，不会静默放行。

## 接入编排：由插件选择，不靠手写文本

这套断言已经注册进 `dsh-orchestrator`，和选模型一样由插件下发，不需要你在 acceptance 里手写命令。

三个入口都能选：

```jsonc
// orchestrate_task 的 config，或设置页里的「数据断言」面板
{
  "task": "...",
  "assertions": ["geo.vector"]              // 整个包
  // ["geo.vector/geojson"]                 // 某个组
  // ["geom.ring.closed", "db.geom.invalid"] // 具体条目
}
```

选中之后插件做三件事：

1. **planner** 收到"已启用数据断言 + 命令"，并被告知这是「主会话待运行验证」，不要为它派发源码任务
2. **worker** 的验收条件里带上完整判定规则（含 `not_applicable ≠ pass`、不许放宽阈值换绿）
3. **reviewer** 复核时同样拿到规则，能区分"静态看过"和"实际跑过"

没选就是没选：报告显示「不适用」，不会显示「通过」。

### 命令实际长这样

```bash
node "<插件目录>/assertions/run.mjs" --root "<项目根>" --profile=ci --only "geo.vector/geojson" --json
```

worker 不会执行它（插件禁止 worker 跑构建/测试）。插件在 worker 全部结束后自己执行一次作为闸门，通过则按 `reviewMode` 决定是否跳过复核；主会话仍可手动重跑同一条命令复核。

### 选择粒度为什么是组

单条开关维护不动，也不是编排需要的粒度：失败时修法相同的归一组（`geojson` / `coords` / `topology` / `schema` / `crs` / `db` / `reconcile`）。要单条调试用 `--only`。

### 项目侧还需要什么

断言库只提供能力，**扫哪些文件、范围多大、连哪个库**属于项目知识，写在项目根的 `checks.config.mjs`（模板见 `checks.config.example.mjs`）。

不写也能跑，但要接受两个后果：

- 会扫描项目里所有 `.json`（大量非地理文件被记为 skipped，报告变长）
- `extent` / `db` / `crs` / `reconcile` 四类断言因为没有参数而报「不适用」

默认不会去猜，也不会因为“猜不到”就判通过。

## 已知豁免

必须带 `reason` 和 `expires`，到期自动失效并作为过期项报出来：

```js
knownIssues: [
  { id: 'geom.ring.winding', path: 'data/hubei/**',
    reason: 'Geofabrik 导出未保证环方向，渲染无影响',
    expires: '2027-03-01' }
]
```

没有到期日的豁免会永久生效，配置加载时会给出警告。
