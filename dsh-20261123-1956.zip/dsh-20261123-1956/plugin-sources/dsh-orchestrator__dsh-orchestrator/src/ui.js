import { flowModel, flowStyles, createFlowView } from './flow.js';
import { captureModule } from './runtime.js';

captureModule(import.meta.url);

export function page(embed = null) {
  const boot = JSON.stringify(embed).replaceAll('<', '\\u003c');
  return String.raw`<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="referrer" content="no-referrer">
<title>DSH 编排器设置</title>
<style>
:root{color-scheme:light dark;--bg:#f5f7fb;--panel:#fff;--text:#172238;--muted:#63718a;--line:#dce3ef;--accent:#3459d1;--soft:#edf2ff;--error:#aa2532;--ok:#17764e;--warn:#8a5a12;font:14px/1.65 system-ui,-apple-system,"Segoe UI","Microsoft YaHei",sans-serif}*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--text)}main{max-width:1120px;margin:auto;padding:28px 24px 64px}header{margin-bottom:22px}h1{font-size:27px;letter-spacing:-.04em;margin:0 0 7px}h2{font-size:19px;margin:0}h3{font-size:16px;margin:0 0 7px}p{margin:8px 0}.muted,.hint{color:var(--muted)}.hint{font-size:12px}.eyebrow{font-size:11px;color:var(--accent);font-weight:750;letter-spacing:.1em}.panel{background:var(--panel);border:1px solid var(--line);border-radius:16px;padding:22px;margin:18px 0;box-shadow:0 3px 15px #15214504}.section-heading{display:flex;align-items:center;justify-content:space-between;gap:14px;margin-bottom:16px}.grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:18px}.model-card{border:1px solid var(--line);border-radius:12px;padding:18px;background:var(--panel)}.step{display:inline-flex;align-items:center;justify-content:center;width:24px;height:24px;border-radius:7px;background:var(--soft);color:var(--accent);font-size:12px;margin-right:8px}label{display:block;font-weight:600;margin:14px 0 6px}input,select,textarea,button{font:inherit}input,select,textarea{display:block;width:100%;border:1px solid var(--line);border-radius:8px;background:var(--panel);color:var(--text);padding:10px 11px;min-width:0}input:focus,select:focus,textarea:focus{outline:2px solid var(--accent);outline-offset:1px}textarea{resize:vertical;min-height:96px}button{border:1px solid var(--line);border-radius:8px;padding:9px 14px;color:var(--text);background:var(--panel);cursor:pointer;font-weight:600}button:hover{border-color:var(--accent)}button.primary{background:var(--accent);border-color:var(--accent);color:#fff}button:disabled{opacity:.5;cursor:wait}.actions{display:flex;gap:10px;flex-wrap:wrap;align-items:center;margin-top:20px}details{margin-top:14px}summary{cursor:pointer;color:var(--muted)}.check{display:flex;align-items:flex-start;gap:9px;font-weight:500}.check input{width:17px;flex:none;margin-top:5px}.banner{border:1px solid var(--line);border-radius:10px;padding:12px 15px;background:var(--soft);white-space:pre-wrap;overflow-wrap:anywhere}.banner.error{color:var(--error);border-color:var(--error);background:transparent}.banner.ok{color:var(--ok);border-color:var(--ok);background:transparent}
.banner.warn{color:var(--warn);border-color:var(--warn);background:transparent}[hidden]{display:none!important}.storage{overflow-wrap:anywhere;font-size:12px;color:var(--muted)}.table-scroll{overflow:auto}table{border-collapse:collapse;width:100%;text-align:left;font-size:13px}th{color:var(--muted);font-size:12px;font-weight:600}th,td{padding:11px 8px;border-bottom:1px solid var(--line);vertical-align:top}td.task{min-width:150px;max-width:310px;white-space:pre-wrap;overflow-wrap:anywhere}.id{font:12px/1.65 ui-monospace,Consolas,monospace;overflow-wrap:anywhere}.badge{display:inline-block;padding:2px 8px;border-radius:6px;background:var(--soft);font-size:12px}.row-actions{display:flex;gap:7px;flex-wrap:wrap}.row-actions button{font-size:12px;padding:5px 9px;white-space:nowrap}.instruction{white-space:pre-wrap;overflow-wrap:anywhere;margin-top:12px;font-family:ui-monospace,Consolas,monospace}.kv{display:grid;grid-template-columns:100px minmax(0,1fr);gap:7px 14px;margin:14px 0}.kv dt{color:var(--muted)}.kv dd{margin:0;white-space:pre-wrap;overflow-wrap:anywhere}.run{border:1px solid var(--line);border-radius:9px;padding:12px;margin:10px 0}.run pre{white-space:pre-wrap;overflow-wrap:anywhere;font:12px/1.7 ui-monospace,Consolas,monospace}.two-wide{grid-column:1/-1}fieldset{border:0;padding:0;margin:0;min-width:0}.notice{border-left:3px solid var(--accent);padding-left:12px;margin-top:16px}.empty{text-align:center;padding:24px;color:var(--muted)}
@media(prefers-color-scheme:dark){:root{--bg:#10141d;--panel:#19202d;--text:#e1e8f4;--muted:#a4b0c6;--line:#344058;--accent:#87a3ff;--soft:#253351;--error:#ff9ba7;--ok:#83d8ae}button.primary{color:#101b34}}@media(max-width:700px){main{padding:18px 14px 40px}.grid{grid-template-columns:1fr}.panel{padding:17px}.section-heading{align-items:flex-start}.kv{grid-template-columns:75px minmax(0,1fr)}h1{font-size:23px}}
#detailBody{overflow-wrap:anywhere}
${flowStyles}
.runtime-details summary{cursor:pointer;font-size:13px;font-weight:550}.runtime-details summary .hint{margin-left:12px}.runtime-details[open] summary{margin-bottom:18px}.worker-slots{display:flex;gap:5px;flex-wrap:wrap}.worker-slots>span{font-size:10px;color:#b0b4ec;background:#26283a;border:1px solid #3b3e58;border-radius:5px;padding:2px 5px}
/* Production studio: cards configure existing form nodes; no alternate data or demo routes. */
.config-node[data-inactive=true]{border-style:dashed}.config-node[data-inactive=true] .node-meta{color:var(--warn)}
:root{color-scheme:dark;--bg:#090a0c;--panel:#111214;--text:#f0f1f4;--muted:#969ba7;--line:#292c33;--accent:#9296f6;--soft:#222439;--error:#ff9ba7;--ok:#82d7a3;--warn:#e7b66a}main{max-width:1600px;padding:32px 32px 64px}h1{font-weight:600}button.primary{background:#5e6ad2;border-color:#5e6ad2;color:#fff}button:focus-visible,summary:focus-visible{outline:2px solid var(--accent);outline-offset:3px}.panel{box-shadow:none}.task-strip{width:100%;display:flex;gap:16px;align-items:center;text-align:left;padding:18px 22px;border-radius:12px;background:var(--panel)}.task-main{flex:1;min-width:0}.task-main strong,.task-main .hint{display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.task-main strong{font-weight:550}.config-board{padding:0;overflow:hidden}.config-board>.section-heading{padding:20px 24px;margin:0;border-bottom:1px solid var(--line)}.canvas-scroll{overflow-x:auto}.config-canvas{min-width:1100px;position:relative;height:408px;background-image:radial-gradient(#30323a .7px,transparent .7px);background-size:24px 24px}.stage-labels{position:absolute;top:24px;left:24px;right:24px;display:grid;grid-template-columns:2fr 1fr 2fr;color:var(--muted);font-size:12px;letter-spacing:.04em}.config-pipeline{position:absolute;left:24px;right:24px;top:114px;display:grid;grid-template-columns:repeat(5,minmax(0,1fr)) 42px;gap:26px;align-items:center}.config-node{position:relative;display:flex;flex-direction:column;justify-content:space-between;gap:13px;min-height:164px;padding:16px;text-align:left;border:1px solid #3a3d46;border-radius:12px;background:#17181c;font-weight:400;min-width:0}.config-node[data-warning=true]{border-color:var(--warn)}.config-node:hover,.config-node[aria-expanded=true]{border-color:var(--accent);background:#202127}.config-node:after{content:'→';position:absolute;right:-23px;top:65px;color:#777c89;pointer-events:none}.node-index{font:11px ui-monospace,Consolas,monospace;color:var(--muted)}.node-title{font-size:16px;font-weight:550}.node-title small{display:block;font:11px ui-monospace,Consolas,monospace;color:var(--muted);margin-top:2px}.node-route{font-size:12px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.node-meta{font-size:11px;color:var(--muted);overflow-wrap:anywhere}.config-finish{color:var(--ok);font-size:12px;text-align:center}.config-finish span{display:block;font-size:25px}.bypass-wire{position:absolute;left:70%;right:40px;top:82px;height:31px;border-top:1px dashed #777c89;border-right:1px dashed #777c89;color:var(--muted);font-size:11px;text-align:center}.bypass-wire span{position:relative;top:-14px;background:var(--panel);padding:0 8px}.bypass-wire:after{content:'↓';position:absolute;right:-5px;bottom:-5px}.repair-wire{position:absolute;left:10%;right:13%;bottom:62px;height:46px;border:1px dashed #66698b;border-top:0;border-radius:0 0 10px 10px;color:#aaaee4;text-align:center;font-size:11px}.repair-wire span{position:relative;top:34px;background:var(--panel);padding:0 10px}.repair-wire:before{content:'↑';position:absolute;left:-5px;top:-12px}.board-bottom{padding:15px 24px;border-top:1px solid var(--line);display:flex;gap:16px;align-items:center;justify-content:space-between}.board-bottom button{font-size:12px;white-space:nowrap}.config-footer{padding:0 4px 18px}.config-drawer{position:fixed;right:0;top:0;bottom:0;z-index:30;width:470px;max-width:100%;display:flex;flex-direction:column;background:#111214;border-left:1px solid #3a3d46;box-shadow:-24px 0 80px #0008}.drawer-head{padding:22px 24px;display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid var(--line)}.drawer-head h2{font-size:21px;margin:4px 0 0}.drawer-content{padding:24px;overflow-y:auto;flex:1}.drawer-content .grid{grid-template-columns:1fr}.drawer-content .model-card{border:0;padding:0;background:transparent}.drawer-content h2{font-size:16px}.drawer-content .section-heading{align-items:flex-start}.drawer-footer{padding:16px 24px;display:flex;gap:12px;align-items:center;justify-content:space-between;border-top:1px solid var(--line)}.assert-pack,.assert-group{border:1px solid var(--line);border-radius:10px;margin:12px 0;background:#17181b;padding:0 12px}.assert-pack>summary,.assert-group>summary{cursor:pointer;padding:12px 0;color:var(--text);font-size:13px}.assert-group{background:#111214}.assert-leaf{border-top:1px solid var(--line);padding:5px 0}.unknown-assertions{border:1px solid var(--warn);padding:12px;border-radius:10px;margin-top:12px}.unknown-assertions .check{overflow-wrap:anywhere}#workerCapacity{border-top:1px solid var(--line);margin-top:22px;padding-top:5px}#pane-task>h3{margin-top:24px}@media(max-width:700px){main{padding:20px 14px 40px}.board-bottom{align-items:flex-start;flex-direction:column}.config-board>.section-heading{padding:18px}.config-drawer{width:100%}.task-strip{padding:16px}.task-strip>.hint{font-size:11px}.drawer-content{padding:20px}.drawer-footer{padding:14px 20px}}
</style>
</head>
<body><main>
<header><div class="eyebrow">DSH ORCHESTRATOR</div><h1 id="pageTitle">先设定边界，再开始编排</h1><p class="muted" id="pageDescription">选择规划与执行模型，限定文件范围，生成独立任务。此页面不会调用模型，也不会直接执行任务。</p><p id="sessionTarget" class="hint" hidden></p><p id="studioStatus" class="hint" role="status">正在读取模型与断言目录…</p></header>
<div id="message" class="banner" role="status" aria-live="polite" hidden></div>
<section id="flowPanel" class="panel" aria-labelledby="flowTitle" hidden><div class="flow-head"><div><div class="eyebrow">LIVE EXECUTION</div><h2 id="flowTitle">编排执行流程</h2><p id="flowTask" class="hint"></p></div><div class="flow-toolbar"><button type="button" id="flowRefresh">立即刷新</button><button type="button" id="flowConfig">返回配置</button></div></div><p id="flowLive" class="flow-live" role="status" aria-live="polite">等待读取运行状态…</p><div id="flowGraph"></div></section>

<form id="configForm"><fieldset id="fields" disabled>
<button type="button" class="task-strip" id="taskScopeCard" data-open="task" aria-controls="configDrawer" aria-expanded="false"><span class="step">◇</span><span class="task-main"><strong id="scopeTaskSummary">先定义任务与文件范围</strong><span id="scopePathSummary" class="hint">项目目录 · 允许修改的路径</span></span><span class="hint">任务与范围 ↗</span></button>
<section class="panel config-board" aria-labelledby="modelsTitle"><div class="section-heading"><div><div class="eyebrow">ORCHESTRATION / CONFIGURATION</div><h2 id="modelsTitle">把分工，排成一条线。</h2></div><span class="hint">点击卡片配置 · 目录由服务端提供</span></div><div class="canvas-scroll"><div class="config-canvas"><div class="stage-labels"><span>01　规划与检查</span><span>02　分工实施</span><span>03　验证与交付</span></div><div id="configPipeline" class="config-pipeline"></div><div class="bypass-wire" id="bypassWire"><span>实测通过 · 直接放行 → 交付</span></div><div class="repair-wire" id="repairWire"><span id="repairSummary">← 问题与证据返回 Planner · 修复后重新验证</span></div></div></div><div class="board-bottom"><span class="hint" id="policySummary"></span><button type="button" data-open="limits" aria-controls="configDrawer" aria-expanded="false">限额与高级配置 ↗</button></div></section>
<div class="config-footer"><div class="actions"><button type="button" id="saveDefaults">保存为默认设置</button><span class="hint">保存角色、规则、限额与文件边界，不保存任务说明。</span></div><div class="notice hint" id="taskNotice">生成任务仅持久化配置，不会启动规划、Worker 或模型请求。复制执行指令后，由你在对话中明确发起。</div><div class="actions"><button type="submit" class="primary" id="createJob">生成任务，不执行</button></div><div id="created" hidden><div class="instruction banner" id="createdInstruction"></div><div class="actions"><button type="button" id="copyCreated">复制执行指令</button><button type="button" id="viewCreated">查看任务</button></div></div></div>
<aside id="configDrawer" class="config-drawer" role="dialog" aria-modal="false" aria-labelledby="drawerTitle" hidden><div class="drawer-head"><div><div class="eyebrow">CONFIGURATION</div><h2 id="drawerTitle">配置</h2></div><button type="button" id="drawerClose" aria-label="关闭配置">✕</button></div><div class="drawer-content"><div id="modelCards"></div><section class="drawer-pane" id="pane-assertions" aria-labelledby="assertTitle" hidden><div class="section-heading"><h2 id="assertTitle">数据断言</h2><span class="hint">选包 / 选组 / 选单条</span></div><div id="assertGroups"><p class="hint">正在读取断言目录…</p></div><p class="hint" id="assertNotice">Verifier 会在编排内实际执行所选断言，保存命令、退出码与结果证据；失败或警告不会被当作通过。不选表示本项目不做这类校验，报告会写明不适用，而不是通过。</p><div style="margin-top:.75em"><span class="hint">复核时机</span><label class="check"><input type="radio" name="reviewMode" value="always" checked><span>总是复核<br><span class="hint">worker 之后无论断言是否通过都做一次独立只读复核。代码改动不该在没人看过的情况下交付。</span></span></label><label class="check"><input type="radio" name="reviewMode" value="on_failure"><span>仅在断言未通过时复核<br><span class="hint">断言实际执行且全部通过就放行，失败或警告才交 reviewer 分析。适合纯数据验证任务；断言没跑起来（不适用）不会放行。</span></span></label></div></section>
<section class="drawer-pane" id="pane-limits" aria-labelledby="limitsTitle" hidden><h2 id="limitsTitle">限额与高级配置</h2><div class="grid">
<div><label for="maxPlanRetries">最大重新规划次数</label><input id="maxPlanRetries" type="number" min="0" max="2" step="1" required value="1"><p class="hint">规划失败后允许重试的次数。</p></div>
</div><label for="maxRepairRounds">最大定向修复轮数</label><input id="maxRepairRounds" type="number" min="0" max="2" step="1" required value="1"><p class="banner warn" id="repairLimitNotice">当前执行器最多一次定向修复。0 表示关闭；历史配置 2 可以保留，但实际仍至多一次，不代表会执行两轮。</p><label class="check"><input id="rollbackOnFailure" type="checkbox" checked><span>失败或取消时恢复计划文件快照<br><span class="hint">仅影响授权范围内的计划文件；默认开启。</span></span></label></section>
<section class="drawer-pane" id="pane-task" aria-labelledby="taskTitle" hidden><h2 id="taskTitle">生成独立任务</h2><label for="projectRoot">项目目录</label><input id="projectRoot" type="text" autocomplete="off" placeholder="项目的绝对路径" required><p class="hint">请先准备可读的项目副本。插件不会自动复制蓝本、安装依赖或从参考 URL 重建项目；空目录会在模型调用前停止。</p><label for="task">任务说明</label><textarea id="task" rows="5" placeholder="说明目标、验收标准和禁止事项" required></textarea><label for="verifyHint">验证提示（可选）</label><textarea id="verifyHint" rows="2" placeholder="例如：需要运行哪些测试，以及不得执行哪些操作"></textarea><h3>文件权限与边界</h3><div class="grid"><div><label for="allowedGlobs">允许的文件范围</label><textarea id="allowedGlobs" spellcheck="false" placeholder="src/**" required></textarea><p class="hint">每行一条 glob，相对于项目目录。此列表不能为空。</p></div>
<div><label for="protectedFiles">受保护文件</label><textarea id="protectedFiles" spellcheck="false" placeholder="每行一个项目相对路径"></textarea><p class="hint">应额外保护的敏感配置、锁文件或其他文件。</p></div>
<label class="check"><input id="allowProtected" type="checkbox"><span>显式允许本任务修改受保护文件<br><span class="hint">默认关闭，仅阻止修改上述受保护文件，不会把整个任务设成只读。清单为空时不额外限制；打开也不能突破允许路径。</span></span></label>
</div></section><section id="workerCapacity" hidden><div><label for="maxWorkers">最大并发 Worker</label><input id="maxWorkers" type="number" min="1" max="6" step="1" required value="2"><p class="hint">所有 Worker 共用同一模型路由；此值仅限制同时实施的会话数，不是固定任务数。按实际计划形状决定：单任务且无跨任务依赖时使用 planner 自检；多任务或跨任务依赖时，额外有 1 个只读可行性确认会话。自检或复核有疑问时，在写入前返回主会话，不自动重规划。</p></div>
</section></div><div class="drawer-footer"><span class="hint">本页草稿 · 保存或提交后才持久化</span><button type="button" id="drawerDone">完成配置</button></div></aside>
</fieldset></form>
<details class="panel runtime-details" aria-labelledby="compatTitle"><summary>运行环境与运行时代码 <span class="hint">展开诊断与兼容性信息</span></summary><div class="section-heading"><h2 id="compatTitle">运行环境</h2><button type="button" id="refresh">刷新状态</button></div><div id="compatibility" class="banner">正在读取环境与模型目录…</div><ul id="issues"></ul><div aria-labelledby="runtimeTitle"><h3 id="runtimeTitle">运行时代码</h3><div id="runtimeCode" class="hint" aria-live="polite">当前实例未提供运行时标识，无法确认</div></div><p id="storage" class="storage"></p></details>
<section class="panel" aria-labelledby="jobsTitle"><div class="section-heading"><h2 id="jobsTitle">任务记录</h2><span id="jobCount" class="hint"></span></div><div class="table-scroll"><table><thead><tr><th>任务 / ID</th><th>状态</th><th>项目与创建时间</th><th>操作</th></tr></thead><tbody id="jobRows"></tbody></table></div><p id="noJobs" class="empty" hidden>还没有任务。点击流程卡片配置，生成第一个任务。</p></section>
<section id="taskDetail" class="panel" aria-labelledby="detailTitle" hidden><div class="section-heading"><h2 id="detailTitle">任务详情</h2><button type="button" id="refreshDetail">刷新此任务</button></div><div id="detailBody"></div></section>
</main>
<script>
(function () {
  'use strict';
  var boot = ${boot} || {};
  var projectFlowModel = ${flowModel.toString()};
  var mountFlow = ${createFlowView.toString()};
  var embedded = boot.embedded === true, detached = boot.detached === true, bound = embedded || detached;
  var bridgeOrigin = boot && boot.parentOrigin || window.origin || location.origin;
  try { var originUrl = new URL(bridgeOrigin); if (!/^https?:$/.test(originUrl.protocol) || originUrl.origin !== bridgeOrigin || originUrl.username || originUrl.password) bridgeOrigin = ''; } catch (_) { bridgeOrigin = ''; }
  var bridgeReady = !bound || ((detached ? location.origin === bridgeOrigin : parent !== window) && !!bridgeOrigin && typeof boot.sessionId === 'string' && !!boot.sessionId && typeof boot.bridgeId === 'string' && !!boot.bridgeId);
  var token = typeof boot.token === 'string' && boot.token ? boot.token : new URLSearchParams(location.search).get('token');
  var apiBase = '/dsh-orchestrator/settings/api/';
  var catalog = [], cards = {}, ready = false, busy = false, initialized = false, createdId = '', selectedId = '', detailGeneration = 0;
  var submissions = new Map(), activeDelivery = null;
  var $ = function (id) { return document.getElementById(id); };
  function el(tag, text, className) { var n = document.createElement(tag); if (text !== undefined) n.textContent = String(text); if (className) n.className = className; return n; }
  function message(text, isError) { var n = $('message'); n.textContent = text; n.className = 'banner ' + (isError ? 'error' : 'ok'); n.setAttribute('role', isError ? 'alert' : 'status'); n.hidden = false; }
  function validationError(text, fieldId) { var error = new Error(text); error.fieldId = fieldId; return error; }
  function fail(error) { if (error && error.fieldId) revealField($(error.fieldId)); message(error instanceof Error ? error.message : '操作失败，请稍后重试。', true); }
  var drawerKey = '', drawerTrigger = null;
  var editorTitles = {planner:'规划 · Planner', feasibility:'可行性 · Feasibility', worker:'实施 · Workers', assertions:'验证 · Verifier', reviewer:'复核 · Reviewer', task:'任务与文件范围', limits:'限额与高级配置'};
  function openDrawer(key, trigger) {
    if (!editorTitles[key]) return;
    drawerKey = key; if (trigger) drawerTrigger = trigger;
    $('drawerTitle').textContent = editorTitles[key]; $('configDrawer').hidden = false;
    Object.keys(cards).forEach(function (role) { cards[role].box.hidden = role !== key; });
    ['task','limits','assertions'].forEach(function (name) { $('pane-' + name).hidden = name !== key; });
    $('workerCapacity').hidden = key !== 'worker';
    document.querySelectorAll('[data-open]').forEach(function (node) { node.setAttribute('aria-expanded', String(node.dataset.open === key)); });
    $('drawerClose').focus();
  }
  function closeDrawer() {
    $('configDrawer').hidden = true; drawerKey = '';
    document.querySelectorAll('[data-open]').forEach(function (node) { node.setAttribute('aria-expanded', 'false'); });
    if (drawerTrigger && drawerTrigger.isConnected) drawerTrigger.focus();
  }
  function revealField(field) {
    if (!field) return;
    var role = Object.keys(cards).find(function (key) { return cards[key].box.contains(field); });
    var key = role || (field.id === 'maxWorkers' ? 'worker' : ['maxPlanRetries','maxRepairRounds','rollbackOnFailure'].includes(field.id) ? 'limits' : 'task');
    openDrawer(key, document.querySelector('[data-open="' + key + '"]'));
    var ancestor = field.parentElement;
    while (ancestor && ancestor !== $('configDrawer')) { if (ancestor.tagName === 'DETAILS') ancestor.open = true; ancestor = ancestor.parentElement; }
    field.focus(); field.scrollIntoView({block:'nearest'});
  }
  function reviewLevelValue() { return ['exploratory','standard','strict'].includes($('reviewLevel').value) ? $('reviewLevel').value : 'standard'; }
  function renderConfigCanvas() {
    var level = reviewLevelValue(), exploratory = level === 'exploratory', strict = level === 'strict';
    if (cards.reviewer) cards.reviewer.routeFields.disabled = exploratory;
    document.querySelectorAll('input[name="reviewMode"]').forEach(function (field) { field.disabled = level !== 'standard'; });
    $('maxRepairRounds').disabled = exploratory;
    $('reviewLevelNotice').textContent = exploratory ? '探索：不调用模型复核，不自动修复；已选数据断言仍实际执行，非通过（含不适用）会受阻。成果仅供试用，运行时仍待验证。' : strict ? '严格：总是独立复核，不按断言通过跳过；扩大复核关注范围，但不会自动执行运行时检查。' : '标准：保持现有兼容行为，按复核时机与修复轮数执行；静态复核不代表运行时验证。';
    var sequence = [['planner','规划','Planner','只读规划'],['feasibility','可行性','Feasibility','按计划形状启用'],['worker','实施','Workers','共享路由 · 并行 ≤ ' + $('maxWorkers').value],['assertions','验证','Verifier','确定性脚本 · 真实执行'],['reviewer','复核','Reviewer','独立只读复核']];
    var host = $('configPipeline');
    if (!host.children.length) {
      sequence.forEach(function (item, index) {
        var node = el('button', undefined, 'config-node'); node.type = 'button'; node.dataset.open = item[0]; node.id = 'node-' + item[0]; node.setAttribute('aria-controls','configDrawer'); node.setAttribute('aria-expanded','false');
        node.append(el('span', '0' + (index + 1) + ' / CONFIGURE ↗', 'node-index'));
        var title = el('span', item[1], 'node-title'); title.append(el('small', item[2]));
        node.append(title, el('span', '', 'node-route'), el('span', '', 'node-meta')); host.append(node);
      });
      var finish = el('div', undefined, 'config-finish'); finish.append(el('span','✓'),document.createTextNode('交付')); host.append(finish);
    }
    sequence.forEach(function (item) {
      var node = $('node-' + item[0]), route = cards[item[0]], model = route && modelFor(route.provider.value.trim(), route.model.value.trim());
      var missingAssertions = $('unknownAssertions') ? $('unknownAssertions').querySelectorAll('input:checked').length : 0;
      node.querySelector('.node-route').textContent = route ? (model && model.label || route.model.value || '尚未选择模型') : selectedAssertions().length + ' 项选择' + (missingAssertions ? ' · ' + missingAssertions + ' 项目录缺失' : '');
      node.dataset.warning = String(!route && missingAssertions > 0);
      node.querySelector('.node-meta').textContent = route ? (route.provider.value || '未选 Provider') + ' · ' + (route.effort.value || '默认 / 继承') + ' · ' + item[3] : item[3];
      if (item[0] === 'worker') {
        var slots = node.querySelector('.worker-slots');
        if (!slots) { slots = el('span', undefined, 'worker-slots'); node.append(slots); }
        slots.replaceChildren();
        var cap = Math.max(1, Math.min(6, Number($('maxWorkers').value) || 1));
        for (var i=1;i<=Math.min(cap,2);i++) slots.append(el('span','↳ 并行槽 ' + i));
        if (cap>2) slots.append(el('span','＋' + (cap-2) + ''));
        slots.title='并发上限示意，不代表固定任务数量；实际任务与依赖由 Planner 分配。';
      }
      if (item[0] === 'reviewer') {
        node.dataset.inactive = String(exploratory);
        node.querySelector('.node-meta').textContent = exploratory ? '探索 · 已停用模型复核 / 自动修复 · 点击切换级别' : (strict ? '严格 · 总是复核，不按断言跳过' : '标准 · 独立只读复核');
        if (exploratory) node.querySelector('.node-route').textContent = '探索模式 · 运行时待验证';
      }
      node.setAttribute('aria-label', '配置' + item[1] + (item[0] === 'worker' ? '，所有 Worker 共用路由' : item[0] === 'reviewer' ? '，验证级别：' + (exploratory ? '探索，复核已停用' : strict ? '严格' : '标准') : ''));
    });
    $('scopeTaskSummary').textContent = $('task').value.trim() || '先定义任务与文件范围';
    $('scopePathSummary').textContent = ($('projectRoot').value.trim() || '未填写项目目录') + ' · ' + (lines('allowedGlobs').join('、') || '未设置允许范围');
    var conditional = level === 'standard' && (document.querySelector('input[name="reviewMode"]:checked') || {}).value === 'on_failure';
    $('bypassWire').hidden = !exploratory && (!conditional || !selectedAssertions().length);
    $('bypassWire').querySelector('span').textContent = exploratory ? '探索 · 跳过模型复核 / 不自动修复 → 待试用' : '实测通过 · 跳过模型复核 → 待运行时验证';
    $('repairWire').hidden = exploratory || Number($('maxRepairRounds').value) === 0;
    var repairText = exploratory ? '探索不自动修复（保留配置 ' + $('maxRepairRounds').value + '）' : Number($('maxRepairRounds').value) > 0 ? '当前执行器至多 1 次定向修复' : '定向修复已关闭';
    if (!exploratory && Number($('maxRepairRounds').value) > 1) repairText += '（历史配置 ' + $('maxRepairRounds').value + ' 已保留，不会执行两轮）';
    $('repairSummary').textContent = '← 问题与证据返回 Planner · 修复后重新验证 · ' + repairText;
    $('policySummary').textContent = (exploratory ? '探索：不做模型复核；所选断言仍执行，非通过即受阻；运行时待验证' : conditional ? '标准：断言实测通过才跳过复核；未执行、失败或警告进入 Reviewer' : (strict ? '严格：' : '标准：') + '始终独立复核；断言通过也不跳过 Reviewer') + ' · ' + repairText;
  }
  document.addEventListener('click', function (event) { var node = event.target.closest('[data-open]'); if (node) openDrawer(node.dataset.open, node); });
  $('drawerClose').addEventListener('click', closeDrawer); $('drawerDone').addEventListener('click', closeDrawer);
  document.addEventListener('keydown', function (event) { if (event.key === 'Escape' && drawerKey) { event.preventDefault(); closeDrawer(); } });
  var invalidPending = false;
  $('configForm').addEventListener('invalid', function (event) {
    event.preventDefault(); if (invalidPending) return;
    invalidPending = true; revealField(event.target); message(event.target.validationMessage || '请检查此项配置。', true);
    queueMicrotask(function () { invalidPending = false; });
  }, true);
  $('configForm').addEventListener('input', renderConfigCanvas); $('configForm').addEventListener('change', renderConfigCanvas);
  function taskConfig() {
    var config = defaultsValue(), task = $('task').value.trim(), root = $('projectRoot').value.trim();
    if (!task || !root) throw new Error('请填写项目目录和任务说明。');
    config.task = task; config.projectRoot = root; config.verifyHint = $('verifyHint').value.trim();
    return config;
  }
  function currentSubmission() {
    if (!bound) return undefined;
    try { return submissions.get(JSON.stringify(taskConfig())); } catch (_) { return undefined; }
  }
  function syncSubmitState() {
    var record = currentSubmission(), locked = !!(record && (record.status === 'sent' || record.status === 'uncertain' || record.status === 'creation-unknown'));
    $('createJob').disabled = busy || !ready || !bridgeReady || locked;
    if (bound) $('createJob').textContent = record && record.status === 'retry' ? '重试发送（复用任务）' : record && record.status === 'sent' ? '已发送到本会话' : record && record.status === 'uncertain' ? '请先查看会话确认' : record && record.status === 'creation-unknown' ? '请先查看任务列表' : '开始编排';
  }
  function setBusy(value) { busy = value; ['saveDefaults', 'refresh', 'refreshDetail'].forEach(function(id) { $(id).disabled = value; }); syncSubmitState(); }
  function settleDelivery(result) {
    var delivery = activeDelivery;
    if (!delivery) return;
    activeDelivery = null; clearTimeout(delivery.timer); clearTimeout(delivery.pollTimer);
    var record = delivery.record;
    if (result.uncertain === true) {
      record.status = 'uncertain';
      message('任务 ' + record.id + ' 的发送结果尚不确定。请返回目标会话查看是否已收到指令；为避免重复执行和计费，本配置已禁止重试发送。' + (typeof result.error === 'string' ? ' ' + result.error : ''), true);
    } else if (result.ok === true) {
      record.status = 'sent';
      showFlow(record.id);
      message((result.queued ? '执行指令已发送；目标会话正在忙碌，已在本会话排队。' : '执行指令已发送到目标会话。') + '任务 ' + record.id + ' 的投递已确认，不代表编排已经完成。流程图将自动更新，也可以关闭面板稍后重新查看。');
    } else {
      record.status = 'retry';
      message(result.timeout ? '等待会话确认已超过 25 秒。请先查看目标会话；如需重试，将复用任务 ' + record.id + '，不会再次创建任务。' : '任务 ' + record.id + ' 已创建，但指令未确认送达：' + (typeof result.error === 'string' ? result.error : '请重试发送。') + ' 重试会复用同一任务。', true);
    }
    syncSubmitState(); delivery.resolve(result);
  }
  function deliverBrowser(record) {
    record.status = 'pending';
    return new Promise(function (resolve) {
      var delivery = {record:record, resolve:resolve, timer:setTimeout(function () {
        if (activeDelivery === delivery) settleDelivery({ok:false, uncertain:true, error:'等待原 DSH 会话确认超过 2 分钟。请查看原会话，勿重复执行。'});
      }, 120000)};
      activeDelivery = delivery;
      function consume(state) {
        if (activeDelivery !== delivery) return true;
        var item = state && Array.isArray(state.deliveries) && state.deliveries.find(function (entry) { return entry.taskId === record.id; });
        if (item && ['sent','retry','uncertain'].includes(item.status)) {
          settleDelivery(item.result || {ok:false, uncertain:true, error:'服务端缺少投递确认'}); return true;
        }
        return false;
      }
      async function poll() {
        if (activeDelivery !== delivery) return;
        try { if (consume(await api('bridge/status?bridgeId=' + encodeURIComponent(boot.bridgeId)))) return; }
        catch (error) { if ([401,403].includes(error.status)) { if (activeDelivery === delivery) settleDelivery({ok:false, uncertain:true, error:error.message}); return; } }
        if (activeDelivery === delivery) delivery.pollTimer = setTimeout(poll, 1500);
      }
      message('任务 ' + record.id + ' 已保存，正在回传到绑定的原 DSH 会话。请保持 DSH 开启；关闭浏览器不会取消已启动任务。');
      api('bridge/submit', {bridgeId:boot.bridgeId, taskId:record.id}).then(function (state) {
        if (!consume(state)) poll();
      }).catch(function (error) {
        if (activeDelivery !== delivery) return;
        // A validation/auth refusal cannot enqueue. A lost HTTP response might
        // have enqueued, so recover its receipt rather than automatically retry.
        if ([400,401,403,404,415].includes(error.status)) settleDelivery({ok:false,error:error.message});
        else poll();
      });
    });
  }
  function deliver(record) {
    if (detached) return deliverBrowser(record);
    record.status = 'pending';
    return new Promise(function (resolve) {
      activeDelivery = {record: record, resolve: resolve, timer: setTimeout(function () { settleDelivery({ok:false, timeout:true}); }, 25000)};
      message('任务 ' + record.id + ' 已创建，正在向目标会话发送执行指令…');
      try { parent.postMessage({type:'dsh-orchestrator:start', sessionId:boot.sessionId, bridgeId:boot.bridgeId, taskId:record.id}, bridgeOrigin); }
      catch (error) { settleDelivery({ok:false, error:error instanceof Error ? error.message : '无法联系目标会话。'}); }
    });
  }
  window.addEventListener('message', function (event) {
    if (detached || !embedded || event.source !== parent || event.origin !== bridgeOrigin || !activeDelivery) return;
    var result = event.data;
    if (!result || result.type !== 'dsh-orchestrator:result' || result.sessionId !== boot.sessionId || result.bridgeId !== boot.bridgeId || result.taskId !== activeDelivery.record.id || typeof result.ok !== 'boolean') return;
    settleDelivery(result);
  });
  if (bound) {
    document.title = detached ? 'AI 编排 · 浏览器工作台' : '在本会话开始编排'; $('pageTitle').textContent = detached ? 'AI 编排工作台' : '在本会话开始编排';
    $('pageDescription').textContent = detached ? '点击流程卡片配置模型与断言。此窗口绑定打开时的 DSH 会话，不会跟随会话切换；请保持 DSH 开启。' : '配置模型与文件边界后，点击「开始编排」即可向这个会话发送执行指令，无需复制任务 JSON。';
    $('sessionTarget').textContent = '目标会话：' + (typeof boot.sessionTitle === 'string' && boot.sessionTitle ? boot.sessionTitle + ' · ' : '') + boot.sessionId; $('sessionTarget').hidden = false;
    $('taskTitle').textContent = '配置并开始编排';
    $('taskNotice').textContent = '提交后会先创建任务，再向上方目标会话发送执行指令。会话忙碌时进入该会话的下一轮队列；发送成功不代表任务完成。';
    $('createJob').textContent = '开始编排'; $('copyCreated').hidden = true;
    if (detached) { $('saveDefaults').textContent = '保存本窗口默认'; $('saveDefaults').title = '仅在本浏览器连接有效期内保留，最多 8 小时；不覆盖 DSH 全局默认设置'; $('taskNotice').textContent += ' 关闭浏览器不会停止已经启动的后台任务；刷新 DSH 原页面后，请从原会话重新打开连接。'; }
  }
  if (typeof boot.workspaceRoot === 'string' && !$('projectRoot').value) $('projectRoot').value = boot.workspaceRoot;
  async function api(route, body) {
    if (!token) throw new Error('缺少设置页访问令牌，请刷新 DSH 页面后从插件设置重新进入。');
    if (!bridgeOrigin) throw new Error('页面来源无效，请从 DSH 编排按钮或插件设置重新进入。');
    var controller = new AbortController();
    var timer = setTimeout(function () { controller.abort(); }, 25000);
    try {
      var options = {method: body === undefined ? 'GET' : 'POST', headers: {'x-settings-token': token}, credentials: 'same-origin', cache: 'no-store', signal: controller.signal};
      if (detached) options.headers['x-orchestrator-bridge'] = boot.bridgeId;
      if (body !== undefined) { options.headers['Content-Type'] = 'application/json'; options.body = JSON.stringify(body); }
      var response = await fetch(new URL(apiBase + route, bridgeOrigin).href, options);
      var data;
      try { data = await response.json(); } catch (_) { throw new Error('服务端返回了无法解析的响应（HTTP ' + response.status + '）。'); }
      if (!response.ok) { var detail = data && (typeof data.error === 'string' ? data.error : typeof data.message === 'string' ? data.message : data.error && data.error.message); var error = new Error(typeof detail === 'string' ? detail : '请求失败（HTTP ' + response.status + '）。'); error.status = response.status; throw error; }
      return data;
    } catch (error) { if (error && error.name === 'AbortError') throw new Error('请求超时，请确认服务可用后重试。'); throw error; }
    finally { clearTimeout(timer); }
  }
  function option(value, label) { var n = el('option', label); n.value = value; return n; }
  function modelFor(provider, model) { return catalog.find(function (entry) { return entry.provider === provider && entry.model === model; }); }
  function routeKey(provider, model) { return JSON.stringify([provider, model]); }
  function createCard(key, title, description, index) {
    var box = el('div', undefined, 'model-card');
    var heading = el('h3'); heading.append(el('span', index, 'step'), document.createTextNode(title)); box.append(heading, el('p', description, 'hint'));
    var selectId = key + 'Model', effortId = key + 'Effort';
    var label = el('label', '模型'); label.htmlFor = selectId;
    var select = el('select'); select.id = selectId; select.setAttribute('aria-label', title + '模型');
    var effortLabel = el('label', '推理档位'); effortLabel.htmlFor = effortId;
    var effort = el('select'); effort.id = effortId;
    var manual = el('details'), summary = el('summary', '手动指定 Provider / Model（可选）');
    var pLabel = el('label', 'Provider ID'); pLabel.htmlFor = key + 'Provider';
    var provider = el('input'); provider.id = key + 'Provider'; provider.autocomplete = 'off';
    var mLabel = el('label', 'Model ID'); mLabel.htmlFor = key + 'ModelId';
    var model = el('input'); model.id = key + 'ModelId'; model.autocomplete = 'off';
    var routeHint = el('p', '', 'hint');
    var probe = el('button', '校验此模型能力（不生成内容）'); probe.type = 'button'; probe.id = key + 'CheckModel';
    manual.append(summary, pLabel, provider, mLabel, model, probe, routeHint);
    if (key === 'reviewer') {
      var levelLabel = el('label', '验证级别'); levelLabel.htmlFor = 'reviewLevel';
      var level = el('select'); level.id = 'reviewLevel'; level.setAttribute('aria-label', '验证级别');
      [['exploratory','探索'],['standard','标准'],['strict','严格']].forEach(function (entry) { level.append(option(entry[0], entry[1])); }); level.value = 'standard';
      var levelNotice = el('p', '', 'hint'); levelNotice.id = 'reviewLevelNotice'; levelNotice.setAttribute('aria-live','polite');
      box.append(levelLabel, level, levelNotice);
    }
    var routeFields = el('fieldset'); routeFields.append(label, select, effortLabel, effort, manual); box.append(routeFields);
    $('modelCards').append(box);
    box.id = 'editor-' + key; box.hidden = true;
    var card = {box: box, select: select, effort: effort, manual: manual, provider: provider, model: model, routeHint: routeHint, routeFields: routeFields}; cards[key] = card;
    var probed = null, generation = 0;
    function entryForRoute() { var p = provider.value.trim(), m = model.value.trim(); return probed && probed.provider === p && probed.model === m ? probed : modelFor(p, m); }
    function refreshEfforts(wanted) {
      var entry = entryForRoute(); effort.replaceChildren(option('', '不指定'));
      if (entry && Array.isArray(entry.efforts)) entry.efforts.forEach(function (e) { if (typeof e.id === 'string' && e.id) effort.append(option(e.id, e.name || e.id)); });
      var supported = !wanted || Array.from(effort.options).some(function (o) { return o.value === wanted; });
      if (!supported) effort.append(option(wanted, wanted + '（能力未声明，请重新选择或校验）'));
      effort.value = wanted || '';
      routeHint.textContent = !supported ? '原档位已保留，但当前能力不支持，提交前必须重新选择；不会静默降级。' : entry ? '精确模型能力已读取；可选档位仅属于本模型。' : '模型不在目录中；可校验精确路由后读取档位，暂仅可选择「不指定」。';
    }
    probe.addEventListener('click', async function () {
      var target = {provider: provider.value.trim(), model: model.value.trim()}, ticket = ++generation;
      probe.disabled = true;
      try {
        if (!target.provider || !target.model) throw new Error('请先完整填写 Provider 和 Model。');
        var data = await api('model', target);
        if (ticket !== generation || provider.value.trim() !== target.provider || model.value.trim() !== target.model) return;
        if (!data.model || data.model.provider !== target.provider || data.model.model !== target.model || !Array.isArray(data.model.efforts)) throw new Error('模型能力响应不完整或路由不一致。');
        probed = data.model; refreshEfforts(effort.value); message(title + '的精确模型能力已读取；尚未调用模型生成内容，也未保证远端服务可用。');
      } catch (error) { if (ticket === generation) fail(error); }
      finally { probe.disabled = false; }
    });
    card.fill = function (route) {
      generation++; route = route || {}; provider.value = route.provider || ''; model.value = route.model || '';
      select.replaceChildren(option('', '请选择模型'), option('__manual__', '手动指定模型…'));
      catalog.forEach(function (entry) { select.append(option(routeKey(entry.provider, entry.model), (entry.label || entry.model) + ' · ' + entry.provider)); });
      var known = modelFor(provider.value, model.value);
      select.value = known ? routeKey(provider.value, model.value) : provider.value || model.value ? '__manual__' : '';
      manual.open = select.value === '__manual__'; refreshEfforts(route.effort || '');
    };
    select.addEventListener('change', function () {
      generation++; probed = null;
      if (select.value === '__manual__') { manual.open = true; provider.focus(); refreshEfforts(''); return; }
      var selected = select.value ? JSON.parse(select.value) : ['', '']; provider.value = selected[0]; model.value = selected[1]; manual.open = false; refreshEfforts('');
    });
    function manualChanged() { generation++; probed = null; select.value = '__manual__'; refreshEfforts(''); }
    provider.addEventListener('input', manualChanged); model.addEventListener('input', manualChanged);
    card.value = function () {
      var providerId = provider.value.trim(), modelId = model.value.trim();
      if (!providerId || !modelId) throw validationError('请为' + title + '选择模型，或完整填写 Provider 与 Model。', key + 'Model');
      var result = {provider: providerId, model: modelId};
      if (effort.value) {
        var entry = entryForRoute();
        if (!entry || !entry.efforts.some(function (item) { return item.id === effort.value; })) throw validationError(title + '的当前档位未被精确模型能力支持；请重新选择或校验能力。', key + 'Effort');
        result.effort = effort.value;
      }
      return result;
    };
  }
  createCard('planner', '规划模型', '将任务拆成目标、硬约束与建议步骤，提供源码可行性自检；模型与精确档位来自服务端目录。', '01');
  createCard('worker', '执行模型', '所有 Worker 共享本路由和档位。仅无依赖任务可并行；任务数量与执行波次由真实计划决定，写入受文件边界限制。', '03');
  createCard('feasibility', '写入前复核模型', '多任务或跨任务依赖时，独立只读检查可实施性；单任务无跨任务依赖采用 Planner 自检。缺省路由沿用规划模型；独立检查会话失败会标注降级。', '02');
  createCard('reviewer', '复核模型', '写入后独立只读复核目标、约束、实际修改与验证证据。模型及档位独立配置；复核时机在 Verifier 中设置。', '05');
  function lines(id) { return $(id).value.split(/\r?\n/).map(function (s) { return s.trim(); }).filter(Boolean); }
  function integer(id, min, label, max) { var value = Number($(id).value); if (!$(id).value.trim() || !Number.isSafeInteger(value) || value < min || (max !== undefined && value > max)) throw validationError(label + '必须是大于等于 ' + min + (max === undefined ? '' : '、小于等于 ' + max) + ' 的安全整数。', id); return value; }
  function esc(text) { return String(text == null ? '' : text).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function assertionBoxes() { return Array.prototype.slice.call(document.querySelectorAll('#assertGroups input[type="checkbox"]')); }
  function selectedAssertions() { return assertionBoxes().filter(function (box) { return box.checked; }).map(function (box) { return box.value; }); }
  function applyAssertions(list) {
    var keep = new Set((Array.isArray(list) ? list : []).filter(function (value) { return typeof value === 'string' && value; }));
    var old = $('unknownAssertions'); if (old) old.remove();
    assertionBoxes().forEach(function (box) { box.checked = keep.has(box.value); keep.delete(box.value); });
    if (keep.size) {
      var unknown = el('div', undefined, 'unknown-assertions'); unknown.id = 'unknownAssertions';
      unknown.append(el('strong', '目录中未找到的已选断言'), el('p', '这些值完整保留，仍会提交；请确认断言目录可用或明确取消选择，不会静默清除。', 'hint'));
      keep.forEach(function (value) { var label = el('label', undefined, 'check'), box = el('input'); box.type = 'checkbox'; box.value = value; box.checked = true; label.append(box, el('span', value)); unknown.append(label); });
      $('assertGroups').append(unknown);
    }
  }
  function renderAssertions(directory) {
    var selected = selectedAssertions(), host = $('assertGroups'), html = '';
    if (!directory || directory.available === false) {
      host.replaceChildren(el('p', (directory && directory.reason) || '断言库不可用', 'hint'));
      $('assertNotice').textContent = '断言库当前不可用；已选值仍会保留并提交，请恢复目录或明确取消。未实际执行不能视为通过。';
      applyAssertions(selected); return;
    }
    $('assertNotice').textContent = 'Verifier 在编排内实际执行所选断言并保留证据。包、组、单条的选择原样提交；未选择或未执行不代表通过，失败或警告不会直接放行。';
    (directory.packs || []).forEach(function (pack) {
      html += '<details class="assert-pack"><summary>' + esc(pack.name || pack.id) + ' · ' + esc(pack.id) + ' · ' + Number(pack.checkCount || 0) + ' 条</summary><label class="check"><input type="checkbox" value="' + esc(pack.id) + '"><span>选择整个包 · ' + esc(pack.id) + '</span></label>';
      (pack.groups || []).forEach(function (group) {
        html += '<details class="assert-group"><summary>' + esc(group.name || group.id) + ' · ' + (group.checks || []).length + ' 条</summary><label class="check"><input type="checkbox" value="' + esc(pack.id + '/' + group.id) + '"><span>选择整个组 · ' + esc(group.id) + '</span></label>';
        (group.checks || []).forEach(function (check) {
          html += '<div class="assert-leaf"><label class="check"><input type="checkbox" value="' + esc(check.id) + '"><span>' + esc(check.name || check.id) + (check.perProject ? ' · 整项目级' : '') + '<br><span class="hint">' + esc(check.id) + ' · ' + esc(check.severity) + ' · ' + esc(check.spec || '') + '</span></span></label></div>';
        });
        html += '</details>';
      });
      html += '</details>';
    });
    host.innerHTML = html || '<p class="hint">断言目录为空。</p>';
    applyAssertions(selected);
  }
  function defaultsValue() {
    var allowed = lines('allowedGlobs'); if (!allowed.length) throw validationError('请至少填写一条允许的文件范围。', 'allowedGlobs');
    var config = {planner: cards.planner.value(), worker: cards.worker.value(), feasibility: cards.feasibility.value(), reviewLevel: reviewLevelValue(), maxWorkers: integer('maxWorkers', 1, '最大并发 Worker'), maxPlanRetries: integer('maxPlanRetries', 0, '重新规划次数'), maxRepairRounds: integer('maxRepairRounds', 0, '定向修复轮数', 2), rollbackOnFailure: $('rollbackOnFailure').checked, allowedGlobs: allowed, protectedFiles: lines('protectedFiles'), allowProtected: $('allowProtected').checked, assertions: selectedAssertions(), reviewMode: (document.querySelector('input[name="reviewMode"]:checked') || {}).value || 'always'};
    if (config.reviewLevel === 'exploratory') { try { config.reviewer = cards.reviewer.value(); } catch (_) { /* Unused route must not block exploration. Keep its raw editor state. */ } }
    else config.reviewer = cards.reviewer.value();
    return config;
  }
  function fillDefaults(defaults) {
    defaults = defaults || {}; cards.planner.fill(defaults.planner); cards.worker.fill(defaults.worker); cards.feasibility.fill(defaults.feasibility === undefined ? defaults.planner : defaults.feasibility); cards.reviewer.fill(defaults.reviewer === undefined ? defaults.planner : defaults.reviewer);
    $('maxWorkers').value = defaults.maxWorkers === undefined ? 2 : defaults.maxWorkers;
    $('maxPlanRetries').value = defaults.maxPlanRetries === undefined ? 1 : defaults.maxPlanRetries;
    $('maxRepairRounds').value = defaults.maxRepairRounds === undefined ? 1 : defaults.maxRepairRounds; $('rollbackOnFailure').checked = defaults.rollbackOnFailure !== false;
    $('allowedGlobs').value = (defaults.allowedGlobs || ['src/**']).join('\n');
    $('protectedFiles').value = (defaults.protectedFiles || []).join('\n'); $('allowProtected').checked = defaults.allowProtected === true;
    applyAssertions(defaults.assertions);
    $('reviewLevel').value = ['exploratory','strict'].includes(defaults.reviewLevel) ? defaults.reviewLevel : 'standard';
    var reviewMode = defaults.reviewMode === 'on_failure' ? 'on_failure' : 'always';
    Array.prototype.slice.call(document.querySelectorAll('input[name="reviewMode"]')).forEach(function (box) { box.checked = box.value === reviewMode; });
    renderConfigCanvas();
  }
  function dateText(value) { if (value === undefined || value === null || value === '') return '未记录时间'; var d = new Date(value); return Number.isNaN(d.getTime()) ? String(value) : d.toLocaleString(); }
  var statusNames = {planned:'规划完成，未修改',needs_validation:'执行完毕，待项目验证',review_failed:'复核发现问题',review_error:'复核异常',retrying:'重试中',created:'已生成',pending:'待执行',queued:'待执行',running:'运行中',planning:'规划中',executing:'执行中',completed:'已完成',failed:'失败',killed:'已停止',stopping:'停止中',cancelled:'已取消',blocked:'受阻',ready:'可行',needs_clarification:'待澄清',verified_statically:'静态复核通过，未验证运行时',issues_found:'发现具体问题',unable_to_verify:'无法静态判定，需实测'};
  function statusText(status) { return statusNames[status] ? statusNames[status] + ' · ' + status : String(status || '未知'); }
  function instruction(id) { return '使用 orchestrate_run 工具执行任务 ' + id; }
  async function copy(text) {
    try { if (navigator.clipboard && window.isSecureContext) { await navigator.clipboard.writeText(text); message('执行指令已复制。复制不会启动任务。'); return; } }
    catch (_) { /* Try a user-initiated legacy copy before offering manual selection. */ }
    var area = el('textarea'); area.value = text; area.setAttribute('aria-label', '请手动复制执行指令'); area.style.cssText = 'position:fixed;left:16px;bottom:16px;z-index:10000;width:calc(100% - 32px);max-width:800px;min-height:80px'; document.body.append(area); area.focus(); area.select();
    var copied = false; try { copied = document.execCommand('copy'); } catch (_) { copied = false; }
    if (copied) { area.remove(); message('执行指令已复制。复制不会启动任务。'); }
    else { message('浏览器未允许复制。已选中底部指令，请按 Ctrl+C 手动复制，完成后点其他位置关闭。', true); area.addEventListener('blur', function () { area.remove(); }, {once:true}); }
  }
  function button(label, action) { var n = el('button', label); n.type = 'button'; n.addEventListener('click', action); return n; }
  function renderJobs(jobs) {
    $('jobRows').replaceChildren(); $('jobCount').textContent = jobs.length + ' 个任务'; $('noJobs').hidden = jobs.length !== 0;
    jobs.forEach(function (job) {
      var row = el('tr'), name = el('td', undefined, 'task'); name.append(el('div', job.task || '未命名任务'), el('div', job.id, 'id'));
      var status = el('td'); status.append(el('span', statusText(job.status), 'badge'));
      var meta = el('td'); meta.append(el('div', job.projectRoot || '未记录项目'), el('div', dateText(job.createdAt), 'hint'));
      var actions = el('td'), group = el('div', undefined, 'row-actions');
      group.append(button('查看', function () { viewTask(job.id); }), button('复制指令', function () { copy(instruction(job.id)).catch(fail); })); actions.append(group); row.append(name, status, meta, actions); $('jobRows').append(row);
    });
  }
  function renderRuntime(runtime) {
    var host = $('runtimeCode'), unknown = '当前实例未提供运行时标识，无法确认';
    host.replaceChildren();
    if (!runtime || typeof runtime !== 'object') { host.append(el('p', unknown)); return; }
    var buildId = typeof runtime.buildId === 'string' && runtime.buildId.trim() ? runtime.buildId : null;
    var loadedAt = typeof runtime.loadedAt === 'string' && runtime.loadedAt.trim() ? runtime.loadedAt : null;
    var pid = Number.isSafeInteger(runtime.pid) && runtime.pid > 0 ? runtime.pid : null;
    var matches = typeof runtime.sourceMatches === 'boolean' ? runtime.sourceMatches : null;
    var retry = runtime.features && typeof runtime.features.reviewRetry === 'boolean' ? runtime.features.reviewRetry : null;
    if (!buildId || !loadedAt || pid === null || matches === null || retry === null) host.append(el('p', unknown));
    var list = el('dl', undefined, 'kv');
    kv(list, '已加载 buildId', buildId || '未提供');
    kv(list, '模块加载时间', loadedAt || '未提供');
    kv(list, 'PID', pid === null ? '未提供' : pid);
    kv(list, '磁盘一致性', matches === true ? '一致' : matches === false ? '不一致' : '未提供，无法确认');
    kv(list, 'reviewRetry', retry === true ? '支持' : retry === false ? '不支持' : '未提供，无法确认');
    host.append(list);
    if (matches === false) {
      host.append(el('p', '已加载代码与磁盘代码不一致。请完整退出宿主（包括后台进程）后重新启动，再刷新此处确认运行时标识与磁盘一致性。', 'banner warn'));
      var stale = Array.isArray(runtime.staleModules) ? runtime.staleModules.filter(function (name) { return typeof name === 'string'; }) : [];
      if (stale.length) host.append(el('p', '不一致模块：' + stale.join('、')));
    }
  }
  async function loadState(initial) {
    if (busy) return; initial = initial || !initialized; setBusy(true);
    try {
      var state = await api('state');
      if (!state || !Array.isArray(state.models) || !Array.isArray(state.jobs)) throw new Error('状态响应不完整：需要模型目录与任务列表。');
      var current = initial ? null : Object.fromEntries(['planner', 'worker', 'feasibility', 'reviewer'].map(function (key) { var card = cards[key]; return [key, {provider: card.provider.value, model: card.model.value, effort: card.effort.value}]; }));
      catalog = state.models.filter(function (entry) { return entry && typeof entry.provider === 'string' && typeof entry.model === 'string'; });
      renderAssertions(state.assertions);
      if (initial) fillDefaults(state.defaults); else { ['planner', 'worker', 'feasibility', 'reviewer'].forEach(function (key) { cards[key].fill(current[key]); }); }
      renderRuntime(state.compatibility && state.compatibility.runtime);
      ready = !!(state.compatibility && state.compatibility.ready) && !(state.compatibility.runtime && state.compatibility.runtime.sourceMatches === false);
      $('studioStatus').textContent = ready ? '● 服务已连接 · 配置使用宿主真实模型与断言目录' : '● 当前环境未就绪，请展开下方运行环境诊断。';
      $('studioStatus').style.color = ready ? 'var(--ok)' : 'var(--error)';
      $('compatibility').textContent = ready ? (bound ? '环境兼容，可以开始编排。提交后将向上方目标会话发送执行指令。' : '环境兼容，可以生成任务。生成后仍需在对话中明确执行。') : '当前环境尚未就绪，暂不可生成任务。请处理下方兼容性问题后刷新。';
      $('compatibility').className = 'banner ' + (ready ? 'ok' : 'error'); $('issues').replaceChildren();
      if (state.compatibility && state.compatibility.runtime && state.compatibility.runtime.sourceMatches === false) $('issues').append(el('li', '加载代码与磁盘不一致，请完整退出并重启 DSH 后再开始编排。'));
      var issues = state.compatibility && Array.isArray(state.compatibility.issues) ? state.compatibility.issues : ['缺少兼容性检查结果。'];
      issues.forEach(function (issue) { $('issues').append(el('li', typeof issue === 'string' ? issue : issue && issue.message || '未知兼容性问题')); });
      if (Array.isArray(state.warnings)) state.warnings.forEach(function (warning) { $('issues').append(el('li', warning)); });
      $('storage').textContent = state.storagePath ? '任务与默认设置存储位置：' + state.storagePath : '服务端未提供存储位置。';
      renderJobs(state.jobs); $('fields').disabled = false; initialized = true; renderConfigCanvas();
      if (!initial) message('状态已刷新；当前表单内容已保留。');
    } catch (error) { fail(error); } finally { setBusy(false); }
  }
  function kv(container, label, value) { container.append(el('dt', label), el('dd', value === undefined || value === null ? '—' : value)); }
  function displayValue(value, depth) {
    if (value === null || value === undefined) return '—';
    if (typeof value !== 'object') return String(value);
    if (depth >= 3) return '[详细内容已折叠]';
    return Object.entries(value).map(function (entry) { return entry[0] + ': ' + displayValue(entry[1], depth + 1); }).join('\n');
  }
  function textList(container, label, items) {
    container.append(el('p', label, 'hint'));
    if (!Array.isArray(items) || !items.length) { container.append(el('p', '无', 'muted')); return; }
    var list = el('ul'); items.forEach(function (item) { list.append(el('li', item)); }); container.append(list);
  }
  function renderRunDetails(card, run) {
    if (run.plan && Array.isArray(run.plan.tasks)) {
      card.append(el('h3', '任务分层'));
      run.plan.tasks.forEach(function (task) {
        var section = el('div', undefined, 'run'); section.append(el('strong', task.id));
        var values = el('dl', undefined, 'kv'); kv(values, '目标', task.goal || task.instruction); kv(values, '文件', Array.isArray(task.files) ? task.files.join('\n') : '—'); section.append(values);
        if (task.goal) { textList(section, '硬约束（必须遵守）', task.constraints); textList(section, '建议步骤（可调整）', task.suggestedSteps); }
        card.append(section);
      });
    }
    function renderFeasibility(title, check) {
      card.append(el('h3', title), el('p', statusText(check.status)), el('p', check.summary));
      if (Array.isArray(check.tasks)) check.tasks.forEach(function (task) {
        var section = el('div', undefined, 'run'); section.append(el('strong', task.taskId + ' · ' + statusText(task.status)), el('p', task.summary));
        textList(section, '已读实现的证据', task.evidence); textList(section, '待主会话澄清', task.questions); card.append(section);
      });
    }
    if (run.plannerFeasibility) renderFeasibility('planner 源码可行性自检', run.plannerFeasibility);
    var skippedReview = run.reviewSkipped || (run.endedAt && run.verdict === 'exploratory_unreviewed' ? {reason:'exploratory',level:'exploratory'} : null);
    if (skippedReview && !run.review) {
      card.append(el('h3', '独立 reviewer 已跳过'), el('p', '跳过原因：' + skippedReview.reason, 'hint'));
      if (skippedReview.reason === 'exploratory' || skippedReview.level === 'exploratory') card.append(el('p', (run.status === 'blocked' ? '探索受阻：所选数据断言未全部通过。' : '探索完成·待试用。') + '未调用模型复核，未自动修复；成果已保留，运行时尚未验证。', 'banner warn'));
    }
    if (run.assertions) {
      card.append(el('h3', '数据断言实测'), el('p', '状态：' + run.assertions.status + ' · 实际执行 ' + (run.assertions.counts && run.assertions.counts.checks_run || 0) + ' 条 · 退出码 ' + (run.assertions.exit_code === undefined ? '未记录' : run.assertions.exit_code), 'hint'));
      if (run.assertions.reason) card.append(el('p', run.assertions.reason, 'banner warn'));
    }
    if (run.review) {
      card.append(el('h3', '独立 reviewer 复核'));
      var view = run.review;
      var meta = el('p', statusText(view.assessment) + (view.legacyAssessment ? '（旧记录值：' + view.legacyAssessment + '）' : ''), 'hint');
      card.append(meta, el('p', view.summary || '—'));
      if (view.route) card.append(el('p', '复核路由：' + view.route.provider + '/' + view.route.model + (view.route.effort ? ' · ' + view.route.effort : ''), 'hint'));
      // 降级不阻塞结论，但必须让人看见：否则「11 项待验证」里少掉一项没人会注意。
      if (Array.isArray(view.degraded) && view.degraded.length) {
        card.append(el('p', '有 ' + view.degraded.length + ' 项条目被降级为不可自动执行（不阻塞结论）：' + view.degraded.map(function (item) {
          return item.id + '（' + item.issue + '）';
        }).join('；'), 'banner warn'));
      }
      if (Array.isArray(view.checks) && view.checks.length) {
        var table = el('div', undefined, 'run');
        table.append(el('strong', '待主会话执行的验证（' + view.checks.length + ' 项）'));
        view.checks.forEach(function (check) {
          var item = el('div', undefined, 'run');
          var badge = '';
          if (check.owner === 'main') badge += ' · 主会话专用';
          if (check.status === 'unverifiable') badge += ' · 已降级';
          item.append(el('strong', check.id + ' · ' + check.kind + badge));
          var kvList = el('dl', undefined, 'kv');
          kv(kvList, '要确认什么', check.statement);
          kv(kvList, '通过标准', check.expected);
          if (check.command) kv(kvList, '命令', check.command);
          if (check.issue) kv(kvList, '降级原因', check.issue);
          item.append(kvList); table.append(item);
        });
        card.append(table);
      } else card.append(el('p', '未列出结构化验证项。', 'muted'));
    }
    // 复核没交出可用结论时不再回滚代码，界面必须把它说清楚，否则「review_failed」看起来像验证过。
    if (run.reviewError) {
      card.append(el('h3', '独立 reviewer 复核未完成'));
      card.append(el('p', '复核没有交出可用结论；已写入的文件与哈希都保留，请按项目既有流程人工复核，或按 scripts/restore.mjs 还原。', 'banner error'));
      card.append(el('p', displayValue(run.reviewError, 600)));
    }
    if (Array.isArray(run.structuredRecoveries) && run.structuredRecoveries.length) {
      card.append(el('p', '结构化结果补交：' + run.structuredRecoveries.map(function (item) {
        return item.role + '=' + item.status + (item.error ? '（' + displayValue(item.error, 200) + '）' : '');
      }).join('，'), 'hint'));
    }
    if (run.feasibilityPolicy) {
      card.append(el('p', run.feasibilityPolicy.reason, 'hint'));
      if (run.feasibilityPolicy.required && !run.feasibility) card.append(el('p', run.planOnly ? '仅规划：未运行独立复核。' : '未取得独立复核结论。', 'muted'));
    }
    if (run.feasibilityDegraded) card.append(el('p', '独立复核运行失败，已降级为 planner 自检继续：' + displayValue(run.feasibilityDegraded.reason, 0), 'banner error'));
    if (run.feasibility) renderFeasibility(run.plannerFeasibility ? '独立复核（写入前）' : '执行前可行性确认', run.feasibility);
    if (Array.isArray(run.tasks) && run.tasks.length > 1) {
      card.append(el('h3', '任务结果'));
      var taskTable = el('table');
      taskTable.append(el('tr', undefined, 'tr').append(el('th', '任务'), el('th', '状态'), el('th', '说明')));
      run.tasks.forEach(function (task) {
        var row = el('tr'); row.append(el('td', task.taskId), el('td', statusText(task.status)), el('td', displayValue(task.error || task.reason || '—', 0)));
        taskTable.append(row);
      });
      card.append(taskTable);
    }
    if (run.repair) {
      card.append(el('h3', '定向修复'));
      card.append(el('p', run.repair.status === 'blocked'
        ? '修复规划判定无法只靠改代码解决：' + (run.repair.blockers || []).join('；')
        : '第 ' + run.repair.round + ' 轮修复：' + (run.repair.workers || []).map(function (worker) { return worker.taskId + '=' + worker.status; }).join('，'), 'hint'));
      if (run.repair.review) card.append(el('p', '修复后复核：' + statusText(run.repair.review.assessment) + ' · ' + (run.repair.review.summary || '—'), 'hint'));
      // 修复轮中途失败时也要说清失败在哪一步、已经产出了什么，而不是只显示一个空轮次号。
      if (run.repair.error) {
        card.append(el('p', '修复未完成：' + displayValue(run.repair.error, 600), 'banner error'));
        if (Array.isArray(run.repair.files) && run.repair.files.length) {
          card.append(el('p', '修复阶段已落盘：' + run.repair.files.map(function (item) { return item.file + (item.changed ? '=changed' : '=unchanged'); }).join('，'), 'hint'));
        }
      }
      // 修复轮失败时留下那一轮 planner 的正文：复盘「为什么没交结构化结果」的第一手材料。
      if (run.repair.rawOutput) card.append(el('p', '修复规划正文（截断）：' + displayValue(run.repair.rawOutput, 1200), 'hint'));
    }
  }
  async function viewTask(id) {
    selectedId = String(id); var generation = ++detailGeneration; $('taskDetail').hidden = false; $('detailBody').replaceChildren(el('p', '正在读取任务详情…', 'muted'));
    try {
      var data = await api('task?id=' + encodeURIComponent(selectedId)); if (generation !== detailGeneration) return;
      if (!data || !data.job) throw new Error('任务响应缺少 job。');
      var job = data.job, body = $('detailBody'); body.replaceChildren();
      var list = el('dl', undefined, 'kv'); kv(list, '任务 ID', job.id || selectedId); kv(list, '状态', statusText(job.status)); kv(list, '项目目录', job.projectRoot); kv(list, '创建时间', dateText(job.createdAt)); kv(list, '任务说明', job.task); ['planner', 'worker', 'feasibility', 'reviewer'].forEach(function (key) { if (key === 'reviewer' && job.reviewLevel === 'exploratory') { kv(list, 'reviewer（探索已停用）', '不调用模型复核，不自动修复；运行时待验证'); return; } var route = job[key] || ((key === 'reviewer' || key === 'feasibility') ? job.planner : null); if (route) kv(list, key + (((key === 'reviewer' || key === 'feasibility') && !job[key]) ? '（旧配置沿用 planner）' : ''), route.provider + '/' + route.model + (route.effort ? ' · ' + route.effort : ' · 宿主默认/继承')); }); if (job.error) kv(list, '错误', displayValue(job.error, 0)); body.append(list);
      body.append(button('查看实时流程图', function () { showFlow(String(job.id || selectedId)); }));
      var command = instruction(String(job.id || selectedId)); body.append(el('div', command, 'banner instruction'), button('复制执行指令', function () { copy(command).catch(fail); }));
      body.append(el('h3', '执行记录'));
      if (!Array.isArray(data.runs) || !data.runs.length) body.append(el('p', '暂无执行记录。生成任务不会自动开始执行。', 'muted'));
      else data.runs.forEach(function (run, index) { var card = el('div', undefined, 'run'); card.append(el('strong', '记录 ' + (index + 1))); renderRunDetails(card, run); var raw = el('details'); raw.append(el('summary', '完整执行记录'), el('pre', JSON.stringify(run, null, 2))); card.append(raw); body.append(card); });
      $('taskDetail').scrollIntoView({behavior:'smooth',block:'start'});
    } catch (error) { if (generation === detailGeneration) { $('detailBody').replaceChildren(el('p', '读取失败；可点击「刷新此任务」重试。', 'muted')); fail(error); } }
  }
  $('saveDefaults').addEventListener('click', async function () {
    if (busy) return;
    try {
      var value = defaultsValue(), inactiveReviewer = value.reviewLevel === 'exploratory' ? {provider:cards.reviewer.provider.value, model:cards.reviewer.model.value, effort:cards.reviewer.effort.value} : null;
      setBusy(true);
      var result = await api(detached ? 'bridge/draft' : 'save', detached ? {bridgeId:boot.bridgeId, config:value} : value);
      if (!result || !result.planner || !result.worker || !result.feasibility || (value.reviewLevel !== 'exploratory' && !result.reviewer)) throw new Error('保存响应不完整，无法确认当前启用的角色默认设置。');
      var missing = value.assertions.filter(function (id) { return !Array.isArray(result.assertions) || !result.assertions.includes(id); });
      fillDefaults(Object.assign({}, result, {assertions:value.assertions}, inactiveReviewer ? {reviewer:inactiveReviewer} : {}));
      message(missing.length ? '默认设置已保存，但服务端未保存以下断言：' + missing.join('、') + '。这些选择仍保留在本页草稿，请确认目录或明确取消。' : (detached ? '本窗口默认配置已保存，在连接有效期内可恢复（最多 8 小时），不影响 DSH 全局默认。尚未启动任务。' : '默认设置已保存。当前任务尚未生成或执行。'), missing.length > 0);
    }
    catch (error) { fail(error); } finally { setBusy(false); }
  });
  $('configForm').addEventListener('submit', async function (event) {
    event.preventDefault(); if (busy || !ready || !bridgeReady) return;
    var record;
    try {
      var config = taskConfig(), fingerprint = JSON.stringify(config);
      record = bound ? submissions.get(fingerprint) : undefined;
      if (record && (record.status === 'sent' || record.status === 'uncertain' || record.status === 'creation-unknown')) return;
      setBusy(true);
      if (!record) {
        record = {id:'', status:'creating'};
        if (bound) submissions.set(fingerprint, record);
        var result;
        try {
          result = await api('job', config);
          if (!result || typeof result.id !== 'string' || !result.id.trim()) throw new Error('服务端未返回任务 ID。');
        } catch (error) {
          if (bound) record.status = 'creation-unknown';
          throw new Error((error instanceof Error ? error.message : '创建请求失败。') + ' 未能确认任务 ID；请先刷新并查看任务列表，不要直接重试创建，以免生成重复任务。');
        }
        record.id = result.id; record.status = 'created';
      }
      createdId = record.id; $('createdInstruction').textContent = bound ? '任务 ID：' + createdId : instruction(createdId); $('created').hidden = false;
      if (bound) {
        await deliver(record);
        api('state').then(function (state) { if (state && Array.isArray(state.jobs)) renderJobs(state.jobs); }).catch(function () { /* Delivery result remains visible; refresh state manually if needed. */ });
      } else {
        message('任务已生成，尚未执行。复制指令并在 DSH 对话中发送后才会启动。');
        try { var state = await api('state'); if (state && Array.isArray(state.jobs)) renderJobs(state.jobs); else throw new Error('状态响应缺少任务列表。'); }
        catch (error) { message('任务 ' + createdId + ' 已生成，但列表刷新失败：' + error.message + ' 请勿重复提交。', true); }
      }
    } catch (error) { fail(error); } finally { setBusy(false); }
  });
  $('configForm').addEventListener('input', syncSubmitState);
  $('configForm').addEventListener('change', syncSubmitState);
  $('copyCreated').addEventListener('click', function () { if (createdId) copy(instruction(createdId)).catch(fail); });
  $('viewCreated').addEventListener('click', function () { if (createdId) viewTask(createdId); });
  $('refresh').addEventListener('click', function () { loadState(false); });
  $('refreshDetail').addEventListener('click', function () { if (selectedId) viewTask(selectedId); });
  var flowView = null, flowTimer = null, flowId = '', flowGeneration = 0;
  function flowMode(active) {
    if (active) closeDrawer();
    $('flowPanel').hidden = !active;
    ['configForm','taskDetail'].forEach(function(id){ $(id).hidden = active; });
    document.querySelector('[aria-labelledby="compatTitle"]').hidden = active;
    document.querySelector('[aria-labelledby="jobsTitle"]').hidden = active;
    if(active) { $('pageTitle').textContent='编排执行现场'; $('pageDescription').textContent='每 1.5 秒读取真实运行报告。点击卡片查看输出、文件与失败原因。'; }
  }
  async function refreshFlow(ticket) {
    if (!flowId || ticket !== flowGeneration) return;
    clearTimeout(flowTimer);
    var keepPolling = true;
    try {
      var data = await api('task?id=' + encodeURIComponent(flowId));
      if(ticket !== flowGeneration) return;
      var runs=(data.runs || []).slice().sort(function(a,b){return String(b.startedAt).localeCompare(String(a.startedAt));});
      var run=runs[0] || null;
      flowView.render(data.job,run);
      $('flowTask').textContent=(data.job.task || '')+' · '+flowId;
      var state=projectFlowModel(data.job,run);
      keepPolling=!state.terminal;
      $('flowLive').dataset.error='false';
      $('flowLive').textContent=(state.terminal?'运行已结束 · ':'实时更新中 · ')+statusText(state.status)+' · '+new Date().toLocaleTimeString();
    } catch(error) {
      if(ticket !== flowGeneration) return;
      $('flowLive').dataset.error='true'; $('flowLive').textContent='连接暂不可用，保留上次结果并自动重试：'+error.message;
    } finally {
      if(ticket===flowGeneration && keepPolling && !$('flowPanel').hidden) flowTimer=setTimeout(function(){refreshFlow(ticket);},1500);
    }
  }
  function showFlow(id) {
    if(!/^[0-9a-f-]{36}$/i.test(id)) return;
    flowId=id;flowGeneration++;clearTimeout(flowTimer);flowMode(true);
    if(!flowView) flowView=mountFlow($('flowGraph'),projectFlowModel);
    refreshFlow(flowGeneration);
  }
  $('flowRefresh').onclick=function(){ if(flowId) refreshFlow(++flowGeneration); };
  $('flowConfig').onclick=function(){ flowGeneration++;clearTimeout(flowTimer);flowMode(false);$('pageTitle').textContent=detached?'AI 编排工作台':bound?'在本会话开始编排':'先设定边界，再开始编排'; $('pageDescription').textContent=detached?'点击流程卡片配置模型与断言；此窗口始终绑定打开时的原 DSH 会话。':'点击流程卡片配置模型、断言与任务边界。'; };
  window.addEventListener('pagehide',function(){flowGeneration++;clearTimeout(flowTimer);if(activeDelivery){clearTimeout(activeDelivery.timer);clearTimeout(activeDelivery.pollTimer);}flowView?.destroy();});
  renderConfigCanvas();
  if (boot.monitorTaskId) showFlow(boot.monitorTaskId);
  if (!token) { $('compatibility').textContent = '缺少访问令牌'; $('compatibility').className = 'banner error'; $('refresh').disabled = true; fail(new Error('请刷新 DSH 页面，再从编排器插件设置进入。不要分享带令牌的设置页地址。')); }
  else if (!bridgeReady) { $('compatibility').textContent = '当前会话连接不可用'; $('compatibility').className = 'banner error'; $('refresh').disabled = true; fail(new Error('请关闭此弹窗，从目标会话中的编排按钮重新打开。')); }
  else loadState(true);
})();
</script></body></html>`;
}
