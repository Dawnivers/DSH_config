import { captureModule } from './runtime.js';
captureModule(import.meta.url);
// 断言目录：让"选断言"和"选模型"用同一套结构。
//
// 模型侧是 provider → model → effort；断言侧是 包 → 组 → 断言。
// 选择值三种写法都接受：
//   'geo.vector'            整个包
//   'geo.vector/geojson'    某个组
//   'geom.ring.closed'      单条
//
// 断言实现住在 assertions/ 下，目录扫描即注册，没有登记表。
// 这里只做三件事：列出可选内容、校验用户选择、把选择渲染成可执行的验收命令。

import { existsSync } from 'node:fs';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

import { discoverChecks, checksDirOf } from '../assertions/lib/registry.mjs';
import { normalizePath } from '../assertions/lib/glob.mjs';

const execFileAsync = promisify(execFile);

// 断言命令是插件自己拼的只读检查，跑它不改项目状态。
// 但仍然给死上限，避免一个失控的断言把编排拖住。
const EXEC_TIMEOUT_MS = 180_000;
const MAX_OUTPUT_BYTES = 2 * 1024 * 1024;
const RAW_HEAD_LIMIT = 2000;

const HERE = dirname(fileURLToPath(import.meta.url));
export const ASSERTIONS_DIR = resolve(HERE, '..', 'assertions');
export const RUNNER_PATH = join(ASSERTIONS_DIR, 'run.mjs');

const SELECTION_MAX = 100;
const SELECTION_PATTERN = /^[A-Za-z0-9][A-Za-z0-9._-]{0,80}(\/[A-Za-z0-9][A-Za-z0-9._-]{0,80})?$/;

let cache = null;

/** 扫描断言实现，返回规范化目录（结果缓存，插件生命周期内不变） */
export async function assertionCatalog() {
  if (cache) return cache;
  if (!existsSync(RUNNER_PATH)) {
    cache = { available: false, reason: `断言库缺失：${RUNNER_PATH}`, packs: [], total: 0, bySelection: new Map() };
    return cache;
  }

  const checks = await discoverChecks(checksDirOf(ASSERTIONS_DIR));
  const packs = new Map();
  const bySelection = new Map();

  for (const { meta } of checks) {
    const pack = meta.pack;
    const group = meta.group;
    if (!packs.has(pack)) packs.set(pack, new Map());
    const groups = packs.get(pack);
    if (!groups.has(group)) groups.set(group, []);
    groups.get(group).push({
      id: meta.id,
      spec: meta.spec ?? '',
      severity: meta.severity ?? 'error',
      description: meta.description ?? '',
      perProject: meta.perProject === true,
    });

    bySelection.set(meta.id, { kind: 'check', pack, group, id: meta.id });
    bySelection.set(`${pack}/${group}`, { kind: 'group', pack, group });
    bySelection.set(pack, { kind: 'pack', pack });
  }

  cache = {
    available: true,
    reason: null,
    total: checks.length,
    packs: [...packs.entries()].map(([id, groups]) => ({
      id,
      groups: [...groups.entries()].map(([gid, checks]) => ({ id: gid, checks })),
      checkCount: [...groups.values()].reduce((n, list) => n + list.length, 0),
    })),
    bySelection,
  };
  return cache;
}

/**
 * 校验并归一化选择。
 * 找不到的项一律报错，不静默丢弃——"你以为启用了，实际没跑"是最坏的失败模式。
 */
export async function validateAssertionSelection(selection) {
  const catalog = await assertionCatalog();
  if (!catalog.available) throw new Error(catalog.reason);

  if (selection == null) return { selection: [], warnings: [] };
  if (!Array.isArray(selection)) throw new Error('断言选择必须是数组');
  if (selection.length > SELECTION_MAX) throw new Error(`断言选择最多 ${SELECTION_MAX} 项`);

  const out = [];
  const seen = new Set();
  for (const raw of selection) {
    if (typeof raw !== 'string' || !raw.trim()) throw new Error('断言选择里有空项或非字符串');
    const value = raw.trim();
    if (!SELECTION_PATTERN.test(value)) throw new Error(`断言选择格式不合法：${value}`);
    if (seen.has(value)) continue;
    seen.add(value);

    const hit = catalog.bySelection.get(value);
    if (!hit) {
      const near = [...catalog.bySelection.keys()].filter((k) => k.includes(value)).slice(0, 3);
      throw new Error(`未知断言：${value}${near.length ? `（你是不是想选：${near.join('、')}）` : ''}`);
    }
    out.push(value);
  }

  // 父项已经覆盖子项时，子项是冗余的（但保留用户原意，只提示）
  const warnings = [];
  for (const value of out) {
    const hit = catalog.bySelection.get(value);
    if (hit.kind === 'check' && out.includes(hit.pack)) warnings.push(`${value} 已被整包 ${hit.pack} 覆盖`);
    if (hit.kind === 'group' && out.includes(hit.pack)) warnings.push(`${value} 已被整包 ${hit.pack} 覆盖`);
  }

  return { selection: out, warnings };
}

/** 展开成 --only 需要的列表：被父项覆盖的子项去掉，避免命令行里堆冗余 */
export async function expandSelection(selection) {
  const catalog = await assertionCatalog();
  const picked = new Set(selection);
  const coveredPack = new Set();
  const coveredGroup = new Set();

  for (const value of picked) {
    const hit = catalog.bySelection.get(value);
    if (!hit) continue;
    if (hit.kind === 'pack') coveredPack.add(hit.pack);
    else if (hit.kind === 'group') coveredGroup.add(`${hit.pack}/${hit.group}`);
  }

  const out = [];
  for (const value of picked) {
    const hit = catalog.bySelection.get(value);
    if (!hit) { out.push(value); continue; }
    if (hit.kind !== 'pack' && coveredPack.has(hit.pack)) continue;
    if (hit.kind === 'check' && coveredGroup.has(`${hit.pack}/${hit.group}`)) continue;
    out.push(value);
  }
  return out.sort();
}

/**
 * 渲染成验收条件文本。这一段会原样进入 planner / worker / reviewer 的提示词，
 * 所以每一句都必须是可判定的，不能出现"确保正确"这类无法执行的表述。
 */
export function renderAssertionRule({ selection, projectRoot, profile = 'ci' }) {
  const only = selection.join(',');
  const command = `node "${RUNNER_PATH}" --root "${projectRoot}" --profile=${profile}${only ? ` --only "${only}"` : ''} --json`;

  return [
    `数据/地理断言（独立于静态审查，需实际执行）：${selection.join('、')}`,
    `执行命令：${command}`,
    '判定规则：退出码 0 且 status 为 pass 或 not_applicable 才算通过；退出码 1 表示有 error 级问题；退出码 2 表示仅有 warn 级问题。',
    'not_applicable 表示"范围内没有可检查的数据"，不是通过，也不得据此声称已验证。',
    '失败时按 results[].locator（path 加上 feature / ring / vertex / adcode 等）定位；若定位到的文件不在本任务归属范围内，只报告不修改，并说明需要谁处理。',
    'worker 不得为了让断言变绿而放宽阈值、扩大 ignore、添加豁免或删除样本。',
  ].join('\n');
}

/** 给 planner 的验证建议附加段（planner 只把可静态判定的写进 acceptance，其余留给主会话） */
export function renderAssertionHint({ selection, projectRoot }) {
  if (!selection.length) return '';
  const only = selection.join(',');
  return `已启用数据断言：${selection.join('、')}。计划里把它们写成"主会话待运行验证"，命令为 node "${RUNNER_PATH}" --root "${projectRoot}" --profile=ci${only ? ` --only "${only}"` : ''} --json；不要为它们派发源码任务，除非断言失败项定位到源码。`;
}

/**
 * Electron 宿主（DSH Desktop）里 process.execPath 指向应用可执行文件，不是 node。
 * 用它跑 .mjs 会启动一个应用实例：退出码 0、stdout 只有一个换行——
 * 看起来像"跑成功了但没输出"，比直接报错难查得多。
 */
export function nodeBin() {
  if (!process.versions.electron) return process.execPath;
  return process.env.DSH_NODE_EXECPATH || 'node';
}

/**
 * 执行已启用的断言，返回放行判定与报告记录。
 *
 * 这是插件里唯一执行外部进程的地方，因此边界写死：
 * 命令只能由本文件拼，参数只取自 job.assertions（创建时已对照目录校验），
 * 不接受任务配置里写任意 shell。
 */
export async function executeAssertions(job, { ownedFiles = new Set(), phase = 'post_worker' } = {}) {
  const selection = Array.isArray(job.assertions) ? job.assertions : [];
  const started = Date.now();
  const record = { phase, ran_at: new Date().toISOString(), profile: 'ci', selection: [...selection] };

  if (!selection.length) {
    return { pass: false, record: { ...record, status: 'not_run', reason: '未启用断言，没有可放行的实测依据' } };
  }

  let expanded;
  try {
    expanded = await expandSelection(selection);
  } catch (error) {
    return { pass: false, record: { ...record, status: 'error', reason: `断言选择无法展开：${error.message}`, duration_ms: Date.now() - started } };
  }

  const only = expanded.length ? ` --only "${expanded.join(',')}"` : '';
  record.command = `node "${RUNNER_PATH}" --root "${job.projectRoot}" --profile=ci${only} --json`;
  const args = [RUNNER_PATH, '--root', job.projectRoot, '--profile=ci', '--json'];
  if (expanded.length) args.push('--only', expanded.join(','));

  let stdout = '';
  let exitCode = 0;
  let spawnError = null;
  try {
    const settled = await execFileAsync(nodeBin(), args, {
      timeout: EXEC_TIMEOUT_MS, maxBuffer: MAX_OUTPUT_BYTES, windowsHide: true, encoding: 'utf8',
    });
    stdout = settled.stdout ?? '';
  } catch (error) {
    // 退出码 1 / 2 是断言的正常结论（发现问题 / 只有警告），不是执行失败。
    if (typeof error?.code === 'number') {
      exitCode = error.code;
      stdout = String(error.stdout ?? '');
    } else {
      spawnError = error;
    }
  }

  if (spawnError) {
    return {
      pass: false,
      record: {
        ...record, status: 'error', duration_ms: Date.now() - started,
        reason: spawnError.killed ? `断言执行超时（上限 ${EXEC_TIMEOUT_MS}ms）` : `断言执行失败：${spawnError.message}`,
      },
    };
  }

  if (!stdout.trim()) {
    // 空输出但退出码 0 几乎只有一个原因：命令被交给了应用可执行文件而不是 node。
    // 单独报出来，否则只会得到"不是合法 JSON"这种没法往下查的原因。
    return {
      pass: false,
      record: {
        ...record, status: 'error', exit_code: exitCode, duration_ms: Date.now() - started, bin: nodeBin(),
        reason: '断言命令没有输出任何内容；请确认它由 node 执行（Electron 宿主下 process.execPath 是应用本身，不是 node）',
        raw_head: stdout.slice(0, RAW_HEAD_LIMIT),
      },
    };
  }

  let parsed;
  try {
    parsed = JSON.parse(stdout);
  } catch {
    return {
      pass: false,
      record: {
        ...record, status: 'error', exit_code: exitCode, duration_ms: Date.now() - started,
        reason: '断言输出不是合法 JSON', raw_head: stdout.slice(0, RAW_HEAD_LIMIT),
      },
    };
  }

  const checks = Array.isArray(parsed.checks) ? parsed.checks : [];
  const ranChecks = checks.filter((entry) => entry.status === 'ran').length;
  const notApplicable = checks.filter((entry) => entry.status === 'not_applicable').length;
  const findings = (Array.isArray(parsed.results) ? parsed.results : []).map((issue) => {
    const path = normalizePath(String(issue.path ?? ''));
    return {
      id: issue.id,
      severity: issue.severity,
      path,
      locator: issue.locator ?? {},
      message: issue.message,
      // 归属决定后续能不能进修复轮：worker 改不了自己的范围外的文件。
      owner: ownedFiles.has(path) ? 'worker' : 'external',
    };
  });

  // 放行必须三条同时成立。not_applicable 的退出码也是 0，但它表示
  // 「范围内没有可检查的数据」，不是通过——拿它放行等于给"跳过全部复核"开后门。
  const pass = exitCode === 0 && parsed.status === 'pass' && ranChecks > 0;
  // 报出"执行了但没问题"的条数：否则合计对不上（12) = 7 执行 + 5 不适用，
  // 而 7 里只有失败的那条会被看见，剩下 6 条像是凭空消失。
  const issueIds = new Set(findings.map((finding) => finding.id));
  const failedChecks = checks.filter((entry) => entry.status === 'ran' && issueIds.has(entry.id)).length;

  return {
    pass,
    record: {
      ...record,
      exit_code: exitCode,
      status: parsed.status ?? 'unknown',
      duration_ms: Date.now() - started,
      counts: {
        ...(parsed.counts ?? {}),
        checks_run: ranChecks,
        checks_passed: ranChecks - failedChecks,
        not_applicable: notApplicable,
      },
      findings,
      expired_exemptions: parsed.expired_exemptions ?? [],
      ...(pass ? {} : {
        reason: ranChecks === 0
          ? '没有断言真正执行（not_applicable 不算通过）'
          : exitCode === 0 ? `status=${parsed.status} 不是 pass` : `退出码 ${exitCode}`,
      }),
    },
  };
}

export function resetAssertionCatalogCache() {
  cache = null;
}
