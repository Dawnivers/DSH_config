// This factory is bundled with page() by scripts/build-client.mjs; no extra browser dependencies.
export function clientFactory(require, renderPage) {
  const React = require('react');
  const h = React.createElement;
  const deliveries = new Map();
  const monitorOwners = new Map();
  const observedRuns = new Map();
  const detachedWindows = new Map();
  const detachedOwners = new Set();
  // A closed panel stays closed for the same run. A later, different run may open it again.
  function discoverRun(sessionId, tasks, seen = observedRuns) {
    const active = (tasks || []).filter(task => task && task.parentSession === sessionId && task.status === 'running' && task.runId && task.id && uuid.test(task.id));
    const known = seen.get(sessionId) || new Set();
    seen.set(sessionId, known);
    const next = active.find(task => !known.has(task.runId));
    active.forEach(task => known.add(task.runId));
    return next || null;
  }
  const uuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

  function settingsUrl() {
    const supplied = window.__DSH_ORCHESTRATOR_SETTINGS__?.url;
    if (!supplied) throw new Error('编排入口未注入，请刷新 DSH 页面。');
    const url = new URL(supplied, window.location.href);
    if (url.origin !== window.location.origin || !/^https?:$/.test(url.protocol) || url.username || url.password || !url.searchParams.get('token')) throw new Error('编排入口无效，请刷新 DSH 页面。');
    return url;
  }

  // Called only by the frame created for this session. Preserve its admission promise
  // so repeated messages, lost acknowledgements and reopening cannot enqueue twice.
  async function deliverBoundTask({ sessionId, taskId, send, isBusy = () => false, ledger = deliveries }) {
    if (typeof taskId !== 'string' || !uuid.test(taskId) || typeof sessionId !== 'string' || !sessionId) throw new Error('无效的会话任务投递');
    const key = sessionId + ':' + taskId;
    let delivery = ledger.get(key);
    if (!delivery) {
      delivery = (async () => {
        const queued = Boolean(isBusy());
        const prompt = '开始 AI 编排，执行已保存任务 ' + taskId + '。\n请立即调用 orchestrate_run：task_id="' + taskId + '"，plan_only=false，run_in_background=true。\n这是用户在本会话绑定的编排窗口点击「开始编排」提交的任务。使用已保存的模型与文件边界，不改写任务配置；完成后按实际结果继续项目验证。';
        try { await send(prompt, taskId); return { ok: true, queued }; }
        catch (error) { return { ok: false, error: String(error?.message || error), uncertain: error?.definitelyRejected !== true }; }
      })();
      ledger.set(key, delivery);
    }
    const result = await delivery;
    if (!result.ok && !result.uncertain && ledger.get(key) === delivery) ledger.delete(key);
    return result;
  }
  function createSessionBridge({ sessionId, bridgeId, origin, source, send, isBusy = () => false, ledger = deliveries }) {
    return async function receive(event) {
      const data = event.data;
      if (event.origin !== origin || event.source !== source || !data || data.type !== 'dsh-orchestrator:start' || data.sessionId !== sessionId || data.bridgeId !== bridgeId || typeof data.taskId !== 'string' || !uuid.test(data.taskId)) return;
      const result = await deliverBoundTask({ sessionId, taskId: data.taskId, send, isBusy, ledger });
      source.postMessage({ type: 'dsh-orchestrator:result', sessionId, bridgeId, taskId: data.taskId, ...result }, origin);
      return result;
    };
  }
  function createDetachedOwner({ sessionId, bridgeId, ownerToken, request, send, isBusy, ledger = deliveries, setTimer = setTimeout, clearTimer = clearTimeout, onStop = () => {} }) {
    let stopped = false, started = false, timer, polling = null;
    function stop() { if (stopped) return; stopped = true; clearTimer(timer); onStop(); }
    const receipts = new Map();
    async function pollOnce() {
      if (stopped) return;
      if (polling) return polling;
      polling = (async () => {
        const data = await request('bridge/poll', { bridgeId, ownerToken });
        if (stopped) return;
        if (data.sessionId !== sessionId || !Array.isArray(data.requests)) { stop(); throw new Error('浏览器回传目标与原会话不一致'); }
        for (const item of data.requests) {
          if (stopped) return;
          if (!uuid.test(item.taskId) || !Number.isSafeInteger(item.attempt) || item.attempt < 1) throw new Error('无效的浏览器任务回传');
          const key = item.taskId + ':' + item.attempt;
          if (!receipts.has(key)) receipts.set(key, await deliverBoundTask({ sessionId, taskId: item.taskId, send, isBusy, ledger }));
          if (stopped) return;
          await request('bridge/result', { bridgeId, ownerToken, taskId: item.taskId, attempt: item.attempt, result: receipts.get(key) });
        }
      })();
      try { return await polling; } finally { polling = null; }
    }
    async function tick() {
      try { await pollOnce(); } catch (error) { if ([400, 401, 403].includes(error?.status)) stop(); /* Preserve receipt dedupe across transport errors. */ }
      finally { if (!stopped) timer = setTimer(tick, 1500); }
    }
    return { pollOnce, start() { if (!stopped && !started) { started = true; tick(); } }, stop };
  }
  async function browserRequest(route, body) {
    const entry = settingsUrl();
    const controller = new AbortController(), timeout = setTimeout(() => controller.abort(), 15000);
    try {
      const response = await fetch(new URL('/dsh-orchestrator/settings/api/' + route, entry.origin), {
        method: 'POST', headers: { 'x-settings-token': entry.searchParams.get('token'), 'content-type': 'application/json' },
        body: JSON.stringify(body), cache: 'no-store', signal: controller.signal,
      });
      const data = await response.json();
      if (!response.ok) throw Object.assign(new Error(data.error || '浏览器连接请求失败'), { status: response.status });
      return data;
    } finally { clearTimeout(timeout); }
  }

  function Frame({ boot, title, frameRef }) {
    return h('iframe', {
      ref: frameRef, title, srcDoc: renderPage(boot), referrerPolicy: 'no-referrer',
      allow: "clipboard-write 'self'", style: { width: '100%', height: '100%', minHeight: 550, border: 0, background: '#10141d', display: 'block' },
    });
  }

  function SettingsPage() {
    try {
      const url = settingsUrl();
      return h('div', { style: { height: '82vh', minHeight: 720 } }, h(Frame, { title: 'AI 编排设置', boot: { token: url.searchParams.get('token'), parentOrigin: window.location.origin } }));
    } catch (error) { return h('p', { role: 'alert' }, error.message); }
  }

  function SessionAction({ sessionId, useSession, sendMessage, getSessionInfo }) {
    const running = useSession(state => state.running);
    const [issue, setIssue] = React.useState('');
    const [externalUrl, setExternalUrl] = React.useState('');
    const [opening, setOpening] = React.useState(false);
    const [latestTask, setLatestTask] = React.useState('');
    const runningRef = React.useRef(running); runningRef.current = running;
    React.useEffect(() => { setExternalUrl(''); setIssue(''); setLatestTask(''); }, [sessionId]);
    React.useEffect(() => {
      let cancelled = false, timer, request;
      const owner = {};
      async function poll() {
        try {
          if (document.hidden) return;
          if (monitorOwners.has(sessionId) && monitorOwners.get(sessionId) !== owner) return;
          monitorOwners.set(sessionId, owner);
          const url = settingsUrl(); request = new AbortController();
          const timeout = setTimeout(() => request.abort(), 7000);
          let data;
          try {
            const response = await fetch(new URL('/dsh-orchestrator/settings/api/activity?session=' + encodeURIComponent(sessionId), url.origin), { headers: { 'x-settings-token': url.searchParams.get('token') }, signal: request.signal, cache: 'no-store' });
            if (!response.ok) return; data = await response.json();
          } finally { clearTimeout(timeout); }
          if (cancelled) return;
          const task = discoverRun(sessionId, data.tasks);
          if (task) setLatestTask(task.id); // Never open a browser automatically on a background run.
        } catch (_) { /* Conversation UI must survive an unavailable observer. */ }
        finally { if (!cancelled) timer = setTimeout(poll, 2000); }
      }
      poll();
      return () => { cancelled = true; clearTimeout(timer); request?.abort(); if (monitorOwners.get(sessionId) === owner) monitorOwners.delete(sessionId); };
    }, [sessionId]);
    async function open(monitorTaskId) {
      if (opening) return;
      setOpening(true); setIssue('');
      try {
        const key = sessionId + ':' + (typeof monitorTaskId === 'string' ? monitorTaskId : 'config');
        let entry = detachedWindows.get(key);
        if (!entry || Date.parse(entry.expiresAt) <= Date.now()) {
          const row = getSessionInfo?.();
          entry = await browserRequest('bridge/open', { sessionId, sessionTitle: row?.displayTitle || row?.title || sessionId, workspaceRoot: row?.cwd || '', ...(typeof monitorTaskId === 'string' && uuid.test(monitorTaskId) ? { monitorTaskId } : {}) });
          const url = new URL(entry.url), base = settingsUrl();
          if (url.origin !== base.origin || url.pathname !== '/dsh-orchestrator/settings' || url.searchParams.get('bridge') !== entry.bridgeId || !uuid.test(entry.bridgeId) || typeof entry.ownerToken !== 'string') throw new Error('服务端返回了无效的浏览器入口');
          const owner = createDetachedOwner({ sessionId, bridgeId: entry.bridgeId, ownerToken: entry.ownerToken, request: browserRequest, send: sendMessage, isBusy: () => Boolean(runningRef.current), onStop: () => { detachedOwners.delete(owner); if (detachedWindows.get(key) === entry) detachedWindows.delete(key); } });
          entry.sessionId = sessionId; entry.owner = owner; detachedOwners.add(owner); detachedWindows.set(key, entry); owner.start();
        }
        setExternalUrl(entry.url);
        // Desktop sends this HTTP URL to the default browser. A plain Web client
        // may block an async popup, so always retain a user-clickable fallback.
        window.open(entry.url, '_blank', 'noopener,noreferrer');
      } catch (error) { setIssue(String(error?.message || error)); }
      finally { setOpening(false); }
    }
    async function disconnect() {
      const entries = [...detachedWindows].filter(([, entry]) => entry.sessionId === sessionId);
      for (const [key, entry] of entries) { entry.owner?.stop(); detachedWindows.delete(key); }
      setExternalUrl(''); setIssue('已断开本会话的浏览器连接；已启动的后台任务不会停止。');
      await Promise.all(entries.map(async ([, entry]) => {
        try { await browserRequest('bridge/close', {bridgeId:entry.bridgeId, ownerToken:entry.ownerToken}); } catch (_) { /* Local ownership already stopped. */ }
      }));
    }
    const style = { display: 'inline-flex', alignItems: 'center', gap: 5, padding: '4px 9px', borderRadius: 7, border: '1px solid var(--border, #60606066)', background: 'transparent', color: 'inherit', cursor: 'pointer', fontSize: 12, whiteSpace: 'nowrap' };
    return h(React.Fragment, null,
      h('button', { type: 'button', onClick: () => open(), disabled: opening, title: '在外部浏览器配置 A 方案流程画布，绑定当前会话', 'aria-label': '在浏览器打开 AI 编排', style }, opening ? '正在连接…' : '✦ AI 编排 ↗'),
      latestTask ? h('button', { type: 'button', onClick: () => open(latestTask), title: '在浏览器查看本会话运行流程', style }, '查看流程 ↗') : null,
      externalUrl ? h('a', { href: externalUrl, target: '_blank', rel: 'noopener noreferrer', style: { color: 'inherit', fontSize: 12 }, title: '若浏览器未自动打开，点击这里；请勿分享此带凭据链接' }, '浏览器入口 ↗') : null,
      externalUrl ? h('button', { type: 'button', onClick: disconnect, title: '断开本会话所有浏览器连接，不停止已启动的任务', 'aria-label': '断开浏览器连接', style }, '×') : null,
      issue ? h('span', { role: 'alert', style: { fontSize: 12 } }, issue) : null);
  }

  return {
    inject: ['slots', 'sessions', 'conversation'],
    createSessionBridge, createDetachedOwner, deliverBoundTask, discoverRun, SessionAction, SettingsPage,
    apply(ctx) {
      ctx.slots.inject('plugins.bundle.config', () => ctx.slots.register({ name: 'plugins.bundle.config', key: 'dsh-orchestrator' }, SettingsPage));
      for (const name of ['conversation.session.header.actions', 'conversation.input.left']) ctx.slots.inject(name, () => ctx.slots.register({
        name, id: 'dsh-orchestrator', order: -30,
        inject: sessionId => ({
          getSessionInfo: () => ctx.sessions.list.getSnapshot().byId[sessionId],
          sendMessage: async (text, requestId) => {
            const binding = ctx.sessions.binding(sessionId);
            if (!binding) throw Object.assign(new Error('conversation.send failed: 会话已关闭，请重新打开编排窗口'), { definitelyRejected: true });
            const result = await binding.session.prompt([{ type: 'text', text }], 'queue', undefined, requestId);
            if (!result?.ok) {
              const code = result?.error?.code || 'unknown';
              // Carrier faults are returned as gateway/internal, not necessarily
              // thrown. Only proven pre-admission failures permit a retry.
              const definitelyRejected = ['session/not-found', 'gateway/bad-request', 'session/invalid-time-zone'].includes(code);
              throw Object.assign(new Error((definitelyRejected ? 'conversation.send failed: ' : 'conversation.send outcome uncertain: ') + code + ': ' + (result?.error?.message || '未获得有效投递结果')), { definitelyRejected });
            }
          },
        }),
      }, SessionAction));
      return () => { for (const owner of detachedOwners) owner.stop(); detachedOwners.clear(); detachedWindows.clear(); deliveries.clear(); monitorOwners.clear(); observedRuns.clear(); };
    },
  };
}
