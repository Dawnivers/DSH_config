import { captureModule } from './runtime.js';
captureModule(import.meta.url);
import { opendirSync } from 'node:fs';
import path from 'node:path';

// Read-only, bounded presence check. It does not infer or copy a blueprint.
const IGNORED = new Set(['.git', 'node_modules', '.dsh-orchestrator']);
export function inspectProject(projectRoot, { maxEntries = 2000, maxDepth = 12, signal, openDirectory = opendirSync } = {}) {
  const pending = [{ directory: projectRoot, depth: 0 }];
  let scannedEntries = 0;
  let incomplete = false;
  while (pending.length) {
    signal?.throwIfAborted();
    const { directory, depth } = pending.pop();
    const handle = openDirectory(directory);
    try {
    let entry;
    while ((entry = handle.readSync()) !== null) {
      signal?.throwIfAborted();
      if (++scannedEntries > maxEntries) return { status: 'blocked', code: 'project_scan_limit', scannedEntries, reason: '项目存在性检查达到扫描上限，尚未确认可读项目文件；请核对项目目录及准备材料。' };
      if (entry.isSymbolicLink() || IGNORED.has(entry.name.toLowerCase())) continue;
      if (entry.isFile()) return { status: 'ready', scannedEntries, sampleFile: path.relative(projectRoot, path.join(directory, entry.name)).replaceAll('\\', '/') };
      if (entry.isDirectory()) {
        if (depth >= maxDepth) incomplete = true;
        else pending.push({ directory: path.join(directory, entry.name), depth: depth + 1 });
      }
    }
    } finally { handle.closeSync(); }
  }
  if (incomplete) return { status: 'blocked', code: 'project_scan_limit', scannedEntries, reason: '项目存在性检查达到目录深度上限，不能断言目录为空；请核对项目目录及准备材料。' };
  return { status: 'blocked', code: 'project_not_prepared', scannedEntries, reason: '项目根中未发现可供规划的普通项目文件（已忽略依赖、Git 和链接）。请由主会话先确认并准备用户指定蓝本，核对基线，再创建同配置的新任务；插件不会自动复制、安装或新建项目。' };
}
