import { captureModule } from './runtime.js';
captureModule(import.meta.url);
// reviewer 输出契约：把「静态复核通过」与「真的验证过」分开，
// 并让 checksNeeded 变成主会话可直接执行的条目，而不是一段自然语言。

/** 复核结论三档。ready_for_validation 是旧值，读取时归一成 verified_statically，历史报告不改写。 */
// reviewer 自己能下的结论。
// 「断言放行」「数据阻塞」是插件根据实测结果下的结论，不能让模型自称——
// 否则模型可以绕过实测直接说"断言过了"。
export const REVIEWER_ASSESSMENTS = ['verified_statically', 'issues_found', 'unable_to_verify'];
export const ASSESSMENTS = [...REVIEWER_ASSESSMENTS, 'passed_by_assertions', 'blocked_by_data'];
const LEGACY_ASSESSMENTS = { ready_for_validation: 'verified_statically' };

/** 待验证条目的类别。决定它需要什么手段，主会话据此判断能否自动化。 */
export const CHECK_KINDS = ['build', 'runtime', 'visual', 'static', 'data', 'process'];

/** 需要可执行入口的类别：这几类离开命令就只剩一句愿望，主会话仍得自己猜怎么跑。 */
export const COMMAND_KINDS = ['build', 'runtime', 'data'];

/* 条目归属。run = 本次编排/工作区里能跑掉的验证（默认）；main = 只有主会话能做
   （计费账本核对、人工目视、真实浏览器、需要用户决策）。main 条目允许没有
   command：这不是缺陷，而是承认它天然不可自动化。 */
export const CHECK_OWNERS = ['run', 'main'];

/** 归一后的条目状态。unverifiable 的条目仍保留给主会话看，只是不计入可直接执行的验证。 */
export const CHECK_STATUSES = ['ok', 'unverifiable'];

const text = { type: 'string' };

const CHECK_SCHEMA = {
  type: 'object', additionalProperties: false,
  required: ['id', 'kind', 'statement', 'command', 'expected'],
  properties: {
    id: { type: 'string' }, kind: { type: 'string', enum: CHECK_KINDS },
    statement: text, command: text, expected: text,
    /* owner 可选：不填按 run 处理，历史记录与旧模型输出都能通过。 */
    owner: { type: 'string', enum: CHECK_OWNERS },
  },
};

export const REVIEW_SCHEMA = {
  type: 'object', additionalProperties: false,
  required: ['assessment', 'summary', 'checks'],
  properties: {
    assessment: { type: 'string', enum: REVIEWER_ASSESSMENTS },
    summary: text,
    checks: { type: 'array', items: CHECK_SCHEMA },
  },
};

const MAX_CHECKS = 40;
const MAX_TEXT = 4000;

/* 单条 check 的归一：结构问题一律「降级保留」，不抛错。
   起因是 arm-a13：修复轮 reviewer 把「记录各模型调用与费用」写成 kind=data 且
   command=""（内容完全正确，只是按插件分工归主会话），整轮 19 分钟的成果被一条
   格式问题判死。校验的职责是把条目变成主会话能读的东西，而不是替模型否决整次复核。
   信封级错误（结论无效、缺 summary、checks 不是数组）仍然抛错——那说明这次复核
   根本没产出可用结构，交给 review_failed 通道更诚实。 */
export function validateReview(result) {
  if (!result || typeof result !== 'object' || Array.isArray(result)) throw new Error('复核结果必须是对象');
  const raw = result.assessment;
  const legacy = Object.hasOwn(LEGACY_ASSESSMENTS, raw);
  const assessment = legacy ? LEGACY_ASSESSMENTS[raw] : raw;
  if (!REVIEWER_ASSESSMENTS.includes(assessment)) throw new Error(`复核结论无效：${String(raw)}`);
  if (typeof result.summary !== 'string' || !result.summary.trim()) throw new Error('复核结果缺少 summary');
  if (result.summary.length > MAX_TEXT) throw new Error('复核 summary 过长');

  // 旧值直接来自历史报告时没有 checks 字段，允许为空数组，但不能伪装成结构化。
  const checks = result.checks ?? [];
  if (!Array.isArray(checks)) throw new Error('复核 checks 必须是数组');
  if (checks.length > MAX_CHECKS) throw new Error(`复核 checks 超过 ${MAX_CHECKS} 项`);

  const ids = new Set();
  const degraded = [];
  /* 降级只记一次原因，避免同一条目在界面上刷出五行。 */
  const degrade = (entry) => {
    degraded.push(entry);
    return entry;
  };

  const normalized = checks.map((check, index) => {
    const problems = [];
    if (!check || typeof check !== 'object' || Array.isArray(check)) {
      const id = `check-${index + 1}`;
      ids.add(id);
      degrade({ id, issue: '条目不是对象，已按 unverifiable 占位保留' });
      return {
        id, kind: 'process', statement: '（模型给出的这一项不是对象，无法解析）', command: '',
        expected: '主会话人工判断这一条是否适用', owner: 'main', status: 'unverifiable',
        issue: '条目不是对象，已按 unverifiable 占位保留',
      };
    }

    // 未知字段：丢弃而不是拒绝，原因写进 issue。
    for (const key of Object.keys(check)) {
      if (!Object.hasOwn(CHECK_SCHEMA.properties, key)) problems.push(`未知字段 ${key} 已忽略`);
    }

    let id = typeof check.id === 'string' ? check.id.trim() : '';
    if (!id) {
      id = `check-${index + 1}`;
      problems.push('缺少 id，已自动编号');
    }
    if (ids.has(id)) {
      const unique = `${id}-${index + 1}`;
      problems.push(`id 重复（${id}），已改为 ${unique}`);
      id = unique;
    }
    ids.add(id);

    const kind = typeof check.kind === 'string' ? check.kind.trim() : '';
    if (!CHECK_KINDS.includes(kind)) problems.push(`kind 无效：${String(check.kind)}`);

    const statement = typeof check.statement === 'string' && check.statement.trim()
      ? check.statement.trim() : (problems.push('statement 为空'), '（模型未给出要确认什么）');
    const expected = typeof check.expected === 'string' && check.expected.trim()
      ? check.expected.trim() : (problems.push('expected 为空'), '（模型未给出通过标准）');

    let command = '';
    if (check.command !== undefined && check.command !== null) {
      if (typeof check.command === 'string') command = check.command.trim();
      else problems.push('command 不是字符串，已忽略');
    }

    // 归属：只有显式 main 才放宽命令要求，其他一律按 run 处理。
    let owner = 'run';
    if (check.owner !== undefined && check.owner !== null && check.owner !== '') {
      if (CHECK_OWNERS.includes(check.owner)) owner = check.owner;
      else problems.push(`owner 无效：${String(check.owner)}（按 run 处理）`);
    }
    if (COMMAND_KINDS.includes(kind) && !command && owner !== 'main') {
      problems.push(`${kind} 类没有可执行 command；只能由主会话完成时请标 owner="main"`);
    }
    for (const [key, value] of [['statement', statement], ['expected', expected]]) {
      if (typeof value === 'string' && value.length > MAX_TEXT) problems.push(`${key} 过长已截断`);
    }

    const entry = {
      id, kind: kind || 'process', statement: statement.slice(0, MAX_TEXT),
      command, expected: expected.slice(0, MAX_TEXT), owner,
      status: problems.length ? 'unverifiable' : 'ok',
    };
    if (problems.length) {
      entry.issue = problems.join('；');
      degrade({ id, issue: entry.issue });
    }
    return entry;
  });

  // 声明 issues_found 却一条问题都不给，等于把判断成本全推回主会话。
  if (assessment === 'issues_found' && !normalized.length) throw new Error('issues_found 至少要给出一个具体问题条目');
  // 声明 verified_statically 却没有任何待验证项，容易让人误以为万事俱备。
  if (assessment === 'verified_statically' && !normalized.length) throw new Error('verified_statically 仍需列出主会话待验证项；确实无事可列时用 unable_to_verify');

  return { assessment, legacyAssessment: legacy ? raw : null, summary: result.summary.trim(), checks: normalized, degraded };
}

/** 结论到任务状态的映射。只有明确报出问题时才算复核失败。 */
export function reviewStatus(review) {
  if (review.assessment === 'issues_found') return 'review_failed';
  if (review.assessment === 'blocked_by_data') return 'blocked';
  return 'needs_validation';
}

/** 主会话侧的人读清单，保持旧字段形状，避免已有消费方中断。 */
export function checkLines(checks) {
  return checks.map(check => {
    const owner = check.owner === 'main' ? '｜归属：主会话（不可自动执行）' : '';
    const bad = check.status === 'unverifiable' ? `｜已降级：${check.issue || '不可自动执行'}` : '';
    return `${check.id} [${check.kind}] ${check.statement}｜预期：${check.expected}${check.command ? `｜命令：${check.command}` : ''}${owner}${bad}`;
  });
}
