import { captureModule } from './runtime.js';
captureModule(import.meta.url);
const stringList = { type: 'array', items: { type: 'string' } };
const status = { type: 'string', enum: ['ready', 'needs_clarification', 'blocked'] };

// The planner returns this check with each task in the same read-only session.
export const TASK_FEASIBILITY_SCHEMA = {
  type: 'object', additionalProperties: false, required: ['status', 'summary', 'evidence', 'questions'], properties: {
    status, summary: { type: 'string' }, evidence: stringList, questions: stringList,
  },
};

function overallStatus(tasks) {
  return tasks.some(task => task.status === 'blocked') ? 'blocked'
    : tasks.some(task => task.status === 'needs_clarification') ? 'needs_clarification' : 'ready';
}

/** Validate planner evidence without claiming a separate worker-model review. */
export function plannerFeasibility(plan) {
  const tasks = plan.tasks.map(task => {
    const check = task.feasibility;
    if (!check || typeof check !== 'object' || Array.isArray(check) || Object.keys(check).some(key => !Object.hasOwn(TASK_FEASIBILITY_SCHEMA.properties, key))) {
      throw new Error(`planner 任务缺少有效 feasibility 自检：${task.id}`);
    }
    return { ...check, taskId: task.id };
  });
  return validateFeasibility({ status: overallStatus(tasks), summary: 'planner 随计划提供的源码可行性自检；不是独立 worker 模型复核。', tasks }, plan);
}

/** Only validated plan shape controls whether an independent review is required. */
export function feasibilityPolicy(plan) {
  const taskCount = plan.tasks.length;
  const crossTaskDependencies = plan.tasks.reduce((count, task) => count + task.consumes.length, 0);
  const required = taskCount > 1 || crossTaskDependencies > 0;
  return { required, taskCount, crossTaskDependencies, reason: required
    ? `计划含 ${taskCount} 个任务、${crossTaskDependencies} 项跨任务依赖，需独立 worker 模型复核。`
    : '单任务且无跨任务依赖，采用 planner 源码自检，跳过独立 worker 模型复核。' };
}

export const FEASIBILITY_SCHEMA = {
  type: 'object', additionalProperties: false, required: ['status', 'summary', 'tasks'], properties: {
    status, summary: { type: 'string' },
    tasks: { type: 'array', items: {
      type: 'object', additionalProperties: false, required: ['taskId', 'status', 'summary', 'evidence', 'questions'], properties: {
        taskId: { type: 'string' }, status, summary: { type: 'string' }, evidence: stringList, questions: stringList,
      },
    } },
  },
};

/** One read-only confirmation covers every task; no result may silently change the plan. */
export function validateFeasibility(result, plan) {
  const validStatus = value => ['ready', 'needs_clarification', 'blocked'].includes(value);
  const validText = value => typeof value === 'string' && !!value.trim() && value.length <= 4000;
  if (!result || !validStatus(result.status) || !validText(result.summary)) throw new Error('可行性确认缺少有效状态或 summary');
  if (!Array.isArray(result.tasks) || result.tasks.length !== plan.tasks.length) throw new Error('可行性确认必须覆盖全部计划任务');
  const expected = new Set(plan.tasks.map(task => task.id));
  for (const task of result.tasks) {
    if (!task || !expected.delete(task.taskId)) throw new Error('可行性确认任务 ID 缺失、重复或不属于计划');
    if (!validStatus(task.status) || !validText(task.summary)) throw new Error(`可行性确认任务状态无效：${task.taskId}`);
    for (const key of ['evidence', 'questions']) {
      if (!Array.isArray(task[key]) || task[key].length > 20 || task[key].some(value => !validText(value))) throw new Error(`可行性确认 ${key} 必须是有效说明数组：${task.taskId}`);
    }
    if (!task.evidence.length) throw new Error(`可行性确认必须给出已读实现的证据：${task.taskId}`);
    if (task.status === 'ready' && task.questions.length) throw new Error(`可行任务不能夹带未解决问题：${task.taskId}`);
    if (task.status === 'needs_clarification' && !task.questions.length) throw new Error(`待澄清任务必须提供具体问题：${task.taskId}`);
  }
  const overall = overallStatus(result.tasks);
  if (result.status !== overall) throw new Error('可行性确认总体状态与任务状态不一致');
  return structuredClone(result);
}
