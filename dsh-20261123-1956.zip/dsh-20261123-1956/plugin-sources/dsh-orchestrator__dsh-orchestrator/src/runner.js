import { captureModule, runtimeIdentity, assertRuntimeCurrent } from './runtime.js';
captureModule(import.meta.url, { reviewRetry: true, reviewErrorStatus: true, runtimeVerification: true, reviewLevels: true });
import path from 'node:path';
import { readFileSync } from 'node:fs';
import { randomUUID } from 'node:crypto';
import { childDiagnostic, errorExcerpt as excerpt, proseExcerpt } from './diagnostics.js';
import { plannerPrompt, feasibilityPrompt, workerPrompt, receiptPrompt, reviewerPrompt, repairPrompt, recoveryPrompt, mismatchPolicy } from './prompts.js';
import { FEASIBILITY_SCHEMA, validateFeasibility, plannerFeasibility, feasibilityPolicy } from './feasibility.js';
import { inspectProject } from './preflight.js';
import { validateModelRoute, validateModelRoutes } from './models.js';
export { models, defaultConfig } from './models.js';
import { validateJob, validatePlan, planWaves, safeTarget, pathKey, within, rebaseToRealRoot, PLAN_SCHEMA, WORKER_SCHEMA } from './policy.js';
import { REVIEW_SCHEMA, validateReview, reviewStatus, checkLines } from './review.js';
import { executeAssertions } from './assertions.js';
import { reviewPolicy } from './review-policy.js';

const locks = new Set();
// 这些失败来自权限、预算与路径约束，属于「安全闸门」而不是模型输出故障：
// 必须照旧失败关闭，绝不降级继续写入。
const SAFETY_REFUSAL = /权限拒绝|工具调用超过上限|越出项目根|不允许符号链接|禁止调用|不属于此 worker|编排任务权限/;
export const isSafetyRefusal = error => SAFETY_REFUSAL.test(String(error?.message || error));
// 合并多个阶段的快照清单：同一文件保留首阶段的条目（它的 before 才是本次运行前的原始字节），
// 只出现在后续阶段（例如修复轮新建）的文件按自己的条目保留，否则报告会漏。
function mergeManifests(...manifests) {
  const seen = new Set();
  const out = [];
  for (const manifest of manifests) for (const item of manifest ?? []) {
    if (seen.has(item.file)) continue;
    seen.add(item.file);
    out.push(item);
  }
  return out;
}
// 只读角色（planner / feasibility / reviewer）的工具调用预算。实测用量：planner ≤21、
// feasibility 21–26、reviewer ≤16；40 留足正常余量，只阻断原地打转的失控循环。
const READ_TOOL_BUDGET = 40;
const implementationVersion = JSON.parse(readFileSync(new URL('../package.json', import.meta.url), 'utf8')).version;
export function compatibility(ctx) {
  const issues = [];
  for (const [label, fn] of [['tools.guard', ctx.tools?.guard], ['subagents.start', ctx.subagents?.start], ['llm.resolveCallConfig', ctx.llm?.resolveCallConfig], ['llm.resolveModelInfo', ctx.llm?.resolveModelInfo]]) {
    if (typeof fn !== 'function') issues.push(`缺少 ${label}，需要支持该接口的 DSH`);
  }
  const provider = ctx.subagents?.getProvider?.('spawn');
  for (const name of ['agentOptions', 'toolFilter', 'outputSchema', 'depthLimit', 'persona']) if (!provider?.capabilities?.[name]) issues.push(`spawn provider 不支持 ${name}`);
  return { ready: !issues.length, issues, implementationVersion, runtime: runtimeIdentity() };
}
export function createRunner(ctx, store, bindings) {
  const active = new Map();
  let closing = false;
  function run(jobId, parent, signal, progress = () => {}, options = {}) {
    if (closing) throw new Error('编排插件正在停止，不能启动新任务');
    const runtime = assertRuntimeCurrent();
    const job = validateJob(store.get(jobId));
    const acceptance = reviewPolicy(job);
    const rootKey = pathKey(job.projectRoot);
    if (store.status(jobId).status !== 'queued') throw new Error('该任务已经启动过；请在设置页生成新的独立任务');
    for (const locked of locks) if (within(locked, rootKey) || within(rootKey, locked)) throw new Error('此项目或其父子目录已有编排任务正在运行');
    const check = compatibility(ctx);
    if (!check.ready) throw new Error(check.issues.join('；'));
    const runId = randomUUID();
    const controller = new AbortController();
    const onAbort = () => controller.abort(signal.reason);
    if (signal?.aborted) controller.abort(signal.reason);
    else signal?.addEventListener('abort', onAbort, { once: true });
    locks.add(rootKey);
    const activity = { controller, result: null };
    active.set(runId, activity);
    const report = { implementationVersion, runtime, runId, jobId, parentSession: parent.session.id, projectRoot: job.projectRoot, task: job.task, startedAt: new Date().toISOString(), status: 'running', children: [], events: [], planOnly: options.planOnly === true, reviewLevel: acceptance.level, reviewPolicy: acceptance };
    let activePhase = 'initial';
    const emit = (stage, message) => {
      report.stage = stage;
      report.events.push({ at: new Date().toISOString(), stage, message });
      progress(stage, message);
      store.report(jobId, runId, report);
    };
    const setStatus = status => { report.status = status; store.setStatus(jobId, { status, runId, parentSession: parent.session.id }); };
    // 结构化结果缺失时的只读补交（planner 含修复轮 / feasibility / reviewer 共用）：
    // 与 worker 的 receipt 同一思路——同路由、只读、把正文压成 schema 形状，不重做任务。
    // 上限 3 次，只用于把「用正文收尾」从硬失败变成一次有界补救。
    const RECOVERABLE = new Set(['planner', 'feasibility', 'reviewer']);
    const RECOVERY_LIMIT = 3;
    async function recoverStructured({ role, route, prompt, schema, prose }) {
      if (!prose || !prose.trim()) return null;
      if ((report.structuredRecoveries || []).length >= RECOVERY_LIMIT) {
        emit('structured-recovery-skipped', `结构化补交已达上限 ${RECOVERY_LIMIT} 次，${role} 直接失败`);
        return null;
      }
      emit('structured-recovery', `${role} 未调用 structured_output，用同路由只读补交一次`);
      const before = report.children.length;
      try {
        const structured = await child('receipt', route, recoveryPrompt(job, { role, prompt, prose, schema }), schema, undefined, { recovery: true });
        (report.structuredRecoveries ||= []).push({ role, status: 'completed', childId: report.children[before]?.childId ?? null });
        return structured;
      } catch (error) {
        (report.structuredRecoveries ||= []).push({ role, status: 'failed', error: excerpt(error), childId: report.children[before]?.childId ?? null });
        controller.signal.throwIfAborted();
        if (isSafetyRefusal(error)) throw error;
        return null;
      }
    }
    async function child(role, route, prompt, schema, task, meta = {}) {
      controller.signal.throwIfAborted();
      // 每次创建前按精确路由校验，不把不支持的档位静默变成默认值。
      const agentOptions = await validateModelRoute(ctx, role, route, controller.signal);
      const entry = { role, taskId: task?.id || null, phase: activePhase, assignedFiles: [...(task?.files || [])], requested: agentOptions, status: 'starting' };
      report.children.push(entry);
      const allow = new Set((task?.files || []).map(file => pathKey(safeTarget(job.projectRoot, file))));
      let run;
      try {
        run = await bindings.start({
          parent, signal: controller.signal, label: `orchestrator:${runId}:${role}:${task?.id || ''}`,
          agentOptions, outputSchema: schema,
          toolFilter: { allow: role === 'worker' ? ['read', 'glob', 'grep', 'write', 'edit'] : ['read', 'glob', 'grep'] },
          persona: `你是编排插件中的 ${role}。项目根为 ${job.projectRoot}。所有文件工具必须显式传绝对路径，glob/grep 的 path 也必须显式指定。不要操作其他目录；不得使用 shell、网络、浏览器或创建其他代理。只通过 structured_output 交付结果。遇到实质接口或版本不符须以证据报告，不得推倒重写。${mismatchPolicy}`,
          prompt: [{ type: 'text', text: prompt }],
        }, { root: job.projectRoot, allow, role, ...(role === 'worker' ? {} : { budget: READ_TOOL_BUDGET }) }, agent => {
          entry.childId = agent.session.id;
          entry.boundBeforeRequest = true;
          entry.status = 'running';
          entry.startedAt = new Date().toISOString();
          emit(role, `已绑定 ${role} ${task?.id || ''}：${agent.session.id}`);
        });
        const result = await run.result;
        entry.stopReason = result.stopReason;
        const prose = proseExcerpt(result.output);
        // 只在「结果没拿到」或「非正常结束」时留正文，避免成功路径把报告体积翻倍。
        if (prose && (result.stopReason !== 'completed' || !result.structured)) entry.rawOutput = prose;
        if (result.stopReason !== 'completed') {
          entry.diagnostic = childDiagnostic(result, run.localAgent);
          const detail = entry.diagnostic;
          const failure = new Error(`${role} 运行未完成：${result.stopReason}${detail ? `；${detail.code ? '[' + detail.code + '] ' : ''}${detail.message}` : ''}`);
          failure.code = detail?.code;
          failure.diagnostic = detail;
          // Only authoritative normal termination can qualify; never infer from prose.
          const end = run.localAgent?.session?.snapshotEvents?.().findLast(event => event.type === 'turn/end');
          if (role === 'worker' && result.stopReason === 'error' && !result.diagnostic && result.structured === undefined && end?.data?.reason?.kind === 'completed' && run.policy.writes.size > 0 && !controller.signal.aborted) {
            failure.receiptRecovery = { childId: entry.childId, excerpt: prose || excerpt('') };
          }
          throw failure;
        }
        if (!result.structured || typeof result.structured !== 'object') {
          // 先补救再判死：模型用正文收尾时，同路由读一次就能把结果压回 schema。
          if (!meta.recovery && RECOVERABLE.has(role)) {
            const recovered = await recoverStructured({ role, route, prompt, schema, prose });
            if (recovered) {
              entry.status = 'completed';
              entry.output = recovered;
              entry.recovered = true;
              return recovered;
            }
          }
          throw new Error(`${role} 缺少结构化结果`);
        }
        entry.status = 'completed';
        entry.output = result.structured;
        return result.structured;
      } catch (error) {
        entry.status = 'failed';
        entry.error = excerpt(error);
        throw error;
      } finally {
        entry.endedAt = new Date().toISOString();
        try { await run?.dispose(); }
        finally { store.report(jobId, runId, report); }
      }
    }
    // 写入阶段状态：跨 try/catch 共享，失败时据此只回滚该回滚的范围。
    const phases = [];
    const failedTaskFiles = new Set();
    const done = (async () => {
      try {
        setStatus('running');
        emit('preflight', '检查项目准备状态、模型、档位和项目路径');
        controller.signal.throwIfAborted();
        report.preflight = inspectProject(job.projectRoot, { signal: controller.signal });
        if (report.preflight.status === 'blocked') {
          report.blockers = [report.preflight.reason];
          report.error = report.preflight.reason;
          report.nextAction = { checksNeeded: report.blockers, note: '尚未调用模型，未启动 worker；请准备项目后生成同配置的新任务。' };
          setStatus('blocked');
          emit('blocked', report.preflight.reason);
          return report;
        }
        // 只校验会使用的模型；探索档不解析、不调用 reviewer。
        await validateModelRoutes(ctx, job, controller.signal);
        let plan;
        let rejection = '';
        for (let attempt = 0; attempt <= job.maxPlanRetries; attempt++) {
          emit('plan', `规划 ${attempt + 1}/${job.maxPlanRetries + 1}`);
          // The host already retries model transport failures. A fresh planner
          // is only appropriate after a completed response fails plan validation.
          const candidate = await child('planner', job.planner,
            plannerPrompt(job, rejection), PLAN_SCHEMA);
          try {
            plan = validatePlan(candidate, job);
            report.planAttempts = attempt + 1;
            break;
          } catch (error) {
            controller.signal.throwIfAborted();
            rejection = excerpt(error);
            emit('plan-rejected', rejection);
            if (attempt === job.maxPlanRetries) throw error;
          }
        }
        report.plan = plan;
        if (plan.status === 'blocked') {
          report.blockers = plan.blockers;
          report.error = plan.blockers.join('；');
          report.nextAction = { checksNeeded: plan.blockers, note: 'planner 报告准备或实质冲突，未启动 worker；解决阻塞后创建同配置的新任务。' };
          setStatus('blocked');
          emit('blocked', report.error);
          return report;
        }
        emit('arbitrate', '文件归属、允许范围、保护文件和跨任务接口签名校验通过');
        report.plannerFeasibility = plannerFeasibility(plan);
        report.feasibilityPolicy = feasibilityPolicy(plan);
        const stopForFeasibility = (confirmation, source) => {
          if (confirmation.status === 'ready') return false;
          const unresolved = confirmation.tasks.filter(task => task.status !== 'ready');
          report.blockers = unresolved.map(task => `${task.taskId} [${task.status}]：${task.summary}；证据：${task.evidence.join('；')}`);
          report.error = report.blockers.join('\n');
          report.nextAction = {
            checksNeeded: report.blockers,
            questions: unresolved.flatMap(task => task.questions.map(question => `${task.taskId}：${question}`)),
            note: `${source}未通过，未启动实施 worker、未修改项目。请主会话解决证据所示问题后生成新任务；不会自动重规划或扩大权限。`,
          };
          setStatus('blocked');
          emit('blocked', report.error);
          return true;
        };
        controller.signal.throwIfAborted();
        if (stopForFeasibility(report.plannerFeasibility, 'planner 源码可行性自检')) return report;
        emit('planner-feasibility-ready', 'planner 已随计划提供逐项源码证据与可行性自检');
        controller.signal.throwIfAborted();
        if (options.planOnly) {
          setStatus('planned');
          return report;
        }
        // 独立复核走自己的路由（缺省继承 planner）。注意区分两类失败：
        //   结论性阻塞（needs_clarification / blocked）—— 必须在写入前停下交回主会话；
        //   运行故障（坏帧、缺 structured_output、结构校验不过）—— 降级为 planner 自检继续，
        //   在报告里留下 feasibilityDegraded 供主会话判断，不再让一次坏响应否决整条编排。
        if (report.feasibilityPolicy.required) {
          emit('feasibility', report.feasibilityPolicy.reason + '通过前不启动写入');
          try {
            report.feasibility = validateFeasibility(await child('feasibility', job.feasibility,
              feasibilityPrompt(job, plan), FEASIBILITY_SCHEMA), plan);
            controller.signal.throwIfAborted();
            if (stopForFeasibility(report.feasibility, '执行前可行性确认')) return report;
            emit('feasibility-ready', '独立复核确认全部任务可行，开始保存修改前快照');
          } catch (error) {
            controller.signal.throwIfAborted();
            // 安全闸门（权限/预算/路径）照样失败关闭；只有模型输出类故障才降级。
            if (isSafetyRefusal(error)) throw error;
            report.feasibilityDegraded = { route: job.feasibility, reason: excerpt(error), at: new Date().toISOString() };
            emit('feasibility-degraded', `独立复核未产出可用结论，降级为 planner 自检继续：${excerpt(error)}`);
          }
        } else {
          emit('feasibility-skipped', report.feasibilityPolicy.reason);
        }
        controller.signal.throwIfAborted();

        // —— 写入阶段 ——
        // 一个「阶段」= 一次快照 + 一组按 consumes 拓扑分波的 worker。
        // 拓扑分波是为了读时序：消费方必须等提供方写完，否则会读到旧文件。
        const conflictFor = task => report.feasibility?.tasks.find(item => item.taskId === task.id);

        async function runTask(task, phase) {
          const progress = phase.flow.tasks.find(item => item.taskId === task.id);
          Object.assign(progress, { status: 'running', startedAt: new Date().toISOString() });
          store.report(jobId, runId, report);
          try {
            const result = await runTaskBody(task, phase);
            Object.assign(progress, result);
            return result;
          } catch (error) {
            Object.assign(progress, { status: controller.signal.aborted ? 'cancelled' : 'failed', error: excerpt(error) });
            throw error;
          } finally {
            progress.endedAt = new Date().toISOString();
            try { progress.actualChangedFiles = store.diff(job.projectRoot, phase.manifest.filter(item => task.files.includes(item.file))).filter(item => item.changed).map(item => item.file); }
            catch (error) { progress.fileCheckError = excerpt(error); }
            store.report(jobId, runId, report);
          }
        }
        async function runTaskBody(task, phase) {
          try {
            let result;
            try {
              result = await child('worker', job.worker, workerPrompt(job, plan, task, conflictFor(task)), WORKER_SCHEMA, task);
            } catch (error) {
              controller.signal.throwIfAborted();
              if (!error.receiptRecovery) throw error;
              const ownedSnapshot = phase.manifest.filter(item => task.files.includes(item.file));
              const changes = store.diff(job.projectRoot, ownedSnapshot);
              if (!changes.some(item => item.changed)) throw error;
              const recovery = { taskId: task.id, sourceChildId: error.receiptRecovery.childId, status: 'running', changes };
              (report.receiptRecoveries ||= []).push(recovery);
              emit('receipt-recovery', `${task.id} 缺少回执；同模型只读补交一次，不重新实施`);
              try {
                result = await child('receipt', job.worker,
                  receiptPrompt(job, task, { changes, previousWorkerText: error.receiptRecovery.excerpt }), WORKER_SCHEMA, task);
                if (JSON.stringify(store.diff(job.projectRoot, ownedSnapshot)) !== JSON.stringify(changes)) throw new Error('补交回执期间文件发生变化，停止复核');
                recovery.status = 'completed';
                result = { ...result, summary: '[只读补交回执；原 worker 未提交有效结果] ' + result.summary };
              } catch (failure) { recovery.status = 'failed'; recovery.error = excerpt(failure); throw failure; }
            }
            if (result.status !== 'completed') throw new Error(`${task.id} 报告 mismatch：${result.summary}`);
            if (!Array.isArray(result.changedFiles)) throw new Error(`${task.id} 缺少 changedFiles`);
            const owned = new Set(task.files.map(file => pathKey(safeTarget(job.projectRoot, file))));
            const changedFiles = result.changedFiles.map(file => {
              if (typeof file !== 'string') throw new Error(`${task.id} 返回无效文件名`);
              const rel = path.isAbsolute(file)
                ? path.relative(job.projectRoot, rebaseToRealRoot(job.projectRoot, file)).replaceAll('\\', '/')
                : file.replaceAll('\\', '/');
              const target = safeTarget(job.projectRoot, rel);
              if (!owned.has(pathKey(target))) throw new Error(`${task.id} 声称修改了分配外文件`);
              return rel;
            });
            // 声明与实际对齐：一个文件都没动却声称完成 → 该任务不可信，直接失败；
            // 部分声称未变 → 从清单里剔除并留事件；真改了却没申报 → 以磁盘为准并进清单。
            const actualChanged = store.diff(job.projectRoot, phase.manifest.filter(item => task.files.includes(item.file)))
              .filter(item => item.changed).map(item => item.file);
            const phantom = changedFiles.filter(file => !actualChanged.includes(file));
            if (phantom.length && !actualChanged.length) {
              throw new Error(`${task.id} 声称修改了 ${phantom.join(', ')}，但这些文件没有实际变化`);
            }
            const declared = changedFiles.filter(file => !phantom.includes(file));
            if (phantom.length) emit('worker-unchanged-claims', `${task.id} 声称的文件里 ${phantom.join(', ')} 实际未变化，已从 changedFiles 移除`);
            const unreported = actualChanged.filter(file => !declared.includes(file));
            if (unreported.length) {
              declared.push(...unreported);
              emit('worker-unreported', `${task.id} 修改了未申报的文件，已按磁盘并入 changedFiles：${unreported.join(', ')}`);
            }
            return { taskId: task.id, status: 'completed', ...result, changedFiles: declared };
          } catch (error) {
            // 真正的取消要向上传播；单任务失败只记录，不再取消同波其他任务。
            controller.signal.throwIfAborted();
            for (const file of task.files) failedTaskFiles.add(file);
            emit('worker-failed', `${task.id} 失败，其下游任务将被跳过：${excerpt(error)}`);
            return { taskId: task.id, status: 'failed', error: excerpt(error), changedFiles: [] };
          }
        }

        async function executePhase(tasks, label) {
          const manifest = store.snapshot(jobId, runId, job.projectRoot, tasks.flatMap(task => task.files), label ? { label } : {});
          const directory = path.join(store.directory(jobId), 'snapshots', runId, ...(label ? [label] : []));
          const flow = { id: label || 'initial', plan: { tasks }, snapshot: { files: manifest, directory }, tasks: tasks.map(task => ({ taskId: task.id, status: 'pending', assignedFiles: task.files })) };
          (report.flowPhases ||= []).push(flow);
          report.snapshot ||= { files: manifest, directory };
          const phase = { label, manifest, directory, flow };
          phases.push(phase);
          emit('snapshot', label ? `已保存 ${label} 阶段的原始字节与哈希` : '已保存计划修改文件的原始字节与哈希');
          const entries = [];
          const unavailable = new Set();
          for (const wave of planWaves(tasks)) {
            const waveTasks = wave.map(id => tasks.find(task => task.id === id));
            const settled = await Promise.allSettled(waveTasks.map(async task => {
              const blockedBy = task.consumes.map(entry => entry.from).filter(id => unavailable.has(id));
              if (blockedBy.length) {
                const skipped = { taskId: task.id, status: 'skipped', reason: `上游未完成：${blockedBy.join(', ')}`, changedFiles: [] };
                Object.assign(flow.tasks.find(item => item.taskId === task.id), skipped);
                store.report(jobId, runId, report);
                return skipped;
              }
              return runTask(task, phase);
            }));
            settled.forEach((result, index) => {
              const task = waveTasks[index];
              if (result.status === 'fulfilled') {
                entries.push(result.value);
                if (result.value.status !== 'completed') unavailable.add(task.id);
              } else {
                entries.push({ taskId: task.id, status: 'failed', error: excerpt(result.reason), changedFiles: [] });
                unavailable.add(task.id);
                for (const file of task.files) failedTaskFiles.add(file);
              }
            });
            controller.signal.throwIfAborted();
          }
          // 立刻记下运行后的哈希基线，供失败回滚做三方比对。
          phase.expected = store.diff(job.projectRoot, manifest);
          return { phase, entries };
        }

        async function reviewOnce(files, workers, planForReview = plan, repairContext = null) {
          emit('review', '由独立 reviewer 模型只读复核实际修改与验收条件');
          // 修复轮必须让复核看到修复计划：否则 reviewer 只能拿首轮计划去套修复后的 diff。
          const prompt = reviewerPrompt(job, planForReview, files, workers, report.assertions, repairContext);
          let raw;
          for (let attempt = 1; attempt <= 2; attempt++) {
            const record = { phase: activePhase, attempt, route: job.reviewer, status: 'running', startedAt: new Date().toISOString() };
            (report.reviewAttempts ||= []).push(record);
            const childStart = report.children.length;
            try {
              raw = await child('reviewer', job.reviewer, prompt, REVIEW_SCHEMA);
              record.status = 'completed';
              break;
            } catch (error) {
              record.status = 'error';
              record.error = excerpt(error);
              record.code = error.code;
              controller.signal.throwIfAborted();
              if (isSafetyRefusal(error)) throw error;
              if (attempt < 2 && error.code === 'MALFORMED_RESPONSE') {
                emit('review-retry', 'reviewer 响应格式异常，使用相同模型与档位只读重试一次');
                continue;
              }
              error.reviewCall = true;
              throw error;
            } finally {
              record.childId = report.children[childStart]?.childId;
              record.endedAt = new Date().toISOString();
            }
          }
          // 归一与校验放在这里：模型输出不可直接当结论用，三档语义、checks 形状都要过一遍。
          let reviewed;
          try { reviewed = validateReview(raw); }
          catch (error) {
            const attempt = report.reviewAttempts.at(-1);
            attempt.status = 'error';
            attempt.error = excerpt(error);
            error.reviewCall = true;
            throw error;
          }
          // 单条 check 的格式问题在这里已被降级成 unverifiable，不再抛错；但要留痕，
          // 否则主会话只会看到「少了一项可执行验证」，分不清是模型写坏了还是插件吃掉了。
          if (reviewed.degraded.length) {
            emit('review-degraded', `复核有 ${reviewed.degraded.length} 项待验证条目降级为 unverifiable（不阻塞结论）：${reviewed.degraded.map(entry => `${entry.id}（${entry.issue}）`).join('；')}`);
          }
          return { ...reviewed, route: job.reviewer };
        }

        const first = await executePhase(plan.tasks, '');
        report.snapshot = { files: first.phase.manifest, directory: first.phase.directory };
        report.snapshots = [report.snapshot];
        report.workers = first.entries;
        report.tasks = first.entries.map(entry => ({ taskId: entry.taskId, status: entry.status, ...(entry.error ? { error: entry.error } : {}) }));
        report.files = store.diff(job.projectRoot, first.phase.manifest);
        const failed = first.entries.filter(entry => entry.status === 'failed');
        if (failed.length) {
          const done = first.entries.filter(entry => entry.status === 'completed').map(entry => entry.taskId);
          throw new Error(`任务失败：${failed.map(entry => `${entry.taskId}（${entry.error || '未说明原因'}）`).join('；')}；已完成 ${done.length ? done.join(', ') : '无'}，其余跳过`);
        }
        const skipped = first.entries.filter(entry => entry.status === 'skipped');
        if (skipped.length) throw new Error(`任务被跳过：${skipped.map(entry => `${entry.taskId}（${entry.reason}）`).join('；')}`);
        if (!report.files.some(file => file.changed) && !job.assertions?.length) {
          throw new Error('worker 均返回完成，但计划文件没有实际变化');
        }

        // —— 断言闸门：worker 全部结束后先跑实测 ——
        // 断言只看数据/产物，不看代码逻辑，所以它能"放行"但不能"批准代码"。
        // 是否据此跳过复核由 reviewMode 决定，默认不跳。
        const ownedFiles = new Set(plan.tasks.flatMap(task => task.files).map(file => pathKey(file)));
        const gate = await executeAssertions(job, { ownedFiles, phase: 'post_worker' });
        // 无 reviewer 分支没有 child() 的取消守卫，不能把断言等待期间的取消报成完成。
        controller.signal.throwIfAborted();
        if (job.assertions?.length) {
          // 只有启用过断言的任务才带这段；没选的项目不该多出一个空记录。
          report.assertions = gate.record;
          emit('assertions', gate.pass
            ? `数据断言通过（执行 ${gate.record.counts.checks_run} 条，${gate.record.counts.not_applicable} 条不适用）`
            : `数据断言未放行（${gate.record.status}）：${gate.record.reason || '存在未通过项'}`);
        }

        controller.signal.throwIfAborted();
        const skipReview = gate.pass && acceptance.assertionBypass;
        if (!acceptance.modelReview) {
          // 明确的探索交付，不伪装成断言批准或静态复核；选中的断言仍然是闸门。
          report.review = null;
          report.reviewSkipped = { reason: 'exploratory', level: acceptance.level };
          report.decidedBy = 'exploration_policy';
          const blocked = Boolean(job.assertions?.length) && !gate.pass;
          report.verdict = blocked ? 'blocked_by_data' : 'exploratory_unreviewed';
          if (blocked) {
            report.blockers = [gate.record.reason || ('所选数据断言未通过：' + gate.record.status)];
          }
          setStatus(blocked ? 'blocked' : 'needs_validation');
          emit('review-skipped', blocked
            ? '探索档不调用 reviewer；所选断言未放行，保留实施结果和证据，等待处理'
            : '探索档已完成实施；未进行模型复核、构建或运行时验证，待主会话最小冒烟检查');
        } else if (skipReview) {
          // 放行时必须留下"这次没有复核"的痕迹，
          // 否则 review=null 会被读成"复核过了没问题"。
          report.review = null;
          report.verdict = 'passed_by_assertions';
          report.decidedBy = 'verifier';
          setStatus('needs_validation');
          emit('review-skipped', '断言全部通过且 reviewMode=on_failure，跳过复核');
        } else try {
          report.review = await reviewOnce(report.files, report.workers);
          setStatus(reviewStatus(report.review));
        } catch (error) {
          controller.signal.throwIfAborted();
          // 安全闸门（权限/预算/越界）仍然失败关闭；其余「复核没交出可用结论」不再销毁成果：
          // 代码已经写完并落过快照，把文件、哈希和失败原因交回主会话，比回滚干净更有用。
          if (isSafetyRefusal(error)) throw error;
          report.reviewError = excerpt(error);
          report.reviewFailure = { phase: activePhase, code: error.code || null, message: excerpt(error) };
          setStatus('review_error');
          emit('review-error', `复核未产出可用结论，保留已写入的成果交回主会话：${excerpt(error)}`);
        }

        // —— 定向修复：reviewer 给出具体问题时，带证据重规划一次并重跑修复任务 ——
        // 但只有 worker 能修的问题才值得开修复轮：数据文件通常不在 allowedGlobs 内，
        // 派任务去改只会撞「文件不在允许范围」。这类直接标 blocked_by_data 交回主会话。
        const findings = report.assertions?.findings ?? [];
        const workerFixable = findings.filter(finding => finding.owner === 'worker');
        const externalOnly = findings.length > 0 && workerFixable.length === 0;
        const reviewRepair = report.review?.assessment === 'issues_found';
        // 断言实测指出 worker 归属内的失败项时，不等模型点头也要修：
        // reviewer 判 verified_statically 只说明它没看出问题，不代表文件改对了。
        const assertionRepair = workerFixable.length > 0;
        if (reviewRepair && externalOnly) {
          report.verdict = 'blocked_by_data';
          report.decidedBy = 'reviewer';
          setStatus('blocked');
          emit('blocked-by-data', `复核确认问题不在 worker 可修改范围内（${findings.length} 项），不做修复轮`);
        } else if (acceptance.autoRepair && (reviewRepair || assertionRepair) && job.maxRepairRounds > 0) {
          // 修复轮是「继续跑」，不是「已结束」：状态必须回到 running。
          // 否则上一轮复核写下的 review_failed 会被 flow 当成终态：worker 还在跑
          // 就显示「失败」、后续节点被标成「已跳过」，前端还会直接停掉轮询。
          setStatus('running');
          report.initialReview = report.review;
          const priorReviewStatus = report.initialReview ? reviewStatus(report.initialReview) : 'review_error';
          activePhase = 'repair-1';
          emit('repair', assertionRepair
            ? `数据断言发现 worker 归属内 ${workerFixable.length} 项失败，带证据做一次定向修复规划`
            : '复核发现具体问题，带证据做一次定向修复规划');
          /* 修复轮的证据边跑边记：中途失败时 report.repair 里至少要有已经产出的计划、
             文件清单和 worker 结果。此前整块被重写成 {status,error}，复盘时「到底改了
             哪些文件」只能翻快照目录才看得出来。 */
          const repairRecord = { round: 1 };
          report.repair = repairRecord;
          try {
            const repairPlan = validatePlan(await child('planner', job.planner,
              repairPrompt(job, plan, report.files, report.workers, report.review, report.assertions), PLAN_SCHEMA), job);
            repairRecord.plan = repairPlan;
            if (repairPlan.status === 'blocked') {
              repairRecord.status = 'blocked';
              repairRecord.blockers = repairPlan.blockers;
              emit('repair-skipped', '定向修复规划判定无法只靠改代码解决，保留复核结论交回主会话');
              // 没修成就要退回首轮结论状态：进修复轮时改成了 running，不退回去报告会一直挂在运行中。
              setStatus(priorReviewStatus);
            } else {
              const repair = await executePhase(repairPlan.tasks, 'repair-1');
              repairRecord.snapshot = { files: repair.phase.manifest, directory: repair.phase.directory };
              report.snapshots.push(repairRecord.snapshot);
              const repairWorkers = repair.entries;
              repairRecord.workers = repairWorkers;
              repairRecord.files = store.diff(job.projectRoot, repair.phase.manifest);
              const repairFailed = repairWorkers.filter(entry => entry.status === 'failed');
              if (repairFailed.length) {
                throw new Error(`修复任务失败：${repairFailed.map(entry => `${entry.taskId}（${entry.error || '未说明原因'}）`).join('；')}`);
              }
              // 先复验再复核：reviewer 该拿到"修复后"的实测结果，而不是修复前的失败项。
              if (job.assertions?.length) {
                const recheck = await executeAssertions(job, {
                  ownedFiles: new Set([...plan.tasks, ...repairPlan.tasks].flatMap(task => task.files).map(file => pathKey(file))),
                  phase: 'post_repair',
                });
                repairRecord.assertions = recheck.record;
                report.assertions = recheck.record;
                emit('assertions-recheck', recheck.pass
                  ? '修复后复验通过'
                  : `修复后复验仍有问题（${recheck.record.status}）：${recheck.record.reason || '存在未通过项'}`);
              }
              // 复核要给全貌：repairRecord.files 只是本轮增量，reviewer 拿它没法判断
              // 「首轮的目标到底做没做」，会把首轮已经修好的东西当成漏做或越界。
              const cumulative = store.diff(job.projectRoot, mergeManifests(first.phase.manifest, repair.phase.manifest));
              const repairReview = await reviewOnce(cumulative, repairWorkers, repairPlan, {
                round: 1,
                triggerFindings: workerFixable,
                previousAssessment: report.initialReview?.assessment,
              });
              delete report.reviewError;
              delete report.reviewFailure;
              repairRecord.review = repairReview;
              repairRecord.status = 'completed';
              report.review = repairReview;
              report.files = cumulative;
              setStatus(reviewStatus(report.review));
            }
          } catch (error) {
            controller.signal.throwIfAborted();
            // 修复是「第二次机会」，它自己失败不该抹掉已经写好且已复核过的成果：
            // 安全类拒绝照样上抛，其余保留原复核结论并标记 repair 失败。
            if (isSafetyRefusal(error)) throw error;
            // 但「修复任务本身失败」必须上抛：那批任务可能写了半截，要交给外层按任务回滚。
            if (report.repair?.workers?.some(entry => entry.status === 'failed')) throw error;
            // 失败时把这一轮 planner 的正文一起留在报告里：否则「为什么没交结构化结果」
            // 只能回原始会话日志挖（模型写了什么，是复盘的第一手材料）。
            const failedPlanner = report.children.findLast(entry => entry.role === 'planner' && entry.phase === 'repair-1');
            repairRecord.status = error.reviewCall ? 'review_error' : 'failed';
            repairRecord.error = excerpt(error);
            if (failedPlanner?.rawOutput) repairRecord.rawOutput = failedPlanner.rawOutput;
            // 同理：修复失败时退回首轮复核结论，不能把报告留在 running 上。
            if (error.reviewCall) {
              repairRecord.implementationStatus = 'completed';
              repairRecord.reviewError = excerpt(error);
              report.review = null;
              report.reviewError = excerpt(error);
              report.reviewFailure = { phase: activePhase, code: error.code || null, message: excerpt(error) };
              setStatus('review_error');
            } else setStatus(priorReviewStatus);
            // 修复阶段已经写过盘：即便这一轮失败，report.files 也要反映磁盘现状，
            // 否则哈希会停在首轮，主会话核对时会以为修复压根没落盘。
            if (repairRecord.snapshot) {
              report.files = store.diff(job.projectRoot, mergeManifests(first.phase.manifest, repairRecord.snapshot.files));
            }
            emit(error.reviewCall ? 'review-error' : 'repair-failed', error.reviewCall
              ? `修复实施已完成，但最终复核调用异常；保留文件与实测结果：${excerpt(error)}`
              : `定向修复未完成，保留原复核结论：${excerpt(error)}`);
          }
        }

        report.nextAction = report.reviewSkipped?.reason === 'exploratory' ? {
          verifyHint: job.verifyHint,
          checksNeeded: [
            ...(report.blockers || []),
            ...(job.verifyHint ? [job.verifyHint] : ['由主会话按项目已有流程执行最小语法/构建、启动及本次关键路径冒烟检查；不适用的项目不强行补齐全套测试。']),
          ],
          checks: [],
          runtimeVerified: false,
          note: report.status === 'blocked'
            ? '探索档未进行模型复核或自动返工；所选数据断言未通过或未实际执行，不能作为通过交付。文件和原始证据已保留。插件未执行构建、启动或运行时冒烟检查。'
            : '探索实施完成，未经模型复核；不等于功能正确或运行不报错。未进行自动返工；文件已保留供试用。插件未执行构建、启动或运行时冒烟检查，需主会话按 verifyHint 做最小验证。',
        } : report.review ? {
          verifyHint: job.verifyHint,
          // 保留旧的字符串数组，已有消费方按 checksNeeded 读取时不会断。
          checksNeeded: checkLines(report.review.checks),
          checks: report.review.checks,
          note: `插件未执行构建/测试。结论 ${report.review.assessment} 只代表只读静态复核；${report.review.checks.length} 项待主会话按 kind 与 expected 逐条执行${report.review.degraded?.length ? `；其中 ${report.review.degraded.length} 项因单条格式问题降级为 unverifiable（原因见 checks[].issue，不影响结论）` : ''}。`,
        } : report.verdict === 'passed_by_assertions' ? {
          verifyHint: job.verifyHint,
          checksNeeded: [],
          checks: [],
          note: `数据断言已实际执行并通过（${report.assertions.counts.checks_run} 条，退出码 0），按 reviewMode=on_failure 跳过复核。注意：断言只覆盖数据与结构，不覆盖实现细节，代码改动未经模型复核。插件未执行构建/测试。`,
        } : {
          verifyHint: job.verifyHint,
          checksNeeded: [],
          checks: [],
          note: `复核未产出可用结论（${report.reviewError || 'review 为空且无错误信息，请核对 reviewMode 与断言状态'}）；文件已保留并记录哈希，请主会话按项目既有流程人工复核后再决定保留或按 scripts/restore.mjs 还原。插件未执行构建/测试。`,
        };
        controller.signal.throwIfAborted();
        return report;
      } catch (error) {
        report.error = excerpt(error);
        const cancelled = controller.signal.aborted === true;
        if (report.reviewSkipped?.reason === 'exploratory') {
          // 交付事件回调也可能触发取消；不能残留“成果已保留待试用”的成功口径。
          delete report.verdict;
          delete report.decidedBy;
          report.nextAction = { verifyHint: job.verifyHint, checksNeeded: [], checks: [], runtimeVerified: false,
            note: '探索运行已取消或失败，未交付待试用结果，也未验证运行时。实际文件保留或回滚情况请查看 rollback 与错误证据。' };
        }
        // 失败或取消后收拾半改现场：留一半改动比失败本身更贵，而且插件没有版本控制兜底。
        // 只在快照存在（已过写入闸门）时尝试；还原本身有哈希守卫与备份自证，不动没改过的文件。
        if (report.snapshot && job.rollbackOnFailure !== false) {
          let note = '';
          try {
            // 任务级失败只回滚「失败发生的那个阶段」里失败任务自己的文件：
            // 更早阶段的同名文件是已复核过的成果，不能被修复阶段的失败连带抹掉。
            // 没有任务级失败（例如复核阶段崩了）才按逆序整体回退。
            const scopes = failedTaskFiles.size
              ? [phases.at(-1)]
              : [...phases].reverse();
            const files = [];
            for (const scope of scopes) {
              const targets = failedTaskFiles.size
                ? scope.manifest.filter(item => failedTaskFiles.has(item.file))
                : scope.manifest;
              if (!targets.length) continue;
              const expected = scope.expected ?? store.diff(job.projectRoot, targets);
              files.push(...store.restore(job.projectRoot, targets, scope.directory, { expected }));
            }
            const changed = files.filter(item => item.action === 'restored' || item.action === 'removed').length;
            const conflicts = files.filter(item => item.action === 'conflict' || item.action === 'skipped').length;
            report.rollback = {
              reason: cancelled ? 'cancelled' : 'failed',
              changed,
              conflicts,
              failed: files.filter(item => item.action === 'failed').length,
              files,
            };
            note = report.rollback.failed
              ? `回滚有 ${report.rollback.failed} 个文件失败，需人工处理`
              : conflicts
                ? `已还原 ${changed} 个文件；${conflicts} 个因运行后有外部改动被跳过`
                : `已把 ${changed} 个计划文件还原到运行前状态`;
          } catch (rollbackError) {
            report.rollback = { reason: cancelled ? 'cancelled' : 'failed', failed: true, error: excerpt(rollbackError) };
            note = '回滚过程中出错，需人工检查计划文件';
          }
          try { emit('rollback', note); }
          catch (recordError) { report.recordError = excerpt(recordError); }
        }
        setStatus(cancelled ? 'cancelled' : 'failed');
        try { emit(report.status, report.error); }
        catch (recordError) { report.recordError = excerpt(recordError); }
        return report;
      } finally {
        report.endedAt = new Date().toISOString();
        try { store.report(jobId, runId, report); }
        catch (error) { report.recordError = excerpt(error); }
        finally {
          locks.delete(rootKey);
          active.delete(runId);
          signal?.removeEventListener('abort', onAbort);
        }
      }
    })();
    activity.result = done;
    return { id: runId, result: done, cancel(reason) { controller.abort(reason || '任务已取消'); } };
  }
  return { run, async dispose() {
    closing = true;
    const running = [...active.values()];
    for (const activity of running) activity.controller.abort('插件卸载');
    await Promise.allSettled(running.map(activity => activity.result));
  } };
}
