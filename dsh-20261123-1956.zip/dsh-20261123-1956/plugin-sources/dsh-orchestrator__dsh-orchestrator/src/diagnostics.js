import { captureModule } from './runtime.js';
captureModule(import.meta.url);
// The native spawn seam may omit diagnostics. Read only the bound child's own
// settled session outcome; never infer an error from assistant prose/tool data.

/** 只做脱敏，不截断；截断交给调用方按场景选长度。 */
function redact(message) {
  return String(message)
    .replace(/\bsk-[a-zA-Z0-9_-]{8,}/g, '[redacted]')
    .replace(/\bBearer\s+[^\s"'<>]+/gi, 'Bearer [redacted]')
    .replace(/((?:api[_-]?key|access[_-]?token|authorization|secret)["']?\s*[:=]\s*["']?)[^\s,"'}]+/gi, '$1[redacted]');
}

export function errorExcerpt(value) {
  const message = typeof value === 'string' ? value : value?.message || String(value);
  return redact(message).slice(0, 1800);
}

/**
 * 子会话最后交给用户的正文（result.output 里的 text 片段）。
 * 失败时必须能自证「模型到底写了什么」——此前只有 structured_output 成功时才会存结果，
 * 一旦模型用正文收尾，报告里就只剩下「未提交有效的 structured_output」这一句，
 * 只能回原始会话日志里挖。这里保留有界正文，供报告与补交会话复用。
 */
export function outputProse(output) {
  return (Array.isArray(output) ? output : [])
    .filter(item => item?.type === 'text')
    .map(item => item.text || '')
    .join('\n')
    .trim();
}

export function proseExcerpt(output, limit = 4000) {
  const text = typeof output === 'string' ? output : outputProse(output);
  return text ? redact(text).slice(0, limit) : '';
}

function diagnostic(value, source) {
  if (value == null) return undefined;
  const message = typeof value === 'string' ? value : value.message;
  if (typeof message !== 'string' || !message.trim()) return undefined;
  return { source, message: errorExcerpt(message), ...(typeof value.code === 'string' ? { code: errorExcerpt(value.code).slice(0, 80) } : {}) };
}

export function childDiagnostic(result, agent) {
  const provided = diagnostic(result.diagnostic, 'result');
  if (provided) return provided;
  if (result.stopReason !== 'error') return undefined;
  try {
    const events = agent?.session?.snapshotEvents?.() || [];
    const end = events.findLast(event => event.type === 'turn/end');
    const reason = end?.data?.reason;
    if (reason?.kind === 'error') return diagnostic(reason.error, 'session');
    if (reason?.kind === 'completed') return diagnostic('子会话结束但未提交有效的 structured_output', 'session');
    if (end) return undefined;
    const retry = events.findLast(event => event.type === 'llm/retry');
    return diagnostic(retry?.data?.failure, 'session');
  } catch {
    // Diagnostic lookup is best effort and must never mask the original error.
    return undefined;
  }
}
