import { captureModule } from './runtime.js';
captureModule(import.meta.url);
// Pure report projection. Never infer a successful write from a plan or a hash alone.
export function flowModel(job = {}, report = null) {
  const run = report || {};
  const children = Array.isArray(run.children) ? run.children : [];
  const nodes = [], edges = [];
  // 有报告就只认 endedAt：运行中的报告没有 endedAt，而 job.status 可能还停在
  // 上一个阶段的结论（首轮复核写完 review_failed、修复轮其实还在跑）。
  // 拿 job.status 判终态会把「还在跑」渲染成「已失败」，前端还会停掉轮询。
  const FINAL_STATUSES = ['failed', 'cancelled', 'blocked', 'planned', 'needs_validation', 'review_failed', 'review_error'];
  const stillWorking = children.some(child => child.status === 'running' || child.status === 'starting');
  const terminal = !stillWorking && (report ? Boolean(run.endedAt) : FINAL_STATUSES.includes(job.status));
  const level = run.reviewLevel || run.reviewPolicy?.level || job.reviewLevel || 'standard';
  const reviewSkipped = run.reviewSkipped || (terminal && (run.verdict === 'exploratory_unreviewed' || level === 'exploratory' && run.verdict === 'blocked_by_data') ? { reason: 'exploratory', level: 'exploratory' } : null);
  const exploratory = level === 'exploratory' || reviewSkipped?.reason === 'exploratory' || reviewSkipped?.level === 'exploratory';
  const selection = [...new Set([...(Array.isArray(job.assertions) ? job.assertions : []), ...(Array.isArray(run.assertions?.selection) ? run.assertions.selection : [])])];
  const assertionsPass = record => record?.status === 'pass' && record.exit_code === 0 && record.counts?.checks_run > 0;
  const exploratoryDataBlocked = exploratory && terminal && ['needs_validation','blocked'].includes(run.status || job.status) && selection.length > 0 && !assertionsPass(run.assertions);
  const labels = { completed: '已完成', running: '运行中', starting: '启动中', pending: '等待中', failed: '失败', skipped: '已跳过', blocked: '受阻', degraded: '已降级', cancelled: '已取消', issues: '发现问题', review_error: '复核异常', retrying: '重试中', needs_validation: '探索完成·待试用' };
  let col = 0;
  function add(id, title, status, detail = {}, at = col, row = 0) {
    const node = { id, title, status, statusLabel: labels[status] || status, col: at, row, ...detail };
    nodes.push(node); return node;
  }
  function connect(from, to, status) { if (!from || !to) return; const broken = from.status === 'failed' || from.status === 'review_error' || from.status === 'blocked' || from.affected; edges.push({ from: from.id, to: to.id, status: status || (broken ? (from.status === 'failed' || from.status === 'review_error' ? 'failed' : 'affected') : to.status === 'failed' || to.status === 'review_error' || to.status === 'blocked' ? 'failed' : to.affected ? 'affected' : to.status === 'completed' ? 'completed' : 'pending') }); }
  function childNode(c, index, title, row = 0, at = col) {
    return add('child-' + index, title, c.status || 'pending', { role: c.role, route: c.requested, startedAt: c.startedAt, endedAt: c.endedAt, output: c.output, error: c.error || c.diagnostic?.message, assignedFiles: c.assignedFiles || [], childId: c.childId }, at, row);
  }
  // 旧报告可能没有 preflight 字段；planner 跑过就说明这一关已经过了，不能显示成失败。
  const preflightStatus = run.preflight?.status === 'blocked' ? 'blocked'
    : run.preflight?.status === 'ready' ? 'completed'
    : children.some(child => child.role === 'planner') ? 'completed'
    : run.startedAt ? (terminal ? 'skipped' : 'running') : 'pending';
  const pre = add('preflight', '环境与边界检查', preflightStatus, { output: run.preflight, error: run.preflight?.status === 'blocked' ? run.preflight.reason || run.error : null });
  col++;
  const firstRepair = children.findIndex(c => c.phase && c.phase !== 'initial');
  const initialChildren = children.map((c, i) => ({ c, i })).filter(({c, i}) => c.phase ? c.phase === 'initial' : firstRepair < 0 || i < firstRepair);
  const repairPlanIndex = firstRepair >= 0 ? firstRepair : run.repair ? children.findIndex((c, i) => c.role === 'planner' && children.slice(0, i).some(x => x.role === 'reviewer')) : -1;
  const initial = initialChildren.filter(({i}) => repairPlanIndex < 0 || i < repairPlanIndex);
  const planners = initial.filter(({c}) => c.role === 'planner');
  let previous = pre;
  if (!planners.length) { const n = add('planner-pending', 'Planner · 规划', terminal ? 'skipped' : 'pending', { role: 'planner', route: job.planner }); connect(previous, n); previous = n; col++; }
  planners.forEach(({c, i}, n) => { const node = childNode(c, i, 'Planner' + (n ? ' · 重规划 ' + n : ' · 规划')); if (c.output?.status === 'blocked') { node.status = 'blocked'; node.statusLabel = labels.blocked; } connect(previous, node); previous = node; col++; });
  const fs = initial.find(({c}) => c.role === 'feasibility');
  const check = fs ? childNode(fs.c, fs.i, 'Feasibility · 写入前复核') : add('feasibility', 'Feasibility · 写入前复核', run.feasibilityPolicy?.required === false || run.planOnly ? 'skipped' : terminal && !run.plan ? 'skipped' : 'pending', { role: 'feasibility', route: job.feasibility || job.planner });
  if (run.feasibilityDegraded) { check.status = 'degraded'; check.statusLabel = labels.degraded; check.error = run.feasibilityDegraded.reason; }
  else if (run.feasibility && run.feasibility.status !== 'ready') { check.status = 'blocked'; check.statusLabel = labels.blocked; }
  connect(previous, check); previous = check; col++;
  function workers(tasks, phaseId, subset, source, progress = []) {
    const byId = new Map(); const levels = new Map();
    function level(task, visiting = new Set()) {
      if (levels.has(task.id)) return levels.get(task.id);
      if (visiting.has(task.id)) return 0;
      const next = new Set(visiting); next.add(task.id);
      const deps = (task.consumes || []).map(d => tasks.find(t => t.id === d.from)).filter(Boolean);
      const n = deps.length ? 1 + Math.max(...deps.map(t => level(t, next))) : 0; levels.set(task.id, n); return n;
    }
    const rowCounts = new Map();
    tasks.forEach(task => {
      const depth = level(task); const row = rowCounts.get(depth) || 0; rowCounts.set(depth, row + 1);
      const matches = subset.filter(({c}) => c.role === 'worker' && c.taskId === task.id);
      const hit = matches[matches.length - 1];
      const p = progress.find(t => t.taskId === task.id);
      let status = p?.status || hit?.c.status || (terminal ? 'skipped' : 'pending');
      if (status === 'completed' && p?.status === 'failed') status = 'failed';
      const receipts = subset.filter(({c}) => c.role === 'receipt' && c.taskId === task.id);
      const node = add(phaseId + '-worker-' + task.id, 'Worker · ' + task.id, status, {
        role: 'worker', taskId: task.id, phase: phaseId, route: hit?.c.requested || job.worker,
        assignedFiles: task.files || [], output: hit?.c.output, actualChangedFiles: p?.actualChangedFiles,
        error: p?.error || hit?.c.error, reason: p?.reason, startedAt: p?.startedAt || hit?.c.startedAt,
        endedAt: p?.endedAt || hit?.c.endedAt, receipts: receipts.map(x => x.c),
        affected: status === 'skipped' && (p?.reason || (task.consumes || []).length > 0),
        rollback: (run.rollback?.files || []).filter(f => (task.files || []).includes(f.file)),
      }, col + depth, row);
      byId.set(task.id, node);
    });
    tasks.forEach(task => {
      const node = byId.get(task.id); const deps = (task.consumes || []).map(d => byId.get(d.from)).filter(Boolean);
      if (!deps.length) connect(source, node);
      else deps.forEach(dep => { if (dep.status === 'failed' || dep.affected) node.affected = node.status === 'skipped'; connect(dep, node, dep.status === 'failed' ? 'failed' : dep.affected || node.affected ? 'affected' : undefined); });
    });
    col += tasks.length ? Math.max(...tasks.map(t => levels.get(t.id))) + 1 : 1;
    return [...byId.values()].filter(n => !tasks.some(t => (t.consumes || []).some(d => d.from === n.taskId)));
  }
  function phase(tasks, phaseId, subset, source, phaseData, reviewData) {
    const snap = add(phaseId + '-snapshot', '保存原文件快照', phaseData?.snapshot || phaseId === 'initial' && run.snapshot ? 'completed' : terminal ? 'skipped' : 'pending', { output: phaseData?.snapshot || (phaseId === 'initial' ? run.snapshot : null), artifactType: 'snapshot' }); connect(source, snap); col++;
    const ends = workers(tasks, phaseId, subset, snap, phaseData?.tasks || (phaseId === 'initial' ? run.workers || [] : run.repair?.workers || []));
    if (!tasks.length) { const placeholder = add(phaseId + '-workers', 'Workers · 等待任务分配', terminal ? 'skipped' : 'pending'); connect(snap, placeholder); ends.push(placeholder); }
    const assertionRecord = phaseData?.assertions || (phaseId === 'initial' ? run.repair?.assertions ? run.initialAssertions : run.assertions : run.repair?.assertions);
    const selected = selection.length > 0 || assertionRecord?.selection?.length > 0;
    const assertionStatus = assertionRecord ? assertionsPass(assertionRecord) ? 'completed' : ['running','starting'].includes(assertionRecord.status) ? 'running' : assertionRecord.status === 'not_run' || assertionRecord.status === 'not_applicable' ? 'skipped' : 'blocked' : selected ? terminal ? 'skipped' : 'pending' : 'skipped';
    const verifier = add(phaseId + '-assertions', 'Verifier · 数据断言', assertionStatus, { role: 'assertions', output: assertionRecord, reason: assertionRecord?.reason || (!selected ? '未选择数据断言；不代表通过' : terminal && !assertionRecord ? '未记录该阶段的断言执行结果；不代表通过' : undefined), affected: selected && terminal && !assertionsPass(assertionRecord) });
    if (assertionRecord?.status === 'not_applicable') verifier.statusLabel = '不适用 · 非通过';
    else if (selected && terminal && !assertionsPass(assertionRecord) && !assertionRecord) verifier.statusLabel = '未执行 · 非通过';
    ends.forEach(n => connect(n, verifier)); col++;
    const reviewers = subset.filter(({c}) => c.role === 'reviewer');
    const r = reviewers.at(-1);
    const skipped = phaseId === 'initial' ? reviewSkipped : run.repair?.reviewSkipped;
    const node = r ? childNode(r.c, r.i, 'Reviewer · 写入后复核') : add(phaseId + '-reviewer', 'Reviewer · 写入后复核', skipped || terminal ? 'skipped' : 'pending', { route: job.reviewer, role: 'reviewer', reason: skipped?.reason, output: skipped ? { reviewSkipped: skipped } : undefined });
    if (!r && skipped?.reason) node.statusLabel = labels.skipped + ' · ' + skipped.reason;
    // 卡片反映本阶段最新尝试，旧调用仍留在详情中供排查重试原因。
    node.reviewerAttempts = reviewers.map(({c}) => c);
    const assessment = reviewData?.assessment || node.output?.assessment;
    if (node.status === 'completed' && assessment === 'issues_found') { node.status = 'issues'; node.statusLabel = labels.issues; }
    if (ends.some(n => n.status === 'failed' || n.status === 'skipped' || n.affected) || verifier.affected || verifier.status === 'blocked') node.affected = true;
    connect(verifier, node); col++;
    return node;
  }
  const initialPhase = (run.flowPhases || []).find(p => p.id === 'initial');
  previous = phase(run.plan?.tasks || [], 'initial', initial, previous, initialPhase, run.repair ? run.initialReview : run.review);
  const repairs = children.map((c,i) => ({c,i})).filter(({c,i}) => c.phase && c.phase !== 'initial' || repairPlanIndex >= 0 && i >= repairPlanIndex);
  if (repairs.length || run.repair) {
    const p = repairs.find(({c}) => c.role === 'planner');
    const repairNode = p ? childNode(p.c, p.i, 'Planner · 定向修复') : add('repair-planner', 'Planner · 定向修复', run.repair?.status || 'pending', { error: run.repair?.error, output: run.repair });
    connect(previous, repairNode); col++;
    previous = phase(run.repair?.plan?.tasks || (run.flowPhases || []).find(p => p.id !== 'initial')?.plan?.tasks || [], 'repair', repairs.filter(x => x !== p), repairNode, (run.flowPhases || []).find(p => p.id !== 'initial'), run.repair?.review);
  }
  if (run.rollback) { const n = add('rollback', '回滚与保留结果', run.rollback.failed || run.rollback.conflicts ? 'blocked' : 'completed', { output: run.rollback, artifactType: 'rollback' }); connect(previous, n); previous = n; col++; }
  const verdict = exploratoryDataBlocked ? 'blocked' : run.status || job.status || 'queued';
  const end = add('result', '运行结果', terminal ? verdict === 'review_error' ? 'review_error' : verdict === 'failed' || verdict === 'review_failed' ? 'failed' : verdict === 'blocked' ? 'blocked' : verdict === 'cancelled' ? 'cancelled' : exploratory && verdict === 'needs_validation' ? 'needs_validation' : 'completed' : 'pending', { output: run.nextAction, error: verdict === 'review_error' ? run.reviewError : run.error, verdict, reviewSkipped, ...(exploratory ? { runtimeVerified: false, reportVerdict: run.verdict } : {}) }); connect(previous, end);
  return { nodes, edges, status: verdict, terminal, runId: run.runId, jobId: job.id || run.jobId, task: job.task || run.task, updatedAt: run.events?.at(-1)?.at || run.startedAt };
}

export const flowStyles = `
.flow-card[data-status=needs_validation]{border-color:var(--flow-amber)}.flow-card[data-status=needs_validation] .flow-chip{color:var(--flow-amber)}
.flow-shell{position:relative;--flow-red:#e44763;--flow-green:#29a577;--flow-blue:#557ef0;--flow-amber:#c3892d}.flow-head{display:flex;justify-content:space-between;align-items:flex-start;gap:16px;margin-bottom:18px}.flow-head h2{font-size:22px;margin:0}.flow-legend{display:flex;flex-wrap:wrap;gap:16px;font-size:12px;color:var(--muted);margin:10px 0 18px}.flow-legend span:before{content:'';display:inline-block;width:7px;height:7px;border-radius:50%;background:var(--dot);margin-right:7px}.flow-layout{display:grid;grid-template-columns:minmax(0,1fr) 320px;gap:16px;align-items:start}.flow-viewport{overflow:auto;min-height:220px;border:1px solid var(--line);border-radius:14px;background:radial-gradient(circle,var(--line) 1px,transparent 1px) 0 0/18px 18px}.flow-canvas{position:relative;display:grid;grid-auto-columns:178px;grid-auto-rows:minmax(118px,auto);gap:22px 38px;padding:26px;min-width:100%;width:max-content;align-items:start}.flow-card{position:relative;z-index:1;text-align:left;width:178px;min-height:118px;border:1px solid var(--line);border-radius:13px;background:var(--panel);color:var(--text);padding:15px;box-shadow:0 4px 14px #101a3010;cursor:pointer;white-space:normal;font-weight:400}.flow-card:hover,.flow-card[aria-pressed=true]{border-color:var(--flow-blue);outline:2px solid color-mix(in srgb,var(--flow-blue) 25%,transparent)}.flow-card strong{display:block;font-size:12.5px;line-height:1.35;margin:8px 0 3px;overflow-wrap:anywhere}.flow-card small{display:block;color:var(--muted);font-size:11px;overflow-wrap:anywhere}.flow-chip{display:inline-flex;gap:6px;align-items:center;font-size:11px;font-weight:650}.flow-chip:before{content:'';width:6px;height:6px;border-radius:50%;background:currentColor}.flow-card[data-status=running],.flow-card[data-status=starting]{border-color:var(--flow-blue);box-shadow:0 0 0 1px #557ef055,0 0 22px #557ef033}.flow-card[data-status=running] .flow-chip,.flow-card[data-status=starting] .flow-chip{color:var(--flow-blue)}.flow-card[data-status=completed] .flow-chip{color:var(--flow-green)}:is(.flow-card[data-status=failed],.flow-card[data-status=review_error]),.flow-card[data-status=blocked],.flow-card[data-status=issues]{border-color:var(--flow-red);box-shadow:0 0 0 1px #e4476355,0 0 22px #e4476340}:is(.flow-card[data-status=failed],.flow-card[data-status=review_error]) .flow-chip,.flow-card[data-status=blocked] .flow-chip,.flow-card[data-status=issues] .flow-chip{color:var(--flow-red)}.flow-card[data-affected=true]{border-color:var(--flow-red);border-style:dashed;box-shadow:0 0 15px #e447632b}.flow-card[data-status=degraded]{border-color:var(--flow-amber)}.flow-card[data-status=degraded] .flow-chip{color:var(--flow-amber)}.flow-card[data-status=pending],.flow-card[data-status=skipped]{opacity:.75}.flow-connectors{position:absolute;inset:0;overflow:visible;pointer-events:none;z-index:0}.flow-edge{fill:none;stroke:var(--line);stroke-width:2}.flow-edge[data-status=completed]{stroke:var(--flow-green);opacity:.7}.flow-edge[data-status=failed]{stroke:var(--flow-red);stroke-width:3;filter:drop-shadow(0 0 4px #e4476399)}.flow-edge[data-status=affected]{stroke:var(--flow-red);stroke-dasharray:6 4;opacity:.7}.flow-detail{border:1px solid var(--line);border-radius:14px;padding:18px;min-width:0;max-height:660px;overflow:auto;overflow-wrap:anywhere}.flow-detail h3{font-size:16px}.flow-detail h4{margin:17px 0 6px;font-size:12px;color:var(--muted)}.flow-detail pre{white-space:pre-wrap;font-size:11px;line-height:1.6;max-height:360px;overflow:auto;background:var(--bg);padding:10px;border-radius:8px}.flow-file{font:11px/1.6 ui-monospace,monospace;border:1px solid var(--line);padding:7px 9px;border-radius:6px;margin:5px 0;overflow-wrap:anywhere}.flow-note{font-size:12px;color:var(--muted)}.flow-warning{color:var(--error)}.flow-toolbar{display:flex;gap:8px;flex-wrap:wrap}.flow-live{font-size:12px;color:var(--muted)}.flow-live[data-error=true]{color:var(--error)}[hidden]{display:none!important}@media(max-width:900px){.flow-layout{grid-template-columns:1fr}.flow-detail{max-height:420px}}@media(prefers-reduced-motion:reduce){.flow-shell *{animation:none!important;transition:none!important}}
`;

// Self-contained DOM renderer, serialized into the settings iframe by page().
export function createFlowView(host, modelFor) {
  let selected = null, model = null, fingerprint = '', destroyed = false;
  const make = (tag, text, cls) => { const n = document.createElement(tag); if (text !== undefined) n.textContent = String(text); if (cls) n.className = cls; return n; };
  const shell = make('div', undefined, 'flow-shell');
  const legend = make('div', undefined, 'flow-legend');
  [['运行中','#557ef0'],['完成','#29a577'],['失败 / 发现问题','#e44763'],['降级','#c3892d'],['虚线：受上游失败影响','#e44763']].forEach(([text,color]) => { const n=make('span',text);n.style.setProperty('--dot',color);legend.append(n); });
  const layout = make('div', undefined, 'flow-layout'), viewport = make('div', undefined, 'flow-viewport'), canvas = make('div', undefined, 'flow-canvas'), detail = make('aside', undefined, 'flow-detail');
  detail.setAttribute('aria-label', '流程卡片详情'); viewport.tabIndex=0; viewport.setAttribute('aria-label','编排流程图，可横向滚动');
  viewport.append(canvas); const hint=make('p','横向滚动可查看更多阶段；点击任意卡片查看该阶段的输出与文件。','flow-note'); hint.style.margin='0 0 8px'; layout.append(viewport,detail);shell.append(legend,hint,layout);host.replaceChildren(shell);
  function showDetail(node) {
    if (!node) return;
    selected=node.id; canvas.querySelectorAll('button').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.nodeId===selected)));
    detail.replaceChildren(make('h3',node.title),make('p',node.statusLabel));
    function section(title,value) { if (value === undefined || value === null || value === '') return;detail.append(make('h4',title),make('pre',typeof value==='string'?value:JSON.stringify(value,null,2))); }
    section('模型路由',node.route ? (node.route.provider || '')+'/'+(node.route.model || '') : null);
    if (node.startedAt || node.endedAt) { detail.append(make('h4','时间')); detail.append(make('p','开始：'+(node.startedAt ? new Date(node.startedAt).toLocaleString() : '未开始'),'flow-note')); if (node.endedAt) detail.append(make('p','结束：'+new Date(node.endedAt).toLocaleString(),'flow-note')); }
    function files(title,items) { if (!items?.length) return;detail.append(make('h4',title));items.forEach(f=>detail.append(make('div',typeof f==='string'?f:JSON.stringify(f), 'flow-file'))); }
    files('计划分配文件（不代表已经改动）',node.assignedFiles);
    if (node.role==='worker') {
      files('已核验的实际修改文件',node.actualChangedFiles);
      files('模型回执声明的文件',node.output?.changedFiles);
      if (!node.actualChangedFiles?.length && !node.output?.changedFiles?.length) detail.append(make('p','暂未记录文件产出。','flow-note'));
      files('回滚 / 保留状态',node.rollback);
    } else detail.append(make('p','该阶段为只读判断或宿主步骤；下方展示结论和报告，不将计划内文件算作新产物。','flow-note'));
    section('输出 / 检查结论',node.output);section('失败原因',node.error);section('跳过原因',node.reason);section('补交回执',node.receipts?.length ? node.receipts : null);section('复核调用记录（含重试）',node.reviewerAttempts?.length > 1 ? node.reviewerAttempts : null);
    if (node.runtimeVerified === false) section('验证边界','探索产物未经模型复核；运行时尚未验证，需按项目既有流程试用与验证。');
    if(node.role==='planner' && node.output?.tasks) files('计划涉及的文件', [...new Set(node.output.tasks.flatMap(t=>t.files||[]))]);
  }
  function draw() {
    if (destroyed || !model) return;
    canvas.querySelector('svg')?.remove();
    const svg=document.createElementNS('http://www.w3.org/2000/svg','svg');svg.classList.add('flow-connectors');svg.setAttribute('aria-hidden','true');svg.setAttribute('width',canvas.scrollWidth);svg.setAttribute('height',canvas.scrollHeight);
    const base=canvas.getBoundingClientRect();
    model.edges.forEach(edge=>{ const a=[...canvas.querySelectorAll('button')].find(b=>b.dataset.nodeId===edge.from),b=[...canvas.querySelectorAll('button')].find(b=>b.dataset.nodeId===edge.to);if(!a||!b)return;const ar=a.getBoundingClientRect(),br=b.getBoundingClientRect(),x=ar.right-base.left,y=ar.top-base.top+ar.height/2,tx=br.left-base.left,ty=br.top-base.top+br.height/2;const p=document.createElementNS(svg.namespaceURI,'path');p.classList.add('flow-edge');p.dataset.status=edge.status;p.setAttribute('d','M'+x+','+y+' C'+(x+(tx-x)/2)+','+y+' '+(x+(tx-x)/2)+','+ty+' '+tx+','+ty);svg.append(p);});canvas.prepend(svg);
  }
  function render(job,report) {
    const next=modelFor(job,report), key=JSON.stringify(next);
    if (key===fingerprint) return;fingerprint=key;model=next;
    const focused=document.activeElement?.dataset?.nodeId;
    canvas.replaceChildren();
    model.nodes.forEach(node=>{ const b=make('button',undefined,'flow-card');b.type='button';b.dataset.nodeId=node.id;b.dataset.status=node.status;b.dataset.affected=String(Boolean(node.affected));b.style.gridColumn=String(node.col+1);b.style.gridRow=String(node.row+1);b.setAttribute('aria-label',node.title+'，'+node.statusLabel+'，点击详情');b.append(make('span',node.statusLabel,'flow-chip'),make('strong',node.title),make('small',node.route?.model || (node.role==='worker' ? '等待任务执行' : '宿主 / 只读阶段')),make('small',node.role==='worker'?((node.actualChangedFiles?.length ?? node.output?.changedFiles?.length ?? 0)+' 个文件产出 · 点击详情'):'查看详情 →'));b.onclick=()=>showDetail(node);canvas.append(b); });
    const chosen=model.nodes.find(n=>n.id===selected)||model.nodes.find(n=>n.status==='running'||n.status==='starting')||model.nodes.find(n=>n.status==='failed'||n.status==='review_error'||n.status==='blocked')||model.nodes[0];showDetail(chosen);
    if(focused) [...canvas.querySelectorAll('button')].find(b=>b.dataset.nodeId===focused)?.focus({preventScroll:true});
    requestAnimationFrame(draw);
  }
  const observer=typeof ResizeObserver==='function'?new ResizeObserver(draw):null;observer?.observe(viewport);
  window.addEventListener('resize',draw);
  return {render,fit(){viewport.scrollLeft=0;draw();},destroy(){destroyed=true;observer?.disconnect();window.removeEventListener('resize',draw);host.replaceChildren();}};
}

