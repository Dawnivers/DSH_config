import { captureModule } from './runtime.js';
captureModule(import.meta.url);
import { randomBytes } from 'node:crypto';
import { createBrowserBridge, secretEquals } from './browser-bridge.js';
import { validateJob } from './policy.js';
import { models, defaultConfig, compatibility } from './runner.js';
import { page } from './ui.js';
import { modelEntry, validateModelRoutes } from './models.js';
import { assertionCatalog, validateAssertionSelection } from './assertions.js';

// 保存探索档默认设置时，未使用的 reviewer 可能因能力目录过期而被前端省略。
// 保留此前的显式配置，避免切回标准档时悄悄丢失模型/effort；启用时仍须重新校验。
function preserveInactiveReviewer(input, previous) {
  const level = input?.reviewLevel ?? input?.adapter?.reviewLevel;
  const explicitReviewer = ['reviewer', 'reviewerProvider', 'reviewerModel', 'reviewerEffort'].some(key => input && Object.hasOwn(input, key));
  const previousReviewer = previous?.reviewer || (previous?.reviewerProvider && previous?.reviewerModel
    ? { provider: previous.reviewerProvider, model: previous.reviewerModel, ...(previous.reviewerEffort != null ? { effort: previous.reviewerEffort } : {}) }
    : null);
  return typeof level === 'string' && level.trim() === 'exploratory' && !explicitReviewer && previousReviewer
    ? { ...input, reviewer: previousReviewer }
    : input;
}

const ROOT = '/dsh-orchestrator/settings';
const PREFIX = ROOT + '/api';
function respond(res, status, data) {
  const body = JSON.stringify(data);
  res.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', 'content-length': Buffer.byteLength(body) });
  res.end(body);
}
function body(req) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    req.on('data', chunk => {
      size += chunk.length;
      if (size > 128 * 1024) { reject(new Error('请求体超过 128 KiB')); req.destroy(); return; }
      chunks.push(chunk);
    });
    req.on('end', () => { try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}')); } catch { reject(new Error('JSON 格式无效')); } });
    req.on('error', reject);
  });
}
export function createSettings(ctx, store) {
  const web = ctx.get?.('webServer');
  if (!web?.register) return null;
  const token = randomBytes(32).toString('hex');
  const equal = candidate => secretEquals(candidate, token);
  const bridges = createBrowserBridge({ store });
  const origin = web.getOrigin?.() || `http://127.0.0.1:${web.port}`;
  async function state(bridgeId) {
    const { catalog, warnings } = await models(ctx);
    const saved = (bridgeId && bridges.defaults(bridgeId)) || store.defaults();
    if ((saved.planner || saved.strongProvider) && !Object.hasOwn(saved, 'reviewer') && !Object.hasOwn(saved, 'reviewerProvider')) warnings.push('旧默认设置没有独立 reviewer，暂沿用原 planner 路由与档位；请选择复核模型并保存。');
    return { models: catalog, defaults: defaultConfig(catalog, saved), jobs: store.list().filter(job => !bridgeId || bridges.canReadTask(bridgeId, job.id)).slice(0, 100), compatibility: compatibility(ctx), storagePath: store.root, warnings, assertions: await assertionCatalog() };
  }
  const handler = async (req, res) => {
    try {
      const url = new URL(req.url, 'http://127.0.0.1');
      if (url.pathname === ROOT && req.method === 'GET') {
        const candidate = url.searchParams.get('token'), bridgeId = url.searchParams.get('bridge');
        const scoped = bridges.authenticate(candidate);
        if (bridgeId ? scoped?.bridgeId !== bridgeId : !equal(candidate)) return respond(res, 403, { error: '设置页访问凭据无效，请从原会话重新打开 AI 编排' });
        const boot = bridgeId ? { ...bridges.boot(bridgeId), token: candidate, parentOrigin: new URL(origin).origin } : null;
        res.writeHead(200, { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-store', 'referrer-policy': 'no-referrer', 'content-security-policy': "default-src 'none'; style-src 'unsafe-inline'; script-src 'unsafe-inline'; connect-src 'self'; base-uri 'none'; form-action 'none'; frame-ancestors 'self'" });
        return res.end(page(boot));
      }
      if (!url.pathname.startsWith(PREFIX + '/')) return respond(res, 404, { error: 'not found' });
      const admin = equal(req.headers['x-settings-token']);
      const scope = admin ? null : bridges.authenticate(req.headers['x-settings-token']);
      if (!admin && !scope) return respond(res, 401, { error: 'API 访问凭据无效或连接已过期，请从原会话重新打开' });
      if (req.headers.origin && req.headers.origin !== new URL(web.getOrigin?.() || `http://127.0.0.1:${web.port}`).origin) return respond(res, 403, { error: '跨来源请求被拒绝' });
      const action = url.pathname.slice(PREFIX.length);
      if (req.method === 'GET' && action === '/bridge/status') {
        const id = url.searchParams.get('bridgeId');
        if (scope && scope.bridgeId !== id) return respond(res, 403, { error: '禁止读取其他浏览器连接' });
        return respond(res, 200, bridges.status(id));
      }
      if (req.method === 'POST' && action.startsWith('/bridge/')) {
        if (!req.headers['content-type']?.startsWith('application/json')) return respond(res, 415, { error: '仅支持 application/json' });
        const input = await body(req);
        if (scope && (!['/bridge/submit', '/bridge/draft'].includes(action) || input.bridgeId !== scope.bridgeId)) return respond(res, 403, { error: '浏览器连接只允许向绑定会话提交本页任务' });
        if (action === '/bridge/draft') {
          const config = preserveInactiveReviewer(input.config, bridges.defaults(input.bridgeId) || store.defaults());
          const candidate = validateJob({ ...config, task: 'browser defaults validation', projectRoot: process.cwd() });
          await validateModelRoutes(ctx, candidate);
          candidate.assertions = (await validateAssertionSelection(candidate.assertions)).selection;
          delete candidate.task; delete candidate.projectRoot;
          return respond(res, 200, bridges.saveDraft(input.bridgeId, candidate));
        }
        if (action === '/bridge/open') {
          const opened = bridges.open(input);
          return respond(res, 200, { ...opened, url: origin + ROOT + '?token=' + opened.browserToken + '&bridge=' + opened.bridgeId });
        }
        if (action === '/bridge/close') { bridges.close(input.bridgeId, input.ownerToken); return respond(res, 200, { closed: true }); }
        if (action === '/bridge/poll') return respond(res, 200, bridges.poll(input.bridgeId, input.ownerToken));
        if (action === '/bridge/result') return respond(res, 200, bridges.settle(input.bridgeId, input.ownerToken, input.taskId, input.result, input.attempt));
        if (action === '/bridge/submit') return respond(res, 200, bridges.submit(input.bridgeId, input.taskId));
        return respond(res, 404, { error: 'not found' });
      }
      if (req.method === 'GET' && action === '/state') {
        const value = await state(scope?.bridgeId);
        return respond(res, 200, value);
      }
      if (req.method === 'GET' && action === '/activity') {
        const session = url.searchParams.get('session');
        if (scope && session !== scope.sessionId) return respond(res, 403, { error: '禁止读取其他会话任务' });
        if (!session || session.length > 200) return respond(res, 400, { error: '缺少有效会话 ID' });
        return respond(res, 200, { tasks: store.list().filter(job => job.parentSession === session && job.runId).slice(0, 20) });
      }
      if (req.method === 'GET' && action === '/task') {
        const id = url.searchParams.get('id') || '';
        if (scope && !bridges.canReadTask(scope.bridgeId, id)) return respond(res, 403, { error: '禁止读取未绑定的任务' });
        return respond(res, 200, { job: { ...store.get(id), ...store.status(id) }, runs: store.runs(id) });
      }
      if (req.method === 'POST' && ['/save', '/job', '/model'].includes(action)) {
        if (!req.headers['content-type']?.startsWith('application/json')) return respond(res, 415, { error: '仅支持 application/json' });
        if (scope && (action === '/save' || (action === '/job' && req.headers['x-orchestrator-bridge'] !== scope.bridgeId))) return respond(res, 403, { error: '浏览器仅能保存绑定任务；全局默认设置请在 DSH 插件设置中修改' });
        const input = await body(req);
        if (action === '/model') return respond(res, 200, { model: await modelEntry(ctx, input?.provider, input?.model) });
        if (action === '/job') {
          const validated = validateJob(input);
          const create = async () => {
            await validateModelRoutes(ctx, validated);
            const assertionCheck = await validateAssertionSelection(validated.assertions);
            validated.assertions = assertionCheck.selection;
            const job = store.create(validated);
            return { id: job.id, instruction: `使用 orchestrate_run 工具执行任务 ${job.id}。任务已保存在插件中；请按工具返回的实际结果继续项目验证。`, job, warnings: assertionCheck.warnings };
          };
          const bridgeId = req.headers['x-orchestrator-bridge'];
          return respond(res, 200, bridgeId ? await bridges.createJob(bridgeId, validated, create) : await create());
        }
        // 默认设置也走同一参数校验；占位任务 / 项目仅用于校验，不保存在默认中。
        const config = preserveInactiveReviewer(input, store.defaults());
        const candidate = validateJob({ ...config, task: 'defaults validation', projectRoot: process.cwd() });
        await validateModelRoutes(ctx, candidate);
        candidate.assertions = (await validateAssertionSelection(candidate.assertions)).selection;
        delete candidate.task; delete candidate.projectRoot;
        return respond(res, 200, store.saveDefaults(candidate));
      }
      return respond(res, 404, { error: 'not found' });
    } catch (error) {
      if (!res.headersSent) respond(res, 400, { error: String(error.message).replace(/\bsk-[a-zA-Z0-9_-]{8,}/g, '[redacted]').slice(0, 1000) });
      else res.end();
    }
  };
  const offRoute = web.register({ kind: 'prefix', path: ROOT, handler });
  const url = (web.getOrigin?.() || `http://127.0.0.1:${web.port}`) + ROOT + '?token=' + token;
  const offBoot = ctx.on('webserver/index-inject', table => { table.push({ kind: 'global', name: '__DSH_ORCHESTRATOR_SETTINGS__', value: { url } }); });
  return { url, handler, dispose() { bridges.dispose(); offBoot?.(); offRoute?.(); } };
}
