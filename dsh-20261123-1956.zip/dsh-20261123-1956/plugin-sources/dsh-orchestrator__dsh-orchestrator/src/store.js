import { captureModule } from './runtime.js';
captureModule(import.meta.url);
import { mkdirSync, readFileSync, writeFileSync, renameSync, readdirSync, existsSync, lstatSync, rmSync } from 'node:fs';
import { homedir } from 'node:os';
import path from 'node:path';
import { randomUUID, createHash } from 'node:crypto';
import { safeTarget } from './policy.js';

export const hash = bytes => createHash('sha256').update(bytes).digest('hex');
export function makeStore(root = process.env.DSH_ORCHESTRATOR_HOME || path.join(process.env.DSH_HOME || path.join(homedir(), '.dsh'), 'storages', 'orchestrator')) {
  root = path.resolve(root);
  const jobsRoot = path.join(root, 'jobs');
  mkdirSync(jobsRoot, { recursive: true });
  function atomic(file, data) {
    mkdirSync(path.dirname(file), { recursive: true });
    const temp = file + '.' + randomUUID() + '.tmp';
    writeFileSync(temp, JSON.stringify(data, null, 2), { encoding: 'utf8', mode: 0o600, flag: 'wx' });
    renameSync(temp, file);
  }
  function id(value) { if (!/^[0-9a-f-]{36}$/.test(value)) throw new Error('任务 ID 无效'); return value; }
  function directory(value) { return path.join(jobsRoot, id(value)); }
  function read(file) { return JSON.parse(readFileSync(file, 'utf8')); }
  function get(jobId) { return read(path.join(directory(jobId), 'job.json')); }
  function status(jobId) {
    const file = path.join(directory(jobId), 'status.json');
    return existsSync(file) ? read(file) : { status: 'queued' };
  }
  /**
   * 把计划文件还原到快照时的字节，用于失败/取消后收拾半改现场。
   *
   * 四条硬约定：
   *  1. 三方哈希：把当前字节和 `expected`（运行结束时的 after 哈希）比对，
   *     不一致说明运行结束后又有别人改过这个文件 —— 跳过并报 conflict，
   *     绝不覆盖用户的并发工作或外部修改。
   *  2. 无事不做：当前字节已经等于 `before` 的文件不写（不产生无意义的 mtime 变化）。
   *  3. 备份自证：写回前用记录的 sha256 校验备份，备份被改过就报失败，绝不还原错字节。
   *  4. 只动快照内的文件：路径仍过 safeTarget，越界/链接照样拒绝。
   * `expected` 缺省（undefined）时按「没有运行后基线」处理，一律跳过，不猜。
   * apply=false 只报告「本来会做什么」。单个文件失败不影响其他文件。
   */
  function restore(projectRoot, manifest, runDir, { apply = true, expected } = {}) {
    const after = expected === undefined || expected === null ? null : new Map(expected.map(item => [item.file, item.after]));
    const results = [];
    for (const entry of manifest) {
      const file = safeTarget(projectRoot, entry.file);
      const backupPath = entry.backup ? path.join(runDir, entry.backup) : null;
      const current = existsSync(file) ? hash(readFileSync(file)) : null;
      if (current === entry.before) {
        results.push({ file: entry.file, action: 'unchanged', ok: true });
        continue;
      }
      if (after === null) {
        results.push({ file: entry.file, action: 'skipped', ok: false, error: '缺少运行后哈希基线，未触碰文件' });
        continue;
      }
      if (after.get(entry.file) !== current) {
        results.push({ file: entry.file, action: 'conflict', ok: false, error: '文件在运行结束后又被改动，未覆盖' });
        continue;
      }
      try {
        if (entry.existed) {
          if (!backupPath || !existsSync(backupPath)) throw new Error('快照备份缺失');
          const bytes = readFileSync(backupPath);
          if (hash(bytes) !== entry.before) throw new Error('快照备份哈希与记录不符');
          if (apply) {
            mkdirSync(path.dirname(file), { recursive: true });
            const temp = `${file}.${randomUUID()}.restore`;
            writeFileSync(temp, bytes, { flag: 'wx' });
            renameSync(temp, file);
            if (hash(readFileSync(file)) !== entry.before) throw new Error('还原后哈希与记录不符');
          }
          results.push({ file: entry.file, action: apply ? 'restored' : 'would-restore', ok: true });
        } else {
          if (apply) {
            rmSync(file, { force: true });
            if (existsSync(file)) throw new Error('删除运行期间新建的文件失败');
          }
          results.push({ file: entry.file, action: apply ? 'removed' : 'would-remove', ok: true });
        }
      } catch (error) {
        results.push({ file: entry.file, action: 'failed', ok: false, error: String(error?.message || error) });
      }
    }
    return results;
  }
  /** 按 jobId/runId 找到该次运行的快照并还原；运行后哈希取自该次运行的报告。 */
  function restoreRun(jobId, runId, options) {
    const runDir = path.join(directory(jobId), 'snapshots', runId, ...(options?.label ? [options.label] : []));
    const manifestPath = path.join(runDir, 'manifest.json');
    if (!existsSync(manifestPath)) throw new Error('该运行没有快照，无法还原');
    const manifest = read(manifestPath);
    const reportPath = path.join(directory(jobId), 'runs', id(runId) + '.json');
    const expected = existsSync(reportPath) ? (read(reportPath).files ?? undefined) : undefined;
    const files = restore(manifest.projectRoot, manifest.files, runDir, { ...options, expected });
    return { jobId, runId, projectRoot: manifest.projectRoot, applied: options?.apply !== false, files,
      failed: files.filter(item => item.action === 'failed').length,
      conflicts: files.filter(item => item.action === 'conflict' || item.action === 'skipped').length };
  }
  return {
    root, directory, atomic, get, status,
    defaults() { const f = path.join(root, 'defaults.json'); return existsSync(f) ? read(f) : {}; },
    saveDefaults(value) { atomic(path.join(root, 'defaults.json'), value); return value; },
    create(config) {
      const job = { id: randomUUID(), createdAt: new Date().toISOString(), ...config };
      atomic(path.join(directory(job.id), 'job.json'), job);
      atomic(path.join(directory(job.id), 'status.json'), { status: 'queued', updatedAt: job.createdAt });
      return job;
    },
    setStatus(jobId, value) { atomic(path.join(directory(jobId), 'status.json'), { ...value, updatedAt: new Date().toISOString() }); },
    list() {
      return readdirSync(jobsRoot).filter(x => /^[0-9a-f-]{36}$/.test(x)).map(jobId => {
        const job = get(jobId);
        return { id: job.id, createdAt: job.createdAt, task: job.task, projectRoot: job.projectRoot, ...status(jobId) };
      }).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    },
    runs(jobId) {
      const dir = path.join(directory(jobId), 'runs');
      return existsSync(dir) ? readdirSync(dir).filter(f => f.endsWith('.json')).map(f => read(path.join(dir, f))) : [];
    },
    report(jobId, runId, report) { atomic(path.join(directory(jobId), 'runs', id(runId) + '.json'), report); },
    snapshot(jobId, runId, projectRoot, files, { label = '' } = {}) {
      const base = path.join(directory(jobId), 'snapshots', runId, ...(label ? [label] : []));
      const manifest = [];
      let total = 0;
      for (const [index, name] of files.entries()) {
        const file = safeTarget(projectRoot, name);
        let bytes = null;
        if (existsSync(file)) {
          const stat = lstatSync(file);
          if (!stat.isFile() || stat.size > 5 * 1024 * 1024) throw new Error(`快照文件类型不支持或超过 5 MiB：${name}`);
          total += stat.size;
          if (total > 50 * 1024 * 1024) throw new Error('本次快照总量超过 50 MiB');
          bytes = readFileSync(file);
        }
        const backup = `${index}.bin`;
        if (bytes) {
          const backupPath = path.join(base, backup);
          mkdirSync(path.dirname(backupPath), { recursive: true });
          writeFileSync(backupPath, bytes, { flag: 'wx', mode: 0o600 });
        }
        manifest.push({ file: name, existed: bytes !== null, before: bytes === null ? null : hash(bytes), backup: bytes === null ? null : backup });
      }
      atomic(path.join(base, 'manifest.json'), { projectRoot, files: manifest });
      return manifest;
    },
    diff(projectRoot, manifest) {
      return manifest.map(entry => {
        const file = safeTarget(projectRoot, entry.file);
        const after = existsSync(file) ? hash(readFileSync(file)) : null;
        return { file: entry.file, before: entry.before, after, changed: entry.before !== after };
      });
    },
    restore, restoreRun,
  };
}
