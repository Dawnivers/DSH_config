import { randomBytes, randomUUID, timingSafeEqual, createHash } from 'node:crypto';
import { captureModule } from './runtime.js';
captureModule(import.meta.url);

const uuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
export function secretEquals(candidate, expected) {
  return typeof candidate === 'string' && Buffer.byteLength(candidate) === Buffer.byteLength(expected) && timingSafeEqual(Buffer.from(candidate), Buffer.from(expected));
}

// A browser never invokes models directly. Only the original DSH client owns
// the receipt secret and can deliver a fixed saved-task instruction to its session.
export function createBrowserBridge({ store, now = Date.now, ttlMs = 8 * 60 * 60 * 1000, heartbeatMs = 120000, maxBridges = 64 }) {
  const bridges = new Map();
  function sweep() { for (const [id, bridge] of bridges) if (now() >= bridge.expiresAt) bridges.delete(id); }
  function get(id) {
    sweep();
    const bridge = bridges.get(id);
    if (!bridge) throw new Error('浏览器会话连接已失效，请从原 DSH 会话重新打开 AI 编排；不会自动切换目标会话。');
    return bridge;
  }
  function owner(id, secret) {
    const bridge = get(id);
    if (!secretEquals(secret, bridge.ownerToken)) throw new Error('会话回传凭据无效');
    return bridge;
  }
  function connected(bridge) { return bridge.lastSeen !== null && now() - bridge.lastSeen <= heartbeatMs; }
  function publicState(bridge) {
    return { bridgeId: bridge.id, sessionId: bridge.sessionId, sessionTitle: bridge.sessionTitle, workspaceRoot: bridge.workspaceRoot,
      expiresAt: new Date(bridge.expiresAt).toISOString(), connected: connected(bridge),
      deliveries: [...bridge.deliveries].map(([taskId, delivery]) => ({ taskId, attempt: delivery.attempt, status: delivery.status, ...(delivery.result ? { result: delivery.result } : {}) })) };
  }
  return {
    open(input) {
      sweep();
      if (!input || typeof input.sessionId !== 'string' || !/^[a-zA-Z0-9][a-zA-Z0-9._:-]{0,199}$/.test(input.sessionId)) throw new Error('缺少有效目标会话');
      if (bridges.size >= maxBridges) throw new Error('浏览器连接已达上限，请关闭旧页面或稍后重新打开');
      let monitorTaskId;
      if (input.monitorTaskId !== undefined) {
        if (!uuid.test(input.monitorTaskId) || store.status(input.monitorTaskId).parentSession !== input.sessionId) throw new Error('该任务不属于目标会话，不能作为浏览器监控目标');
        monitorTaskId = input.monitorTaskId;
      }
      const id = randomUUID(), ownerToken = randomBytes(32).toString('hex'), browserToken = randomBytes(32).toString('hex');
      const bridge = { id, ownerToken, browserToken, sessionId: input.sessionId, sessionTitle: String(input.sessionTitle || input.sessionId).slice(0, 200),
        workspaceRoot: String(input.workspaceRoot || '').slice(0, 4096), monitorTaskId,
        expiresAt: now() + ttlMs, lastSeen: null, jobs: new Set(), creations: new Map(), deliveries: new Map() };
      bridges.set(id, bridge);
      return { bridgeId: id, ownerToken, browserToken, expiresAt: new Date(bridge.expiresAt).toISOString() };
    },
    authenticate(candidate) {
      sweep();
      for (const b of bridges.values()) if (secretEquals(candidate, b.browserToken)) return { bridgeId: b.id, sessionId: b.sessionId };
      return null;
    },
    canReadTask(id, taskId) {
      const b = get(id);
      if (b.jobs.has(taskId) || b.monitorTaskId === taskId) return true;
      try { return store.status(taskId).parentSession === b.sessionId; } catch { return false; }
    },
    close(id, secret) { owner(id, secret); bridges.delete(id); },
    defaults(id) { return get(id).defaults || null; },
    saveDraft(id, config) { const b = get(id); b.defaults = structuredClone(config); return b.defaults; },
    boot(id) {
      const b = get(id);
      return { detached: true, bridgeId: b.id, sessionId: b.sessionId, sessionTitle: b.sessionTitle, workspaceRoot: b.workspaceRoot, ...(b.monitorTaskId ? { monitorTaskId: b.monitorTaskId } : {}) };
    },
    status(id) { return publicState(get(id)); },
    async createJob(id, config, create) {
      const b = get(id);
      const key = createHash('sha256').update(JSON.stringify(config)).digest('hex');
      if (!b.creations.has(key)) {
        if (b.creations.size >= 128) throw new Error('此浏览器连接的任务草稿已达上限，请从原会话重新打开');
        // Retain the promise even after a transport/storage failure. Never create
        // a second task because the first creation response was lost.
        const creation = Promise.resolve().then(create).then(result => { b.jobs.add(result.id); return result; });
        b.creations.set(key, creation);
      }
      return b.creations.get(key);
    },
    submit(id, taskId) {
      const b = get(id);
      if (!uuid.test(taskId) || !b.jobs.has(taskId)) throw new Error('只能提交此浏览器连接创建的任务，不允许跨会话或历史任务重放');
      const old = b.deliveries.get(taskId);
      if (old && old.status !== 'retry') return publicState(b);
      if (!connected(b)) throw new Error('原 DSH 会话页面暂未连接。请保持原页面开启并稍后重试；不会自动投递到其他会话。');
      if (store.status(taskId).status !== 'queued') throw new Error('此任务已启动，不能再次提交');
      b.deliveries.set(taskId, { status: 'pending', attempt: (old?.attempt || 0) + 1, result: null });
      return publicState(b);
    },
    poll(id, secret) {
      const b = owner(id, secret); b.lastSeen = now();
      const requests = [];
      for (const [taskId, delivery] of b.deliveries) {
        if (!['pending', 'delivering'].includes(delivery.status)) continue;
        delivery.status = 'delivering'; requests.push({ taskId, attempt: delivery.attempt });
      }
      return { sessionId: b.sessionId, requests, expiresAt: new Date(b.expiresAt).toISOString() };
    },
    settle(id, secret, taskId, result, attempt) {
      const b = owner(id, secret), delivery = b.deliveries.get(taskId);
      if (!delivery || !Number.isSafeInteger(attempt) || attempt !== delivery.attempt || delivery.status === 'pending') throw new Error('任务尚未交给原会话，不能确认投递');
      if (!result || typeof result.ok !== 'boolean' || (result.queued !== undefined && typeof result.queued !== 'boolean') || (result.uncertain !== undefined && typeof result.uncertain !== 'boolean')) throw new Error('无效的投递确认');
      if (result.ok && result.uncertain) throw new Error('投递确认不能同时成功和不确定');
      const clean = { ok: result.ok, ...(result.queued === true ? { queued: true } : {}), ...(result.uncertain === true ? { uncertain: true } : {}),
        ...(typeof result.error === 'string' ? { error: result.error.replace(/\bsk-[a-zA-Z0-9_-]{8,}/g, '[redacted]').slice(0, 1000) } : {}) };
      if (delivery.result) {
        if (JSON.stringify(delivery.result) !== JSON.stringify(clean)) throw new Error('此任务已有不同的投递确认，拒绝覆盖');
      } else {
        delivery.result = clean;
        delivery.status = clean.ok ? 'sent' : clean.uncertain ? 'uncertain' : 'retry';
      }
      return publicState(b);
    },
    dispose() { bridges.clear(); },
  };
}
