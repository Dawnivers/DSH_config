import { captureModule } from './runtime.js';
captureModule(import.meta.url);
import { existsSync, lstatSync, realpathSync } from 'node:fs';
import path from 'node:path';
import { normalizeRoutes } from './models.js';
import { normalizeReviewLevel } from './review-policy.js';
import { TASK_FEASIBILITY_SCHEMA, plannerFeasibility } from './feasibility.js';

export function relativeFile(value) {
  if (typeof value !== 'string' || !value.trim() || value !== value.trim()) throw new Error('文件名必须是非空相对路径');
  const name = value.replaceAll('\\', '/');
  if (path.posix.isAbsolute(name) || path.win32.isAbsolute(value) || /[:*?\x00-\x1f]/.test(name)) throw new Error(`禁止绝对路径、通配符或特殊文件名：${value}`);
  const parts = name.split('/');
  if (parts.some(part => !part || part === '.' || part === '..' || /[. ]$/.test(part) || /^(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)/i.test(part))) throw new Error(`禁止不规范路径：${value}`);
  if (parts.some(part => ['.git', '.dsh-orchestrator', 'node_modules'].includes(part.toLowerCase()))) throw new Error(`禁止修改内部目录：${value}`);
  return name;
}
export const pathKey = value => process.platform === 'win32' ? value.toLowerCase() : value;
export function within(root, target) {
  const rel = path.relative(root, target);
  return !path.isAbsolute(rel) && rel !== '..' && !rel.startsWith('..' + path.sep);
}
/**
 * 把可能经由「项目根自身别名」（例如 node_modules 里的 junction）表示的绝对路径，
 * 换算成真实项目根下的等价路径。
 *
 * 项目根本身是链接是合法场景：canonicalRoot 会把它解析成真实路径，此后调用方若仍用
 * 别名前缀拼文件路径（子代理、测试 fixture、宿主工具都可能这样），within() 会误判越界。
 * 这里只在「别名前缀解析后仍落在同一真实根内」时接受，根内部出现链接依旧交给
 * safeTarget 逐段拒绝——不因为这个便利而放宽项目内的链接限制。
 */
export function rebaseToRealRoot(root, target) {
  const resolvedRoot = path.resolve(root);
  if (within(resolvedRoot, target)) return target;
  // 目标可能尚不存在（新建文件），因此从最深的已存在祖先开始解析真实位置。
  let probe = path.resolve(target);
  const tail = [];
  for (;;) {
    try {
      const real = realpathSync(probe);
      const candidate = tail.length ? path.join(real, ...tail) : real;
      if (!within(resolvedRoot, candidate)) throw new Error('路径越出项目根');
      return candidate;
    } catch (error) {
      if (error.code !== 'ENOENT') throw error;
      const parent = path.dirname(probe);
      if (parent === probe) throw new Error('路径越出项目根');
      tail.unshift(path.basename(probe));
      probe = parent;
    }
  }
}
/** 禁止经过任何符号链接 / junction；最靠近目标的现有祖先也必须位于真实项目根下。 */
export function safeTarget(root, name) {
  const normalized = relativeFile(name);
  const target = path.resolve(root, normalized);
  if (!within(root, target)) throw new Error('路径越出项目根');
  let cursor = root;
  for (const part of normalized.split('/')) {
    cursor = path.join(cursor, part);
    try { if (lstatSync(cursor).isSymbolicLink()) throw new Error(`不允许符号链接或 junction：${name}`); }
    catch (error) { if (error.code === 'ENOENT') break; throw error; }
    if (!within(root, realpathSync(cursor))) throw new Error('真实路径越出项目根');
  }
  return target;
}
export function canonicalRoot(value) {
  if (typeof value !== 'string' || !path.isAbsolute(value)) throw new Error('项目根必须是绝对路径');
  const root = realpathSync(value);
  if (!lstatSync(root).isDirectory()) throw new Error('项目根不是目录');
  return root;
}
export function globMatch(name, pattern) {
  if (typeof pattern !== 'string' || !pattern || pattern.includes('\\') || pattern.startsWith('/') || pattern.split('/').some(p => p === '..' || p === '.') || /[\[\]{}!:]/.test(pattern)) throw new Error(`不支持的允许路径表达式：${pattern}`);
  const escaped = pattern.split('/').map(segment => {
    if (segment === '**') return '.*';
    if (segment.includes('**')) throw new Error('** 必须单独占一个路径段');
    return segment.replace(/[.+^$()|\\]/g, '\\$&').replaceAll('*', '[^/]*').replaceAll('?', '[^/]');
  }).join('/');
  const source = escaped.replaceAll('.*/', '(?:.*/)?');
  return new RegExp('^' + source + '$', process.platform === 'win32' ? 'i' : '').test(name);
}

/**
 * 按 consumes 依赖把任务排成可并行执行的分波（第 0 波无依赖）。
 *
 * 文件互斥只挡写冲突，挡不住「消费者读到提供者还没写的新版本」，所以执行顺序
 * 必须由依赖决定。成环或指向未知任务时抛错，绝不静默按原顺序硬跑。
 */
export function planWaves(tasks) {
  const order = new Map(tasks.map((task, index) => [task.id, index]));
  const placed = new Set();
  let pending = tasks.slice();
  const waves = [];
  while (pending.length) {
    const ready = pending.filter(task => task.consumes.every(entry => placed.has(entry.from)));
    if (!ready.length) throw new Error(`跨任务依赖成环或指向未排入的任务：${pending.map(task => task.id).join(', ')}`);
    // 同一波内按计划原顺序执行，保证同输入同输出。
    ready.sort((a, b) => order.get(a.id) - order.get(b.id));
    waves.push(ready.map(task => task.id));
    for (const task of ready) placed.add(task.id);
    pending = pending.filter(task => !placed.has(task.id));
  }
  return waves;
}

const REVIEW_MODES = ['always', 'on_failure'];
function normalizeReviewMode(value) {
  if (value === undefined || value === null || value === '') return 'always';
  const mode = String(value).trim();
  if (!REVIEW_MODES.includes(mode)) throw new Error('reviewMode 只能是 always 或 on_failure');
  return mode;
}
export function validateJob(input) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) throw new Error('任务配置必须是对象');
  const task = String(input.task || '').trim();
  if (!task || task.length > 30000) throw new Error('任务描述长度须为 1–30000');
  const projectRoot = canonicalRoot(input.projectRoot || input.adapter?.projectRoot);
  const routes = normalizeRoutes(input);
  const maxWorkers = input.maxWorkers ?? 2;
  const maxPlanRetries = input.maxPlanRetries ?? 1;
  const maxRepairRounds = input.maxRepairRounds ?? 1;
  if (!Number.isInteger(maxWorkers) || maxWorkers < 1 || maxWorkers > 6) throw new Error('worker 数须为 1–6');
  if (!Number.isInteger(maxPlanRetries) || maxPlanRetries < 0 || maxPlanRetries > 2) throw new Error('规划重试数须为 0–2');
  if (!Number.isInteger(maxRepairRounds) || maxRepairRounds < 0 || maxRepairRounds > 2) throw new Error('定向修复轮数须为 0–2');
  const allowedGlobs = input.allowedGlobs ?? input.adapter?.allowedGlobs ?? ['src/**'];
  const protectedFiles = input.protectedFiles ?? input.adapter?.protectedFiles ?? [];
  if (!Array.isArray(allowedGlobs) || !allowedGlobs.length || allowedGlobs.length > 50) throw new Error('至少填写一个允许路径，最多 50 个');
  for (const pattern of allowedGlobs) globMatch('probe', pattern);
  if (!Array.isArray(protectedFiles) || protectedFiles.length > 200) throw new Error('受保护文件列表不合法');
  const protectedNormalized = protectedFiles.map(relativeFile);
  // 断言选择只做形状校验；"这一项到底存不存在"要读断言目录，
  // 由调用方 await validateAssertionSelection() 完成（见 assertions.js）。
  const assertions = input.assertions ?? input.adapter?.assertions ?? [];
  if (!Array.isArray(assertions)) throw new Error('断言选择必须是数组');
  if (assertions.length > 100) throw new Error('断言选择最多 100 项');
  for (const item of assertions) {
    if (typeof item !== 'string' || !item.trim() || item.trim().length > 200) throw new Error('断言选择项必须是 1–200 字符的字符串');
  }
  return {
    task, projectRoot, ...routes,
    assertions: [...new Set(assertions.map((s) => s.trim()))],
    maxWorkers, maxPlanRetries, maxRepairRounds, allowedGlobs: [...allowedGlobs], protectedFiles: protectedNormalized,
    allowProtected: (input.allowProtected ?? input.adapter?.allowProtected) === true,
    // 失败/取消后是否把计划文件还原到快照状态。默认开：半改现场需要人工收拾，代价高于重跑。
    rollbackOnFailure: (input.rollbackOnFailure ?? input.adapter?.rollbackOnFailure) !== false,
    // always：worker 之后总是复核（默认，代码改动不该在没人看过的情况下交付）
    // on_failure：断言通过就放行，只有失败/警告才交 reviewer
    reviewMode: normalizeReviewMode(input.reviewMode ?? input.adapter?.reviewMode),
    reviewLevel: normalizeReviewLevel(input.reviewLevel ?? input.adapter?.reviewLevel),
    verifyHint: String(input.verifyHint ?? input.adapter?.verifyHint ?? '').slice(0, 4000),
  };
}
export const PLAN_SCHEMA = {
  type: 'object', additionalProperties: false, required: ['tasks', 'acceptance', 'status', 'blockers'], properties: {
    tasks: { type: 'array', items: { type: 'object', additionalProperties: false, required: ['id', 'files', 'goal', 'constraints', 'suggestedSteps', 'provides', 'consumes', 'feasibility'], properties: {
      feasibility: TASK_FEASIBILITY_SCHEMA,
      id: { type: 'string' }, files: { type: 'array', items: { type: 'string' } }, goal: { type: 'string' },
      constraints: { type: 'array', items: { type: 'string' } }, suggestedSteps: { type: 'array', items: { type: 'string' } },
      provides: { type: 'array', items: { type: 'object', additionalProperties: false, required: ['name', 'signature'], properties: { name: { type: 'string' }, signature: { type: 'string' } } } },
      consumes: { type: 'array', items: { type: 'object', additionalProperties: false, required: ['name', 'from', 'signature'], properties: { name: { type: 'string' }, from: { type: 'string' }, signature: { type: 'string' } } } },
    } } }, acceptance: { type: 'array', items: { type: 'string' } },
    status: { type: 'string', enum: ['ready', 'blocked'] }, blockers: { type: 'array', items: { type: 'string' } },
  },
};
export const WORKER_SCHEMA = {
  type: 'object', additionalProperties: false, required: ['status', 'summary', 'changedFiles'], properties: {
    status: { type: 'string', enum: ['completed', 'mismatch'] }, summary: { type: 'string' }, changedFiles: { type: 'array', items: { type: 'string' } },
  },
};
export function validatePlan(plan, job) {
  if (!['ready', 'blocked'].includes(plan?.status)) throw new Error('计划须明确 status=ready 或 blocked，不得将实施降级为只读');
  if (!Array.isArray(plan.blockers) || plan.blockers.some(x => typeof x !== 'string' || !x.trim())) throw new Error('计划 blockers 必须为非空说明字符串组成的数组');
  if (plan.status === 'blocked') {
    if (!Array.isArray(plan.tasks) || plan.tasks.length || !plan.blockers.length || !Array.isArray(plan.acceptance) || plan.acceptance.some(x => typeof x !== 'string' || !x.trim())) throw new Error('受阻计划须 tasks=[]、非空 blockers 和有效 acceptance 数组');
    return structuredClone(plan);
  }
  if (plan.blockers.length) throw new Error('可实施计划 blockers 必须为空；真正受阻时应返回 blocked');
  if (!Array.isArray(plan?.tasks) || !plan.tasks.length || plan.tasks.length > job.maxWorkers) throw new Error('计划任务数必须为 1 到 worker 上限');
  if (!Array.isArray(plan.acceptance) || !plan.acceptance.length || plan.acceptance.some(x => typeof x !== 'string' || !x.trim())) throw new Error('计划必须有验收条件');
  const ids = new Set();
  const files = new Set();
  const providers = new Map();
  const normalized = structuredClone(plan);
  for (const task of normalized.tasks) {
    if (!/^[a-zA-Z0-9_-]{1,50}$/.test(task.id) || ids.has(task.id)) throw new Error('任务 ID 无效或重复');
    ids.add(task.id);
    if (Object.hasOwn(task, 'instruction')) throw new Error('任务指令须拆分为 goal、constraints、suggestedSteps，不再接受 instruction');
    if (typeof task.goal !== 'string' || !task.goal.trim() || task.goal.length > 6000) throw new Error('任务 goal 必须是 1–6000 字符的实施目标');
    for (const key of ['constraints', 'suggestedSteps']) {
      if (!Array.isArray(task[key]) || task[key].length > 50 || task[key].some(value => typeof value !== 'string' || !value.trim() || value.length > 4000)) throw new Error(`任务 ${key} 须为最多 50 条非空说明的数组`);
    }
    if (task.goal.length + [...task.constraints, ...task.suggestedSteps].reduce((size, value) => size + value.length, 0) > 20000) throw new Error('任务分层指令总长度不能超过 20000 字符');
    if (!Array.isArray(task.files) || !task.files.length || task.files.length > 100) throw new Error('每个任务须分配 1–100 个文件');
    task.files = task.files.map(relativeFile);
    for (const file of task.files) {
      const key = pathKey(safeTarget(job.projectRoot, file));
      if (files.has(key)) throw new Error(`文件重复分配：${file}`);
      for (const existing of files) if (within(existing, key) || within(key, existing)) throw new Error(`文件路径互相包含：${file}`);
      files.add(key);
      if (!job.allowedGlobs.some(g => globMatch(file, g))) throw new Error(`文件不在允许范围：${file}`);
      if (!job.allowProtected && job.protectedFiles.some(p => pathKey(p) === pathKey(file))) throw new Error(`受保护文件：${file}`);
      if (existsSync(key) && !lstatSync(key).isFile()) throw new Error(`分配目标不是文件：${file}`);
    }
    if (!Array.isArray(task.provides) || !Array.isArray(task.consumes)) throw new Error('任务缺少接口声明数组');
    for (const entry of task.provides) {
      if (!entry.name?.trim() || !entry.signature?.trim() || providers.has(entry.name)) throw new Error('接口提供方无效或重复');
      providers.set(entry.name, { from: task.id, signature: entry.signature });
    }
  }
  for (const task of normalized.tasks) for (const entry of task.consumes) {
    const provided = providers.get(entry.name);
    if (!provided || provided.from !== entry.from || provided.signature !== entry.signature || entry.from === task.id) throw new Error(`接口不闭合或签名不匹配：${task.id}/${entry.name}`);
  }
  // 契约闭合还不够：依赖必须能排出执行顺序，成环时拒绝计划而不是并发硬跑。
  planWaves(normalized.tasks);
  plannerFeasibility(normalized);
  return normalized;
}
