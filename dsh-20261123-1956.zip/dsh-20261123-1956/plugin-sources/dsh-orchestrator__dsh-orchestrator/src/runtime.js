import { createHash } from 'node:crypto';
import { readFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

// Capture at module evaluation, NOT when a settings request arrives. A cached old
// runner must keep its old hash even if the source file has since been edited.
export function createRuntimeTracker(root) {
  const loaded = new Map();
  const loadedAt = new Date().toISOString();
  const hash = file => createHash('sha256').update(readFileSync(file)).digest('hex');
  const build = records => createHash('sha256').update(JSON.stringify(records)).digest('hex').slice(0, 20);
  function capture(url, features = {}) {
    const file = fileURLToPath(url);
    const name = path.relative(root, file).replaceAll('\\', '/');
    loaded.set(name, { file, name, loadedHash: hash(file), features: { ...features } });
  }
  function identity() {
    const modules = [...loaded.values()].sort((a, b) => a.name.localeCompare(b.name)).map(item => {
      let diskHash = null;
      try { diskHash = hash(item.file); } catch { /* Missing/unreadable source is not a match. */ }
      return { name: item.name, loadedHash: item.loadedHash, diskHash, matches: item.loadedHash === diskHash };
    });
    const runner = loaded.get('src/runner.js');
    return {
      buildId: build(modules.map(m => [m.name, m.loadedHash])),
      diskBuildId: build(modules.map(m => [m.name, m.diskHash])),
      loadedAt, pid: process.pid, moduleRoot: root,
      sourceMatches: modules.length > 0 && modules.every(m => m.matches),
      staleModules: modules.filter(m => !m.matches).map(m => m.name),
      features: { ...(runner?.features || {}) }, modules,
    };
  }
  return { capture, identity };
}

const tracker = createRuntimeTracker(fileURLToPath(new URL('../', import.meta.url)));
export const captureModule = tracker.capture;
export const runtimeIdentity = tracker.identity;
captureModule(import.meta.url);
captureModule(new URL('../package.json', import.meta.url));

export function assertRuntimeCurrent() {
  const runtime = runtimeIdentity();
  if (!runtime.sourceMatches) {
    throw new Error(`编排插件已加载代码与磁盘不一致（${runtime.staleModules.join(', ')}）；请完整退出宿主后重新启动，再检查运行时标识。尚未启动模型调用。`);
  }
  return runtime;
}
