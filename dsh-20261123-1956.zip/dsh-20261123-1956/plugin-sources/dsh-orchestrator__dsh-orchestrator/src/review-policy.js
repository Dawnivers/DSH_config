import { captureModule } from './runtime.js';
captureModule(import.meta.url);

export const REVIEW_LEVELS = ['exploratory', 'standard', 'strict'];

export function normalizeReviewLevel(value) {
  if (value === undefined || value === null || value === '') return 'standard';
  if (typeof value !== 'string' || !REVIEW_LEVELS.includes(value.trim())) {
    throw new Error('reviewLevel 只能是 exploratory、standard 或 strict');
  }
  return value.trim();
}

// 验收范围与模型 effort 是两个独立维度；档位不能放宽文件/接口/权限边界。
export function reviewPolicy(job) {
  const level = normalizeReviewLevel(job.reviewLevel ?? job.adapter?.reviewLevel);
  return {
    level,
    modelReview: level !== 'exploratory',
    assertionBypass: level === 'standard' && job.reviewMode === 'on_failure',
    autoRepair: level !== 'exploratory',
    // 当前宿主编排仅运行选定的数据断言；运行时冒烟仍由主会话执行。
    runtimeVerified: false,
  };
}
