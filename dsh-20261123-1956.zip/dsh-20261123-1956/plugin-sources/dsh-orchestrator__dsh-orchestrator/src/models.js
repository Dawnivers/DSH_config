import { captureModule } from './runtime.js';
captureModule(import.meta.url);
import { normalizeReviewLevel, reviewPolicy } from './review-policy.js';
export const MODEL_ROLES = ['planner', 'worker', 'feasibility', 'reviewer'];
const owns = (value, key) => Object.hasOwn(value, key);

/** Only an absent feasibility/reviewer inherits the planner route. Invalid explicit routes never fall back. */
export function normalizeRoutes(input) {
  function role(key, legacy, fallback) {
    const hasLegacy = [legacy + 'Provider', legacy + 'Model', key + 'Effort'].some(name => owns(input, name));
    const candidate = owns(input, key) ? input[key] : hasLegacy
      ? { provider: input[legacy + 'Provider'], model: input[legacy + 'Model'], effort: input[key + 'Effort'] } : fallback;
    if (!candidate || typeof candidate !== 'object' || Array.isArray(candidate)) throw new Error(`${key} 必须指定 provider 和 model`);
    const provider = typeof candidate.provider === 'string' ? candidate.provider.trim() : '';
    const model = typeof candidate.model === 'string' ? candidate.model.trim() : '';
    if (!provider || !model || provider.length > 200 || model.length > 300 || /[\x00-\x1f]/.test(provider + model)) throw new Error(`${key} 必须指定 provider 和 model`);
    if (candidate.effort != null && typeof candidate.effort !== 'string') throw new Error(`${key} 档位必须是字符串`);
    const effort = candidate.effort == null ? '' : candidate.effort.trim();
    if (effort.length > 80 || /[\x00-\x1f]/.test(effort)) throw new Error(`${key} 档位无效`);
    return { provider, model, ...(effort ? { effort } : {}) };
  }
  const planner = role('planner', 'strong');
  // 写入前复核默认沿用 planner：判断力比吞吐重要，且与执行模型解耦后才有「第二双眼」。
  return {
    planner,
    worker: role('worker', 'cheap'),
    feasibility: role('feasibility', 'feasibility', planner),
    reviewer: role('reviewer', 'reviewer', planner),
  };
}

export const agentOptions = route => ({ provider: route.provider, model: route.model, ...(route.effort ? { reasoningEffort: route.effort } : {}) });

export async function validateModelRoute(ctx, role, route, signal) {
  try {
    const options = agentOptions(route);
    const resolved = await ctx.llm.resolveCallConfig(options, signal);
    if (resolved.provider !== options.provider || resolved.model !== options.model || (options.reasoningEffort !== undefined && resolved.reasoningEffort !== options.reasoningEffort)) throw new Error('宿主解析改变了显式模型路由或档位，拒绝继续');
    return options;
  } catch (error) {
    if (signal?.aborted) signal.throwIfAborted();
    throw new Error(`${role} 模型配置不可用（${route.provider}/${route.model}）：${error.message}`, { cause: error });
  }
}
export async function validateModelRoutes(ctx, job, signal) {
  const policy = reviewPolicy(job);
  for (const role of MODEL_ROLES) {
    // 探索档从不调用 reviewer：已停用路由的目录/effort 不可用不应阻塞实施。
    if (role === 'reviewer' && !policy.modelReview) continue;
    await validateModelRoute(ctx, role, job[role], signal);
  }
}

export async function modelEntry(ctx, provider, model, label) {
  if (typeof provider !== 'string' || !provider.trim() || typeof model !== 'string' || !model.trim() || provider.length > 200 || model.length > 300 || /[\x00-\x1f]/.test(provider + model)) throw new Error('必须提供有效 provider 和 model');
  provider = provider.trim(); model = model.trim();
  const info = await ctx.llm.resolveModelInfo(provider, model);
  if (info.provider !== provider || info.id !== model) throw new Error('宿主返回的模型身份与请求不一致');
  return { provider, model, label: label || `${provider} · ${info.name || model}`,
    efforts: (info.reasoning?.efforts || []).map(entry => ({ id: entry.id, name: entry.name || entry.id })),
    ...(info.reasoning?.defaultEffort ? { defaultEffort: info.reasoning.defaultEffort } : {}),
  };
}
export async function models(ctx) {
  const catalog = [], warnings = [];
  await Promise.all(ctx.llm.listProviders().map(async provider => {
    let candidates;
    try { candidates = await ctx.llm.listModels(provider.id); }
    catch { warnings.push(`${provider.id} 的模型清单暂不可用，可刷新重试或手填模型并校验能力`); return; }
    for (const model of candidates) {
      try { catalog.push(await modelEntry(ctx, provider.id, model.id, `${provider.displayName || provider.name || provider.id} · ${model.name || model.id}`)); }
      catch { warnings.push(`${provider.id}/${model.id} 的能力暂不可用；其他模型仍可选择`); }
    }
  }));
  return { catalog: catalog.sort((a, b) => a.provider.localeCompare(b.provider) || a.model.localeCompare(b.model)), warnings };
}

export function defaultConfig(catalog, saved = {}) {
  const choose = family => {
    const candidate = catalog.find(item => family.test(item.model)) || catalog[0];
    // Do not invent or transfer an effort across families. Omission keeps the host's default semantics.
    return candidate ? { provider: candidate.provider, model: candidate.model } : { provider: '', model: '' };
  };
  const hasOldRoute = (key, legacy) => owns(saved, key) || owns(saved, legacy + 'Provider') || owns(saved, legacy + 'Model') || owns(saved, key + 'Effort');
  const oldRoute = (key, legacy) => owns(saved, key) ? saved[key] : { provider: saved[legacy + 'Provider'], model: saved[legacy + 'Model'], ...(saved[key + 'Effort'] ? { effort: saved[key + 'Effort'] } : {}) };
  const planner = hasOldRoute('planner', 'strong') ? oldRoute('planner', 'strong') : choose(/claude/i);
  const worker = hasOldRoute('worker', 'cheap') ? oldRoute('worker', 'cheap') : choose(/deepseek|qwen|claude/i);
  // 写入前复核与 reviewer 一样：没有显式配置时跟随 planner，而不是悄悄退回执行模型。
  const feasibility = hasOldRoute('feasibility', 'feasibility') ? oldRoute('feasibility', 'feasibility')
    : hasOldRoute('planner', 'strong') ? { ...planner } : choose(/claude/i);
  const reviewer = hasOldRoute('reviewer', 'reviewer') ? oldRoute('reviewer', 'reviewer')
    : hasOldRoute('planner', 'strong') ? { ...planner } : choose(/(?:^|[/_.-])gpt(?:[-_.]|\d)/i);
  return { maxWorkers: 2, maxPlanRetries: 1, allowedGlobs: ['src/**'], protectedFiles: [], allowProtected: false, verifyHint: '', assertions: [], ...saved, reviewLevel: normalizeReviewLevel(saved.reviewLevel ?? saved.adapter?.reviewLevel), planner, worker, feasibility, reviewer };
}
