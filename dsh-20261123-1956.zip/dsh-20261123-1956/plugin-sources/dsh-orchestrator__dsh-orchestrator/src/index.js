import { captureModule } from './runtime.js';
captureModule(import.meta.url);
import { makeStore } from './store.js';
import { createBindings } from './bindings.js';
import { createRunner, compatibility } from './runner.js';
import { createSettings } from './settings.js';
import { validateModelRoutes } from './models.js';

export const name = 'dsh-orchestrator';
export const inject = ['tools', 'subagents', 'llm'];
const output = { schema: { type: 'json' }, render(_args, result) { return [{ type: 'text', text: JSON.stringify(result, null, 2) }]; } };
const routeConfig = { type: 'object', additionalProperties: true, properties: {
  provider: { type: 'string', required: true }, model: { type: 'string', required: true }, effort: { type: 'string' },
} };
const taskConfig = { type: 'object', additionalProperties: true,
  description: 'Task configuration as a JSON object. Do not stringify it or pass JSON text. Legacy flat route and adapter fields remain supported.',
  properties: {
    task: { type: 'string', required: true }, projectRoot: { type: 'string' },
    planner: routeConfig, worker: routeConfig, feasibility: routeConfig, reviewer: routeConfig,
    maxWorkers: { type: 'integer' }, maxPlanRetries: { type: 'integer' }, maxRepairRounds: { type: 'integer' },
    allowedGlobs: { type: 'array', items: { type: 'string' } },
    protectedFiles: { type: 'array', items: { type: 'string' } },
    allowProtected: { type: 'boolean' }, verifyHint: { type: 'string' },
    assertions: { type: 'array', items: { type: 'string' }, description: 'Enabled data assertions. Accepts a pack (geo.vector), a group (geo.vector/geojson) or a check id (geom.ring.closed). Rendered into acceptance as a command the main session must run; not executed by workers.' },
    reviewLevel: { type: 'string', enum: ['exploratory', 'standard', 'strict'], description: 'Acceptance scope, independent of model effort. exploratory: no model review or automatic repair; selected assertions still run and must pass, runtime remains unverified. standard (default): existing reviewMode policy. strict: always review with expanded static edge-case and regression scrutiny; never skip on assertion success. No level runs shell builds or runtime smoke tests.' },
    reviewMode: { type: 'string', enum: ['always', 'on_failure'], description: 'Applies only to standard reviewLevel. always (default): independent review after workers. on_failure: skip review only when selected data assertions actually ran and passed. Exploration skips model review explicitly; strict always reviews.' },
    rollbackOnFailure: { type: 'boolean', description: 'Restore the planned files to their snapshot when the run fails or is cancelled. Defaults to true.' },
  },
};

export function toolSpecs(ctx, store, runner, getSettings) {
  return [
    {
      name: 'orchestrate_settings',
      description: 'Get the local visual configuration page for multi-model coding orchestration. Configure independent planner/worker/reviewer models and effort, save uniquely identified tasks. Does not start model requests.',
      parameters: {}, output, isConcurrencySafe: () => true,
      async execute() {
        const settings = getSettings();
        return { available: !!settings, ...(settings ? { url: settings.url } : {}), compatibility: compatibility(ctx), storagePath: store.root, text: settings ? '打开此链接配置并生成任务。把生成的任务 ID 交给 orchestrate_run 即可在当前会话执行。' : '当前宿主未提供 Web 服务；可使用 orchestrate_task 创建任务。' };
      },
    },
    {
      name: 'orchestrate_task',
      description: 'Create an immutable coding-orchestration task or inspect a saved task by ID. Input may use independent planner/worker/reviewer routes or legacy strongProvider/strongModel/cheapProvider/cheapModel plus reviewerProvider/reviewerModel and per-role effort fields. Missing reviewer inherits the legacy planner route; invalid explicit reviewer never falls back. Creating does not run agents.',
      parameters: { action: { type: 'string', enum: ['create', 'get', 'list'], required: true }, task_id: { type: 'string' }, config: taskConfig },
      output, isConcurrencySafe: () => true,
      async execute(args) {
        if (args.action === 'list') return { tasks: store.list().slice(0, 100) };
        if (args.action === 'get') return { job: { ...store.get(args.task_id), ...store.status(args.task_id) }, runs: store.runs(args.task_id) };
        const { validateJob } = await import('./policy.js');
        const { validateAssertionSelection } = await import('./assertions.js');
        const config = validateJob(args.config);
        await validateModelRoutes(ctx, config);
        // 断言选择在创建时就要对上目录：选了不存在的断言必须当场报错，
        // 不能等到运行才发现"以为启用了，其实没跑"。
        config.assertions = (await validateAssertionSelection(config.assertions)).selection;
        const job = store.create(config);
        return { job, instruction: `使用 orchestrate_run 执行任务 ${job.id}` };
      },
    },
    {
      name: 'orchestrate_run',
      description: 'Execute a saved orchestration task ID: planner separates goals, mandatory constraints and advisory steps; host validates disjoint file assignments and declared interface signatures. Planner includes per-task source evidence and feasibility status in the plan. A single task without cross-task dependencies skips the extra session; multiple tasks or cross-task dependencies require one independent read-only feasibility check on its own route (defaults to the planner route) before backups and writers; if that session itself fails, the run degrades to the planner self-check and records feasibilityDegraded instead of failing. Workers run in dependency waves derived from consumes, so consumers wait for providers; one failed task only skips its downstream tasks and its own files are rolled back, while siblings keep their work. Review runs on the independent reviewer route (legacy jobs without reviewer inherit planner); when it reports issues_found and maxRepairRounds > 0, the planner is asked for a targeted repair plan with the evidence, that repair is executed and reviewed once. Only active model routes and explicit efforts are validated before planning; no model fallback. reviewLevel=exploratory skips reviewer and automatic repair, still runs selected assertions, and reports runtime-unverified needs_validation (or blocked if selected assertions do not pass). standard preserves reviewMode; strict always reviews with expanded relevant static scrutiny. Ambiguity, blockers or a non-ready conclusion from the independent check return report.status=blocked with evidence and nextAction.questions before any implementation; no automatic clarification loop. Each role uses its configured reasoning effort. Empty/unprepared projects stop before model calls. Does not run shell builds/tests. Use only when the user requested this coding task. Foreground by default; background uses job_output/job_kill. plan_only retains planner self-check evidence but skips independent feasibility and implementation.',
      parameters: { task_id: { type: 'string', required: true }, plan_only: { type: 'boolean' }, run_in_background: { type: 'boolean' } },
      output, isConcurrencySafe: () => false,
      async execute(args, exec) {
        if (!exec.agent) throw new Error('编排必须从 DSH 会话调用，才能绑定执行会话和子代理');
        if (args.run_in_background) {
          const jobs = ctx.get?.('jobs');
          if (!jobs) throw new Error('当前宿主没有 jobs 服务，请以前台模式启动');
          let runId;
          const jobId = jobs.start({
            kind: 'orchestration', label: `编排 ${args.task_id}`, owner: exec.agent.session.id,
            run(handle) {
              const controller = new AbortController();
              const run = runner.run(args.task_id, exec.agent, controller.signal, (stage, message) => {
                handle.updateProgress(stage);
                handle.append(`${message}\n`, { channel: 'log' });
              }, { planOnly: args.plan_only });
              runId = run.id;
              return {
                cancel(reason) { controller.abort(reason || '后台任务已取消'); },
                done: run.result.then(report => ({
                  status: report.status === 'cancelled' ? 'killed' : ['planned', 'needs_validation'].includes(report.status) ? 'completed' : 'failed',
                  ...(report.error ? { detail: report.error } : {}), result: JSON.stringify(report),
                })).catch(error => ({ status: 'failed', detail: String(error.message) })),
              };
            },
          });
          return { kind: 'background', jobId, runId, taskId: args.task_id, text: '使用 job_output 查看执行结果，使用 job_kill 取消。' };
        }
        const run = runner.run(args.task_id, exec.agent, exec.signal, undefined, { planOnly: args.plan_only });
        return { kind: 'foreground', report: await run.result };
      },
    },
  ];
}

export async function apply(ctx, config = {}) {
  // 注册不做模型请求，不改全局默认，不替换 workflowEngine。
  const { defineTool } = await import('@deepseek-ai/dsh-tools');
  const store = makeStore(config.storageDir);
  const check = compatibility(ctx);
  const disposers = [];
  let bindings;
  let runner;
  let settings;
  if (typeof ctx.tools.guard === 'function') {
    bindings = createBindings(ctx);
    runner = createRunner(ctx, store, bindings);
  } else {
    runner = { run() { throw new Error(check.issues.join('；')); }, dispose() {} };
  }
  for (const spec of toolSpecs(ctx, store, runner, () => settings)) disposers.push(ctx.tools.register(defineTool(spec)));
  const attach = settingsCtx => {
    let localSettings;
    try { localSettings = createSettings(settingsCtx, store); settings = localSettings; }
    catch (error) { ctx.logger.warn('orchestrator settings unavailable: ' + String(error.message)); }
    return () => { localSettings?.dispose(); if (settings === localSettings) settings = undefined; };
  };
  if (typeof ctx.inject === 'function') {
    const fiber = ctx.inject(['webServer'], attach);
    disposers.push(typeof fiber === 'function' ? fiber : () => fiber?.dispose?.());
  } else disposers.push(attach(ctx));
  return async () => {
    // 先撤回入口并取消运行，待所有持有的 child 静止后才撤销 guard。
    for (const dispose of disposers.reverse()) if (typeof dispose === 'function') dispose();
    settings?.dispose();
    await runner.dispose();
    await bindings?.dispose();
  };
}
