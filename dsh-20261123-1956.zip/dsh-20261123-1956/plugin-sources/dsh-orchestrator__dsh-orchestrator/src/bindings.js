import { captureModule } from './runtime.js';
captureModule(import.meta.url);
import { AsyncLocalStorage } from 'node:async_hooks';
import { isAbsolute, relative } from 'node:path';
import { safeTarget, within, pathKey, rebaseToRealRoot } from './policy.js';

/** ALS + awaited agent/created: binds exact ownership before any child request. */
export function createBindings(ctx) {
  const launching = new AsyncLocalStorage();
  const bound = new WeakMap();
  const active = new Set();
  const pending = new Set();
  let closing = false;
  const offCreated = ctx.on('agent/created', ({ agent }) => {
    const launch = launching.getStore();
    if (!launch || launch.bound) return;
    if (agent.session.header.origin !== 'subagent' || agent.session.header.parentSession !== launch.parent.session.id) return;
    const registry = agent.ctx?.agents || ctx.get?.('agents');
    if (typeof registry?.isOwnedBy !== 'function' || !registry.isOwnedBy(agent.id, launch.parent)) throw new Error('无法确认编排子代理归属');
    const policy = { ...launch.policy, writes: new Set(), calls: 0, closed: false, agentId: agent.session.id };
    bound.set(agent, policy);
    if (typeof agent.ctx?.tools?.guard !== 'function') throw new Error('子代理缺少作用域权限 guard');
    agent.ctx.tools.guard(checkExecution);
    launch.bound = agent;
    launch.onBind?.(agent, policy);
    // 不返回值，避免中断宿主 serial listener 链。
  }, { global: true, prepend: true });
  function checkExecution(exec) {
    const policy = exec.agent && bound.get(exec.agent);
    if (!policy) {
      const launch = launching.getStore();
      if (launch && exec.agent?.session.header.origin === 'subagent' && exec.agent.session.header.parentSession === launch.parent.session.id) return '编排子代理权限未在创建阶段绑定，禁止执行工具';
      return;
    }
    if (policy.closed) return '编排任务权限已关闭';
    const readTools = new Set(['read', 'glob', 'grep']);
    const writeTools = new Set(['write', 'edit']);
    if (exec.name === 'run_code' || exec.name === 'structured_output') return;
    if (!readTools.has(exec.name) && !writeTools.has(exec.name)) return `编排子代理禁止调用 ${exec.name}`;
    if (writeTools.has(exec.name) && policy.role !== 'worker') return '规划 / 复核代理只允许读取';
    // 只读会话的工具预算：spawn provider 没有 maxSteps 能力，这里按工具调用数封顶。
    // 实测可行性会话用 21–26 次，40 次留足正常余量，只用于阻断失控循环。
    // 同一个 exec 只计一次，避免 guard 在多处注册时重复扣预算。
    if (policy.budget != null) {
      policy.counted ||= new WeakSet();
      if (!policy.counted.has(exec)) {
        policy.counted.add(exec);
        if (++policy.calls > policy.budget) return `编排${policy.role}只读会话工具调用超过上限 ${policy.budget} 次，已停止；请直接给出结论或在结论中说明证据不足`;
      }
    }
    try {
      const args = exec.arguments;
      const rawPath = (exec.name === 'glob' || exec.name === 'grep') ? args?.path : args?.file_path;
      if (typeof rawPath !== 'string' || !isAbsolute(rawPath)) throw new Error('编排工具必须显式使用项目内绝对路径');
      // 项目根可能被以 junction 别名传入（宿主 cwd、子代理拼路径等）。先归一到真实根下的
      // 等价路径；根内部的符号链接仍由 safeTarget 逐段拒绝，不因此放宽。
      const inputPath = rebaseToRealRoot(policy.root, rawPath);
      if (!within(policy.root, inputPath)) throw new Error('路径越出项目根');
      const rel = relative(policy.root, inputPath).replaceAll('\\', '/');
      const target = rel ? safeTarget(policy.root, rel) : policy.root;
      if (writeTools.has(exec.name)) {
        if (!policy.allow.has(pathKey(target))) throw new Error('文件不属于此 worker');
        policy.writes.add(rel);
      }
      if (!rel && (exec.name === 'read' || writeTools.has(exec.name))) throw new Error('此工具不能操作项目根目录本身');
    } catch (error) { return `编排文件权限拒绝：${error.message}`; }
  }
  const offGuard = ctx.tools.guard(checkExecution);
  return {
    async start(request, policy, onBind) {
      if (closing) throw new Error('编排权限服务正在停止');
      const launch = { parent: request.parent, policy, bound: null, onBind };
      let run;
      let release;
      const completion = new Promise(resolve => { release = resolve; });
      pending.add(completion);
      try {
        run = await launching.run(launch, () => ctx.subagents.start('spawn', request));
        if (closing) { await run.dispose(); throw new Error('编排权限服务已停止'); }
        if (!launch.bound || run.localAgent !== launch.bound || run.id !== launch.bound.session.id) {
          await run.dispose();
          throw new Error('当前 DSH 未在子代理创建阶段绑定权限；已停止，不继续执行');
        }
        const rule = bound.get(launch.bound);
        const holder = { run, rule };
        active.add(holder);
        return {
          ...run,
          policy: rule,
          async dispose() {
            try { await run.dispose(); }
            finally { rule.closed = true; active.delete(holder); }
          },
        };
      } catch (error) {
        if (launch.bound) bound.get(launch.bound).closed = true;
        throw error;
      } finally { pending.delete(completion); release(); }
    },
    async dispose() {
      closing = true;
      await Promise.allSettled([...pending]);
      const settled = await Promise.allSettled([...active].map(async ({ run, rule }) => {
        try { await run.dispose(); } finally { rule.closed = true; }
      }));
      offGuard?.(); offCreated?.();
      const failures = settled.filter(item => item.status === 'rejected');
      if (failures.length) throw new AggregateError(failures.map(item => item.reason), '编排子代理清理失败');
    },
  };
}
