/**
 * index.js —— M1 探针。**只观察，不拦截。**
 *
 * 目的只有一个：搞清楚「子代理写文件时，能不能区分出它是谁」。
 * 这个问题决定后面能不能做 per-worker 文件白名单。
 *
 * 为什么这样接：
 *  - `inject: ['fs']` —— fs 是每次会话都必然存在的服务。
 *    **绝不能 inject 'sandboxPolicy'**：cordis 的 inject 是硬前缀，服务缺失时
 *    apply 根本不会被调用，插件会永远停在"加载中"，而且日志里什么都没有。
 *    （这条来自你自己 dsh-video-storyboard 的 README 教训。）
 *  - 所以 sandboxPolicy 走**运行期探测** `ctx.get('sandboxPolicy')`，拿不到也无所谓。
 *
 * 记录位置：%USERPROFILE%\.dsh\fs-probe.log（一行一条 JSON，方便 grep）
 * 控制台也打一份，方便你直接看宿主 stdout。
 */
import { appendFileSync, mkdirSync } from "node:fs";
import { homedir } from "node:os";
import { join } from "node:path";

export const name = "dsh-fs-probe";

// 只声明必然存在的服务；sandboxPolicy 运行期再说
export const inject = ["fs"];

// 日志文件：放在 .dsh 下，跟其他运行态文件同级
const LOG_DIR = join(homedir(), ".dsh");
const LOG_FILE = join(LOG_DIR, "fs-probe.log");

function record(kind, payload) {
  const line = JSON.stringify({ t: new Date().toISOString(), kind, ...payload });
  try {
    mkdirSync(LOG_DIR, { recursive: true });
    appendFileSync(LOG_FILE, line + "\n", "utf8");
  } catch {
    /* 探针绝不能因为写日志失败而影响主流程 */
  }
  // 控制台副本：宿主 stdout 能看到就顺手看一眼
  console.log("[fs-probe]", line);
}

/** 把 target 描述成能看懂的样子，不 dump 二进制内容 */
function describeTarget(target) {
  if (target === null || target === undefined) return { target: String(target) };
  // 工具层传进来的是 ctx.fs.resolve() 的结果；沙箱后端用的是 displayPath
  const displayPath = target.displayPath ?? target.path ?? target.realPath ?? target.id;
  return {
    targetType: typeof target,
    displayPath: typeof displayPath === "string" ? displayPath : undefined,
    targetKeys: typeof target === "object" ? Object.keys(target).slice(0, 12) : undefined,
  };
}

/** 策略对象里有什么：这是"身份能不能传下来"的关键线索 */
function describePolicy(policy) {
  if (!policy || typeof policy !== "object") return { policy: String(policy) };
  return {
    policyKeys: Object.keys(policy).slice(0, 12),
    mode: policy.mode,
    workspaceRoot: policy.workspaceRoot,
    // 身份：M2 的 claim 表就是按这个 key 查的
    sessionId: policy.sessionId,
  };
}

/** session 对象的形状：我们要找的是"子代理有没有独立 id" */
function describeSession(opts) {
  const session = opts && typeof opts === "object" ? opts.session : undefined;
  if (!session || typeof session !== "object") return { session: String(session) };
  return {
    sessionKeys: Object.keys(session).slice(0, 16),
    sessionId: session.id ?? session.sessionId ?? session.key,
    sessionKind: session.kind ?? session.type,
  };
}

export function apply(ctx) {
  const fs = ctx.fs;
  const restores = [];

  // ---- 探针 1：所有写操作（writeText / editText）----
  // 这两个方法是 dsh-fs-sandbox 覆写的那两个，也是工具层唯一能改文件的两个入口
  for (const method of ["writeText", "editText"]) {
    const original = fs[method];
    if (typeof original !== "function") {
      record("skip", { method, reason: "not a function on ctx.fs" });
      continue;
    }

    fs[method] = function probed(target, content, expected, signal, policy) {
      try {
        record("mutation", {
          method,
          ...describeTarget(target),
          ...describePolicy(policy),
          contentBytes: typeof content === "string" ? content.length : undefined,
          hasExpected: expected !== undefined,
        });
      } catch {
        /* 记录失败不影响调用 */
      }
      // 关键：原样委托，一个字节都不改
      return original.call(this, target, content, expected, signal, policy);
    };

    restores.push(() => {
      fs[method] = original;
    });
  }

  // ---- 探针 2：策略解析（运行期探测，缺了也不影响加载）----
  // 工具层每次写之前都会调用 sandboxPolicy.resolve({ session })，
  // 这里能看到 session —— 子代理是否独立，就看这里的 id 变不变
  const policy = ctx.get("sandboxPolicy");
  if (policy && typeof policy.resolve === "function") {
    const originalResolve = policy.resolve;

    policy.resolve = function probedResolve(opts) {
      try {
        record("policy", describeSession(opts));
      } catch {
        /* 同上 */
      }
      return originalResolve.call(this, opts);
    };

    restores.push(() => {
      policy.resolve = originalResolve;
    });

    record("mounted", { sandboxPolicy: "wrapped" });
  } else {
    record("mounted", { sandboxPolicy: "absent (fs 层探针仍然工作)" });
  }

  // 返回 disposer：卸载时把两个方法都还原，别留副作用
  return () => {
    for (const restore of restores) {
      try {
        restore();
      } catch {
        /* 卸载失败也不该炸 */
      }
    }
  };
}
