/**
 * index.js —— M3 强制层（带 pending 认领）。
 *
 * 判定顺序：
 *   1. claim 表没启用 → 放行
 *   2. session 已在 workers 里 → 按它的 allow 判
 *   3. session 未登记，但 pending 里有条目能覆盖这个路径 → **认领**，然后放行
 *   4. session 未登记且 pending 匹配不到：
 *        - claims.strictUnbound === true 且是子代理（sessionId 不以 "session-" 开头）→ 拒绝
 *        - 否则放行
 *
 * 第 3 步是让 workflow 脚本免于知道 sessionId 的关键：编排方只声明计划
 * （"w1 该写 koi.js"），谁先写到那个路径谁就领走这条 claim。
 *
 * 拦什么：ctx.fs 的 write / edit。
 * 不拦什么：读、列目录、pwsh/bash —— shell 是另一个口子（M4 要收工具集）。
 */
import { appendFileSync, mkdirSync } from "node:fs";
import { homedir } from "node:os";
import { join } from "node:path";
import { CLAIMS_PATH, bindPending, decide, loadClaims } from "./claims.js";

export const name = "dsh-fs-claims";
export const inject = ["fs"];

const LOG_DIR = join(homedir(), ".dsh");
const LOG_FILE = join(LOG_DIR, "fs-claims.log");

function record(payload) {
  const line = JSON.stringify({ t: new Date().toISOString(), ...payload });
  try {
    mkdirSync(LOG_DIR, { recursive: true });
    appendFileSync(LOG_FILE, line + "\n", "utf8");
  } catch {
    /* 记日志失败不能影响判定 */
  }
  console.log("[fs-claims]", line);
}

function pathOf(target) {
  if (target === null || target === undefined) return undefined;
  if (typeof target === "string") return target;
  return target.displayPath ?? target.path ?? target.targetKey;
}

/** 主会话 id 以 "session-" 开头；子代理是裸 UUID。这个启发式用来避免锁死编排者自己。 */
function isWorkerSession(sessionId) {
  return typeof sessionId === "string" && sessionId.length > 0 && !sessionId.startsWith("session-");
}

function deny(displayPath, sessionId, reason) {
  const err = new Error(
    `[sandbox: file access denied under claims mode] ${displayPath ?? "(unknown path)"} ` +
      `— session ${sessionId ?? "(none)"} 无权写该路径（reason: ${reason}）。` +
      `如需放行，编辑 ${CLAIMS_PATH} 里该 session 的 allow 列表，或把它加进 pending。`
  );
  err.code = "FS_SANDBOX_DENIED";
  return err;
}

export function apply(ctx) {
  const fs = ctx.fs;
  const restores = [];

  for (const method of ["writeText", "editText"]) {
    const original = fs[method];
    if (typeof original !== "function") {
      record({ kind: "skip", method, reason: "not a function on ctx.fs" });
      continue;
    }

    fs[method] = async function claimed(target, content, expected, signal, policy) {
      const sessionId = policy && policy.sessionId;
      const displayPath = pathOf(target);

      let verdict;
      try {
        const claims = loadClaims();
        verdict = decide(claims, sessionId, displayPath);

        // 未登记 → 先试认领，再判 strictUnbound。
        // 注意：strictUnbound 的检查**不能**放在 "pending 非空" 的条件里 ——
        // pending 被前面几个 worker 领完变空后，后来的越界写会绕过检查（实测踩过）。
        if (verdict.allow && verdict.unlisted) {
          let bound = null;
          if (claims && Array.isArray(claims.pending) && claims.pending.length) {
            bound = await bindPending(sessionId, displayPath);
          }
          if (bound) {
            verdict = { allow: true, reason: "bound-pending", boundId: bound.id, rule: bound.matchedRule };
            record({ kind: "bind", sessionId, displayPath, boundId: bound.id, rule: bound.matchedRule });
          } else if (claims && claims.strictUnbound === true && isWorkerSession(sessionId)) {
            verdict = { allow: false, reason: "unbound-no-pending-match" };
          }
        }
      } catch {
        // 判定本身出错 → 放行（fail-open）。宁可漏拦，也不要因为插件 bug 让所有写入失败。
        verdict = { allow: true, reason: "decision-error" };
      }

      record({ kind: "decision", method, sessionId, displayPath, ...verdict });

      if (!verdict.allow) throw deny(displayPath, sessionId, verdict.reason);

      return original.call(this, target, content, expected, signal, policy);
    };

    restores.push(() => {
      fs[method] = original;
    });
  }

  // ---- M4：拦掉 worker 的 shell ----
  // 为什么必须在这里拦：pwsh/bash 写文件不经过 ctx.fs，fs 围栏管不到。
  // 用 tools/pre-execute 这个逐调用 waterfall（dsh-tools/lib/index.js:3225），
  // exec 里带 agent，agent.session 就是已验证的 sessionId 来源。
  // 主会话（session- 前缀）不受影响，只有 worker 被禁。
  const SHELL_TOOLS = new Set(["pwsh", "bash"]);
  try {
    const off = ctx.on("tools/pre-execute", (exec, next) => {
      try {
        const toolName = exec && exec.name;
        const session = exec && exec.agent && exec.agent.session;
        const sessionId = session ? session.id : undefined;
        if (toolName && SHELL_TOOLS.has(toolName) && isWorkerSession(sessionId)) {
          record({ kind: "tool-deny", tool: toolName, sessionId });
          return {
            kind: "deny",
            reason:
              `worker 会话 ${sessionId} 不允许使用 ${toolName}：shell 会绕过文件围栏（fs-claims）。` +
              `需要构建/测试请交给编排者（主会话）执行。`
          };
        }
      } catch {
        /* 钩子自身出错必须放行，不能把所有工具调用带崩 */
      }
      return next();
    });
    restores.push(() => {
      try {
        if (typeof off === "function") off();
      } catch {
        /* 解绑失败不该炸 */
      }
    });
  } catch (e) {
    record({ kind: "hook-error", error: String(e && e.message ? e.message : e) });
  }

  record({ kind: "mounted", claimsPath: CLAIMS_PATH, methods: restores.length, version: 3 });

  return () => {
    for (const restore of restores) {
      try {
        restore();
      } catch {
        /* 卸载失败不该炸 */
      }
    }
  };
}
