/**
 * claims.js —— claim 表的读写与匹配。**纯数据逻辑，不做判定策略。**
 *
 * 数据文件：%USERPROFILE%\.dsh\fs-claims.json
 *
 *   {
 *     "enabled": true,
 *     "strictUnbound": false,          // 见下
 *     "workers": { "<sessionId>": { "allow": ["D:/proj/src/koi.js"] } },
 *     "pending": [                      // 待认领：谁先写到匹配路径，谁就领走
 *       { "id": "w1", "allow": ["D:/proj/src/koi.js"] },
 *       { "id": "w2", "allow": ["D:/proj/src/styles.css"] }
 *     ]
 *   }
 *
 * 认领机制（这是让 workflow 脚本免于知道 sessionId 的关键）：
 *   编排方**只声明计划**——"w1 该写 koi.js、w2 该写 styles.css"。
 *   子代理第一次写文件时，插件拿目标路径去 pending 里找匹配项；
 *   命中就把该 session 绑到这条 claim 上，并把条目从 pending 移进 workers。
 *
 *   所以编排器不需要拿到子代理 id，也不需要嗅探日志。
 *
 * strictUnbound：
 *   true 时，**未绑定的子代理**（sessionId 不以 "session-" 开头）在 pending 非空
 *   却匹配不到任何条目时会被拒绝。主会话（session- 前缀）永远不受此约束，
 *   以免把编排者自己锁死。
 */
import { readFileSync, statSync, writeFileSync } from "node:fs";
import { homedir } from "node:os";
import { join } from "node:path";

export const CLAIMS_PATH = join(homedir(), ".dsh", "fs-claims.json");

let cache = { mtimeMs: 0, data: null };

/** 带缓存读（供每次写入时的判定用） */
export function loadClaims(path = CLAIMS_PATH) {
  try {
    const st = statSync(path);
    if (st.mtimeMs === cache.mtimeMs && cache.data) return cache.data;
    const data = JSON.parse(readFileSync(path, "utf8"));
    cache = { mtimeMs: st.mtimeMs, data };
    return data;
  } catch {
    cache = { mtimeMs: 0, data: null };
    return null;
  }
}

/** 绕过缓存读（供绑定时的读-改-写用，避免用旧快照覆盖别人的改动） */
export function readClaimsFresh(path = CLAIMS_PATH) {
  try {
    const data = JSON.parse(readFileSync(path, "utf8"));
    cache = { mtimeMs: 0, data: null };
    return data;
  } catch {
    return null;
  }
}

export function saveClaims(data, path = CLAIMS_PATH) {
  writeFileSync(path, JSON.stringify(data, null, 2) + "\n", "utf8");
  cache = { mtimeMs: 0, data: null };
}

function norm(p) {
  if (typeof p !== "string") return "";
  const s = p.replace(/\\/g, "/");
  return process.platform === "win32" ? s.toLowerCase() : s;
}

export function toMatcher(rule) {
  const r = norm(rule).trim();
  if (!r) return null;
  if (r.endsWith("/**")) {
    const base = r.slice(0, -3);
    return (p) => p === base || p.startsWith(base + "/");
  }
  if (r.endsWith("/")) {
    const base = r.slice(0, -1);
    return (p) => p === base || p.startsWith(base + "/");
  }
  if (r.includes("*")) {
    const escaped = r
      .split("*")
      .map((part) => part.replace(/[.+?^${}()|[\]\\]/g, "\\$&"))
      .join("[^/]*");
    const re = new RegExp("^" + escaped + "$");
    return (p) => re.test(p);
  }
  return (p) => p === r;
}

/** 某条 claim（{allow:[...]}）是否覆盖这个路径 */
export function entryAllows(entry, displayPath) {
  const allow = entry && Array.isArray(entry.allow) ? entry.allow : [];
  const target = norm(displayPath);
  if (!allow.length || !target) return null;
  for (const rule of allow) {
    const m = toMatcher(rule);
    if (m && m(target)) return rule;
  }
  return null;
}

/** 判定（不含绑定；绑定在 index.js 里做，因为它要写文件） */
export function decide(claims, sessionId, displayPath) {
  if (!claims || claims.enabled !== true) return { allow: true, reason: "disabled" };

  const entry = claims.workers && sessionId ? claims.workers[sessionId] : undefined;
  if (!entry) return { allow: true, reason: "unlisted-session", unlisted: true };

  const allow = Array.isArray(entry.allow) ? entry.allow : [];
  if (allow.length === 0) return { allow: true, reason: "empty-allow-list" };

  const rule = entryAllows(entry, displayPath);
  if (rule) return { allow: true, reason: "matched", rule };
  return { allow: false, reason: "not-in-allow-list" };
}

/** 串行化绑定写入：同一进程内并发写入时，避免两条 pending 被同一个 session 同时领走 */
let chain = Promise.resolve();
function serialize(fn) {
  const next = chain.then(fn, fn);
  chain = next.catch(() => {});
  return next;
}

/**
 * 按路径认领一条 pending，把 session 绑定到它。
 * @returns {Promise<object|null>} 领到的条目；没得领返回 null
 */
export function bindPending(sessionId, displayPath, path = CLAIMS_PATH) {
  return serialize(() => {
    const claims = readClaimsFresh(path);
    if (!claims || !Array.isArray(claims.pending) || !claims.pending.length) return null;

    let hit = -1;
    let rule = null;
    for (let i = 0; i < claims.pending.length; i++) {
      const r = entryAllows(claims.pending[i], displayPath);
      if (r) {
        hit = i;
        rule = r;
        break;
      }
    }
    if (hit < 0) return null;

    const [entry] = claims.pending.splice(hit, 1);
    claims.workers = claims.workers || {};
    claims.workers[sessionId] = { ...entry, boundBy: rule };
    saveClaims(claims, path);
    return { ...entry, matchedRule: rule };
  });
}
