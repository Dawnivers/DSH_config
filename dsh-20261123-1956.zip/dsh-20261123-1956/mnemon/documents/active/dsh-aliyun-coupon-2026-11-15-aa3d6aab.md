---
id: "aa3d6aab-1f5d-44de-a564-056edc04ae85"
title: "dsh-aliyun-coupon 账号校验自否决的根因与本地补丁（掩码昵称 + 别名白名单，2026-11-15）"
description: "dsh-aliyun-coupon v1.3.2「账号不一致→永不出数」的根因：登录名是手机号、控制台登录态返回脱敏昵称，sameAccount() 双向包含必然判不一致。含本地补丁设计（maskMatches + account-alias.json 别名）、改动的函数与文件、两趟真模块验证数据、改源码后需重挂载才生效、备份与回滚点、上游 issue 口径。排查/升级该插件时参考。"
status: "active"
created_at: "2026-11-15T13:56:24.779Z"
updated_at: "2026-11-15T13:56:24.779Z"
content_hash: "4fec87c10967d7999a00c7ca3414d1d54d0131d45a1f3936b6ebdb24909f7f21"
source_paths:
  []
session_ids:
  - "72732225-b4f6-46d5-9e51-9304ff85ae31"
memory_body_ids:
  []
---

# dsh-aliyun-coupon 账号校验自否决：根因与本地补丁

日期：2026-11-15。对象：`D:\Users\林先语\Documents\dsh-plugins\dsh-aliyun-coupon`（link 安装，改源码即改安装物）。前置安装/落点记录见文档 `a20c305b-4c55-40e2-890f-92915b4dd399`；本文只记「登得进去但取不到数」这一层。

## 1. 故障分两层，别混在一起

| 层 | 现象 | 真因 |
|---|---|---|
| 一 | 填完账号密码报账号/密码错误、提示「该账号不存在」 | 配置里填的是**账号 UID**（一串 16 位数字），登录框只认登录名（手机号/邮箱/Aliyun ID） |
| 二 | 换成手机号后能登录成功，但仍判定「账号不一致」→ 返回空券表 | 控制台登录态返回**脱敏昵称** `nick5528****`，与手机号无任何包含关系，v1.3.2 的 `sameAccount()` 必然判不一致 |

第一层改凭据即可（`~/.dsh/.credentials.yaml` 的 `ALIYUN_CONSOLE_ACCOUNT` 改为手机号，密码不动）。第二层是插件 bug，不是配置问题。

## 2. 第二层的代码级根因

`index.js` 里的校验是「相等 / 双向包含」：

```js
function sameAccount(live, configured) {
  const a = normAccount(live), b = normAccount(configured)
  if (!a || !b) return true
  return a === b || a.includes(b) || b.includes(a)
}
```

`live` 来自控制台的 `loginAliyunId`，形如 `nick5528****`；`configured` 是手机号。两者互不包含 → 恒判不一致。

恶性循环：判不一致 → 主动清 Cookie → 用手机号重登（能成功）→ 抓完再比一次 → 仍不一致 → **不返回券数据**。所以账号密码全对也永远出不来数，而报错文案会误导成「登录态失效或账号密码有误」。

注意：v1.3.2 加这道校验本意是防「读到上一个账号的券」（同一浏览器 profile 复用登录态时的串号）。任何修法都不能把校验修成摆设。

## 3. 本地补丁设计（改的是插件源码，改动均带注释）

| 改动 | 作用 | 安全边界 |
|---|---|---|
| 新增 `maskMatches()` | 把 `*` 当通配符比对，`nick5528****` 能对上真实昵称前缀 | 仅解决脱敏，不放宽到任意账号 |
| 新增 `liveMatches()` | 原 `sameAccount` 放行，否则再查别名表 | 别名缺失时**不**退化为放行（曾写错成「空别名也返回真」，等于废掉校验，已修） |
| 新增 `account-alias.json`（存 `storageDir()`） | 记「这个配置账号登录成功时控制台显示的昵称」 | 只在该账号**用自己的凭据登录成功那一次**写入 |
| 抓取成功后 `rememberAlias()` | 首次/换账号自愈；之后暖会话直接放行 | 换别的账号照样被逮住 |

别名文件结构：`{ configured, live, at }`；读取时先比 `normAccount(configured)`，不匹配就当没有别名。

## 4. 验证证据（真插件模块 + 假 ctx + 真无头浏览器 + 真券表）

脚本：`D:\Users\林先语\Documents\dsh-plugins\_downloads\verify-plugin.mjs`（起一个最小 ctx 跑插件 `/balance` 路由）。

| 场景 | 结果 |
|---|---|
| 冷启动、无别名 | 判不一致 → 清 Cookie → 手机号重登 → 记录别名 → **出数**，15.5 s，`loginAttempted: true` |
| 暖会话、有别名 | 直接放行、不重登，4.3 s，`loginAttempted: false` |

两趟都拿到同一份真数据：面值 300、余额 297.06、已用 2.94（0.98%），券名「阿里云云工开物学生专属代金券」。中间踩过的坑：脚本里 `(?m)` 不能用于 `new RegExp`（`Invalid group`），改成在 `match` 上用 `m` 标志的写法。

## 5. 生效与回滚

- 改的是磁盘源码，**运行中的 DSH 不会自己换模块**。生效方式：设置 → 插件 → 把 `dsh-aliyun-coupon` 关掉再打开（HMR 重新 import），或完全退出 DSH Desktop 再启动。之后回面板刷新一次。
- 回滚点：`index.js.bak-20261115-215215`（52038 字节，与改前同目录）。
- 面板缓存的 `last-good.json` 会在实时抓取失败时展示为 stale，便于区分「抓取失败」与「无数据」。
- 抓取用的临时无头 Chrome 已清理（进程 0）；插件下次刷新自行再拉，登录态留在 profile 里。

## 6. 上游 issue 口径

标题方向：登录名是手机号时，控制台 `login_aliyunid` 返回脱敏值，`sameAccount()` 恒判不一致，导致校验自我否决、券列表恒空。建议方案：把脱敏值加入比对（`*` 通配），或首次登录成功后持久化「配置账号 ↔ 控制台昵称」映射，二者取一，且不要退化成放行。

附带提醒：该补丁属本地改动，插件升级会被覆盖。
