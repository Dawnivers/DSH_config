---
id: "19f22f4c-cab0-49c1-87a2-0e5a86a59c47"
title: "agent-desktop v1.3.1 无头桌面控制：D 盘安装实录与 windows-mcp 0.8.8 能力边界（2026-11-15 实测）"
description: "回答\"agent-desktop 能不能装、和 windows-mcp 哪个好\"：官方 Windows x64 发布包在 D 盘的安装与 SHA-256 校验、AGENT_DESKTOP_HOME 迁移、状态目录 DACL 踩坑与修法、任务栏快照实测（31 refs、不移动指针/不抢焦点）、无头 vs --headed 的能力禁令清单，以及与 windows-mcp 0.8.8 控制闸门的分层对比与选型建议。关联：b8b40b8b（windows-mcp 控制权补丁）、8ba56185（MCP 选型）、68b45688（D 盘安装规矩）。"
status: "active"
created_at: "2026-11-15T14:30:12.599Z"
updated_at: "2026-11-15T14:30:12.599Z"
content_hash: "f22e379d9096110b16bc10567e54424e1b8414c6bb5e6635c97f97465c7276bb"
source_paths:
  []
session_ids:
  - "a5f68b31-da7c-48f7-afbf-c13aa7d8c7ca"
memory_body_ids:
  []
---

# agent-desktop 装机实测与 windows-mcp 对比

日期：2026-11-15。用户问「vercel-labs/agent-desktop 据说能不抢鼠标控制软件，我能装吗？和 windows-mcp 哪个更好？」——本文是实测后的定版记录。

## 0. 结论先说

- **能装，已装好**：v1.3.1（2026-11-13 发布）官方 Windows x64 包，解包即用，单文件 exe，**不走 npm**。
- **"不影响鼠标"是真的**：无头模式读 Windows UI Automation 语义树 + 给控件编 `ref`，按 ref 走语义调用（Invoke/Value pattern），不移动指针、不抢前台焦点。
- **但它看得见**：一次任务栏快照读出 WiFi 名、电池电量、当前开着的微信/迅雷/VS Code。README 亦声明 snapshots / clipboard 可能含隐私。定位是"后台静默读屏"，不是"什么都不看"。
- **两者不是替代关系**：agent-desktop 只有 UI 层；文件/注册表/PowerShell/进程/通知仍只有 windows-mcp 能做。

## 1. 安装（按 D 盘规矩，绕过 npm 全局）

关键判断：本机 `npm config get prefix` = `C:\Users\林先语\AppData\Roaming\npm`，`npm install -g` 必然落 C 盘，违反"安装一律 D 盘"的规矩（该规矩的历史代价见文档 `68b45688`）。因此改走官方发布包。

```powershell
# 取 tag v1.3.1 的 x86_64-pc-windows-msvc 包 + checksums.txt
# 校验后解包到 D:
# agent-desktop-v1.3.1-x86_64-pc-windows-msvc.tar.gz  1,835,706 bytes
# sha256 6ee4b1e078f4e78792e79f16e32e4a78b9919464aa3c55629b7e27ed53a08c13  (MATCH)
```

装后布局：

| 项 | 值 |
|---|---|
| 本体 | `D:\tools\agent-desktop\agent-desktop.exe`（3.85 MB） |
| 状态目录 | `D:\tools\agent-desktop\home`（环境变量 `AGENT_DESKTOP_HOME` 已持久化到用户级） |
| 版本自述 | `{"version":"2.6","ok":true,"command":"version","data":{"os":"windows","target":"x86_64","version":"1.3.1"}}` |
| C 盘残留 | 无（默认路径 `C:\Users\林先语\.agent-desktop` 未曾生成） |
| 卸载 | 删目录 + 清环境变量即可 |

发布包矩阵里另有 aarch64-apple-darwin / aarch64-pc-windows-msvc / linux-gnu 变体；Windows ARM 有原生包。

## 2. 最大的坑：状态目录不能手动预建

手动 `mkdir D:\tools\agent-desktop\home` 后所有 snapshot 失败：

```json
{"ok":false,"command":"snapshot","error":{"code":"INTERNAL",
 "message":"private file DACL grants an untrusted principal",
 "disposition":{"delivery":"not_delivered","retry":"safe"}}}
```

`icacls` 显示继承来的宽松 ACL（`Authenticated Users:(M)`、`Users:(RX)`）。工具要求状态目录**仅属主可访问**，任何继承的宽泛主体都会触发拒绝。修法只有一条：**删掉目录，让工具自己创建**（`status` 调用后它自己建，再跑 snapshot 即 ok）。

同类机制值得记住：这种 `INTERNAL` + `retry:safe` 的报错是**可安全重试**的分类，不是数据损坏。

## 3. 实测：无头读任务栏

```
snapshot --surface taskbar
→ ok=true, app=explorer.exe, complete=true, ref_count=31, snapshot_id=s6pnkgsafbizp
```

回传的是完整语义树：开始/搜索/任务视图、31 个固定与运行中应用（含 `Appid:` 形式的原生标识）、托盘图标（网络/音量/电源/时钟，带文字描述如"电池状态: 已充满 100%"）。整个过程指针未移动、焦点未变。

`permissions` 输出值得注意：

```json
{"accessibility":{"state":"granted"},"automation":{"state":"not_required"},
 "screen_recording":{"state":"not_required"}}
```

**不需要屏幕录制权限**——它不靠截图识别，靠 UIA 树。这与 windows-mcp 的 `Snapshot`（截图 + 坐标）路线是根本差异。`supported_surfaces`：window / focused / sheet / menu / start-menu / taskbar / system-tray / system-tray-overflow / action-center。

## 4. 硬限制（决定它能不能替代 windows-mcp）

- **无头模式下 `type` / `right-click` / `double-click` / `drag` / `hover` 一律 `POLICY_DENIED`**。输入文字要用 `set-value`（走 Value pattern）；真要敲键盘只能 `--headed`，那时就会抢焦点。
- **元素 ref 与快照绑定**，界面一变即 `STALE_REF`，必须重新快照再点（快照成本 = 一次 UIA 遍历）。
- Chromium / Electron 冷启动需 **10–25 秒**才建出完整树，要调 `--timeout-ms`。
- **二进制未签名**，官方明说 Smart App Control 与杀软可能拦（本次未触发）。
- 必须是**已登录的交互式桌面会话**；锁屏、UAC 安全桌面、session 0 均不支持。
- 管理员权限窗口**读得到、点不了**（UIPI），须用同级权限终端运行。
- 能力范围**只有 UI 层**（约 61 个命令）：无文件、注册表、命令执行、进程管理、通知。

## 5. 与 windows-mcp 的分层对比

本机 windows-mcp 为 `uv tool` 安装的 **v0.8.8**（PyPI 最新 0.8.9），已带 relaxed 控制闸门（`ControlStatus` / `ConsentCountdown` / 夺回热键），并非"野蛮抢鼠标"的老版。该版本曾有一次控制权卡死事故与就地补丁，见文档 `b8b40b8b`；MCP 选型背景见 `8ba56185`。

| 维度 | agent-desktop v1.3.1 | windows-mcp 0.8.8 |
|---|---|---|
| 实现 | Rust 原生，单文件 exe | Python，uv tool 装的 MCP server |
| 读界面 | UIA 语义树 + ref 编号 | UIA 树 + 坐标 + 截图 |
| 点按钮 | 无头语义调用，不动指针、不抢焦点 | 坐标点击，需桌面所有权 |
| 抢鼠标 | 仅 `--headed` | 默认会，但有闸门：琥珀色边缘 + 10 秒倒计时，动鼠标或 `Ctrl+Alt+Shift+Backspace` 夺回 |
| 免桌面所有权的工具 | 全部（无头） | FileSystem / Registry / Snapshot / Screenshot / Process list |
| 能力边界 | 仅 UI 层 | 文件 / 注册表 / PowerShell / 进程 / 通知 / 截图 |
| 接入方式 | CLI（亦可 `agent-desktop mcp` 走 stdio） | 已是 DSH 的 MCP |

## 6. 选型建议

- **要「动软件但不打扰我」→ agent-desktop**：点按钮、填表单、读控件，全程静默，这是它唯一的独门优势。
- **要「动系统」→ 只能 windows-mcp**。
- **两者可共存**，MCP 层并列挂，由模型自选。
- **只留一个 → 留 windows-mcp**（覆盖面）；若诉求纯粹是"别抢鼠标" → agent-desktop 更对味，但要接受它碰不了文件。

## 7. 未决项

- 是否把 agent-desktop 接成 DSH 的 MCP（`agent-desktop mcp`，stdio），以此获得 `desktop_*` 工具，当时留给用户决定，尚无结论。
- 未做的实测：`set-value` 在真实表单（Electron 应用）上的可靠性、`STALE_REF` 重试在动态界面下的实际失效率。
