---
id: "64d3ea2f-4a08-4267-9763-c8a90e99449e"
title: "assertion 闸门首次端到端实跑的根因与修复：Electron process.execPath 指向 DSH.exe"
description: "第一次真跑 assertsions 闸门（lab-a 实验 1）暴露的运行时故障排查记录：插件进程用 process.execPath 执行 run.mjs 时拿到的是 DSH.exe 而非 node，stdout 只有一个换行、exit_code 却为 0，导致 JSON 解析失败被判 status=error；给出 nodeBin() 修复、空输出诊断字段 bin、回归测试，以及同一轮观察到的 planner 路由 MALFORMED_RESPONSE 与 on_failure 未能在失败分支下被验证的两条遗留项。"
status: "active"
created_at: "2026-11-19T06:01:42.530Z"
updated_at: "2026-11-19T06:01:42.530Z"
content_hash: "857f52941b43a8b52356551cc674a97627f1dc8458f7f49f3064916f8d96f914"
source_paths:
  - "dsh-orchestrator/src/assertions.js"
  - "dsh-orchestrator/test/assertions.test.mjs"
  - "dsh-orchestrator/assertions/run.mjs"
session_ids:
  - "b726126f-58c2-455d-9bb8-73cf29929cfb"
memory_body_ids:
  []
---

# assertion 闸门首次端到端实跑：根因与修复

> 依据：2026-11-19 已完成父会话的有界检查点（`orchestrate_run` 的 run 报告 JSON、`src/assertions.js` 205–244 行摘录、`test/assertions.test.mjs` 摘录、终端探测输出、全量测试输出 219/215/0）。未重读源码，行号对应检查点当时状态。
>
> 关联：`a9aa08c1-e1f5-40be-87f5-4e8c4d8031b1`（闸门的**设计与实现**：`reviewMode`、`report.assertions`、三条安全不变量——本文是它第一次真跑时暴露的运行时缺陷，不重复其设计论证）；`f838a05b-bbd7-4b3c-9b29-6d21c6ec243e`（`assertions` 选择层）。

## 一、故障现象

在 `D:\DSH_test_lab3\assertion-gate\lab-a` 上跑实验 1（任务：只改 `src/area.mjs`，加 `decimals` 参数与 `describe` 空值保护），闸门在报告里落成：

```json
"status": "error", "exit_code": 0,
"reason": "断言输出不是合法 JSON",
"raw_head": "\r\n"
```

两个反常点：**stdout 只有一个换行**，且**退出码是 0**。任务因此判 `review_failed`，reviewer 正常介入。

## 二、排查过程中被排除的假设（避免重复走）

1. **`run.mjs --json` 输出被人读摘要污染** —— 排除。第 227–232 行是 `if (opts.json) {…} else if (!opts.quiet) {…}` 的互斥分支，`--json` 路径干净。
2. **JSON 本身有结构问题** —— 排除。写 `_probe.mjs` 直接 `execFile` 复现：stdout 4670 字节、`JSON.parse` 成功、`status = pass`、12 条 check。
3. **工作目录里没有 job 存储** —— 排除但踩了两个环境坑：`$HOME` 在 PowerShell 是只读常量（`WriteError: 无法覆盖变量 HOME`），且 `DSH_ORCHESTRATOR_HOME` 未设置时落在 `%DSH_HOME%\storage\jobs`（`DSH_HOME=C:\Users\…\.dsh`），不是 `C:\Users\…\storage`。

「终端一切正常、插件里必坏」这个反差本身就是最强线索。

## 三、根因

DSH Desktop 是 Electron 应用，**插件进程里的 `process.execPath` 指向 `DSH.exe`，不是 node**。用它去执行 `.mjs` 只会拉起一个应用实例然后正常退出 0 —— 于是拿到「空 stdout + exit_code 0」。

终端探测时用的是 `E:\node.exe`，所以本地复现永远成功。这属于**宿主环境差异**，纯静态读代码推不出来，只有端到端实跑才会暴露。

## 四、修复

`src/assertions.js` 增加可执行文件解析，所有断言命令改走它：

```js
export function nodeBin() {
  if (!process.versions.electron) return process.execPath;
  return process.env.DSH_NODE_EXECPATH || 'node';
}
```

配套两点：

1. **诊断优先于结论**：stdout 为空但退出码为 0 时，明确报「命令没有输出任何内容，请确认它由 node 执行」，而不是含糊的「不是合法 JSON」；记录里新增 `bin` 字段，直接暴露实际用了哪个可执行文件——下次同类问题不用再猜。
2. **回归测试**：`test/assertions.test.mjs` 锁住「`process.versions.electron` 存在时 `nodeBin()` 必须退回 `node`」。
3. 全量测试 **219 条 / 215 通过 / 0 失败**。

关键教训：`process.execPath` 在 Electron 宿主里不等于某个 JS 运行时。任何插件内 spawn 脚本的地方都要显式解析解释器，而不是假定 `execPath` 能跑 `.mjs`。

## 五、同一轮验证有效、以及未能验证的部分

已验证有效（实验 1 的正面结果）：

- `assertions: ["geo.vector"]`、`reviewMode: "on_failure"` 正确落进 job。
- planner 的 acceptance 里出现「主会话待运行验证：`node …\assertions\run.mjs … --json` 通过」——断言提示词注入生效。
- worker 回执写明「`not_applicable` 不算通过」「不得以 `exit_code=0` 放行」。
- worker 实际只改了 `src/area.mjs`（9→10 行，`decimals = 2` + `toFixed(decimals)` + 空值保护），`allowedGlobs` 边界未被突破。
- 安全线未被绕过：闸门 `status=error` 时 reviewer 拒绝放行，并追加一条 check 质疑「不能只看 exit_code」——注入的判定规则真被模型用上了。

未能验证：`reviewMode=on_failure` 的「断言通过则跳过 reviewer」分支。因为闸门报错走的是失败路径，reviewer 照常启动。成功形态应为 `assertions.status = "pass"`、`verdict = "passed_by_assertions"`、**`review = null`** 且报告里没有 reviewer child。

## 六、两条遗留项

1. **修复要重启 DSH 才生效**：插件进程加载的是旧代码，`assertions.js` 的改动必须重启 DSH Desktop。重启后重跑实验 1 才能验证 `review = null` 分支（`lab-a/src/area.mjs` 已重置回原始状态，跑前确认闸门全绿 exit 0）。
2. **planner 路由质量问题（与插件无关）**：`deepseek-official / deepseek-flash` 作为 planner 会报 `MALFORMED_RESPONSE`（`DeepSeek Messages stream: tool input is invalid JSON`），planner 阶段直接 failed；换成 `worldcode4 / claude-opus-5-5` 后同一任务正常完成。属该模型路由的流式输出缺陷，不是编排逻辑问题——排查失败时先换路由再怀疑代码。
