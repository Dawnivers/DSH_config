---
id: "c84547d8-dd5c-4fbb-b03d-7bf61489d47c"
title: "周备份连续两周失败（11-15 / 11-22）：robocopy 跟踪 Junction 报 exit 9 的根因、复现与 /XJ 修法"
description: "记录 2026-11-22 周备份在 export-dsh.ps1 导出阶段失败（robocopy exit 9）的完整排查：.dsh/storages 下两个 Junction 被跟踪导致复制失败、11-15 同因同败的纠正、/XJ 复现验证、一行补丁与重跑命令、失败残留与剪枝已成功的边界说明。"
status: "active"
created_at: "2026-11-22T14:02:26.503Z"
updated_at: "2026-11-22T14:02:26.503Z"
content_hash: "4b8fad18271c400ef4b2dfcab5cf8d47d177d210c20bba0c54a4b59508b0c335"
source_paths:
  - "dsh-migration/export-dsh.ps1"
  - "dsh-migration/publish-dsh.ps1"
  - "dsh-migration/distill/distill-20261122.md"
session_ids:
  - "ca237c54-4b1b-4c92-bc0f-092c52c65c11"
memory_body_ids:
  []
---

# 周备份连续两周失败：robocopy 撞 Junction（2026-11-22 排查）

承接既有三份备份链路文档：`284e4a5f-9725-4a26-bd8c-7ad334658199`（单提交 force push 发布链路）、`6ad8866f-0f40-4601-91e9-d31b793a186e`（体积上限与闸门）、`3c18a070-eeb5-4f8a-88f4-ae6bdd470227`（回收站 purge 接入）。本文只记这一次**导出阶段失败**的排查结论与待落地的补丁。

## 1. 结论先行

周备份在 `export-dsh.ps1` 的导出阶段就 `throw`，**没有走到 zip、脱敏、push**。原因是 `Invoke-Robocopy` 的参数缺 `/XJ`，robocopy 跟踪了 `~/.dsh/storages` 下两个新出现的 Junction，报 `exit 9`（= 1 成功 + 8 有文件复制失败）。加 `/XJ` 后同一目录 `exit 1` 通过。

因此 **11-15、11-22 两周都没备份成功**，远端仍停在 `dsh-20261108-2200.zip`，`publish-state.json.at` 也停在 `2026-11-08T22:01:55`。

## 2. 关键纠正：11-15 不是"job 结果丢失"

11-15 那次当时判为「后台 job 的 `job_output` 结果丢失、outcome unknown」。11-22 的取证否定了这个解释——**11-15 是真失败，同一根因**：

| 证据 | 值 |
|---|---|
| `publish-state.json.at` | `2026-11-08T22:01:55`（两周未更新） |
| 本地 zip 最新一份 | `dsh-20261108-2200.zip`，11.76 MB |
| `dsh-20261115*.zip` | 不存在 |

时间线也吻合：11-08 成功时 `storages` 下还没有这两个链接；11-15 装上 `dsh-aliyun-coupon` 后连挂两周。

## 3. 失败现场（11-22 22:00）

```
robocopy failed (9): C:\Users\林先语\.dsh\storages -> D:\dsh-migration\dsh-20261122-2200\home\storages
export-dsh.ps1 失败（exit 1）
退出码: 1   耗时 18 秒
```

`storages` 下新增的两个链接：

| 名字 | 类型 | 指向 | 体量 |
|---|---|---|---|
| `aliyun-coupon` | Junction | `D:\Users\林先语\Documents\dsh-plugins\_data\aliyun-coupon` | 2053 文件 / 425.3 MB |
| `orchestrator` | Junction | `...\deepseek-harness\default-workspace\orchestration\plugin-data` | 232 文件 / 3.87 MB |

代码位置 `dsh-migration/export-dsh.ps1` L47–53：

```powershell
function Invoke-Robocopy {
  param([string]$Source, [string]$Destination, [string[]]$ExcludeDirs = @())
  $rcArgs = @($Source, $Destination, '/E', '/R:1', '/W:1', '/NFL', '/NDL', '/NJH', '/NJS', '/NP')
  if ($ExcludeDirs.Count -gt 0) { $rcArgs += '/XD'; $rcArgs += $ExcludeDirs }
  $null = robocopy @rcArgs
  if ($LASTEXITCODE -gt 7) { throw "robocopy failed ($LASTEXITCODE): $Source -> $Destination" }
}
```

注意 `if ($LASTEXITCODE -gt 7)`：robocopy 的 8（部分失败）与 9（1+8）都会 throw，但 1–7 视为成功——所以 `/XJ` 后的 `exit 1` 是正常放行，不是隐患。

## 4. 复现与验证（同一源目录层级）

| 命令 | robocopy exit | 判定 |
|---|---|---|
| 不带 `/XJ` | **9** | 复现失败 |
| 带 `/XJ` | **1** | 通过（1–7 放行） |

`/XJ` 的语义：跳过 Junction 与符号链接**本身**，不展开其目标；普通目录照常遍历。因此包里会缺 `storages\aliyun-coupon`、`storages\orchestrator` 两块——恢复后插件自行重建，且那个 425 MB 的优惠券缓存本不该塞进 ~11 MB 的每周包。

## 5. 待落地补丁（截止本文未改文件）

`dsh-migration/export-dsh.ps1` **第 49 行**，只在 `/E` 后插入 `'/XJ'`：

```powershell
$rcArgs = @($Source, $Destination, '/E', '/XJ', '/R:1', '/W:1', '/NFL', '/NDL', '/NJH', '/NJS', '/NP')
```

改完重跑：

```powershell
cd 'D:\Users\林先语\Documents\deepseek-harness\default-workspace\dsh-migration'
pwsh -NoProfile -File .\publish-dsh.ps1
```

重跑幂等：11-22 那 34 个会话已被 `prune-sessions.mjs` 搬进 `session-trash\20261122-2200`，`distill-20261122.md` 也已生成，不会重复提炼/重复搬运。

## 6. 失败时已完成的部分（信息未丢）

剪枝与提炼在导出之前，**都已成功**：

| 项 | 值 |
|---|---|
| 提炼 | 26 个会话（跳过子代理 179 / 碎片 5）→ `distill\distill-20261122.md`，48.4 KB，打码 1 处 |
| 剪枝 | 34 个会话 / 33.90 MB → `D:\dsh-migration\session-trash\20261122-2200`（跨卷按 复制→删源） |
| 跳过原因分布 | 摘要里没有 877、摘要太新 19、摘要后又改过 7 |

## 7. 验收时必须带 PAT（踩过两次）

核对远端是否真的收到包，要走 GitHub API；**未认证 API 只有 60 次/小时，且按出口 IP 共享**，代理后面极易被别人吃光：

```
HTTP 403 API rate limit exceeded for 161.81.206.66
```

后果是**把"推送成功"误判成"推送失败"**——11-07、11-08 两次验收都撞到（11-07 加 `User-Agent` 侥幸过，11-08 连 UA 都不够）。脚本自身推送走的是本地 PAT（5000 次/时），不受影响。取证时应读本地 PAT 文件（`%USERPROFILE%\.dsh-config-publish\token`）以 `Authorization: Bearer` 调用，读后立刻看到 `core: 1/5000`。

另一条同期的环境事实：11-22 那天本机代理端口 7897/7890/10809 **全部未开**，而 GitHub 直连 `http=200`；`publish-dsh.ps1` 的 `Get-LocalProxy` 会自动探测并在直连可用时走直连，所以代理缺失不构成阻塞——那次日志里 `proxy: 直连`。

## 8. 遗留待决

1. **失败残留 357.94 MB**：`D:\dsh-migration\dsh-20261122-2200`（2449 文件）是导出到一半的产物，脚本失败时未清理；可直接 `Remove-Item -Recurse -Force`，未擅自动手。
2. **425 MB 优惠券缓存**：`dsh-plugins\_data\aliyun-coupon` 是缓存还是必要数据未确认；若是缓存可整体清掉。
3. **仓库可见性提示**：脚本启动即告警仓库为 public，而包含 `~/.mnemon` 记忆、会话标题与项目路径，建议改 private——属于既有风险，非本次故障。
