---
id: "228d76d9-3ea7-4058-8c41-30194ae295e9"
title: "Cloudflare 524 长尾诊断：worldcode2（Claude 分支）双峰延迟把单步推过 120s（2026-11-13，arm-a7）"
description: "worldcode2 Claude 分支的 524 不是通道故障而是双峰尾部延迟：24 次小请求 96% 成功且零 524，但 5 次 78~89s 长尾 + 复刻 45KB prefill 请求 38/42/110s，逼近 Cloudflare 120s 上限。含延迟对照表、5 次重试打满窗口的时间线、流式首字节证据、探针脚本路径与分流处置建议。"
status: "active"
created_at: "2026-11-13T06:53:35.327Z"
updated_at: "2026-11-13T06:53:35.327Z"
content_hash: "63568c3dd2124f8255f1ddfa8b43c760920761ce6bb12e30098f0cae69659016"
source_paths:
  - "tools/scan-retries.mjs"
  - "tools/scan-retries2.mjs"
  - "tools/probe-channel.mjs"
  - "tools/probe-channel2.mjs"
  - "tools/probe-channel3.mjs"
  - "tools/probe-streaming.mjs"
  - "tools/probe-replay-step3.mjs"
  - "tools/probe-thinking.mjs"
  - "tools/probe-firstbyte.mjs"
  - "tools/probe-compare.mjs"
  - "tools/probe-ttft-scaling.mjs"
  - "tools/probe-baseline.mjs"
session_ids:
  - "39c97a19-e8d6-410c-b41f-8abe52ed35f3"
memory_body_ids:
  []
---

# Cloudflare 524 长尾诊断（worldcode2 / Claude 分支，2026-11-13，arm-a7）

## 证据范围与关联

依据 2026-11-13 已完成父会话的有界检查点：用户问「统计历史 524 分布，判断是偶发还是常态」，父会话转为**直连真实接口实测**（多支探针脚本，回执为直接证据），最后给出分流建议。维护儿童未重跑探针、未重开项目文件；脚本正文仅有创建回执，**输出**才是直接证据，不视为对网关内部实现的源码审计。

同网关的其他失败类（本篇是第三种，处置不同）：

- `0ea9f8bc-802e-4617-9ac3-68f552d821e1`：503「No available accounts」账户池容量（可重试抖动）
- `b8cb07bf-eb56-4205-9c8e-a6f365504a74`：opus 返回畸形 thinking signature → 400（不可重试）
- **本篇**：524 origin_response_timeout——不是坏，是**慢**，慢到超过 Cloudflare 120 秒上限

工作区：`D:\DSH_test_lab2\arm-a7`。

## 结论

**既不是「偶发」也不是「haiku 这条通道坏了」，而是 worldcode2 的 Claude 分支存在双峰尾部延迟，长上下文 prefill 时尾部会顶到 120 秒。**

1. 当天直连同 key 同模型发 24 次极小请求：成功 23/24 = 96%，状态码 `{200:23, 502:1}`——**没有一次 524**，通道本身是通的。
2. 但延迟双峰：24 次里 5 次耗时 78~89s，其余多为 2~4s（min 1.8s / 中位 4.3s / max 88.7s）。均值被尾巴拉到 20s 以上。
3. 长尾不是 haiku 特有：同 provider 的 `claude-opus-5-5` 8 次里 2 次 83.7s / 102.7s。
4. 对照组无尾部：`worldcode1/deepseek-v4.1-flash-1017` 24/24、1.3~3.1s；`worldcode/gpt-6.1-sol` 12/12、2.6~4.8s。

## 关键实测证据

### 延迟分布对照（同日、同探针形状）

| 通道 | 成功 | 延迟 |
|---|---|---|
| worldcode1 / deepseek-v4.1-flash-1017 | 24/24 | 1.3~3.1s，无尾部 |
| worldcode / gpt-6.1-sol | 12/12 | 2.6~4.8s，无尾部 |
| worldcode2 / claude-haiku-4-5 | 23/24 | 1.8~88.7s，双峰 |
| worldcode2 / claude-opus-5-5 | 8/8 | 5.1~102.7s，长尾 |

### 复刻失败请求形状（45KB koi.js 上下文 + 要求重写全文，prefill≈52K token）

```
#1 200  42.2s   in=1774 out=6527 cw=42572
#2 200  38.4s   in=2661 out=6385 cw=7982  cr=33703
非流式重跑 200 110.8s   ← 离 120s 只差 9 秒
```

同一请求形状耗时差近 3 倍（38s / 42s / 110s）：落在尾巴上就是 524。

### 真正失败的那 5 次重试

区间 `2026-11-13T03:08~03:17`，全是 Cloudflare 524 origin_response_timeout：

```
03:08:29  retry1 delayMs 523
03:10:35  retry2 delayMs 996
03:12:42  retry3 delayMs 2098
03:14:49  retry4 delayMs 4360
03:17:00  retry5 delayMs 7649
```

间隔 126/127/127/131/135s —— **5 次全部打满 120 秒完整窗口**，一次都没提前返回。响应体为 Cloudflare 错误页（`zone worldcodes.online`、`instance=ray_id`，无 body），宿主的错误分类把 524 归到 `SERVER`。即源站当时确实没吐字节，但当前同样形状 40 秒就能出结果 → 拥塞/慢路径，而非永久故障。

### 流式探针：慢在排队+prefill，不在生成

| 输出规模 | firstByte | total |
|---|---|---|
| 短 | 4.9s | 5.0s |
| 250 行 | 17.8s | 18.5s |
| 900 行 | 53.4s | 54.7s |
| 2000 行 | 72.5s | 74.7s |

首字节占绝大部分时间，证明上游**不是**「攒完再吐」，主要是排队 + prefill 吞吐不稳。

## 为什么 5 次重试一次都没成

宿主退避 0.5s→1s→2s→4s→8s（实测 523/996/2098/4360/7649ms），但单次请求本身就要 120s。退避相对超时窗口可忽略：5 次重试 = 10 分钟里连续 5 个独立的 120s 超时，源站若正处拥塞/该 prompt 形状反复走慢路径，不会自愈。

## 处置建议

- **要立刻拿到结果**：worker 换 `worldcode1/deepseek-v4.1-flash-1017`（历史记录里它把 arm-a5/a6 编排从 2457s 压到 576s、缓存率 89%）。配置改 `~/.dsh/storages/orchestrator/defaults.json` 或设置页 API。
- **保持 haiku 只赌一次**：复刻形状下单步成功率约 2/3，连挂 5 次概率约 0.4%，重跑大概率能过，但要再花约 15 分钟。
- **折中**：worker 换 deepseek，planner 留 opus——planner 单轮能被 120s 兜住且有 maxPlanRetries，worker 要跑十几步，最该换掉尾部不稳的通道。
- **判据可复用**：worker 用于「读大文件 + 重写全文」时，选通道先看**尾部延迟**而不是中位/平均；中位数 4s 的通道照样会把 120s 超时打穿。

## 复现脚本（均在 arm-a7/tools/）

- `scan-retries.mjs` / `scan-retries2.mjs`：扫历史会话失败分布与重试事件
- `probe-channel.mjs` / `probe-channel2.mjs` / `probe-channel3.mjs`：通道直连冒烟、大上下文、长输出、并发
- `probe-streaming.mjs`：流式首字节 vs 输出规模
- `probe-replay-step3.mjs`：复刻失败步骤的请求形状
- `probe-thinking.mjs`：thinking budget 影响
- `probe-firstbyte.mjs`：首字节分布（no-think vs think1024 vs 8192；8192 两次直接 502）
- `probe-compare.mjs`：跨通道首字节横向对比
- `probe-ttft-scaling.mjs`：TTFT vs 输入长度（2KB 42.4s / 8KB、20KB 失败 / 40KB 6.0s / 70KB 7.5s / 110KB 15.7s——非线性，进一步说明是排队而非纯算力）
- `probe-baseline.mjs`：基线失败率样本（支持 `--model` 等参数，24 次/轮）

脚本从凭据存储读 key，不把凭据写进文件。

## 附带观察

- thinking budget=8192 时 2/2 直接 502（`<!DOCTYPE html>` 页面 @8~11s）；budget=1024 可跑但更慢；no-think 首字节 37~45s。该通道对大 thinking budget 不稳定。
- `pi-ai` 等包在 Desktop 安装目录中未找到（`node_modules` 只有 `@deepseek-ai`、`@deepseek-harness-tui`），故 `pi-ai stream idle timeout after 300000ms` 一类错误无法从该处源码继续追；检查点内没有更多证据。
