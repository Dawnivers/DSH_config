---
id: "b6f49797-e0d2-48a8-84d3-f13a3eb6fc80"
title: "官方 agent team 与 dsh-orchestrator 编排的本质差异（源码级对照，2026-11-19）"
description: "用户问「我的 AI 编排和 DSH 官方多智能体协作插件有什么区别」后，读官方 agent-team、workflow 源码与自家 dsh-orchestrator 2.0.12 runner 得到的定版对照：协作原语 vs 流程约束的四种形态分层、8 维逐项差异、权限是真拦还是靠提示词、跨模型路由为何不可互替、谁兜住\"AI 说自己做完了\"、选型建议。承接文档 f3e88214（委派触发机制）、aac1741e（多模型编排先例）。"
status: "active"
created_at: "2026-11-19T02:41:15.216Z"
updated_at: "2026-11-19T02:41:15.216Z"
content_hash: "4bc6749da43d2b19260450f7de8eb25e8e280fb473c029313bea04c7cea7cc86"
source_paths:
  - "node_modules/@deepseek-ai/dsh-experimental-tool-agent-team/lib/index.js"
  - "node_modules/@deepseek-ai/dsh-experimental-agent-team"
  - "node_modules/@deepseek-ai/dsh-tool-workflow/README.zh.md"
  - "dsh-orchestrator/src/runner.js"
  - "dsh-orchestrator/package.json"
session_ids:
  - "c6080d83-e4bb-41ba-a830-92192e7201be"
memory_body_ids:
  []
---

# 官方 agent team ≠ 我的编排：一句话与八项对照

日期：2026-11-19。问题：**「我这个 AI 编排和 DSH 官方插件：多智能体协作有什么区别？」**
回答依据：读官方 `dsh-experimental-agent-team` / `dsh-experimental-tool-agent-team` / `dsh-tool-workflow` 源码，对照自家 `dsh-orchestrator` 2.0.12 的 `src/runner.js`。

## 0. 一句话结论

**官方给你一支团队，让模型自己当经理；我的编排给一条产线，模型只是产线上的工位。**

官方做的是**协作原语**（身份、邮箱、看板、CAS），把「怎么协调」留给模型现场决定；`dsh-orchestrator` 做的是**流程约束**（阶段、权限、互斥、独立复核），把「怎么协调」写死在代码里。

## 1. 先分清层次：官方有三套，这是第四套

| | 形态 | 谁在指挥 | 关键工具/包 |
|---|---|---|---|
| `subagent` / `subagent_fork` | 一次性派活，子代理跑完交结果 | 主会话 | `dsh-subagent` |
| `workflow` | 模型写一段 JS 脚本扇出子代理，分阶段收结构化结果 | **脚本** | `dsh-tool-workflow`（README 明确：仅当用户显式要求工作流或大型多 agent 编排时使用） |
| **agent team** | 主会话当 Lead，创建**具名常驻** teammate，互发消息、共享任务板 | **Lead 模型临场判断** | `dsh-experimental-agent-team` + `-tool-agent-team`（+ `-client-ui-agent-team` 面板） |
| **dsh-orchestrator**（自家） | 预存不可变任务 → 固定产线 planner → 可行性复核 → workers → reviewer | **插件代码**，不由模型决定阶段 | `orchestrate_task` / `orchestrate_run` |

面板上中文名「团队 / 多智能体协作」指的是第三个。三者工具名不冲突（自家注册 `orchestrate_*`），但会抢同一份模型配额；且官方团队工具会覆盖同名旧 subagent 控件，同开无收益。

## 2. 八维逐项对照

| 维度 | 官方 agent team | dsh-orchestrator |
|---|---|---|
| 阶段 | 无固定阶段，Lead 想 spawn 就 spawn、想发消息就发 | 强制顺序：planner → 独立可行性复核 → 原始字节快照 → 按依赖波次跑 worker → 独立 reviewer → 可选定向修复轮 |
| 能力边界 | **靠提示词策略**，README 自承「write scope 仅作提示」，Bash / formatter / 代码生成器可绕过 | **靠宿主校验**：只读角色无写权限、worker 只能改声明文件、文件分配互斥，越界直接拦；另有 `protectedFiles` |
| 模型路由 | `spawn_teammate` 只收 name/description/prompt/context，**teammate 继承会话模型** | 三角色各自 provider/model/effort（如 opus 规划、deepseek 写、gpt 复核），并可在 `/model` 探针里先验档位可用性 |
| 成员间通信 | 可互发 `send_message`、`wait_agent`、任务板 claim/complete | **完全无通信**，只有 `consumes/provides` 形成的 DAG，下游等上游 |
| 完成判定 | Lead 自述 + 任务板打勾 | 独立 reviewer 出结构化 verdict（`verified_statically` / `issues_found` / `unable_to_verify`），且契约禁止冒充「运行时已验证」 |
| 失败处理 | CAS revision 拒绝陈旧写；消息与任务持久化，崩溃可恢复；**不自动释放 owner** | 每个 worker 有原始字节快照，失败**回滚自己的文件**；单任务失败只跳过其下游 |
| 持久化 | Team 事件追加进 Lead 会话日志，roster/邮箱/看板可跨重启回放 | `~/.dsh/storages/orchestrator/jobs`，存 job 定义 + 每轮 plan/diff/review 快照（**运行档案，不是可恢复的活状态**） |
| 触发与成熟度 | 必须人明确说「建个团队」；标 experimental、不承诺稳定 | 必须先 `orchestrate_task` 存任务再 `orchestrate_run`；自家 2.0.12，76 项测试 |

## 3. 三个真正值得展开的差别

**① 权限是真拦还是嘴上说说。**
官方成员共用同一 cwd 与 checkout，隔离只有「写范围提示」，README 原文承认 Bash、formatter、代码生成器与直接外部写入可以绕过文件版本检查，Lead 必须自己协调 owner 并检查最终 diff。自家编排里 worker 改到未声明文件是被宿主拒绝的——这是实现路线的分水岭，不是配置差异。

**② 模型能不能混（最不可互替的一点）。**
官方每个 teammate 都跟随会话模型，无法让「负责验收的那个用 gpt」。自家天生三路由，这既是跨模型互审的前提，也是踩到「deepseek 路由不支持 reasoning effort 必须省略 effort 字段」这类坑的原因（该坑详见记忆中的默认配置条目）。

**③ 谁来兜住「AI 说自己做完了」。**
官方没有独立验收环节，完成与否是 Lead 自述。自家把自述换成另一个模型的只读复核，并强制结论里写明「未执行构建/测试」、把待验证项按 kind/expected 交回主会话执行。
**代价**：reviewer 看得见验收条件却跑不了任何东西，只能把待验证项标成待人工验证——「reviewer 全判 red」不是缺陷，是这个设计的固有代价。

## 4. 什么时候用哪个

- **探索性、需要中途改主意**（先看看仓库哪里有问题，再分头修）→ 官方 agent team，Lead 能边看边调人。
- **结构固定、要跨模型互审**（按验收标准改指定文件，改完被另一个模型挑刺）→ 自家编排。
- **几十个并行**（审 200 个文件）→ 官方 `workflow`。

上限与下限的权衡：官方上限更高、下限更低（Lead 判断失误就全歪）；自家上限低一些（流程固定，规划错就整轮白跑）但下限稳。
**重要归因**：遇到「11/21 跑不完」这类属于**基础设施稳定性**（401/524/提前结束）的问题，换成官方团队一样会发生，且没有 rollback。

## 5. 关联

- `f3e88214-9bd9-4a3f-bfb7-4d1bd0125017`：DSH 是否有「工程量大就自动编排」——结论是没有，委派只由显式工具调用或 preset 决定，含各工具门禁措辞。本篇是它的对照面：官方形态之间存在差异，而自家编排属于第四种。
- `aac1741e-a57b-419a-9842-695f14b6c707`：多模型协作的先例与成熟模式（strong-planner/cheap-worker、级联、路由、MoA），说明自家三路由设计并非自创。
