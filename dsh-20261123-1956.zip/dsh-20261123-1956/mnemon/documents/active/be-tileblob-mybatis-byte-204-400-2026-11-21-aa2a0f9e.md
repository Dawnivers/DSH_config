---
id: "aa2a0f9e-b2ee-41b6-97f2-f5892a48ad93"
title: "BE 矢量瓦片端点四层落地：TileBlob 绕 MyBatis byte[] 数组判定 + 204/400/缓存头实测（2026-11-21）"
description: "serviceAnalysis 后端 MVT 端点 /api/tiles/poi/{z}/{x}/{y}.pbf 的 DTO-Mapper-XML-Service-Controller 落地记录：MyBatis 把 byte[] 当多行结果的根因与 record 包装修法、_byte[] 别名、z/x/y 校验与 204 空瓦片、Cache-Control、gzip 白名单，以及五项接口实测与 forked JVM 占端口的排错。"
status: "active"
created_at: "2026-11-21T13:25:59.532Z"
updated_at: "2026-11-21T13:25:59.532Z"
content_hash: "b6385f265e373e9d9f0c42fffee27881ac210829bc29201190ccef32925d62d6"
source_paths:
  - "serviceAnalysis/BE/src/main/java/com/dawnivers/be/controller/TileController.java"
  - "serviceAnalysis/BE/src/main/java/com/dawnivers/be/service/TileService.java"
  - "serviceAnalysis/BE/src/main/java/com/dawnivers/be/mapper/TileMapper.java"
  - "serviceAnalysis/BE/src/main/resources/mapper/TileMapper.xml"
  - "serviceAnalysis/BE/src/main/java/com/dawnivers/be/dto/TileBlob.java"
  - "serviceAnalysis/BE/src/main/resources/application.properties"
session_ids:
  - "d41de003-197e-466e-b2e0-a7d241f95b99"
memory_body_ids:
  []
---

# BE 矢量瓦片端点四层落地（2026-11-21 实测）

库侧的 `poi_mvt()` 已在 `66713d2a-95db-4c77-ba5b-4bcbcd0c348f` 记录，瓦片字节编码与 bytea 去向见 `7c5042f6-1d33-4f08-9063-8c472b39b80b`，网格与 extent 尺度见 `97c90c7e-30cd-4865-bd85-1cb7691fbc36`。本文只记**后端这四层怎么包、踩到什么坑、实测结果**。

## 1. 五文件交付（路径按项目体例）

| 层 | 文件 | 职责 |
|---|---|---|
| DTO | `serviceAnalysis/BE/src/main/java/com/dawnivers/be/dto/TileBlob.java` | 仅包一层 `record TileBlob(byte[] data)`，业务上无字段 |
| Mapper | `serviceAnalysis/BE/src/main/java/com/dawnivers/be/mapper/TileMapper.java` | `TileBlob selectPoiTile(int z,int x,int y)`，三个 `@Param` 全参数化 |
| XML | `serviceAnalysis/BE/src/main/resources/mapper/TileMapper.xml` | `SELECT poi_mvt(#{z}, #{x}, #{y}) AS data` |
| Service | `serviceAnalysis/BE/src/main/java/com/dawnivers/be/service/TileService.java` | z/x/y 校验（400）、空瓦片归一成 `new byte[0]` |
| Controller | `serviceAnalysis/BE/src/main/java/com/dawnivers/be/controller/TileController.java` | 路由 `{y:[0-9]+}.pbf`、Content-Type、204、Cache-Control |

配置只加一行：`server.compression.mime-types` 末尾追加 `application/vnd.mapbox-vector-tile`；`min-response-size=2048` 不动（z16 小瓦片才 ~188 B，压了更大）。

## 2. 本轮最值钱的坑：MyBatis 不认 `byte[]` 返回值

第一版直接 `byte[] selectPoiTile(...)`，接口 500，body 只有 `"message":"argument type mismatch"`。堆栈落点：

```
MapperMethod.convertToArray(MapperMethod.java:186)
MapperMethod.executeForMany(MapperMethod.java:154)
```

**根因**：MyBatis 解析方法签名时看到「返回类型是数组」就判定为**多行结果**（它分不清 `byte[]` 和 `User[]`），走 `executeForMany` 把每行塞进数组；而实际只有一行、那行本身就是 `byte[]`，于是 `Array.set` 类型不匹配。

**修法**：包成对象，让 MyBatis 回到普通 resultMap 路径，内层 `byte[]` 交给 `ByteArrayTypeHandler` 读 PostgreSQL `bytea`：

```xml
<resultMap id="TileBlobMap" type="com.dawnivers.be.dto.TileBlob">
  <constructor>
    <arg column="data" javaType="_byte[]"/>
  </constructor>
</resultMap>
```

两个别名细节，错一个就静默失败：
- `javaType="_byte[]"`（带下划线）才是原始类型 `byte[]`；不带下划线的 `byte[]` 指包装类 `Byte[]`。
- XML 的 `AS data` 必须与 record 分量名一致，否则构造出 null。

**结论修正**：上一轮判断「这个接口不需要 DTO 层」是错的——DTO 回来了，不是为了映射业务字段，而是为了让 MyBatis 停止把返回值当数组。这也说明：ORM 能力在这里一处都用不上，保留 Mapper/Service 只是为与其它接口同构，为将来 Redis 缓存 / 按 z 分流 / 多图层合并留位。

## 3. 接口契约

- 路由：`GET /api/tiles/poi/{z}/{x}/{y:[0-9]+}.pbf`（Spring 6 `PathPattern` 支持后缀，`/abc.pbf` 已被挡成 404）。
- 校验：`z ∈ [0,22]`，`x,y ∈ [0,(1<<z)-1]`，越界抛 `ResponseStatusException(BAD_REQUEST)`，因此 400 的 body 里有可读 reason——前提是 `application.properties` 的 `server.error.include-message=always`（早前为 `/api/poi/within` 的多路 400 加的）。`1<<22` 仍在 int 内；MAX_ZOOM 放到 31 以上必须换 long。
- 空瓦片：库函数返回 0 字节 bytea（非 NULL），Service 归一为 `byte[0]`，Controller 返 **204 + Cache-Control**，不返 404（避免代理/客户端反复重试）。
- 响应头：`Content-Type: application/vnd.mapbox-vector-tile`（否则 OL 不解码）、`Cache-Control: max-age=21600, public`（6 h，poi 随 ETL 增量更新，不设一年）。
- gzip 不在代码里做，交给 Spring compression filter，靠上面的 mime-types 白名单生效。

## 4. 实测（5 项全过）

| 用例 | 期望 | 实际 |
|---|---|---|
| `12/3351/1684.pbf` | 396 B | 200 · 396 B · 前 4 字节 `1A 89 03 0A` |
| `12/3348/1682.pbf` | 53,869 B | 200 · 53,869 B |
| `12/1682/3348.pbf`（空地） | 204 | 204 |
| `99/1/1.pbf` | 400 | 400，message 说明范围 |
| 带 `Accept-Encoding: gzip` | 压缩 | `Content-Encoding: gzip` |

## 5. 排错要点：改完代码仍复现旧错误

`job_kill` 只杀了 `mvn` 父进程，**fork 出去的 java 仍占着 8094**，跑的是旧类。症状是「改了没效果、5xx 一模一样」。处理：查 `Get-NetTCPConnection -LocalPort 8094` 找到 PID，`Stop-Process` 掉 mvn 与 forked java 两个进程，确认端口空再 `& 'D:\maven\bin\mvn.cmd' -B -q -DskipTests spring-boot:run`。

## 6. 交付方式与 git 状态

文件当时已落盘并跑通，供对照；用户之后明确要求**以后把代码贴出来自己敲，不直接写进仓库**。`BE/.gitignore` 只挡 `target/ *.iml .idea/ application-local.properties *.log`。`05_mvt_poi.sql` 已随 `fac5621 feat(DB): poi 矢量瓦片函数（3857 生成列 + GiST + ST_AsMVT）` 入库（先前文档里"05 尚未入库"的缺口已闭），`main` 领先 `origin/main` 1 个提交。

下一步（W1 验收剩下的一件）：前端 `FE/src/map/mvt.js` + `mapView.vue` 把 poi 换成 `VectorTileLayer`。
