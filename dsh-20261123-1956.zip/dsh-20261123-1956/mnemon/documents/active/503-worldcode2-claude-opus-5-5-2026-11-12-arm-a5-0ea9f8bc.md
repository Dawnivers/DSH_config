---
id: "0ea9f8bc-802e-4617-9ac3-68f552d821e1"
title: "编排链路 503 根因诊断：worldcode2 / claude-opus-5-5 上游账户池容量（2026-11-12，arm-a5）"
description: "记录「单独对话能调 Claude、一跑编排就 503」的完整排查：排除插件/协议/signature 假设，定位为上游账户池容量与重试窗口过短，附实测证据与规避/根治配置。"
status: "active"
created_at: "2026-11-12T08:53:35.730Z"
updated_at: "2026-11-12T08:53:35.730Z"
content_hash: "562ccfbbbea9838144c617f851e37ec07d03b9ee79732b120e3ac42c82eb1f6b"
source_paths:
  - "orchestration-503-diagnosis.md"
session_ids:
  - "5d1d8ee5-ea27-4480-9290-51184a026256"
memory_body_ids:
  []
---

# 编排链路 503 根因诊断（worldcode2 / claude-opus-5-5）

## 证据范围与关联

本记录依据 2026-11-12 已完成父会话的有界检查点：用户只要求诊断「为什么单独对话能调 Claude，编排就不行」，父会话以一系列可重复运行的探针脚本完成变量分离，并写出诊断报告。维护儿童未重新打开文件、未重复运行探针；报告全文未在检查点内展开，脚本内容亦仅有创建回执，只有其**输出**是直接证据。下列结论按实测输出记录，不视为对网关内部实现的源码审计。

相关文档：`7477dea5-2363-46b3-a27d-03c693c1868b`（dsh-orchestrator v0.2.4 arm-a5 修复验收与上线边界，其中把「供应商 503 是否恢复」列为未解决边界）——本篇补充的就是该未解决边界的原因与处置。工作区：`D:\DSH_test_lab2\arm-a5`。

## 结论

问题与「编排」机制本身无关，而是供应商侧账户池容量：

- `worldcodes.online` 网关的 `claude-opus-5-5`（provider `worldcode2`）上游账户池小且波动大，池满即返回 `503 {"error":{"message":"No available accounts: no available accounts","type":"api_error"}}`（code `SERVER`）。
- 单请求本身耗时 5~90 秒（中位数约 30 秒），偶发 120 秒以上，会被 Cloudflare 挡成 524。
- 单独对话通常 1~2 步即结束；编排 planner 必须先 glob/read 摸清项目再规划，天然多步，第 2 步再次请求时撞上池容量。
- DSH 默认重试 5 次、总窗口约 16 秒，而实测尖峰可持续 40 秒以上，因此重试常常全灭后判负。

## 关键实测证据

宿主会话日志聚合（当天全部 agent 失败，按 step 归类）：

| step | code | 消息 |
|---|---|---|
| 1 | TIMEOUT | Request timed out. |
| 2 ×6 | SERVER | 503 No available accounts |
| 6 | TRANSPORT | Anthropic stream ended without a stop reason |

即 **6/6 次 503 全在 step 2**，且这些会话的 step 1 全部成功并已发出 `glob` 工具调用。

planner 子会话回放（`llm/retry` 事件）证明重试确实发生：`policyKey=["normal",5,["EMPTY_RESPONSE","RATE_LIMIT","SERVER","TIMEOUT","TRANSPORT"],500,10000,0.1]`，退避 515 → 1082 → 1929 → 3647 → 8422 ms，5 次后 `turn/end reason.kind=error`。

逐项排除（均为检查点内的探针输出）：

- thinking signature 回传丢失：真实会话的 signature 解码为 `{"agentContinuationId":"245c259d-...","mintedAtMs":1794467984638,"modelHash":"3RtVG0s2grTg","slots":[],"v":1}`；用真实 assistant 消息回放（含 signature + 5811 字符大工具结果）5 变量分离，两轮全部 200/stop=tool_use（仅一轮出现 503 属池瞬时状态，签名置空、删除 thinking 块同样 200）。
- 工具调用协议：step1/step2 对照各 8/8 成功。
- planner 提示词/模型形态（大 system + 4 工具 + thinking）：串行 8/8、并发 4/4、持续 12 步循环 11/12（唯一失败为 524，127 秒）。
- 交错 A/B 各 8 次：短对话 7/8（1 次 524）、planner 形态 8/8 —— 说明是池的瞬时状态而非请求形状。
- 账户池并发：opus 并发 6 → 6/6 成功但耗时 22~44 秒；haiku 并发 6 → 6/6、3.5~5 秒；opus 等 15 秒再并发 6 → 6/6、5.6~18.8 秒。
- 尖峰后立即按 DSH 真实退避重试：5 次全成功（重试窗口内 0/5 失败）；继续等待观察，+40 秒仍有单次 503。
- 各路路由实测：Claude Opus 5.5 / Haiku 5.5 / Qwen3.8-flash / GPT-6.1-sol / deepseek-v4.1 各 3 次全部 200。

## 处置

**临时跑通**：planner 换 `claude-haiku-5-5`（同供应商但独立池，实测 2 秒级），或临时用 `deepseek-v4.1`；也可错峰 2~5 分钟重跑。

**根治**：在 `cordis.patch.yml` 的 `worldcode2` 下显式覆盖重试策略，把总窗口从约 16 秒拉到约 2 分钟，改完需重启 DSH：

```yaml
retryPolicy:
  mode: normal
  maxRetries: 8
  backoff:
    initialDelayMs: 2000
    maxDelayMs: 30000
```

排查过程中同时确认：插件侧（dsh-orchestrator v0.2.4）如实记录了 503 与完整重试链，表现正确；5 把 API key 均在、配置正确。故不需要修改插件或凭据。

## 原始产物

- [诊断报告全文](<D:/DSH_test_lab2/arm-a5/orchestration-503-diagnosis.md>)（父会话写入，检查点仅确认创建，未展示正文）。
- 复现探针（工作区外，均在 `D:\temp\`，检查点仅确认创建）：`multiround-trial.mjs`、`real-shape-probe.mjs`、`sustained-probe.mjs`、`replay-probe.mjs`、`isolate-probe.mjs`、`step-rate.mjs`、`size-decide.mjs`、`pool-probe.mjs`、`ab-compare.mjs`、`recovery-window.mjs`、`all-providers.mjs`；会话反解辅助 `dump-planner-session.py`、`dump-structure.py`、`build-replay.py` 等。
