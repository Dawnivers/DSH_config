---
id: "b31065ed-11e5-4485-bacb-d2c3be7daf5c"
title: "arm-a9：游动行波方向与鳍相位回绕两处真缺陷的修复、object-space 振幅剖面验收与逐角色成本（2026-11-13）"
description: "arm-a9（D:\\DSH_test_lab2\\arm-a9）worldcode 编排 review_failed 后由主会话修掉两处真缺陷：行波 sin(phase - x*k) 使波峰在尾部朝头回卷、已 wrap 相位再乘非整数倍导致回绕跳变；附 35 项 swim-check 验收、object-space 振幅剖面替代屏幕空间指标的判据、81 次调用 ¥0.8128 逐角色账与 4173 端口冲突处置。"
status: "active"
created_at: "2026-11-13T14:13:26.438Z"
updated_at: "2026-11-13T14:13:26.438Z"
content_hash: "faa0f1e234865ec1f3ea08501074496048e88b7b9acac39b0311cd883019db58"
source_paths:
  - "src/koi.js"
  - "src/swim-config.js"
  - "src/main.js"
  - "dist/app.js"
  - "_verify/swim-check.mjs"
session_ids:
  - "3c216c8f-07d8-4f55-8840-9c33eebaaca0"
memory_body_ids:
  []
---

# arm-a9：游动行波方向与鳍相位回绕的修复与验收

日期：2026-11-13（Asia/Shanghai）。依据完成检查点中的工具输出与最终结论保存，未重新打开文件或复跑实验。

## 关联与边界

- `981bf163-9596-4e2b-ad5f-79539910c398`（arm-a5）：同一站点游动行波的 A/B 量化基线、旧版构建 `FF53234F…` 可复现性、误覆盖后按 seq 重放恢复的方法。
- `79224afa-a7ff-4519-94ff-8018ca1fb8a6`（arm-a8）：吻部/鳍遮罩覆盖率类缺陷的同类「代码存在 ≠ 参数可达」教训。
- `605ddc8b-daa4-4374-aea3-21339e784bd2`（arm-a4）：35 项验收的组织方式与受保护 bundle 的验收路径。

工作区 `D:\DSH_test_lab2\arm-a9`，编排任务 `b618b0eb`，边界 `arm-a9/**`。编排最终状态为 `review_failed`——worker 三个文件都改了，但 reviewer 只读代码、不运行，挑出两个真实缺陷。**主会话修复并验证通过，但原始编排状态不得追写为成功。**

## 两处真缺陷（reviewer 挑对，已复现）

1. **行波方向反了**：`sin(phase - x*k)` 配合 phase 随时间递增，波峰向 `+x` 传播；而 koi 的尾部在负 x，等效于尾巴上的波朝头回卷。修法：改为 `sin(uSwimPhase + p.x * uWaveNumber)`（`src/koi.js:714`）。
2. **相位回绕跳变**：先把相位 `wrap` 到 [0,2π) 再乘非整数倍（`wrapPhase(wavePhase * 1.6)`，shader 里又对已取模的 `uFinPhase` 乘 `0.82`），回绕瞬间相位从 4.12 突跳到 0.35，产生可见抖动。修法：每条相位**独立累加、只做整 2π 回绕**，shader 侧只保留常数偏移（`-1.05`）不再缩放（`src/koi.js:718, 729`、`src/swim-config.js:90`）。

一般化判据：**对已 wrap 的相位只允许加减常数，任何非整数倍缩放都会在回绕点产生非整周突变。**

## 验收证据

- `tools/swim-check.mjs`（本轮新增，218 行）：**35 通过 / 0 失败**。覆盖相位连续性（speed=1/12s、speed=4/8s、speed=0.25/20s，跨多个 2π 回绕）、传播方向（波峰 x `0.727 → 0.650`，Δ=`-0.076`，负值即头→尾）、快慢单调、体轴振幅剖面。
- 浏览器动态验证 19 项通过；项目自带 `tools/qa.mjs` 四视口正常、particles=38888、errors none；`dist/app.js` esbuild 重建零报错（840.4kb）。
- 运动速率单调：0.25x=2.17 → 1x=3.13 → 4x=5.16；reduced-motion 下变化率 ≈0（真静止）。

**关键判据方法（可复用）**：屏幕空间帧间差分**不能**直接当作头尾证据，因为相机朝向会改变投影。本轮先跑像素分析得到「右端/左端 ≈ 694×」，随后自我否定并改用与相机无关的 **object-space 振幅剖面**。

剖面第一版还踩了一个坑：用 `aFlex=1` 的最坏情况算头部，得到 tail=0.1039 / head=0.0484（2.15×），虽通过但失真；改为按各 x 位置的真实 flex 后：尾部 `x=-1.5 → 0.1033 (flex 0.97)` 到头 `x=0.9 → 0.0290 (flex 0.15)`，比值 **3.56×**，从头到尾单调递增。**验收断言必须用真实系数，而不是上界。**

## 文件状态与改动范围

相对基线 sha256 对比，仅三个源文件变化：`src/swim-config.js`、`src/koi.js`、`src/main.js`；`index.html`、`styles.css` 与基线完全一致（未被动过）。重建 `dist/app.js`（860,522 B）。旧的硬编码游动项已消失，`swim-config.js` 的 import 唯一（第 10 行）。

## 成本口径（原始任务的第二要求）

按 cost-meter 账本 `C:\Users\...\.dsh\storages\cost-meter\ledger.json` 的 `days.<date>.sessions` 按时间窗口（UTC 13:44–14:01）筛会话统计，共 **81 次调用**：

| 模型 | 角色 | 调用 | USD | CNY（×7.2） |
|---|---|---|---|---|
| worldcode2:claude-opus-5-5 | planner | 21 | 0.040504 | ¥0.2916 |
| deepseek-official:deepseek-flash | feasibility + 2 workers | 47 | 0.064447 | ¥0.4640 |
| worldcode:gpt-6.1-sol | reviewer | 13 | 0.007932 | ¥0.0571 |
| 合计 | | 81 | 0.112883 | ¥0.8128 |

账本为按分钟/天数聚合的本地估算，非供应商实扣凭据；`reasoning` 字段恒为 0，不能解释为模型无推理。工具侧注意：`ledger.json` 顶层含 `planSamples`/`planHourBuckets` 等可能为 null 的字段，PowerShell 直接链式取属性会 `InvalidOperation`，需逐层判空。

## 环境坑

`tools/shot.mjs` 本身跑不起来：4173 端口被残留 node 进程占用（PID 28268，`E:\node.exe`）。本轮未杀该进程，改在 4190 端口出图，输出到 `.shots/verify-20261113/`，未覆盖原参考截图。另外当前模型不支持图像输入，无法直接看 PNG，只能用像素/差分热力图分析并 `present` 给用户——验收脚本应尽量输出**数值**而非只出图。

## 待确认事项

原始任务措辞为「鲸鱼」，但项目主体是锦鲤粒子（Koiyama）。本轮按「保留原资产、只改游动手感」处理，未换物种；若要真换鲸鱼形态需重做点云，属另一件事。
