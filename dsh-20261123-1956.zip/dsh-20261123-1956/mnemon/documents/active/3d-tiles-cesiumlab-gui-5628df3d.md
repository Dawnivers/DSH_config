---
id: "5628df3d-3dd8-4f0f-9d33-4c26c82d81e0"
title: "3D Tiles 性能调优的可复现方法：三层拆解、开源工具链与「中游」定位（替代 Cesiumlab GUI）"
description: "回应用户「只会点 Cesiumlab、认为自己没掌握三维性能优化、是否需要无人机/执照/建模」的质疑：把三维性能调优拆成数据层/运行时层/度量层，给出免申请的开源工具链（3d-tiles-tools、py3dtiles、gltf-pipeline、gltfpack）、SSE 切换原理与可调参数、度量表模板，以及上游/中游/下游分工与无人机法规《国务院令第761号》的结论，附四周可执行清单。"
status: "active"
created_at: "2026-11-18T08:02:29.831Z"
updated_at: "2026-11-18T08:02:29.831Z"
content_hash: "1f5e1e10445a5813ac2bbd30ca192af4401667bce08eeb533dfb5f224c544cef"
source_paths:
  - "求职/两条路一页.html"
  - "求职/求职时间线_2026-11_2027-06.xlsx"
  - "求职/build_timeline.py"
session_ids:
  - "466a38e0-21a8-4c3e-bca4-6c5d0bcf7e5f"
memory_body_ids:
  []
---

# 3D Tiles 性能调优的可复现方法（2026-11-18 会话产物）

前序文档：三维权重已被下调为「差异化证据」而非职业主线，见 `da16df8d-76d7-4f3e-bb8f-7181b813a903`；渠道/比赛/时间线见 `5e5a2f11-a6dd-47be-8ea3-43e834f52fac`；P0–P4 能力补齐路线见 `b8259dad-91bd-41dc-9632-f910dcf9bd9e`；JD 词频见 `0602ba33-1c09-49ac-ad67-6e04b1a0fdc7`。

**本文只解决一个具体问题**：用户的全部三维经验是「用 Cesiumlab GUI 把 shp 拉伸成白模 → LOD 分片 → 顶点压缩 → 在 tileset.json 里手工限定显示的 LOD 层」，且该工具需要申请、非随时可用。因此他判断「我没掌握三维性能优化，受制于人」，并连带担心「是否必须学无人机 + 飞行执照」「是否要自己建模」。本文记三层拆解、开源替代、法规结论与四周清单。

## 1. 核心判断

**「点 GUI」与「掌握」的差别只有两个词：可复现、可解释。**

- 可复现：同一条命令能重跑、能进 CI、不依赖某台装了 Cesiumlab 的机器；
- 可解释：知道那个勾选框改的是 `tileset.json` 里的哪个数值。

用户的判断是对的——他做的是**数据预处理**，不是**调优**；但这是工具绑住了手，不是能力问题。换工具后两条立刻都有。

另外，「切了 10–20 只显示 10–14」的性质要讲清：那是**人为砍掉最细几层**，属于**权衡**（清晰度换流畅度），不是优化。优化的门槛是能说出量化代价：「砍掉 4% 三角形、首屏快 1.2 秒」。

## 2. 三维性能调优的三层

| 层 | 干什么 | 典型手段 | 用户现状 |
|---|---|---|---|
| **数据层**（离线） | 决定「有多少数据要传」 | LOD 切分、顶点压缩、纹理压缩、去内部面、简化、空间索引 | ✅ 只碰了这层，且靠 GUI |
| **运行时层**（浏览器） | 决定「传多少、画多少」 | `maximumScreenSpaceError`、缓存预算、按需渲染、裁剪、合批 | ❌ 未接触 |
| **度量层** | 决定「怎么知道变好了」 | Cesium Inspector、Chrome Performance、Spector.js、显存/绘制调用统计 | ❌ 未接触 |

### LOD 何时切换：屏幕空间误差（SSE）

```
SSE = geometricError × 屏幕高度 ÷ (2 × 距离 × tan(fov/2))
```

**当 SSE > `maximumScreenSpaceError`（默认 16）时加载子节点。** 关键可调参数：

```js
tileset.maximumScreenSpaceError = 16;   // 调小到 8：更清晰、更吃性能
tileset.cacheBytes = 256 * 1024 * 1024; // 缓存预算，超了开始卸载
tileset.maximumMemoryUsage = 512;       // 显存上限（MB）
viewer.scene.requestRenderMode = true;  // 场景静止时不逐帧重绘
```

推论：Cesiumlab 的「LOD 分片」本质就是改 `geometricError` 与树的深度；「顶点压缩」本质就是调用 Draco。**这一条就是「受制于人」的解药。**

## 3. 打开黑箱的三个动作（全免费、免申请）

1. **拆开自己的白模**，看里面到底是什么：
   ```bash
   npx 3d-tiles-tools convertB3dmToGlb -i ./tiles/0.b3dm -o ./out/0.glb
   npx 3d-tiles-tools --help        # convert* / optimize* 一族
   ```
   （CesiumGS 官方 npm 包 `3d-tiles-tools`，无需申请。）
2. **手工造一次 tileset，与 Cesiumlab 输出 diff 对比**。开源可替代：
   - OSGB → 3D Tiles：`shitou186/osgbTo3DTiles`、`VillageMoonlight/OSGB-3DTiles`（支持 1.0 b3dm 与 1.1 glb 双版本）
   - 点云 LAS/LAZ → 3D Tiles 1.1：`py3dtiles convert cloud.las --out ./tileset_dir`
   - 压缩：`gltf-pipeline -i m.glb -o m_draco.glb -d`（Draco）／`gltfpack -i m.glb -o m.glb -cc`（meshopt）
   同一份数据跑两遍，diff 两个 `tileset.json`。
3. **拿数字说话**：Cesium Inspector 看瓦片加载数/层级/内存；Chrome Performance 录 10 秒；Spector.js 抓一帧看 draw call。同一场景跑 SSE = 8/16/32 三档，出表：

   | SSE | 首屏(ms) | 帧率(P50) | 显存(MB) | 瓦片请求数 |
   |---|---|---|---|---|
   | 8 | | | | |
   | 16 | | | | |
   | 32 | | | | |

   **这张表就是「掌握」的证明**：从「我点了哪个按钮」升级为「我把显存从 1.2G 压到 480M，代价是远景糊了一点」。

## 4. 无人机与执照：不需要

法规依据：《无人驾驶航空器飞行管理暂行条例》（国务院令第 761 号，2024-01-01 施行）。

- 微型、轻型：**无需操控员执照**，只需熟练掌握操作方法、了解风险警示；
- 轻型在管制空域飞行，需通过局方理论培训考试取得「安全操控理论培训合格证明」；
- **小型及以上**才需操控员执照；
- 飞行一般需**提前 1 日 12 时前**向空管机构申请；真高 120 米以上、机场周边、军事/重要设施周边属管制空域。

但**这构不成门槛**：WebGIS 岗不要求你飞。你不需要当「数据采集者」，而是「数据加工者」。

## 5. 上游/中游/下游：位置在中间

用户「数据生产是上游，和 WebGIS 中下游不符」的直觉是对的，只是切分位置差一格：

```
上游：外业采集（无人机、测绘、空域审批、执照）
  ↓
中游：数据加工（OSGB→3D Tiles、轻量化、配准、发布）   ← 真正的位置
  ↓
下游：Web 端渲染与业务（Cesium、交互、分析、性能）      ← 已在这里
```

**不需要「种麦子」，但要会「磨面」。** 磨面不需要执照也不需要无人机。

数据来源全部免费/公开：Cesium 官方 3D Tiles 样例（基准对比）、OSM 建筑 + BlenderGIS（拉伸白模，已会）、公开点云（OpenTopography、USGS 3D Elevation）、IFC/BIM（练 glTF 转换与批处理属性）、商业样例（大疆智图、ContextCapture 输出的 OSGB）、自切 shp → 白模 → tileset（全链路复现，不依赖 Cesiumlab）。

**关键认识**：中游的「生产」= 把别人采的数据变成能流畅加载的瓦片，不是自己去采。招聘 JD 写「熟悉 3D Tiles/OSGB 解析与处理」，从来不写「会飞无人机」。

## 6. 要不要学建模

**不要成为建模师**（3ds Max/Blender 建模是美术岗，学 3 个月也打不过科班）。工程侧只需三件事：

1. **读/改 glTF**：节点树、材质、纹理引用、PBR 参数；
2. **轻量化**：减面（QEM）、合并、纹理图集、Draco/meshopt/KTX2；
3. **语义化**：给构件挂 `batch id` 与属性——用户分层分户项目里已有「构件级」数据，**这是三维里最值钱的部分**（点选、查询、统计），比「好看」值钱得多。

## 7. 四周可执行清单（对齐时间线 W11–W15 寒假档）

| 周 | 任务 | 验收物 |
|---|---|---|
| W1 | 装 3d-tiles-tools / py3dtiles / gltf-pipeline；拆自己的白模，读 `tileset.json` 树 | 结构笔记：节点数、geometricError 序列 |
| W2 | 开源工具重切一版，与 Cesiumlab 输出 diff | 差异表（改什么参数 → 什么效果） |
| W3 | SSE 三档（8/16/32）+ Inspector + Performance | 三档对比表（首屏/帧率/显存/请求数） |
| W4 | 轻量化实验（Draco vs meshopt、KTX2 纹理） | 体积-显存-帧率表 + 结论 |

四周后即可主张「掌握三维性能调优」——不是因为学会了按钮，而是因为能命令复现、数字证明。

## 8. 一句话收束

**缺的不是无人机，是命令行。** Cesiumlab 让你「能出结果」，开源工具让你「知道为什么」：把黑箱换脚本、按钮换参数、感觉换表格。

## 9. 相关产物路径

- 二维/三维两条路 A4 一页对比（含 78:22 配比与「6 周试验」）：`D:\WebGIS\求职\两条路一页.pdf`，源文件 `D:\WebGIS\求职\两条路一页.html`（单页 A4 横向，改字后重新导出）。
- 求职时间线 Excel（W11–W15 即本文四周清单的落点）：`D:\WebGIS\求职\求职时间线_2026-11_2027-06.xlsx`，生成脚本 `D:\WebGIS\求职\build_timeline.py`。
- 岗位匹配清单与脚本：`D:\WebGIS\求职\WebGIS岗位匹配清单_2026-11-18.xlsx`、`D:\WebGIS\求职\build_job_sheet.py`。
- 两份 Excel 均为脚本生成、数据源在脚本内的列表里，改数据重跑，不手改 xlsx。
